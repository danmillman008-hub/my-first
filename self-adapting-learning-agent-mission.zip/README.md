# Private Self-Adapting Learning Agent

**One learner. One continuous tutor.** Say what you want to learn — any subject — answer its checks, ask questions, push back when it is wrong about you. The tutor keeps a persistent, inspectable, correctable model of *what you know* (from what you demonstrate, not what you were told) and of *how explanations land for you*, and it runs a learning loop (teach → check → apply → transfer → spaced review → misconception remediation) so that every turn produces evidence of learning.

- `FINAL_ARCHITECTURE.md` — what the system is and why.
- `RESEARCH_SYNTHESIS.md` — forensics of the previous attempts and the learning-science evidence that shaped decisions.
- `EVALUATION.md` — the laboratory, ablations, results, and what has *not* been shown.
- `DECISION_LOG.md` — decisions, alternatives, evidence.

## Run

```
npm install
npx drizzle-kit push          # creates the tables (DATABASE_URL from .env)
npm run dev                   # http://localhost:3000
```

Optional environment: `OPENAI_API_KEY` (+ `OPENAI_MODEL`, `OPENAI_BASE_URL` for any OpenAI-compatible endpoint) enables model-written prose, answers to open questions and synthesis of packs for unknown subjects; without it the tutor runs fully offline with curated packs (Bash, statistics, Spanish, music theory) and Wikipedia research. `RESEARCH_ENABLED=0` disables research. `MCP_TOKEN` protects `POST /api/mcp`. `LEARNER_CALIBRATION=1` enables per-learner forgetting calibration (neutral in simulation, hence opt-in).

## Verify

```
npm test              # unit tests for the pure core
npm run adversarial   # 38 regression checks against the real engine
npm run lab           # synthetic-learner benchmark + ablations (deterministic, ~2 s)
```

## HTTP

- `POST /api/chat` `{ message }` → `{ reply, trace, domain, sessionId }` (identity via `pal_learner` cookie)
- `GET /api/memory` → beliefs (status, confidence, provenance), knowledge states (retention, stage, next review), approach statistics
- `POST /api/memory` `{ beliefId, replacement? }` → "that's not true about me"
- `POST /api/mcp` — JSON-RPC 2.0: `tutoring_turn`, `get_learner_model`, `challenge_belief`
- `GET /api/health`

## Docker

```
docker compose up --build     # app + postgres, runs drizzle-kit push on start
```
