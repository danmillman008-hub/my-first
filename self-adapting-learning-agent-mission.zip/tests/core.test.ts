import { test } from "node:test";
import assert from "node:assert/strict";
import { applyGrade, applyClaim, attribute, bktUpdate, confidenceFor, newKnowledge, retained, statusFor, applyReviewOutcome, newCalibration, daysUntilReview } from "../src/lib/core/epistemics";
import { perceive } from "../src/lib/core/perceive";
import { grade, conceptOrder } from "../src/lib/domain/types";
import { PACKS } from "../src/lib/domain/packs";
import { validatePack } from "../src/lib/domain/registry";
import { selectApproach, mulberry32 } from "../src/lib/core/bandit";
import { APPROACHES, type OutcomeRecord } from "../src/lib/core/types";

const now = new Date("2025-01-10T10:00:00Z");
const DAY = 86_400_000;

test("belief lifecycle: inferred beliefs must earn activity; contradiction contests then retires", () => {
  assert.equal(statusFor("inferred", 1, 0, 1, "candidate"), "candidate");
  assert.equal(statusFor("inferred", 2, 0, 1, "candidate"), "candidate"); // one session only
  assert.equal(statusFor("inferred", 2, 0, 2, "candidate"), "active");
  assert.equal(statusFor("inferred", 3, 0, 1, "candidate"), "active");
  assert.equal(statusFor("inferred", 3, 1, 2, "active"), "active", "a single contradiction against three supports is not enough to contest");
  assert.equal(statusFor("inferred", 4, 2, 2, "active"), "contested");
  assert.equal(statusFor("inferred", 3, 3, 2, "contested"), "retired");
  assert.equal(statusFor("stated", 1, 0, 1, "candidate"), "active");
  assert.ok(confidenceFor("inferred", 100, 0) <= 0.92, "inferred confidence is capped: never a verdict");
});

test("knowledge: claims set a prior but never override behaviour; recall updates p(known) and stability", () => {
  let k = newKnowledge("l", "bash", "pipes", now);
  Object.assign(k, applyClaim(k, 1, now));
  assert.equal(k.basis, "claimed"); assert.equal(k.pKnown, 0.6);
  Object.assign(k, applyGrade(k, { itemId: "x", itemKind: "recall", concept: "pipes", correct: false, matchedMisconception: null, priorPKnown: 0.6 }, now));
  assert.equal(k.basis, "demonstrated"); assert.ok(k.pKnown < 0.6);
  Object.assign(k, applyClaim(k, 1, now));
  assert.equal(k.basis, "demonstrated", "a later claim does not override demonstrated behaviour");
  const s0 = k.stability;
  Object.assign(k, applyGrade(k, { itemId: "x", itemKind: "recall", concept: "pipes", correct: true, matchedMisconception: null, priorPKnown: k.pKnown }, now));
  assert.ok(k.stability > s0, "successful retrieval increases stability");
  k = { ...k, pKnown: 0.9, stability: 2, lastEvidenceAt: now };
  assert.ok(Math.abs(retained(k, new Date(now.getTime() + 2 * DAY)) - 0.45) < 0.01, "half-life forgetting on read");
  assert.ok((daysUntilReview(k, now, 1, 0.7) ?? 0) > 0);
});

test("bkt moves in the right direction and stays bounded", () => {
  assert.ok(bktUpdate(0.5, true) > 0.5); assert.ok(bktUpdate(0.5, false) < 0.5);
  assert.ok(bktUpdate(0.99, false) < 0.99 && bktUpdate(0.01, true) > 0.01);
});

test("attribution: only explanations credit an approach; mastery confounds are down-weighted; corrections/topic switches are never attributed", () => {
  const base = { previousActivity: "teach", reaction: "neutral" as const, taskResult: null, requestedDifferentApproach: false, isCorrection: false, topicSwitch: false, priorPKnown: 0.5, sameSession: true };
  assert.equal(attribute({ ...base, previousActivity: "apply", taskResult: "correct" }), null, "apply items do not credit an approach");
  assert.equal(attribute({ ...base, isCorrection: true, reaction: "confused" }), null);
  assert.equal(attribute({ ...base, topicSwitch: true, reaction: "understood" }), null);
  assert.equal(attribute({ ...base, sameSession: false, reaction: "understood" }), null, "no cross-session attribution");
  const unknownFail = attribute({ ...base, taskResult: "incorrect", priorPKnown: 0.1 })!;
  const knownFail = attribute({ ...base, taskResult: "incorrect", priorPKnown: 0.5 })!;
  assert.ok(unknownFail.weight < knownFail.weight, "failing on an unknown concept says less about the approach");
  const knownSuccess = attribute({ ...base, taskResult: "correct", priorPKnown: 0.9 })!;
  assert.ok(knownSuccess.weight < 0.2, "success on a known concept is minimal evidence");
  assert.ok(attribute({ ...base, reaction: "confused" })!.outcome < 0);
});

test("perception: reactions and answers co-occur; requests are not questions; corrections are not requests", () => {
  const p = perceive("Makes sense. $count", true);
  assert.equal(p.reaction, "understood"); assert.equal(p.looksLikeAnswer, true);
  const q = perceive("Can you show me a concrete example?", true);
  assert.equal(q.requestedApproach, "worked_example"); assert.equal(q.looksLikeAnswer, false);
  const c = perceive("That's not true about me — I don't prefer worked examples.", true);
  assert.equal(c.isCorrection, true); assert.equal(c.requestedApproach, null); assert.equal(c.reaction, "neutral");
  const g = perceive("I want to learn Bash. I already know pipes", false);
  assert.equal(g.goalText?.toLowerCase().includes("bash"), true); assert.equal(g.selfReports[0]?.level, 1);
  assert.equal(perceive("Let's continue.", false).requestedApproach, null);
});

test("grading: text, numeric tolerance, distractor → misconception; packs are well-formed", () => {
  const stats = PACKS.find((p) => p.id === "statistics")!;
  const median = stats.concepts[0].items.find((i) => i.id === "mm-a1")!;
  assert.equal(grade(median, "it's 3").correct, true);
  assert.deepEqual(grade(median, "23.6"), { correct: false, matchedMisconception: "median-is-mean" });
  const bash = PACKS.find((p) => p.id === "bash")!;
  assert.equal(grade(bash.concepts[0].items[0], "you write $count").correct, true);
  assert.equal(grade(bash.concepts[0].items[0], "count").matchedMisconception, "var-no-dollar");
  for (const p of PACKS) {
    const ids = new Set(p.concepts.map((c) => c.id));
    for (const c of p.concepts) {
      for (const pr of c.prereqs) assert.ok(ids.has(pr), `${p.id}/${c.id} prereq ${pr}`);
      for (const kind of ["recall", "apply", "transfer"]) assert.ok(c.items.some((i) => i.kind === kind), `${p.id}/${c.id} needs a ${kind} item`);
      for (const i of c.items) for (const d of i.distractors ?? []) assert.ok(c.misconceptions?.some((m) => m.id === d.misconception), `${p.id}/${c.id}/${i.id} unknown misconception ${d.misconception}`);
    }
    assert.equal(conceptOrder(p).length, p.concepts.length);
  }
});

test("pack validation rejects malformed model output and sanitises shapes", () => {
  assert.equal(validatePack(null), null);
  assert.equal(validatePack({ label: "X", concepts: [] }), null);
  assert.equal(validatePack({ label: "X", concepts: [{ label: "c", kernel: "k", items: [{ kind: "apply", prompt: "p", accept: ["a"] }] }] }), null, "a concept without a recall item is dropped");
  const ok = validatePack({ label: "Knots", concepts: [{ id: "bowline", label: "Bowline", kernel: "A fixed loop.", prereqs: ["missing"], items: [{ id: "r", kind: "recall", prompt: "?", accept: ["loop"], distractors: [{ answers: ["slip"], misconception: "slip knot" }] }, { kind: "bogus", prompt: "x", accept: ["y"] }], misconceptions: [{ id: "slip knot", statement: "s", refutation: "r" }] }] }, "model");
  assert.ok(ok); assert.equal(ok!.concepts[0].prereqs.length, 0); assert.equal(ok!.concepts[0].items.length, 1); assert.equal(ok!.concepts[0].items[0].distractors![0].misconception, "slip_knot");
});

test("bandit: converges to the rewarded arm and other-domain evidence does not leak as in-domain evidence", () => {
  const rnd = mulberry32(7);
  const outcomes: OutcomeRecord[] = [];
  let t = now.getTime();
  let picks = 0, best = 0;
  for (let i = 0; i < 120; i++) {
    const sel = selectApproach({ outcomes, beliefs: [], domain: "bash", now: new Date(t), lastApproach: null, lastOutcome: null, consecutiveStrongFailures: 0, rnd, useLongTerm: true });
    const v = sel.approach === "analogy" ? 0.8 : -0.4;
    outcomes.push({ learnerId: "l", domain: "bash", approach: sel.approach, value: v, weight: 1, at: new Date(t), tutorTurnId: `t${i}` });
    if (i >= 60) { picks++; if (sel.approach === "analogy") best++; }
    t += 60_000;
  }
  assert.ok(best / picks > 0.6, `late best-rate ${best / picks}`);
  const other = selectApproach({ outcomes, beliefs: [], domain: "spanish", now: new Date(t), lastApproach: null, lastOutcome: null, consecutiveStrongFailures: 0, rnd, useLongTerm: true });
  const analogy = other.stats.find((s) => s.approach === "analogy")!;
  assert.equal(analogy.weight, 0, "no in-domain evidence in a new domain");
  assert.ok(analogy.prior > 0 && analogy.prior <= 0.6 * 0.35 + 1e-9, "only a shrunk prior travels across domains");
  assert.equal(APPROACHES.length, 6);
});

test("calibration moves the forgetting scale by surprise and stays bounded", () => {
  let c = newCalibration("l", "bash", now);
  for (let i = 0; i < 30; i++) c = { ...c, ...applyReviewOutcome(c, 0.9, false, now) };
  assert.ok(c.stabilityScale >= 0.3 && c.stabilityScale < 0.5);
  for (let i = 0; i < 60; i++) c = { ...c, ...applyReviewOutcome(c, 0.2, true, now) };
  assert.ok(c.stabilityScale <= 3);
});
