import { Engine } from "../../src/lib/core/engine";
import { InMemoryStore } from "../../src/lib/core/store";
import { OfflineProvider } from "../../src/lib/providers";
import { DomainRegistry } from "../../src/lib/domain/registry";
import { ARCHETYPES } from "./harness";
// Re-run one learner and print the tutor's activity stream (uses the same harness code path via a monkeypatched Engine.turn)
const name = process.argv[2] ?? "example_lover";
const orig = Engine.prototype.turn;
let n = 0;
Engine.prototype.turn = async function (this: Engine, id: string, msg: string, now: Date) {
  const r = await orig.call(this, id, msg, now);
  const d = r.trace.decision;
  n++;
  console.log(`${String(n).padStart(3)} ${now.toISOString().slice(0, 10)} L: ${msg.slice(0, 40).padEnd(40)} | T: ${d.activity.padEnd(9)} ${(d.concept ?? "").padEnd(12)} ${(d.approach ?? "").padEnd(18)} ${d.itemId ?? ""} ${r.trace.grade ? (r.trace.grade.correct ? "✓" : "✗") : " "} ${d.reasons[d.reasons.length - 1]?.slice(0, 70) ?? ""}`);
  return r;
};
import("./harness").then(async (h) => {
  const spec = ARCHETYPES.find((a) => a.name === name)!;
  const rep = await h.runLearner(spec, { name: "full", ablation: {} }, { sessions: 6, turnsPerSession: 8, seed: 1, retentionGapDays: 7 });
  console.log(JSON.stringify(rep, null, 0));
});
void InMemoryStore; void OfflineProvider; void DomainRegistry;
