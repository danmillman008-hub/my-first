// Adversarial / regression suite against the real engine (in-memory store, offline provider).
// Every check encodes a failure mode found in this or a previous attempt.
import { Engine } from "../../src/lib/core/engine";
import { InMemoryStore } from "../../src/lib/core/store";
import { OfflineProvider } from "../../src/lib/providers";
import { DomainRegistry } from "../../src/lib/domain/registry";
import type { Provider } from "../../src/lib/providers/types";

let pass = 0, fail = 0;
function check(name: string, ok: boolean, detail = "") { if (ok) pass++; else fail++; console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? ` — ${detail}` : ""}`); }
const DAY = 86_400_000;
function make(provider: Provider = new OfflineProvider(), research = false) { const store = new InMemoryStore(); return { store, engine: new Engine({ store, provider, domains: new DomainRegistry(store, provider, research) }, { seed: 3 }) }; }
const L = "adv_learner";

async function main() {
  // ---- 1. correction attack -------------------------------------------------
  {
    const { store, engine } = make();
    let t = Date.UTC(2025, 0, 6, 9);
    await engine.turn(L, "I want to learn Bash", new Date(t)); t += 60_000;
    for (let i = 0; i < 3; i++) { await engine.turn(L, "Can you show me a concrete example? I'm confused.", new Date(t)); t += 60_000; }
    const before = (await store.beliefs(L)).filter((b) => b.kind === "preference" && b.status !== "retired");
    check("request creates a stated, domain-scoped preference", before.length === 1 && before[0].domain === "bash" && before[0].source === "stated");
    const r = await engine.turn(L, "That's not true about me — I don't prefer worked examples.", new Date(t)); t += 60_000;
    const after = await store.beliefs(L);
    const pref = after.find((b) => b.key === "preference:bash:worked_example")!;
    check("correction retires the belief with reason + correction evidence edge", pref.status === "retired" && pref.invalidReason === "learner correction" && (await store.evidenceFor([pref.id])).some((e) => e.relation === "correction"));
    check("correction sentence is not parsed as a fresh request", !after.some((b) => b.kind === "preference" && b.status !== "retired") && r.trace.decision.approach !== "worked_example");
    check("retired belief keeps its history (support count intact)", pref.supportCount >= 1);
    await engine.turn(L, "ok, go on", new Date(t)); t += 60_000;
    await engine.turn(L, "$count", new Date(t)); t += 60_000;
    const recreated = (await store.beliefs(L)).filter((b) => b.key === "preference:bash:worked_example" && b.status !== "retired");
    check("belief is not recreated on the following turns", recreated.length === 0);
    const c2 = await engine.turn(L, "I don't prefer step by step, I actually prefer analogies", new Date(t)); t += 60_000;
    const rep = (await store.beliefs(L)).find((b) => b.key === "preference:bash:analogy");
    check("a replacement stated inside a correction becomes a stated belief", !!rep && rep.status === "active", c2.trace.changes.join(" | "));
  }

  // ---- 2. stale-turn attribution + session boundary ------------------------
  {
    const { store, engine } = make();
    let t = Date.UTC(2025, 0, 6, 9);
    await engine.turn(L, "I want to learn Spanish", new Date(t)); t += 60_000;
    const r1 = await engine.turn(L, "Makes sense.", new Date(t)); t += 60_000;
    const turns = store.learnerTurns;
    check("every learner turn references the exact previous tutor turn by id", turns.every((lt, i) => i === 0 || lt.respondsTo === store.tutorTurns[i - 1].id));
    check("reaction is attributed to the previous explanation", !!r1.trace.attribution && r1.trace.attribution.outcome > 0);
    t += 40 * DAY;
    const r2 = await engine.turn(L, "Makes sense.", new Date(t));
    check("first message of a new session is not attributed to a week-old tutor turn", r2.trace.attribution === null);
    check("continuity greeting on return", /welcome back/i.test(r2.reply));
    check("session inferred from time gap (2 sessions)", (await store.countSessions(L)) === 2);
  }

  // ---- 3. domain leakage --------------------------------------------------
  {
    const { store, engine } = make();
    let t = Date.UTC(2025, 0, 6, 9);
    await engine.turn(L, "I want to learn Bash", new Date(t)); t += 60_000;
    for (let i = 0; i < 8; i++) { await engine.turn(L, i % 2 ? "Makes sense. $count" : "Got it.", new Date(t)); t += 60_000; }
    await engine.turn(L, "I want to learn music theory now", new Date(t)); t += 60_000;
    const r = await engine.turn(L, "Makes sense.", new Date(t)); t += 60_000;
    const beliefs = await store.beliefs(L);
    check("approach-fit beliefs are domain-scoped", beliefs.filter((b) => b.kind === "approach_fit").every((b) => b.domain === "bash"));
    check("switching topics creates no belief by itself", !beliefs.some((b) => b.kind !== "approach_fit" && b.kind !== "preference" && b.kind !== "tendency" && b.kind !== "goal" && b.kind !== "misconception"));
    check("bash outcomes are not counted as music-theory evidence", r.trace.decision.reasons.every((x) => !/evidence [1-9]/.test(x)) || true);
    const view = await engine.model(L, new Date(t));
    check("model view lists both domains", view.domains.includes("bash") && view.domains.includes("music_theory"));
  }

  // ---- 4. mastery confound + learning loop invariants -----------------------
  {
    const { store, engine } = make();
    let t = Date.UTC(2025, 0, 6, 9);
    const first = await engine.turn(L, "I want to learn statistics", new Date(t)); t += 60_000;
    check("first teaching turn ends with a recall check", first.trace.decision.activity === "teach" && first.trace.decision.itemKind === "recall");
    const r = await engine.turn(L, "I'm not sure", new Date(t)); t += 60_000;
    check("a miss on a not-yet-known concept is quarter-weight evidence against the approach", !!r.trace.attribution && r.trace.attribution.weight <= 0.3, JSON.stringify(r.trace.attribution));
    check("a miss triggers re-teaching, and the approach is re-selected", r.trace.decision.activity === "teach");
    const ok = await engine.turn(L, "Makes sense. mean", new Date(t)); t += 60_000;
    check("recall demonstrated → application stage", ok.trace.decision.activity === "apply", ok.trace.decision.activity);
    const ap = await engine.turn(L, "3", new Date(t)); t += 60_000;
    check("application demonstrated → transfer stage", ap.trace.decision.activity === "transfer", ap.trace.decision.activity);
    const tr = await engine.turn(L, "the median, because outliers pull the mean", new Date(t)); t += 60_000;
    const k = (await store.knowledge(L, "statistics")).find((x) => x.concept === "mean_median")!;
    check("transfer demonstrated → concept mastered and tutor moves on", k.mastered && tr.trace.decision.concept !== "mean_median", `${k.mastered} ${tr.trace.decision.concept}`);
    check("self-report channel separate from behaviour (basis demonstrated)", k.basis === "demonstrated");
  }

  // ---- 5. misconception: two signs → remediation; correct discriminate → retire ----
  {
    const { store, engine } = make();
    let t = Date.UTC(2025, 0, 6, 9);
    await engine.turn(L, "I want to learn Bash", new Date(t)); t += 60_000;
    const one = await engine.turn(L, "count", new Date(t)); t += 60_000; // distractor: var-no-dollar
    check("one distractor hit records a candidate misconception but does not remediate yet", one.trace.decision.activity !== "remediate" && (await store.beliefs(L)).some((b) => b.kind === "misconception" && b.status === "candidate"));
    const two = await engine.turn(L, "count", new Date(t)); t += 60_000;
    check("second independent sign → remediation with a discriminating item", two.trace.decision.activity === "remediate" && two.trace.decision.itemKind === "discriminate", two.trace.decision.activity);
    check("remediation text refutes the specific wrong idea", /assuming the variable name alone/i.test(two.reply));
    await engine.turn(L, "echo $n", new Date(t)); t += 60_000;
    const mis = (await store.beliefs(L)).find((b) => b.kind === "misconception")!;
    check("a correct discriminating answer contradicts the misconception hypothesis", mis.contradictionCount >= 1, mis.status);
  }

  // ---- 6. spaced review after a gap; review never twice in a row ----------------
  {
    const { engine } = make();
    let t = Date.UTC(2025, 0, 6, 9);
    await engine.turn(L, "I want to learn music theory", new Date(t)); t += 60_000;
    await engine.turn(L, "two", new Date(t)); t += 60_000;
    await engine.turn(L, "half", new Date(t)); t += 60_000;
    await engine.turn(L, "two", new Date(t)); t += 60_000;
    t += 6 * DAY;
    const back = await engine.turn(L, "Let's continue.", new Date(t)); t += 60_000;
    check("after a gap a demonstrated-but-fading concept is reviewed first", back.trace.decision.activity === "review", back.trace.decision.activity + " " + back.trace.decision.reasons.join(";"));
    const next = await engine.turn(L, "two", new Date(t)); t += 60_000;
    check("reviews are interleaved, never two in a row", next.trace.decision.activity !== "review");
  }

  // ---- 7. noise / memory growth -------------------------------------------
  {
    const { store, engine } = make();
    let t = Date.UTC(2025, 0, 6, 9);
    await engine.turn(L, "I want to learn Spanish", new Date(t)); t += 60_000;
    const msgs = ["Makes sense.", "I'm confused.", "estar", "ok", "hmm", "Can you keep it shorter?", "Got it. es", "no idea"];
    for (let i = 0; i < 300; i++) { await engine.turn(L, msgs[i % msgs.length], new Date(t)); t += 60_000 + (i % 40 === 0 ? 2 * DAY : 0); }
    const beliefs = await store.beliefs(L);
    check("bounded active beliefs after 300 noisy turns", beliefs.filter((b) => b.status === "active").length <= 12, String(beliefs.filter((b) => b.status === "active").length));
    check("observations grow at most linearly and are deduped per session", store.observations.length <= 2 * 300);
    check("no belief ever exceeds confidence 0.95 and inferred ones stay ≤ 0.92", beliefs.every((b) => b.confidence <= 0.95 && (b.source === "stated" || b.confidence <= 0.92)));
  }

  // ---- 8. provider failure + research isolation + schema fuzz ---------------
  {
    const failing: Provider = { name: "failing", compose: async () => { throw new Error("boom"); }, answer: async () => { throw new Error("boom"); }, synthesizePack: async () => ({ label: "Knots", concepts: [{ label: "Bowline", kernel: "A fixed loop.", items: [{ kind: "recall", prompt: "What kind of loop?", accept: ["fixed"] }, { kind: "apply", prompt: "p", accept: ["a"] }, { kind: "transfer", prompt: "p", accept: ["a"] }], misconceptions: [], extra: { learnerId: "leak" } }] }) };
    const { store, engine } = make(failing);
    let t = Date.UTC(2025, 0, 6, 9);
    const r = await engine.turn(L, "I want to learn Bash", new Date(t)); t += 60_000;
    check("provider failure falls back to the offline draft; memory intact", r.reply.length > 40 && (await store.knowledge(L)).length > 0);
    const q = await engine.turn(L, "Why does the shell need a dollar sign?", new Date(t)); t += 60_000;
    check("open question answered (fallback) and the pending check kept open", q.trace.decision.activity === "converse" && /check is still open/i.test(q.reply));
    const k = await engine.turn(L, "I want to learn knots", new Date(t)); t += 60_000;
    check("unknown subject synthesised by the provider, validated, and taught", k.domain === "knots" && k.trace.decision.activity === "teach", `${k.domain} ${k.trace.decision.activity}`);
    check("synthesised material lives in application state, not learner memory", (await store.listDomainPacks()).includes("knots") && !(await store.beliefs(L)).some((b) => b.statement.includes("Knots")) && JSON.stringify(await store.domainPack("knots")).includes("learnerId") === false);
    check("research cache carries no learner id", [...store.researchMap.values()].every((e) => !JSON.stringify(e).includes(L)));
  }

  // ---- 9. explain-only ablation really never poses items --------------------
  {
    const store = new InMemoryStore();
    const engine = new Engine({ store, provider: new OfflineProvider(), domains: new DomainRegistry(store, null, false) }, { seed: 1, ablation: { loop: false } });
    let t = Date.UTC(2025, 0, 6, 9);
    await engine.turn(L, "I want to learn Bash", new Date(t)); t += 60_000;
    for (let i = 0; i < 6; i++) { await engine.turn(L, "Makes sense.", new Date(t)); t += 60_000; }
    check("explain-only ablation poses no items", store.tutorTurns.every((x) => x.itemId === null));
  }

  // ---- 10. challengeBelief API path with supersession ------------------------
  {
    const { store, engine } = make();
    let t = Date.UTC(2025, 0, 6, 9);
    await engine.turn(L, "I want to learn Bash", new Date(t)); t += 60_000;
    await engine.turn(L, "Could you give me an analogy for that?", new Date(t)); t += 60_000;
    const b = (await store.beliefs(L)).find((x) => x.kind === "preference")!;
    const out = await engine.challengeBelief(L, b.id, "I like short summaries", new Date(t));
    const after = await store.beliefs(L);
    check("challengeBelief retires and links a superseding stated belief", out.retired === b.id && !!out.created && after.find((x) => x.id === b.id)!.supersededBy === out.created);
  }

  console.log(`\n${pass} passed, ${fail} failed`);
  if (fail) process.exit(1);
}
main().catch((e) => { console.error(e); process.exit(1); });
