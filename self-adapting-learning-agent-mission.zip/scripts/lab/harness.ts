// Synthetic-learner laboratory. Learners have HIDDEN ground truth; the tutor only sees text
// (and the learner only sees the tutor's text + the posed question, exactly as in the UI).
//
// IMPORTANT: the hidden learning model ENCODES assumptions (retrieval strengthens memory,
// spacing/effort matter, feedback helps, refutation clears misconceptions, application builds
// transfer). The lab therefore tests whether the tutor EXPLOITS such regularities correctly and
// robustly — it does not prove those regularities hold for a given human.
import { Engine } from "../../src/lib/core/engine";
import { InMemoryStore } from "../../src/lib/core/store";
import { OfflineProvider } from "../../src/lib/providers";
import { DomainRegistry } from "../../src/lib/domain/registry";
import { mulberry32 } from "../../src/lib/core/bandit";
import { PACKS } from "../../src/lib/domain/packs";
import { APPROACHES, APPROACH_LABEL, type Ablation, type Approach } from "../../src/lib/core/types";
import type { DomainPack, Item } from "../../src/lib/domain/types";

export interface LearnerSpec {
  name: string;
  domains: string[];
  favourite: Record<string, Approach>;
  learnRate: number; // knowledge gained from a well-matched explanation
  baseStability: number; // days, initial memory half-life after first learning
  retrievalBenefit: number; // stability multiplier gain per successful retrieval (0 = testing does nothing)
  transferFactor: number; // 0..1 ceiling on applying knowledge to novel situations before practice
  misconceptionRate: number; // probability a concept starts with an active misconception
  noise: number; // probability a reaction is flipped
  articulate: number; // probability of voicing how an explanation landed
  overconfidence: number; // -1 underclaims .. 1 overclaims
  requestRate: number; // probability of asking for the favourite approach when confused
  switching: number; // per-turn probability of switching domain
  gapDays: number; // days between sessions
  drift: { atSession: number } | null;
  correctionAt: number | null; // session index at which the learner corrects the tutor's top preference belief
  initialKnowledge: number;
}

export interface Condition { name: string; ablation: Ablation }
export interface RunConfig { sessions: number; turnsPerSession: number; seed: number; retentionGapDays: number }

export interface LearnerReport {
  learner: string; condition: string; seed: number; turns: number; categories: string[];
  learningGain: number; finalKnowledge: number; retention: number; transfer: number;
  misconceptionsInitial: number; misconceptionsRemaining: number;
  bestRateEarly: number; bestRateLate: number; understoodRate: number;
  itemsPerTurn: number; reviewsPerTurn: number; teachShare: number;
  activeBeliefs: number; totalBeliefs: number; falseActiveBeliefs: number; leakedFitBeliefs: number;
  correctionRecreated: boolean | null; driftRecoveryTurns: number | null; calibrationScale: number | null;
  observations: number; msPerTurn: number;
}

interface HiddenConcept { k: number; kt: number; stab: number; lastAt: number; misconception: string | null }

const REQUEST_PHRASE: Record<Approach, string> = {
  worked_example: "Can you show me a concrete example?", analogy: "Could you give me an analogy for that?", step_by_step: "Can you walk me through it step by step?",
  socratic: "Ask me questions and let me figure it out.", concise_summary: "Can you keep it shorter? Just the summary.", direct_explanation: "Just explain it directly, please.",
};

export function affinityFor(rnd: () => number, favourite: Approach): Record<Approach, number> {
  const out = {} as Record<Approach, number>;
  for (const a of APPROACHES) out[a] = 0.25 + rnd() * 0.25;
  out[favourite] = 0.88;
  return out;
}
function bestOf(aff: Record<Approach, number>): Approach[] { const m = Math.max(...APPROACHES.map((a) => aff[a])); return APPROACHES.filter((a) => aff[a] >= m - 0.05); }
export function hash(s: string) { let h = 2166136261; for (const ch of s) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
const DAY = 86_400_000;
const packOf = (id: string) => PACKS.find((p) => p.id === id)!;
function itemOf(pack: DomainPack, id: string): Item | null { for (const c of pack.concepts) { const i = c.items.find((x) => x.id === id); if (i) return i; } return null; }

export async function runLearner(spec: LearnerSpec, cond: Condition, cfg: RunConfig): Promise<LearnerReport> {
  const rnd = mulberry32(cfg.seed * 7919 + hash(spec.name));
  const store = new InMemoryStore();
  const engine = new Engine({ store, provider: new OfflineProvider(), domains: new DomainRegistry(store, null, false) }, { ablation: cond.ablation, seed: cfg.seed * 31 + hash(spec.name) });
  const learnerId = `sim_${spec.name}`;
  const affinity: Record<string, Record<Approach, number>> = {};
  for (const d of spec.domains) affinity[d] = affinityFor(rnd, spec.favourite[d] ?? spec.favourite[spec.domains[0]]);

  // hidden state
  const hidden = new Map<string, HiddenConcept>();
  let misconceptionsInitial = 0;
  let now = Date.UTC(2025, 0, 6, 9, 0, 0);
  for (const d of spec.domains) for (const c of packOf(d).concepts) {
    const mis = c.misconceptions && c.misconceptions.length && rnd() < spec.misconceptionRate ? c.misconceptions[Math.floor(rnd() * c.misconceptions.length)].id : null;
    if (mis) misconceptionsInitial++;
    hidden.set(`${d}/${c.id}`, { k: spec.initialKnowledge, kt: 0.1, stab: spec.baseStability, lastAt: now, misconception: mis });
  }
  const initialK = mean([...hidden.values()].map((h) => h.k));
  const recall = (h: HiddenConcept, at: number) => h.k * Math.pow(0.5, Math.max(0, (at - h.lastAt) / DAY) / h.stab);

  let domain = spec.domains[0];
  const log: { turn: number; teach: boolean; best: boolean; understood: boolean; item: boolean; review: boolean }[] = [];
  let driftTurnIndex: number | null = null;
  let correctionKey: string | null = null;
  let correctionRecreated: boolean | null = null;
  const t0 = Date.now();
  let last: Awaited<ReturnType<Engine["turn"]>> | null = null;
  let lastDomain: string | null = null;

  for (let s = 0; s < cfg.sessions; s++) {
    if (spec.drift && s === spec.drift.atSession) {
      for (const d of spec.domains) { const old = bestOf(affinity[d])[0]; const others = APPROACHES.filter((x) => x !== old); affinity[d] = affinityFor(rnd, others[Math.floor(rnd() * others.length)]); }
      driftTurnIndex = log.length;
    }
    for (let t = 0; t < cfg.turnsPerSession; t++) {
      let msg: string;
      let understood = false;
      const dec = last?.trace.decision ?? null;
      const pack = packOf(domain);
      if (s === 0 && t === 0) {
        msg = `I want to learn ${pack.label}`;
        if (spec.overconfidence > 0.3) { const c = pack.concepts[Math.floor(rnd() * pack.concepts.length)]; msg += `. I already know ${c.label}`; }
        if (spec.overconfidence < -0.3) { const c = pack.concepts[Math.floor(rnd() * pack.concepts.length)]; msg += `. I don't know ${c.label} at all`; }
      } else if (t === 0) {
        msg = "Let's continue.";
      } else if (spec.correctionAt === s && t === 2 && !correctionKey) {
        const view = await engine.model(learnerId, new Date(now));
        const top = view.beliefs.filter((b) => (b.kind === "preference" || b.kind === "approach_fit") && b.status !== "retired" && b.status !== "candidate").sort((a, b) => b.influence - a.influence)[0];
        const approach = top ? APPROACHES.find((a) => top.statement.includes(APPROACH_LABEL[a])) ?? null : null;
        if (top && approach) { correctionKey = `${top.kind}:${approach}`; msg = `That's not true about me — I don't prefer ${APPROACH_LABEL[approach]}.`; }
        else msg = "Let's continue.";
      } else if (rnd() < spec.switching && spec.domains.length > 1 && !(dec?.itemId)) {
        const others = spec.domains.filter((d) => d !== domain); domain = others[Math.floor(rnd() * others.length)];
        msg = `I want to learn ${packOf(domain).label} now`;
      } else {
        // respond to the previous tutor turn
        const parts: string[] = [];
        const wasTeach = dec?.activity === "teach" || dec?.activity === "remediate";
        if (wasTeach && dec?.concept && lastDomain === domain) {
          const h = hidden.get(`${domain}/${dec.concept}`)!;
          const a = dec.approach!;
          const u = affinity[domain][a];
          // hidden learning from an explanation
          h.k = Math.min(1, h.k + spec.learnRate * u * (1 - h.k));
          if (h.k > 0.5) h.stab *= 1.1; // restudy adds little stability
          if (h.misconception && rnd() < (dec.activity === "remediate" ? 0.7 : 0.15 * u)) h.misconception = null;
          if (dec.activity === "remediate") { h.k = Math.min(1, h.k + 0.15 * (1 - h.k)); h.kt = Math.min(1, h.kt + 0.1); }
          let reaction: "understood" | "confused" | "neutral" = rnd() < u * 0.9 ? "understood" : rnd() < (1 - u) * 0.7 ? "confused" : "neutral";
          if (rnd() < spec.noise) reaction = reaction === "understood" ? "confused" : "understood";
          understood = reaction === "understood";
          if (rnd() < spec.articulate) {
            if (reaction === "understood") parts.push(["Makes sense.", "Got it.", "I see."][Math.floor(rnd() * 3)]);
            if (reaction === "confused") parts.push(["I'm confused.", "I don't get it.", "That's unclear to me."][Math.floor(rnd() * 3)]);
          }
          if (reaction === "confused" && rnd() < spec.requestRate) parts.push(REQUEST_PHRASE[bestOf(affinity[domain])[0]]);
        }
        if (dec?.itemId && dec.concept && lastDomain === domain && !parts.some((p) => p.startsWith("Can you") || p.startsWith("Ask me") || p.startsWith("Could you") || p.startsWith("Just explain"))) {
          const item = itemOf(pack, dec.itemId)!;
          const h = hidden.get(`${domain}/${dec.concept}`)!;
          const r = recall(h, now);
          const blocked = h.misconception && item.distractors?.find((d) => d.misconception === h.misconception);
          let answer: string;
          if (blocked && rnd() < 0.85) {
            answer = blocked.answers[0];
            h.kt = Math.min(1, h.kt + 0.05);
          } else {
            const pSuccess = item.kind === "recall" || item.kind === "discriminate" ? r : item.kind === "apply" ? r * (0.6 + 0.4 * h.kt) : r * (0.3 + 0.7 * h.kt);
            const ok = rnd() < pSuccess * 0.92 + (1 - pSuccess) * 0.05;
            if (ok) {
              answer = item.accept[0];
              h.stab *= 1 + spec.retrievalBenefit * (0.8 + 1.2 * (1 - r)); // successful, effortful retrieval strengthens memory
              h.k = Math.min(1, h.k + 0.05);
            } else {
              answer = item.distractors && rnd() < 0.3 ? item.distractors[Math.floor(rnd() * item.distractors.length)].answers[0] : ["I'm not sure", "no idea", "hmm, maybe something else"][Math.floor(rnd() * 3)];
              h.k = Math.min(1, h.k + 0.2 * (1 - h.k)); // corrective feedback teaches
              h.stab = Math.max(0.5, h.stab * 0.85);
              if (h.misconception && rnd() < 0.25) h.misconception = null;
            }
            if (item.kind === "apply" || item.kind === "transfer") h.kt = Math.min(1, h.kt + 0.25 * (1 - h.kt)); else h.kt = Math.min(1, h.kt + 0.05);
            h.lastAt = now;
          }
          parts.push(answer);
        }
        if (!parts.length) parts.push(dec?.activity === "orient" ? `I want to learn ${pack.label}` : "ok, go on");
        msg = parts.join(" ");
      }

      last = await engine.turn(learnerId, msg, new Date(now));
      lastDomain = last.domain;
      const d = last.trace.decision;
      const teach = d.activity === "teach" && !!d.approach && lastDomain === domain;
      log.push({ turn: log.length, teach, best: teach ? bestOf(affinity[domain]).includes(d.approach!) : false, understood, item: !!d.itemId, review: d.activity === "review" });
      if (correctionKey && !correctionRecreated) {
        const [kind, approach] = correctionKey.split(":");
        const view = await store.beliefs(learnerId);
        if (view.some((b) => b.kind === kind && b.status !== "retired" && b.key.endsWith(`:${approach}`) && b.source === "inferred" && b.polarity === 1)) correctionRecreated = true;
      }
      now += 2 * 60_000;
    }
    now += spec.gapDays * DAY;
  }
  if (correctionKey && correctionRecreated === null) correctionRecreated = false;

  // ---- hidden final assessment after a retention gap ----
  const at = now + cfg.retentionGapDays * DAY;
  const hs = [...hidden.values()];
  const retention = mean(hs.map((h) => recall(h, at)));
  const transfer = mean(hs.map((h) => recall(h, at) * (0.3 + 0.7 * h.kt)));
  const finalKnowledge = mean(hs.map((h) => h.k));
  const misconceptionsRemaining = hs.filter((h) => h.misconception).length;

  // ---- teaching-adaptation metrics ----
  const teachTurns = log.filter((l) => l.teach);
  const half = Math.floor(teachTurns.length / 2);
  const early = teachTurns.slice(0, half), late = teachTurns.slice(half);
  let driftRecoveryTurns: number | null = null;
  if (driftTurnIndex != null) {
    const after = log.slice(driftTurnIndex).filter((l) => l.teach);
    for (let i = 0; i + 6 <= after.length; i++) if (after.slice(i, i + 6).filter((l) => l.best).length >= 4) { driftRecoveryTurns = i; break; }
  }
  const beliefs = await store.beliefs(learnerId);
  const activeB = beliefs.filter((b) => b.status === "active" || b.status === "contested");
  const falseActive = activeB.filter((b) => (b.kind === "preference" || b.kind === "approach_fit") && b.polarity === 1 && (() => { const a = APPROACHES.find((x) => b.key.endsWith(`:${x}`)); const dom = b.domain ?? spec.domains[0]; return !!a && !!affinity[dom] && affinity[dom][a] < 0.6; })()).length;
  const leaked = beliefs.filter((b) => b.kind === "approach_fit" && b.domain && !spec.domains.includes(b.domain)).length;
  const calib = await store.calibration(learnerId, spec.domains[0]);
  return {
    learner: spec.name, condition: cond.name, seed: cfg.seed, turns: log.length, categories: [...new Set(spec.domains.map((d) => packOf(d).category))],
    learningGain: finalKnowledge - initialK, finalKnowledge, retention, transfer, misconceptionsInitial, misconceptionsRemaining,
    bestRateEarly: rate(early), bestRateLate: rate(late), understoodRate: teachTurns.length ? teachTurns.filter((l) => l.understood).length / teachTurns.length : 0,
    itemsPerTurn: log.filter((l) => l.item).length / log.length, reviewsPerTurn: log.filter((l) => l.review).length / log.length, teachShare: teachTurns.length / log.length,
    activeBeliefs: activeB.length, totalBeliefs: beliefs.length, falseActiveBeliefs: falseActive, leakedFitBeliefs: leaked,
    correctionRecreated, driftRecoveryTurns, calibrationScale: calib?.stabilityScale ?? null,
    observations: store.observations.length, msPerTurn: (Date.now() - t0) / Math.max(1, log.length),
  };
}

function rate(l: { best: boolean }[]) { return l.length ? l.filter((x) => x.best).length / l.length : 0; }
export function mean(xs: number[]) { return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0; }

const base: Omit<LearnerSpec, "name" | "domains" | "favourite"> = { learnRate: 0.35, baseStability: 2, retrievalBenefit: 0.6, transferFactor: 0.7, misconceptionRate: 0.35, noise: 0.05, articulate: 0.8, overconfidence: 0, requestRate: 0.3, switching: 0, gapDays: 3, drift: null, correctionAt: null, initialKnowledge: 0.1 };

export const ARCHETYPES: LearnerSpec[] = [
  { ...base, name: "example_lover", domains: ["bash"], favourite: { bash: "worked_example" } },
  { ...base, name: "theory_direct", domains: ["statistics"], favourite: { statistics: "direct_explanation" } },
  { ...base, name: "socratic_fan", domains: ["music_theory"], favourite: { music_theory: "socratic" } },
  { ...base, name: "analogy_language", domains: ["spanish"], favourite: { spanish: "analogy" } },
  { ...base, name: "context_dependent", domains: ["bash", "statistics"], favourite: { bash: "worked_example", statistics: "step_by_step" }, switching: 0.12 },
  { ...base, name: "drifter", domains: ["spanish"], favourite: { spanish: "step_by_step" }, drift: { atSession: 2 } },
  { ...base, name: "overconfident", domains: ["statistics"], favourite: { statistics: "worked_example" }, overconfidence: 0.8, initialKnowledge: 0.15 },
  { ...base, name: "underconfident", domains: ["bash"], favourite: { bash: "step_by_step" }, overconfidence: -0.8, initialKnowledge: 0.35 },
  { ...base, name: "noisy", domains: ["music_theory"], favourite: { music_theory: "worked_example" }, noise: 0.35 },
  { ...base, name: "silent", domains: ["spanish"], favourite: { spanish: "concise_summary" }, articulate: 0.1, requestRate: 0 },
  { ...base, name: "switcher", domains: ["bash", "spanish", "music_theory"], favourite: { bash: "worked_example", spanish: "worked_example", music_theory: "worked_example" }, switching: 0.2 },
  { ...base, name: "long_gap", domains: ["statistics"], favourite: { statistics: "analogy" }, gapDays: 21 },
  { ...base, name: "corrector", domains: ["bash"], favourite: { bash: "analogy" }, correctionAt: 4 },
  { ...base, name: "fast_forgetter", domains: ["spanish"], favourite: { spanish: "worked_example" }, baseStability: 0.7 },
  { ...base, name: "slow_forgetter", domains: ["music_theory"], favourite: { music_theory: "step_by_step" }, baseStability: 8 },
  { ...base, name: "retrieval_insensitive", domains: ["statistics"], favourite: { statistics: "worked_example" }, retrievalBenefit: 0.05 },
  { ...base, name: "misconception_prone", domains: ["bash"], favourite: { bash: "direct_explanation" }, misconceptionRate: 0.9 },
  { ...base, name: "low_transfer", domains: ["statistics"], favourite: { statistics: "step_by_step" }, transferFactor: 0.3 },
];

export const CONDITIONS: Condition[] = [
  { name: "full", ablation: {} },
  { name: "no_loop", ablation: { loop: false } },
  { name: "no_spacing", ablation: { spacing: false } },
  { name: "no_remediation", ablation: { remediation: false } },
  { name: "no_transfer", ablation: { transfer: false } },
  { name: "no_bandit", ablation: { bandit: false } },
  { name: "no_long_term", ablation: { longTerm: false } },
  { name: "no_correction", ablation: { correction: false } },
  { name: "with_calibration", ablation: { calibration: true } },
];
