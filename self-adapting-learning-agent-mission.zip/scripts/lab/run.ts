// Benchmark + ablations. Deterministic given --seeds. Writes lab/out/summary.json.
//   npx tsx scripts/lab/run.ts --seeds=3 --sessions=8 --turns=10 [--conditions=full,no_loop] [--learners=a,b]
import { mkdirSync, writeFileSync } from "node:fs";
import { ARCHETYPES, CONDITIONS, mean, runLearner, type LearnerReport } from "./harness";

const arg = (k: string, d: string) => (process.argv.find((a) => a.startsWith(`--${k}=`))?.split("=")[1] ?? d);
const seeds = parseInt(arg("seeds", "2"));
const sessions = parseInt(arg("sessions", "6"));
const turns = parseInt(arg("turns", "8"));
const gap = parseInt(arg("gap", "7"));
const condFilter = arg("conditions", "").split(",").filter(Boolean);
const learnerFilter = arg("learners", "").split(",").filter(Boolean);

async function main() {
  const conditions = condFilter.length ? CONDITIONS.filter((c) => condFilter.includes(c.name)) : CONDITIONS;
  const learners = learnerFilter.length ? ARCHETYPES.filter((l) => learnerFilter.includes(l.name)) : ARCHETYPES;
  const reports: LearnerReport[] = [];
  const t0 = Date.now();
  for (let seed = 1; seed <= seeds; seed++) for (const c of conditions) for (const l of learners) reports.push(await runLearner(l, c, { sessions, turnsPerSession: turns, seed, retentionGapDays: gap }));
  const elapsed = Date.now() - t0;

  const cols = ["condition", "gain", "retain", "transfer", "misc.left", "best.early", "best.late", "understood", "items/turn", "reviews/turn", "false.act", "leaked", "corr.recreated", "drift.rec"];
  const rows = conditions.map((c) => {
    const rs = reports.filter((r) => r.condition === c.name);
    const corr = rs.filter((r) => r.correctionRecreated != null);
    const drift = rs.filter((r) => r.driftRecoveryTurns != null || r.learner === "drifter");
    return [c.name, f(mean(rs.map((r) => r.learningGain))), f(mean(rs.map((r) => r.retention))), f(mean(rs.map((r) => r.transfer))), `${f(mean(rs.map((r) => r.misconceptionsRemaining / Math.max(1, r.misconceptionsInitial))))}`, f(mean(rs.map((r) => r.bestRateEarly))), f(mean(rs.map((r) => r.bestRateLate))), f(mean(rs.map((r) => r.understoodRate))), f(mean(rs.map((r) => r.itemsPerTurn))), f(mean(rs.map((r) => r.reviewsPerTurn))), f(mean(rs.map((r) => r.falseActiveBeliefs))), f(mean(rs.map((r) => r.leakedFitBeliefs))), corr.length ? `${corr.filter((r) => r.correctionRecreated).length}/${corr.length}` : "–", drift.length ? `${f(mean(drift.filter((r) => r.driftRecoveryTurns != null).map((r) => r.driftRecoveryTurns!)), 0)} (${drift.filter((r) => r.driftRecoveryTurns == null).length} unrec.)` : "–"];
  });
  console.log(`\n${reports.length} runs, ${reports.reduce((s, r) => s + r.turns, 0)} turns in ${(elapsed / 1000).toFixed(1)}s\n`);
  console.log(table([cols, ...rows]));

  // generality: full condition by domain category
  const full = reports.filter((r) => r.condition === "full");
  const cats = [...new Set(full.flatMap((r) => r.categories))];
  console.log("\nGenerality (full condition, by domain category):");
  console.log(table([["category", "n", "gain", "retain", "transfer", "misc.left", "best.late"], ...cats.map((cat) => { const rs = full.filter((r) => r.categories.includes(cat)); return [cat, String(rs.length), f(mean(rs.map((r) => r.learningGain))), f(mean(rs.map((r) => r.retention))), f(mean(rs.map((r) => r.transfer))), f(mean(rs.map((r) => r.misconceptionsRemaining / Math.max(1, r.misconceptionsInitial)))), f(mean(rs.map((r) => r.bestRateLate)))]; })]));

  console.log("\nPer learner (full vs no_loop): gain / retention / transfer / best.late");
  for (const l of learners) {
    const a = reports.filter((r) => r.learner === l.name && r.condition === "full"), b = reports.filter((r) => r.learner === l.name && r.condition === "no_loop");
    if (a.length) console.log(`  ${l.name.padEnd(22)} full ${f(mean(a.map((r) => r.learningGain)))} / ${f(mean(a.map((r) => r.retention)))} / ${f(mean(a.map((r) => r.transfer)))} / ${f(mean(a.map((r) => r.bestRateLate)))}${b.length ? `   no_loop ${f(mean(b.map((r) => r.learningGain)))} / ${f(mean(b.map((r) => r.retention)))} / ${f(mean(b.map((r) => r.transfer)))} / ${f(mean(b.map((r) => r.bestRateLate)))}` : ""}   calib ${a[0].calibrationScale?.toFixed(2) ?? "-"}`);
  }
  mkdirSync("lab/out", { recursive: true });
  writeFileSync("lab/out/summary.json", JSON.stringify({ config: { seeds, sessions, turns, retentionGapDays: gap }, generatedAt: new Date().toISOString(), conditions: conditions.map((c) => c.name), learners: learners.map((l) => l.name), table: rows, reports }, null, 1));
  console.log("\nwritten lab/out/summary.json");
}

function f(x: number, d = 2) { return Number.isFinite(x) ? x.toFixed(d) : "–"; }
function table(rows: string[][]) { const w = rows[0].map((_, i) => Math.max(...rows.map((r) => r[i].length))); return rows.map((r, i) => r.map((c, j) => c.padEnd(w[j])).join("  ") + (i === 0 ? "\n" + w.map((x) => "-".repeat(x)).join("  ") : "")).join("\n"); }
main().catch((e) => { console.error(e); process.exit(1); });
