import { boolean, doublePrecision, integer, jsonb, pgTable, primaryKey, text, timestamp } from "drizzle-orm/pg-core";

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull(),
  lastActivityAt: timestamp("last_activity_at", { withTimezone: true }).notNull(),
  domain: text("domain"),
});

export const observations = pgTable("observations", {
  id: text("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  sessionId: text("session_id").notNull(),
  at: timestamp("at", { withTimezone: true }).notNull(),
  kind: text("kind").notNull(),
  content: text("content").notNull(),
  domain: text("domain"),
  concept: text("concept"),
  dedupeKey: text("dedupe_key").notNull(),
});

export const beliefs = pgTable("beliefs", {
  id: text("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  kind: text("kind").notNull(),
  key: text("key").notNull(),
  statement: text("statement").notNull(),
  domain: text("domain"),
  concept: text("concept"),
  source: text("source").notNull(),
  polarity: integer("polarity").notNull(),
  status: text("status").notNull(),
  confidence: doublePrecision("confidence").notNull(),
  supportCount: integer("support_count").notNull(),
  contradictionCount: integer("contradiction_count").notNull(),
  sessionIds: jsonb("session_ids").$type<string[]>().notNull(),
  validFrom: timestamp("valid_from", { withTimezone: true }).notNull(),
  invalidAt: timestamp("invalid_at", { withTimezone: true }),
  invalidReason: text("invalid_reason"),
  supersededBy: text("superseded_by"),
  lastConfirmedAt: timestamp("last_confirmed_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull(),
});

export const beliefEvidence = pgTable("belief_evidence", {
  beliefId: text("belief_id").notNull(),
  observationId: text("observation_id").notNull(),
  relation: text("relation").notNull(),
  at: timestamp("at", { withTimezone: true }).notNull(),
}, (t) => [primaryKey({ columns: [t.beliefId, t.observationId, t.relation] })]);

export const knowledgeStates = pgTable("knowledge_states", {
  learnerId: text("learner_id").notNull(),
  domain: text("domain").notNull(),
  concept: text("concept").notNull(),
  pKnown: doublePrecision("p_known").notNull(),
  basis: text("basis").notNull(),
  attempts: integer("attempts").notNull(),
  successes: integer("successes").notNull(),
  stability: doublePrecision("stability").notNull(),
  lastEvidenceAt: timestamp("last_evidence_at", { withTimezone: true }).notNull(),
  lastTaughtAt: timestamp("last_taught_at", { withTimezone: true }),
  applySuccesses: integer("apply_successes").notNull(),
  applyAttempts: integer("apply_attempts").notNull(),
  transferSuccesses: integer("transfer_successes").notNull(),
  transferAttempts: integer("transfer_attempts").notNull(),
  claimedLevel: doublePrecision("claimed_level"),
  claimedAt: timestamp("claimed_at", { withTimezone: true }),
  mastered: boolean("mastered").notNull(),
  masteredAt: timestamp("mastered_at", { withTimezone: true }),
}, (t) => [primaryKey({ columns: [t.learnerId, t.domain, t.concept] })]);

export const calibrations = pgTable("calibrations", {
  learnerId: text("learner_id").notNull(),
  domain: text("domain").notNull(),
  stabilityScale: doublePrecision("stability_scale").notNull(),
  reviewsObserved: integer("reviews_observed").notNull(),
  reviewsPassed: integer("reviews_passed").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull(),
}, (t) => [primaryKey({ columns: [t.learnerId, t.domain] })]);

export const tutorTurns = pgTable("tutor_turns", {
  id: text("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  sessionId: text("session_id").notNull(),
  at: timestamp("at", { withTimezone: true }).notNull(),
  domain: text("domain"),
  concept: text("concept"),
  activity: text("activity").notNull(),
  approach: text("approach"),
  itemId: text("item_id"),
  itemKind: text("item_kind"),
  text: text("text").notNull(),
  reasons: jsonb("reasons").$type<string[]>().notNull(),
});

export const learnerTurns = pgTable("learner_turns", {
  id: text("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  sessionId: text("session_id").notNull(),
  at: timestamp("at", { withTimezone: true }).notNull(),
  text: text("text").notNull(),
  respondsTo: text("responds_to"),
  attribution: jsonb("attribution"),
  grade: jsonb("grade"),
});

export const outcomes = pgTable("outcomes", {
  id: text("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  domain: text("domain").notNull(),
  approach: text("approach").notNull(),
  value: doublePrecision("value").notNull(),
  weight: doublePrecision("weight").notNull(),
  at: timestamp("at", { withTimezone: true }).notNull(),
  tutorTurnId: text("tutor_turn_id").notNull(),
});

/** Subject research. Application knowledge — deliberately has no learner_id column. */
export const researchCache = pgTable("research_cache", {
  key: text("key").primaryKey(),
  payload: jsonb("payload").notNull(),
  source: text("source").notNull(),
  fetchedAt: timestamp("fetched_at", { withTimezone: true }).notNull(),
});

export const domainPacks = pgTable("domain_packs", {
  id: text("id").primaryKey(),
  pack: jsonb("pack").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
