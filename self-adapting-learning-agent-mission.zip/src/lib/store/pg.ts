// Drizzle/Postgres implementation of the Store boundary.
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import * as t from "@/db/schema";
import type { Store } from "../core/store";
import type { Belief, BeliefEvidence, Calibration, KnowledgeState, LearnerTurn, Observation, OutcomeRecord, ResearchEntry, Session, TutorTurn } from "../core/types";

const asBelief = (r: typeof t.beliefs.$inferSelect): Belief => ({ ...r, kind: r.kind as Belief["kind"], source: r.source as Belief["source"], status: r.status as Belief["status"], polarity: r.polarity as 1 | -1 });
const asTutor = (r: typeof t.tutorTurns.$inferSelect): TutorTurn => ({ ...r, activity: r.activity as TutorTurn["activity"], approach: r.approach as TutorTurn["approach"], itemKind: r.itemKind as TutorTurn["itemKind"] });
const asKnowledge = (r: typeof t.knowledgeStates.$inferSelect): KnowledgeState => ({ ...r, basis: r.basis as KnowledgeState["basis"] });

export class PgStore implements Store {
  async latestSession(learnerId: string) { const r = await db.select().from(t.sessions).where(eq(t.sessions.learnerId, learnerId)).orderBy(desc(t.sessions.startedAt)).limit(1); return r[0] ?? null; }
  async countSessions(learnerId: string) { const r = await db.select({ n: sql<number>`count(*)::int` }).from(t.sessions).where(eq(t.sessions.learnerId, learnerId)); return r[0]?.n ?? 0; }
  async saveSession(s: Session) { await db.insert(t.sessions).values(s).onConflictDoUpdate({ target: t.sessions.id, set: { lastActivityAt: s.lastActivityAt, domain: s.domain } }); }

  async addObservation(o: Observation) {
    const dup = await db.select({ id: t.observations.id }).from(t.observations).where(and(eq(t.observations.learnerId, o.learnerId), eq(t.observations.sessionId, o.sessionId), eq(t.observations.dedupeKey, o.dedupeKey))).limit(1);
    if (dup.length) return false;
    await db.insert(t.observations).values(o); return true;
  }
  async recentObservations(learnerId: string, limit: number) { return (await db.select().from(t.observations).where(eq(t.observations.learnerId, learnerId)).orderBy(desc(t.observations.at)).limit(limit)) as Observation[]; }
  async observationsByIds(ids: string[]) { if (!ids.length) return []; return (await db.select().from(t.observations).where(inArray(t.observations.id, ids))) as Observation[]; }
  async sessionObservations(learnerId: string, sessionId: string) { return (await db.select().from(t.observations).where(and(eq(t.observations.learnerId, learnerId), eq(t.observations.sessionId, sessionId))).orderBy(asc(t.observations.at))) as Observation[]; }

  async beliefs(learnerId: string) { return (await db.select().from(t.beliefs).where(eq(t.beliefs.learnerId, learnerId))).map(asBelief); }
  async saveBelief(b: Belief) { const { id, ...rest } = b; await db.insert(t.beliefs).values({ id, ...rest }).onConflictDoUpdate({ target: t.beliefs.id, set: rest }); }
  async addEvidence(e: BeliefEvidence) { await db.insert(t.beliefEvidence).values(e).onConflictDoNothing(); }
  async evidenceFor(ids: string[]) { if (!ids.length) return []; return (await db.select().from(t.beliefEvidence).where(inArray(t.beliefEvidence.beliefId, ids))) as BeliefEvidence[]; }

  async knowledge(learnerId: string, domain?: string) { return (await db.select().from(t.knowledgeStates).where(domain ? and(eq(t.knowledgeStates.learnerId, learnerId), eq(t.knowledgeStates.domain, domain)) : eq(t.knowledgeStates.learnerId, learnerId))).map(asKnowledge); }
  async saveKnowledge(k: KnowledgeState) { const { learnerId, domain, concept, ...rest } = k; await db.insert(t.knowledgeStates).values(k).onConflictDoUpdate({ target: [t.knowledgeStates.learnerId, t.knowledgeStates.domain, t.knowledgeStates.concept], set: rest }); void learnerId; void domain; void concept; }
  async calibration(learnerId: string, domain: string) { const r = await db.select().from(t.calibrations).where(and(eq(t.calibrations.learnerId, learnerId), eq(t.calibrations.domain, domain))).limit(1); return r[0] ?? null; }
  async saveCalibration(c: Calibration) { const { learnerId, domain, ...rest } = c; await db.insert(t.calibrations).values(c).onConflictDoUpdate({ target: [t.calibrations.learnerId, t.calibrations.domain], set: rest }); void learnerId; void domain; }

  async lastTutorTurn(learnerId: string) { const r = await db.select().from(t.tutorTurns).where(eq(t.tutorTurns.learnerId, learnerId)).orderBy(desc(t.tutorTurns.at)).limit(1); return r[0] ? asTutor(r[0]) : null; }
  async saveTutorTurn(x: TutorTurn) { await db.insert(t.tutorTurns).values(x); }
  async saveLearnerTurn(x: LearnerTurn) { await db.insert(t.learnerTurns).values(x); }
  async recentTutorTurns(learnerId: string, sessionId: string) { return (await db.select().from(t.tutorTurns).where(and(eq(t.tutorTurns.learnerId, learnerId), eq(t.tutorTurns.sessionId, sessionId))).orderBy(asc(t.tutorTurns.at))).map(asTutor); }
  async recentLearnerTurns(learnerId: string, sessionId: string) { return (await db.select().from(t.learnerTurns).where(and(eq(t.learnerTurns.learnerId, learnerId), eq(t.learnerTurns.sessionId, sessionId))).orderBy(asc(t.learnerTurns.at))) as LearnerTurn[]; }

  async outcomes(learnerId: string) { return (await db.select().from(t.outcomes).where(eq(t.outcomes.learnerId, learnerId))).map(({ id: _id, ...o }) => o as OutcomeRecord); }
  async addOutcome(o: OutcomeRecord) { await db.insert(t.outcomes).values({ id: `${o.tutorTurnId}:${o.at.getTime()}`, ...o }).onConflictDoNothing(); }

  async research(key: string) { const r = await db.select().from(t.researchCache).where(eq(t.researchCache.key, key)).limit(1); return (r[0] as ResearchEntry | undefined) ?? null; }
  async saveResearch(e: ResearchEntry) { await db.insert(t.researchCache).values({ key: e.key, payload: e.payload as object, source: e.source, fetchedAt: e.fetchedAt }).onConflictDoUpdate({ target: t.researchCache.key, set: { payload: e.payload as object, fetchedAt: e.fetchedAt } }); }
  async domainPack(id: string) { const r = await db.select().from(t.domainPacks).where(eq(t.domainPacks.id, id)).limit(1); return r[0]?.pack ?? null; }
  async saveDomainPack(id: string, pack: unknown) { await db.insert(t.domainPacks).values({ id, pack: pack as object }).onConflictDoUpdate({ target: t.domainPacks.id, set: { pack: pack as object } }); }
  async listDomainPacks() { return (await db.select({ id: t.domainPacks.id }).from(t.domainPacks)).map((r) => r.id); }
}
