// Domain-agnostic core types. Nothing here knows about any subject.
// Two decision layers are deliberately separate:
//   - Activity  = WHAT the tutor does this turn (the learning loop; deterministic controller)
//   - Approach  = HOW an explanation is delivered (learned per learner/domain by a bandit)

export const APPROACHES = ["direct_explanation", "worked_example", "analogy", "step_by_step", "socratic", "concise_summary"] as const;
export type Approach = (typeof APPROACHES)[number];

export const APPROACH_LABEL: Record<Approach, string> = {
  direct_explanation: "a direct explanation",
  worked_example: "a worked example",
  analogy: "an analogy",
  step_by_step: "a step-by-step walkthrough",
  socratic: "guiding questions",
  concise_summary: "a concise summary",
};

/** Learning-loop stages. `teach` is the only activity whose outcome credits an Approach. */
export const ACTIVITIES = ["orient", "teach", "check", "apply", "transfer", "review", "remediate", "converse"] as const;
export type Activity = (typeof ACTIVITIES)[number];

export type ItemKind = "recall" | "apply" | "transfer" | "discriminate";

export interface Session {
  id: string;
  learnerId: string;
  startedAt: Date;
  lastActivityAt: Date;
  domain: string | null;
}

export type ObservationKind =
  | "goal" | "question" | "self_report" | "answer" | "reaction" | "request" | "correction"
  | "topic_switch" | "statement" | "context";

/** Short-term, append-only, never edited. */
export interface Observation {
  id: string;
  learnerId: string;
  sessionId: string;
  at: Date;
  kind: ObservationKind;
  content: string;
  domain: string | null;
  concept: string | null;
  dedupeKey: string;
}

export type BeliefKind = "preference" | "approach_fit" | "tendency" | "goal" | "misconception" | "context";
export type BeliefSource = "stated" | "inferred";
export type BeliefStatus = "candidate" | "active" | "contested" | "dormant" | "retired";

/** Long-term, revisable, bi-temporal, with provenance. Memory is a prior, never a verdict. */
export interface Belief {
  id: string;
  learnerId: string;
  kind: BeliefKind;
  key: string; // stable identity, e.g. preference:worked_example
  statement: string;
  domain: string | null; // null = general
  concept: string | null;
  source: BeliefSource;
  polarity: 1 | -1;
  status: BeliefStatus;
  confidence: number;
  supportCount: number;
  contradictionCount: number;
  sessionIds: string[];
  validFrom: Date;
  invalidAt: Date | null;
  invalidReason: string | null;
  supersededBy: string | null;
  lastConfirmedAt: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface BeliefEvidence {
  beliefId: string;
  observationId: string;
  relation: "supports" | "contradicts" | "correction";
  at: Date;
}

export type KnowledgeBasis = "prior" | "claimed" | "demonstrated";

/** Per learner × domain × concept. Behaviour channel (BKT + stability) is kept apart from the self-report channel. */
export interface KnowledgeState {
  learnerId: string;
  domain: string;
  concept: string;
  pKnown: number;
  basis: KnowledgeBasis;
  attempts: number;
  successes: number;
  /** memory stability in days; grows with successful, effortful retrieval */
  stability: number;
  lastEvidenceAt: Date;
  lastTaughtAt: Date | null;
  applySuccesses: number;
  applyAttempts: number;
  transferSuccesses: number;
  transferAttempts: number;
  claimedLevel: number | null;
  claimedAt: Date | null;
  mastered: boolean;
  masteredAt: Date | null;
}

/** Learning adaptation: how fast THIS learner forgets in THIS domain relative to the default curve. */
export interface Calibration {
  learnerId: string;
  domain: string;
  stabilityScale: number; // 1 = default; <1 forgets faster than modelled
  reviewsObserved: number;
  reviewsPassed: number;
  updatedAt: Date;
}

export interface TutorTurn {
  id: string;
  learnerId: string;
  sessionId: string;
  at: Date;
  domain: string | null;
  concept: string | null;
  activity: Activity;
  approach: Approach | null;
  itemId: string | null;
  itemKind: ItemKind | null;
  text: string;
  reasons: string[];
}

export interface Attribution {
  outcome: number; // -1..1 about the previous tutor turn's teaching approach
  weight: number;
  reasons: string[];
}

export interface Grade {
  itemId: string;
  itemKind: ItemKind;
  concept: string;
  correct: boolean;
  matchedMisconception: string | null;
  priorPKnown: number;
}

export interface LearnerTurn {
  id: string;
  learnerId: string;
  sessionId: string;
  at: Date;
  text: string;
  respondsTo: string | null; // tutor turn id
  attribution: Attribution | null;
  grade: Grade | null;
}

export interface OutcomeRecord {
  learnerId: string;
  domain: string;
  approach: Approach;
  value: number;
  weight: number;
  at: Date;
  tutorTurnId: string;
}

export interface ResearchEntry {
  key: string;
  payload: unknown;
  source: string;
  fetchedAt: Date;
}

export interface Ablation {
  loop?: boolean; // false → explain-only tutor
  spacing?: boolean;
  remediation?: boolean;
  transfer?: boolean;
  bandit?: boolean;
  longTerm?: boolean;
  correction?: boolean;
  calibration?: boolean;
}

export interface BeliefView {
  id: string;
  kind: BeliefKind;
  statement: string;
  domain: string | null;
  concept: string | null;
  source: BeliefSource;
  status: BeliefStatus;
  confidence: number;
  influence: number;
  supportCount: number;
  contradictionCount: number;
  lastConfirmedAt: string;
  invalidReason: string | null;
  evidence: { observationId: string; relation: string; content: string; at: string }[];
}

export interface KnowledgeView {
  domain: string;
  concept: string;
  label: string;
  pKnown: number;
  retained: number;
  basis: KnowledgeBasis;
  stage: "untaught" | "learning" | "applying" | "transferring" | "mastered";
  attempts: number;
  successes: number;
  stabilityDays: number;
  nextReviewInDays: number | null;
  claimedLevel: number | null;
  mastered: boolean;
}

export interface Trace {
  observed: string[];
  inferred: string[];
  attribution: Attribution | null;
  grade: Grade | null;
  decision: { activity: Activity; approach: Approach | null; concept: string | null; itemId: string | null; itemKind: ItemKind | null; itemPrompt: string | null; reasons: string[] };
  changes: string[];
}

export interface TurnResult {
  reply: string;
  tutorTurnId: string;
  sessionId: string;
  domain: string | null;
  trace: Trace;
}

export interface LearnerModelView {
  learnerId: string;
  domains: string[];
  beliefs: BeliefView[];
  knowledge: KnowledgeView[];
  calibrations: Calibration[];
  approachStats: { domain: string; approach: Approach; mean: number; weight: number }[];
  recentObservations: { kind: ObservationKind; content: string; at: string; domain: string | null }[];
  sessions: number;
}
