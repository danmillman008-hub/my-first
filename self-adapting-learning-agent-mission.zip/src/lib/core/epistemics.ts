// Pure epistemic rules. No I/O. Deterministic. Unit-testable.
import type { Attribution, Belief, BeliefSource, BeliefStatus, Calibration, Grade, KnowledgeState } from "./types";

export const DAY = 86_400_000;
export const clamp = (x: number, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, x));

// ---------------------------------------------------------------------------
// Beliefs: candidate → active → contested → retired; dormancy computed on read.
// ---------------------------------------------------------------------------

export function recencyFactor(lastConfirmedAt: Date, now: Date, halfLifeDays = 60): number {
  const days = Math.max(0, (now.getTime() - lastConfirmedAt.getTime()) / DAY);
  return Math.pow(0.5, days / halfLifeDays);
}

export function confidenceFor(source: BeliefSource, support: number, contradiction: number): number {
  if (source === "stated") return clamp(0.85 + 0.05 * support - 0.3 * contradiction, 0.15, 0.95);
  return Math.min(0.92, (support + 1) / (support + contradiction + 2)); // capped Beta mean: never a verdict
}

export function statusFor(source: BeliefSource, support: number, contradiction: number, distinctSessions: number, prev: BeliefStatus): BeliefStatus {
  if (prev === "retired") return "retired";
  if (contradiction > 0 && contradiction >= Math.max(2, support)) return "retired";
  if (contradiction > 0 && contradiction / Math.max(1, support) >= 0.34) return "contested";
  if (source === "stated") return "active";
  if (support >= 2 && (distinctSessions >= 2 || support >= 3)) return "active";
  return prev === "active" || prev === "contested" ? "active" : "candidate";
}

export const STATUS_WEIGHT: Record<BeliefStatus, number> = { active: 1, contested: 0.5, candidate: 0.3, dormant: 0.15, retired: 0 };

export function effectiveStatus(b: Belief, now: Date): BeliefStatus {
  if (b.status === "active" && b.source === "inferred" && recencyFactor(b.lastConfirmedAt, now) < 0.25) return "dormant";
  return b.status;
}

/** influence = confidence × status × recency × scope. Approach-fit beliefs have zero influence outside their domain. */
export function influenceOf(b: Belief, now: Date, domain: string | null): number {
  const scope = !b.domain ? 0.85 : b.domain === domain ? 1 : b.kind === "approach_fit" || b.kind === "misconception" ? 0 : 0.1;
  return b.confidence * STATUS_WEIGHT[effectiveStatus(b, now)] * (0.4 + 0.6 * recencyFactor(b.lastConfirmedAt, now)) * scope;
}

export function applySupport(b: Belief, sessionId: string, now: Date): Partial<Belief> {
  const sessionIds = b.sessionIds.includes(sessionId) ? b.sessionIds : [...b.sessionIds, sessionId];
  const supportCount = b.supportCount + 1;
  const status = statusFor(b.source, supportCount, b.contradictionCount, sessionIds.length, b.status);
  return { supportCount, sessionIds, status, confidence: confidenceFor(b.source, supportCount, b.contradictionCount), lastConfirmedAt: now, updatedAt: now };
}

export function applyContradiction(b: Belief, now: Date, reason: string): Partial<Belief> {
  const contradictionCount = b.contradictionCount + 1;
  const status = statusFor(b.source, b.supportCount, contradictionCount, b.sessionIds.length, b.status);
  return { contradictionCount, status, confidence: confidenceFor(b.source, b.supportCount, contradictionCount), updatedAt: now, ...(status === "retired" ? { invalidAt: now, invalidReason: reason } : {}) };
}

export function retirePatch(b: Belief, now: Date, reason: string, supersededBy: string | null): Partial<Belief> {
  return { status: "retired", invalidAt: now, invalidReason: reason, supersededBy, contradictionCount: b.contradictionCount + 1, confidence: Math.min(b.confidence, 0.1), updatedAt: now };
}

// ---------------------------------------------------------------------------
// Knowledge: BKT for p(known) + a stability-based forgetting curve.
// Retention is estimated on read; stability grows with successful retrieval,
// more when retrieval was effortful (desirable difficulty), and shrinks on failure.
// ---------------------------------------------------------------------------

export const BKT = { learn: 0.2, slip: 0.1, guess: 0.2 };
export const INITIAL_STABILITY_DAYS = 1.5;

export function bktUpdate(pKnown: number, correct: boolean, opts: Partial<typeof BKT> = {}): number {
  const { learn, slip, guess } = { ...BKT, ...opts };
  const num = correct ? pKnown * (1 - slip) : pKnown * slip;
  const den = correct ? pKnown * (1 - slip) + (1 - pKnown) * guess : pKnown * slip + (1 - pKnown) * (1 - guess);
  const post = num / den;
  return clamp(post + (1 - post) * learn, 0.01, 0.99);
}

export function newKnowledge(learnerId: string, domain: string, concept: string, now: Date): KnowledgeState {
  return { learnerId, domain, concept, pKnown: 0.15, basis: "prior", attempts: 0, successes: 0, stability: INITIAL_STABILITY_DAYS, lastEvidenceAt: now, lastTaughtAt: null, applySuccesses: 0, applyAttempts: 0, transferSuccesses: 0, transferAttempts: 0, claimedLevel: null, claimedAt: null, mastered: false, masteredAt: null };
}

/** Predicted probability the learner can still retrieve the concept now. */
export function retained(k: KnowledgeState, now: Date, stabilityScale = 1): number {
  if (k.basis !== "demonstrated") return k.pKnown;
  const days = Math.max(0, (now.getTime() - k.lastEvidenceAt.getTime()) / DAY);
  return k.pKnown * Math.pow(0.5, days / (k.stability * stabilityScale));
}

export function daysUntilReview(k: KnowledgeState, now: Date, stabilityScale: number, threshold: number): number | null {
  if (k.basis !== "demonstrated" || k.pKnown <= threshold) return null;
  const s = k.stability * stabilityScale;
  const days = s * Math.log2(k.pKnown / threshold);
  const elapsed = (now.getTime() - k.lastEvidenceAt.getTime()) / DAY;
  return Math.max(0, days - elapsed);
}

/** A claim sets a prior when nothing has been demonstrated; it never overrides behaviour. */
export function applyClaim(k: KnowledgeState, level: number, now: Date): Partial<KnowledgeState> {
  const patch: Partial<KnowledgeState> = { claimedLevel: level, claimedAt: now };
  if (k.attempts === 0) {
    patch.pKnown = level >= 1 ? 0.6 : level > 0 ? 0.4 : 0.15;
    patch.basis = "claimed";
  }
  return patch;
}

export function applyTaught(k: KnowledgeState, now: Date): Partial<KnowledgeState> {
  // Teaching alone is weak evidence of knowing; it nudges the prior, it does not demonstrate.
  return { lastTaughtAt: now, pKnown: k.basis === "demonstrated" ? k.pKnown : clamp(k.pKnown + 0.1, 0, 0.5) };
}

/**
 * A graded item. Recall items update p(known) and stability; apply/transfer items also
 * update their own counters and count for less on p(known) (they measure use, not recall).
 */
export function applyGrade(k: KnowledgeState, g: Grade, now: Date, stabilityScale = 1): Partial<KnowledgeState> {
  const before = retained(k, now, stabilityScale);
  const effort = k.basis === "demonstrated" ? 1 - before : 0; // harder retrieval → larger stability gain
  const isRecall = g.itemKind === "recall" || g.itemKind === "discriminate";
  const pKnown = bktUpdate(k.basis === "demonstrated" ? before : k.pKnown, g.correct, isRecall ? {} : { learn: 0.12 });
  let stability = k.stability;
  if (g.correct) stability = k.stability * (1.6 + 1.4 * effort);
  else stability = Math.max(INITIAL_STABILITY_DAYS, k.stability * 0.6);
  const patch: Partial<KnowledgeState> = { pKnown, basis: "demonstrated", attempts: k.attempts + 1, successes: k.successes + (g.correct ? 1 : 0), stability: Math.min(365, stability), lastEvidenceAt: now };
  if (g.itemKind === "apply") { patch.applyAttempts = k.applyAttempts + 1; patch.applySuccesses = k.applySuccesses + (g.correct ? 1 : 0); }
  if (g.itemKind === "transfer") { patch.transferAttempts = k.transferAttempts + 1; patch.transferSuccesses = k.transferSuccesses + (g.correct ? 1 : 0); }
  return patch;
}

export function discrepancy(k: KnowledgeState): "overclaims" | "underclaims" | "aligned" | null {
  if (k.claimedLevel == null || k.attempts < 3 || k.basis !== "demonstrated") return null;
  const gap = k.claimedLevel - k.pKnown;
  if (gap >= 0.45) return "overclaims";
  if (gap <= -0.45) return "underclaims";
  return "aligned";
}

// ---------------------------------------------------------------------------
// Calibration (learning adaptation): compare predicted recall at review time with
// the observed outcome and move the learner's stability scale by the surprise.
// ---------------------------------------------------------------------------

export function newCalibration(learnerId: string, domain: string, now: Date): Calibration {
  return { learnerId, domain, stabilityScale: 1, reviewsObserved: 0, reviewsPassed: 0, updatedAt: now };
}

export function applyReviewOutcome(c: Calibration, predicted: number, correct: boolean, now: Date): Partial<Calibration> {
  const surprise = (correct ? 1 : 0) - predicted; // >0: remembered better than modelled
  const scale = clamp(c.stabilityScale * Math.exp(0.35 * surprise), 0.3, 3);
  return { stabilityScale: scale, reviewsObserved: c.reviewsObserved + 1, reviewsPassed: c.reviewsPassed + (correct ? 1 : 0), updatedAt: now };
}

// ---------------------------------------------------------------------------
// Attribution: which learner response says what about the PREVIOUS tutor turn's approach.
// Reactions speak about teaching. Task results speak mostly about mastery and are
// down-weighted, more so when the concept was unknown (failure) or known (success).
// ---------------------------------------------------------------------------

export interface AttributionInput {
  previousActivity: string | null;
  reaction: "understood" | "confused" | "neutral" | "disagree";
  taskResult: "correct" | "incorrect" | null;
  requestedDifferentApproach: boolean;
  isCorrection: boolean;
  topicSwitch: boolean;
  priorPKnown: number | null;
  sameSession: boolean;
}

export function attribute(i: AttributionInput): Attribution | null {
  if (!i.sameSession || i.isCorrection || i.topicSwitch) return null;
  if (i.previousActivity !== "teach" && i.previousActivity !== "remediate") return null; // only explanations credit an approach
  const parts: { v: number; w: number; why: string }[] = [];
  const knownBefore = i.priorPKnown != null && i.priorPKnown >= 0.75;
  const unknownBefore = i.priorPKnown != null && i.priorPKnown < 0.35;
  if (i.reaction === "understood") parts.push({ v: 1, w: knownBefore ? 0.5 : 1, why: knownBefore ? "signalled understanding (already knew it: half weight)" : "signalled understanding" });
  if (i.reaction === "confused") parts.push({ v: -1, w: 1, why: "signalled confusion" });
  if (i.reaction === "disagree") parts.push({ v: -0.4, w: 0.5, why: "pushed back" });
  if (i.requestedDifferentApproach) parts.push({ v: -0.6, w: 0.7, why: "asked for a different approach" });
  if (i.taskResult === "correct") parts.push({ v: 0.7, w: knownBefore ? 0.15 : 0.5, why: knownBefore ? "correct, but already known (minimal weight)" : "answered the check correctly (half weight)" });
  if (i.taskResult === "incorrect") parts.push({ v: -0.7, w: unknownBefore ? 0.25 : 0.5, why: unknownBefore ? "missed the check on a concept not yet known (quarter weight)" : "missed the check (half weight)" });
  if (!parts.length) return null;
  const wsum = parts.reduce((s, p) => s + p.w, 0);
  const outcome = clamp(parts.reduce((s, p) => s + p.v * p.w, 0) / wsum, -1, 1);
  return { outcome, weight: Math.min(1, wsum), reasons: parts.map((p) => p.why) };
}
