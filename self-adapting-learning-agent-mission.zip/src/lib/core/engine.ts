// The tutor loop. Deterministic invariants live here; a provider only writes prose.
import { APPROACHES, APPROACH_LABEL, type Ablation, type Activity, type Approach, type Belief, type BeliefKind, type BeliefView, type Grade, type ItemKind, type KnowledgeState, type KnowledgeView, type LearnerModelView, type Observation, type Session, type Trace, type TurnResult, type TutorTurn } from "./types";
import type { Store } from "./store";
import { perceive, approachMentioned, type Perception } from "./perceive";
import { applyClaim, applyContradiction, applyGrade, applyReviewOutcome, applySupport, applyTaught, attribute, daysUntilReview, discrepancy, influenceOf, newCalibration, newKnowledge, retained, retirePatch, effectiveStatus } from "./epistemics";
import { armStats, mulberry32, selectApproach } from "./bandit";
import { conceptOrder, grade as gradeItem, type Concept, type DomainPack, type Item } from "../domain/types";
import type { DomainRegistry } from "../domain/registry";
import type { Provider } from "../providers/types";

export interface EngineDeps { store: Store; provider: Provider; domains: DomainRegistry }
export interface EngineOptions { ablation?: Ablation; seed?: number; reviewThreshold?: number; sessionGapMinutes?: number }

const SESSION_GAP_MS = 45 * 60_000;
let idCounter = 0;
export function nextId(prefix: string, rnd: () => number): string { idCounter++; return `${prefix}_${Date.now().toString(36)}_${Math.floor(rnd() * 1e9).toString(36)}_${idCounter.toString(36)}`; }

// calibration is opt-in: it was neutral in simulation (see EVALUATION.md) and a neutral mechanism should not be on by default.
const DEFAULT_ABLATION: Required<Ablation> = { loop: true, spacing: true, remediation: true, transfer: true, bandit: true, longTerm: true, correction: true, calibration: process.env.LEARNER_CALIBRATION === "1" };

export class Engine {
  private ab: Required<Ablation>;
  private rnd: () => number;
  private reviewThreshold: number;
  private gapMs: number;
  constructor(private deps: EngineDeps, opts: EngineOptions = {}) {
    this.ab = { ...DEFAULT_ABLATION, ...(opts.ablation ?? {}) };
    this.rnd = mulberry32(opts.seed ?? 42);
    this.reviewThreshold = opts.reviewThreshold ?? 0.7;
    this.gapMs = (opts.sessionGapMinutes ?? 45) * 60_000 || SESSION_GAP_MS;
  }

  // -------------------------------------------------------------------------
  async turn(learnerId: string, message: string, now: Date = new Date()): Promise<TurnResult> {
    const { store } = this.deps;
    const trace: Trace = { observed: [], inferred: [], attribution: null, grade: null, decision: { activity: "orient", approach: null, concept: null, itemId: null, itemKind: null, itemPrompt: null, reasons: [] }, changes: [] };
    const text = message.slice(0, 4000);

    // ---- session ----
    let session = await store.latestSession(learnerId);
    const newSession = !session || now.getTime() - session.lastActivityAt.getTime() > this.gapMs;
    const previousDomain = session?.domain ?? null;
    const previousSessionsCount = await store.countSessions(learnerId);
    if (newSession) { session = { id: nextId("s", this.rnd), learnerId, startedAt: now, lastActivityAt: now, domain: previousDomain }; }
    session = session!;
    const lastTutor = await store.lastTutorTurn(learnerId);
    const pendingItem = !newSession && lastTutor?.itemId ? lastTutor : null;
    const p = perceive(text, !!pendingItem);

    // ---- domain resolution ----
    let pack: DomainPack | null = session.domain ? await this.deps.domains.byId(session.domain) : null;
    let topicSwitch = false;
    const goalOrMention = p.goalText ?? (!p.looksLikeAnswer ? text : null);
    if (goalOrMention && (p.goalText || !pack)) {
      const found = await this.deps.domains.resolve(goalOrMention, !!p.goalText);
      if (found && found.id !== pack?.id) { topicSwitch = !!pack; pack = found; }
    } else if (!p.looksLikeAnswer && pack) {
      const mention = await this.deps.domains.mentioned(text);
      if (mention && mention.id !== pack.id) { topicSwitch = true; pack = mention; }
    }
    session.domain = pack?.id ?? session.domain;
    session.lastActivityAt = now;
    await store.saveSession(session);
    const domain = pack?.id ?? null;

    // ---- observations (append-only, deduped per session) ----
    const obs = async (kind: Observation["kind"], content: string, concept: string | null = null) => {
      const o: Observation = { id: nextId("o", this.rnd), learnerId, sessionId: session!.id, at: now, kind, content: content.slice(0, 500), domain, concept, dedupeKey: `${kind}:${content.toLowerCase().replace(/\s+/g, " ").trim().slice(0, 120)}` };
      const added = await store.addObservation(o);
      if (added) trace.observed.push(`${kind}: ${content.slice(0, 80)}`);
      return o;
    };
    if (p.goalText) await obs("goal", p.goalText);
    if (topicSwitch) await obs("topic_switch", `${previousDomain ?? "none"} → ${domain}`);
    if (p.isCorrection) await obs("correction", text);
    if (p.requestedApproach && !p.isCorrection) await obs("request", `asked for ${APPROACH_LABEL[p.requestedApproach]}`);
    if (p.reaction !== "neutral") await obs("reaction", p.reaction);
    for (const sr of p.selfReports) await obs("self_report", `${sr.level ? "knows" : "does not know"}: ${sr.text}`);
    if (p.isQuestion && !p.looksLikeAnswer && !p.goalText) await obs("question", text);

    // ---- knowledge & calibration for this domain ----
    const knowledge = domain ? await store.knowledge(learnerId, domain) : [];
    const kOf = (concept: string): KnowledgeState => knowledge.find((k) => k.concept === concept) ?? (() => { const k = newKnowledge(learnerId, domain!, concept, now); knowledge.push(k); return k; })();
    const saveK = async (k: KnowledgeState, patch: Partial<KnowledgeState>) => { Object.assign(k, patch); await store.saveKnowledge(k); };
    let calib = domain ? (await store.calibration(learnerId, domain)) ?? newCalibration(learnerId, domain, now) : null;
    const scale = this.ab.calibration && calib ? calib.stabilityScale : 1;

    let beliefs = this.ab.longTerm ? await store.beliefs(learnerId) : [];
    const live = (b: Belief) => b.status !== "retired";

    // ---- grade the pending item, if the message answers it ----
    let gradeRes: Grade | null = null;
    let answeredObs: Observation | null = null;
    if (pendingItem && pack && pendingItem.domain === pack.id && p.looksLikeAnswer) {
      const item = findItem(pack, pendingItem.itemId!);
      const concept = pendingItem.concept ? conceptById(pack, pendingItem.concept) : null;
      if (item && concept) {
        const k = kOf(concept.id);
        const prior = retained(k, now, scale);
        const g = gradeItem(item, text);
        gradeRes = { itemId: item.id, itemKind: item.kind, concept: concept.id, correct: g.correct, matchedMisconception: g.matchedMisconception, priorPKnown: prior };
        answeredObs = await obs("answer", `${g.correct ? "correct" : "incorrect"} on ${item.kind} item ${item.id}${g.matchedMisconception ? ` (matches misconception ${g.matchedMisconception})` : ""}`, concept.id);
        if (pendingItem.activity === "review" && calib && this.ab.calibration) {
          const patch = applyReviewOutcome(calib, prior, g.correct, now);
          calib = { ...calib, ...patch }; await store.saveCalibration(calib);
          trace.inferred.push(`review of ${concept.label}: predicted recall ${prior.toFixed(2)}, ${g.correct ? "remembered" : "forgotten"} → forgetting scale ${calib.stabilityScale.toFixed(2)}`);
        }
        await saveK(k, applyGrade(k, gradeRes, now, scale));
        trace.inferred.push(`${concept.label}: p(known) ${prior.toFixed(2)} → ${k.pKnown.toFixed(2)} after ${g.correct ? "correct" : "incorrect"} ${item.kind}`);
        trace.grade = gradeRes;
        // misconception hypotheses live as beliefs: revisable, domain+concept scoped, with provenance
        if (this.ab.remediation && this.ab.longTerm) {
          if (g.matchedMisconception) {
            const m = concept.misconceptions?.find((x) => x.id === g.matchedMisconception);
            if (m) { const b = await this.upsert(beliefs, { learnerId, kind: "misconception", key: `misconception:${pack.id}:${m.id}`, statement: `may be assuming ${m.statement}`, domain: pack.id, concept: concept.id, source: "inferred", polarity: 1 }, answeredObs.id, session.id, now, trace, true); beliefs = b; }
          } else if (g.correct) {
            for (const b of beliefs.filter((b) => live(b) && b.kind === "misconception" && b.concept === concept.id)) {
              if (item.kind === "discriminate" || item.kind === "transfer" || b.supportCount <= 1) { await this.contradict(b, answeredObs.id, now, `answered ${item.kind} item correctly`, trace); }
            }
          }
        }
      }
    }

    // ---- attribution to the PREVIOUS tutor turn (by id) ----
    if (lastTutor && lastTutor.approach && lastTutor.domain) {
      const priorK = lastTutor.concept && pack && lastTutor.domain === pack.id ? kOf(lastTutor.concept) : null;
      const a = attribute({ previousActivity: lastTutor.activity, reaction: p.reaction, taskResult: gradeRes ? (gradeRes.correct ? "correct" : "incorrect") : null, requestedDifferentApproach: !!p.requestedApproach && p.requestedApproach !== lastTutor.approach, isCorrection: p.isCorrection, topicSwitch, priorPKnown: gradeRes ? gradeRes.priorPKnown : priorK ? retained(priorK, now, scale) : null, sameSession: !newSession });
      if (a) {
        trace.attribution = a;
        if (this.ab.bandit) await store.addOutcome({ learnerId, domain: lastTutor.domain, approach: lastTutor.approach, value: a.outcome, weight: a.weight, at: now, tutorTurnId: lastTutor.id });
        trace.inferred.push(`${APPROACH_LABEL[lastTutor.approach]} → outcome ${a.outcome.toFixed(2)} (w ${a.weight.toFixed(2)}): ${a.reasons.join("; ")}`);
      }
    }

    // ---- correction: present testimony defeats old inference ----
    let correctionReply: string | null = null;
    if (p.isCorrection && this.ab.correction && this.ab.longTerm) {
      // "I don't prefer X, I actually prefer Y": the target is named before the replacement clause.
      const replacement = /\b(i (actually )?(prefer|like|learn best with|want))\s+([^.!?]{2,60})/i.exec(text);
      const target = approachMentioned(replacement ? text.slice(0, replacement.index) : text);
      const candidates = beliefs.filter(live).filter((b) => (b.kind === "preference" || b.kind === "approach_fit" || b.kind === "tendency") && (target ? b.key.endsWith(`:${target}`) : true));
      const chosen = target ? candidates : candidates.sort((a, b) => influenceOf(b, now, domain) - influenceOf(a, now, domain)).slice(0, 1);
      const corrObs = (await store.sessionObservations(learnerId, session.id)).find((o) => o.kind === "correction" && o.content === text.slice(0, 500));
      for (const b of chosen) {
        await store.saveBelief(Object.assign(b, retirePatch(b, now, "learner correction", null)));
        if (corrObs) await store.addEvidence({ beliefId: b.id, observationId: corrObs.id, relation: "correction", at: now });
        trace.changes.push(`retired belief "${b.statement}" (learner correction)`);
      }
      correctionReply = chosen.length ? `Understood — I've dropped ${chosen.length === 1 ? `the assumption that you ${chosen[0].statement}` : `${chosen.length} assumptions about how you learn`}. I'll only rebuild it from what happens after now.` : "Understood — I don't hold a belief like that right now, and I've noted your correction so I won't form one lightly.";
      // A replacement stated inside the correction becomes a stated belief, linked as superseding.
      const repApproach = replacement ? approachMentioned(replacement[4]) : null;
      if (repApproach && repApproach !== target) {
        beliefs = await this.upsert(beliefs, { learnerId, kind: "preference", key: `preference:${domain ?? "general"}:${repApproach}`, statement: `prefer ${APPROACH_LABEL[repApproach]}${domain ? ` in ${pack!.label}` : ""}`, domain, concept: null, source: "stated", polarity: 1 }, corrObs?.id ?? null, session.id, now, trace, false);
        const nb = beliefs.find((b) => b.key === `preference:${domain ?? "general"}:${repApproach}`);
        for (const b of chosen) if (nb) await store.saveBelief(Object.assign(b, { supersededBy: nb.id }));
      }
    }

    // ---- requests → stated, domain-scoped preference beliefs ----
    if (p.requestedApproach && !p.isCorrection && domain && this.ab.longTerm) {
      const reqObs = (await store.sessionObservations(learnerId, session.id)).find((o) => o.kind === "request" && o.content.includes(APPROACH_LABEL[p.requestedApproach!]));
      beliefs = await this.upsert(beliefs, { learnerId, kind: "preference", key: `preference:${domain}:${p.requestedApproach}`, statement: `prefer ${APPROACH_LABEL[p.requestedApproach]} in ${pack!.label}`, domain, concept: null, source: "stated", polarity: 1 }, reqObs?.id ?? null, session.id, now, trace, false);
    }

    // ---- self-reports → claims on concepts (a prior, never evidence) ----
    if (pack) for (const sr of p.selfReports) {
      const c = matchConcept(pack, sr.text);
      if (c) { const k = kOf(c.id); await saveK(k, applyClaim(k, sr.level, now)); trace.inferred.push(`claim: ${sr.level ? "knows" : "does not know"} ${c.label} → ${k.basis === "claimed" ? `prior ${k.pKnown.toFixed(2)}` : "recorded (behaviour already observed)"}`); }
    }
    // durable claim/behaviour gaps become observed tendencies (revisable)
    if (pack && this.ab.longTerm) {
      const over = knowledge.filter((k) => discrepancy(k) === "overclaims").length, under = knowledge.filter((k) => discrepancy(k) === "underclaims").length, aligned = knowledge.filter((k) => discrepancy(k) === "aligned").length;
      const evidenceObs = answeredObs?.id ?? null;
      if (evidenceObs && over >= 2 && over > under) beliefs = await this.upsert(beliefs, { learnerId, kind: "tendency", key: `tendency:${domain}:overclaims`, statement: `tend to rate their knowledge of ${pack.label} higher than checks show`, domain, concept: null, source: "inferred", polarity: 1 }, evidenceObs, session.id, now, trace, true);
      if (evidenceObs && under >= 2 && under > over) beliefs = await this.upsert(beliefs, { learnerId, kind: "tendency", key: `tendency:${domain}:underclaims`, statement: `tend to know more ${pack.label} than they claim`, domain, concept: null, source: "inferred", polarity: 1 }, evidenceObs, session.id, now, trace, true);
      if (evidenceObs && aligned >= 2) for (const b of beliefs.filter((b) => live(b) && b.kind === "tendency" && b.domain === domain)) await this.contradict(b, evidenceObs, now, "claims and checks agree again", trace);
    }
    // approach-fit beliefs derived from attributed outcomes in this domain (inferred, domain-scoped)
    if (domain && this.ab.longTerm && this.ab.bandit && trace.attribution && lastTutor?.approach) {
      const stats = armStats(await store.outcomes(learnerId), domain, now)[lastTutor.approach];
      if (stats.weight >= 3) {
        const mean = stats.sum / stats.weight;
        const obsId = answeredObs?.id ?? (await store.sessionObservations(learnerId, session.id)).slice(-1)[0]?.id ?? null;
        if (mean >= 0.35) beliefs = await this.upsert(beliefs, { learnerId, kind: "approach_fit", key: `approach_fit:${domain}:${lastTutor.approach}`, statement: `learn ${pack!.label} well from ${APPROACH_LABEL[lastTutor.approach]}`, domain, concept: null, source: "inferred", polarity: 1 }, obsId, session.id, now, trace, true);
        else if (mean <= -0.35) beliefs = await this.upsert(beliefs, { learnerId, kind: "approach_fit", key: `approach_fit:${domain}:${lastTutor.approach}`, statement: `do not learn ${pack!.label} well from ${APPROACH_LABEL[lastTutor.approach]}`, domain, concept: null, source: "inferred", polarity: -1 }, obsId, session.id, now, trace, true);
        else for (const b of beliefs.filter((b) => live(b) && b.key === `approach_fit:${domain}:${lastTutor!.approach}`)) if (obsId && Math.abs(mean) < 0.15) await this.contradict(b, obsId, now, "recent outcomes no longer support it", trace);
      }
    }

    // ---- prepare approach selection once (bandit), then decide the activity ----
    this.lastSelection = null; this.pendingApproachReasons = [];
    if (domain && this.ab.bandit) this.lastSelection = await this.prepareApproach(learnerId, domain, beliefs, lastTutor, !newSession, now, this.pendingApproachReasons);
    const decision = await this.decide({ learnerId, pack, knowledge, session, newSession, p, pendingItem, gradeRes, lastTutor, beliefs, scale, now, trace });
    trace.decision = { activity: decision.activity, approach: decision.approach, concept: decision.concept?.id ?? null, itemId: decision.item?.id ?? null, itemKind: decision.item?.kind ?? null, itemPrompt: decision.item?.prompt ?? null, reasons: decision.reasons };
    if (decision.activity === "teach" && decision.concept) { const k = kOf(decision.concept.id); await saveK(k, applyTaught(k, now)); }
    if (decision.markMastered && pack) { const k = kOf(decision.markMastered); await saveK(k, { mastered: true, masteredAt: now }); trace.changes.push(`${conceptById(pack, decision.markMastered)?.label ?? decision.markMastered}: mastered (recall, application and transfer demonstrated)`); }

    // ---- compose ----
    const reply = await this.compose({ decision, pack, gradeRes, pendingItem, newSession, previousSessionsCount, previousDomain, correctionReply, p, text, knowledge, scale, now });

    const tutorTurn: TutorTurn = { id: nextId("t", this.rnd), learnerId, sessionId: session.id, at: now, domain, concept: decision.concept?.id ?? null, activity: decision.activity, approach: decision.approach, itemId: decision.item?.id ?? null, itemKind: decision.item?.kind ?? null, text: reply, reasons: decision.reasons };
    await store.saveTutorTurn(tutorTurn);
    await store.saveLearnerTurn({ id: nextId("l", this.rnd), learnerId, sessionId: session.id, at: now, text, respondsTo: lastTutor?.id ?? null, attribution: trace.attribution, grade: gradeRes });
    return { reply, tutorTurnId: tutorTurn.id, sessionId: session.id, domain, trace };
  }

  // -------------------------------------------------------------------------
  private async decide(x: { learnerId: string; pack: DomainPack | null; knowledge: KnowledgeState[]; session: Session; newSession: boolean; p: Perception; pendingItem: TutorTurn | null; gradeRes: Grade | null; lastTutor: TutorTurn | null; beliefs: Belief[]; scale: number; now: Date; trace: Trace }): Promise<Decision> {
    const { pack, knowledge, p, gradeRes, lastTutor, now, scale } = x;
    const reasons: string[] = [];
    if (!pack) { reasons.push("no learning goal yet"); return { activity: "orient", approach: null, concept: null, item: null, reasons, markMastered: null, misconception: null }; }
    const kOf = (id: string) => knowledge.find((k) => k.concept === id) ?? newKnowledge(x.learnerId, pack.id, id, now);
    const order = conceptOrder(pack);
    const sessionTurns = await this.deps.store.recentTutorTurns(x.learnerId, x.session.id);
    const sameDomainLast = lastTutor && lastTutor.domain === pack.id && !x.newSession ? lastTutor : null;

    // Open question → converse (keep any pending item alive so the answer can still be graded)
    if (p.isQuestion && !p.looksLikeAnswer && !p.goalText && !p.isCorrection && !p.wantsReview && !p.requestedApproach) {
      const c = matchConcept(pack, p.normalized) ?? (sameDomainLast?.concept ? conceptById(pack, sameDomainLast.concept) : null);
      reasons.push("learner asked a question; answering before continuing");
      return { activity: "converse", approach: null, concept: c, item: x.pendingItem && x.pendingItem.itemId ? findItem(pack, x.pendingItem.itemId) : null, reasons, markMastered: null, misconception: null };
    }

    // Explain-only ablation: the classic chat tutor. Never poses items.
    if (!this.ab.loop) {
      const c = (sameDomainLast?.concept ? conceptById(pack, sameDomainLast.concept) : null) ?? nextConcept(order, kOf, null, sessionTurns) ?? order[0];
      const approach = this.pickApproach(x, c, reasons);
      reasons.push("explain-only mode");
      return { activity: "teach", approach, concept: c, item: null, reasons, markMastered: null, misconception: null };
    }

    // 1) Spaced review, interleaved: never two reviews in a row, never right after a fresh teach of the focus concept.
    const lastActivity = sameDomainLast?.activity ?? null;
    if (this.ab.spacing && lastActivity !== "review" && !(lastActivity === "teach" && !gradeRes)) {
      const due = knowledge
        .filter((k) => k.basis === "demonstrated" && k.successes > 0 && k.lastEvidenceAt.getTime() < x.session.startedAt.getTime() && retained(k, now, scale) < this.reviewThreshold)
        .sort((a, b) => retained(a, now, scale) - retained(b, now, scale));
      const reviewsThisSession = sessionTurns.filter((t) => t.activity === "review").length;
      if (due.length && (p.wantsReview || reviewsThisSession < Math.max(2, Math.ceil(due.length / 2)) || x.newSession)) {
        const c = conceptById(pack, due[0].concept)!;
        const item = pickItem(c, "recall", due[0].attempts);
        if (item) { reasons.push(`${c.label} is due for review (predicted recall ${retained(due[0], now, scale).toFixed(2)} < ${this.reviewThreshold}, last seen ${daysAgo(due[0].lastEvidenceAt, now)}d ago)`); return { activity: "review", approach: null, concept: c, item, reasons, markMastered: null, misconception: null }; }
      }
    }

    // 2) Focus concept: continue the current one unless it is mastered or parked.
    let focus = sameDomainLast?.concept ? conceptById(pack, sameDomainLast.concept) : null;
    if (sameDomainLast?.activity === "review") focus = previousFocus(sessionTurns, pack) ?? focus;
    let markMastered: string | null = null;
    if (focus) {
      const k = kOf(focus.id);
      const done = k.transferSuccesses >= 1 || (!this.ab.transfer && k.applySuccesses >= 1);
      if (done && !k.mastered) markMastered = focus.id;
      if (done || k.mastered || parked(sessionTurns, focus.id)) focus = null;
    }
    if (!focus) {
      focus = nextConcept(order, kOf, markMastered, sessionTurns);
      if (!focus) {
        // everything mastered: keep the strongest evidence fresh with the weakest concept
        const weakest = [...knowledge].sort((a, b) => retained(a, now, scale) - retained(b, now, scale))[0];
        const c = weakest ? conceptById(pack, weakest.concept) : order[0];
        const item = c ? pickItem(c, "transfer", weakest?.transferAttempts ?? 0) ?? pickItem(c, "apply", weakest?.applyAttempts ?? 0) : null;
        reasons.push(`all ${pack.label} concepts mastered; stretching the weakest (${c?.label})`);
        return { activity: item?.kind === "transfer" ? "transfer" : "apply", approach: null, concept: c, item, reasons, markMastered, misconception: null };
      }
      reasons.push(markMastered ? `moving on to ${focus.label}` : `next concept in prerequisite order: ${focus.label}`);
    }
    const k = kOf(focus.id);

    // 3) Active misconception on the focus concept → remediation (refutation + discriminating item)
    if (this.ab.remediation) {
      // One distractor hit can be a guess; two independent signs are required before we spend a turn refuting it.
      const mis = x.beliefs.filter((b) => b.status !== "retired" && b.kind === "misconception" && b.concept === focus!.id && b.domain === pack.id && b.supportCount >= 2).sort((a, b) => b.supportCount - a.supportCount)[0];
      const m = mis ? focus.misconceptions?.find((mm) => mis.key.endsWith(`:${mm.id}`)) : null;
      const remediatedRecently = sameDomainLast?.activity === "remediate" && sameDomainLast.concept === focus.id;
      if (m && !remediatedRecently) {
        const item = pickDiscriminating(focus, m.id, k.attempts);
        reasons.push(`evidence of a specific misconception ("${m.statement}", ${mis!.supportCount} sign${mis!.supportCount === 1 ? "" : "s"}); refuting it directly`);
        return { activity: "remediate", approach: this.pickApproach(x, focus, reasons), concept: focus, item, reasons, markMastered, misconception: m };
      }
    }

    // 4) Verify a claim before trusting it
    if (k.basis === "claimed" && k.pKnown >= 0.4 && k.attempts === 0) {
      const item = pickItem(focus, "recall", 0);
      reasons.push(`learner says they know ${focus.label}; verifying with a quick check before skipping`);
      return { activity: "check", approach: null, concept: focus, item, reasons, markMastered, misconception: null };
    }

    // 5) Stage machine on the focus concept
    const lastOnFocus = sameDomainLast && sameDomainLast.concept === focus.id ? sameDomainLast : null;
    const failedNow = gradeRes && gradeRes.concept === focus.id && !gradeRes.correct;
    const passedNow = gradeRes && gradeRes.concept === focus.id && gradeRes.correct;
    const teachCount = sessionTurns.filter((t) => t.concept === focus!.id && t.activity === "teach").length;

    if (lastOnFocus?.activity === "teach" && !gradeRes && lastOnFocus.itemId && !p.requestedApproach) {
      const item = findItem(pack, lastOnFocus.itemId);
      reasons.push(p.reaction === "understood" ? "learner says it makes sense; asking for the check to see it" : "re-posing the unanswered check");
      return { activity: "check", approach: null, concept: focus, item, reasons, markMastered, misconception: null };
    }
    const needsTeaching = k.lastTaughtAt == null || (failedNow && (gradeRes!.itemKind === "recall" || gradeRes!.itemKind === "discriminate")) || p.requestedApproach || p.reaction === "confused";
    if (needsTeaching && !(k.basis === "demonstrated" && k.pKnown >= 0.85 && !failedNow && !p.requestedApproach && p.reaction !== "confused")) {
      const approach = this.pickApproach(x, focus, reasons);
      const item = pickItem(focus, "recall", k.attempts + teachCount);
      reasons.push(k.lastTaughtAt == null ? `${focus.label} has not been taught yet` : failedNow ? "the check was missed; explaining again differently" : p.requestedApproach ? "explaining the way the learner asked" : "learner is confused; explaining again");
      return { activity: "teach", approach, concept: focus, item, reasons, markMastered, misconception: null };
    }
    if (k.applySuccesses === 0 || (failedNow && gradeRes!.itemKind === "apply" && k.applyAttempts < 3)) {
      const item = pickItem(focus, "apply", k.applyAttempts);
      reasons.push(passedNow ? "recall demonstrated; moving to application" : "application not yet demonstrated");
      return { activity: "apply", approach: null, concept: focus, item, reasons, markMastered, misconception: null };
    }
    if (this.ab.transfer && k.transferSuccesses === 0 && k.transferAttempts < 2) {
      const item = pickItem(focus, "transfer", k.transferAttempts);
      reasons.push("application demonstrated; testing transfer to a new situation");
      return { activity: "transfer", approach: null, concept: focus, item, reasons, markMastered, misconception: null };
    }
    // Parked or completed: move on.
    const next = nextConcept(order, kOf, focus.id, sessionTurns) ?? focus;
    const approach = this.pickApproach(x, next, reasons);
    reasons.push(next.id === focus.id ? "continuing" : `${focus.label} is ${k.transferSuccesses >= 1 ? "mastered" : "parked for now"}; moving to ${next.label}`);
    return { activity: "teach", approach, concept: next, item: pickItem(next, "recall", kOf(next.id).attempts), reasons, markMastered: markMastered ?? (k.transferSuccesses >= 1 ? focus.id : null), misconception: null };
  }

  private pickApproach(x: { p: Perception }, _c: Concept, reasons: string[]): Approach {
    if (x.p.requestedApproach) { reasons.push(`learner asked for ${APPROACH_LABEL[x.p.requestedApproach]}`); return x.p.requestedApproach; }
    if (!this.ab.bandit || !this.lastSelection) { reasons.push("fixed approach (no adaptation)"); return "direct_explanation"; }
    reasons.push(...this.pendingApproachReasons);
    return this.lastSelection;
  }
  private lastSelection: Approach | null = null;

  private async compose(x: { decision: Decision; pack: DomainPack | null; gradeRes: Grade | null; pendingItem: TutorTurn | null; newSession: boolean; previousSessionsCount: number; previousDomain: string | null; correctionReply: string | null; p: Perception; text: string; knowledge: KnowledgeState[]; scale: number; now: Date }): Promise<string> {
    const { decision, pack } = x;
    const parts: string[] = [];
    if (x.newSession && x.previousSessionsCount > 0 && pack) {
      const learned = x.knowledge.filter((k) => k.mastered).length;
      parts.push(`Welcome back. Last time we worked on ${pack.label}${learned ? ` — ${learned} concept${learned === 1 ? "" : "s"} mastered so far` : ""}.`);
    }
    if (x.correctionReply) parts.push(x.correctionReply);
    if (x.gradeRes && pack && x.pendingItem?.itemId) {
      const item = findItem(pack, x.pendingItem.itemId);
      const c = conceptById(pack, x.gradeRes.concept);
      if (x.gradeRes.correct) parts.push(x.gradeRes.itemKind === "transfer" ? "Yes — that's the idea carried into a new situation." : "Right.");
      else {
        const m = x.gradeRes.matchedMisconception && c?.misconceptions?.find((mm) => mm.id === x.gradeRes!.matchedMisconception);
        parts.push(`Not quite. ${item?.feedback ?? c?.kernel ?? ""}${m ? ` (That answer usually comes from assuming ${m.statement}.)` : ""}`.trim());
      }
    }
    const prompt = decision.item ? decision.item.prompt : null;
    switch (decision.activity) {
      case "orient": {
        parts.push(x.p.goalText ? `I don't have material for "${x.p.goalText}" yet. Right now I can teach ${this.deps.domains.available().join(", ")} — or name another subject and I'll try to build it.` : `What would you like to learn? Tell me in your own words — for example "I want to learn ${this.deps.domains.available()[0]}". You can also say what you already know.`);
        break;
      }
      case "converse": {
        const c = decision.concept;
        const answer = await this.deps.provider.answer(x.text, { domainLabel: pack?.label ?? "", conceptLabel: c?.label ?? "", kernel: c?.kernel ?? "" }).catch(() => null);
        parts.push(answer ?? (c ? `${c.kernel}` : `Let's stay with ${pack?.label}; ask me about any of: ${pack?.concepts.map((k) => k.label).join(", ")}.`));
        if (prompt) parts.push(`When you're ready, the check is still open: ${prompt}`);
        break;
      }
      case "teach": {
        const c = decision.concept!; const a = decision.approach!;
        const body = c.explain[a] ?? c.kernel;
        const lead = { direct_explanation: "", worked_example: "Here's a concrete example. ", analogy: "Think of it this way. ", step_by_step: "Step by step: ", socratic: "Let me ask you something first. ", concise_summary: "In short: " }[a];
        let prose = `${lead}${body}`;
        if (a !== "direct_explanation" && a !== "concise_summary" && a !== "socratic") prose += `\n\nThe core idea: ${c.kernel}`;
        const rewritten = await this.deps.provider.compose({ activity: "teach", approach: a, conceptLabel: c.label, kernel: c.kernel, draft: prose, domainLabel: pack!.label }).catch(() => null);
        parts.push(`**${c.label}**\n\n${rewritten ?? prose}`);
        if (prompt) parts.push(`Quick check: ${prompt}`);
        else parts.push("Does that make sense so far?");
        break;
      }
      case "check": parts.push(`Quick check on ${decision.concept!.label}: ${prompt}`); break;
      case "review": parts.push(`Before we go on — a quick review of ${decision.concept!.label} from earlier: ${prompt}`); break;
      case "apply": parts.push(`Let's use it. ${prompt}`); break;
      case "transfer": parts.push(`New situation, same idea. ${prompt}`); break;
      case "remediate": {
        const m = decision.misconception!; const c = decision.concept!;
        const rewritten = await this.deps.provider.compose({ activity: "remediate", approach: decision.approach, conceptLabel: c.label, kernel: c.kernel, draft: m.refutation, domainLabel: pack!.label }).catch(() => null);
        parts.push(`There's a specific mix-up worth clearing up. It looks like you may be assuming ${m.statement}. ${rewritten ?? m.refutation}`);
        if (prompt) parts.push(`Try this one: ${prompt}`);
        break;
      }
    }
    return parts.filter(Boolean).join("\n\n");
  }

  /** Called by decide() through pickApproach; separated so bandit state can be prepared once per turn. */
  async prepareApproach(learnerId: string, domain: string, beliefs: Belief[], lastTutor: TutorTurn | null, sameSession: boolean, now: Date, reasons: string[]): Promise<Approach> {
    const outcomes = await this.deps.store.outcomes(learnerId);
    const mine = outcomes.filter((o) => o.domain === domain).sort((a, b) => a.at.getTime() - b.at.getTime());
    const lastTwo = mine.slice(-2);
    const strongFails = lastTwo.filter((o) => o.value < -0.3 && o.weight >= 0.5 && lastTutor && o.approach === lastTutor.approach).length;
    const last = mine[mine.length - 1];
    const sel = selectApproach({ outcomes, beliefs, domain, now, lastApproach: sameSession && lastTutor?.domain === domain ? lastTutor.approach : null, lastOutcome: last && lastTutor && last.tutorTurnId === lastTutor.id ? { value: last.value, weight: last.weight } : null, consecutiveStrongFailures: strongFails, rnd: this.rnd, useLongTerm: this.ab.longTerm });
    reasons.push(...sel.reasons);
    return sel.approach;
  }

  // -------------------------------------------------------------------------
  async challengeBelief(learnerId: string, beliefId: string, replacement: string | null, now: Date = new Date()): Promise<{ retired: string | null; created: string | null }> {
    const { store } = this.deps;
    const beliefs = await store.beliefs(learnerId);
    const b = beliefs.find((x) => x.id === beliefId);
    if (!b) return { retired: null, created: null };
    let session = await store.latestSession(learnerId);
    if (!session) { session = { id: nextId("s", this.rnd), learnerId, startedAt: now, lastActivityAt: now, domain: null }; await store.saveSession(session); }
    const o: Observation = { id: nextId("o", this.rnd), learnerId, sessionId: session.id, at: now, kind: "correction", content: `not true: ${b.statement}${replacement ? ` — instead: ${replacement}` : ""}`, domain: b.domain, concept: b.concept, dedupeKey: `correction:${b.id}:${now.getTime()}` };
    await store.addObservation(o);
    let created: string | null = null;
    if (replacement) {
      const nb: Belief = { id: nextId("b", this.rnd), learnerId, kind: b.kind === "misconception" ? "context" : b.kind === "approach_fit" ? "preference" : b.kind, key: `stated:${replacement.toLowerCase().replace(/[^a-z0-9]+/g, "_").slice(0, 60)}`, statement: replacement, domain: b.domain, concept: b.concept, source: "stated", polarity: 1, status: "active", confidence: 0.85, supportCount: 1, contradictionCount: 0, sessionIds: [session.id], validFrom: now, invalidAt: null, invalidReason: null, supersededBy: null, lastConfirmedAt: now, createdAt: now, updatedAt: now };
      await store.saveBelief(nb); await store.addEvidence({ beliefId: nb.id, observationId: o.id, relation: "supports", at: now }); created = nb.id;
    }
    await store.saveBelief(Object.assign(b, retirePatch(b, now, "learner correction", created)));
    await store.addEvidence({ beliefId: b.id, observationId: o.id, relation: "correction", at: now });
    return { retired: b.id, created };
  }

  async model(learnerId: string, now: Date = new Date()): Promise<LearnerModelView> {
    const { store } = this.deps;
    const beliefs = await store.beliefs(learnerId);
    const ev = await store.evidenceFor(beliefs.map((b) => b.id));
    const obsList = await store.observationsByIds(ev.map((e) => e.observationId));
    const knowledge = await store.knowledge(learnerId);
    const domains = [...new Set(knowledge.map((k) => k.domain))];
    const calibrations = (await Promise.all(domains.map((d) => store.calibration(learnerId, d)))).filter((c): c is NonNullable<typeof c> => !!c);
    const outcomes = await store.outcomes(learnerId);
    const approachStats: LearnerModelView["approachStats"] = [];
    for (const d of new Set(outcomes.map((o) => o.domain))) { const s = armStats(outcomes, d, now); for (const a of APPROACHES) if (s[a].weight > 0) approachStats.push({ domain: d, approach: a, mean: s[a].sum / s[a].weight, weight: s[a].weight }); }
    const views: BeliefView[] = beliefs.map((b) => ({ id: b.id, kind: b.kind, statement: b.statement, domain: b.domain, concept: b.concept, source: b.source, status: effectiveStatus(b, now), confidence: b.confidence, influence: influenceOf(b, now, b.domain), supportCount: b.supportCount, contradictionCount: b.contradictionCount, lastConfirmedAt: b.lastConfirmedAt.toISOString(), invalidReason: b.invalidReason, evidence: ev.filter((e) => e.beliefId === b.id).map((e) => { const o = obsList.find((x) => x.id === e.observationId); return { observationId: e.observationId, relation: e.relation, content: o?.content ?? "", at: (o?.at ?? e.at).toISOString() }; }) })).sort((a, b) => b.influence - a.influence);
    const kviews: KnowledgeView[] = [];
    for (const k of knowledge) {
      const pack = await this.deps.domains.byId(k.domain);
      const c = pack ? conceptById(pack, k.concept) : null;
      const cal = calibrations.find((x) => x.domain === k.domain);
      const stage: KnowledgeView["stage"] = k.mastered ? "mastered" : k.transferAttempts > 0 || k.applySuccesses > 0 ? "transferring" : k.successes > 0 ? "applying" : k.lastTaughtAt || k.attempts > 0 ? "learning" : "untaught";
      kviews.push({ domain: k.domain, concept: k.concept, label: c?.label ?? k.concept, pKnown: k.pKnown, retained: retained(k, now, cal?.stabilityScale ?? 1), basis: k.basis, stage, attempts: k.attempts, successes: k.successes, stabilityDays: k.stability * (cal?.stabilityScale ?? 1), nextReviewInDays: daysUntilReview(k, now, cal?.stabilityScale ?? 1, this.reviewThreshold), claimedLevel: k.claimedLevel, mastered: k.mastered });
    }
    const recent = await store.recentObservations(learnerId, 30);
    return { learnerId, domains, beliefs: views, knowledge: kviews, calibrations, approachStats, recentObservations: recent.map((o) => ({ kind: o.kind, content: o.content, at: o.at.toISOString(), domain: o.domain })), sessions: await store.countSessions(learnerId) };
  }

  // -------------------------------------------------------------------------
  private async upsert(beliefs: Belief[], p: { learnerId: string; kind: BeliefKind; key: string; statement: string; domain: string | null; concept: string | null; source: Belief["source"]; polarity: 1 | -1 }, obsId: string | null, sessionId: string, now: Date, trace: Trace, inferred: boolean): Promise<Belief[]> {
    const { store } = this.deps;
    // opposite-polarity live belief with the same key is contradicted, not overwritten
    const opposite = beliefs.find((b) => b.key === p.key && b.status !== "retired" && b.polarity !== p.polarity);
    if (opposite && obsId) await this.contradict(opposite, obsId, now, "opposite evidence", trace);
    let b = beliefs.find((x) => x.key === p.key && x.status !== "retired" && x.polarity === p.polarity);
    if (b) {
      // Strategy-fit / misconception beliefs may not re-derive from evidence before the last correction.
      const patch = applySupport(b, sessionId, now);
      const before = b.status;
      Object.assign(b, patch);
      await store.saveBelief(b);
      if (obsId) await store.addEvidence({ beliefId: b.id, observationId: obsId, relation: "supports", at: now });
      if (before !== b.status) trace.changes.push(`belief "${b.statement}" ${before} → ${b.status} (support ${b.supportCount})`);
      return beliefs;
    }
    const retiredByCorrection = beliefs.find((x) => x.key === p.key && x.status === "retired" && x.invalidReason === "learner correction");
    if (retiredByCorrection && inferred && retiredByCorrection.invalidAt && now.getTime() - retiredByCorrection.invalidAt.getTime() < 14 * 86_400_000) {
      trace.inferred.push(`not re-creating "${p.statement}": corrected by the learner ${daysAgo(retiredByCorrection.invalidAt, now)}d ago`);
      return beliefs;
    }
    b = { id: nextId("b", this.rnd), learnerId: p.learnerId, kind: p.kind, key: p.key, statement: p.statement, domain: p.domain, concept: p.concept, source: p.source, polarity: p.polarity, status: p.source === "stated" ? "active" : "candidate", confidence: p.source === "stated" ? 0.85 : 0.5, supportCount: 1, contradictionCount: 0, sessionIds: [sessionId], validFrom: now, invalidAt: null, invalidReason: null, supersededBy: null, lastConfirmedAt: now, createdAt: now, updatedAt: now };
    await store.saveBelief(b);
    if (obsId) await store.addEvidence({ beliefId: b.id, observationId: obsId, relation: "supports", at: now });
    trace.changes.push(`new ${b.status} belief: "${b.statement}"`);
    return [...beliefs, b];
  }

  private async contradict(b: Belief, obsId: string, now: Date, reason: string, trace: Trace) {
    const before = b.status;
    Object.assign(b, applyContradiction(b, now, reason));
    await this.deps.store.saveBelief(b);
    await this.deps.store.addEvidence({ beliefId: b.id, observationId: obsId, relation: "contradicts", at: now });
    if (before !== b.status) trace.changes.push(`belief "${b.statement}" ${before} → ${b.status} (${reason})`);
  }

  pendingApproachReasons: string[] = [];
}

// ---------------------------------------------------------------------------
interface Decision { activity: Activity; approach: Approach | null; concept: Concept | null; item: Item | null; reasons: string[]; markMastered: string | null; misconception: { id: string; statement: string; refutation: string } | null }

export function conceptById(pack: DomainPack, id: string): Concept | null { return pack.concepts.find((c) => c.id === id) ?? null; }
export function findItem(pack: DomainPack, id: string): Item | null { for (const c of pack.concepts) { const i = c.items.find((x) => x.id === id); if (i) return i; } return null; }
export function matchConcept(pack: DomainPack, text: string): Concept | null {
  const t = text.toLowerCase();
  let best: { c: Concept; s: number } | null = null;
  for (const c of pack.concepts) {
    let s = 0;
    if (t.includes(c.label.toLowerCase())) s += c.label.length;
    for (const k of c.keywords) if (t.includes(k.toLowerCase())) s += k.length;
    if (s > 0 && (!best || s > best.s)) best = { c, s };
  }
  return best?.c ?? null;
}
function pickItem(c: Concept, kind: ItemKind, n: number): Item | null { const list = c.items.filter((i) => i.kind === kind); return list.length ? list[n % list.length] : null; }
function pickDiscriminating(c: Concept, misconceptionId: string, n: number): Item | null {
  const list = c.items.filter((i) => i.distractors?.some((d) => d.misconception === misconceptionId)).sort((a, b) => (a.kind === "discriminate" ? -1 : 1) - (b.kind === "discriminate" ? -1 : 1));
  return list.length ? list[n % list.length] : pickItem(c, "recall", n);
}
function daysAgo(d: Date, now: Date) { return Math.round((now.getTime() - d.getTime()) / 86_400_000); }
function parked(sessionTurns: TutorTurn[], conceptId: string): boolean {
  const onIt = sessionTurns.filter((t) => t.concept === conceptId);
  return onIt.filter((t) => t.activity === "teach").length >= 4 || onIt.filter((t) => t.activity === "transfer").length >= 2 && onIt.length >= 8;
}
function previousFocus(sessionTurns: TutorTurn[], pack: DomainPack): Concept | null {
  for (let i = sessionTurns.length - 1; i >= 0; i--) { const t = sessionTurns[i]; if (t.activity !== "review" && t.activity !== "converse" && t.concept) return conceptById(pack, t.concept); }
  return null;
}
function nextConcept(order: Concept[], kOf: (id: string) => KnowledgeState, exclude: string | null, sessionTurns: TutorTurn[]): Concept | null {
  const done = (id: string) => { const k = kOf(id); return k.mastered || k.transferSuccesses >= 1 || id === exclude; };
  const ready = order.filter((c) => !done(c.id) && !parked(sessionTurns, c.id) && c.prereqs.every((p) => { const k = kOf(p); return done(p) || k.pKnown >= 0.75 || parked(sessionTurns, p); }));
  return ready[0] ?? null;
}
