// Storage boundary. The engine only talks to this interface.
import type { Belief, BeliefEvidence, Calibration, KnowledgeState, LearnerTurn, Observation, OutcomeRecord, ResearchEntry, Session, TutorTurn } from "./types";

export interface Store {
  // sessions
  latestSession(learnerId: string): Promise<Session | null>;
  countSessions(learnerId: string): Promise<number>;
  saveSession(s: Session): Promise<void>;
  // observations (append-only)
  addObservation(o: Observation): Promise<boolean>; // false if deduped
  recentObservations(learnerId: string, limit: number): Promise<Observation[]>;
  observationsByIds(ids: string[]): Promise<Observation[]>;
  sessionObservations(learnerId: string, sessionId: string): Promise<Observation[]>;
  // beliefs
  beliefs(learnerId: string): Promise<Belief[]>;
  saveBelief(b: Belief): Promise<void>;
  addEvidence(e: BeliefEvidence): Promise<void>;
  evidenceFor(beliefIds: string[]): Promise<BeliefEvidence[]>;
  // knowledge
  knowledge(learnerId: string, domain?: string): Promise<KnowledgeState[]>;
  saveKnowledge(k: KnowledgeState): Promise<void>;
  calibration(learnerId: string, domain: string): Promise<Calibration | null>;
  saveCalibration(c: Calibration): Promise<void>;
  // turns
  lastTutorTurn(learnerId: string): Promise<TutorTurn | null>;
  saveTutorTurn(t: TutorTurn): Promise<void>;
  saveLearnerTurn(t: LearnerTurn): Promise<void>;
  recentTutorTurns(learnerId: string, sessionId: string): Promise<TutorTurn[]>;
  recentLearnerTurns(learnerId: string, sessionId: string): Promise<LearnerTurn[]>;
  // approach outcomes
  outcomes(learnerId: string): Promise<OutcomeRecord[]>;
  addOutcome(o: OutcomeRecord): Promise<void>;
  // research (isolated from learner memory)
  research(key: string): Promise<ResearchEntry | null>;
  saveResearch(e: ResearchEntry): Promise<void>;
  // custom domain packs (model/research-built), stored as application state, not learner state
  domainPack(id: string): Promise<unknown | null>;
  saveDomainPack(id: string, pack: unknown): Promise<void>;
  listDomainPacks(): Promise<string[]>;
}

export class InMemoryStore implements Store {
  sessions: Session[] = [];
  observations: Observation[] = [];
  beliefList: Belief[] = [];
  evidence: BeliefEvidence[] = [];
  knowledgeList: KnowledgeState[] = [];
  calibrations: Calibration[] = [];
  tutorTurns: TutorTurn[] = [];
  learnerTurns: LearnerTurn[] = [];
  outcomeList: OutcomeRecord[] = [];
  researchMap = new Map<string, ResearchEntry>();
  packs = new Map<string, unknown>();

  async latestSession(learnerId: string) { return [...this.sessions].filter((s) => s.learnerId === learnerId).sort((a, b) => b.startedAt.getTime() - a.startedAt.getTime())[0] ?? null; }
  async countSessions(learnerId: string) { return this.sessions.filter((s) => s.learnerId === learnerId).length; }
  async saveSession(s: Session) { const i = this.sessions.findIndex((x) => x.id === s.id); if (i >= 0) this.sessions[i] = s; else this.sessions.push(s); }
  async addObservation(o: Observation) {
    if (this.observations.some((x) => x.learnerId === o.learnerId && x.sessionId === o.sessionId && x.dedupeKey === o.dedupeKey)) return false;
    this.observations.push(o); return true;
  }
  async recentObservations(learnerId: string, limit: number) { return this.observations.filter((o) => o.learnerId === learnerId).slice(-limit).reverse(); }
  async observationsByIds(ids: string[]) { const s = new Set(ids); return this.observations.filter((o) => s.has(o.id)); }
  async sessionObservations(learnerId: string, sessionId: string) { return this.observations.filter((o) => o.learnerId === learnerId && o.sessionId === sessionId); }
  async beliefs(learnerId: string) { return this.beliefList.filter((b) => b.learnerId === learnerId).map((b) => ({ ...b })); }
  async saveBelief(b: Belief) { const i = this.beliefList.findIndex((x) => x.id === b.id); if (i >= 0) this.beliefList[i] = { ...b }; else this.beliefList.push({ ...b }); }
  async addEvidence(e: BeliefEvidence) { this.evidence.push(e); }
  async evidenceFor(ids: string[]) { const s = new Set(ids); return this.evidence.filter((e) => s.has(e.beliefId)); }
  async knowledge(learnerId: string, domain?: string) { return this.knowledgeList.filter((k) => k.learnerId === learnerId && (!domain || k.domain === domain)).map((k) => ({ ...k })); }
  async saveKnowledge(k: KnowledgeState) { const i = this.knowledgeList.findIndex((x) => x.learnerId === k.learnerId && x.domain === k.domain && x.concept === k.concept); if (i >= 0) this.knowledgeList[i] = { ...k }; else this.knowledgeList.push({ ...k }); }
  async calibration(learnerId: string, domain: string) { const c = this.calibrations.find((x) => x.learnerId === learnerId && x.domain === domain); return c ? { ...c } : null; }
  async saveCalibration(c: Calibration) { const i = this.calibrations.findIndex((x) => x.learnerId === c.learnerId && x.domain === c.domain); if (i >= 0) this.calibrations[i] = { ...c }; else this.calibrations.push({ ...c }); }
  async lastTutorTurn(learnerId: string) { const l = this.tutorTurns.filter((t) => t.learnerId === learnerId); return l[l.length - 1] ?? null; }
  async saveTutorTurn(t: TutorTurn) { this.tutorTurns.push(t); }
  async saveLearnerTurn(t: LearnerTurn) { this.learnerTurns.push(t); }
  async recentTutorTurns(learnerId: string, sessionId: string) { return this.tutorTurns.filter((t) => t.learnerId === learnerId && t.sessionId === sessionId); }
  async recentLearnerTurns(learnerId: string, sessionId: string) { return this.learnerTurns.filter((t) => t.learnerId === learnerId && t.sessionId === sessionId); }
  async outcomes(learnerId: string) { return this.outcomeList.filter((o) => o.learnerId === learnerId); }
  async addOutcome(o: OutcomeRecord) { this.outcomeList.push(o); }
  async research(key: string) { return this.researchMap.get(key) ?? null; }
  async saveResearch(e: ResearchEntry) { this.researchMap.set(e.key, e); }
  async domainPack(id: string) { return this.packs.get(id) ?? null; }
  async saveDomainPack(id: string, pack: unknown) { this.packs.set(id, pack); }
  async listDomainPacks() { return [...this.packs.keys()]; }
}
