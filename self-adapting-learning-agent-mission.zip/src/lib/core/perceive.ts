// Deterministic perception of learner text. Flags evidence; never classifies the person.
// A provider may add a validated patch on top, but these fields are the safety net.
import { APPROACHES, type Approach } from "./types";

export interface Perception {
  reaction: "understood" | "confused" | "neutral" | "disagree";
  requestedApproach: Approach | null;
  selfReports: { text: string; level: number }[]; // level 0 (don't know) .. 1 (know)
  isCorrection: boolean;
  correctionTarget: string | null; // free text after "not true"/"I don't" etc.
  isQuestion: boolean;
  goalText: string | null;
  wantsBreak: boolean;
  wantsReview: boolean;
  looksLikeAnswer: boolean;
  normalized: string;
}

const REQUEST: [RegExp, Approach][] = [
  [/\b(example|show me|concrete|for instance|demo)\b/i, "worked_example"],
  [/\b(analogy|metaphor|compare it to|like what)\b/i, "analogy"],
  [/\b(step by step|step-by-step|walk me through|one step at a time|slowly)\b/i, "step_by_step"],
  [/\b(ask me questions|let me figure|quiz me|socratic|guide me)\b/i, "socratic"],
  [/\b(shorter|summary|tl;?dr|just the gist|concise|brief)\b/i, "concise_summary"],
  [/\b(just explain|explain it directly|plain explanation|tell me directly|no analogies)\b/i, "direct_explanation"],
];

const UNDERSTOOD = /\b(makes sense|got it|i see|i understand|that helps|clear now|understood|perfect|thanks,? that|ok(ay)? got|that clicked|ah+,? ok)\b/i;
const CONFUSED = /\b(confus|don't get|dont get|do not get|lost|not following|unclear|huh|what do you mean|i'm stuck|im stuck|doesn't make sense|not clear)\b/i;
const DISAGREE = /\b(i disagree|that's wrong|thats wrong|not right|incorrect|actually,? no|no,? that)\b/i;
const CORRECTION = /\b(that'?s not true about me|not true about me|you'?re wrong about me|i (do not|don't|never) (actually )?(prefer|like|need|want|learn best)|stop (assuming|giving)|i'?m not (a|an) )\b/i;
const KNOW = /\b(i (already )?know|i'?m (familiar|comfortable|good) with|i'?ve (used|done|learned)|i understand) ([^.,!?]{2,60})/i;
const DONT_KNOW = /\b(i (don'?t|do not|never) (know|understand|get)|i'?m (new to|unfamiliar with|weak (on|at))|never (used|heard of)) ([^.,!?]{2,60})/i;
const GOAL = /\b(i want to (learn|understand|get better at|study|master)|teach me|help me (learn|understand|with)|let'?s (learn|study|do)|can you teach me|i'?d like to learn)\s+([^.!?]{2,80})/i;

export function perceive(text: string, hasPendingItem: boolean): Perception {
  const t = text.trim();
  const lower = t.toLowerCase();
  const isCorrection = CORRECTION.test(t);
  let requestedApproach: Approach | null = null;
  if (!isCorrection) for (const [re, a] of REQUEST) if (re.test(t)) { requestedApproach = a; break; }
  const reaction = isCorrection ? "neutral" : DISAGREE.test(t) ? "disagree" : CONFUSED.test(t) ? "confused" : UNDERSTOOD.test(t) ? "understood" : "neutral";
  const selfReports: Perception["selfReports"] = [];
  if (!isCorrection) {
    const k = KNOW.exec(t); if (k) selfReports.push({ text: k[k.length - 1].trim(), level: 1 });
    const d = DONT_KNOW.exec(t); if (d) selfReports.push({ text: d[d.length - 1].trim(), level: 0 });
  }
  const g = GOAL.exec(t);
  const goalText = g ? g[g.length - 1].trim() : null;
  const isQuestion = /\?\s*$/.test(t) || /^(what|why|how|when|where|which|can|could|is|are|does|do)\b/i.test(t);
  const wantsBreak = /\b(take a break|stop for now|enough for today|i'?m done|later)\b/i.test(t);
  const wantsReview = /\b(review|recap|refresh|go over|quiz me on what)\b/i.test(t) && !requestedApproach;
  // Reactions and answers co-occur ("makes sense — $count"): strip reaction phrases and see if content remains.
  const residual = t.replace(UNDERSTOOD, " ").replace(CONFUSED, " ").replace(DISAGREE, " ").replace(/^(ok(ay)?|yes|yeah|right|hmm+|ah+|oh|well|so|thanks|thank you)\b[\s,.:!-]*/i, "").replace(/[\s,.:!;-]+/g, " ").trim();
  const clearlyQuestion = /^(what|why|how|when|where|which|who|can|could|would|should|is|are|does|do|did)\b/i.test(t) && /\?/.test(t);
  const looksLikeAnswer = hasPendingItem && !isCorrection && !requestedApproach && !goalText && !wantsBreak && !wantsReview && !clearlyQuestion && !(isQuestion && t.length > 60) && residual.length > 0 && !(reaction === "confused" && residual.length < 3);
  return { reaction, requestedApproach, selfReports, isCorrection, correctionTarget: isCorrection ? t : null, isQuestion, goalText, wantsBreak, wantsReview, looksLikeAnswer, normalized: lower };
}

/** Which approach a correction sentence is about, if any. */
export function approachMentioned(text: string): Approach | null {
  const t = text.toLowerCase();
  const names: Record<Approach, RegExp> = {
    worked_example: /example/,
    analogy: /analog|metaphor/,
    step_by_step: /step/,
    socratic: /question|socratic|figure it out/,
    concise_summary: /summar|short|concise|brief/,
    direct_explanation: /direct|plain|explanation/,
  };
  for (const a of APPROACHES) if (names[a].test(t)) return a;
  return null;
}
