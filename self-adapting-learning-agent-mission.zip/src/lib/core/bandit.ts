// Approach selection: discounted per-arm posteriors, other-domain hierarchical prior,
// belief-shifted priors, UCB + ε, evidence-gated hysteresis. Deterministic given a seed.
import { APPROACHES, type Approach, type Belief, type OutcomeRecord } from "./types";
import { DAY, influenceOf } from "./epistemics";

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface ArmStat { approach: Approach; mean: number; weight: number; ucb: number; prior: number }

const GAMMA = 0.9; // per-arm discount: effective memory ≈ 10 outcomes of that arm

/** Discounted mean/weight per arm for one domain. Newest outcome weighs 1, older ones γ^k. */
export function armStats(outcomes: OutcomeRecord[], domain: string, now: Date): Record<Approach, { sum: number; weight: number }> {
  const out = {} as Record<Approach, { sum: number; weight: number }>;
  for (const a of APPROACHES) out[a] = { sum: 0, weight: 0 };
  const byArm = new Map<Approach, OutcomeRecord[]>();
  for (const o of outcomes) if (o.domain === domain) (byArm.get(o.approach) ?? byArm.set(o.approach, []).get(o.approach)!).push(o);
  for (const [a, list] of byArm) {
    list.sort((x, y) => y.at.getTime() - x.at.getTime());
    list.forEach((o, i) => {
      const age = Math.max(0, (now.getTime() - o.at.getTime()) / DAY);
      const w = o.weight * Math.pow(GAMMA, i) * Math.max(0.35, Math.pow(0.5, age / 90));
      out[a].sum += o.value * w;
      out[a].weight += w;
    });
  }
  return out;
}

/** Pooled evidence from OTHER domains only, shrunk to ≤ 4 pseudo-observations. */
export function hierarchicalPrior(outcomes: OutcomeRecord[], domain: string, now: Date): Record<Approach, number> {
  const prior = {} as Record<Approach, number>;
  const others = outcomes.filter((o) => o.domain !== domain);
  const domains = new Set(others.map((o) => o.domain));
  for (const a of APPROACHES) prior[a] = 0;
  for (const d of domains) {
    const s = armStats(others, d, now);
    for (const a of APPROACHES) if (s[a].weight > 0) prior[a] += (s[a].sum / s[a].weight) * Math.min(1, s[a].weight / 4);
  }
  const n = Math.max(1, domains.size);
  for (const a of APPROACHES) prior[a] = Math.max(-0.6, Math.min(0.6, prior[a] / n));
  return prior;
}

export interface SelectInput {
  outcomes: OutcomeRecord[];
  beliefs: Belief[];
  domain: string;
  now: Date;
  lastApproach: Approach | null;
  lastOutcome: { value: number; weight: number } | null;
  consecutiveStrongFailures: number;
  rnd: () => number;
  useLongTerm: boolean;
}

export interface Selection { approach: Approach; stats: ArmStat[]; reasons: string[] }

export function selectApproach(i: SelectInput): Selection {
  const stats = armStats(i.outcomes, i.domain, i.now);
  const hier = hierarchicalPrior(i.outcomes, i.domain, i.now);
  const W = APPROACHES.reduce((s, a) => s + stats[a].weight, 0);
  const arms: ArmStat[] = APPROACHES.map((a) => {
    let prior = 0.35 * hier[a];
    if (i.useLongTerm) {
      for (const b of i.beliefs) {
        if ((b.kind === "preference" || b.kind === "approach_fit") && b.key.endsWith(`:${a}`)) prior += 0.5 * b.polarity * influenceOf(b, i.now, i.domain);
      }
    }
    const pseudo = 1.5;
    const mean = (stats[a].sum + prior * pseudo) / (stats[a].weight + pseudo);
    const bonus = 0.6 * Math.sqrt(Math.log(2 + W) / (1 + stats[a].weight));
    return { approach: a, mean, weight: stats[a].weight, ucb: mean + bonus, prior };
  });
  const reasons: string[] = [];
  const best = [...arms].sort((x, y) => y.ucb - x.ucb)[0];
  const eps = Math.max(0.04, 0.3 / (1 + W / 6));

  // Change detector: two strong failures in a row → switch regardless.
  if (i.lastApproach && i.consecutiveStrongFailures >= 2) {
    const alt = arms.filter((a) => a.approach !== i.lastApproach).sort((x, y) => y.ucb - x.ucb)[0];
    reasons.push(`switched away from ${i.lastApproach}: two strong failures in a row`);
    return { approach: alt.approach, stats: arms, reasons };
  }
  // Hysteresis: win-stay only on strong positive evidence with a decent arm and no clear winner elsewhere.
  if (i.lastApproach && i.lastOutcome && i.lastOutcome.weight >= 0.5 && i.lastOutcome.value > 0.3) {
    const cur = arms.find((a) => a.approach === i.lastApproach)!;
    if (cur.mean >= 0.55 && best.mean - cur.mean < 0.15) {
      reasons.push(`kept ${cur.approach}: it just worked (mean ${cur.mean.toFixed(2)})`);
      return { approach: cur.approach, stats: arms, reasons };
    }
  }
  if (i.rnd() < eps) {
    const pick = arms[Math.floor(i.rnd() * arms.length)];
    reasons.push(`exploring ${pick.approach} (ε=${eps.toFixed(2)})`);
    return { approach: pick.approach, stats: arms, reasons };
  }
  reasons.push(`${best.approach} has the best estimate (mean ${best.mean.toFixed(2)}, evidence ${best.weight.toFixed(1)}${best.prior ? `, prior ${best.prior.toFixed(2)}` : ""})`);
  return { approach: best.approach, stats: arms, reasons };
}
