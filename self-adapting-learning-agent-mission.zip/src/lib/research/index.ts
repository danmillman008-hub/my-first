// Subject research (Wikipedia). Produces subject material with provenance, cached in the
// research store. It is application knowledge, never learner knowledge: nothing here reads
// or writes learner state, and the request carries no learner information beyond the subject.
import type { Store } from "../core/store";

interface WikiSummary { title: string; extract: string; content_urls?: { desktop?: { page?: string } } }

async function fetchJson<T>(url: string): Promise<T | null> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 8000);
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { "user-agent": "private-learning-agent/1.0 (research; no learner data)" } });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch { return null; } finally { clearTimeout(t); }
}

/** Build a minimal pack: the subject plus up to 3 linked sub-topics, each with a definition and a cloze recall item. */
export async function researchPack(subject: string, store: Store): Promise<unknown | null> {
  const key = `wiki:${subject.toLowerCase()}`;
  const cached = await store.research(key);
  if (cached) return cached.payload;
  const search = await fetchJson<{ pages?: { key: string; title: string; description?: string }[] }>(`https://en.wikipedia.org/w/rest.php/v1/search/title?q=${encodeURIComponent(subject)}&limit=4`);
  const titles = (search?.pages ?? []).map((p) => p.title).slice(0, 4);
  if (!titles.length) return null;
  const concepts: unknown[] = [];
  for (const title of titles) {
    const s = await fetchJson<WikiSummary>(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`);
    if (!s?.extract) continue;
    const sentences = s.extract.split(/(?<=[.!?])\s+/).filter((x) => x.length > 30);
    const kernel = sentences[0] ?? s.extract.slice(0, 300);
    const cloze = makeCloze(kernel, s.title);
    concepts.push({
      id: s.title, label: s.title, prereqs: concepts.length ? [] : [], keywords: [s.title.toLowerCase()],
      kernel,
      explain: { direct_explanation: sentences.slice(0, 3).join(" "), concise_summary: kernel, step_by_step: sentences.slice(0, 3).map((x, i) => `${i + 1}) ${x}`).join(" ") },
      items: [
        cloze ? { id: "r1", kind: "recall", prompt: cloze.prompt, accept: cloze.accept, feedback: kernel } : null,
        { id: "a1", kind: "apply", prompt: `In your own words, what is ${s.title}? Include the key term "${keyTerm(kernel, s.title)}".`, accept: [keyTerm(kernel, s.title)], feedback: kernel },
        { id: "t1", kind: "transfer", prompt: `Give one example or situation where ${s.title} matters, and name the idea it relies on ("${keyTerm(kernel, s.title)}").`, accept: [keyTerm(kernel, s.title)], feedback: kernel },
      ].filter(Boolean),
      misconceptions: [],
      provenance: s.content_urls?.desktop?.page ?? `https://en.wikipedia.org/wiki/${encodeURIComponent(s.title)}`,
    });
  }
  if (!concepts.length) return null;
  const payload = { id: subject, label: titles[0], category: "researched", keywords: [subject.toLowerCase(), ...titles.map((t) => t.toLowerCase())], concepts, source: "research" };
  await store.saveResearch({ key, payload, source: "wikipedia", fetchedAt: new Date() });
  return payload;
}

function keyTerm(sentence: string, title: string): string {
  const words = sentence.replace(/[^\w\s-]/g, " ").split(/\s+/).filter((w) => w.length >= 6 && !title.toLowerCase().includes(w.toLowerCase()) && !/^(which|through|between|because|usually|generally|typically|however|although)$/i.test(w));
  return (words.sort((a, b) => b.length - a.length)[0] ?? title).toLowerCase();
}
function makeCloze(sentence: string, title: string): { prompt: string; accept: string[] } | null {
  const term = keyTerm(sentence, title);
  if (!term || !sentence.toLowerCase().includes(term)) return null;
  const re = new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
  return { prompt: `Fill in the blank: "${sentence.replace(re, "_____")}"`, accept: [term] };
}
