import type { ComposePlan, Provider } from "./types";

/** Deterministic provider: keeps drafts verbatim. Used offline, in the lab and in tests. */
export class OfflineProvider implements Provider {
  name = "offline";
  async compose(_plan: ComposePlan) { return null; }
  async answer() { return null; }
  async synthesizePack() { return null; }
}

/**
 * OpenAI-compatible chat provider over fetch (works with OpenAI, Ollama, vLLM, OpenRouter…).
 * Every failure falls back to the offline behaviour; no learner data other than the current
 * question / concept text is ever sent.
 */
export class OpenAIProvider implements Provider {
  name = "openai";
  constructor(private apiKey: string, private model = process.env.OPENAI_MODEL ?? "gpt-4o-mini", private baseUrl = (process.env.OPENAI_BASE_URL ?? "https://api.openai.com/v1").replace(/\/$/, "")) {}

  private async chat(system: string, user: string, json = false, maxTokens = 700): Promise<string | null> {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 20_000);
    try {
      const res = await fetch(`${this.baseUrl}/chat/completions`, {
        method: "POST", signal: ctrl.signal,
        headers: { "content-type": "application/json", authorization: `Bearer ${this.apiKey}` },
        body: JSON.stringify({ model: this.model, temperature: 0.4, max_tokens: maxTokens, ...(json ? { response_format: { type: "json_object" } } : {}), messages: [{ role: "system", content: system }, { role: "user", content: user }] }),
      });
      if (!res.ok) return null;
      const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      return data.choices?.[0]?.message?.content?.trim() || null;
    } catch { return null; } finally { clearTimeout(t); }
  }

  async compose(plan: ComposePlan) {
    const style: Record<string, string> = { direct_explanation: "a clear, direct explanation", worked_example: "one fully worked concrete example, then the principle", analogy: "one vivid analogy, then map it explicitly onto the real concept", step_by_step: "numbered steps, one action per step", socratic: "two or three guiding questions that lead the learner to the idea, without giving the answer", concise_summary: "at most three short sentences" };
    const out = await this.chat(
      `You are a tutor writing ONE explanation for the concept "${plan.conceptLabel}" in ${plan.domainLabel}. Use ${style[plan.approach ?? "direct_explanation"] ?? "a clear explanation"}. The explanation must be consistent with this ground truth: "${plan.kernel}". ${plan.activity === "remediate" ? "The learner holds a specific misconception; refute it directly (state the wrong idea, why it fails, and the correct idea)." : ""} Do not ask a quiz question; the system adds its own check. Plain text or light markdown, under 160 words.`,
      `Draft to improve (keep it factually identical):\n${plan.draft}`,
    );
    return out && out.length > 20 ? out : null;
  }

  async answer(question: string, ctx: { domainLabel: string; conceptLabel: string; kernel: string }) {
    return this.chat(`You are a tutor for ${ctx.domainLabel}. Answer the learner's question briefly (under 120 words), staying consistent with: "${ctx.kernel}" (concept: ${ctx.conceptLabel}). If the question is off-topic, answer in one sentence and steer back.`, question);
  }

  async synthesizePack(subject: string) {
    const out = await this.chat(
      `Produce a compact learning pack as JSON for the subject the user names. Schema: {"id":slug,"label":string,"category":"procedural|quantitative|language|symbolic|conceptual|creative|other","keywords":string[],"concepts":[{"id":slug,"label":string,"prereqs":string[] (ids),"keywords":string[],"kernel":one-sentence truth,"explain":{"worked_example":string,"analogy":string,"step_by_step":string,"socratic":string,"concise_summary":string},"items":[{"id":slug,"kind":"recall|apply|transfer|discriminate","prompt":string,"accept":string[] (short acceptable answer tokens),"distractors":[{"answers":string[],"misconception":id}],"feedback":string}],"misconceptions":[{"id":slug,"statement":string,"refutation":string}]}]}. 4 concepts, each with exactly one item of each kind, accept tokens short and unambiguous, at least one misconception per concept. Output JSON only.`,
      subject, true, 3500,
    );
    if (!out) return null;
    try { return JSON.parse(out); } catch { return null; }
  }
}

export function providerFromEnv(): Provider {
  const key = process.env.OPENAI_API_KEY;
  return key ? new OpenAIProvider(key) : new OfflineProvider();
}
