// Model provider boundary. Providers write prose and synthesise subject material.
// They never touch learner memory and never decide the teaching action.
export interface ComposePlan {
  activity: "teach" | "remediate";
  approach: string | null;
  conceptLabel: string;
  kernel: string;
  draft: string;
  domainLabel: string;
}

export interface Provider {
  name: string;
  /** Rewrite a drafted explanation for an already-decided plan. Return null to keep the draft. */
  compose(plan: ComposePlan): Promise<string | null>;
  /** Answer an open learner question briefly, grounded in the concept. Return null to use the kernel. */
  answer(question: string, ctx: { domainLabel: string; conceptLabel: string; kernel: string }): Promise<string | null>;
  /** Build a domain pack for an unknown subject. Return null if unavailable. Output is validated by the caller. */
  synthesizePack(subject: string): Promise<unknown | null>;
}
