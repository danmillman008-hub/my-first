// Domain capability contract. The core never imports a specific pack; it only
// uses this interface. Packs can be curated, synthesised by a model, or researched.
import type { Approach, ItemKind } from "../core/types";

export type GraderKind = "text" | "numeric" | "regex";

export interface Item {
  id: string;
  kind: ItemKind;
  prompt: string;
  /** acceptable answers (tokens / phrases / numbers / regex sources depending on grader) */
  accept: string[];
  grader?: GraderKind;
  tolerance?: number; // numeric grader
  /** wrong answers that reveal a specific misconception */
  distractors?: { answers: string[]; misconception: string }[];
  feedback?: string; // shown after grading (correct answer explanation)
}

export interface Misconception {
  id: string;
  statement: string; // what the learner wrongly believes
  refutation: string; // why it is wrong and what is true
}

export interface Concept {
  id: string;
  label: string;
  prereqs: string[];
  keywords: string[];
  kernel: string; // the one-sentence truth
  explain: Partial<Record<Approach, string>>; // approach-specific renderings; fall back to kernel
  items: Item[];
  misconceptions?: Misconception[];
}

export interface DomainPack {
  id: string;
  label: string;
  category: string; // e.g. procedural, quantitative, language, symbolic — for generality reporting
  keywords: string[];
  concepts: Concept[];
  source: "curated" | "model" | "research";
}

export interface GradeResult { correct: boolean; matchedMisconception: string | null }

export function normalize(s: string): string {
  return s.toLowerCase().replace(/[`"'“”‘’]/g, "").replace(/\s+/g, " ").trim();
}

function textMatch(answer: string, accept: string[]): boolean {
  const a = normalize(answer);
  return accept.some((x) => {
    const n = normalize(x);
    if (!n) return false;
    if (a === n) return true;
    // whole-token containment for short accepts, substring for longer phrases
    if (n.length <= 3) return new RegExp(`(^|[^a-z0-9$])${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^a-z0-9]|$)`).test(a);
    return a.includes(n);
  });
}

export function grade(item: Item, answer: string): GradeResult {
  const kind = item.grader ?? "text";
  let correct = false;
  if (kind === "numeric") {
    const m = answer.replace(/,/g, "").match(/-?\d+(\.\d+)?/);
    if (m) {
      const v = parseFloat(m[0]);
      correct = item.accept.some((x) => Math.abs(parseFloat(x) - v) <= (item.tolerance ?? 1e-6));
    }
  } else if (kind === "regex") {
    correct = item.accept.some((src) => new RegExp(src, "i").test(answer));
  } else {
    correct = textMatch(answer, item.accept);
  }
  let matchedMisconception: string | null = null;
  if (!correct && item.distractors) {
    for (const d of item.distractors) {
      const hit = kind === "numeric"
        ? (() => { const m = answer.replace(/,/g, "").match(/-?\d+(\.\d+)?/); return !!m && d.answers.some((x) => Math.abs(parseFloat(x) - parseFloat(m[0])) <= (item.tolerance ?? 1e-6)); })()
        : textMatch(answer, d.answers);
      if (hit) { matchedMisconception = d.misconception; break; }
    }
  }
  return { correct, matchedMisconception };
}

/** Topological order honouring prerequisites (stable for ties). */
export function conceptOrder(pack: DomainPack): Concept[] {
  const byId = new Map(pack.concepts.map((c) => [c.id, c]));
  const seen = new Set<string>();
  const out: Concept[] = [];
  const visit = (c: Concept) => {
    if (seen.has(c.id)) return;
    seen.add(c.id);
    for (const p of c.prereqs) { const pc = byId.get(p); if (pc) visit(pc); }
    out.push(c);
  };
  for (const c of pack.concepts) visit(c);
  return out;
}
