// Resolves a learner's stated subject to a DomainPack: curated → stored (model/research-built)
// → model synthesis → Wikipedia research. Built packs are application state, not learner memory.
import { PACKS, findPack } from "./packs";
import type { DomainPack } from "./types";
import type { Store } from "../core/store";
import type { Provider } from "../providers/types";
import { researchPack } from "../research";

export class DomainRegistry {
  private cache = new Map<string, DomainPack>();
  constructor(private store: Store | null, private provider: Provider | null, private allowResearch: boolean) {
    for (const p of PACKS) this.cache.set(p.id, p);
  }

  available(): string[] { return [...this.cache.values()].map((p) => p.label); }

  async byId(id: string): Promise<DomainPack | null> {
    if (this.cache.has(id)) return this.cache.get(id)!;
    const stored = this.store ? await this.store.domainPack(id) : null;
    const v = stored ? validatePack(stored) : null;
    if (v) this.cache.set(v.id, v);
    return v;
  }

  /** Only strong keyword hits count as a mention (used to detect topic switches mid-conversation). */
  async mentioned(text: string): Promise<DomainPack | null> {
    const t = text.toLowerCase();
    for (const p of [...this.cache.values()]) if (t.includes(p.label.toLowerCase()) || p.keywords.some((k) => k.length >= 5 && new RegExp(`\\b${k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`).test(t))) return p;
    return null;
  }

  async resolve(text: string, isGoal: boolean): Promise<DomainPack | null> {
    const curated = findPack(text);
    if (curated) return curated;
    for (const p of this.cache.values()) if (p.source !== "curated" && (text.toLowerCase().includes(p.label.toLowerCase()) || p.keywords.some((k) => text.toLowerCase().includes(k)))) return p;
    if (this.store) {
      for (const id of await this.store.listDomainPacks()) { const p = await this.byId(id); if (p && (text.toLowerCase().includes(p.label.toLowerCase()) || p.keywords.some((k) => text.toLowerCase().includes(k)))) return p; }
    }
    if (!isGoal) return null;
    const subject = text.replace(/\b(the|basics of|fundamentals of|how to|about)\b/gi, " ").replace(/\s+/g, " ").trim().slice(0, 80);
    if (!subject) return null;
    const fromModel = this.provider ? validatePack(await this.provider.synthesizePack(subject).catch(() => null), "model") : null;
    if (fromModel) { await this.persist(fromModel); return fromModel; }
    if (this.allowResearch && this.store) {
      const researched = validatePack(await researchPack(subject, this.store).catch(() => null), "research");
      if (researched) { await this.persist(researched); return researched; }
    }
    return null;
  }

  private async persist(p: DomainPack) { this.cache.set(p.id, p); if (this.store) await this.store.saveDomainPack(p.id, p); }
}

const KINDS = new Set(["recall", "apply", "transfer", "discriminate"]);
const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "").slice(0, 40);

/** Strict structural validation: a model may hallucinate shape; the core only accepts well-formed packs. */
export function validatePack(raw: unknown, source?: DomainPack["source"]): DomainPack | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  const label = typeof r.label === "string" ? r.label.slice(0, 60) : null;
  if (!label || !Array.isArray(r.concepts) || r.concepts.length === 0) return null;
  const id = slug(typeof r.id === "string" ? r.id : label);
  if (!id) return null;
  const concepts: DomainPack["concepts"] = [];
  for (const c0 of r.concepts.slice(0, 12)) {
    if (!c0 || typeof c0 !== "object") continue;
    const c = c0 as Record<string, unknown>;
    const clabel = typeof c.label === "string" ? c.label.slice(0, 60) : null;
    const kernel = typeof c.kernel === "string" ? c.kernel.slice(0, 400) : null;
    if (!clabel || !kernel) continue;
    const cid = slug(typeof c.id === "string" ? c.id : clabel);
    const explainRaw = (c.explain && typeof c.explain === "object" ? c.explain : {}) as Record<string, unknown>;
    const explain: Record<string, string> = {};
    for (const k of ["direct_explanation", "worked_example", "analogy", "step_by_step", "socratic", "concise_summary"]) if (typeof explainRaw[k] === "string") explain[k] = (explainRaw[k] as string).slice(0, 900);
    const items: DomainPack["concepts"][number]["items"] = [];
    for (const i0 of Array.isArray(c.items) ? c.items.slice(0, 8) : []) {
      const i = i0 as Record<string, unknown>;
      if (!i || typeof i.prompt !== "string" || !KINDS.has(String(i.kind)) || !Array.isArray(i.accept)) continue;
      const accept = i.accept.filter((a): a is string => typeof a === "string" && a.trim().length > 0).map((a) => a.slice(0, 80));
      if (!accept.length) continue;
      const distractors = Array.isArray(i.distractors) ? i.distractors.filter((d): d is { answers: string[]; misconception: string } => !!d && typeof d === "object" && Array.isArray((d as { answers?: unknown }).answers) && typeof (d as { misconception?: unknown }).misconception === "string").map((d) => ({ answers: d.answers.filter((a) => typeof a === "string"), misconception: slug(d.misconception) })) : undefined;
      items.push({ id: `${cid}-${slug(typeof i.id === "string" ? i.id : String(items.length))}`, kind: i.kind as "recall", prompt: i.prompt.slice(0, 400), accept, grader: i.grader === "numeric" ? "numeric" : "text", tolerance: typeof i.tolerance === "number" ? i.tolerance : undefined, distractors, feedback: typeof i.feedback === "string" ? i.feedback.slice(0, 300) : undefined });
    }
    if (!items.some((i) => i.kind === "recall")) continue;
    const misconceptions = Array.isArray(c.misconceptions) ? c.misconceptions.filter((m): m is { id: string; statement: string; refutation: string } => !!m && typeof m === "object" && typeof (m as { statement?: unknown }).statement === "string" && typeof (m as { refutation?: unknown }).refutation === "string").map((m) => ({ id: slug(typeof m.id === "string" ? m.id : m.statement), statement: m.statement.slice(0, 200), refutation: m.refutation.slice(0, 400) })) : [];
    concepts.push({ id: cid, label: clabel, prereqs: Array.isArray(c.prereqs) ? c.prereqs.filter((p): p is string => typeof p === "string").map(slug) : [], keywords: Array.isArray(c.keywords) ? c.keywords.filter((k): k is string => typeof k === "string").map((k) => k.toLowerCase()) : [clabel.toLowerCase()], kernel, explain, items, misconceptions });
  }
  if (!concepts.length) return null;
  const ids = new Set(concepts.map((c) => c.id));
  for (const c of concepts) c.prereqs = c.prereqs.filter((p) => ids.has(p) && p !== c.id);
  return { id, label, category: typeof r.category === "string" ? r.category : "other", keywords: [label.toLowerCase(), ...(Array.isArray(r.keywords) ? r.keywords.filter((k): k is string => typeof k === "string").map((k) => k.toLowerCase()) : [])], concepts, source: source ?? ((r.source as DomainPack["source"]) || "model") };
}
