// Curated seed packs from four substantially different categories of learning.
// They exist to exercise the general core and to give the offline provider real content.
// Unknown subjects are synthesised (model) or researched (Wikipedia) into the same shape.
import type { DomainPack } from "./types";

export const PACKS: DomainPack[] = [
  {
    id: "bash", label: "Bash", category: "procedural", source: "curated",
    keywords: ["bash", "shell", "terminal", "script", "scripting", "command line", "grep", "pipe", "linux"],
    concepts: [
      {
        id: "variables", label: "shell variables", prereqs: [], keywords: ["variable", "assign", "$"],
        kernel: "A shell variable is assigned with NAME=value (no spaces around =) and read with $NAME.",
        explain: {
          worked_example: 'name="Ada"\necho "Hello $name"   # → Hello Ada\ncount=3; echo $count   # → 3',
          analogy: "A variable is a labelled jar: NAME=value puts something in the jar, $NAME takes it out to look at it.",
          step_by_step: "1) Write the name, an equals sign and the value with no spaces: n=5. 2) Read it by prefixing a dollar sign: echo $n. 3) Wrap in braces when text follows: ${n}px.",
          socratic: "If echo count prints the word 'count', what extra character do you think tells the shell you mean the value inside?",
          concise_summary: "Assign: x=5 (no spaces). Read: $x or ${x}.",
        },
        items: [
          { id: "var-r1", kind: "recall", prompt: "How do you read the value of a variable called count?", accept: ["$count", "${count}"], distractors: [{ answers: ["count", "%count%", "count$"], misconception: "var-no-dollar" }], feedback: "Read a variable with $count (or ${count})." },
          { id: "var-a1", kind: "apply", prompt: "Write a line that stores the text hello in a variable named greeting, then a line that prints it.", accept: ["greeting=hello", 'greeting="hello"', "echo $greeting"], distractors: [{ answers: ["greeting = hello"], misconception: "var-spaces" }], feedback: 'greeting="hello"; echo "$greeting"' },
          { id: "var-t1", kind: "transfer", prompt: "A script has `dir=/tmp` and later runs `ls $dirs`. Why does it list the current directory instead of /tmp?", accept: ["dirs", "different variable", "empty", "unset", "not defined", "doesn't exist", "typo"], feedback: "$dirs is a different, unset variable; it expands to nothing, so ls gets no argument." },
          { id: "var-d1", kind: "discriminate", prompt: "Which of these prints 7: `n=7; echo n` or `n=7; echo $n`?", accept: ["echo $n", "$n", "second", "the second"], distractors: [{ answers: ["echo n", "first", "the first"], misconception: "var-no-dollar" }] },
        ],
        misconceptions: [
          { id: "var-no-dollar", statement: "the variable name alone gives its value", refutation: "The bare name is just text; the shell only substitutes a value when it sees $name. `echo n` prints n." },
          { id: "var-spaces", statement: "spaces around = are fine in assignments", refutation: "`n = 5` runs a command called n with arguments = and 5. Assignments must be n=5 with no spaces." },
        ],
      },
      {
        id: "quoting", label: "quoting", prereqs: ["variables"], keywords: ["quote", "quoting", "word splitting"],
        kernel: "Double quotes still expand $variables but keep the result as one word; single quotes are fully literal.",
        explain: {
          worked_example: 'f="my file.txt"\ncat "$f"   # one argument → works\ncat $f     # two arguments: my, file.txt → fails\necho \'$f\'  # prints $f literally',
          analogy: "Double quotes are a window: the shell can see the variables through them. Single quotes are a wall: nothing gets through.",
          step_by_step: "1) Decide if you want expansion. 2) If yes, use double quotes: \"$f\". 3) If you want the text exactly as typed, use single quotes. 4) Never leave a variable that may contain spaces unquoted.",
          socratic: "If $f holds `my file.txt`, how many arguments does `cat $f` receive? And `cat \"$f\"`?",
          concise_summary: "\"$x\" expands, one word. '$x' is literal. Bare $x splits on spaces.",
        },
        items: [
          { id: "q-r1", kind: "recall", prompt: "Which quotes still expand $variables: single or double?", accept: ["double"], distractors: [{ answers: ["single", "both", "neither"], misconception: "quotes-same" }], feedback: "Double quotes expand; single quotes are literal." },
          { id: "q-a1", kind: "apply", prompt: "Variable f holds a filename with a space. Write the safe way to cat it.", accept: ['cat "$f"', 'cat "${f}"'], distractors: [{ answers: ["cat $f"], misconception: "no-quote-needed" }, { answers: ["cat '$f'"], misconception: "quotes-same" }], feedback: 'cat "$f" keeps the name as one argument.' },
          { id: "q-t1", kind: "transfer", prompt: "`for x in $list` misbehaves when list contains a path with a space. What is happening?", accept: ["word splitting", "split", "splits", "two words", "separate words", "unquoted"], feedback: "The unquoted expansion is split on whitespace, so one path becomes two loop iterations." },
          { id: "q-d1", kind: "discriminate", prompt: "What does echo '$HOME' print: your home directory, or the text $HOME?", accept: ["text", "$HOME", "literal", "the text"], distractors: [{ answers: ["home directory", "/home", "directory", "path"], misconception: "quotes-same" }] },
        ],
        misconceptions: [
          { id: "quotes-same", statement: "single and double quotes behave the same", refutation: "They differ precisely on expansion: \"$HOME\" becomes your directory, '$HOME' stays the five characters $HOME." },
          { id: "no-quote-needed", statement: "quoting a variable is optional style", refutation: "Unquoted $f is split on whitespace and glob-expanded; with a space in the value the command receives two arguments." },
        ],
      },
      {
        id: "pipes", label: "pipes", prereqs: [], keywords: ["pipe", "|", "stdout", "stdin", "stream"],
        kernel: "A pipe | sends the standard output of one command into the standard input of the next.",
        explain: {
          worked_example: "cat access.log | grep 404 | wc -l\n# cat produces lines → grep keeps those with 404 → wc counts them",
          analogy: "A pipe is a conveyor belt between stations: each command transforms what arrives and passes it on.",
          step_by_step: "1) Run a command that prints something. 2) Add | and a command that reads input. 3) Chain more filters as needed; each only sees the previous output.",
          socratic: "grep reads from its input when given no file. Where would that input come from in `ls | grep txt`?",
          concise_summary: "a | b: a's stdout → b's stdin. Errors (stderr) are not piped.",
        },
        items: [
          { id: "p-r1", kind: "recall", prompt: "Which stream of the first command does a pipe connect to the second command's input?", accept: ["stdout", "standard output", "output"], distractors: [{ answers: ["stderr", "standard error", "error"], misconception: "pipe-stderr" }, { answers: ["file", "argument", "arguments"], misconception: "pipe-args" }], feedback: "stdout → stdin. stderr bypasses the pipe." },
          { id: "p-a1", kind: "apply", prompt: "Write a pipeline that counts the lines containing ERROR in app.log.", accept: ["grep ERROR app.log | wc -l", "grep -c ERROR app.log", "cat app.log | grep ERROR | wc -l", "| wc -l"], feedback: "grep ERROR app.log | wc -l" },
          { id: "p-t1", kind: "transfer", prompt: "`make 2>&1 | grep error` shows compiler errors but `make | grep error` does not. Why?", accept: ["stderr", "standard error", "2>&1", "redirect", "errors go to stderr"], feedback: "Compiler errors go to stderr, which a plain pipe does not carry; 2>&1 merges it into stdout first." },
          { id: "p-d1", kind: "discriminate", prompt: "Does `ls | rm` remove the files ls listed? yes or no, and why in a few words.", accept: ["no"], distractors: [{ answers: ["yes"], misconception: "pipe-args" }], feedback: "No: rm ignores stdin and takes filenames as arguments; you would need xargs." },
        ],
        misconceptions: [
          { id: "pipe-stderr", statement: "pipes carry error output too", refutation: "Only stdout flows through |. stderr goes straight to the terminal unless you redirect it with 2>&1." },
          { id: "pipe-args", statement: "a pipe passes the output as command-line arguments", refutation: "A pipe feeds standard input, not arguments. Commands that only read arguments (rm, echo) ignore it; xargs converts input into arguments." },
        ],
      },
      {
        id: "exit_codes", label: "exit codes and &&", prereqs: ["pipes"], keywords: ["exit code", "&&", "||", "$?", "status"],
        kernel: "Every command returns an exit status: 0 means success, non-zero means failure; && runs the next command only on success, || only on failure.",
        explain: {
          worked_example: "mkdir build && cd build   # cd only if mkdir succeeded\ngrep -q foo f.txt || echo 'not found'\nfalse; echo $?   # → 1",
          analogy: "Exit codes are a thumbs-up (0) or thumbs-down (anything else) each command gives; && waits for a thumbs-up before proceeding.",
          step_by_step: "1) After any command, $? holds its status. 2) 0 is success. 3) a && b runs b only if a returned 0. 4) a || b runs b only if a failed.",
          socratic: "If 0 means success, how many different ways can a command fail? What does that suggest about why non-zero is failure?",
          concise_summary: "0 = ok, non-zero = error. a && b (b if ok), a || b (b if error), $? = last status.",
        },
        items: [
          { id: "e-r1", kind: "recall", prompt: "What exit status means success?", accept: ["0", "zero"], distractors: [{ answers: ["1", "one", "true", "non-zero"], misconception: "exit-one-success" }], feedback: "0 is success; anything else signals an error." },
          { id: "e-a1", kind: "apply", prompt: "Write a one-liner that runs `npm test` and only if it succeeds runs `npm run deploy`.", accept: ["npm test && npm run deploy"], distractors: [{ answers: ["npm test || npm run deploy"], misconception: "and-or-swap" }, { answers: ["npm test ; npm run deploy", "npm test; npm run deploy"], misconception: "semicolon-conditional" }], feedback: "npm test && npm run deploy" },
          { id: "e-t1", kind: "transfer", prompt: "In a script, `grep -q root /etc/passwd || exit 1` — in plain words, what does this line do?", accept: ["exit", "exits if", "if not found", "not found", "fails", "stop the script", "missing"], feedback: "If grep finds nothing (non-zero), the script exits with status 1." },
          { id: "e-d1", kind: "discriminate", prompt: "`cmd1 ; cmd2` versus `cmd1 && cmd2`: which one runs cmd2 even when cmd1 fails?", accept: ["semicolon", ";", "first", "cmd1 ; cmd2"], distractors: [{ answers: ["&&", "second", "both"], misconception: "semicolon-conditional" }] },
        ],
        misconceptions: [
          { id: "exit-one-success", statement: "1 means true/success like in most languages", refutation: "In the shell, 0 is success because there is one way to succeed and many ways to fail; every non-zero value is a failure code." },
          { id: "and-or-swap", statement: "|| chains commands on success", refutation: "|| is the fallback operator: it runs the right side only when the left side failed. && is the success chain." },
          { id: "semicolon-conditional", statement: "; behaves like && (stops on failure)", refutation: "; is an unconditional separator; the second command runs regardless. Only && checks the exit status." },
        ],
      },
    ],
  },
  {
    id: "statistics", label: "Introductory statistics", category: "quantitative", source: "curated",
    keywords: ["statistics", "stats", "mean", "median", "standard deviation", "probability", "data analysis", "distribution"],
    concepts: [
      {
        id: "mean_median", label: "mean vs median", prereqs: [], keywords: ["mean", "median", "average", "outlier"],
        kernel: "The mean is the sum divided by the count; the median is the middle value when sorted — the median resists outliers, the mean does not.",
        explain: {
          worked_example: "Salaries 30, 32, 35, 40, 500 (thousands). Mean = 637/5 = 127.4. Median = 35. One outlier dragged the mean far above what most people earn.",
          analogy: "The mean is the balance point of a seesaw — one heavy kid far out tips it. The median is the kid sitting in the middle seat, no matter who is on the ends.",
          step_by_step: "1) Sort the values. 2) Median = middle value (or the mean of the two middle values). 3) Mean = add everything, divide by the count. 4) If they differ a lot, suspect skew or outliers.",
          socratic: "If the richest person in a town moves away, does the median income change much? Does the mean? What does that tell you?",
          concise_summary: "Mean: sum ÷ n, sensitive to outliers. Median: middle of sorted data, robust.",
        },
        items: [
          { id: "mm-r1", kind: "recall", prompt: "Which is more affected by a single extreme outlier: the mean or the median?", accept: ["mean"], distractors: [{ answers: ["median"], misconception: "median-outlier" }, { answers: ["both", "same", "equally", "neither"], misconception: "median-outlier" }], feedback: "The mean; the median only looks at the middle position." },
          { id: "mm-a1", kind: "apply", prompt: "Data: 2, 3, 3, 10, 100. What is the median?", accept: ["3"], grader: "numeric", tolerance: 0.01, distractors: [{ answers: ["23.6"], misconception: "median-is-mean" }, { answers: ["10"], misconception: "median-unsorted" }], feedback: "Sorted: 2,3,3,10,100 → middle value is 3." },
          { id: "mm-t1", kind: "transfer", prompt: "House prices in a district are reported as 'average 900k' but most homes sell near 400k. Which statistic would better describe a typical home, and why?", accept: ["median", "middle", "outliers", "skew", "expensive homes pull"], feedback: "The median: a few very expensive sales pull the mean up but leave the median near the typical price." },
          { id: "mm-d1", kind: "discriminate", prompt: "Data: 5, 1, 9. Is the median 1, 5 or 9?", accept: ["5"], grader: "numeric", tolerance: 0.01, distractors: [{ answers: ["1"], misconception: "median-unsorted" }] },
        ],
        misconceptions: [
          { id: "median-outlier", statement: "the median moves as much as the mean when an outlier appears", refutation: "The median depends only on the middle rank. Replacing the largest value with a billion changes the mean enormously and the median not at all." },
          { id: "median-is-mean", statement: "median is another word for average/mean", refutation: "They are different: the mean is computed from all values; the median is the middle of the sorted list. For 2,3,3,10,100 the mean is 23.6, the median 3." },
          { id: "median-unsorted", statement: "the median is the middle value in the order given", refutation: "You must sort first. For 5,1,9 the sorted order is 1,5,9, so the median is 5, not 1." },
        ],
      },
      {
        id: "spread", label: "standard deviation", prereqs: ["mean_median"], keywords: ["standard deviation", "variance", "spread", "sd"],
        kernel: "Standard deviation measures how far values typically sit from the mean; it is the square root of the variance and has the same units as the data.",
        explain: {
          worked_example: "Values 2, 4, 6. Mean 4. Deviations −2, 0, 2. Squares 4, 0, 4. Variance (population) = 8/3 ≈ 2.67. SD = √2.67 ≈ 1.63.",
          analogy: "Two archers both average the bullseye; the one whose arrows cluster tightly has a small standard deviation, the scattered one a large one.",
          step_by_step: "1) Compute the mean. 2) Subtract it from each value. 3) Square each difference. 4) Average the squares (variance). 5) Take the square root (SD).",
          socratic: "Two classes both average 70 on a test. What could differ between them that the average hides?",
          concise_summary: "SD = √(mean of squared deviations). Same units as data. Bigger = more spread.",
        },
        items: [
          { id: "sd-r1", kind: "recall", prompt: "Standard deviation is the square root of which quantity?", accept: ["variance"], distractors: [{ answers: ["mean", "average"], misconception: "sd-of-mean" }], feedback: "SD = √variance." },
          { id: "sd-a1", kind: "apply", prompt: "Values 1, 3, 5 have mean 3. What is the population standard deviation (to 2 decimals)?", accept: ["1.63"], grader: "numeric", tolerance: 0.02, distractors: [{ answers: ["2.67"], misconception: "sd-is-variance" }, { answers: ["2"], misconception: "sd-mean-abs" }], feedback: "Deviations −2,0,2 → squares 4,0,4 → variance 8/3 ≈ 2.67 → SD ≈ 1.63." },
          { id: "sd-t1", kind: "transfer", prompt: "Two delivery services both average 30 minutes, SDs of 2 and 15 minutes. Which one would you choose for a time-critical delivery, and why?", accept: ["2", "first", "smaller", "less variable", "consistent", "predictable"], feedback: "The SD-2 service: same average but far more predictable arrival times." },
          { id: "sd-d1", kind: "discriminate", prompt: "If every value in a data set is multiplied by 2, does the standard deviation stay the same, double, or quadruple?", accept: ["double", "doubles", "2"], distractors: [{ answers: ["quadruple", "quadruples", "4", "same", "stay"], misconception: "sd-is-variance" }] },
        ],
        misconceptions: [
          { id: "sd-is-variance", statement: "standard deviation and variance are interchangeable", refutation: "Variance is in squared units; SD is its square root, in the original units. Scaling data by 2 doubles the SD but quadruples the variance." },
          { id: "sd-of-mean", statement: "SD is computed from the mean alone", refutation: "SD needs every value: it averages the squared distances of each value from the mean." },
          { id: "sd-mean-abs", statement: "SD is the average absolute deviation", refutation: "Close cousin but not the same: SD squares deviations before averaging and then takes a root, so it weighs large deviations more." },
        ],
      },
      {
        id: "conditional", label: "conditional probability", prereqs: [], keywords: ["conditional", "given", "bayes", "base rate"],
        kernel: "P(A|B) is the probability of A among only the cases where B holds; it is generally not equal to P(B|A).",
        explain: {
          worked_example: "Of 1000 people, 10 have a disease; a test flags 9 of them and also 50 healthy people. P(disease | positive) = 9/59 ≈ 15%, even though P(positive | disease) = 90%.",
          analogy: "P(rain | clouds) and P(clouds | rain) are different questions: it rains rarely without clouds, but clouds often pass without rain.",
          step_by_step: "1) Restrict attention to the cases where the condition B is true. 2) Count how many of those also have A. 3) Divide. 4) Check: would swapping A and B change the denominator? Then the two probabilities differ.",
          socratic: "Most professional basketball players are tall. Are most tall people professional basketball players? Why not?",
          concise_summary: "P(A|B) = P(A and B) / P(B). Direction matters. Base rates matter.",
        },
        items: [
          { id: "c-r1", kind: "recall", prompt: "Is P(A|B) generally equal to P(B|A)? yes or no", accept: ["no"], distractors: [{ answers: ["yes"], misconception: "inverse-equal" }], feedback: "No — they have different denominators." },
          { id: "c-a1", kind: "apply", prompt: "1000 people, 10 sick. Test catches 9 of the sick and wrongly flags 50 healthy. What is P(sick | positive) as a percentage (nearest whole)?", accept: ["15"], grader: "numeric", tolerance: 1, distractors: [{ answers: ["90"], misconception: "inverse-equal" }, { answers: ["95", "5"], misconception: "base-rate-neglect" }], feedback: "9 true positives out of 59 positives ≈ 15%." },
          { id: "c-t1", kind: "transfer", prompt: "A spam filter catches 99% of spam. A flagged email is not necessarily 99% likely to be spam. What extra information would you need to know the real probability?", accept: ["base rate", "how much spam", "proportion", "false positive", "how often", "prior", "non-spam flagged"], feedback: "The base rate of spam and the false-positive rate on legitimate mail." },
          { id: "c-d1", kind: "discriminate", prompt: "\"90% of accidents happen near home\" — does this mean driving near home is more dangerous per mile? yes or no", accept: ["no"], distractors: [{ answers: ["yes"], misconception: "base-rate-neglect" }] },
        ],
        misconceptions: [
          { id: "inverse-equal", statement: "P(A|B) equals P(B|A)", refutation: "They divide by different totals. P(positive | sick) can be 90% while P(sick | positive) is 15% when the disease is rare." },
          { id: "base-rate-neglect", statement: "the base rate can be ignored once you know the test accuracy", refutation: "Most positives come from the large healthy group when the condition is rare; the base rate decides what a positive means." },
        ],
      },
    ],
  },
  {
    id: "spanish", label: "Spanish basics", category: "language", source: "curated",
    keywords: ["spanish", "español", "castellano", "ser", "estar", "conjugation", "vocabulary"],
    concepts: [
      {
        id: "ser_estar", label: "ser vs estar", prereqs: [], keywords: ["ser", "estar", "to be"],
        kernel: "Both mean 'to be': ser for identity and inherent traits, estar for location and temporary states.",
        explain: {
          worked_example: "Soy profesora (identity). Estoy cansada (state). El libro es rojo (trait). El libro está en la mesa (location).",
          analogy: "Ser is a passport photo — what you are. Estar is a snapshot — how or where you are right now.",
          step_by_step: "1) Ask: identity, origin, profession, permanent trait? → ser. 2) Location or a changeable state (mood, health)? → estar. 3) Check the adjective: some change meaning (aburrido: boring vs bored).",
          socratic: "'Estoy feliz' and 'soy feliz' are both grammatical. What different things might they say about the person?",
          concise_summary: "ser = what it is (DOCTOR: description, occupation, characteristic, time, origin, relation). estar = where/how it is right now.",
        },
        items: [
          { id: "se-r1", kind: "recall", prompt: "Which verb is used for location: ser or estar?", accept: ["estar"], distractors: [{ answers: ["ser"], misconception: "ser-location" }], feedback: "Estar: La casa está aquí." },
          { id: "se-a1", kind: "apply", prompt: "Fill in: 'Mi hermano ___ médico.' (ser or estar, conjugated)", accept: ["es"], distractors: [{ answers: ["está", "esta"], misconception: "estar-profession" }], feedback: "Es — professions take ser." },
          { id: "se-t1", kind: "transfer", prompt: "'La sopa está fría' vs 'la sopa es fría'. What does the second one imply that the first does not?", accept: ["always", "characteristic", "by nature", "gazpacho", "cold soup", "type of soup", "inherent", "permanent"], feedback: "With ser it is a cold soup by nature (like gazpacho); with estar it has merely gone cold." },
          { id: "se-d1", kind: "discriminate", prompt: "'Madrid ___ en España.' — es or está?", accept: ["está", "esta"], distractors: [{ answers: ["es"], misconception: "ser-location" }] },
        ],
        misconceptions: [
          { id: "ser-location", statement: "permanent locations use ser because they never change", refutation: "Location always uses estar, even for cities and buildings: Madrid está en España. Permanence is not the rule; location is." },
          { id: "estar-profession", statement: "professions use estar because jobs change", refutation: "Occupation is treated as identity: soy médico. Estar is for states and locations, not roles." },
        ],
      },
      {
        id: "present_ar", label: "present tense -ar verbs", prereqs: [], keywords: ["conjugation", "-ar", "hablar", "present"],
        kernel: "Drop -ar and add -o, -as, -a, -amos, -áis, -an for yo, tú, él/ella, nosotros, vosotros, ellos.",
        explain: {
          worked_example: "hablar → hablo, hablas, habla, hablamos, habláis, hablan. cantar → canto, cantas, canta...",
          analogy: "The stem is a plug and the endings are six sockets; every regular -ar verb fits the same six sockets.",
          step_by_step: "1) Remove -ar to get the stem (habl-). 2) Pick the ending for the person. 3) Attach: habl + as = hablas.",
          socratic: "If 'canto' means I sing and 'hablo' means I speak, what do you guess 'trabajo' means, and which ending marks 'I'?",
          concise_summary: "-ar → -o -as -a -amos -áis -an.",
        },
        items: [
          { id: "ar-r1", kind: "recall", prompt: "What is the tú (you, singular) ending for regular -ar verbs?", accept: ["-as", "as"], distractors: [{ answers: ["-es", "es"], misconception: "er-ending-on-ar" }], feedback: "-as: tú hablas." },
          { id: "ar-a1", kind: "apply", prompt: "Conjugate 'trabajar' for nosotros.", accept: ["trabajamos"], distractors: [{ answers: ["trabajan"], misconception: "person-confusion" }, { answers: ["trabajemos"], misconception: "er-ending-on-ar" }], feedback: "trabajamos" },
          { id: "ar-t1", kind: "transfer", prompt: "You meet the new verb 'nadar' (to swim). How would you say 'they swim'?", accept: ["nadan"], distractors: [{ answers: ["nadamos"], misconception: "person-confusion" }], feedback: "nadan — same pattern as hablan." },
          { id: "ar-d1", kind: "discriminate", prompt: "'Ella habl__' — a or as?", accept: ["a", "habla"], distractors: [{ answers: ["as", "hablas"], misconception: "person-confusion" }] },
        ],
        misconceptions: [
          { id: "er-ending-on-ar", statement: "-ar verbs take -es/-emos endings", refutation: "Those belong to -er verbs (comes, comemos). -ar verbs keep the a: hablas, hablamos." },
          { id: "person-confusion", statement: "-an and -amos are interchangeable plural endings", refutation: "-amos is we (nosotros), -an is they (ellos): trabajamos vs trabajan." },
        ],
      },
      {
        id: "gender", label: "noun gender and articles", prereqs: [], keywords: ["gender", "el", "la", "article", "masculine", "feminine"],
        kernel: "Nouns are masculine or feminine; -o is usually masculine (el), -a usually feminine (la), with notable exceptions like el día, la mano, el problema.",
        explain: {
          worked_example: "el libro, la casa, el día (exception), la mano (exception), el problema (Greek -ma words are masculine).",
          analogy: "Gender is like a team jersey every noun wears; the article and adjectives must wear the matching colour.",
          step_by_step: "1) Look at the ending: -o → el, -a → la as a first guess. 2) Check the exceptions list (día, mano, -ma words). 3) Match the article and adjective to the noun.",
          socratic: "'El problema' ends in -a but takes el. What might that tell you about relying on endings alone?",
          concise_summary: "-o → el, -a → la, exceptions: el día, el mapa, el problema, la mano, la foto.",
        },
        items: [
          { id: "g-r1", kind: "recall", prompt: "Which article goes with 'problema': el or la?", accept: ["el"], distractors: [{ answers: ["la"], misconception: "a-always-feminine" }], feedback: "el problema (-ma words from Greek are masculine)." },
          { id: "g-a1", kind: "apply", prompt: "Give the correct article for 'mano' (hand).", accept: ["la"], distractors: [{ answers: ["el"], misconception: "o-always-masculine" }], feedback: "la mano — a famous exception." },
          { id: "g-t1", kind: "transfer", prompt: "You see the new noun 'sistema'. Which article would you pick, and why?", accept: ["el", "-ma", "greek", "like problema"], distractors: [{ answers: ["la"], misconception: "a-always-feminine" }], feedback: "el sistema — same -ma family as problema, tema, clima." },
          { id: "g-d1", kind: "discriminate", prompt: "'día': el or la?", accept: ["el"], distractors: [{ answers: ["la"], misconception: "a-always-feminine" }] },
        ],
        misconceptions: [
          { id: "a-always-feminine", statement: "every noun ending in -a is feminine", refutation: "Most are, but el día, el mapa, el planeta and the -ma family (problema, sistema, tema) are masculine." },
          { id: "o-always-masculine", statement: "every noun ending in -o is masculine", refutation: "la mano, la foto, la moto and la radio are feminine." },
        ],
      },
    ],
  },
  {
    id: "music_theory", label: "Music theory", category: "symbolic", source: "curated",
    keywords: ["music theory", "music", "intervals", "scale", "chord", "key signature", "harmony"],
    concepts: [
      {
        id: "half_whole", label: "half and whole steps", prereqs: [], keywords: ["half step", "whole step", "semitone", "tone"],
        kernel: "A half step (semitone) is the distance between adjacent keys on a piano; a whole step is two half steps.",
        explain: {
          worked_example: "E→F is a half step (no black key between). C→D is a whole step (C# sits between). B→C is a half step.",
          analogy: "Half steps are the rungs of a ladder; a whole step is skipping one rung.",
          step_by_step: "1) Find the note on a keyboard. 2) Move to the very next key (black or white) → one half step. 3) Do it twice → one whole step.",
          socratic: "On a piano there is no black key between E and F. What does that imply about the distance between them?",
          concise_summary: "Half step = adjacent keys. Whole step = 2 half steps. Natural half steps: E–F and B–C.",
        },
        items: [
          { id: "hw-r1", kind: "recall", prompt: "How many half steps make a whole step?", accept: ["2", "two"], grader: "text", distractors: [{ answers: ["1", "one"], misconception: "whole-is-adjacent" }], feedback: "Two." },
          { id: "hw-a1", kind: "apply", prompt: "Is E to F a half step or a whole step?", accept: ["half"], distractors: [{ answers: ["whole"], misconception: "letters-equal-whole" }], feedback: "Half — there is no key between E and F." },
          { id: "hw-t1", kind: "transfer", prompt: "On a guitar, each fret is one half step. How many frets up from an open string do you go to raise the pitch a whole step?", accept: ["2", "two"], distractors: [{ answers: ["1", "one"], misconception: "whole-is-adjacent" }], feedback: "Two frets." },
          { id: "hw-d1", kind: "discriminate", prompt: "B to C: half step or whole step?", accept: ["half"], distractors: [{ answers: ["whole"], misconception: "letters-equal-whole" }] },
        ],
        misconceptions: [
          { id: "letters-equal-whole", statement: "moving one letter name is always a whole step", refutation: "E–F and B–C are only half steps; letter names are not evenly spaced." },
          { id: "whole-is-adjacent", statement: "a whole step is the next key", refutation: "The next key is a half step; a whole step skips one key." },
        ],
      },
      {
        id: "major_scale", label: "the major scale", prereqs: ["half_whole"], keywords: ["major scale", "W W H", "pattern"],
        kernel: "A major scale follows the step pattern W W H W W W H starting from the root.",
        explain: {
          worked_example: "C major: C→D (W) D→E (W) E→F (H) F→G (W) G→A (W) A→B (W) B→C (H). G major: G A B C D E F# G — the F# is needed for the last W.",
          analogy: "The pattern is a recipe; change the starting ingredient (root) and the recipe tells you which notes to sharpen or flatten.",
          step_by_step: "1) Start on the root. 2) Apply W W H W W W H. 3) Whenever a step lands on a black key, name it as a sharp or flat so each letter is used once.",
          socratic: "Starting on G and applying W W H W W W H, what happens when you reach the sixth step — is F the right size?",
          concise_summary: "Major = W W H W W W H. Half steps fall between scale degrees 3–4 and 7–8.",
        },
        items: [
          { id: "ms-r1", kind: "recall", prompt: "Between which scale degrees do the half steps fall in a major scale?", accept: ["3-4 and 7-8", "3 and 4", "7 and 8", "3-4", "third and fourth"], distractors: [{ answers: ["2-3", "2 and 3", "4-5"], misconception: "wrong-half-position" }], feedback: "3–4 and 7–8." },
          { id: "ms-a1", kind: "apply", prompt: "Which single note in the G major scale is sharp?", accept: ["f#", "f sharp", "f♯"], distractors: [{ answers: ["c#", "g#", "none"], misconception: "wrong-half-position" }], feedback: "F#." },
          { id: "ms-t1", kind: "transfer", prompt: "Apply the pattern from D. Which two notes are sharp in D major?", accept: ["f# and c#", "f#, c#", "c# and f#", "f# c#", "c# f#", "f sharp and c sharp"], feedback: "F# and C#." },
          { id: "ms-d1", kind: "discriminate", prompt: "Is the step from the 3rd to the 4th degree of a major scale a half or a whole step?", accept: ["half"], distractors: [{ answers: ["whole"], misconception: "wrong-half-position" }] },
        ],
        misconceptions: [
          { id: "wrong-half-position", statement: "the half steps sit at the same place in every scale type, or at 2–3", refutation: "In a major scale they are always 3–4 and 7–8; the minor scale moves them (2–3 and 5–6)." },
        ],
      },
      {
        id: "intervals", label: "intervals", prereqs: ["major_scale"], keywords: ["interval", "third", "fifth", "perfect", "major third", "minor third"],
        kernel: "An interval is the distance between two notes named by letter count (third, fifth) and quality (major, minor, perfect) from the half-step count.",
        explain: {
          worked_example: "C→E: 3 letters (C D E) and 4 half steps → major third. C→E♭: 3 half steps → minor third. C→G: 7 half steps → perfect fifth.",
          analogy: "The letter count is the street name, the half-step count is the house number; you need both to find the address.",
          step_by_step: "1) Count letter names inclusively → the number (C to E = 3rd). 2) Count half steps → the quality (4 = major third, 3 = minor third, 7 = perfect fifth).",
          socratic: "C→E and C→E♭ are both 'thirds'. What differs between them, and how might you name the difference?",
          concise_summary: "Number from letters; quality from half steps. M3 = 4, m3 = 3, P5 = 7, P4 = 5.",
        },
        items: [
          { id: "iv-r1", kind: "recall", prompt: "How many half steps are in a perfect fifth?", accept: ["7", "seven"], distractors: [{ answers: ["5", "five"], misconception: "number-equals-half-steps" }], feedback: "Seven." },
          { id: "iv-a1", kind: "apply", prompt: "What interval is C to E♭ (3 half steps)?", accept: ["minor third", "m3"], distractors: [{ answers: ["major third", "m3rd major"], misconception: "third-always-major" }], feedback: "Minor third." },
          { id: "iv-t1", kind: "transfer", prompt: "Name the interval from G up to D.", accept: ["perfect fifth", "fifth", "p5"], distractors: [{ answers: ["fourth", "p4"], misconception: "number-equals-half-steps" }], feedback: "Perfect fifth (7 half steps: G A B C D = 5 letters)." },
          { id: "iv-d1", kind: "discriminate", prompt: "C→E is 4 half steps and C→E♭ is 3. Which one is the major third?", accept: ["c→e", "c to e", "4", "first"], distractors: [{ answers: ["both", "either"], misconception: "third-always-major" }] },
        ],
        misconceptions: [
          { id: "number-equals-half-steps", statement: "a fifth spans five half steps", refutation: "The number counts letter names, not half steps. A perfect fifth spans 7 half steps; 5 half steps is a perfect fourth." },
          { id: "third-always-major", statement: "every third is a major third", refutation: "Thirds come in two sizes: major (4 half steps) and minor (3). C–E♭ is minor." },
        ],
      },
    ],
  },
];

export function findPack(idOrText: string): DomainPack | null {
  const t = idOrText.toLowerCase();
  const exact = PACKS.find((p) => p.id === t);
  if (exact) return exact;
  let best: { p: DomainPack; score: number } | null = null;
  for (const p of PACKS) {
    let score = 0;
    for (const k of p.keywords) if (t.includes(k)) score += k.length;
    if (score > 0 && (!best || score > best.score)) best = { p, score };
  }
  return best?.p ?? null;
}
