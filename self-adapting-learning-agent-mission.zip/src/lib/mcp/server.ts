// Minimal, dependency-free MCP (JSON-RPC 2.0 over stateless Streamable HTTP).
// Tools operate on the SAME engine and store as the UI: there is no second learner model.
import { engine } from "../runtime";

const TOOLS = [
  { name: "tutoring_turn", description: "Send a learner message and receive the tutor's reply plus a decision trace.", inputSchema: { type: "object", properties: { learnerId: { type: "string" }, message: { type: "string" } }, required: ["learnerId", "message"] } },
  { name: "get_learner_model", description: "Inspect beliefs (with status, confidence, provenance), per-concept knowledge and retention estimates, approach statistics.", inputSchema: { type: "object", properties: { learnerId: { type: "string" } }, required: ["learnerId"] } },
  { name: "challenge_belief", description: "Learner correction: retire a belief, optionally stating what is true instead.", inputSchema: { type: "object", properties: { learnerId: { type: "string" }, beliefId: { type: "string" }, replacement: { type: "string" } }, required: ["learnerId", "beliefId"] } },
];

type Rpc = { jsonrpc: "2.0"; id?: string | number | null; method: string; params?: Record<string, unknown> };

export async function handleRpc(msg: Rpc): Promise<unknown> {
  const reply = (result: unknown) => ({ jsonrpc: "2.0", id: msg.id ?? null, result });
  const error = (code: number, message: string) => ({ jsonrpc: "2.0", id: msg.id ?? null, error: { code, message } });
  switch (msg.method) {
    case "initialize": return reply({ protocolVersion: "2025-03-26", capabilities: { tools: {} }, serverInfo: { name: "private-learning-agent", version: "1.0.0" } });
    case "notifications/initialized": return null;
    case "ping": return reply({});
    case "tools/list": return reply({ tools: TOOLS });
    case "tools/call": {
      const name = String(msg.params?.name ?? "");
      const args = (msg.params?.arguments ?? {}) as Record<string, unknown>;
      const learnerId = typeof args.learnerId === "string" && /^[a-zA-Z0-9_-]{6,80}$/.test(args.learnerId) ? args.learnerId : null;
      if (!learnerId) return error(-32602, "learnerId (6-80 chars, [a-zA-Z0-9_-]) required");
      const text = (o: unknown) => reply({ content: [{ type: "text", text: JSON.stringify(o) }] });
      if (name === "tutoring_turn") { if (typeof args.message !== "string") return error(-32602, "message required"); return text(await engine().turn(learnerId, args.message)); }
      if (name === "get_learner_model") return text(await engine().model(learnerId));
      if (name === "challenge_belief") { if (typeof args.beliefId !== "string") return error(-32602, "beliefId required"); return text(await engine().challengeBelief(learnerId, args.beliefId, typeof args.replacement === "string" ? args.replacement : null)); }
      return error(-32601, `unknown tool ${name}`);
    }
    default: return error(-32601, `method not found: ${msg.method}`);
  }
}
