// Single engine instance for the app: one canonical learner state shared by HTTP and MCP.
import { Engine } from "./core/engine";
import { DomainRegistry } from "./domain/registry";
import { providerFromEnv } from "./providers";
import { PgStore } from "./store/pg";

const g = globalThis as typeof globalThis & { __palEngine?: Engine };
export function engine(): Engine {
  if (!g.__palEngine) {
    const store = new PgStore();
    const provider = providerFromEnv();
    g.__palEngine = new Engine({ store, provider, domains: new DomainRegistry(store, provider, process.env.RESEARCH_ENABLED !== "0") }, { seed: Date.now() % 1_000_000 });
  }
  return g.__palEngine;
}

/** Private identity: an opaque cookie. No account, no PII. */
export function learnerIdFrom(req: Request, explicit?: string | null): { id: string; setCookie: string | null } {
  if (explicit && /^[a-zA-Z0-9_-]{6,80}$/.test(explicit)) return { id: explicit, setCookie: null };
  const cookie = req.headers.get("cookie") ?? "";
  const m = /(?:^|;\s*)pal_learner=([a-zA-Z0-9_-]{6,80})/.exec(cookie);
  if (m) return { id: m[1], setCookie: null };
  const id = `l_${crypto.randomUUID().replace(/-/g, "").slice(0, 20)}`;
  return { id, setCookie: `pal_learner=${id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${60 * 60 * 24 * 365 * 3}` };
}
