"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import type { LearnerModelView, Trace } from "@/lib/core/types";

interface Msg { role: "learner" | "tutor"; text: string; trace?: Trace }

export default function Tutor() {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [model, setModel] = useState<LearnerModelView | null>(null);
  const [tab, setTab] = useState<"beliefs" | "knowledge" | "trace">("knowledge");
  const [showRetired, setShowRetired] = useState(false);
  const bottom = useRef<HTMLDivElement>(null);

  const refresh = useCallback(async () => { try { const r = await fetch("/api/memory"); if (r.ok) setModel(await r.json()); } catch { /* offline */ } }, []);
  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => { bottom.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  const send = async (text: string) => {
    if (!text.trim() || busy) return;
    setBusy(true); setInput("");
    setMsgs((m) => [...m, { role: "learner", text }]);
    try {
      const r = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ message: text }) });
      const data = await r.json();
      setMsgs((m) => [...m, { role: "tutor", text: data.reply ?? data.error ?? "…", trace: data.trace }]);
      if (data.trace) setTab((t) => (t === "trace" ? t : t));
      await refresh();
    } catch { setMsgs((m) => [...m, { role: "tutor", text: "Network error — nothing was lost." }]); }
    finally { setBusy(false); }
  };

  const challenge = async (beliefId: string) => {
    const replacement = window.prompt("What is true instead? (optional)") ?? "";
    await fetch("/api/memory", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ beliefId, replacement }) });
    await refresh();
  };

  const lastTrace = [...msgs].reverse().find((m) => m.trace)?.trace ?? null;
  const visibleBeliefs = (model?.beliefs ?? []).filter((b) => showRetired || b.status !== "retired");

  return (
    <div className="mx-auto grid max-w-7xl grid-cols-1 gap-4 p-4 lg:grid-cols-[1fr_420px]">
      <section className="flex h-[calc(100vh-2rem)] flex-col rounded-2xl border border-slate-200 bg-white shadow-sm">
        <header className="border-b border-slate-100 px-5 py-3">
          <h1 className="text-lg font-semibold">Your tutor</h1>
          <p className="text-xs text-slate-500">One continuous relationship. Say what you want to learn, answer the checks, push back whenever something is not true about you.</p>
        </header>
        <div className="flex-1 space-y-3 overflow-y-auto px-5 py-4">
          {msgs.length === 0 && (
            <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-600">
              <p className="mb-2 font-medium text-slate-800">Try:</p>
              <div className="flex flex-wrap gap-2">
                {["I want to learn Bash", "Teach me introductory statistics", "I want to learn Spanish, I already know ser vs estar", "I'd like to learn music theory"].map((s) => (
                  <button key={s} onClick={() => send(s)} className="rounded-full border border-slate-300 bg-white px-3 py-1 text-xs hover:bg-slate-100">{s}</button>
                ))}
              </div>
            </div>
          )}
          {msgs.map((m, i) => (
            <div key={i} className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${m.role === "learner" ? "ml-auto bg-slate-900 text-white" : "bg-slate-100 text-slate-900"}`}>
              {m.text.split(/(\*\*[^*]+\*\*)/g).map((part, j) => part.startsWith("**") ? <strong key={j}>{part.slice(2, -2)}</strong> : <span key={j}>{part}</span>)}
              {m.trace && <div className="mt-2 border-t border-slate-200 pt-1 text-[11px] text-slate-500">{m.trace.decision.activity}{m.trace.decision.approach ? ` · ${m.trace.decision.approach.replace(/_/g, " ")}` : ""}{m.trace.decision.concept ? ` · ${m.trace.decision.concept}` : ""} — {m.trace.decision.reasons[m.trace.decision.reasons.length - 1]}</div>}
            </div>
          ))}
          <div ref={bottom} />
        </div>
        <form onSubmit={(e) => { e.preventDefault(); void send(input); }} className="flex gap-2 border-t border-slate-100 p-3">
          <input value={input} onChange={(e) => setInput(e.target.value)} placeholder={busy ? "Thinking…" : "Type your answer, a question, or a correction…"} disabled={busy} className="flex-1 rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-slate-500" />
          <button disabled={busy} className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50">Send</button>
        </form>
      </section>

      <aside className="flex h-[calc(100vh-2rem)] flex-col rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="flex border-b border-slate-100 text-sm">
          {(["knowledge", "beliefs", "trace"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`flex-1 px-3 py-2.5 capitalize ${tab === t ? "border-b-2 border-slate-900 font-medium" : "text-slate-500"}`}>{t === "trace" ? "This turn" : t === "beliefs" ? "What it believes" : "What you know"}</button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto p-4 text-sm">
          {tab === "knowledge" && (
            <div className="space-y-2">
              {!model?.knowledge.length && <p className="text-slate-500">Nothing yet. Once you start, each concept shows what has been demonstrated (not what you were told), an estimate of what you still retain, and when it is due for review.</p>}
              {model?.knowledge.map((k) => (
                <div key={`${k.domain}/${k.concept}`} className="rounded-xl border border-slate-100 p-3">
                  <div className="flex items-center justify-between"><span className="font-medium">{k.label}</span><span className={`rounded-full px-2 py-0.5 text-[11px] ${k.stage === "mastered" ? "bg-emerald-100 text-emerald-800" : k.stage === "untaught" ? "bg-slate-100 text-slate-600" : "bg-amber-100 text-amber-800"}`}>{k.stage}</span></div>
                  <div className="mt-2 h-1.5 w-full rounded bg-slate-100"><div className="h-1.5 rounded bg-slate-800" style={{ width: `${Math.round(k.retained * 100)}%` }} /></div>
                  <div className="mt-1 flex flex-wrap gap-x-3 text-[11px] text-slate-500">
                    <span>{k.domain}</span>
                    <span>retained ≈ {Math.round(k.retained * 100)}%</span>
                    <span>basis: {k.basis}</span>
                    <span>{k.successes}/{k.attempts} checks</span>
                    {k.nextReviewInDays != null && <span>review in {k.nextReviewInDays < 1 ? "<1" : Math.round(k.nextReviewInDays)}d</span>}
                    {k.claimedLevel != null && <span>you said: {k.claimedLevel >= 1 ? "know it" : "don't know it"}</span>}
                  </div>
                </div>
              ))}
              {!!model?.approachStats.length && (
                <div className="mt-4">
                  <p className="mb-1 text-xs font-medium uppercase tracking-wide text-slate-500">How explanations land (attributed outcomes)</p>
                  {model.approachStats.sort((a, b) => b.mean - a.mean).map((s) => <div key={`${s.domain}/${s.approach}`} className="flex justify-between text-xs text-slate-600"><span>{s.domain} · {s.approach.replace(/_/g, " ")}</span><span>{s.mean >= 0 ? "+" : ""}{s.mean.toFixed(2)} (n≈{s.weight.toFixed(1)})</span></div>)}
                </div>
              )}
            </div>
          )}
          {tab === "beliefs" && (
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-xs text-slate-500"><input type="checkbox" checked={showRetired} onChange={(e) => setShowRetired(e.target.checked)} /> show retired beliefs (history)</label>
              {!visibleBeliefs.length && <p className="text-slate-500">No beliefs about you yet. Beliefs are inferred from evidence, hold a status and a confidence, and can always be challenged.</p>}
              {visibleBeliefs.map((b) => (
                <div key={b.id} className={`rounded-xl border p-3 ${b.status === "retired" ? "border-slate-100 opacity-60" : "border-slate-200"}`}>
                  <div className="flex items-start justify-between gap-2">
                    <div><span className="text-[10px] uppercase tracking-wide text-slate-400">{b.kind.replace(/_/g, " ")} · {b.source}{b.domain ? ` · ${b.domain}` : " · general"}</span><p className="font-medium">You {b.statement}</p></div>
                    <span className={`shrink-0 rounded-full px-2 py-0.5 text-[11px] ${b.status === "active" ? "bg-emerald-100 text-emerald-800" : b.status === "contested" ? "bg-amber-100 text-amber-800" : b.status === "retired" ? "bg-slate-100 text-slate-500" : "bg-slate-100 text-slate-600"}`}>{b.status}</span>
                  </div>
                  <div className="mt-1 text-[11px] text-slate-500">confidence {Math.round(b.confidence * 100)}% · influence {b.influence.toFixed(2)} · {b.supportCount} for / {b.contradictionCount} against{b.invalidReason ? ` · retired: ${b.invalidReason}` : ""}</div>
                  {!!b.evidence.length && <details className="mt-1 text-[11px] text-slate-500"><summary className="cursor-pointer">evidence ({b.evidence.length})</summary><ul className="mt-1 list-disc pl-4">{b.evidence.slice(-6).map((e, i) => <li key={i}><span className="font-medium">{e.relation}</span>: {e.content}</li>)}</ul></details>}
                  {b.status !== "retired" && <button onClick={() => challenge(b.id)} className="mt-2 rounded-lg border border-slate-300 px-2 py-1 text-[11px] hover:bg-slate-50">That&apos;s not true about me</button>}
                </div>
              ))}
            </div>
          )}
          {tab === "trace" && (
            <div className="space-y-3 text-xs">
              {!lastTrace && <p className="text-slate-500">After each turn this shows what the tutor observed, what it inferred, why it chose this activity and approach, and what changed in memory.</p>}
              {lastTrace && (<>
                <Block title="Observed" items={lastTrace.observed} empty="nothing new" />
                <Block title="Inferred" items={lastTrace.inferred} empty="no inference this turn" />
                {lastTrace.attribution && <div><p className="font-medium text-slate-700">Attributed to the previous explanation</p><p className="text-slate-600">outcome {lastTrace.attribution.outcome.toFixed(2)} (weight {lastTrace.attribution.weight.toFixed(2)}): {lastTrace.attribution.reasons.join("; ")}</p></div>}
                <div><p className="font-medium text-slate-700">Decision</p><p className="text-slate-600">{lastTrace.decision.activity}{lastTrace.decision.approach ? ` · ${lastTrace.decision.approach.replace(/_/g, " ")}` : ""}{lastTrace.decision.concept ? ` · ${lastTrace.decision.concept}` : ""}</p><ul className="list-disc pl-4 text-slate-600">{lastTrace.decision.reasons.map((r, i) => <li key={i}>{r}</li>)}</ul></div>
                <Block title="Changed in memory" items={lastTrace.changes} empty="nothing changed" />
              </>)}
            </div>
          )}
        </div>
        <footer className="border-t border-slate-100 px-4 py-2 text-[11px] text-slate-400">Private: identity is an opaque cookie; research about subjects never becomes a fact about you. {model ? `${model.sessions} session${model.sessions === 1 ? "" : "s"}.` : ""}</footer>
      </aside>
    </div>
  );
}

function Block({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return <div><p className="font-medium text-slate-700">{title}</p>{items.length ? <ul className="list-disc pl-4 text-slate-600">{items.map((x, i) => <li key={i}>{x}</li>)}</ul> : <p className="text-slate-400">{empty}</p>}</div>;
}
