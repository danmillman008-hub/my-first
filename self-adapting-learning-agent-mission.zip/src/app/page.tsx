import Tutor from "@/components/Tutor";
export default function Page() { return <main className="min-h-screen bg-slate-100"><Tutor /></main>; }
