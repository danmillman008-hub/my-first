import { engine, learnerIdFrom } from "@/lib/runtime";
export const dynamic = "force-dynamic";

/** Inspect the learner model. */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const { id, setCookie } = learnerIdFrom(req, url.searchParams.get("learnerId"));
  const view = await engine().model(id);
  const res = Response.json(view);
  if (setCookie) res.headers.set("set-cookie", setCookie);
  return res;
}

/** "That's not true about me": retire a belief (optionally stating what is true instead). */
export async function POST(req: Request) {
  let body: { beliefId?: unknown; replacement?: unknown; learnerId?: unknown } = {};
  try { body = await req.json(); } catch { /* empty */ }
  if (typeof body.beliefId !== "string") return Response.json({ error: "beliefId required" }, { status: 400 });
  const { id } = learnerIdFrom(req, typeof body.learnerId === "string" ? body.learnerId : null);
  const out = await engine().challengeBelief(id, body.beliefId, typeof body.replacement === "string" && body.replacement.trim() ? body.replacement.trim().slice(0, 200) : null);
  return Response.json(out);
}
