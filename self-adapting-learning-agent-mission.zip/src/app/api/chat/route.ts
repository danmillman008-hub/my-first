import { engine, learnerIdFrom } from "@/lib/runtime";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  let body: { message?: unknown; learnerId?: unknown } = {};
  try { body = await req.json(); } catch { /* empty */ }
  const message = typeof body.message === "string" ? body.message.trim() : "";
  if (!message) return Response.json({ error: "message required" }, { status: 400 });
  const { id, setCookie } = learnerIdFrom(req, typeof body.learnerId === "string" ? body.learnerId : null);
  try {
    const result = await engine().turn(id, message);
    const res = Response.json({ learnerId: id, ...result });
    if (setCookie) res.headers.set("set-cookie", setCookie);
    return res;
  } catch (e) {
    console.error("[chat]", e);
    return Response.json({ error: "The tutor hit an internal error. Your memory is intact; please try again." }, { status: 500 });
  }
}
