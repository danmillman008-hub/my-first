import { handleRpc } from "@/lib/mcp/server";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const token = process.env.MCP_TOKEN;
  if (token && req.headers.get("authorization") !== `Bearer ${token}`) return new Response("unauthorized", { status: 401 });
  let body: unknown;
  try { body = await req.json(); } catch { return Response.json({ jsonrpc: "2.0", id: null, error: { code: -32700, message: "parse error" } }, { status: 400 }); }
  const msgs = Array.isArray(body) ? body : [body];
  const out = (await Promise.all(msgs.map((m) => handleRpc(m)))).filter((x) => x !== null);
  if (!out.length) return new Response(null, { status: 202 });
  return Response.json(Array.isArray(body) ? out : out[0]);
}
export async function GET() { return new Response("MCP endpoint: POST JSON-RPC 2.0 messages here.", { status: 405 }); }
