# Final architecture

**One learner. One continuous tutor. Two separate adaptation problems, kept separate.**

```
learner message
  │
  ├─ perceive        deterministic signals: reaction, request, self-report, correction, goal,
  │                  question-vs-answer (regex safety net; a provider may only add, never override)
  ├─ session         inferred from a 45-min gap; first message of a new session is never attributed
  ├─ domain          curated pack → stored pack → model-synthesised pack (validated) → Wikipedia research
  ├─ observe         append-only observations, deduped per session (short-term memory)
  ├─ grade           the previous turn's item, by id  → knowledge state (BKT + stability), misconception hypothesis
  ├─ attribute       the previous *explanation*, by id → approach outcome (down-weighted for mastery confounds)
  ├─ revise          beliefs: support / contradict / retire (correction), tendency & approach-fit derivation
  ├─ DECIDE  ┌─ Activity  (WHAT)  deterministic learning-loop controller
  │          │     review-due? → misconception (≥2 signs)? → verify claim? → teach → check → apply → transfer → next
  │          └─ Approach  (HOW)   discounted UCB+ε bandit, per domain, belief-shifted prior, other-domain prior
  ├─ compose         templates from the pack; provider may rewrite prose for an already-decided plan
  └─ trace           observed · inferred · attribution · decision reasons · memory changes  (UI "This turn", MCP)
```

## Why two decision layers

The previous synthesis (and 16 archives before it) had one adaptive layer: *how to explain*. Its own README admitted the lab "measures the adaptation machinery, not learning". This architecture adds an orthogonal layer, *what to do next*, driven by evidence about the learner's knowledge rather than by their reactions. The split is what lets the lab measure **teaching adaptation** (best-approach rate, understood rate) and **learning** (hidden knowledge gain, retention after a gap, transfer, misconceptions remaining) as separate quantities — and the result was instructive: the bandit moves the first family of metrics and barely the second (see EVALUATION.md).

## Layers and their responsibilities

| Layer | Files | Owns |
| --- | --- | --- |
| Types | `src/lib/core/types.ts` | observations, beliefs (bi-temporal, provenance), knowledge states, calibration, turns, traces, ablation flags |
| Epistemics (pure) | `src/lib/core/epistemics.ts` | belief lifecycle `candidate→active→contested→retired` (+ read-time dormancy), capped confidence, BKT, stability-based forgetting curve, claim-vs-behaviour discrepancy, review-outcome calibration, attribution |
| Approach bandit (pure) | `src/lib/core/bandit.ts` | per-arm discounting (γ=0.9), wall-clock decay, other-domain hierarchical prior (≤4 pseudo-obs), belief-shifted priors, UCB+ε, evidence-gated hysteresis, change detector |
| Perception (pure) | `src/lib/core/perceive.ts` | text → flags. Never classifies the person |
| Engine | `src/lib/core/engine.ts` | the loop above; `turn()`, `model()`, `challengeBelief()` |
| Store boundary | `src/lib/core/store.ts` (interface + in-memory), `src/lib/store/pg.ts` (Drizzle) | the only code that touches storage; same engine runs in the app and in the lab |
| Domain capability | `src/lib/domain/types.ts` (contract + graders), `packs.ts` (4 curated packs), `registry.ts` (resolution + strict validation) | concepts with prerequisites, per-approach explanation kernels, items by loop stage (`recall / apply / transfer / discriminate`), misconception-tagged distractors, refutations, pluggable graders (`text`, `numeric`, `regex`) |
| Research | `src/lib/research/index.ts` | Wikipedia → pack shape, cached in `research_cache` (no learner_id column by design) |
| Providers | `src/lib/providers/` | `OfflineProvider` (deterministic), `OpenAIProvider` (OpenAI-compatible `fetch`, JSON mode, timeouts, every failure falls back) |
| HTTP / MCP / UI | `src/app/api/{chat,memory,mcp,health}`, `src/lib/mcp/server.ts`, `src/components/Tutor.tsx` | one engine instance; MCP tools call the same engine — there is no second learner model |
| Lab | `scripts/lab/{harness,run,adversarial,debug}.ts` | hidden-ground-truth learners, ablations, adversarial regression suite |
| Tests | `tests/core.test.ts` | pure-core unit tests |

## The learner model

Three epistemic channels are never merged:

1. **Observations** — what happened, verbatim-ish, append-only, deduped per session. An observation can stay an observation forever.
2. **Knowledge states** (per learner × domain × concept) — the *behaviour* channel (`pKnown` from BKT, `stability` in days, apply/transfer counters, `basis ∈ prior|claimed|demonstrated`) kept apart from the *self-report* channel (`claimedLevel`). A claim sets a prior only while nothing has been demonstrated; it never overrides behaviour. Retention is computed **on read** as `pKnown · 2^(−days/stability)`; nothing decays into oblivion.
3. **Beliefs** — revisable statements about the learner: `preference`, `approach_fit`, `tendency`, `misconception`, `goal`, `context`. Each has `source ∈ stated|inferred`, polarity, status, capped confidence (inferred ≤ 0.92: never a verdict), support/contradiction counts, distinct supporting sessions, scope (domain or general), `validFrom / invalidAt / invalidReason / supersededBy`, and evidence edges to observations (`supports | contradicts | correction`).

**Present beats past.** Selection order is: explicit request this turn → beliefs and bandit posteriors (discounted, recency-weighted, dormancy on read). Inferred beliefs need ≥2 supports across ≥2 sessions (or ≥3) to become active. Opposite evidence contests before it retires; retired beliefs stay inspectable. A correction retires the belief immediately, records a `correction` edge, may link a superseding stated belief, and blocks re-derivation of the same inferred belief for 14 days — after that, only evidence recorded *after* the correction can rebuild it.

**Misconceptions are beliefs**, not a separate subsystem: a distractor hit creates a `candidate` misconception hypothesis scoped to domain + concept; a second independent sign triggers remediation (refutation + a discriminating item); correct discriminating answers contradict and eventually retire it. The same lifecycle, provenance and UI apply.

## The learning loop controller (WHAT)

Deterministic, per turn, given the focus concept's knowledge state and the session so far:

1. **Spaced review** — a demonstrated concept from an earlier session whose predicted recall < 0.7 is reviewed first; reviews are interleaved (never two in a row, never right after a fresh explanation).
2. **Remediation** — ≥2 signs of a specific misconception on the focus concept.
3. **Verify a claim** — "I already know X" gets a quick check before anything is skipped.
4. **Stage machine** — untaught → `teach` (+ recall check) → correct → `apply` → correct → `transfer` → correct → **mastered**, move on in prerequisite order. A miss re-teaches (the bandit re-selects the approach with the miss as evidence); an unanswered check is re-posed; too many failures park the concept for the session instead of looping.
5. **Open questions** are answered (`converse`) while keeping the pending check open.

Every non-conversational turn produces gradeable evidence. This is deliberate: the classic "learner asks → AI explains" loop produces no evidence of learning, and the `no_loop` ablation quantifies what that costs.

## The approach bandit (HOW)

Six approaches (`direct_explanation, worked_example, analogy, step_by_step, socratic, concise_summary`). `hands_on_task` from the previous taxonomy was removed: practice is a loop *stage*, not an explanation *style*. Only `teach`/`remediate` turns credit an approach; task results count at half weight, quarter weight when the concept was unknown (failure) and minimal weight when it was already known (success). UCB+ε over discounted per-arm posteriors, with hysteresis gated on strong evidence and a two-strong-failures change detector (retained from the previous synthesis where it beat Thompson twice).

## Domain generality

The core imports nothing from any pack. A domain is a `DomainPack` (validated shape) plus graders. Four curated packs span procedural (Bash), quantitative (statistics — numeric grader), language (Spanish), and symbolic (music theory); unknown subjects are synthesised by the model or researched from Wikipedia into the same shape. The lab reports metrics by category (EVALUATION.md) — the loop and the epistemics behave comparably across all four; the bandit's late best-rate varies more (0.41–0.70), which is a sample-size effect of few explanation turns, not a domain effect.

## Privacy boundaries

Learner data (observations, beliefs, knowledge, turns) · application state (packs, research cache — no learner id) · model output (prose only, for an already-decided plan) · evaluation data (in-memory, synthetic). Identity is an opaque cookie. The provider receives only the current message/concept text; research requests carry only the subject string.

## What was rejected, and why

- **Concept graph as the primary store** (4 archives) — retrieval/invalidation got harder, no measured gain. Kept only prerequisite edges inside packs.
- **Curriculum + affect engines** dominating the code — no measured adaptation gain in the archives; not rebuilt.
- **Thompson sampling** — lost to UCB+ε in two independent harnesses; not re-run here.
- **Batch consolidation pass** — second code path, latency; consolidation is per turn and deterministic.
- **Calibration on by default** — implemented, unit-tested, *neutral* in simulation → opt-in (`LEARNER_CALIBRATION=1`).
- **Remediation on one sign** — traced to false remediation loops from guesses; requires two.
- **`hands_on_task` as a style** — folded into the `apply` stage.
