# Research synthesis

What was investigated, what the evidence says, and which findings materially changed the system. This is an engineering document: every finding ends in a decision.

## 1. Forensics of the previous work

### The current repository (snapshot: `synthesize-self-adapting-learning-agent.zip` in the archive)
A serious synthesis of 16 archived attempts: pure storage-agnostic core, bi-temporal beliefs with provenance, correction semantics, attribution by tutor-turn id, discounted UCB+ε bandit, 14 synthetic archetypes, ablations, 26 adversarial checks. Its own README states the decisive limitation: *"The synthetic reaction model … measures the adaptation machinery, not learning."* There is no retrieval, no spacing, no application/transfer, no misconception model, no retention measurement, and the concept graph was dropped entirely.

**Retained (with evidence):** belief lifecycle and confidence caps; separate self-report vs behaviour channels; attribution rules incl. the mastery confound; correction semantics ("the correction sentence is never a request"; block re-derivation); domain-scoped fit beliefs with zero out-of-domain influence; other-domain hierarchical prior; UCB+ε over Thompson (two independent replications); session inference from time; research isolation.

**Discarded:** `hands_on_task` as an explanation style; probing (neutral-to-negative in its own table); calibration-free retention; the assumption that "understood" is the outcome to optimise.

### The archive (`my-first`)
16 zips; two exact duplicates, one unrelated game, one conventional LMS. Repeated survivors across attempts: append-only evidence + mutable beliefs; self-report as prior, never as evidence; present request > memory; domain scoping. Repeated failures: graph-as-primary-store; curriculum/affect engines that grew without measured benefit; Thompson under-exploiting; single global style ladders; forced-choice probes becoming standing orders. The root README's attempt had BKT, prerequisite graphs and misconception-tagged exercises — good ideas that were later thrown out *together with* the over-built curriculum engine. This work recovers the ideas without the engine.

## 2. Learning-science evidence used

Sources consulted during this work (meta-analyses and reviews; effect sizes are Hedges' g unless noted):

| Mechanism | Evidence | Confidence | Decision |
| --- | --- | --- | --- |
| Retrieval practice (testing effect) | Rowland 2014: g≈0.50 (159 effects); Adesope et al. 2017: g≈0.61; robust in classrooms; feedback increases the benefit; also improves metacognitive calibration | High, **but domain-dependent**: a 2025 meta-analysis on mathematics found g=0.18 with CI crossing zero | Every teaching turn ends with a recall check; feedback always given. Because the effect is not universal, the lab includes a `retrieval_insensitive` learner and the mechanism is measured, not assumed |
| Spacing | g≈0.7 (Latimier et al. 2021 review: 0.71–0.74 for spaced vs massed retrieval); **expanding vs uniform schedules equivalent (g=0.03)**; longer gaps → harder retrieval → better delayed retention | High | Simple threshold scheduler on predicted recall (no expanding-interval machinery); reviews interleaved. Result in simulation: small-to-neutral (see EVALUATION.md) |
| Desirable difficulty / retrieval effort | Harder successful retrieval → larger benefit; diminishing returns beyond criterion | Medium-high | Stability gain scales with (1 − predicted recall) at retrieval; review threshold 0.7 rather than "review everything" |
| Retrieval does **not** improve higher-order / transfer performance by itself | Multiple experiments (2018–2020) show superior retention without better question generation or transfer | Medium | Transfer is a separate loop stage with distinct items; measured separately |
| Application / varied practice → transfer | Standard finding in transfer literature (varied examples, application in new contexts) | Medium | `apply` then `transfer` stages; hidden transfer strength in the lab grows with application practice |
| Misconception remediation via refutation | Refutation texts outperform standard expository text for conceptual change | Medium-high | `remediate` activity: name the wrong idea, why it fails, correct idea, then a discriminating item. Requires two signs (one distractor hit is often a guess) |
| Self-report vs performance | Learners' judgements of learning are poorly calibrated; retrieval improves calibration | High | Claims are priors only; "verify before skipping"; durable claim/behaviour gaps become revisable `tendency` beliefs |
| Learning-style matching | Repeatedly unsupported as a *learning* mechanism | High (negative) | Approach adaptation is framed as interaction fit and measured against learning separately. The lab reproduced the distinction: adaptation raised understood-rate, not retention |

## 3. Engineering research

- **Knowledge tracing.** BKT is simple, interpretable and sufficient for per-concept p(known); deep KT would add opacity without a data regime to justify it. Forgetting is modelled as a half-life on read (as in half-life regression / FSRS-style schedulers) rather than as a BKT extension, so stability is inspectable and calibratable.
- **Bandits.** Non-stationarity handled by per-arm discounting; wall-clock decay floors at 0.35 so old evidence never vanishes. Thompson vs UCB: UCB+ε won in two independent harnesses; discount-capped counts keep Thompson posteriors wide.
- **Attribution.** Outcomes are attributed by *id* to the immediately preceding tutor turn, only within a session, and only for explanation activities. The alternative (crediting whatever happened after) was the source of several archive failures.
- **LLM boundary.** Providers write prose for an already-decided plan and synthesise subject material into a strictly validated shape. No invariant depends on model output; any failure falls back to templates.
- **MCP.** Kept minimal and stateless; tools call the same engine so no parallel learner model can diverge.

## 4. Findings that changed the design during the work

1. A single distractor hit triggered remediation loops on guesses → **two independent signs** rule.
2. Reactions and answers co-occur in one message → perception strips the reaction and grades the remainder.
3. Requests phrased as questions were treated as Q&A → requests take precedence.
4. A just-mastered concept was re-taught (flag applied after selection) → exclusion in `nextConcept`.
5. The first hidden forgetting model was harsher than any published spaced-retrieval data → half-life growth set to ≈×1.5–2.2 per successful retrieval (documented assumption).
6. Correction with a replacement clause picked the wrong target → target parsed from text before the replacement clause.
7. Calibration was neutral → opt-in.

## 5. Open questions

- Whether the six-approach taxonomy is right for humans; whether a real learner's "understood" is as informative as the simulated one.
- Real effect of the review scheduler at horizons of months.
- Whether item-level graders (text/numeric/regex) are enough for open-ended domains without a model grader — the provider hook exists, the evaluation does not.
- Whether misconception distractors can be synthesised reliably by a model for arbitrary subjects (schema is validated; pedagogical quality is not).
