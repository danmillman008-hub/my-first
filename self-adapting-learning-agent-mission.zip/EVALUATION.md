# Evaluation

## What is being measured, and what is not

The lab drives the **real engine** (in-memory store, offline provider, fixed seeds) with synthetic learners whose ground truth is hidden from the tutor. The tutor only sees text; the learner only sees the tutor's text and the posed question (exactly what the UI shows).

**The hidden learner model encodes assumptions** — successful retrieval strengthens memory (more when effortful), corrective feedback teaches, refutation clears misconceptions better than re-explanation, application practice builds transfer, explanations land better when they match a hidden per-domain affinity. Therefore the lab answers: *does the tutor exploit such regularities correctly, robustly, across learner types and domains, without the memory failure modes of earlier attempts?* It does **not** show that any human learns more. Nothing below is a claim about people.

## Setup

- `npm run lab` → `scripts/lab/run.ts --seeds=3` (defaults: 6 sessions × 8 turns, 3-day gaps unless the archetype says otherwise, hidden final assessment 7 days after the last session). Fully deterministic per seed; configuration and every per-learner report are written to `lab/out/summary.json`.
- 18 archetypes across 4 domain categories: `example_lover` (bash), `theory_direct` (statistics), `socratic_fan` (music), `analogy_language` (spanish), `context_dependent` (bash≠statistics), `drifter` (preference flips at session 2), `overconfident`, `underconfident`, `noisy` (35% flipped reactions), `silent` (rarely says how it landed), `switcher` (3 domains), `long_gap` (21 days), `corrector` (scripted "that's not true about me"), `fast_forgetter`, `slow_forgetter`, `retrieval_insensitive` (testing barely helps), `misconception_prone` (90% of concepts start wrong), `low_transfer`.
- 9 conditions: `full` and one-mechanism ablations `no_loop` (explain-only chat tutor), `no_spacing`, `no_remediation`, `no_transfer`, `no_bandit` (fixed approach), `no_long_term` (no beliefs; note this also removes misconception hypotheses, which are beliefs), `no_correction`, `with_calibration` (calibration is opt-in by default).
- Metrics. *Learning:* hidden knowledge gain, retention (predicted recall at +7 days), transfer (recall × transfer strength), misconceptions remaining / initial. *Teaching adaptation:* best-approach rate on explanation turns early/late (chance 0.17), understood-rate. *Interaction:* items per turn, reviews per turn. *Memory:* false active beliefs (active positive preference/fit whose hidden affinity < 0.6), leaked fit beliefs (outside the learner's domains), correction recreated, drift recovery (explanation turns after the flip until 4 of 6 picks are best).

## Results (3 seeds × 18 archetypes × 9 conditions = 486 runs, 23,328 turns, 1.6 s)

| condition | gain | retain | transfer | misc. left | best early | best late | understood | items/turn | reviews/turn | false active | leaked | corr. recreated |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **full** | 0.81 | **0.67** | **0.65** | 0.11 | 0.41 | 0.56 | 0.29 | 1.00 | 0.11 | 0.11 | 0 | **0/3** |
| no_loop | 0.27 | 0.22 | 0.08 | 0.51 | 0.59 | **0.75** | **0.54** | 0 | 0 | 0.31 | 0 | 0/3 |
| no_spacing | 0.80 | 0.62 | 0.60 | 0.12 | 0.39 | 0.53 | 0.36 | 1.00 | 0 | 0.11 | 0 | 0/3 |
| no_remediation | 0.79 | 0.57 | 0.55 | 0.24 | 0.43 | 0.66 | 0.33 | 1.00 | 0.12 | 0.11 | 0 | 0/2 |
| no_transfer | 0.82 | 0.60 | 0.58 | 0.08 | 0.30 | 0.58 | 0.29 | 1.00 | 0.13 | 0.02 | 0 | 0/2 |
| no_bandit | 0.81 | 0.63 | 0.61 | 0.12 | 0.19 | 0.20 | 0.23 | 1.00 | 0.11 | 0.04 | 0 | 0/2 |
| no_long_term | 0.79 | 0.58 | 0.55 | 0.27 | 0.33 | 0.43 | 0.28 | 1.00 | 0.12 | 0 | 0 | – |
| no_correction | 0.81 | 0.67 | 0.65 | 0.11 | 0.41 | 0.58 | 0.30 | 1.00 | 0.11 | 0.11 | 0 | **2/3** |
| with_calibration | 0.81 | 0.66 | 0.63 | 0.12 | 0.41 | 0.57 | 0.30 | 1.00 | 0.10 | 0.11 | 0 | 0/3 |

Generality (`full`, by domain category): procedural gain 0.68 / retain 0.52 / transfer 0.49 / misc. left 0.24 / best-late 0.65 · quantitative 0.82 / 0.61 / 0.59 / 0.11 / 0.70 · symbolic 0.75 / 0.71 / 0.68 / 0.25 / 0.50 · language 0.76 / 0.67 / 0.65 / 0.21 / 0.41.

Longer horizon (12 sessions, 14-day final gap, 2 seeds): full retain 0.84 / transfer 0.84; no_spacing 0.83 / 0.83; no_loop 0.29 / 0.11; with_calibration 0.84 / 0.84.

## Reading the table honestly

1. **The learning loop is the dominant mechanism.** Explain-only tutoring (`no_loop`) reaches gain 0.27, retention 0.22, transfer 0.08 and leaves half the misconceptions; the loop reaches 0.81 / 0.67 / 0.65 / 0.11. This is the expected consequence of a hidden model in which retrieval and feedback matter; the point is that the controller extracts the benefit across every archetype, including `silent`, `noisy`, `overconfident` and `long_gap`.
2. **Teaching adaptation and learning are different quantities — and the lab shows it.** `no_bandit` collapses best-approach rate to chance (0.20 vs 0.56) and lowers understood-rate (0.23 vs 0.29), yet retention drops only 0.67→0.63. Personalising *how* something is explained improves the experience much more than the outcome in this model. This is the distinction the product must keep visible, and why the UI reports knowledge and beliefs separately.
3. **Explain-only looks better on adaptation metrics** (best-late 0.75, understood 0.54) because every one of its turns is an explanation with a reaction — ten times the bandit's sample size. It is a reminder that "the learner liked it" is cheap to optimise and says little about learning.
4. **Remediation works** (misconceptions left 0.24 → 0.11; retention +0.10). `no_long_term` shows a similar learning loss because misconception hypotheses live in the belief layer — an intentional confound, documented rather than hidden.
5. **Transfer stage:** modest but consistent (+0.07 retention, +0.07 transfer). It costs turns that would otherwise go to more recall.
6. **Spacing is small-to-neutral** (+0.05 retention at 6 sessions, +0.01 at 12). In a loop where *every* turn is a retrieval event, the scheduler only changes *which* concept is retrieved; the benefit shows at the margin. It is kept because it is the only mechanism that revisits mastered concepts across long gaps, because it is what makes retention observable in the product, and because its cost is ≈0.1 turns. It is not proven to matter here.
7. **Calibration is neutral** → opt-in. A per-learner forgetting scale cannot help when reviews themselves are marginal.
8. **Correction works and costs nothing elsewhere:** 0/3 recreations with the mechanism, 2/3 without. In the 12-session run the corrected belief *was* rebuilt after the 14-day guard, from post-correction evidence only — by design, because the simulated learner's true affinity never changed.
9. **Memory hygiene:** zero leaked fit beliefs in every condition; false-active rate 0.11 in `full` (0.31 in explain-only, where reaction volume inflates confidence); observations grow linearly.
10. **Known weaknesses.** *Drift recovery is poor* (3/3 unrecovered at 6 sessions; 26 explanation turns at 12): with ≈3 explanation turns per session the bandit cannot detect a flip quickly — a direct consequence of trading explanation turns for evidence turns. *Multi-domain learners* (`switcher`, `context_dependent`) learn less per domain within the same budget (gain 0.35–0.51). *Best-approach rate varies widely across archetypes* (0.13–0.93) at this sample size. *Items per turn is 1.0*: the loop is demanding; a real learner may want conversational slack, which the `converse` path provides only on demand.

## Adversarial suite (`npm run adversarial`, 38/38)

Correction attack (retire + evidence edge + not re-parsed + not recreated + replacement supersedes) · stale-turn attribution (every learner turn references the exact previous tutor turn) · session boundary (no cross-session attribution; continuity greeting) · domain leakage (fit beliefs domain-scoped; switching creates no belief) · mastery confound (quarter-weight evidence) · loop invariants (teach ends with recall check; recall→apply→transfer→mastered→move on) · misconception (one sign = candidate, two = remediation with a discriminating item, correct answer contradicts) · spaced review after a gap, never twice in a row · 300 noisy turns → ≤12 active beliefs, linear observations, capped confidence · provider failure fallback · open question keeps the check open · model-synthesised subject validated and stored as application state · research cache carries no learner id · explain-only ablation poses no items · `challengeBelief` supersession.

## Unit tests (`npm test`, 9)

Belief lifecycle thresholds and caps; claims vs behaviour; BKT bounds; attribution rules; perception edge cases; grading (text, numeric tolerance, distractor→misconception) and pack integrity; pack validation against malformed model output; bandit convergence and cross-domain isolation; calibration bounds.

## What has and has not been shown

| Claim | Status |
| --- | --- |
| Core invariants (attribution, scoping, correction, dedupe, caps, validation) | tested (unit + adversarial) |
| The controller extracts learning gains when retrieval/feedback/refutation/application matter | simulated, benchmarked, ablated |
| Approach adaptation beats fixed/chance | simulated, benchmarked |
| Adaptation ≠ learning | simulated: shown to be distinct in this model |
| Remediation, transfer stage, long-term memory help learning | simulated, ablated (modest to clear) |
| Spacing scheduler helps | simulated: small-to-neutral — not proven |
| Calibration helps | simulated: neutral — off by default |
| Generality across domain categories | simulated across 4 categories; mechanisms behave comparably |
| Any effect on humans; pedagogical quality of model prose; correct grading of open-ended answers | **not validated** |

## Reproducing

```
npm test                       # unit tests
npm run adversarial            # 38 regression checks against the real engine
npm run lab                    # 3 seeds, writes lab/out/summary.json
npx tsx scripts/lab/run.ts --seeds=2 --sessions=12 --gap=14 --conditions=full,no_spacing
npx tsx scripts/lab/debug.ts example_lover   # turn-by-turn trace of one synthetic learner
```
