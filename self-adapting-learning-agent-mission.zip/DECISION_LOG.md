# Decision log

Chronological. Each entry: decision · alternatives · evidence · outcome.

### D1 — Treat the current repo as the strongest hypothesis, not as the product
The archive's `synthesize-self-adapting-learning-agent.zip` (the current repo's snapshot; the GitHub repo itself was not reachable from the sandbox) already synthesised 16 attempts with ablations. Its epistemics and bandit had evidence; its lab measured only reactions. **Decision:** keep the proven epistemics, rebuild around a learning loop. *Alternative:* start from the largest archive (graph-native) — rejected: no measured gain, harder invalidation.

### D2 — Two decision layers (activity × approach)
*Alternative:* one bandit over combined (activity, approach) arms. Rejected: 8×6 arms cannot be learned from a few dozen turns, and most activity choices are not preferences but consequences of evidence (a due review, a misconception, an unverified claim). **Decision:** deterministic controller for WHAT, bandit for HOW. Outcome: the lab can measure teaching adaptation and learning separately — and found them to be different.

### D3 — Every teaching turn ends with a retrieval check
Evidence: testing effect (g≈0.5–0.6), feedback amplifies it. Cost: items/turn = 1.0; the bandit sees fewer explanation turns. Outcome: learning metrics ×2–8 over explain-only in simulation; drift detection slower (documented weakness).

### D4 — Remove `hands_on_task` as an explanation style
It is a loop stage (`apply`). Six arms instead of seven also help sample efficiency.

### D5 — Misconceptions as beliefs
*Alternative:* a separate misconception table/engine (archives had one inside the curriculum engine). Rejected: it would need its own lifecycle, provenance, correction and UI. **Decision:** `kind: "misconception"`, scoped to domain + concept, same lifecycle. Confound accepted and documented: `no_long_term` also removes misconception tracking.

### D6 — Two independent signs before remediation
Trace of `example_lover` showed a 30%-guess distractor triggering repeated remediation of a misconception the learner never had. Outcome: remediation loop gone; adversarial test added.

### D7 — Forgetting as a stability half-life computed on read
*Alternative:* BKT-with-forgetting parameter. Rejected: stability is inspectable ("review in 3 d"), calibratable, and matches how spaced-retrieval schedulers work. Expanding schedules were not implemented: meta-analytic evidence says expanding ≈ uniform (g=0.03).

### D8 — Simple threshold review scheduler, interleaved
Outcome: small-to-neutral in simulation (+0.05 retention at 6 sessions, +0.01 at 12). Kept: cost ≈0.1 turns, only mechanism that revisits mastered concepts, needed for observing retention in the product. Recorded as *not proven*.

### D9 — Calibration opt-in
Implemented and unit-tested; neutral in every run. Per the rule "no measurable gain → not on by default", enabled only with `LEARNER_CALIBRATION=1`. Kept in code because it is small and its purpose (per-learner forgetting) is well defined; a longer real-world horizon is where it could matter.

### D10 — UCB+ε retained; Thompson not re-run
Two independent prior harnesses found UCB+ε better (0.65 vs 0.54; 0.6 vs 0.5). Re-running would have cost lab budget for a question already answered twice.

### D11 — Hidden learner model parameters
First version: stability ×1.24–1.6 per retrieval → floor effects at 14 days (retention 0.12 everywhere). Second: ×1.5–2.2, failure ×0.85 → discriminating benchmark. The change was driven by matching published half-life growth, not by making the system look good; the comparison between conditions is what matters, and it was qualitatively unchanged.

### D12 — Perception fixes found by tests
Reactions + answers co-occur; wh-questions are not answers; requests beat questions; correction targets are parsed before the replacement clause. All four have regression tests.

### D13 — Provider writes prose, never decides
Any OpenAI-compatible endpoint; JSON mode for pack synthesis; strict validator drops anything malformed (bogus item kinds, unknown prerequisites, missing recall items). Offline fallback everywhere. Adversarial test uses a provider that throws.

### D14 — Research and packs are application state
`research_cache` and `domain_packs` have no learner id; the registry persists validated packs and the engine treats them exactly like curated ones. Learner beliefs are never created from research content.

### D15 — MCP minimal and stateless
Three tools on the same engine. *Alternative:* full MCP SDK with sessions — rejected: no product benefit, extra dependency, risk of a second state path.

### D16 — Not built (deliberately)
Affect/emotion engine; probing questions (neutral-to-negative in the previous lab); knowledge graph store; per-learner LLM fine-tuning; accounts/multi-device identity.
