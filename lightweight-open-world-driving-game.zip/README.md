# Sunfall City Drive

A lightweight, stylised open-world driving game (PS2-era look, cleaner and refined) built with
React + Vite + Three.js. **Everything is generated procedurally at runtime** – textures, road
markings, buildings, cars – so the whole game is a single ~250 kB (gzipped) HTML file with
zero asset downloads and zero network usage.

## Features

| Area | What's in |
| --- | --- |
| World | 6×6 block city (downtown towers, mid-rise, residential, parks, parking lots), concrete ring highway, dirt rally trail, gravel quarry loop, rolling hills |
| Roads | 4-lane asphalt with lane/edge markings, zebra crosswalks & stop lines, curbs/sidewalks, street lamps, working traffic lights (9 s cycle), road signs, jersey barriers, hydrants, benches |
| Surfaces | asphalt · concrete · sidewalk · parking · plaza · dirt · gravel · grass – each with its own grip, top-speed penalty and bumpiness |
| Cars | 7 original vehicles built from extruded side-profiles: real wheel arches, tinted glass shell, pillars, mirrors, door seams, grille, bumpers, plates, exhausts, interior seats, textured rims. Per-class handling (grip, drift, power, off-road) |
| Feel | arcade slip model with handbrake drifting, suspension pitch/roll, curb bumps, hill gravity, building & traffic collisions |
| Time & weather | continuous day/night (sun, golden hour, moon, stars, lit windows, street lamps, auto headlights), Clear / Cloudy / Rain (wet reflective roads + particles) / Fog |
| Cameras | Chase · Hood · Top-down · Cinematic tripod (`C`) |
| Missions | 6 routes: sprint, ring time-trial, two rallies, courier delivery, grand tour – checkpoints, par times, best times saved locally, `R` = reset to last checkpoint |
| Performance | Low / Medium / High presets (resolution scale, shadows, draw distance, traffic count, rain density), chunk-based visibility (only nearby sections rendered), prop LOD distance, merged geometry & instancing (~300 draw calls) |
| Extras | procedural engine audio (WebAudio, no files), minimap, `F3` fps/draw-call overlay, localStorage save |

## Controls

`W A S D` / arrows drive · `Space` handbrake · `C` camera · `R` reset · `N` headlights · `T` +1 hour · `Esc` pause · `F3` debug

## Run in the browser

```bash
npm install
npm run dev      # development
npm run build    # -> dist/index.html (single self-contained file)
```

## Desktop app (same engine)

The game is a plain static bundle, so it drops straight into a compact desktop shell.
Recommended: **Tauri** (≈ 5 MB binary, uses the system WebView).

```bash
npm install -D @tauri-apps/cli
npx tauri init        # frontend dist: ../dist, dev command: npm run dev, dev url: http://localhost:5173
npx tauri build       # produces .exe / .app / .deb / .AppImage
```

Nothing in `src/game` depends on the browser beyond WebGL 2, `localStorage` and WebAudio,
all of which exist in the Tauri/Electron WebViews. Save data lives in `localStorage`
(key `sunfall-drive-save-v1`) – in Tauri this is persisted in the app data directory.

## Architecture

```
src/game/
  types.ts        settings, HUD state, quality profiles
  store.ts        localStorage save
  textures.ts     all canvas-generated textures (road, crosswalk, facades, signs, rims…)
  world.ts        layout constants, terrain height field, trails, surface detection
  citybuilder.ts  road/sidewalk/building/prop generation, chunking, colliders
  vehicles.ts     vehicle catalogue + procedural car builder
  physics.ts      arcade vehicle model
  traffic.ts      AI traffic (lanes, turns, lights, avoidance)
  audio.ts        procedural engine sound
  Engine.ts       renderer, sky/lighting, weather, cameras, missions, minimap, game loop
src/components/   React UI (menus, garage turntable, HUD, pause, results)
```
