import * as THREE from 'three';
import { buildCar, VEHICLES, type CarModel } from './vehicles';
import { NR, roadCoord, mulberry32, HALF_ROAD } from './world';

type Axis = 'x' | 'z';

export interface AICar {
  model: CarModel;
  x: number;
  z: number;
  heading: number;
  speed: number;
  cruise: number;
  axis: Axis;
  dir: 1 | -1;
  lane: number;
  road: number; // road index whose centreline we're following
  turning: 0 | 1 | -1; // 0 none, 1 right, -1 left
  turnRemaining: number; // radians left
  turnRadius: number;
  decidedAt: number; // intersection index already decided for
  waitTimer: number;
  steerVis: number;
  pending: 0 | 1 | -1;
  pendingCentre: number;
  pendingRoad: number;
}

const LANES = [1.75, 5.25];

export class Traffic {
  cars: AICar[] = [];
  private rnd = mulberry32(99);
  private scene: THREE.Scene;
  private rimTex: THREE.Texture;
  phaseA = true; // NS green

  constructor(scene: THREE.Scene, rimTex: THREE.Texture) {
    this.scene = scene;
    this.rimTex = rimTex;
  }

  setCount(n: number, px: number, pz: number) {
    while (this.cars.length > n) {
      const c = this.cars.pop()!;
      this.scene.remove(c.model.group);
    }
    while (this.cars.length < n) this.cars.push(this.spawn(px, pz));
  }

  private spawn(px: number, pz: number, far = false): AICar {
    const spec = VEHICLES[Math.floor(this.rnd() * VEHICLES.length)];
    const color = spec.colors[Math.floor(this.rnd() * spec.colors.length)];
    const model = buildCar(spec, color, this.rimTex);
    this.scene.add(model.group);
    const car: AICar = {
      model, x: 0, z: 0, heading: 0, speed: 8, cruise: 10 + this.rnd() * 5, axis: 'z', dir: 1, lane: 1.75, road: 3,
      turning: 0, turnRemaining: 0, turnRadius: 6, decidedAt: -99, waitTimer: 0, steerVis: 0, pending: 0, pendingCentre: 0, pendingRoad: 0,
    };
    this.place(car, px, pz, far);
    return car;
  }

  private place(car: AICar, px: number, pz: number, far: boolean) {
    for (let tries = 0; tries < 20; tries++) {
      car.axis = this.rnd() < 0.5 ? 'x' : 'z';
      car.dir = this.rnd() < 0.5 ? 1 : -1;
      car.lane = LANES[Math.floor(this.rnd() * 2)];
      car.road = Math.floor(this.rnd() * NR);
      const seg = Math.floor(this.rnd() * (NR - 1));
      const along = roadCoord(seg) + HALF_ROAD + 12 + this.rnd() * 40;
      const centre = roadCoord(car.road);
      const f = this.forward(car);
      const rt = { x: -f.z, z: f.x };
      if (car.axis === 'z') {
        car.x = centre + rt.x * car.lane;
        car.z = along;
      } else {
        car.z = centre + rt.z * car.lane;
        car.x = along;
      }
      const d = Math.hypot(car.x - px, car.z - pz);
      if (far ? d > 90 && d < 260 : d > 25) break;
    }
    car.heading = Math.atan2(this.forward(car).x, this.forward(car).z);
    car.turning = 0;
    car.pending = 0;
    car.decidedAt = -99;
    car.speed = car.cruise * 0.6;
    car.model.group.position.set(car.x, 0, car.z);
    car.model.group.rotation.set(0, car.heading, 0);
  }

  private forward(car: AICar) {
    return car.axis === 'z' ? { x: 0, z: car.dir } : { x: car.dir, z: 0 };
  }

  update(dt: number, px: number, pz: number, pvx: number, pvz: number, headlights: boolean) {
    const cars = this.cars;
    for (let i = 0; i < cars.length; i++) {
      const c = cars[i];
      // recycle far cars
      if (Math.hypot(c.x - px, c.z - pz) > 380) {
        this.place(c, px, pz, true);
        continue;
      }
      let f = this.forward(c);
      let fx = Math.sin(c.heading), fz = Math.cos(c.heading);

      // ---- decide turns at the next intersection ----
      if (!c.turning) {
        const along = c.axis === 'z' ? c.z : c.x;
        const nextIdx = c.dir > 0 ? Math.ceil((along - roadCoord(0)) / 78 - 1e-6) : Math.floor((along - roadCoord(0)) / 78 + 1e-6);
        const clampedIdx = Math.max(0, Math.min(NR - 1, nextIdx));
        const centre = roadCoord(clampedIdx);
        const distToCentre = (centre - along) * c.dir;
        if (c.decidedAt !== clampedIdx && distToCentre < 22) {
          c.decidedAt = clampedIdx;
          const atEdge = nextIdx <= 0 && c.dir < 0 ? true : nextIdx >= NR - 1 && c.dir > 0 ? true : false;
          const r = this.rnd();
          let choice: 0 | 1 | -1 = 0;
          if (atEdge) choice = r < 0.5 ? 1 : -1;
          else if (r < 0.22) choice = 1;
          else if (r < 0.4) choice = -1;
          // left turn requires being in inner lane, right in outer lane: swap lane silently (cheap)
          if (choice === 1) c.lane = 1.75;
          if (choice === -1) c.lane = 5.25;
          c.pending = choice;
          c.pendingCentre = centre;
          c.pendingRoad = clampedIdx;
        }
        const pending = c.pending;
        if (pending !== 0) {
          const pc = c.pendingCentre;
          const d = (pc - along) * c.dir;
          const rR = 6.0, rL = 10.5;
          const trigger = pending === 1 ? c.lane + rR : rL - c.lane;
          if (d <= trigger) {
            c.turning = pending;
            c.turnRadius = pending === 1 ? rR : rL;
            c.turnRemaining = Math.PI / 2;
            c.pending = 0;
            // new road index is the crossing road
            const newRoad = c.pendingRoad;
            const newAxis: Axis = c.axis === 'z' ? 'x' : 'z';
            // right of forward: rt = (-fz, fx); left = -rt
            const rt = { x: -f.z, z: f.x };
            const nf = pending === 1 ? rt : { x: -rt.x, z: -rt.z };
            c.axis = newAxis;
            c.dir = (newAxis === 'z' ? nf.z : nf.x) > 0 ? 1 : -1;
            c.road = newRoad;
            f = this.forward(c);
          }
        }
        // traffic light: stop if red for our axis
        const green = c.axis === 'z' ? this.phaseA : !this.phaseA;
        if (!green && distToCentre > 8.5 && distToCentre < 13) c.waitTimer = 0.3;
      }

      // ---- turn execution ----
      let targetSpeed = c.cruise;
      if (c.turning) {
        const yaw = (c.speed / c.turnRadius) * dt;
        const step = Math.min(yaw, c.turnRemaining);
        c.heading += -c.turning * step; // right turn = clockwise = negative heading
        c.turnRemaining -= step;
        targetSpeed = Math.min(c.cruise, c.turning === 1 ? 6 : 8);
        c.steerVis += ((-c.turning * 0.5) - c.steerVis) * Math.min(1, dt * 6);
        if (c.turnRemaining <= 1e-4) {
          c.turning = 0;
          c.heading = Math.atan2(f.x, f.z);
          // snap to lane
          const rt = { x: -f.z, z: f.x };
          const centre = roadCoord(c.road);
          if (c.axis === 'z') c.x = centre + rt.x * c.lane;
          else c.z = centre + rt.z * c.lane;
        }
      } else {
        c.steerVis *= Math.exp(-6 * dt);
        // hold lane precisely
        const rt = { x: -f.z, z: f.x };
        const centre = roadCoord(c.road);
        if (c.axis === 'z') c.x += (centre + rt.x * c.lane - c.x) * Math.min(1, dt * 4);
        else c.z += (centre + rt.z * c.lane - c.z) * Math.min(1, dt * 4);
      }
      fx = Math.sin(c.heading);
      fz = Math.cos(c.heading);

      // ---- avoidance: cars ahead + player ----
      let ahead = 40;
      for (let j = 0; j < cars.length; j++) {
        if (j === i) continue;
        const o = cars[j];
        const dx = o.x - c.x, dz = o.z - c.z;
        const along = dx * fx + dz * fz;
        const lat = Math.abs(-dx * fz + dz * fx);
        if (along > 0 && along < ahead && lat < 2.6) ahead = along;
      }
      {
        const dx = px - c.x, dz = pz - c.z;
        const along = dx * fx + dz * fz;
        const lat = Math.abs(-dx * fz + dz * fx);
        if (along > 0 && along < ahead && lat < 3) ahead = along;
        // player coming from the side at an intersection – be polite
        void pvx; void pvz;
      }
      if (ahead < 16) targetSpeed = Math.min(targetSpeed, Math.max(0, (ahead - 5) * 1.2));
      if (c.waitTimer > 0) {
        c.waitTimer -= dt;
        targetSpeed = 0;
      }
      const acc = targetSpeed > c.speed ? 4 : 9;
      c.speed += Math.max(-acc * dt, Math.min(acc * dt, targetSpeed - c.speed));
      c.x += fx * c.speed * dt;
      c.z += fz * c.speed * dt;

      // ---- visuals ----
      const g = c.model.group;
      g.position.set(c.x, 0, c.z);
      g.rotation.y = c.heading;
      const spin = (c.speed / c.model.spec.wheelR) * dt;
      for (let w = 0; w < 4; w++) {
        const wm = c.model.wheels[w];
        wm.rotation.x += spin;
        if (w < 2) wm.rotation.y = c.steerVis;
      }
      c.model.tail.emissiveIntensity = targetSpeed < c.speed - 0.5 ? 2.5 : headlights ? 0.9 : 0.25;
      c.model.head.emissiveIntensity = headlights ? 3 : 0.2;
    }
  }

  /** push player out of AI cars; returns true on hit */
  collide(p: { x: number; z: number; vx: number; vz: number }, radius: number): boolean {
    let hit = false;
    for (const c of this.cars) {
      const dx = p.x - c.x, dz = p.z - c.z;
      const d = Math.hypot(dx, dz);
      const minD = radius + 2.1;
      if (d < minD && d > 1e-3) {
        const nx = dx / d, nz = dz / d;
        const push = minD - d;
        p.x += nx * push;
        p.z += nz * push;
        const vn = p.vx * nx + p.vz * nz;
        if (vn < 0) {
          p.vx -= nx * vn * 1.5;
          p.vz -= nz * vn * 1.5;
        }
        p.vx *= 0.9;
        p.vz *= 0.9;
        c.waitTimer = 1.2;
        hit = true;
      }
    }
    return hit;
  }
}
