import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { TextureSet } from './textures';
import {
  AABB, BLOCK, CITY_HALF, GRID0, HALF_ROAD, NB, NR, PITCH, RING_IN, RING_OUT, RING_R, RING_W, SIDEWALK_H, SIDEWALK_W,
  TRAILS, WORLD_HALF, FLAT_R, blockType, heightAt, mulberry32, roadCoord, trailDistance,
} from './world';

export interface Chunk {
  center: THREE.Vector3;
  radius: number;
  main: THREE.Object3D[]; // buildings – long distance
  props: THREE.Object3D[]; // details – short distance
}

export interface ParkedSpot {
  x: number;
  z: number;
  heading: number;
}

export interface CityResult {
  group: THREE.Group;
  chunks: Chunk[];
  colliders: AABB[];
  parked: ParkedSpot[];
  lampHeadMat: THREE.MeshStandardMaterial;
  facadeMats: THREE.MeshStandardMaterial[];
  roadMats: THREE.MeshStandardMaterial[];
  trafficLamps: THREE.InstancedMesh;
  trafficPhaseA: boolean[]; // per lamp: true = belongs to NS set
  trafficIsRed: boolean[]; // per lamp: red or green bulb
}

// ---------- helpers ----------
function boxUV(g: THREE.BoxGeometry, w: number, h: number, d: number, scale: number) {
  const uv = g.getAttribute('uv') as THREE.BufferAttribute;
  const dims: [number, number][] = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) {
    const [su, sv] = dims[f];
    for (let i = 0; i < 4; i++) {
      const idx = f * 4 + i;
      uv.setXY(idx, (uv.getX(idx) * su) / scale, (uv.getY(idx) * sv) / scale);
    }
  }
}

function texturedBox(w: number, h: number, d: number, x: number, y: number, z: number, scale: number) {
  const g = new THREE.BoxGeometry(w, h, d);
  boxUV(g, w, h, d, scale);
  g.translate(x, y, z);
  return g;
}

function flatPlane(w: number, l: number, x: number, y: number, z: number, texSize: number, rotY = 0) {
  const g = new THREE.PlaneGeometry(w, l);
  const uv = g.getAttribute('uv') as THREE.BufferAttribute;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, (uv.getX(i) * w) / texSize, (uv.getY(i) * l) / texSize);
  g.rotateX(-Math.PI / 2);
  if (rotY) g.rotateY(rotY);
  g.translate(x, y, z);
  return g;
}

function colored(g: THREE.BufferGeometry, color: THREE.Color) {
  const n = g.getAttribute('position').count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    arr[i * 3] = color.r;
    arr[i * 3 + 1] = color.g;
    arr[i * 3 + 2] = color.b;
  }
  g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return g;
}

function merge(list: THREE.BufferGeometry[]) {
  if (!list.length) return null;
  const prepared = list.map((g) => (g.index ? g.toNonIndexed() : g));
  const m = mergeGeometries(prepared, false);
  prepared.forEach((g) => g.dispose());
  return m;
}

class GeoBucket {
  lists = new Map<string, THREE.BufferGeometry[]>();
  add(key: string, g: THREE.BufferGeometry) {
    let l = this.lists.get(key);
    if (!l) this.lists.set(key, (l = []));
    l.push(g);
  }
}

class PropBucket {
  items = new Map<string, THREE.Matrix4[]>();
  colors = new Map<string, THREE.Color[]>();
  add(key: string, x: number, y: number, z: number, ry: number, scale = 1, color?: THREE.Color) {
    let l = this.items.get(key);
    if (!l) this.items.set(key, (l = []));
    const m = new THREE.Matrix4();
    m.compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), ry), new THREE.Vector3(scale, scale, scale));
    l.push(m);
    if (color) {
      let c = this.colors.get(key);
      if (!c) this.colors.set(key, (c = []));
      c.push(color);
    }
  }
}

// ---------- prop geometries ----------
function propGeometries(tex: TextureSet) {
  const grey = new THREE.Color(0x6f7479);
  const darkGrey = new THREE.Color(0x2b2e32);

  // lamp post
  const pole = colored(new THREE.CylinderGeometry(0.07, 0.11, 7, 8).translate(0, 3.5, 0), grey);
  const arm = colored(new THREE.BoxGeometry(0.1, 0.1, 2.0).translate(0, 6.9, 1.0), grey);
  const base = colored(new THREE.CylinderGeometry(0.2, 0.25, 0.5, 8).translate(0, 0.25, 0), darkGrey);
  const lamp = merge([pole, arm, base])!;
  const lampHead = new THREE.BoxGeometry(0.36, 0.14, 0.7).translate(0, 6.86, 1.75);

  // tree
  const trunk = colored(new THREE.CylinderGeometry(0.16, 0.24, 2.4, 6).translate(0, 1.2, 0), new THREE.Color(0x5b4128));
  const leaf1 = colored(new THREE.IcosahedronGeometry(1.9, 0).translate(0, 3.4, 0), new THREE.Color(0x3f7a2f));
  const leaf2 = colored(new THREE.IcosahedronGeometry(1.4, 0).translate(0.4, 4.6, 0.2), new THREE.Color(0x4f8f38));
  const tree = merge([trunk, leaf1, leaf2])!;
  // pine (hills)
  const ptrunk = colored(new THREE.CylinderGeometry(0.14, 0.22, 2.0, 6).translate(0, 1.0, 0), new THREE.Color(0x4e3620));
  const cone1 = colored(new THREE.ConeGeometry(1.8, 3.2, 7).translate(0, 3.2, 0), new THREE.Color(0x2f5f2a));
  const cone2 = colored(new THREE.ConeGeometry(1.3, 2.6, 7).translate(0, 5.0, 0), new THREE.Color(0x376b30));
  const pine = merge([ptrunk, cone1, cone2])!;

  // sign: pole + plate (uv of pole => grey corner)
  const spole = new THREE.CylinderGeometry(0.035, 0.035, 2.6, 6).translate(0, 1.3, 0);
  const suv = spole.getAttribute('uv') as THREE.BufferAttribute;
  for (let i = 0; i < suv.count; i++) suv.setXY(i, 0.02, 0.02);
  const plate = new THREE.PlaneGeometry(0.8, 0.8).translate(0, 2.55, 0.04);
  const plateBack = new THREE.PlaneGeometry(0.8, 0.8).rotateY(Math.PI).translate(0, 2.55, 0.02);
  const buv = plateBack.getAttribute('uv') as THREE.BufferAttribute;
  for (let i = 0; i < buv.count; i++) buv.setXY(i, 0.02, 0.02);
  const sign = merge([spole, plate, plateBack])!;

  // hydrant
  const hyd = merge([
    new THREE.CylinderGeometry(0.13, 0.15, 0.7, 8).translate(0, 0.35, 0),
    new THREE.SphereGeometry(0.14, 8, 6).translate(0, 0.72, 0),
    new THREE.CylinderGeometry(0.06, 0.06, 0.4, 6).rotateZ(Math.PI / 2).translate(0, 0.5, 0),
  ])!;

  // jersey barrier
  const barrier = new THREE.BoxGeometry(0.55, 0.85, 3.0).translate(0, 0.425, 0);

  // traffic light: pole + housing
  const tpole = colored(new THREE.CylinderGeometry(0.07, 0.09, 4.2, 8).translate(0, 2.1, 0), grey);
  const housing = colored(new THREE.BoxGeometry(0.36, 1.05, 0.3).translate(0, 3.55, 0.12), darkGrey);
  const visor = colored(new THREE.BoxGeometry(0.4, 0.04, 0.2).translate(0, 4.06, 0.3), darkGrey);
  const tlight = merge([tpole, housing, visor])!;
  const bulb = new THREE.SphereGeometry(0.1, 8, 6);

  // bench (park)
  const bench = merge([
    colored(new THREE.BoxGeometry(1.6, 0.06, 0.45).translate(0, 0.45, 0), new THREE.Color(0x7a5230)),
    colored(new THREE.BoxGeometry(1.6, 0.4, 0.06).translate(0, 0.7, -0.22), new THREE.Color(0x7a5230)),
    colored(new THREE.BoxGeometry(0.08, 0.45, 0.45).translate(-0.7, 0.22, 0), darkGrey),
    colored(new THREE.BoxGeometry(0.08, 0.45, 0.45).translate(0.7, 0.22, 0), darkGrey),
  ])!;

  const vc = (extra: Partial<THREE.MeshStandardMaterialParameters> = {}) => new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.85, ...extra });
  const lampHeadMat = new THREE.MeshStandardMaterial({ color: 0xf0f2f4, emissive: 0xfff1c4, emissiveIntensity: 0, roughness: 0.4 });
  const signMats = tex.signs.map((t) => new THREE.MeshStandardMaterial({ map: t, roughness: 0.6, metalness: 0.2 }));

  return {
    lampHeadMat,
    defs: {
      lamp: { geo: lamp, mat: vc({ metalness: 0.3, roughness: 0.6 }) },
      lampHead: { geo: lampHead, mat: lampHeadMat },
      tree: { geo: tree, mat: vc() },
      pine: { geo: pine, mat: vc() },
      sign0: { geo: sign, mat: signMats[0] },
      sign1: { geo: sign, mat: signMats[1] },
      sign2: { geo: sign, mat: signMats[2] },
      sign3: { geo: sign, mat: signMats[3] },
      hydrant: { geo: hyd, mat: new THREE.MeshStandardMaterial({ color: 0xc8202a, roughness: 0.5, metalness: 0.3 }) },
      barrier: { geo: barrier, mat: new THREE.MeshStandardMaterial({ color: 0x9a9891, roughness: 0.9 }) },
      tlight: { geo: tlight, mat: vc({ metalness: 0.3, roughness: 0.6 }) },
      bench: { geo: bench, mat: vc() },
    } as Record<string, { geo: THREE.BufferGeometry; mat: THREE.Material }>,
    bulb,
  };
}

// ---------- main builder ----------
export function buildCity(tex: TextureSet, quality: { shadows: boolean }): CityResult {
  const rnd = mulberry32(1337);
  const group = new THREE.Group();
  const colliders: AABB[] = [];
  const parked: ParkedSpot[] = [];
  const shadows = quality.shadows;

  // materials
  const roadMat = new THREE.MeshStandardMaterial({ map: tex.road, roughness: 0.92, metalness: 0.0 });
  const interMat = new THREE.MeshStandardMaterial({ map: tex.intersection, roughness: 0.92 });
  const hwyMat = new THREE.MeshStandardMaterial({ map: tex.highway, roughness: 0.9 });
  const parkingMat = new THREE.MeshStandardMaterial({ map: tex.parking, roughness: 0.9 });
  const sidewalkMat = new THREE.MeshStandardMaterial({ map: tex.sidewalk, roughness: 0.95 });
  const plazaMat = new THREE.MeshStandardMaterial({ map: tex.plaza, roughness: 0.9 });
  const grassMat = new THREE.MeshStandardMaterial({ map: tex.grass, roughness: 1 });
  const dirtMat = new THREE.MeshStandardMaterial({ map: tex.dirt, roughness: 1 });
  const gravelMat = new THREE.MeshStandardMaterial({ map: tex.gravel, roughness: 1 });
  const roofMat = new THREE.MeshStandardMaterial({ map: tex.roof, roughness: 0.95 });
  const miscMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.8 });
  const facadeMats = tex.facades.map(
    (f) => new THREE.MeshStandardMaterial({ map: f.map, emissiveMap: f.emissive, emissive: 0xffffff, emissiveIntensity: 0, roughness: 0.7, metalness: 0.05 }),
  );
  const matByKey: Record<string, THREE.Material> = {
    road: roadMat, inter: interMat, hwy: hwyMat, parking: parkingMat, sidewalk: sidewalkMat, plaza: plazaMat, grass: grassMat,
    dirt: dirtMat, gravel: gravelMat, roof: roofMat, misc: miscMat,
    facade0: facadeMats[0], facade1: facadeMats[1], facade2: facadeMats[2], facade3: facadeMats[3], facade4: facadeMats[4],
  };

  const global = new GeoBucket(); // always visible (ground)
  const chunkGeo: GeoBucket[] = [];
  const chunkProps: PropBucket[] = [];
  const chunkCenters: THREE.Vector3[] = [];
  const chunkRadius: number[] = [];
  // 3x3 city chunks (2x2 blocks each) + 4 outer quadrants
  for (let cj = 0; cj < 3; cj++)
    for (let ci = 0; ci < 3; ci++) {
      chunkGeo.push(new GeoBucket());
      chunkProps.push(new PropBucket());
      chunkCenters.push(new THREE.Vector3(GRID0 + (ci * 2 + 1) * PITCH, 20, GRID0 + (cj * 2 + 1) * PITCH));
      chunkRadius.push(PITCH * 1.5);
    }
  for (let q = 0; q < 4; q++) {
    chunkGeo.push(new GeoBucket());
    chunkProps.push(new PropBucket());
    const sx = q % 2 ? 1 : -1;
    const sz = q < 2 ? -1 : 1;
    chunkCenters.push(new THREE.Vector3(sx * 360, 10, sz * 360));
    chunkRadius.push(520);
  }
  const chunkOf = (x: number, z: number) => {
    if (Math.max(Math.abs(x), Math.abs(z)) <= CITY_HALF + 2) {
      const ci = Math.min(2, Math.max(0, Math.floor((x - GRID0) / (PITCH * 2))));
      const cj = Math.min(2, Math.max(0, Math.floor((z - GRID0) / (PITCH * 2))));
      return cj * 3 + ci;
    }
    return 9 + (x > 0 ? 1 : 0) + (z > 0 ? 2 : 0);
  };
  const addProp = (key: string, x: number, y: number, z: number, ry: number, scale = 1, color?: THREE.Color) =>
    chunkProps[chunkOf(x, z)].add(key, x, y, z, ry, scale, color);
  const addGeo = (key: string, g: THREE.BufferGeometry, x: number, z: number) => chunkGeo[chunkOf(x, z)].add(key, g);

  // ---------- Roads ----------
  for (let i = 0; i < NR; i++) {
    const c = roadCoord(i);
    for (let j = 0; j < NB; j++) {
      const a = roadCoord(j) + HALF_ROAD;
      const len = PITCH - 2 * HALF_ROAD;
      const mid = a + len / 2;
      global.add('road', flatPlane(14, len, c, 0, mid, 14));
      global.add('road', flatPlane(14, len, mid, 0, c, 14, Math.PI / 2));
    }
    // extensions to ring
    const extLen = RING_IN - CITY_HALF;
    for (const s of [-1, 1]) {
      const mid = s * (CITY_HALF + extLen / 2);
      global.add('road', flatPlane(14, extLen, c, 0, mid, 14));
      global.add('road', flatPlane(14, extLen, mid, 0, c, 14, Math.PI / 2));
    }
    for (let j = 0; j < NR; j++) global.add('inter', flatPlane(14, 14, c, 0.002, roadCoord(j), 14));
  }
  // ring highway
  global.add('hwy', flatPlane(RING_W, RING_OUT * 2, RING_R, 0, 0, 12));
  global.add('hwy', flatPlane(RING_W, RING_OUT * 2, -RING_R, 0, 0, 12));
  global.add('hwy', flatPlane(RING_W, RING_IN * 2, 0, 0, RING_R, 12, Math.PI / 2));
  global.add('hwy', flatPlane(RING_W, RING_IN * 2, 0, 0, -RING_R, 12, Math.PI / 2));

  // ---------- Terrain ----------
  {
    const seg = 144;
    const g = new THREE.PlaneGeometry(WORLD_HALF * 2, WORLD_HALF * 2, seg, seg);
    g.rotateX(-Math.PI / 2);
    const pos = g.getAttribute('position') as THREE.BufferAttribute;
    const col = new Float32Array(pos.count * 3);
    const uv = g.getAttribute('uv') as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const h = heightAt(x, z);
      pos.setY(i, h - 0.04);
      uv.setXY(i, (uv.getX(i) * WORLD_HALF * 2) / 8, (uv.getY(i) * WORLD_HALF * 2) / 8);
      const dry = Math.min(1, h / 30);
      const nearTrail = TRAILS.some((t) => trailDistance(x, z, t) < t.width * 1.2);
      let r = 0.82 + dry * 0.35;
      let gg = 0.92 - dry * 0.1;
      let b = 0.8 - dry * 0.25;
      if (nearTrail) {
        r *= 1.1;
        gg *= 0.95;
        b *= 0.85;
      }
      col[i * 3] = r;
      col[i * 3 + 1] = gg;
      col[i * 3 + 2] = b;
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    g.computeVertexNormals();
    const terrain = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ map: tex.grass, vertexColors: true, roughness: 1 }));
    terrain.receiveShadow = shadows;
    group.add(terrain);
  }

  // ---------- Trails ----------
  for (const t of TRAILS) {
    const s = t.samples;
    const n = s.length / 2;
    const verts: number[] = [];
    const uvs: number[] = [];
    const idx: number[] = [];
    let dist = 0;
    for (let i = 0; i < n; i++) {
      const x = s[i * 2];
      const z = s[i * 2 + 1];
      const nx = s[Math.min(n - 1, i + 1) * 2] - s[Math.max(0, i - 1) * 2];
      const nz = s[Math.min(n - 1, i + 1) * 2 + 1] - s[Math.max(0, i - 1) * 2 + 1];
      const l = Math.hypot(nx, nz) || 1;
      const px = -nz / l;
      const pz = nx / l;
      const hw = t.width / 2;
      const lx = x + px * hw, lz = z + pz * hw, rx = x - px * hw, rz = z - pz * hw;
      verts.push(lx, heightAt(lx, lz) + 0.06, lz, rx, heightAt(rx, rz) + 0.06, rz);
      if (i > 0) dist += Math.hypot(x - s[(i - 1) * 2], z - s[(i - 1) * 2 + 1]);
      uvs.push(0, dist / t.width, 1, dist / t.width);
      if (i > 0) {
        const a = (i - 1) * 2;
        idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    g.setIndex(idx);
    g.computeVertexNormals();
    const m = new THREE.Mesh(g, t.kind === 'dirt' ? dirtMat : gravelMat);
    m.receiveShadow = shadows;
    group.add(m);
  }

  // ---------- Blocks ----------
  const awningColors = [0xc0392b, 0x2980b9, 0x27ae60, 0xf39c12, 0x8e44ad, 0x16a085].map((c) => new THREE.Color(c));
  const roofColors = [0x7a3b2e, 0x5a4636, 0x3d4a5a, 0x6b5b4a].map((c) => new THREE.Color(c));
  const acGrey = new THREE.Color(0x9a9ea3);
  const pathCol = new THREE.Color(0xb5ae9c);
  const waterCol = new THREE.Color(0x2f7fb3);

  for (let bj = 0; bj < NB; bj++) {
    for (let bi = 0; bi < NB; bi++) {
      const type = blockType(bi, bj);
      const x0 = roadCoord(bi) + HALF_ROAD; // block min x
      const z0 = roadCoord(bj) + HALF_ROAD;
      const cx = x0 + BLOCK / 2;
      const cz = z0 + BLOCK / 2;
      const inner = BLOCK - SIDEWALK_W * 2; // 58

      // sidewalks (4 strips)
      const sy = SIDEWALK_H / 2;
      global.add('sidewalk', texturedBox(BLOCK, SIDEWALK_H, SIDEWALK_W, cx, sy, z0 + SIDEWALK_W / 2, 4));
      global.add('sidewalk', texturedBox(BLOCK, SIDEWALK_H, SIDEWALK_W, cx, sy, z0 + BLOCK - SIDEWALK_W / 2, 4));
      global.add('sidewalk', texturedBox(SIDEWALK_W, SIDEWALK_H, inner, x0 + SIDEWALK_W / 2, sy, cz, 4));
      global.add('sidewalk', texturedBox(SIDEWALK_W, SIDEWALK_H, inner, x0 + BLOCK - SIDEWALK_W / 2, sy, cz, 4));

      // interior fill
      const fillKey = type === 'K' ? 'parking' : type === 'P' || type === 'R' ? 'grass' : 'plaza';
      const fillTex = type === 'K' ? 16 : type === 'P' || type === 'R' ? 8 : 4;
      global.add(fillKey, flatPlane(inner, inner, cx, SIDEWALK_H - 0.005, cz, fillTex));

      // hydrants + occasional street trees along sidewalk
      if (rnd() < 0.6) addProp('hydrant', x0 + 1.2, SIDEWALK_H, z0 + 8 + rnd() * 40, 0);
      if (type !== 'D') {
        for (let k = 0; k < 3; k++) {
          if (rnd() < 0.5) addProp('tree', x0 + 1.5, SIDEWALK_H, z0 + 10 + k * 20 + rnd() * 6, rnd() * 6, 0.65 + rnd() * 0.2);
          if (rnd() < 0.5) addProp('tree', x0 + 10 + k * 20 + rnd() * 6, SIDEWALK_H, z0 + BLOCK - 1.5, rnd() * 6, 0.65 + rnd() * 0.2);
        }
      }

      const ix0 = x0 + SIDEWALK_W;
      const iz0 = z0 + SIDEWALK_W;

      const addBuilding = (bx: number, bz: number, w: number, d: number, h: number, facade: number, opts: { podium?: boolean; house?: boolean } = {}) => {
        const yBase = SIDEWALK_H;
        const g = new THREE.BoxGeometry(w, h, d);
        boxUV(g, w, h, d, 1);
        // facade texture: 8m x 7m modules
        const uv = g.getAttribute('uv') as THREE.BufferAttribute;
        for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) / 8, uv.getY(i) / 7);
        g.translate(bx, yBase + h / 2, bz);
        addGeo('facade' + facade, g, bx, bz);
        // roof
        if (opts.house) {
          const rc = roofColors[Math.floor(rnd() * roofColors.length)];
          const cone = new THREE.ConeGeometry(Math.hypot(w, d) / 2 + 0.4, 2.2 + rnd(), 4);
          cone.rotateY(Math.PI / 4);
          cone.scale(w / Math.hypot(w, d) * 1.02, 1, d / Math.hypot(w, d) * 1.02);
          cone.translate(bx, yBase + h + 1.1, bz);
          addGeo('misc', colored(cone, rc), bx, bz);
        } else {
          addGeo('roof', flatPlane(w, d, bx, yBase + h + 0.03, bz, 4), bx, bz);
          // parapet
          const par = new THREE.BoxGeometry(w + 0.3, 0.5, d + 0.3);
          boxUV(par, w + 0.3, 0.5, d + 0.3, 8);
          par.translate(bx, yBase + h + 0.2, bz);
          addGeo('facade' + facade, par, bx, bz);
          // AC units / stairwell
          const nAc = 1 + Math.floor(rnd() * 3);
          for (let k = 0; k < nAc; k++) {
            const aw = 1.5 + rnd() * 3;
            const ax = bx + (rnd() - 0.5) * (w - aw - 2);
            const az = bz + (rnd() - 0.5) * (d - aw - 2);
            addGeo('misc', colored(new THREE.BoxGeometry(aw, 1 + rnd() * 2, aw).translate(ax, yBase + h + 0.8, az), acGrey), bx, bz);
          }
          if (h > 45 && rnd() < 0.7) {
            addGeo('misc', colored(new THREE.CylinderGeometry(0.15, 0.15, 6 + rnd() * 6, 6).translate(bx + w * 0.3, yBase + h + 4, bz), new THREE.Color(0xdddddd)), bx, bz);
          }
        }
        // ground floor awnings (midrise)
        if (facade !== 0 && !opts.house && h < 40 && rnd() < 0.7) {
          const ac = awningColors[Math.floor(rnd() * awningColors.length)];
          const side = Math.floor(rnd() * 4);
          const len = (side < 2 ? w : d) * 0.6;
          const aw = new THREE.BoxGeometry(side < 2 ? len : 1.2, 0.12, side < 2 ? 1.2 : len);
          const off = side === 0 ? [0, d / 2 + 0.6] : side === 1 ? [0, -d / 2 - 0.6] : side === 2 ? [w / 2 + 0.6, 0] : [-w / 2 - 0.6, 0];
          aw.translate(bx + off[0], yBase + 3.2, bz + off[1]);
          addGeo('misc', colored(aw, ac), bx, bz);
        }
        if (opts.podium) {
          const pw = w + 6, pd = d + 6, ph = 8;
          const pg = new THREE.BoxGeometry(pw, ph, pd);
          boxUV(pg, pw, ph, pd, 1);
          const puv = pg.getAttribute('uv') as THREE.BufferAttribute;
          for (let i = 0; i < puv.count; i++) puv.setXY(i, puv.getX(i) / 8, puv.getY(i) / 7);
          pg.translate(bx, yBase + ph / 2, bz);
          addGeo('facade1', pg, bx, bz);
          addGeo('roof', flatPlane(pw, pd, bx, yBase + ph + 0.03, bz, 4), bx, bz);
          colliders.push({ minX: bx - pw / 2, maxX: bx + pw / 2, minZ: bz - pd / 2, maxZ: bz + pd / 2 });
        } else {
          colliders.push({ minX: bx - w / 2, maxX: bx + w / 2, minZ: bz - d / 2, maxZ: bz + d / 2 });
        }
      };

      if (type === 'D') {
        const lot = inner / 2;
        for (let lj = 0; lj < 2; lj++)
          for (let li = 0; li < 2; li++) {
            const podium = rnd() < 0.35;
            const w = podium ? 14 + rnd() * 5 : 19 + rnd() * 7;
            const d = podium ? 14 + rnd() * 5 : 19 + rnd() * 7;
            const bx = ix0 + lot * li + lot / 2 + (rnd() - 0.5) * 2;
            const bz = iz0 + lot * lj + lot / 2 + (rnd() - 0.5) * 2;
            const h = 36 + rnd() * 50;
            const facade = [0, 0, 4, 1][Math.floor(rnd() * 4)];
            addBuilding(bx, bz, w, d, h, facade, { podium });
          }
      } else if (type === 'M') {
        const lot = inner / 3;
        for (let lj = 0; lj < 3; lj++)
          for (let li = 0; li < 3; li++) {
            if (rnd() < 0.1) {
              addProp('tree', ix0 + lot * li + lot / 2, SIDEWALK_H, iz0 + lot * lj + lot / 2, rnd() * 6, 0.9 + rnd() * 0.3);
              continue;
            }
            const w = 12 + rnd() * 5.5;
            const d = 12 + rnd() * 5.5;
            const bx = ix0 + lot * li + lot / 2;
            const bz = iz0 + lot * lj + lot / 2;
            const h = 11 + rnd() * 20;
            const facade = [1, 2, 4, 2][Math.floor(rnd() * 4)];
            addBuilding(bx, bz, w, d, h, facade);
          }
      } else if (type === 'R') {
        const lot = inner / 4;
        for (let lj = 0; lj < 4; lj++)
          for (let li = 0; li < 4; li++) {
            const bx = ix0 + lot * li + lot / 2;
            const bz = iz0 + lot * lj + lot / 2;
            if (rnd() < 0.25) {
              addProp('tree', bx + (rnd() - 0.5) * 4, SIDEWALK_H, bz + (rnd() - 0.5) * 4, rnd() * 6, 0.8 + rnd() * 0.5);
              if (rnd() < 0.5) addProp('bench', bx + 3, SIDEWALK_H, bz - 3, rnd() * 6);
              continue;
            }
            const w = 7.5 + rnd() * 3;
            const d = 7.5 + rnd() * 3;
            const h = 5 + rnd() * 3;
            addBuilding(bx, bz, w, d, h, 3, { house: true });
            if (rnd() < 0.7) addProp('tree', bx + (li < 2 ? -1 : 1) * (w / 2 + 2.2), SIDEWALK_H, bz + (rnd() - 0.5) * 6, rnd() * 6, 0.6 + rnd() * 0.4);
          }
      } else if (type === 'P') {
        // park: paths, pond, trees, benches
        addGeo('misc', colored(new THREE.BoxGeometry(inner, 0.02, 3).translate(cx, SIDEWALK_H + 0.01, cz), pathCol), cx, cz);
        addGeo('misc', colored(new THREE.BoxGeometry(3, 0.02, inner).translate(cx, SIDEWALK_H + 0.01, cz), pathCol), cx, cz);
        addGeo('misc', colored(new THREE.CylinderGeometry(7, 7, 0.05, 20).translate(cx + 14, SIDEWALK_H + 0.02, cz - 14), waterCol), cx, cz);
        addGeo('misc', colored(new THREE.TorusGeometry(7.2, 0.35, 6, 24).rotateX(Math.PI / 2).translate(cx + 14, SIDEWALK_H + 0.15, cz - 14), pathCol), cx, cz);
        for (let k = 0; k < 26; k++) {
          const tx = ix0 + 3 + rnd() * (inner - 6);
          const tz = iz0 + 3 + rnd() * (inner - 6);
          if (Math.abs(tx - cx) < 2.5 || Math.abs(tz - cz) < 2.5) continue;
          if (Math.hypot(tx - (cx + 14), tz - (cz - 14)) < 9) continue;
          addProp('tree', tx, SIDEWALK_H, tz, rnd() * 6, 0.8 + rnd() * 0.6);
        }
        for (let k = 0; k < 6; k++) {
          const along = rnd() < 0.5;
          const t = (rnd() - 0.5) * (inner - 10);
          addProp('bench', along ? cx + t : cx - 2.4, SIDEWALK_H, along ? cz - 2.4 : cz + t, along ? 0 : Math.PI / 2);
        }
        for (let k = 0; k < 4; k++) addProp('lamp', ix0 + 6 + k * 15, SIDEWALK_H, cz + 3, 0, 0.6);
      } else if (type === 'K') {
        // parking lot: parked cars + lamps
        for (let k = 0; k < 5; k++) {
          const row = Math.floor(rnd() * 3);
          const tileZ = iz0 + row * 16 + (rnd() < 0.5 ? 5.25 : 10.75);
          const stall = Math.floor(rnd() * 20);
          const px = ix0 + 1.35 + stall * 2.7;
          if (px > ix0 + inner - 2) continue;
          parked.push({ x: px, z: tileZ, heading: rnd() < 0.5 ? 0 : Math.PI });
        }
        addProp('lamp', ix0 + 10, SIDEWALK_H, cz, Math.PI / 2, 0.85);
        addProp('lamp', ix0 + inner - 10, SIDEWALK_H, cz, -Math.PI / 2, 0.85);
        // ticket booth
        const booth = new THREE.BoxGeometry(3, 3, 3);
        boxUV(booth, 3, 3, 3, 1);
        booth.translate(ix0 + 2.5, SIDEWALK_H + 1.5, iz0 + 2.5);
        addGeo('facade1', booth, ix0 + 2.5, iz0 + 2.5);
        colliders.push({ minX: ix0 + 1, maxX: ix0 + 4, minZ: iz0 + 1, maxZ: iz0 + 4 });
      }
    }
  }

  // ---------- Street lamps, signs, traffic lights ----------
  const signKinds = ['sign0', 'sign1', 'sign2', 'sign3'];
  for (let i = 0; i < NR; i++) {
    const c = roadCoord(i);
    for (let j = 0; j < NB; j++) {
      const a = roadCoord(j) + HALF_ROAD;
      for (let s = 10; s < BLOCK - 4; s += 22) {
        const p = a + s;
        // vertical road (along z) at x=c
        addProp('lamp', c - 7.8, SIDEWALK_H, p, Math.PI / 2);
        addProp('lamp', c + 7.8, SIDEWALK_H, p + 11, -Math.PI / 2);
        // horizontal road at z=c
        addProp('lamp', p, SIDEWALK_H, c - 7.8, 0);
        addProp('lamp', p + 11, SIDEWALK_H, c + 7.8, Math.PI);
      }
      // mid-segment signs
      if (rnd() < 0.45) {
        const k = signKinds[1 + Math.floor(rnd() * 2)];
        addProp(k, c - 7.6, SIDEWALK_H, a + 20 + rnd() * 24, Math.PI);
      }
      if (rnd() < 0.45) {
        const k = signKinds[1 + Math.floor(rnd() * 2)];
        addProp(k, a + 20 + rnd() * 24, SIDEWALK_H, c + 7.6, -Math.PI / 2);
      }
    }
  }

  // traffic lights at intersections; bulbs are one instanced mesh
  const tlPositions: { x: number; z: number; ry: number; ns: boolean }[] = [];
  for (let i = 0; i < NR; i++)
    for (let j = 0; j < NR; j++) {
      const cx = roadCoord(i);
      const cz = roadCoord(j);
      const isOuter = i === 0 || j === 0 || i === NR - 1 || j === NR - 1;
      const neighborsRes =
        !isOuter &&
        [blockType(i - 1, j - 1), blockType(i, j - 1), blockType(i - 1, j), blockType(i, j)].every((t) => t === 'R' || t === 'P');
      if (neighborsRes) {
        // quiet residential crossing: stop signs
        addProp('sign0', cx - 7.6, SIDEWALK_H, cz - 8.6, Math.PI);
        addProp('sign0', cx + 7.6, SIDEWALK_H, cz + 8.6, 0);
        addProp('sign0', cx + 8.6, SIDEWALK_H, cz + 7.6, -Math.PI / 2);
        addProp('sign0', cx - 8.6, SIDEWALK_H, cz - 7.6, Math.PI / 2);
        continue;
      }
      tlPositions.push({ x: cx - 7.6, z: cz + 7.6, ry: Math.PI, ns: true });
      tlPositions.push({ x: cx + 7.6, z: cz - 7.6, ry: 0, ns: true });
      tlPositions.push({ x: cx + 7.6, z: cz + 7.6, ry: -Math.PI / 2, ns: false });
      tlPositions.push({ x: cx - 7.6, z: cz - 7.6, ry: Math.PI / 2, ns: false });
    }
  for (const t of tlPositions) addProp('tlight', t.x, SIDEWALK_H, t.z, t.ry);

  // ring road lamps + barriers + green belt trees
  for (let p = -RING_OUT + 18; p < RING_OUT - 10; p += 36) {
    addProp('lamp', RING_OUT + 0.8, 0, p, -Math.PI / 2);
    addProp('lamp', -RING_OUT - 0.8, 0, p + 18, Math.PI / 2);
    addProp('lamp', p, 0, RING_OUT + 0.8, Math.PI);
    addProp('lamp', p + 18, 0, -RING_OUT - 0.8, 0);
  }
  for (let p = -RING_OUT; p < RING_OUT; p += 3.05) {
    const skip = Math.abs(p - 60) < 8 || Math.abs(p - 170) < 8 || Math.abs(p + 80) < 8 || Math.abs(p + 200) < 8; // trail exits
    if (!skip) {
      if (Math.abs(p) > 30) addProp('barrier', RING_OUT + 0.4, 0, p, 0);
      if (Math.abs(p) > 30) addProp('barrier', -RING_OUT - 0.4, 0, p, 0);
    }
    if (Math.abs(p) > 30) {
      addProp('barrier', p, 0, RING_OUT + 0.4, Math.PI / 2);
      addProp('barrier', p, 0, -RING_OUT - 0.4, Math.PI / 2);
    }
  }
  for (let k = 0; k < 90; k++) {
    const side = Math.floor(rnd() * 4);
    const along = -CITY_HALF + rnd() * CITY_HALF * 2;
    const off = CITY_HALF + 6 + rnd() * 16;
    const x = side === 0 ? off : side === 1 ? -off : along;
    const z = side === 2 ? off : side === 3 ? -off : along;
    // skip road extensions
    const u = x - GRID0, v = z - GRID0;
    const nearRoadX = Math.abs(u - Math.round(u / PITCH) * PITCH) < 9;
    const nearRoadZ = Math.abs(v - Math.round(v / PITCH) * PITCH) < 9;
    if ((side < 2 && nearRoadZ) || (side >= 2 && nearRoadX)) continue;
    addProp('tree', x, -0.03, z, rnd() * 6, 0.9 + rnd() * 0.5);
  }
  // hills trees
  for (let k = 0; k < 420; k++) {
    const x = (rnd() - 0.5) * 2 * (WORLD_HALF - 40);
    const z = (rnd() - 0.5) * 2 * (WORLD_HALF - 40);
    const d = Math.max(Math.abs(x), Math.abs(z));
    if (d < RING_OUT + 12) continue;
    if (TRAILS.some((t) => trailDistance(x, z, t) < t.width / 2 + 3)) continue;
    const h = heightAt(x, z);
    addProp(rnd() < 0.7 ? 'pine' : 'tree', x, h - 0.1, z, rnd() * 6, 0.9 + rnd() * 0.8);
  }
  // rally-side barriers along the trails at a few spots
  for (const t of TRAILS) {
    for (let i = 30; i < t.samples.length / 2 - 30; i += 45) {
      for (let k = 0; k < 5; k++) {
        const idx = (i + k * 2) * 2;
        const x = t.samples[idx], z = t.samples[idx + 1];
        const nx = t.samples[idx + 2] - x, nz = t.samples[idx + 3] - z;
        const l = Math.hypot(nx, nz) || 1;
        const px = -nz / l, pz = nx / l;
        const bx = x + px * (t.width / 2 + 1), bz = z + pz * (t.width / 2 + 1);
        addProp('barrier', bx, heightAt(bx, bz), bz, Math.atan2(nx, nz));
      }
    }
  }

  // ---------- Build meshes ----------
  const buildBucket = (bucket: GeoBucket, out: THREE.Object3D[]) => {
    for (const [key, list] of bucket.lists) {
      const geo = merge(list);
      if (!geo) continue;
      const mesh = new THREE.Mesh(geo, matByKey[key]);
      mesh.receiveShadow = shadows;
      mesh.castShadow = shadows && key.startsWith('facade');
      mesh.matrixAutoUpdate = false;
      group.add(mesh);
      out.push(mesh);
    }
  };
  const globalObjs: THREE.Object3D[] = [];
  buildBucket(global, globalObjs);

  const props = propGeometries(tex);
  const chunks: Chunk[] = [];
  const tmpColor = new THREE.Color();
  chunkGeo.forEach((bucket, idx) => {
    const chunk: Chunk = { center: chunkCenters[idx], radius: chunkRadius[idx], main: [], props: [] };
    buildBucket(bucket, chunk.main);
    const pb = chunkProps[idx];
    for (const [key, mats] of pb.items) {
      const def = props.defs[key];
      if (!def) continue;
      const im = new THREE.InstancedMesh(def.geo, def.mat, mats.length);
      mats.forEach((m, i) => im.setMatrixAt(i, m));
      const cols = pb.colors.get(key);
      if (key === 'tree' || key === 'pine') {
        for (let i = 0; i < mats.length; i++) {
          const v = 0.8 + rnd() * 0.4;
          im.setColorAt(i, tmpColor.setRGB(v * (0.9 + rnd() * 0.2), v, v * 0.9));
        }
      } else if (cols) cols.forEach((c, i) => im.setColorAt(i, c));
      im.castShadow = shadows && key !== 'lampHead';
      im.receiveShadow = false;
      im.instanceMatrix.needsUpdate = true;
      group.add(im);
      chunk.props.push(im);
      if (key === 'lamp') {
        const heads = new THREE.InstancedMesh(props.defs.lampHead.geo, props.defs.lampHead.mat, mats.length);
        mats.forEach((m, i) => heads.setMatrixAt(i, m));
        heads.instanceMatrix.needsUpdate = true;
        group.add(heads);
        chunk.props.push(heads);
      }
    }
    chunks.push(chunk);
  });

  // traffic bulbs
  const bulbCount = tlPositions.length * 3;
  const bulbMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const bulbs = new THREE.InstancedMesh(props.bulb, bulbMat, bulbCount);
  const trafficPhaseA: boolean[] = [];
  const trafficIsRed: boolean[] = [];
  const m4 = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const v3 = new THREE.Vector3();
  tlPositions.forEach((t, i) => {
    q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), t.ry);
    for (let k = 0; k < 3; k++) {
      const local = new THREE.Vector3(0, SIDEWALK_H + 3.9 - k * 0.32, 0.3).applyQuaternion(q);
      v3.set(t.x + local.x, local.y, t.z + local.z);
      m4.compose(v3, q, new THREE.Vector3(1, 1, 1));
      bulbs.setMatrixAt(i * 3 + k, m4);
      trafficPhaseA.push(t.ns);
      trafficIsRed.push(k === 0);
      if (k === 1) bulbs.setColorAt(i * 3 + k, tmpColor.setRGB(0.3, 0.22, 0.05));
    }
  });
  bulbs.instanceMatrix.needsUpdate = true;
  group.add(bulbs);

  return {
    group,
    chunks,
    colliders,
    parked,
    lampHeadMat: props.lampHeadMat,
    facadeMats,
    roadMats: [roadMat, interMat, hwyMat, parkingMat],
    trafficLamps: bulbs,
    trafficPhaseA,
    trafficIsRed,
  };
}

export { FLAT_R };
