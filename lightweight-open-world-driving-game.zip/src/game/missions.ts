import type { MissionDef } from './types';
import { TRAILS, roadCoord } from './world';

const R = roadCoord; // road index -> coordinate (0..6)

export const MISSIONS: (MissionDef & { start: [number, number] })[] = [
  {
    id: 'sprint',
    name: 'Downtown Sprint',
    type: 'sprint',
    description: 'A quick blast through the towers. Hit every checkpoint in order.',
    start: [R(3) - 1.75, -215],
    startHeading: 0,
    points: [[R(3), R(2)], [R(4), R(2)], [R(4), R(4)], [R(3), R(4)], [R(2), R(4)], [R(2), R(5)], [R(3), R(5)], [R(3) - 1.75, 232]],
    par: 75,
  },
  {
    id: 'ring',
    name: 'Ring Road Time Trial',
    type: 'trial',
    description: 'One full lap of the concrete ring highway. Keep it flat out.',
    start: [278, -200],
    startHeading: 0,
    points: [[275, 0], [275, 275], [0, 275], [-275, 275], [-275, 0], [-275, -275], [0, -275], [275, -275], [278, -205]],
    par: 130,
  },
  {
    id: 'rally',
    name: 'Hillside Rally',
    type: 'rally',
    description: 'Dirt, dust and blind crests. Follow the trail through the eastern hills.',
    start: [258, 60],
    startHeading: Math.PI / 2,
    points: TRAILS[0].control.slice(1).map(([x, z]) => [x, z] as [number, number]),
    par: 120,
  },
  {
    id: 'gravel',
    name: 'Quarry Gravel Loop',
    type: 'rally',
    description: 'A loose gravel run around the western quarry. Brake early, slide late.',
    start: [258, -80],
    startHeading: -Math.PI / 2,
    points: TRAILS[1].control.slice(1).map(([x, z]) => [x, z] as [number, number]),
    par: 120,
  },
  {
    id: 'courier',
    name: 'Courier Run',
    type: 'delivery',
    description: 'Four drop-offs across the city. Pick your own route between them.',
    start: [R(4) - 1.75, R(1) + 20],
    startHeading: 0,
    points: [[R(4), R(3)], [R(1), R(5)], [R(0), R(1)], [R(5), R(0)], [R(6), R(4)]],
    par: 170,
  },
  {
    id: 'tour',
    name: 'Grand City Tour',
    type: 'tour',
    description: 'The long one. Every district, the ring road, and back downtown.',
    start: [R(0) - 1.75, R(0) - 20],
    startHeading: 0,
    points: [
      [R(0), R(2)], [R(1), R(2)], [R(1), R(4)], [R(0), R(4)], [R(0), R(6)], [R(2), R(6)], [R(2), R(3)], [R(3), R(1)],
      [R(5), R(1)], [R(6), R(2)], [R(6), R(5)], [R(4), R(6)], [R(4), R(4)], [R(3), R(3)],
    ],
    par: 260,
  },
];

export const MISSION_START_RADIUS = 7.5;
