/** Tiny procedural engine sound – no audio assets needed. */
export class EngineAudio {
  private ctx: AudioContext | null = null;
  private osc: OscillatorNode | null = null;
  private osc2: OscillatorNode | null = null;
  private gain: GainNode | null = null;
  private filter: BiquadFilterNode | null = null;
  private noise: AudioBufferSourceNode | null = null;
  private noiseGain: GainNode | null = null;
  enabled = true;
  private started = false;

  start() {
    if (this.started) return;
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC();
      const ctx = this.ctx;
      this.gain = ctx.createGain();
      this.gain.gain.value = 0;
      this.filter = ctx.createBiquadFilter();
      this.filter.type = 'lowpass';
      this.filter.frequency.value = 600;
      this.osc = ctx.createOscillator();
      this.osc.type = 'sawtooth';
      this.osc2 = ctx.createOscillator();
      this.osc2.type = 'square';
      const g2 = ctx.createGain();
      g2.gain.value = 0.35;
      this.osc.connect(this.filter);
      this.osc2.connect(g2).connect(this.filter);
      this.filter.connect(this.gain).connect(ctx.destination);
      this.osc.start();
      this.osc2.start();
      // tyre/road noise
      const len = ctx.sampleRate * 1;
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * 0.5;
      this.noise = ctx.createBufferSource();
      this.noise.buffer = buf;
      this.noise.loop = true;
      this.noiseGain = ctx.createGain();
      this.noiseGain.gain.value = 0;
      const nf = ctx.createBiquadFilter();
      nf.type = 'bandpass';
      nf.frequency.value = 900;
      this.noise.connect(nf).connect(this.noiseGain).connect(ctx.destination);
      this.noise.start();
      this.started = true;
    } catch {
      this.started = false;
    }
  }

  update(rpm: number, throttle: number, speed: number, slipping: boolean) {
    if (!this.started || !this.ctx || !this.osc || !this.osc2 || !this.gain || !this.filter || !this.noiseGain) return;
    const t = this.ctx.currentTime;
    const on = this.enabled;
    const f = 45 + rpm * 190;
    this.osc.frequency.setTargetAtTime(f, t, 0.05);
    this.osc2.frequency.setTargetAtTime(f * 0.5, t, 0.05);
    this.filter.frequency.setTargetAtTime(400 + rpm * 1400 + throttle * 600, t, 0.08);
    const vol = on ? 0.05 + rpm * 0.08 + throttle * 0.05 : 0;
    this.gain.gain.setTargetAtTime(vol, t, 0.08);
    const nv = on ? Math.min(0.12, speed * 0.0025) + (slipping ? 0.08 : 0) : 0;
    this.noiseGain.gain.setTargetAtTime(nv, t, 0.1);
  }

  setEnabled(v: boolean) {
    this.enabled = v;
    if (this.ctx && v && this.ctx.state === 'suspended') this.ctx.resume();
  }

  dispose() {
    try {
      this.osc?.stop();
      this.osc2?.stop();
      this.noise?.stop();
      this.ctx?.close();
    } catch {
      /* ignore */
    }
    this.started = false;
  }
}
