import * as THREE from 'three';

type Draw = (ctx: CanvasRenderingContext2D, size: number) => void;

function canvasTex(size: number, draw: Draw, opts: { srgb?: boolean; repeat?: boolean; nearest?: boolean } = {}) {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d')!;
  draw(ctx, size);
  const t = new THREE.CanvasTexture(c);
  if (opts.srgb !== false) t.colorSpace = THREE.SRGBColorSpace;
  if (opts.repeat !== false) {
    t.wrapS = THREE.RepeatWrapping;
    t.wrapT = THREE.RepeatWrapping;
  }
  if (opts.nearest) {
    t.magFilter = THREE.NearestFilter;
  }
  t.anisotropy = 4;
  t.needsUpdate = true;
  return t;
}

/** cheap deterministic noise sprinkle */
function speckle(ctx: CanvasRenderingContext2D, size: number, count: number, colors: string[], maxR = 1.5, seed = 1) {
  let s = seed;
  const rnd = () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
  for (let i = 0; i < count; i++) {
    ctx.fillStyle = colors[Math.floor(rnd() * colors.length)];
    const r = 0.5 + rnd() * maxR;
    ctx.fillRect(rnd() * size, rnd() * size, r, r);
  }
}

function asphaltBase(ctx: CanvasRenderingContext2D, size: number, base = '#3b3b3f') {
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, size, size);
  speckle(ctx, size, 9000, ['#2d2d31', '#48484c', '#525257', '#333336', '#5a5a5e'], 2.2, 7);
  // faint tire wear bands
  const g = ctx.createLinearGradient(0, 0, size, 0);
  g.addColorStop(0, 'rgba(0,0,0,0)');
  g.addColorStop(0.18, 'rgba(0,0,0,0.12)');
  g.addColorStop(0.32, 'rgba(0,0,0,0)');
  g.addColorStop(0.68, 'rgba(0,0,0,0)');
  g.addColorStop(0.82, 'rgba(0,0,0,0.12)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
}

export interface TextureSet {
  road: THREE.Texture;
  intersection: THREE.Texture;
  highway: THREE.Texture;
  sidewalk: THREE.Texture;
  plaza: THREE.Texture;
  dirt: THREE.Texture;
  gravel: THREE.Texture;
  parking: THREE.Texture;
  grass: THREE.Texture;
  roof: THREE.Texture;
  facades: { map: THREE.Texture; emissive: THREE.Texture }[];
  signs: THREE.Texture[];
  rain: THREE.Texture;
  rim: THREE.Texture;
  glow: THREE.Texture;
}

/** 14m x 14m 4-lane road strip. Road runs along V axis. */
function drawRoad(ctx: CanvasRenderingContext2D, size: number) {
  asphaltBase(ctx, size);
  const m = size / 14; // px per metre
  // edge lines
  ctx.fillStyle = '#d8d8d0';
  ctx.fillRect(0.35 * m, 0, 0.14 * m, size);
  ctx.fillRect(size - 0.49 * m, 0, 0.14 * m, size);
  // double yellow center
  ctx.fillStyle = '#e0b43a';
  ctx.fillRect(size / 2 - 0.22 * m, 0, 0.13 * m, size);
  ctx.fillRect(size / 2 + 0.09 * m, 0, 0.13 * m, size);
  // dashed lane dividers at 3.5m from each side
  ctx.fillStyle = '#e4e4de';
  const dash = 3 * m;
  const period = 7 * m;
  for (const x of [3.5 * m, 10.5 * m]) {
    for (let y = 0; y < size; y += period) ctx.fillRect(x - 0.07 * m, y, 0.14 * m, dash);
  }
  // manhole
  ctx.fillStyle = '#2a2a2c';
  ctx.beginPath();
  ctx.arc(2 * m, 9 * m, 0.45 * m, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#555';
  ctx.lineWidth = 2;
  ctx.stroke();
}

function drawIntersection(ctx: CanvasRenderingContext2D, size: number) {
  asphaltBase(ctx, size);
  const m = size / 14;
  ctx.fillStyle = '#e4e4de';
  // zebra crosswalks on all four sides
  const band = 2.6 * m;
  const stripeW = 0.55 * m;
  const gap = 0.55 * m;
  const inset = 0.6 * m;
  for (let s = 1.6 * m; s < size - 1.6 * m; s += stripeW + gap) {
    ctx.fillRect(s, inset, stripeW, band); // top
    ctx.fillRect(s, size - inset - band, stripeW, band); // bottom
    ctx.fillRect(inset, s, band, stripeW); // left
    ctx.fillRect(size - inset - band, s, band, stripeW); // right
  }
  // stop lines
  ctx.fillStyle = '#f0f0ea';
  ctx.fillRect(size / 2, inset + band + 0.3 * m, size / 2 - 1.5 * m, 0.35 * m);
  ctx.fillRect(1.5 * m, size - inset - band - 0.65 * m, size / 2 - 1.5 * m, 0.35 * m);
  ctx.fillRect(inset + band + 0.3 * m, 1.5 * m, 0.35 * m, size / 2 - 1.5 * m);
  ctx.fillRect(size - inset - band - 0.65 * m, size / 2, 0.35 * m, size / 2 - 1.5 * m);
}

/** 12m wide 2-lane concrete highway, runs along V */
function drawHighway(ctx: CanvasRenderingContext2D, size: number) {
  ctx.fillStyle = '#7d7c78';
  ctx.fillRect(0, 0, size, size);
  speckle(ctx, size, 7000, ['#6f6e6a', '#8a8985', '#75746f', '#93928e'], 2, 3);
  const m = size / 12;
  // expansion joints
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  for (let y = 0; y < size; y += 6 * m) ctx.fillRect(0, y, size, 3);
  ctx.fillStyle = 'rgba(0,0,0,0.25)';
  ctx.fillRect(size / 2 - 1, 0, 2, size);
  // markings
  ctx.fillStyle = '#e6e6e0';
  ctx.fillRect(0.5 * m, 0, 0.15 * m, size);
  ctx.fillRect(size - 0.65 * m, 0, 0.15 * m, size);
  for (let y = 0; y < size; y += 6 * m) ctx.fillRect(size / 2 - 0.08 * m, y, 0.16 * m, 3 * m);
}

function drawSidewalk(ctx: CanvasRenderingContext2D, size: number) {
  ctx.fillStyle = '#a9a69e';
  ctx.fillRect(0, 0, size, size);
  speckle(ctx, size, 5000, ['#9c9991', '#b5b2aa', '#a19e96', '#bcb9b1'], 2, 11);
  ctx.strokeStyle = 'rgba(60,55,50,0.45)';
  ctx.lineWidth = 2;
  const n = 4; // 4m tile => 1m squares
  for (let i = 0; i <= n; i++) {
    const p = (i * size) / n;
    ctx.beginPath();
    ctx.moveTo(p, 0);
    ctx.lineTo(p, size);
    ctx.moveTo(0, p);
    ctx.lineTo(size, p);
    ctx.stroke();
  }
}

function drawPlaza(ctx: CanvasRenderingContext2D, size: number) {
  ctx.fillStyle = '#8d8a84';
  ctx.fillRect(0, 0, size, size);
  speckle(ctx, size, 5000, ['#7f7c76', '#9a9791', '#868380'], 2, 5);
  ctx.strokeStyle = 'rgba(40,40,40,0.4)';
  ctx.lineWidth = 3;
  const n = 2;
  for (let i = 0; i <= n; i++) {
    const p = (i * size) / n;
    ctx.beginPath();
    ctx.moveTo(p, 0);
    ctx.lineTo(p, size);
    ctx.moveTo(0, p);
    ctx.lineTo(size, p);
    ctx.stroke();
  }
}

function drawDirt(ctx: CanvasRenderingContext2D, size: number) {
  ctx.fillStyle = '#7a5f42';
  ctx.fillRect(0, 0, size, size);
  speckle(ctx, size, 9000, ['#6b5238', '#8a6d4e', '#5e4730', '#96795a', '#725a3f'], 2.5, 21);
  // two wheel ruts along V
  const g1 = ctx.createLinearGradient(0, 0, size, 0);
  g1.addColorStop(0, 'rgba(0,0,0,0)');
  g1.addColorStop(0.22, 'rgba(40,25,10,0.35)');
  g1.addColorStop(0.3, 'rgba(0,0,0,0)');
  g1.addColorStop(0.7, 'rgba(0,0,0,0)');
  g1.addColorStop(0.78, 'rgba(40,25,10,0.35)');
  g1.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g1;
  ctx.fillRect(0, 0, size, size);
  // grass strip in the middle
  ctx.fillStyle = 'rgba(70,90,40,0.25)';
  ctx.fillRect(size * 0.45, 0, size * 0.1, size);
}

function drawGravel(ctx: CanvasRenderingContext2D, size: number) {
  ctx.fillStyle = '#8d8779';
  ctx.fillRect(0, 0, size, size);
  speckle(ctx, size, 14000, ['#7b7568', '#a09a8b', '#6c665a', '#b3ad9e', '#8a8477'], 3, 33);
}

function drawParking(ctx: CanvasRenderingContext2D, size: number) {
  asphaltBase(ctx, size, '#414145');
  // 16m x 16m: stalls 2.7m wide, 5.5m deep, double row in middle
  const m = size / 16;
  ctx.fillStyle = '#e0e0da';
  for (let x = 0; x < size; x += 2.7 * m) {
    ctx.fillRect(x, 2.5 * m, 0.12 * m, 5.5 * m);
    ctx.fillRect(x, 8 * m, 0.12 * m, 5.5 * m);
  }
  ctx.fillRect(0, 8 * m - 0.06 * m, size, 0.12 * m);
}

function drawGrass(ctx: CanvasRenderingContext2D, size: number) {
  ctx.fillStyle = '#5c8a3a';
  ctx.fillRect(0, 0, size, size);
  speckle(ctx, size, 12000, ['#4f7c30', '#6a9a44', '#57853a', '#7aa34f', '#476f2a'], 2.5, 17);
}

function drawRoof(ctx: CanvasRenderingContext2D, size: number) {
  ctx.fillStyle = '#6a6762';
  ctx.fillRect(0, 0, size, size);
  speckle(ctx, size, 5000, ['#5f5c58', '#767370', '#56534f'], 2, 9);
}

interface FacadeStyle {
  wall: string;
  wallAlt: string;
  frame: string;
  glass: string;
  glassAlt: string;
  cols: number; // windows per 8m
  rows: number; // floors per 7m (2 floors)
  winW: number; // fraction
  winH: number;
  litChance: number;
  ledge?: boolean;
}

const FACADES: FacadeStyle[] = [
  // 0: modern glass tower
  { wall: '#2f3d4c', wallAlt: '#3a4a5a', frame: '#1c2530', glass: '#6f9dc0', glassAlt: '#5580a3', cols: 4, rows: 2, winW: 0.82, winH: 0.72, litChance: 0.55 },
  // 1: beige office
  { wall: '#b8a98f', wallAlt: '#a8987c', frame: '#5c5245', glass: '#4d6e8a', glassAlt: '#3c5a74', cols: 3, rows: 2, winW: 0.55, winH: 0.55, litChance: 0.4, ledge: true },
  // 2: red brick
  { wall: '#8a4a3a', wallAlt: '#7a3f31', frame: '#3b2a25', glass: '#5a7086', glassAlt: '#485c70', cols: 3, rows: 2, winW: 0.45, winH: 0.6, litChance: 0.35, ledge: true },
  // 3: stucco residential
  { wall: '#d9cdb4', wallAlt: '#cabc9f', frame: '#6b5a48', glass: '#3f5b73', glassAlt: '#34506a', cols: 2, rows: 2, winW: 0.4, winH: 0.5, litChance: 0.45 },
  // 4: dark concrete brutalist
  { wall: '#5f6063', wallAlt: '#54555a', frame: '#2c2d30', glass: '#7e97ab', glassAlt: '#6a8398', cols: 4, rows: 2, winW: 0.6, winH: 0.45, litChance: 0.3, ledge: true },
];

function drawFacade(style: FacadeStyle, emissive: boolean, seed: number): Draw {
  return (ctx, size) => {
    let s = seed;
    const rnd = () => {
      s = (s * 16807) % 2147483647;
      return (s - 1) / 2147483646;
    };
    ctx.fillStyle = emissive ? '#000' : style.wall;
    ctx.fillRect(0, 0, size, size);
    if (!emissive) {
      speckle(ctx, size, 3000, [style.wallAlt, style.wall], 3, seed);
      if (style.wall === '#8a4a3a') {
        // brick courses
        ctx.fillStyle = 'rgba(0,0,0,0.18)';
        for (let y = 0; y < size; y += 8) ctx.fillRect(0, y, size, 1.5);
      }
    }
    const cw = size / style.cols;
    const rh = size / style.rows;
    for (let r = 0; r < style.rows; r++) {
      for (let c = 0; c < style.cols; c++) {
        const ww = cw * style.winW;
        const wh = rh * style.winH;
        const x = c * cw + (cw - ww) / 2;
        const y = r * rh + (rh - wh) / 2;
        if (emissive) {
          const lit = rnd() < style.litChance;
          if (lit) {
            const warm = rnd() > 0.3;
            ctx.fillStyle = warm ? `rgb(${230 + rnd() * 25},${190 + rnd() * 40},${110 + rnd() * 60})` : '#b9d8ff';
            ctx.fillRect(x, y, ww, wh);
          }
        } else {
          ctx.fillStyle = style.frame;
          ctx.fillRect(x - 2, y - 2, ww + 4, wh + 4);
          const g = ctx.createLinearGradient(x, y, x + ww, y + wh);
          g.addColorStop(0, style.glass);
          g.addColorStop(1, style.glassAlt);
          ctx.fillStyle = g;
          ctx.fillRect(x, y, ww, wh);
          // reflection streak
          ctx.fillStyle = 'rgba(255,255,255,0.18)';
          ctx.fillRect(x + ww * 0.1, y + 2, ww * 0.25, wh - 4);
          // mullion
          ctx.fillStyle = style.frame;
          ctx.fillRect(x + ww / 2 - 1, y, 2, wh);
        }
      }
      if (style.ledge && !emissive) {
        ctx.fillStyle = 'rgba(0,0,0,0.25)';
        ctx.fillRect(0, (r + 1) * rh - 4, size, 4);
      }
    }
  };
}

function drawSign(kind: 'stop' | 'speed' | 'oneway' | 'yield'): Draw {
  return (ctx, size) => {
    // bottom 12% is grey pole strip (UV mapped to pole geometry)
    ctx.clearRect(0, 0, size, size);
    ctx.fillStyle = '#8d939a';
    ctx.fillRect(0, 0, size, size);
    const c = size / 2;
    const r = size * 0.42;
    ctx.save();
    ctx.translate(c, c * 0.9);
    if (kind === 'stop') {
      ctx.fillStyle = '#c8202a';
      ctx.beginPath();
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2 + Math.PI / 8;
        ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
      }
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = size * 0.03;
      ctx.stroke();
      ctx.fillStyle = '#fff';
      ctx.font = `bold ${size * 0.26}px Arial`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('STOP', 0, 0);
    } else if (kind === 'speed') {
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(0, 0, r, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#d02030';
      ctx.lineWidth = size * 0.08;
      ctx.stroke();
      ctx.fillStyle = '#111';
      ctx.font = `bold ${size * 0.36}px Arial`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('50', 0, 0);
    } else if (kind === 'oneway') {
      ctx.fillStyle = '#111';
      ctx.fillRect(-r, -r * 0.45, r * 2, r * 0.9);
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.moveTo(-r * 0.8, 0);
      ctx.lineTo(r * 0.2, -r * 0.3);
      ctx.lineTo(r * 0.2, -r * 0.12);
      ctx.lineTo(r * 0.8, -r * 0.12);
      ctx.lineTo(r * 0.8, r * 0.12);
      ctx.lineTo(r * 0.2, r * 0.12);
      ctx.lineTo(r * 0.2, r * 0.3);
      ctx.closePath();
      ctx.fill();
    } else {
      ctx.fillStyle = '#d02030';
      ctx.beginPath();
      ctx.moveTo(-r, -r * 0.8);
      ctx.lineTo(r, -r * 0.8);
      ctx.lineTo(0, r);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.moveTo(-r * 0.65, -r * 0.6);
      ctx.lineTo(r * 0.65, -r * 0.6);
      ctx.lineTo(0, r * 0.55);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  };
}

function drawRain(ctx: CanvasRenderingContext2D, size: number) {
  ctx.clearRect(0, 0, size, size);
  const g = ctx.createLinearGradient(0, 0, 0, size);
  g.addColorStop(0, 'rgba(255,255,255,0)');
  g.addColorStop(0.5, 'rgba(220,235,255,0.9)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(size * 0.44, 0, size * 0.12, size);
}

function drawRim(ctx: CanvasRenderingContext2D, size: number) {
  const c = size / 2;
  ctx.fillStyle = '#151515';
  ctx.fillRect(0, 0, size, size);
  // tire sidewall ring
  ctx.fillStyle = '#1e1e1e';
  ctx.beginPath();
  ctx.arc(c, c, c * 0.98, 0, Math.PI * 2);
  ctx.fill();
  // rim
  ctx.fillStyle = '#c9ccd1';
  ctx.beginPath();
  ctx.arc(c, c, c * 0.66, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#2a2d31';
  ctx.beginPath();
  ctx.arc(c, c, c * 0.58, 0, Math.PI * 2);
  ctx.fill();
  // spokes
  ctx.fillStyle = '#d5d8dd';
  for (let i = 0; i < 6; i++) {
    ctx.save();
    ctx.translate(c, c);
    ctx.rotate((i / 6) * Math.PI * 2);
    ctx.beginPath();
    ctx.moveTo(-c * 0.07, 0);
    ctx.lineTo(-c * 0.12, -c * 0.6);
    ctx.lineTo(c * 0.12, -c * 0.6);
    ctx.lineTo(c * 0.07, 0);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.fillStyle = '#9ea3aa';
  ctx.beginPath();
  ctx.arc(c, c, c * 0.14, 0, Math.PI * 2);
  ctx.fill();
}

function drawGlow(ctx: CanvasRenderingContext2D, size: number) {
  ctx.clearRect(0, 0, size, size);
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.25, 'rgba(255,255,255,0.6)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
}

export function createRimTexture() {
  return canvasTex(128, drawRim, { repeat: false });
}

export function createTextures(anisotropy: number): TextureSet {
  const set: TextureSet = {
    road: canvasTex(512, drawRoad),
    intersection: canvasTex(512, drawIntersection),
    highway: canvasTex(512, drawHighway),
    sidewalk: canvasTex(256, drawSidewalk),
    plaza: canvasTex(256, drawPlaza),
    dirt: canvasTex(256, drawDirt),
    gravel: canvasTex(256, drawGravel),
    parking: canvasTex(512, drawParking),
    grass: canvasTex(256, drawGrass),
    roof: canvasTex(128, drawRoof),
    facades: FACADES.map((f, i) => ({
      map: canvasTex(256, drawFacade(f, false, 100 + i)),
      emissive: canvasTex(256, drawFacade(f, true, 100 + i)),
    })),
    signs: [
      canvasTex(128, drawSign('stop'), { repeat: false }),
      canvasTex(128, drawSign('speed'), { repeat: false }),
      canvasTex(128, drawSign('oneway'), { repeat: false }),
      canvasTex(128, drawSign('yield'), { repeat: false }),
    ],
    rain: canvasTex(32, drawRain, { repeat: false }),
    rim: canvasTex(128, drawRim, { repeat: false }),
    glow: canvasTex(64, drawGlow, { repeat: false }),
  };
  const all: THREE.Texture[] = [
    set.road, set.intersection, set.highway, set.sidewalk, set.plaza, set.dirt, set.gravel,
    set.parking, set.grass, set.roof, ...set.facades.flatMap((f) => [f.map, f.emissive]),
  ];
  for (const t of all) t.anisotropy = anisotropy;
  return set;
}
