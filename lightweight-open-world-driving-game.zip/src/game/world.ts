import * as THREE from 'three';

// ---------- Layout constants ----------
export const PITCH = 78;
export const ROAD_W = 14;
export const HALF_ROAD = ROAD_W / 2;
export const BLOCK = PITCH - ROAD_W; // 64
export const NB = 6; // blocks per side
export const NR = NB + 1; // roads per side
export const GRID0 = -(NB / 2) * PITCH; // -234
export const CITY_HALF = -GRID0 + HALF_ROAD; // 241
export const RING_R = 275;
export const RING_W = 12;
export const RING_IN = RING_R - RING_W / 2; // 269
export const RING_OUT = RING_R + RING_W / 2; // 281
export const FLAT_R = 300;
export const WORLD_HALF = 720;
export const SIDEWALK_W = 3;
export const SIDEWALK_H = 0.15;

export const roadCoord = (i: number) => GRID0 + i * PITCH;

// ---------- Block map ----------
// D downtown, M midrise, R residential, P park, K parking
export type BlockType = 'D' | 'M' | 'R' | 'P' | 'K';
const MAP_ROWS = [
  'RRMPRR',
  'RMMMKR',
  'MMDDMR',
  'RMDDMK',
  'KMMMRR',
  'RRPMRR',
];
export function blockType(bi: number, bj: number): BlockType {
  return MAP_ROWS[bj][bi] as BlockType;
}

// ---------- Seeded random ----------
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- Terrain ----------
function smoothstep(a: number, b: number, x: number) {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
}

function hills(x: number, z: number) {
  const v =
    Math.sin(x * 0.0115 + 1.7) * Math.cos(z * 0.0093 + 0.4) * 0.5 +
    Math.sin(x * 0.021 + z * 0.016) * 0.28 +
    Math.sin((x - z) * 0.037 + 2) * 0.14 +
    Math.cos(x * 0.05) * Math.sin(z * 0.047) * 0.08;
  return (v + 1) / 2;
}

export function heightAt(x: number, z: number) {
  const d = Math.max(Math.abs(x), Math.abs(z));
  if (d < FLAT_R) return 0;
  const t = smoothstep(FLAT_R, FLAT_R + 110, d);
  return t * hills(x, z) * 34;
}

// ---------- Trails (off-road) ----------
export interface TrailDef {
  kind: 'dirt' | 'gravel';
  width: number;
  control: [number, number][];
  samples: Float32Array; // x,z pairs
}

function makeTrail(kind: 'dirt' | 'gravel', width: number, control: [number, number][]): TrailDef {
  const curve = new THREE.CatmullRomCurve3(control.map(([x, z]) => new THREE.Vector3(x, 0, z)), false, 'catmullrom', 0.5);
  const n = 260;
  const pts = curve.getSpacedPoints(n);
  const samples = new Float32Array((n + 1) * 2);
  pts.forEach((p, i) => {
    samples[i * 2] = p.x;
    samples[i * 2 + 1] = p.z;
  });
  return { kind, width, control, samples };
}

export const TRAILS: TrailDef[] = [
  makeTrail('dirt', 7, [
    [268, 60], [330, 60], [400, 30], [470, -30], [540, 10], [560, 110], [500, 190], [420, 230], [340, 200], [268, 170],
  ]),
  makeTrail('gravel', 8, [
    [-268, -80], [-340, -100], [-420, -60], [-500, -120], [-530, -220], [-460, -300], [-360, -320], [-290, -260], [-268, -200],
  ]),
];

export function trailDistance(x: number, z: number, trail: TrailDef) {
  let best = Infinity;
  const s = trail.samples;
  for (let i = 0; i < s.length; i += 2) {
    const dx = s[i] - x;
    const dz = s[i + 1] - z;
    const d = dx * dx + dz * dz;
    if (d < best) best = d;
  }
  return Math.sqrt(best);
}

// ---------- Surfaces ----------
export type SurfaceKind = 'asphalt' | 'concrete' | 'sidewalk' | 'dirt' | 'gravel' | 'grass' | 'parking' | 'plaza';
export interface Surface {
  kind: SurfaceKind;
  grip: number;
  speedMul: number;
  y: number;
  bump: number;
}

const SURF: Record<SurfaceKind, Omit<Surface, 'y'>> = {
  asphalt: { kind: 'asphalt', grip: 1, speedMul: 1, bump: 0 },
  concrete: { kind: 'concrete', grip: 1, speedMul: 1, bump: 0.05 },
  sidewalk: { kind: 'sidewalk', grip: 0.9, speedMul: 0.9, bump: 0.1 },
  parking: { kind: 'parking', grip: 1, speedMul: 0.9, bump: 0 },
  plaza: { kind: 'plaza', grip: 0.95, speedMul: 0.9, bump: 0.05 },
  dirt: { kind: 'dirt', grip: 0.68, speedMul: 0.8, bump: 0.35 },
  gravel: { kind: 'gravel', grip: 0.62, speedMul: 0.85, bump: 0.3 },
  grass: { kind: 'grass', grip: 0.55, speedMul: 0.55, bump: 0.6 },
};

const surfOut: Surface = { ...SURF.asphalt, y: 0 };

function setSurf(kind: SurfaceKind, y: number) {
  const s = SURF[kind];
  surfOut.kind = s.kind;
  surfOut.grip = s.grip;
  surfOut.speedMul = s.speedMul;
  surfOut.bump = s.bump;
  surfOut.y = y;
  return surfOut;
}

/** returns a shared mutable object – copy if needed */
export function surfaceAt(x: number, z: number): Surface {
  const d = Math.max(Math.abs(x), Math.abs(z));
  const u = x - GRID0;
  const v = z - GRID0;
  const ix = Math.round(u / PITCH);
  const iz = Math.round(v / PITCH);
  const onX = ix >= 0 && ix < NR && Math.abs(u - ix * PITCH) <= HALF_ROAD;
  const onZ = iz >= 0 && iz < NR && Math.abs(v - iz * PITCH) <= HALF_ROAD;

  if (d <= CITY_HALF) {
    if (onX || onZ) return setSurf('asphalt', 0);
    const bi = Math.min(NB - 1, Math.max(0, Math.floor(u / PITCH)));
    const bj = Math.min(NB - 1, Math.max(0, Math.floor(v / PITCH)));
    const lu = u - bi * PITCH - HALF_ROAD;
    const lv = v - bj * PITCH - HALF_ROAD;
    if (lu < SIDEWALK_W || lu > BLOCK - SIDEWALK_W || lv < SIDEWALK_W || lv > BLOCK - SIDEWALK_W) return setSurf('sidewalk', SIDEWALK_H);
    const t = blockType(bi, bj);
    if (t === 'P' || t === 'R') return setSurf('grass', SIDEWALK_H);
    if (t === 'K') return setSurf('parking', SIDEWALK_H);
    return setSurf('plaza', SIDEWALK_H);
  }
  if (d >= RING_IN - 0.3 && d <= RING_OUT + 0.3) return setSurf('concrete', 0);
  if (d < RING_IN) {
    if ((onX && Math.abs(z) < RING_IN) || (onZ && Math.abs(x) < RING_IN)) return setSurf('asphalt', 0);
    return setSurf('grass', -0.03);
  }
  const h = heightAt(x, z);
  for (const t of TRAILS) {
    if (trailDistance(x, z, t) < t.width / 2) return setSurf(t.kind, h + 0.02);
  }
  return setSurf('grass', h);
}

/** ground height including surface offsets (for wheel placement) */
export function groundY(x: number, z: number) {
  return surfaceAt(x, z).y;
}

// ---------- Colliders ----------
export interface AABB {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

// ---------- Minimap data ----------
export interface MinimapData {
  roads: [number, number, number, number][];
  ring: number;
  trails: Float32Array[];
}

export function buildMinimapData(): MinimapData {
  const roads: [number, number, number, number][] = [];
  for (let i = 0; i < NR; i++) {
    const c = roadCoord(i);
    roads.push([c, -RING_IN, c, RING_IN]);
    roads.push([-RING_IN, c, RING_IN, c]);
  }
  return { roads, ring: RING_R, trails: TRAILS.map((t) => t.samples) };
}
