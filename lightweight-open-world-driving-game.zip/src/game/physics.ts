import type { VehicleSpec } from './vehicles';
import type { Surface } from './world';

export interface Input {
  throttle: number; // 0..1
  brake: number; // 0..1
  steer: number; // -1..1 (positive = left)
  handbrake: boolean;
}

export interface CarState {
  x: number;
  z: number;
  y: number;
  heading: number;
  vx: number;
  vz: number;
  steer: number;
  vF: number;
  vL: number;
  accelF: number; // smoothed longitudinal acceleration
  accelL: number;
  wheelSpin: number;
  rpm: number;
  gear: number;
  pitch: number;
  roll: number;
  bodyPitch: number;
  bodyRoll: number;
  bodyY: number;
  bodyVy: number;
  bumpPhase: number;
  slipping: boolean;
}

export function createCarState(x: number, z: number, heading: number): CarState {
  return {
    x, z, y: 0, heading, vx: 0, vz: 0, steer: 0, vF: 0, vL: 0, accelF: 0, accelL: 0, wheelSpin: 0, rpm: 0.1, gear: 1,
    pitch: 0, roll: 0, bodyPitch: 0, bodyRoll: 0, bodyY: 0, bodyVy: 0, bumpPhase: 0, slipping: false,
  };
}

export function resetVelocity(s: CarState) {
  s.vx = 0;
  s.vz = 0;
  s.vF = 0;
  s.vL = 0;
  s.steer = 0;
  s.accelF = 0;
  s.accelL = 0;
  s.bodyPitch = 0;
  s.bodyRoll = 0;
  s.bodyY = 0;
  s.bodyVy = 0;
}

const GEAR_SPEEDS = [0, 0.16, 0.3, 0.48, 0.68, 0.86, 1.01];

export function stepCar(s: CarState, spec: VehicleSpec, wheelbase: number, input: Input, surf: Surface, slopePitch: number, wet: boolean, dt: number) {
  const fx = Math.sin(s.heading);
  const fz = Math.cos(s.heading);
  const rx = -fz;
  const rz = fx;

  let vF = s.vx * fx + s.vz * fz;
  let vL = s.vx * rx + s.vz * rz;
  const prevVF = vF;
  const speed = Math.abs(vF);

  // ----- steering -----
  const speedFactor = 1 / (1 + speed * 0.05);
  const targetSteer = input.steer * spec.steerMax * speedFactor;
  const ds = targetSteer - s.steer;
  const maxDs = spec.steerSpeed * dt;
  s.steer += Math.max(-maxDs, Math.min(maxDs, ds));
  if (Math.abs(input.steer) < 0.05) s.steer *= Math.exp(-6 * dt); // return to centre

  // ----- surface / weather -----
  const offroadPenalty = 1 - (1 - surf.speedMul) * (1 - spec.offroad * 0.6);
  const gripSurf = 1 - (1 - surf.grip) * (1 - spec.offroad * 0.5);
  const topSpeed = spec.topSpeed * offroadPenalty;
  const wetMul = wet ? 0.85 : 1;

  // ----- engine / brakes -----
  let accel = 0;
  if (input.throttle > 0) {
    const ratio = Math.min(1, Math.max(0, vF / topSpeed));
    accel += input.throttle * spec.power * (1 - ratio * ratio * 0.9) * (vF < 0 ? 2.5 : 1);
  }
  if (input.brake > 0) {
    if (vF > 0.3) accel -= input.brake * spec.brake;
    else accel -= input.brake * spec.power * 0.6 * (vF > -topSpeed * 0.3 ? 1 : 0);
  }
  if (input.handbrake && speed > 0.2) accel -= Math.sign(vF) * spec.brake * 0.55;
  // slope: gravity along forward axis
  accel -= 9.81 * Math.sin(slopePitch) * 0.9;
  // drag & rolling
  accel -= vF * speed * 0.0018 + Math.sign(vF) * Math.min(speed / dt, 0.8 + (1 - surf.speedMul) * 6);
  vF += accel * dt;

  // ----- lateral grip -----
  const baseGrip = input.handbrake ? spec.driftGrip : spec.grip;
  // less grip when the lateral velocity is already large (progressive slide)
  const slideFactor = 1 / (1 + Math.abs(vL) * 0.12);
  const grip = baseGrip * gripSurf * wetMul * slideFactor;
  vL *= Math.exp(-grip * dt);
  s.slipping = Math.abs(vL) > 2.5;

  // ----- yaw -----
  let yawRate = 0;
  if (speed > 0.05) {
    const turnFactor = input.handbrake ? 1.35 : 1.0;
    yawRate = (vF / wheelbase) * Math.tan(s.steer) * turnFactor;
    // reduce steering authority when sliding sideways a lot
    yawRate *= 1 / (1 + Math.abs(vL) * 0.05);
    // low-speed steering boost so parking feels natural
    yawRate *= Math.min(1, 0.6 + speed * 0.1);
  }
  const maxYaw = 2.4;
  yawRate = Math.max(-maxYaw, Math.min(maxYaw, yawRate));
  s.heading += yawRate * dt;

  // rebuild world velocity in the (old) basis, heading already updated -> natural slip
  s.vx = fx * vF + rx * vL;
  s.vz = fz * vF + rz * vL;
  s.x += s.vx * dt;
  s.z += s.vz * dt;
  s.vF = vF;
  s.vL = vL;

  // ----- derived: suspension & sound -----
  const aF = (vF - prevVF) / Math.max(dt, 1e-4);
  s.accelF += (aF - s.accelF) * Math.min(1, dt * 6);
  s.accelL += (vF * yawRate - s.accelL) * Math.min(1, dt * 6);
  const targetPitch = -Math.max(-6, Math.min(6, s.accelF)) * 0.006;
  const targetRoll = Math.max(-12, Math.min(12, s.accelL)) * 0.011;
  s.bodyPitch += (targetPitch - s.bodyPitch) * Math.min(1, dt * 5);
  s.bodyRoll += (targetRoll - s.bodyRoll) * Math.min(1, dt * 5);
  // vertical spring
  const k = 40, c = 6;
  s.bodyVy += (-k * s.bodyY - c * s.bodyVy) * dt;
  s.bodyY += s.bodyVy * dt;
  // bumps on rough surfaces
  s.bumpPhase += speed * dt * (0.8 + surf.bump);
  if (surf.bump > 0.2 && speed > 3) s.bodyVy += Math.sin(s.bumpPhase * 7) * surf.bump * 0.4 * dt * 60 * 0.02;

  s.wheelSpin += (vF / spec.wheelR) * dt;

  const ratio = Math.min(1.05, speed / spec.topSpeed);
  let gear = 1;
  for (let g = 1; g < GEAR_SPEEDS.length; g++) if (ratio > GEAR_SPEEDS[g]) gear = g + 1;
  gear = Math.min(6, gear);
  const lo = GEAR_SPEEDS[gear - 1];
  const hi = GEAR_SPEEDS[gear] ?? 1.1;
  let rpm = (ratio - lo) / (hi - lo);
  rpm = 0.15 + Math.max(0, Math.min(1, rpm)) * 0.85;
  if (input.throttle > 0 && speed < 1) rpm = 0.45;
  s.rpm += (rpm - s.rpm) * Math.min(1, dt * 8);
  s.gear = vF < -0.5 ? 0 : gear;
}
