import type { Settings } from './types';

const KEY = 'sunfall-drive-save-v1';

export interface SaveData {
  settings: Settings;
  vehicleId: string;
  colorIndex: number;
  bestTimes: Record<string, number>;
  unlockedKm: number;
}

export const DEFAULT_SETTINGS: Settings = {
  quality: 'medium',
  weather: 'clear',
  timeOfDay: 16.5,
  timeFlow: true,
  camera: 'chase',
  sound: true,
  traffic: true,
  headlightsAuto: true,
};

const DEFAULT_SAVE: SaveData = {
  settings: DEFAULT_SETTINGS,
  vehicleId: 'stiletto',
  colorIndex: 0,
  bestTimes: {},
  unlockedKm: 0,
};

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return structuredClone(DEFAULT_SAVE);
    const parsed = JSON.parse(raw);
    return {
      ...structuredClone(DEFAULT_SAVE),
      ...parsed,
      settings: { ...DEFAULT_SETTINGS, ...(parsed.settings || {}) },
    };
  } catch {
    return structuredClone(DEFAULT_SAVE);
  }
}

export function writeSave(data: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    /* storage unavailable (private mode) – ignore */
  }
}
