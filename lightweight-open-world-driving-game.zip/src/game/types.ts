export type Quality = 'low' | 'medium' | 'high';
export type Weather = 'clear' | 'cloudy' | 'rain' | 'fog';
export type CameraMode = 'chase' | 'hood' | 'top' | 'cinematic';

export interface Settings {
  quality: Quality;
  weather: Weather;
  timeOfDay: number; // 0..24
  timeFlow: boolean;
  camera: CameraMode;
  sound: boolean;
  traffic: boolean;
  headlightsAuto: boolean;
}

export interface MissionHud {
  id: string;
  name: string;
  checkpoint: number;
  total: number;
  time: number;
  best: number | null;
  distance: number;
  finished: boolean;
}

export interface HudState {
  speed: number; // km/h
  rpm: number; // 0..1
  gear: number;
  surface: string;
  clock: string;
  weather: Weather;
  camera: CameraMode;
  headlights: boolean;
  handbrake: boolean;
  mission: MissionHud | null;
  message: string | null;
  fps: number;
  drawCalls: number;
  vehicleName: string;
}

export interface MissionDef {
  id: string;
  name: string;
  type: 'sprint' | 'trial' | 'rally' | 'delivery' | 'tour';
  description: string;
  points: [number, number][];
  startHeading: number;
  par: number; // seconds
}

export interface QualityProfile {
  pixelRatio: number;
  shadows: boolean;
  shadowSize: number;
  drawDistance: number;
  propDistance: number;
  fogFar: number;
  rainCount: number;
  trafficCount: number;
  anisotropy: number;
  antialias: boolean;
}

export const QUALITY: Record<Quality, QualityProfile> = {
  low: {
    pixelRatio: 0.75,
    shadows: false,
    shadowSize: 512,
    drawDistance: 320,
    propDistance: 180,
    fogFar: 420,
    rainCount: 600,
    trafficCount: 6,
    anisotropy: 2,
    antialias: false,
  },
  medium: {
    pixelRatio: 1,
    shadows: true,
    shadowSize: 1024,
    drawDistance: 480,
    propDistance: 260,
    fogFar: 620,
    rainCount: 1500,
    trafficCount: 10,
    anisotropy: 4,
    antialias: true,
  },
  high: {
    pixelRatio: Math.min(window.devicePixelRatio || 1, 2),
    shadows: true,
    shadowSize: 2048,
    drawDistance: 700,
    propDistance: 380,
    fogFar: 900,
    rainCount: 2600,
    trafficCount: 14,
    anisotropy: 8,
    antialias: true,
  },
};
