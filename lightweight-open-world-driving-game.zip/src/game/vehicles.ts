import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

export type BodyStyle = 'sedan' | 'coupe' | 'muscle' | 'suv' | 'van' | 'hatch' | 'pickup';

export interface VehicleSpec {
  id: string;
  name: string;
  style: BodyStyle;
  tagline: string;
  length: number;
  width: number;
  roofH: number;
  hoodH: number;
  trunkH: number;
  ground: number;
  wheelR: number;
  overhangF: number;
  overhangR: number;
  cabin: [number, number, number, number]; // fractions of L: cabinFront, roofFront, roofRear, cabinRear
  // handling
  power: number; // m/s^2 at low speed
  topSpeed: number; // m/s
  brake: number;
  grip: number; // lateral damping /s
  driftGrip: number;
  steerMax: number; // rad
  steerSpeed: number;
  offroad: number; // 0..1 multiplier of offroad penalty resistance
  colors: string[];
  stats: { speed: number; accel: number; handling: number; offroad: number };
}

export const VEHICLES: VehicleSpec[] = [
  {
    id: 'vandal', name: 'Vandal Sedan', style: 'sedan', tagline: 'Balanced family four-door. Predictable and honest.',
    length: 4.65, width: 1.86, roofH: 1.44, hoodH: 0.96, trunkH: 1.0, ground: 0.3, wheelR: 0.34, overhangF: 0.9, overhangR: 1.0,
    cabin: [0.13, -0.04, -0.29, -0.4],
    power: 9.5, topSpeed: 47, brake: 16, grip: 7.5, driftGrip: 2.2, steerMax: 0.6, steerSpeed: 3.2, offroad: 0.5,
    colors: ['#b8bcc2', '#1d3a6b', '#7a1f1f', '#2b2b2e', '#d9c48a'],
    stats: { speed: 62, accel: 55, handling: 66, offroad: 40 },
  },
  {
    id: 'stiletto', name: 'Stiletto GT', style: 'coupe', tagline: 'Low, wide and glued to the asphalt.',
    length: 4.45, width: 1.92, roofH: 1.26, hoodH: 0.84, trunkH: 0.92, ground: 0.24, wheelR: 0.35, overhangF: 0.85, overhangR: 0.95,
    cabin: [0.04, -0.13, -0.31, -0.46],
    power: 12.5, topSpeed: 62, brake: 20, grip: 9.5, driftGrip: 2.6, steerMax: 0.55, steerSpeed: 3.8, offroad: 0.25,
    colors: ['#e03a2f', '#f2c400', '#0b0d10', '#e8e8ea', '#00a5b5'],
    stats: { speed: 92, accel: 84, handling: 90, offroad: 20 },
  },
  {
    id: 'bruiser', name: 'Bruiser 71', style: 'muscle', tagline: 'Big block, rear wheels, questionable decisions.',
    length: 4.95, width: 1.96, roofH: 1.36, hoodH: 1.02, trunkH: 1.02, ground: 0.3, wheelR: 0.36, overhangF: 1.0, overhangR: 1.15,
    cabin: [0.05, -0.1, -0.33, -0.42],
    power: 13.5, topSpeed: 58, brake: 15, grip: 5.5, driftGrip: 1.4, steerMax: 0.55, steerSpeed: 3.0, offroad: 0.35,
    colors: ['#f26b1d', '#2e2e30', '#3b7a3b', '#6b2fa8', '#c0c3c8'],
    stats: { speed: 84, accel: 92, handling: 52, offroad: 30 },
  },
  {
    id: 'ridgeback', name: 'Ridgeback 4x4', style: 'suv', tagline: 'Tall, tough and happiest off the tarmac.',
    length: 4.75, width: 1.98, roofH: 1.9, hoodH: 1.22, trunkH: 1.74, ground: 0.42, wheelR: 0.42, overhangF: 0.85, overhangR: 0.95,
    cabin: [0.17, 0.05, -0.42, -0.48],
    power: 9, topSpeed: 45, brake: 15, grip: 6.5, driftGrip: 2.4, steerMax: 0.58, steerSpeed: 2.8, offroad: 0.95,
    colors: ['#4d6b3a', '#c8c9cb', '#1f2a44', '#8c3b2a', '#dcdcdc'],
    stats: { speed: 58, accel: 52, handling: 55, offroad: 95 },
  },
  {
    id: 'courier', name: 'Courier Van', style: 'van', tagline: 'Delivers everything except lap times.',
    length: 5.1, width: 1.98, roofH: 2.15, hoodH: 1.16, trunkH: 2.05, ground: 0.34, wheelR: 0.38, overhangF: 0.95, overhangR: 1.15,
    cabin: [0.3, 0.14, -0.47, -0.49],
    power: 7, topSpeed: 38, brake: 13, grip: 6, driftGrip: 2.5, steerMax: 0.55, steerSpeed: 2.5, offroad: 0.5,
    colors: ['#f0efe9', '#2d6fb5', '#d8a72c', '#3c3c3c'],
    stats: { speed: 45, accel: 38, handling: 44, offroad: 45 },
  },
  {
    id: 'pip', name: 'Pip Hatch', style: 'hatch', tagline: 'Tiny, nimble, and always parking where it should not.',
    length: 3.95, width: 1.74, roofH: 1.5, hoodH: 0.9, trunkH: 1.32, ground: 0.28, wheelR: 0.31, overhangF: 0.75, overhangR: 0.7,
    cabin: [0.15, -0.02, -0.36, -0.46],
    power: 9, topSpeed: 42, brake: 17, grip: 9, driftGrip: 3, steerMax: 0.66, steerSpeed: 4.2, offroad: 0.4,
    colors: ['#40c4a0', '#f4f1ea', '#f7b2c9', '#1b1b1d', '#ffcc33'],
    stats: { speed: 52, accel: 58, handling: 88, offroad: 35 },
  },
  {
    id: 'hauler', name: 'Hauler Pickup', style: 'pickup', tagline: 'Long bed, long wheelbase, long braking distance.',
    length: 5.4, width: 1.98, roofH: 1.88, hoodH: 1.2, trunkH: 1.16, ground: 0.42, wheelR: 0.42, overhangF: 0.95, overhangR: 1.2,
    cabin: [0.2, 0.08, -0.1, -0.14],
    power: 8.5, topSpeed: 44, brake: 13, grip: 6, driftGrip: 2, steerMax: 0.52, steerSpeed: 2.6, offroad: 0.85,
    colors: ['#8a1c1c', '#2f4f6f', '#e6e3dc', '#26262a'],
    stats: { speed: 55, accel: 50, handling: 48, offroad: 85 },
  },
];

export function getVehicle(id: string) {
  return VEHICLES.find((v) => v.id === id) ?? VEHICLES[0];
}

export interface CarModel {
  group: THREE.Group;
  body: THREE.Group;
  wheels: THREE.Mesh[];
  paint: THREE.MeshStandardMaterial;
  tail: THREE.MeshStandardMaterial;
  head: THREE.MeshStandardMaterial;
  spec: VehicleSpec;
  wheelbase: number;
  track: number;
}

// Shared materials (created lazily once)
let shared: {
  dark: THREE.MeshStandardMaterial;
  chrome: THREE.MeshStandardMaterial;
  glass: THREE.MeshPhysicalMaterial;
  plate: THREE.MeshStandardMaterial;
  tire: THREE.MeshStandardMaterial;
  rim: THREE.MeshStandardMaterial;
  interior: THREE.MeshStandardMaterial;
} | null = null;

export function getSharedCarMaterials(rimTex: THREE.Texture) {
  if (!shared) {
    shared = {
      dark: new THREE.MeshStandardMaterial({ color: 0x1a1b1e, roughness: 0.7, metalness: 0.2 }),
      chrome: new THREE.MeshStandardMaterial({ color: 0xd8dde3, roughness: 0.15, metalness: 1.0 }),
      glass: new THREE.MeshPhysicalMaterial({
        color: 0x0e1418, roughness: 0.08, metalness: 0.2, transparent: true, opacity: 0.78,
        envMapIntensity: 1.4, depthWrite: false,
      }),
      plate: new THREE.MeshStandardMaterial({ color: 0xf0f0e8, roughness: 0.6, metalness: 0.1 }),
      tire: new THREE.MeshStandardMaterial({ color: 0x141414, roughness: 0.95, metalness: 0 }),
      rim: new THREE.MeshStandardMaterial({ map: rimTex, roughness: 0.35, metalness: 0.7 }),
      interior: new THREE.MeshStandardMaterial({ color: 0x2b2a2e, roughness: 0.9 }),
    };
  }
  return shared;
}

function box(w: number, h: number, d: number, x: number, y: number, z: number, ry = 0): THREE.BufferGeometry {
  const g = new THREE.BoxGeometry(w, h, d);
  if (ry) g.rotateY(ry);
  g.translate(x, y, z);
  return g;
}

function stripUV(g: THREE.BufferGeometry) {
  // ensure all geometries share the same attributes for merging
  if (!g.getAttribute('uv')) {
    const n = g.getAttribute('position').count;
    g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(n * 2), 2));
  }
  return g;
}

function mergeClean(list: THREE.BufferGeometry[]): THREE.BufferGeometry | null {
  if (!list.length) return null;
  const prepared = list.map((g) => {
    const ng = g.index ? g.toNonIndexed() : g;
    stripUV(ng);
    // remove extra attributes that some geometries may have
    for (const k of Object.keys(ng.attributes)) if (!['position', 'normal', 'uv'].includes(k)) ng.deleteAttribute(k);
    return ng;
  });
  const merged = mergeGeometries(prepared, false);
  return merged;
}

/**
 * Build a car. Local axes: +z forward, +x left (right-hand traffic side is -x), +y up.
 */
export function buildCar(spec: VehicleSpec, color: string, rimTex: THREE.Texture, opts: { staticModel?: boolean } = {}): CarModel {
  const sm = getSharedCarMaterials(rimTex);
  const L = spec.length;
  const W = spec.width;
  const g0 = spec.ground;
  const rArch = spec.wheelR + 0.15;
  const rearAxle = -L / 2 + spec.overhangR;
  const frontAxle = L / 2 - spec.overhangF;
  const [cf, rf, rr, cr] = spec.cabin.map((f) => f * L);
  const hoodFront = spec.hoodH - 0.08;
  const hoodRear = spec.hoodH;
  const roofH = spec.roofH;
  const trunkH = spec.trunkH;
  const trunkRear = spec.style === 'pickup' ? trunkH : trunkH - 0.06;
  const bevel = 0.07;
  const Lf = L / 2 + bevel; // beveled skin extends past the profile

  // ----- Body profile (x = length, y = up) -----
  const s = new THREE.Shape();
  s.moveTo(-L / 2 + 0.06, g0);
  s.lineTo(rearAxle - rArch, g0);
  s.absarc(rearAxle, g0, rArch, Math.PI, 0, true);
  s.lineTo(frontAxle - rArch, g0);
  s.absarc(frontAxle, g0, rArch, Math.PI, 0, true);
  s.lineTo(L / 2 - 0.08, g0);
  s.lineTo(L / 2, g0 + 0.22);
  s.lineTo(L / 2, hoodFront - 0.05);
  s.lineTo(L / 2 - 0.12, hoodFront);
  s.lineTo(cf, hoodRear);
  s.lineTo(rf, roofH);
  s.lineTo(rr, roofH);
  s.lineTo(cr, trunkH);
  s.lineTo(-L / 2 + 0.12, trunkRear);
  s.lineTo(-L / 2, trunkRear - 0.12);
  s.lineTo(-L / 2, g0 + 0.22);
  s.closePath();

  const bodyGeo = new THREE.ExtrudeGeometry(s, {
    depth: W - bevel * 2, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 2, curveSegments: 8,
  });
  bodyGeo.translate(0, 0, -(W - bevel * 2) / 2);
  bodyGeo.rotateY(-Math.PI / 2);

  // ----- Glass shell -----
  const gs = new THREE.Shape();
  gs.moveTo(cf + 0.05, hoodRear + 0.01);
  gs.lineTo(rf + 0.03, roofH - 0.06);
  gs.lineTo(rr - 0.03, roofH - 0.06);
  gs.lineTo(cr - 0.05, trunkH + 0.01);
  gs.closePath();
  const glassGeo = new THREE.ExtrudeGeometry(gs, { depth: W + 0.05, bevelEnabled: false });
  glassGeo.translate(0, 0, -(W + 0.05) / 2);
  glassGeo.rotateY(-Math.PI / 2);

  const paint: THREE.BufferGeometry[] = [bodyGeo];
  const dark: THREE.BufferGeometry[] = [];
  const chrome: THREE.BufferGeometry[] = [];
  const head: THREE.BufferGeometry[] = [];
  const tail: THREE.BufferGeometry[] = [];
  const plate: THREE.BufferGeometry[] = [];
  const interior: THREE.BufferGeometry[] = [];

  // chassis block (hides see-through wheel arches)
  dark.push(box(W - 0.5, 0.42, L - 0.5, 0, g0 + 0.2, 0));
  // B pillars
  const pillarX = rf + (rr - rf) * 0.45;
  dark.push(box(W + 0.07, roofH - hoodRear - 0.05, 0.1, 0, (roofH + hoodRear) / 2 - 0.02, pillarX));
  // door seams
  const doorSplit = cf - 0.6;
  for (const side of [-1, 1]) {
    dark.push(box(0.015, hoodRear - g0 - 0.3, 0.02, side * (W / 2 + 0.003), (hoodRear + g0) / 2 + 0.05, doorSplit));
    dark.push(box(0.015, hoodRear - g0 - 0.3, 0.02, side * (W / 2 + 0.003), (hoodRear + g0) / 2 + 0.05, pillarX + 0.02));
    // door handles
    chrome.push(box(0.03, 0.03, 0.16, side * (W / 2 + 0.01), hoodRear - 0.15, pillarX + 0.35));
    if (spec.style !== 'coupe' && spec.style !== 'pickup') chrome.push(box(0.03, 0.03, 0.16, side * (W / 2 + 0.01), hoodRear - 0.15, pillarX - 0.6));
    // mirrors
    paint.push(box(0.09, 0.12, 0.2, side * (W / 2 + 0.13), hoodRear + 0.22, cf - 0.05));
    dark.push(box(0.12, 0.03, 0.03, side * (W / 2 + 0.06), hoodRear + 0.16, cf - 0.05));
  }
  // bumpers
  const paintedBumper = spec.style === 'coupe' || spec.style === 'sedan' || spec.style === 'hatch';
  const bumperF = box(W + 0.02, 0.24, 0.16, 0, g0 + 0.24, Lf - 0.03);
  const bumperR = box(W + 0.02, 0.24, 0.16, 0, g0 + 0.24, -Lf + 0.03);
  (paintedBumper ? paint : dark).push(bumperF, bumperR);
  dark.push(box(W - 0.3, 0.1, 0.06, 0, g0 + 0.16, Lf + 0.04)); // lower lip
  // grille
  dark.push(box(W * 0.42, 0.2, 0.05, 0, hoodFront - 0.2, Lf + 0.01));
  chrome.push(box(W * 0.44, 0.03, 0.06, 0, hoodFront - 0.12, Lf + 0.01));
  chrome.push(box(W * 0.44, 0.03, 0.06, 0, hoodFront - 0.28, Lf + 0.01));
  // headlights & taillights
  const hlW = spec.style === 'coupe' || spec.style === 'muscle' ? 0.42 : 0.34;
  for (const side of [-1, 1]) {
    head.push(box(hlW, 0.16, 0.08, side * (W / 2 - hlW / 2 - 0.12), hoodFront - 0.2, Lf + 0.02));
    tail.push(box(0.42, 0.14, 0.08, side * (W / 2 - 0.36), trunkRear - 0.22, -Lf - 0.02));
    dark.push(box(0.46, 0.18, 0.06, side * (W / 2 - 0.36), trunkRear - 0.22, -Lf - 0.005));
  }
  // plates
  plate.push(box(0.5, 0.13, 0.02, 0, g0 + 0.36, Lf + 0.08));
  plate.push(box(0.5, 0.13, 0.02, 0, g0 + 0.36, -Lf - 0.08));
  // exhaust
  const ex = new THREE.CylinderGeometry(0.04, 0.045, 0.16, 8);
  ex.rotateX(Math.PI / 2);
  ex.translate(-(W / 2 - 0.35), g0 + 0.06, -Lf - 0.02);
  chrome.push(ex);
  if (spec.style === 'muscle' || spec.style === 'coupe') {
    const ex2 = ex.clone();
    ex2.translate(W - 0.7, 0, 0);
    chrome.push(ex2);
  }
  // interior hints: seats + dash + wheel
  const seatY = hoodRear - 0.35;
  interior.push(box(0.5, 0.55, 0.5, -0.4, seatY + 0.1, pillarX - 0.1));
  interior.push(box(0.5, 0.55, 0.5, 0.4, seatY + 0.1, pillarX - 0.1));
  interior.push(box(W - 0.4, 0.22, 0.4, 0, hoodRear - 0.12, cf - 0.3));
  const sw = new THREE.TorusGeometry(0.18, 0.025, 6, 16);
  sw.rotateX(Math.PI / 2 - 0.5);
  sw.translate(-0.4, hoodRear + 0.05, cf - 0.55);
  interior.push(sw);

  // style extras
  if (spec.style === 'muscle') {
    paint.push(box(0.5, 0.08, 1.0, 0, hoodRear + 0.02, cf + 0.75)); // hood scoop
    dark.push(box(0.4, 0.05, 0.1, 0, hoodRear + 0.04, cf + 1.22));
    paint.push(box(W * 0.8, 0.08, 0.2, 0, trunkRear + 0.15, -L / 2 + 0.2)); // spoiler
    dark.push(box(0.08, 0.15, 0.1, -0.5, trunkRear + 0.05, -L / 2 + 0.2));
    dark.push(box(0.08, 0.15, 0.1, 0.5, trunkRear + 0.05, -L / 2 + 0.2));
  }
  if (spec.style === 'coupe') {
    paint.push(box(W * 0.7, 0.05, 0.16, 0, trunkRear + 0.1, -L / 2 + 0.15)); // ducktail
  }
  if (spec.style === 'suv' || spec.style === 'van') {
    dark.push(box(0.06, 0.08, (rr - rf) * 0.9, -(W / 2 - 0.2), roofH + 0.06, (rf + rr) / 2)); // roof rails
    dark.push(box(0.06, 0.08, (rr - rf) * 0.9, W / 2 - 0.2, roofH + 0.06, (rf + rr) / 2));
    dark.push(box(W + 0.16, 0.1, L - 0.4, 0, g0 + 0.05, 0)); // running boards / side skirts
  }
  if (spec.style === 'pickup') {
    dark.push(box(W - 0.36, 0.04, -L / 2 + 0.25 - cr, 0, trunkH + 0.02, (cr + (-L / 2 + 0.25)) / 2 + 0.05)); // bed liner
    dark.push(box(W + 0.12, 0.1, L - 0.4, 0, g0 + 0.05, 0));
  }
  if (spec.style === 'van') {
    dark.push(box(0.02, 0.5, 0.8, 0, 0, 0)); // placeholder (removed below) – keeps shape simple
    dark.pop();
    // side panel window
    const pw = box(0.02, 0.45, 1.0, W / 2 + 0.005, roofH - 0.55, cr + 0.9);
    const pw2 = box(0.02, 0.45, 1.0, -(W / 2 + 0.005), roofH - 0.55, cr + 0.9);
    dark.push(pw, pw2);
  }

  // ----- materials -----
  const paintMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(color), roughness: 0.32, metalness: 0.55, envMapIntensity: 1.3 });
  const headMat = new THREE.MeshStandardMaterial({ color: 0xf4f6f0, emissive: 0xfff2c8, emissiveIntensity: 0.2, roughness: 0.3 });
  const tailMat = new THREE.MeshStandardMaterial({ color: 0x8a1010, emissive: 0xff2010, emissiveIntensity: 0.25, roughness: 0.4 });

  const group = new THREE.Group();
  const body = new THREE.Group();
  group.add(body);

  const addMerged = (list: THREE.BufferGeometry[], mat: THREE.Material, castShadow = true) => {
    const geo = mergeClean(list);
    if (!geo) return;
    const m = new THREE.Mesh(geo, mat);
    m.castShadow = castShadow;
    m.receiveShadow = false;
    body.add(m);
  };

  const wheelbase = frontAxle - rearAxle;
  const track = W / 2 - 0.04;
  const wheels: THREE.Mesh[] = [];

  // ----- wheels -----
  const wheelW = 0.26;
  const tireGeo = new THREE.CylinderGeometry(spec.wheelR, spec.wheelR, wheelW, 18);
  tireGeo.rotateZ(Math.PI / 2);
  const wheelMats = [sm.tire, sm.rim, sm.rim];

  if (opts.staticModel) {
    // static: merge tires into dark, rims into a single mesh with rim texture
    const tires: THREE.BufferGeometry[] = [];
    const rimGeo = new THREE.CylinderGeometry(spec.wheelR * 0.7, spec.wheelR * 0.7, wheelW + 0.02, 14);
    rimGeo.rotateZ(Math.PI / 2);
    const rims: THREE.BufferGeometry[] = [];
    for (const [x, z] of [[track, frontAxle], [-track, frontAxle], [track, rearAxle], [-track, rearAxle]]) {
      const t = tireGeo.clone();
      t.translate(x, spec.wheelR, z);
      tires.push(t);
      const r = rimGeo.clone();
      r.translate(x, spec.wheelR, z);
      rims.push(r);
    }
    addMerged(tires, sm.tire);
    addMerged(rims, sm.rim);
  } else {
    for (const [x, z] of [[track, frontAxle], [-track, frontAxle], [track, rearAxle], [-track, rearAxle]]) {
      const w = new THREE.Mesh(tireGeo, wheelMats);
      w.rotation.order = 'YXZ';
      w.position.set(x, spec.wheelR, z);
      w.castShadow = true;
      group.add(w);
      wheels.push(w);
    }
  }

  addMerged(paint, paintMat);
  addMerged(dark, sm.dark);
  addMerged(chrome, sm.chrome, false);
  addMerged(head, headMat, false);
  addMerged(tail, tailMat, false);
  addMerged(plate, sm.plate, false);
  addMerged(interior, sm.interior, false);
  const glass = new THREE.Mesh(glassGeo, sm.glass);
  glass.renderOrder = 2;
  body.add(glass);

  return { group, body, wheels, paint: paintMat, tail: tailMat, head: headMat, spec, wheelbase, track };
}
