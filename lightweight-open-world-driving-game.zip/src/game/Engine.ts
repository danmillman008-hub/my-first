import * as THREE from 'three';
import { createTextures, type TextureSet } from './textures';
import { buildCity, type CityResult } from './citybuilder';
import { buildCar, getVehicle, type CarModel } from './vehicles';
import { createCarState, resetVelocity, stepCar, type CarState, type Input } from './physics';
import { Traffic } from './traffic';
import { EngineAudio } from './audio';
import { MISSIONS, MISSION_START_RADIUS } from './missions';
import { QUALITY, type CameraMode, type HudState, type Settings, type Weather, type MissionHud } from './types';
import { buildMinimapData, roadCoord, surfaceAt, NR, GRID0, PITCH, WORLD_HALF, type AABB, type MinimapData, type Surface } from './world';

export type EngineMode = 'attract' | 'play';

export interface EngineCallbacks {
  onHud: (h: HudState) => void;
  onMissionComplete: (result: { id: string; name: string; time: number; best: number | null; isNewBest: boolean; par: number }) => void;
  getBest: (id: string) => number | null;
  saveBest: (id: string, t: number) => void;
}

const SKY_VERT = `varying vec3 vDir; void main(){ vDir = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`;
const SKY_FRAG = `
varying vec3 vDir;
uniform vec3 topColor; uniform vec3 horizonColor; uniform vec3 sunDir; uniform vec3 sunColor; uniform vec3 fogColor; uniform float fogMix;
void main(){
  vec3 d = normalize(vDir);
  float h = d.y;
  vec3 col = mix(horizonColor, topColor, pow(clamp(h, 0.0, 1.0), 0.5));
  if (h < 0.0) col = mix(horizonColor, horizonColor * 0.6, clamp(-h * 5.0, 0.0, 1.0));
  float s = max(dot(d, sunDir), 0.0);
  col += sunColor * (pow(s, 1200.0) * 4.0 + pow(s, 16.0) * 0.28 + pow(s, 3.0) * 0.07);
  col = mix(col, fogColor, fogMix);
  gl_FragColor = vec4(col, 1.0);
}`;

function lerpColor(out: THREE.Color, a: THREE.Color, b: THREE.Color, t: number) {
  return out.copy(a).lerp(b, Math.min(1, Math.max(0, t)));
}

export class Engine {
  canvas: HTMLCanvasElement;
  minimap: HTMLCanvasElement | null = null;
  renderer!: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera!: THREE.PerspectiveCamera;
  tex!: TextureSet;
  city!: CityResult;
  traffic!: Traffic;
  settings: Settings;
  cb: EngineCallbacks;
  mode: EngineMode = 'attract';
  paused = false;
  disposed = false;
  ready = false;

  // player
  player!: CarModel;
  state: CarState = createCarState(roadCoord(3) - 1.75, -100, 0);
  input: Input = { throttle: 0, brake: 0, steer: 0, handbrake: false };
  keys = new Set<string>();
  headlights = false;
  headlightsManual: boolean | null = null;
  spotL!: THREE.SpotLight;
  spotR!: THREE.SpotLight;
  surface: Surface = { ...surfaceAt(0, -100) };

  // env
  sun!: THREE.DirectionalLight;
  hemi!: THREE.HemisphereLight;
  ambient!: THREE.AmbientLight;
  skyMat!: THREE.ShaderMaterial;
  sky!: THREE.Mesh;
  stars!: THREE.Points;
  moon!: THREE.Sprite;
  rain!: THREE.Points;
  rainVel = 0;
  pmrem!: THREE.PMREMGenerator;
  envScene = new THREE.Scene();
  envTex: THREE.Texture | null = null;
  lastEnvTime = -99;
  lastEnvWeather: Weather | null = null;
  timeOfDay = 16.5;
  nightFactor = 0;
  wet = false;
  trafficTimer = 0;

  // camera
  cameraMode: CameraMode = 'chase';
  camPos = new THREE.Vector3();
  camLook = new THREE.Vector3();
  cinePos = new THREE.Vector3();
  cineTimer = 0;
  attractAngle = 0;

  // mission
  mission: (typeof MISSIONS)[number] | null = null;
  cpIndex = 0;
  missionTime = 0;
  missionDone = false;
  cpMarker!: THREE.Group;
  arrow!: THREE.Mesh;
  lastCheckpoint: { x: number; z: number; h: number } | null = null;

  // misc
  audio = new EngineAudio();
  clock = new THREE.Clock();
  hudTimer = 0;
  fps = 60;
  fpsAcc = 0;
  fpsFrames = 0;
  message: string | null = null;
  messageTimer = 0;
  minimapData: MinimapData = buildMinimapData();
  raf = 0;
  tmpV = new THREE.Vector3();
  tmpV2 = new THREE.Vector3();
  colA = new THREE.Color();
  colB = new THREE.Color();
  colC = new THREE.Color();
  parkedModels: CarModel[] = [];
  onKey = (e: KeyboardEvent) => this.handleKey(e);
  onResize = () => this.resize();

  constructor(canvas: HTMLCanvasElement, settings: Settings, cb: EngineCallbacks) {
    this.canvas = canvas;
    this.settings = { ...settings };
    this.cb = cb;
    this.timeOfDay = settings.timeOfDay;
    this.cameraMode = settings.camera;
  }

  // ------------------------------------------------------------------ init
  async init(vehicleId: string, colorIndex: number) {
    const q = QUALITY[this.settings.quality];
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: q.antialias, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(q.pixelRatio);
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.renderer.shadowMap.enabled = q.shadows;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;

    this.camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.3, 1600);
    this.scene.fog = new THREE.Fog(0xaabbcc, 100, q.fogFar);

    this.tex = createTextures(Math.min(q.anisotropy, this.renderer.capabilities.getMaxAnisotropy()));
    await new Promise((r) => setTimeout(r, 10));

    // lights
    this.sun = new THREE.DirectionalLight(0xffffff, 2.5);
    this.sun.castShadow = q.shadows;
    this.sun.shadow.mapSize.set(q.shadowSize, q.shadowSize);
    const sc = this.sun.shadow.camera;
    sc.left = -70; sc.right = 70; sc.top = 70; sc.bottom = -70; sc.near = 10; sc.far = 400;
    this.sun.shadow.bias = -0.0008;
    this.sun.shadow.normalBias = 0.05;
    this.scene.add(this.sun, this.sun.target);
    this.hemi = new THREE.HemisphereLight(0x8fb6ff, 0x5a4a3a, 0.8);
    this.ambient = new THREE.AmbientLight(0xffffff, 0.15);
    this.scene.add(this.hemi, this.ambient);

    // sky
    this.skyMat = new THREE.ShaderMaterial({
      vertexShader: SKY_VERT, fragmentShader: SKY_FRAG, side: THREE.BackSide, depthWrite: false, fog: false,
      uniforms: {
        topColor: { value: new THREE.Color(0x3d74c8) }, horizonColor: { value: new THREE.Color(0xc4dcf0) },
        sunDir: { value: new THREE.Vector3(0, 1, 0) }, sunColor: { value: new THREE.Color(0xffffff) },
        fogColor: { value: new THREE.Color(0xc4dcf0) }, fogMix: { value: 0 },
      },
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(1400, 28, 14), this.skyMat);
    this.sky.renderOrder = -10;
    this.sky.frustumCulled = false;
    this.scene.add(this.sky);
    // stars
    {
      const n = 900;
      const pos = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        const v = new THREE.Vector3().randomDirection();
        if (v.y < 0.02) v.y = Math.abs(v.y) + 0.02;
        v.normalize().multiplyScalar(1300);
        pos.set([v.x, v.y, v.z], i * 3);
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      this.stars = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffffff, size: 2.2, sizeAttenuation: false, transparent: true, opacity: 0, depthWrite: false, fog: false }));
      this.stars.frustumCulled = false;
      this.scene.add(this.stars);
    }
    this.moon = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.tex.glow, color: 0xdfe8ff, transparent: true, opacity: 0, depthWrite: false, fog: false }));
    this.moon.scale.set(90, 90, 1);
    this.scene.add(this.moon);

    // environment map (reflections)
    this.pmrem = new THREE.PMREMGenerator(this.renderer);
    const envSky = new THREE.Mesh(new THREE.SphereGeometry(500, 16, 8), this.skyMat);
    const envGround = new THREE.Mesh(new THREE.CircleGeometry(480, 24).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0x4a4f48 }));
    envGround.position.y = -2;
    this.envScene.add(envSky, envGround);

    // city
    this.city = buildCity(this.tex, { shadows: q.shadows });
    this.scene.add(this.city.group);
    await new Promise((r) => setTimeout(r, 10));

    // parked cars
    for (const p of this.city.parked) {
      const spec = getVehicle(['vandal', 'pip', 'ridgeback', 'courier', 'hauler'][Math.floor(Math.random() * 5)]);
      const m = buildCar(spec, spec.colors[Math.floor(Math.random() * spec.colors.length)], this.tex.rim, { staticModel: true });
      m.group.position.set(p.x, 0.15, p.z);
      m.group.rotation.y = p.heading;
      m.group.matrixAutoUpdate = false;
      m.group.updateMatrix();
      m.group.traverse((o) => (o.matrixAutoUpdate = false));
      m.group.updateMatrixWorld(true);
      this.scene.add(m.group);
      this.parkedModels.push(m);
    }

    // player
    this.setVehicle(vehicleId, colorIndex);

    // traffic
    this.traffic = new Traffic(this.scene, this.tex.rim);
    this.traffic.setCount(this.settings.traffic ? q.trafficCount : 0, this.state.x, this.state.z);

    // rain
    {
      const n = QUALITY.high.rainCount;
      const pos = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) pos.set([(Math.random() - 0.5) * 60, Math.random() * 30, (Math.random() - 0.5) * 60], i * 3);
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const m = new THREE.PointsMaterial({ map: this.tex.rain, color: 0xcfe0f5, size: 0.9, transparent: true, opacity: 0.55, depthWrite: false, blending: THREE.AdditiveBlending, fog: false });
      this.rain = new THREE.Points(g, m);
      this.rain.frustumCulled = false;
      this.rain.visible = false;
      this.scene.add(this.rain);
    }

    // checkpoint marker & arrow
    this.cpMarker = new THREE.Group();
    const ringGeo = new THREE.TorusGeometry(MISSION_START_RADIUS, 0.35, 8, 40).rotateX(Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xffc233, transparent: true, opacity: 0.9, fog: false });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.y = 0.4;
    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(MISSION_START_RADIUS * 0.7, MISSION_START_RADIUS * 0.9, 60, 24, 1, true),
      new THREE.MeshBasicMaterial({ color: 0xffc233, transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false, fog: false }),
    );
    beam.position.y = 30;
    this.cpMarker.add(ring, beam);
    this.cpMarker.visible = false;
    this.scene.add(this.cpMarker);
    this.arrow = new THREE.Mesh(new THREE.ConeGeometry(0.45, 1.3, 4).rotateX(Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xffc233, fog: false }));
    this.arrow.visible = false;
    this.scene.add(this.arrow);

    window.addEventListener('keydown', this.onKey);
    window.addEventListener('keyup', this.onKey);
    window.addEventListener('resize', this.onResize);
    this.applySettings(this.settings, true);
    this.updateEnvironment(true);
    this.ready = true;
    this.clock.start();
    this.loop();
  }

  // ------------------------------------------------------------------ public API
  setVehicle(id: string, colorIndex: number) {
    const spec = getVehicle(id);
    const color = spec.colors[colorIndex % spec.colors.length];
    const prev = this.player;
    this.player = buildCar(spec, color, this.tex.rim);
    if (prev) {
      this.scene.remove(prev.group);
      prev.paint.dispose();
      if (this.spotL) prev.body.remove(this.spotL, this.spotR, this.spotL.target, this.spotR.target);
    }
    this.scene.add(this.player.group);
    // headlights
    if (!this.spotL) {
      const mk = () => {
        const s = new THREE.SpotLight(0xfff4d6, 0, 90, 0.55, 0.6, 1.0);
        s.castShadow = false;
        return s;
      };
      this.spotL = mk();
      this.spotR = mk();
    }
    const L = spec.length, W = spec.width;
    this.spotL.position.set(W / 2 - 0.35, spec.hoodH - 0.2, L / 2);
    this.spotR.position.set(-(W / 2 - 0.35), spec.hoodH - 0.2, L / 2);
    this.spotL.target.position.set(W / 2 - 0.2, -0.6, L / 2 + 22);
    this.spotR.target.position.set(-(W / 2 - 0.2), -0.6, L / 2 + 22);
    this.player.body.add(this.spotL, this.spotL.target, this.spotR, this.spotR.target);
    this.syncPlayerVisual();
  }

  applySettings(s: Settings, initial = false) {
    const prevQ = this.settings.quality;
    this.settings = { ...s };
    const q = QUALITY[s.quality];
    if (!initial && prevQ !== s.quality) {
      this.renderer.setPixelRatio(q.pixelRatio);
      this.renderer.setSize(window.innerWidth, window.innerHeight, false);
      const shadowChanged = this.renderer.shadowMap.enabled !== q.shadows;
      this.renderer.shadowMap.enabled = q.shadows;
      this.sun.castShadow = q.shadows;
      this.sun.shadow.mapSize.set(q.shadowSize, q.shadowSize);
      if (this.sun.shadow.map) {
        this.sun.shadow.map.dispose();
        this.sun.shadow.map = null;
      }
      if (shadowChanged) this.scene.traverse((o) => {
        const m = (o as THREE.Mesh).material as THREE.Material | THREE.Material[] | undefined;
        if (!m) return;
        if (Array.isArray(m)) m.forEach((x) => (x.needsUpdate = true));
        else m.needsUpdate = true;
      });
    }
    (this.scene.fog as THREE.Fog).far = q.fogFar;
    this.rain.geometry.setDrawRange(0, q.rainCount);
    if (this.traffic) this.traffic.setCount(s.traffic ? q.trafficCount : 0, this.state.x, this.state.z);
    this.audio.setEnabled(s.sound);
    if (Math.abs(this.timeOfDay - s.timeOfDay) > 0.01 && !s.timeFlow) this.timeOfDay = s.timeOfDay;
    if (!initial && Math.abs(this.settings.timeOfDay - this.timeOfDay) > 0.6) this.timeOfDay = s.timeOfDay;
    this.cameraMode = s.camera;
    this.updateEnvironment(true);
  }

  setTimeOfDay(t: number) {
    this.timeOfDay = ((t % 24) + 24) % 24;
    this.settings.timeOfDay = this.timeOfDay;
    this.updateEnvironment(true);
  }

  setMode(m: EngineMode) {
    this.mode = m;
    if (m === 'play') {
      this.audio.start();
      this.audio.setEnabled(this.settings.sound);
      this.camPos.set(0, 0, 0); // forces snap
    }
  }

  setPaused(p: boolean) {
    this.paused = p;
    if (!p) this.clock.getDelta();
  }

  cycleCamera(): CameraMode {
    const order: CameraMode[] = ['chase', 'hood', 'top', 'cinematic'];
    this.cameraMode = order[(order.indexOf(this.cameraMode) + 1) % order.length];
    this.settings.camera = this.cameraMode;
    this.cineTimer = 0;
    return this.cameraMode;
  }

  setCameraMode(m: CameraMode) {
    this.cameraMode = m;
    this.settings.camera = m;
  }

  startFreeRoam() {
    this.mission = null;
    this.cpMarker.visible = false;
    this.arrow.visible = false;
    this.teleport(roadCoord(3) - 1.75, -110, 0);
    this.showMessage('Free roam – explore Sunfall City', 3);
  }

  startMission(id: string) {
    const m = MISSIONS.find((x) => x.id === id);
    if (!m) return;
    this.mission = m;
    this.cpIndex = 0;
    this.missionTime = 0;
    this.missionDone = false;
    this.teleport(m.start[0], m.start[1], m.startHeading);
    this.lastCheckpoint = { x: m.start[0], z: m.start[1], h: m.startHeading };
    this.cpMarker.visible = true;
    this.arrow.visible = true;
    this.placeMarker();
    this.showMessage(`${m.name} – reach the checkpoints`, 3);
  }

  abortMission() {
    this.mission = null;
    this.cpMarker.visible = false;
    this.arrow.visible = false;
  }

  resetCar() {
    if (this.mission && this.lastCheckpoint && !this.missionDone) {
      const c = this.lastCheckpoint;
      this.teleport(c.x, c.z, c.h);
      this.showMessage('Reset to last checkpoint', 1.5);
      return;
    }
    // snap to nearest road lane
    const s = this.state;
    const u = s.x - GRID0, v = s.z - GRID0;
    const ix = Math.max(0, Math.min(NR - 1, Math.round(u / PITCH)));
    const iz = Math.max(0, Math.min(NR - 1, Math.round(v / PITCH)));
    const dx = Math.abs(u - ix * PITCH), dz = Math.abs(v - iz * PITCH);
    const d = Math.max(Math.abs(s.x), Math.abs(s.z));
    if (d < 300) {
      if (dx < dz) this.teleport(roadCoord(ix) - 1.75, s.z, 0);
      else this.teleport(s.x, roadCoord(iz) + 1.75, Math.PI / 2);
    } else {
      this.teleport(s.x, s.z, s.heading);
    }
    this.showMessage('Vehicle reset', 1.5);
  }

  teleport(x: number, z: number, heading: number) {
    const s = this.state;
    s.x = x;
    s.z = z;
    s.heading = heading;
    resetVelocity(s);
    this.syncPlayerVisual();
    this.camPos.set(0, 0, 0);
  }

  showMessage(text: string, seconds = 2) {
    this.message = text;
    this.messageTimer = seconds;
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKey);
    window.removeEventListener('keyup', this.onKey);
    window.removeEventListener('resize', this.onResize);
    this.audio.dispose();
    this.renderer.dispose();
    this.pmrem.dispose();
  }

  // ------------------------------------------------------------------ input
  handleKey(e: KeyboardEvent) {
    if (e.type === 'keydown') {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) e.preventDefault();
      if (e.repeat) return;
      this.keys.add(e.code);
      if (this.mode !== 'play' || this.paused) return;
      if (e.code === 'KeyC') this.showMessage(`Camera: ${this.cycleCamera()}`, 1.2);
      if (e.code === 'KeyR') this.resetCar();
      if (e.code === 'KeyN') {
        this.headlightsManual = this.headlightsManual === null ? !this.headlights : !this.headlightsManual;
        this.showMessage(`Headlights ${this.headlightsManual ? 'on' : 'off'}`, 1.2);
      }
      if (e.code === 'KeyT') {
        this.setTimeOfDay(this.timeOfDay + 1);
        this.showMessage(`Time: ${this.clockString()}`, 1.2);
      }
    } else {
      this.keys.delete(e.code);
    }
  }

  readInput() {
    const k = this.keys;
    const i = this.input;
    i.throttle = k.has('KeyW') || k.has('ArrowUp') ? 1 : 0;
    i.brake = k.has('KeyS') || k.has('ArrowDown') ? 1 : 0;
    const left = k.has('KeyA') || k.has('ArrowLeft') ? 1 : 0;
    const right = k.has('KeyD') || k.has('ArrowRight') ? 1 : 0;
    i.steer = left - right; // positive = left (counter-clockwise)
    i.handbrake = k.has('Space');
  }

  resize() {
    if (!this.renderer) return;
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
  }

  // ------------------------------------------------------------------ loop
  loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    let dt = this.clock.getDelta();
    if (dt > 0.1) dt = 0.1;
    if (this.paused) {
      this.renderer.render(this.scene, this.camera);
      return;
    }
    // fps
    this.fpsAcc += dt;
    this.fpsFrames++;
    if (this.fpsAcc > 0.5) {
      this.fps = this.fpsFrames / this.fpsAcc;
      this.fpsAcc = 0;
      this.fpsFrames = 0;
    }
    if (this.settings.timeFlow) {
      this.timeOfDay = (this.timeOfDay + dt / 50) % 24;
      this.settings.timeOfDay = this.timeOfDay;
    }
    if (this.messageTimer > 0) {
      this.messageTimer -= dt;
      if (this.messageTimer <= 0) this.message = null;
    }

    if (this.mode === 'play') {
      this.readInput();
      // fixed-ish substeps for stability
      const steps = dt > 0.033 ? 2 : 1;
      for (let s = 0; s < steps; s++) this.stepPlayer(dt / steps);
      if (this.mission && !this.missionDone) {
        this.missionTime += dt;
        this.checkMission();
      }
      this.audio.update(this.state.rpm, this.input.throttle, Math.abs(this.state.vF), this.state.slipping);
    } else {
      this.input.throttle = 0;
    }

    // traffic
    this.trafficTimer += dt;
    if (this.trafficTimer > 9) {
      this.trafficTimer = 0;
      this.traffic.phaseA = !this.traffic.phaseA;
      this.updateTrafficLights();
    }
    this.traffic.update(dt, this.state.x, this.state.z, this.state.vx, this.state.vz, this.nightFactor > 0.4);
    if (this.mode === 'play' && this.traffic.collide(this.state, this.player.spec.width * 0.55 + 0.4)) {
      this.state.bodyVy -= 0.4;
    }

    this.updateCamera(dt);
    this.updateEnvironment(false);
    this.updateRain(dt);
    this.updateChunks();
    this.updateMarker(dt);

    this.hudTimer += dt;
    if (this.hudTimer > 0.1) {
      this.hudTimer = 0;
      this.emitHud();
      this.drawMinimap();
    }
    this.renderer.render(this.scene, this.camera);
  };

  // ------------------------------------------------------------------ player
  stepPlayer(dt: number) {
    const s = this.state;
    const spec = this.player.spec;
    const surf = surfaceAt(s.x, s.z);
    this.surface.kind = surf.kind;
    this.surface.grip = surf.grip;
    this.surface.speedMul = surf.speedMul;
    this.surface.bump = surf.bump;
    // slopes from ground samples
    const fx = Math.sin(s.heading), fz = Math.cos(s.heading);
    const rx = -fz, rz = fx;
    const hb = this.player.wheelbase / 2, ht = this.player.track;
    const hF = surfaceAt(s.x + fx * hb, s.z + fz * hb).y;
    const hR = surfaceAt(s.x - fx * hb, s.z - fz * hb).y;
    const hRt = surfaceAt(s.x + rx * ht, s.z + rz * ht).y;
    const hLt = surfaceAt(s.x - rx * ht, s.z - rz * ht).y;
    const pitch = Math.atan2(hF - hR, this.player.wheelbase);
    const roll = Math.atan2(hLt - hRt, ht * 2);
    const groundY = (hF + hR + hRt + hLt) / 4;
    const prevY = s.y;
    s.pitch += (pitch - s.pitch) * Math.min(1, dt * 10);
    s.roll += (roll - s.roll) * Math.min(1, dt * 10);
    s.y += (groundY - s.y) * Math.min(1, dt * 12);
    if (Math.abs(groundY - prevY) > 0.08) s.bodyVy += (groundY - prevY) * 4; // curb bump

    stepCar(s, spec, this.player.wheelbase, this.input, surf, s.pitch, this.wet, dt);
    this.collideBuildings();
    // world bounds
    const lim = WORLD_HALF - 15;
    if (Math.abs(s.x) > lim || Math.abs(s.z) > lim) {
      s.x = Math.max(-lim, Math.min(lim, s.x));
      s.z = Math.max(-lim, Math.min(lim, s.z));
      s.vx *= -0.3;
      s.vz *= -0.3;
      this.showMessage('End of the map', 1.5);
    }
    this.syncPlayerVisual();
  }

  collideBuildings() {
    const s = this.state;
    const spec = this.player.spec;
    const hl = spec.length / 2, hw = spec.width / 2;
    const fx = Math.sin(s.heading), fz = Math.cos(s.heading);
    const rx = -fz, rz = fx;
    const corners = [
      [hl, hw], [hl, -hw], [-hl, hw], [-hl, -hw],
    ];
    const cols = this.city.colliders;
    for (let k = 0; k < cols.length; k++) {
      const c = cols[k];
      if (c.minX - 6 > s.x || c.maxX + 6 < s.x || c.minZ - 6 > s.z || c.maxZ + 6 < s.z) continue;
      for (const [a, b] of corners) {
        const px = s.x + fx * a + rx * b;
        const pz = s.z + fz * a + rz * b;
        if (px > c.minX && px < c.maxX && pz > c.minZ && pz < c.maxZ) this.resolveAABB(c, px, pz);
      }
    }
  }

  resolveAABB(c: AABB, px: number, pz: number) {
    const s = this.state;
    const dxl = px - c.minX, dxr = c.maxX - px, dzl = pz - c.minZ, dzr = c.maxZ - pz;
    const m = Math.min(dxl, dxr, dzl, dzr);
    let nx = 0, nz = 0;
    if (m === dxl) nx = -1;
    else if (m === dxr) nx = 1;
    else if (m === dzl) nz = -1;
    else nz = 1;
    s.x += nx * (m + 0.02);
    s.z += nz * (m + 0.02);
    const vn = s.vx * nx + s.vz * nz;
    if (vn < 0) {
      const impact = -vn;
      s.vx -= nx * vn * 1.3;
      s.vz -= nz * vn * 1.3;
      s.vx *= 0.75;
      s.vz *= 0.75;
      if (impact > 4) {
        s.bodyVy -= Math.min(1.2, impact * 0.08);
        s.bodyPitch += (Math.random() - 0.5) * 0.1;
      }
    }
  }

  syncPlayerVisual() {
    const s = this.state;
    const g = this.player.group;
    g.position.set(s.x, s.y, s.z);
    g.rotation.order = 'YXZ';
    g.rotation.set(s.pitch, s.heading, s.roll);
    const b = this.player.body;
    b.rotation.set(s.bodyPitch, 0, s.bodyRoll);
    b.position.y = s.bodyY;
    for (let i = 0; i < 4; i++) {
      const w = this.player.wheels[i];
      w.rotation.x = s.wheelSpin;
      if (i < 2) w.rotation.y = s.steer;
    }
    const braking = this.input.brake > 0 || this.input.handbrake;
    this.player.tail.emissiveIntensity = braking ? 3 : this.headlights ? 1.0 : 0.25;
    this.player.head.emissiveIntensity = this.headlights ? 3.5 : 0.2;
  }

  // ------------------------------------------------------------------ missions
  placeMarker() {
    if (!this.mission) return;
    const p = this.mission.points[this.cpIndex];
    const y = surfaceAt(p[0], p[1]).y;
    this.cpMarker.position.set(p[0], y, p[1]);
    const isLast = this.cpIndex === this.mission.points.length - 1;
    const col = isLast ? 0x59d66b : 0xffc233;
    (this.cpMarker.children[0] as THREE.Mesh).material = new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.9, fog: false });
    ((this.cpMarker.children[1] as THREE.Mesh).material as THREE.MeshBasicMaterial).color.setHex(col);
    (this.arrow.material as THREE.MeshBasicMaterial).color.setHex(col);
  }

  checkMission() {
    const m = this.mission!;
    const p = m.points[this.cpIndex];
    const d = Math.hypot(this.state.x - p[0], this.state.z - p[1]);
    if (d < MISSION_START_RADIUS + 1) {
      this.lastCheckpoint = { x: p[0], z: p[1], h: this.state.heading };
      this.cpIndex++;
      if (this.cpIndex >= m.points.length) {
        this.missionDone = true;
        const t = this.missionTime;
        const best = this.cb.getBest(m.id);
        const isNewBest = best === null || t < best;
        if (isNewBest) this.cb.saveBest(m.id, t);
        this.cpMarker.visible = false;
        this.arrow.visible = false;
        this.showMessage('Finished!', 3);
        this.cb.onMissionComplete({ id: m.id, name: m.name, time: t, best: isNewBest ? t : best, isNewBest, par: m.par });
      } else {
        this.placeMarker();
        this.showMessage(`Checkpoint ${this.cpIndex}/${m.points.length}`, 1.2);
      }
    }
  }

  updateMarker(dt: number) {
    if (!this.cpMarker.visible) return;
    this.cpMarker.rotation.y += dt * 0.8;
    const ring = this.cpMarker.children[0];
    ring.scale.setScalar(1 + Math.sin(performance.now() * 0.004) * 0.06);
    const p = this.mission!.points[this.cpIndex];
    const s = this.state;
    this.arrow.position.set(s.x, s.y + this.player.spec.roofH + 1.2 + Math.sin(performance.now() * 0.005) * 0.1, s.z);
    this.arrow.rotation.y = Math.atan2(p[0] - s.x, p[1] - s.z);
  }

  // ------------------------------------------------------------------ camera
  updateCamera(dt: number) {
    const cam = this.camera;
    const s = this.state;
    const fx = Math.sin(s.heading), fz = Math.cos(s.heading);
    const spec = this.player.spec;
    const snap = this.camPos.lengthSq() === 0;

    if (this.mode === 'attract') {
      this.attractAngle += dt * 0.05;
      const r = 210;
      const tx = Math.cos(this.attractAngle) * r, tz = Math.sin(this.attractAngle) * r;
      this.tmpV.set(tx, 95 + Math.sin(this.attractAngle * 2) * 15, tz);
      if (snap) this.camPos.copy(this.tmpV);
      this.camPos.lerp(this.tmpV, Math.min(1, dt * 1.5));
      cam.position.copy(this.camPos);
      cam.up.set(0, 1, 0);
      cam.lookAt(Math.cos(this.attractAngle + 1.2) * 60, 25, Math.sin(this.attractAngle + 1.2) * 60);
      cam.fov = 58;
      cam.updateProjectionMatrix();
      return;
    }

    const speed = Math.abs(s.vF);
    if (this.cameraMode === 'chase') {
      const dist = 6.2 + spec.length * 0.35 + speed * 0.045;
      const height = 2.2 + spec.roofH * 0.5 + speed * 0.012;
      // lag the camera behind the *velocity* direction a little for drift feel
      const vlen = Math.hypot(s.vx, s.vz);
      let bx = fx, bz = fz;
      if (vlen > 3 && s.vF > 0) {
        const blend = Math.min(0.5, (vlen - 3) * 0.05);
        bx = fx * (1 - blend) + (s.vx / vlen) * blend;
        bz = fz * (1 - blend) + (s.vz / vlen) * blend;
        const l = Math.hypot(bx, bz);
        bx /= l;
        bz /= l;
      }
      this.tmpV.set(s.x - bx * dist, s.y + height, s.z - bz * dist);
      if (snap) this.camPos.copy(this.tmpV);
      const k = 1 - Math.exp(-dt * 6);
      this.camPos.lerp(this.tmpV, k);
      // keep the camera above ground
      const gy = surfaceAt(this.camPos.x, this.camPos.z).y;
      if (this.camPos.y < gy + 1.0) this.camPos.y = gy + 1.0;
      cam.position.copy(this.camPos);
      this.tmpV2.set(s.x + fx * 3, s.y + 1.1, s.z + fz * 3);
      this.camLook.lerp(this.tmpV2, snap ? 1 : 1 - Math.exp(-dt * 10));
      cam.up.set(0, 1, 0);
      cam.lookAt(this.camLook);
      cam.fov = 62 + Math.min(14, speed * 0.25);
    } else if (this.cameraMode === 'hood') {
      const g = this.player.group;
      this.tmpV.set(0, spec.hoodH + 0.45, spec.cabin[0] * spec.length - 0.4);
      g.localToWorld(this.tmpV);
      cam.position.copy(this.tmpV);
      this.camPos.copy(this.tmpV);
      this.tmpV2.set(0, spec.hoodH + 0.2, spec.length / 2 + 25);
      g.localToWorld(this.tmpV2);
      cam.up.set(0, 1, 0);
      cam.lookAt(this.tmpV2);
      cam.rotateZ(-s.roll * 0.3);
      cam.fov = 72;
    } else if (this.cameraMode === 'top') {
      this.tmpV.set(s.x - fx * 4, s.y + 48 + speed * 0.4, s.z - fz * 4);
      if (snap) this.camPos.copy(this.tmpV);
      this.camPos.lerp(this.tmpV, 1 - Math.exp(-dt * 5));
      cam.position.copy(this.camPos);
      cam.up.set(fx, 0, fz);
      cam.lookAt(s.x + fx * 6, s.y, s.z + fz * 6);
      cam.fov = 55;
    } else {
      // cinematic: fixed tripod positions that hop ahead of the car
      this.cineTimer -= dt;
      const d = Math.hypot(s.x - this.cinePos.x, s.z - this.cinePos.z);
      if (this.cineTimer <= 0 || d > 90 || snap) {
        const ahead = 30 + Math.random() * 25;
        const side = (Math.random() < 0.5 ? -1 : 1) * (5 + Math.random() * 8);
        const px = s.x + fx * ahead - fz * side;
        const pz = s.z + fz * ahead + fx * side;
        this.cinePos.set(px, surfaceAt(px, pz).y + 1.2 + Math.random() * 4, pz);
        this.cineTimer = 6;
        this.camPos.copy(this.cinePos);
      }
      cam.position.copy(this.cinePos);
      this.tmpV2.set(s.x, s.y + 0.8, s.z);
      this.camLook.lerp(this.tmpV2, snap ? 1 : 1 - Math.exp(-dt * 8));
      cam.up.set(0, 1, 0);
      cam.lookAt(this.camLook);
      cam.fov = 38 + Math.min(20, d * 0.2);
    }
    cam.updateProjectionMatrix();
  }

  // ------------------------------------------------------------------ environment
  clockString() {
    const h = Math.floor(this.timeOfDay);
    const m = Math.floor((this.timeOfDay - h) * 60);
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
  }

  updateEnvironment(force: boolean) {
    const t = this.timeOfDay;
    const dayFrac = (t - 6) / 12; // 0 at sunrise, 1 at sunset
    const elev = Math.sin(dayFrac * Math.PI);
    const az = dayFrac * Math.PI;
    const sunDir = this.tmpV.set(Math.cos(az), Math.max(elev, -0.35), 0.35).normalize();
    const daylight = THREE.MathUtils.smoothstep(elev, -0.08, 0.28);
    const golden = Math.max(0, 1 - Math.abs(elev) / 0.32) * daylight;
    const night = 1 - daylight;
    this.nightFactor = night;
    const w = this.settings.weather;
    const cloud = w === 'clear' ? 0 : w === 'cloudy' ? 0.7 : w === 'rain' ? 0.9 : 0.6;
    this.wet = w === 'rain';

    // sun light
    const sunCol = lerpColor(this.colA, new THREE.Color(1, 0.98, 0.93), new THREE.Color(1, 0.55, 0.28), golden);
    sunCol.lerp(new THREE.Color(0.8, 0.82, 0.88), cloud * 0.8);
    const moonCol = this.colB.setRGB(0.45, 0.55, 0.85);
    const sunIntensity = daylight * (2.9 - cloud * 1.9) + night * 0.35 * (1 - cloud * 0.6);
    if (daylight <= 0.05) this.sun.color.copy(moonCol);
    else this.sun.color.copy(sunCol).lerp(moonCol, Math.max(0, 1 - daylight * 3));
    this.sun.intensity = sunIntensity;
    const lightDir = daylight > 0.02 ? sunDir.clone() : new THREE.Vector3(-0.4, 0.8, 0.3).normalize();
    const px = this.state.x, pz = this.state.z;
    this.sun.position.set(px + lightDir.x * 180, this.state.y + lightDir.y * 180, pz + lightDir.z * 180);
    this.sun.target.position.set(px, this.state.y, pz);

    // sky colours
    const dayTop = new THREE.Color(0.24, 0.47, 0.9), dayHor = new THREE.Color(0.74, 0.85, 0.95);
    const setTop = new THREE.Color(0.2, 0.22, 0.48), setHor = new THREE.Color(1.0, 0.56, 0.3);
    const nightTop = new THREE.Color(0.008, 0.012, 0.035), nightHor = new THREE.Color(0.04, 0.06, 0.12);
    const top = lerpColor(new THREE.Color(), nightTop, dayTop, daylight).lerp(setTop, golden * 0.8);
    const hor = lerpColor(new THREE.Color(), nightHor, dayHor, daylight).lerp(setHor, golden * 0.9);
    // clouds / rain desaturate
    const grey = new THREE.Color(0.55, 0.58, 0.62).multiplyScalar(0.25 + daylight * 0.75);
    top.lerp(grey, cloud);
    hor.lerp(grey.clone().multiplyScalar(1.15), cloud);
    const fogCol = hor.clone();
    if (w === 'fog') fogCol.lerp(new THREE.Color(0.8, 0.82, 0.85).multiplyScalar(0.2 + daylight * 0.8), 0.7);
    const u = this.skyMat.uniforms;
    u.topColor.value.copy(top);
    u.horizonColor.value.copy(hor);
    u.sunDir.value.copy(sunDir);
    u.sunColor.value.copy(sunCol).multiplyScalar(daylight * (1 - cloud * 0.85));
    u.fogColor.value.copy(fogCol);
    u.fogMix.value = w === 'fog' ? 0.85 : w === 'rain' ? 0.45 : w === 'cloudy' ? 0.2 : 0;

    const fog = this.scene.fog as THREE.Fog;
    fog.color.copy(fogCol);
    const q = QUALITY[this.settings.quality];
    const fogFar = w === 'fog' ? 170 : w === 'rain' ? q.fogFar * 0.5 : w === 'cloudy' ? q.fogFar * 0.8 : q.fogFar;
    fog.near = w === 'fog' ? 5 : w === 'rain' ? 30 : 90;
    fog.far += (fogFar - fog.far) * (force ? 1 : 0.05);

    // ambient
    this.hemi.color.copy(top).lerp(new THREE.Color(1, 1, 1), 0.3);
    this.hemi.groundColor.setRGB(0.35, 0.3, 0.25).multiplyScalar(0.3 + daylight * 0.7);
    this.hemi.intensity = 0.25 + daylight * 0.75 * (1 - cloud * 0.3) + cloud * daylight * 0.5;
    this.ambient.intensity = 0.05 + night * 0.12;
    this.renderer.toneMappingExposure = 1.0 + night * 0.25;

    // night things
    (this.stars.material as THREE.PointsMaterial).opacity = Math.max(0, night - 0.2) * (1 - cloud);
    this.moon.material.opacity = Math.max(0, night - 0.1) * (1 - cloud * 0.9);
    this.moon.position.copy(this.camera.position).add(new THREE.Vector3(-0.4, 0.8, 0.3).normalize().multiplyScalar(1200));
    this.city.lampHeadMat.emissiveIntensity = night > 0.3 ? 2.5 : 0;
    const windows = THREE.MathUtils.smoothstep(night, 0.25, 0.7) * 0.75;
    for (const m of this.city.facadeMats) m.emissiveIntensity = windows;
    const autoLights = this.settings.headlightsAuto && (night > 0.35 || w === 'fog' || w === 'rain');
    this.headlights = this.headlightsManual !== null ? this.headlightsManual : autoLights;
    const spotI = this.headlights ? 60 + night * 40 : 0;
    this.spotL.intensity = spotI;
    this.spotR.intensity = spotI;

    // wet roads
    for (const m of this.city.roadMats) {
      const wr = this.wet ? 0.35 : 0.92;
      m.roughness += (wr - m.roughness) * (force ? 1 : 0.05);
      m.metalness = this.wet ? 0.25 : 0;
    }

    // sky follows camera
    this.sky.position.copy(this.camera.position);
    this.stars.position.copy(this.camera.position);

    // env map refresh (cheap, throttled)
    const dtEnv = Math.abs(t - this.lastEnvTime);
    if (force || dtEnv > 0.34 || this.lastEnvWeather !== w) {
      this.lastEnvTime = t;
      this.lastEnvWeather = w;
      const old = this.envTex;
      const rt = this.pmrem.fromScene(this.envScene, 0.02, 1, 600);
      this.envTex = rt.texture;
      this.scene.environment = this.envTex;
      this.scene.environmentIntensity = 0.55 + daylight * 0.5;
      if (old) old.dispose();
    }
  }

  updateTrafficLights() {
    const im = this.city.trafficLamps;
    const c = new THREE.Color();
    const A = this.traffic.phaseA;
    for (let i = 0; i < this.city.trafficPhaseA.length; i++) {
      const ns = this.city.trafficPhaseA[i];
      const red = this.city.trafficIsRed[i];
      const k = i % 3;
      if (k === 1) continue; // amber stays dim
      const green = ns === A;
      const lit = red ? !green : green;
      if (red) c.setRGB(lit ? 1 : 0.25, lit ? 0.1 : 0.03, lit ? 0.08 : 0.03);
      else c.setRGB(lit ? 0.15 : 0.03, lit ? 1 : 0.22, lit ? 0.35 : 0.08);
      im.setColorAt(i, c);
    }
    if (im.instanceColor) im.instanceColor.needsUpdate = true;
  }

  updateRain(dt: number) {
    const on = this.settings.weather === 'rain';
    this.rain.visible = on;
    if (!on) return;
    const pos = this.rain.geometry.getAttribute('position') as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    const n = this.rain.geometry.drawRange.count;
    const cx = this.camera.position.x, cy = this.camera.position.y, cz = this.camera.position.z;
    const fall = 28 * dt;
    const windX = 3 * dt;
    for (let i = 0; i < n; i++) {
      let y = arr[i * 3 + 1] - fall;
      let x = arr[i * 3] + windX;
      let z = arr[i * 3 + 2];
      if (y < cy - 6) {
        y = cy + 20 + Math.random() * 8;
        x = cx + (Math.random() - 0.5) * 60;
        z = cz + (Math.random() - 0.5) * 60;
      }
      if (Math.abs(x - cx) > 30) x = cx + (Math.random() - 0.5) * 60;
      if (Math.abs(z - cz) > 30) z = cz + (Math.random() - 0.5) * 60;
      arr[i * 3] = x;
      arr[i * 3 + 1] = y;
      arr[i * 3 + 2] = z;
    }
    pos.needsUpdate = true;
  }

  updateChunks() {
    const q = QUALITY[this.settings.quality];
    const cp = this.camera.position;
    for (const ch of this.city.chunks) {
      const d = Math.hypot(ch.center.x - cp.x, ch.center.z - cp.z) - ch.radius;
      const mainVis = d < q.drawDistance;
      const propVis = d < q.propDistance;
      for (const o of ch.main) o.visible = mainVis;
      for (const o of ch.props) o.visible = propVis;
    }
  }

  // ------------------------------------------------------------------ HUD / minimap
  emitHud() {
    const s = this.state;
    let mission: MissionHud | null = null;
    if (this.mission) {
      const p = this.mission.points[Math.min(this.cpIndex, this.mission.points.length - 1)];
      mission = {
        id: this.mission.id,
        name: this.mission.name,
        checkpoint: this.cpIndex,
        total: this.mission.points.length,
        time: this.missionTime,
        best: this.cb.getBest(this.mission.id),
        distance: Math.hypot(p[0] - s.x, p[1] - s.z),
        finished: this.missionDone,
      };
    }
    this.cb.onHud({
      speed: Math.abs(s.vF) * 3.6,
      rpm: s.rpm,
      gear: s.gear,
      surface: this.surface.kind,
      clock: this.clockString(),
      weather: this.settings.weather,
      camera: this.cameraMode,
      headlights: this.headlights,
      handbrake: this.input.handbrake,
      mission,
      message: this.message,
      fps: this.fps,
      drawCalls: this.renderer.info.render.calls,
      vehicleName: this.player.spec.name,
    });
  }

  drawMinimap() {
    const c = this.minimap;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    const W = c.width, H = c.height;
    const s = this.state;
    const scale = 0.28; // px per metre
    ctx.clearRect(0, 0, W, H);
    ctx.save();
    ctx.beginPath();
    ctx.arc(W / 2, H / 2, W / 2 - 2, 0, Math.PI * 2);
    ctx.clip();
    ctx.fillStyle = '#1d2a1e';
    ctx.fillRect(0, 0, W, H);
    ctx.translate(W / 2, H / 2 + 18);
    ctx.rotate(s.heading - Math.PI);
    ctx.scale(scale, scale);
    ctx.translate(-s.x, -s.z);
    // ring
    ctx.strokeStyle = '#8a8d90';
    ctx.lineWidth = 12;
    ctx.strokeRect(-this.minimapData.ring, -this.minimapData.ring, this.minimapData.ring * 2, this.minimapData.ring * 2);
    // trails
    ctx.lineWidth = 7;
    ctx.strokeStyle = '#8a6b46';
    for (const tr of this.minimapData.trails) {
      ctx.beginPath();
      for (let i = 0; i < tr.length; i += 2) i === 0 ? ctx.moveTo(tr[i], tr[i + 1]) : ctx.lineTo(tr[i], tr[i + 1]);
      ctx.stroke();
    }
    // roads
    ctx.strokeStyle = '#6b6f75';
    ctx.lineWidth = 14;
    ctx.beginPath();
    for (const [x1, z1, x2, z2] of this.minimapData.roads) {
      ctx.moveTo(x1, z1);
      ctx.lineTo(x2, z2);
    }
    ctx.stroke();
    // mission route
    if (this.mission && !this.missionDone) {
      const pts = this.mission.points;
      ctx.strokeStyle = 'rgba(255,194,51,0.5)';
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.moveTo(s.x, s.z);
      for (let i = this.cpIndex; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
      ctx.stroke();
      const p = pts[this.cpIndex];
      ctx.fillStyle = this.cpIndex === pts.length - 1 ? '#59d66b' : '#ffc233';
      ctx.beginPath();
      ctx.arc(p[0], p[1], 12, 0, Math.PI * 2);
      ctx.fill();
    }
    // traffic
    ctx.fillStyle = '#d8d8d8';
    for (const car of this.traffic.cars) ctx.fillRect(car.x - 4, car.z - 4, 8, 8);
    ctx.restore();
    // player arrow
    ctx.save();
    ctx.translate(W / 2, H / 2 + 18);
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(0, -9);
    ctx.lineTo(6, 7);
    ctx.lineTo(0, 4);
    ctx.lineTo(-6, 7);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(W / 2, H / 2, W / 2 - 2, 0, Math.PI * 2);
    ctx.stroke();
    // north indicator (north = -z in world; map rotates with heading)
    ctx.fillStyle = '#ff5c5c';
    ctx.font = 'bold 10px sans-serif';
    ctx.textAlign = 'center';
    const ang = s.heading + Math.PI;
    const r = W / 2 - 12;
    ctx.fillText('N', W / 2 + Math.sin(ang) * r, Math.min(H - 4, Math.max(10, H / 2 + 18 - Math.cos(ang) * r)) + 3);
  }
}
