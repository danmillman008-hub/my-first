import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { buildCar, getVehicle } from '../game/vehicles';
import { createRimTexture } from '../game/textures';

let rimTex: THREE.Texture | null = null;

export default function GaragePreview({ vehicleId, colorIndex }: { vehicleId: string; colorIndex: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const carRef = useRef<THREE.Group | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);

  useEffect(() => {
    const canvas = ref.current!;
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.shadowMap.enabled = true;
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
    camera.position.set(7.5, 2.6, 7.5);
    camera.lookAt(0, 0.7, 0);
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    const key = new THREE.DirectionalLight(0xffffff, 3);
    key.position.set(5, 8, 4);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    scene.add(key, new THREE.HemisphereLight(0xbfd4ff, 0x30281f, 0.6));
    const floor = new THREE.Mesh(new THREE.CircleGeometry(5, 48), new THREE.MeshStandardMaterial({ color: 0x1b1d22, roughness: 0.35, metalness: 0.4 }));
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);
    const rim = new THREE.Mesh(new THREE.RingGeometry(4.9, 5.1, 64), new THREE.MeshBasicMaterial({ color: 0xffc233, side: THREE.DoubleSide }));
    rim.rotation.x = -Math.PI / 2;
    rim.position.y = 0.01;
    scene.add(rim);

    let raf = 0;
    let angle = 0.6;
    const clock = new THREE.Clock();
    const resize = () => {
      const w = canvas.clientWidth || 400;
      const h = canvas.clientHeight || 300;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    const loop = () => {
      raf = requestAnimationFrame(loop);
      angle += clock.getDelta() * 0.5;
      if (carRef.current) carRef.current.rotation.y = angle;
      renderer.render(scene, camera);
    };
    loop();
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      renderer.dispose();
      pmrem.dispose();
    };
  }, []);

  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;
    if (!rimTex) rimTex = createRimTexture();
    const spec = getVehicle(vehicleId);
    const model = buildCar(spec, spec.colors[colorIndex % spec.colors.length], rimTex);
    model.group.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) o.castShadow = true;
    });
    if (carRef.current) {
      carRef.current.rotation.y = 0;
      scene.remove(carRef.current);
    }
    model.group.rotation.y = carRef.current?.rotation.y ?? 0.6;
    carRef.current = model.group;
    scene.add(model.group);
  }, [vehicleId, colorIndex]);

  return <canvas ref={ref} className="h-full w-full" />;
}
