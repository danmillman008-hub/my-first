import { VEHICLES, getVehicle } from '../game/vehicles';
import { MISSIONS } from '../game/missions';
import type { Settings } from '../game/types';
import GaragePreview from './GaragePreview';
import { Key, MenuButton, Panel, Segmented, StatBar, Toggle, formatTime } from './ui';
import { cn } from '../utils/cn';

// ---------------------------------------------------------------- Main menu
export function MainMenu({
  onFreeRoam, onMissions, onGarage, onSettings, vehicleName, version,
}: { onFreeRoam: () => void; onMissions: () => void; onGarage: () => void; onSettings: () => void; vehicleName: string; version: string }) {
  return (
    <div className="pointer-events-auto flex h-full w-full flex-col justify-between p-6 md:p-12">
      <div>
        <div className="flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.35em] text-amber-300">
          <span className="h-px w-10 bg-amber-300" /> Open-world driving
        </div>
        <h1 className="mt-2 text-6xl font-black uppercase italic leading-[0.85] tracking-tighter text-white drop-shadow-[0_6px_0_rgba(0,0,0,0.5)] md:text-8xl">
          Sunfall
          <br />
          <span className="text-amber-400">City</span> Drive
        </h1>
        <p className="mt-4 max-w-md text-sm text-white/70">
          A lightweight, stylised open-world driving game. Procedural city, seven original cars, day/night, weather, and time-trial routes –
          rendered in real time in your browser.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-[320px_1fr] md:items-end">
        <div className="flex flex-col gap-2">
          <MenuButton primary onClick={onFreeRoam} hint="Enter">Free Roam</MenuButton>
          <MenuButton onClick={onMissions} hint="Routes">Missions &amp; Time Trials</MenuButton>
          <MenuButton onClick={onGarage} hint={vehicleName}>Garage</MenuButton>
          <MenuButton onClick={onSettings} hint="Graphics">Settings</MenuButton>
        </div>
        <div className="text-xs text-white/50 md:text-right">
          <div className="mb-2 flex flex-wrap gap-x-4 gap-y-1 md:justify-end">
            <span><Key>W</Key><Key>A</Key><Key>S</Key><Key>D</Key> drive</span>
            <span><Key>Space</Key> handbrake</span>
            <span><Key>C</Key> camera</span>
            <span><Key>R</Key> reset</span>
            <span><Key>N</Key> lights</span>
            <span><Key>T</Key> +1 hour</span>
            <span><Key>Esc</Key> pause</span>
          </div>
          <p>Runs locally – no downloads, no accounts. {version}</p>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- Garage
export function Garage({
  vehicleId, colorIndex, onSelect, onColor, onBack, onDrive, inGame,
}: {
  vehicleId: string; colorIndex: number; onSelect: (id: string) => void; onColor: (i: number) => void; onBack: () => void; onDrive: () => void; inGame: boolean;
}) {
  const spec = getVehicle(vehicleId);
  return (
    <div className="pointer-events-auto flex h-full w-full items-center justify-center p-4 md:p-8">
      <Panel className="grid w-full max-w-6xl gap-6 md:grid-cols-[260px_1fr_280px]" title="Garage" subtitle="Choose your ride">
        <div className="flex flex-col gap-1 md:col-start-1">
          {VEHICLES.map((v) => (
            <button
              key={v.id}
              onClick={() => onSelect(v.id)}
              className={cn(
                'flex items-center justify-between border-l-4 px-4 py-2.5 text-left transition-all',
                v.id === vehicleId ? 'border-amber-400 bg-amber-400/15 text-white' : 'border-transparent bg-black/30 text-white/70 hover:bg-white/5 hover:text-white',
              )}
            >
              <div>
                <div className="text-sm font-bold uppercase tracking-wide">{v.name}</div>
                <div className="text-[10px] uppercase tracking-[0.2em] text-white/40">{v.style}</div>
              </div>
              <span className="h-3 w-3 rounded-full border border-white/30" style={{ background: v.colors[0] }} />
            </button>
          ))}
        </div>

        <div className="relative min-h-[300px] border border-white/10 bg-gradient-to-b from-[#1a1f2a] to-[#07090c]">
          <GaragePreview vehicleId={vehicleId} colorIndex={colorIndex} />
          <div className="pointer-events-none absolute left-4 top-4 text-[10px] uppercase tracking-[0.3em] text-white/40">Turntable preview</div>
          <div className="absolute bottom-4 left-4 flex gap-2">
            {spec.colors.map((c, i) => (
              <button
                key={c}
                onClick={() => onColor(i)}
                className={cn('h-7 w-7 rounded-full border-2 transition-transform hover:scale-110', i === colorIndex % spec.colors.length ? 'border-amber-400 scale-110' : 'border-white/30')}
                style={{ background: c }}
                aria-label={`colour ${i + 1}`}
              />
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div>
            <h3 className="text-2xl font-black uppercase italic tracking-tight text-white">{spec.name}</h3>
            <p className="mt-1 text-sm text-white/60">{spec.tagline}</p>
          </div>
          <div className="flex flex-col gap-2">
            <StatBar label="Top speed" value={spec.stats.speed} />
            <StatBar label="Accel" value={spec.stats.accel} />
            <StatBar label="Handling" value={spec.stats.handling} />
            <StatBar label="Off-road" value={spec.stats.offroad} />
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px] uppercase tracking-wider text-white/50">
            <div>Length <span className="text-white">{spec.length.toFixed(2)} m</span></div>
            <div>Width <span className="text-white">{spec.width.toFixed(2)} m</span></div>
            <div>V-max <span className="text-white">{Math.round(spec.topSpeed * 3.6)} km/h</span></div>
            <div>Drive <span className="text-white">{spec.style === 'suv' || spec.style === 'pickup' ? 'AWD' : spec.style === 'hatch' || spec.style === 'van' ? 'FWD' : 'RWD'}</span></div>
          </div>
          <div className="mt-auto flex flex-col gap-2">
            <MenuButton primary onClick={onDrive}>{inGame ? 'Apply & resume' : 'Drive'}</MenuButton>
            <MenuButton onClick={onBack}>Back</MenuButton>
          </div>
        </div>
      </Panel>
    </div>
  );
}

// ---------------------------------------------------------------- Missions
export function Missions({ bestTimes, onStart, onBack }: { bestTimes: Record<string, number>; onStart: (id: string) => void; onBack: () => void }) {
  const typeLabel: Record<string, string> = { sprint: 'Sprint', trial: 'Time trial', rally: 'Rally', delivery: 'Delivery', tour: 'Tour' };
  return (
    <div className="pointer-events-auto flex h-full w-full items-center justify-center p-4 md:p-8">
      <Panel className="w-full max-w-4xl" title="Routes & Missions" subtitle="Checkpoint challenges – R resets to the last checkpoint">
        <div className="grid gap-2 md:grid-cols-2">
          {MISSIONS.map((m) => {
            const best = bestTimes[m.id];
            return (
              <button
                key={m.id}
                onClick={() => onStart(m.id)}
                className="group flex flex-col border border-white/10 bg-black/40 p-4 text-left transition-all hover:border-amber-400 hover:bg-amber-400/10"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-amber-300">{typeLabel[m.type]}</span>
                  <span className="text-[10px] uppercase tracking-widest text-white/40">{m.points.length} checkpoints</span>
                </div>
                <div className="mt-1 text-lg font-black uppercase italic tracking-tight text-white group-hover:text-amber-200">{m.name}</div>
                <p className="mt-1 text-xs text-white/60">{m.description}</p>
                <div className="mt-3 flex gap-4 font-mono text-xs">
                  <span className="text-white/50">Par <span className="text-white">{formatTime(m.par)}</span></span>
                  <span className="text-white/50">Best <span className={best ? 'text-amber-300' : 'text-white/40'}>{best ? formatTime(best) : '--:--.--'}</span></span>
                  {best && best < m.par && <span className="text-emerald-400">★ Under par</span>}
                </div>
              </button>
            );
          })}
        </div>
        <div className="mt-4 flex justify-end">
          <MenuButton onClick={onBack} className="max-w-[200px]">Back</MenuButton>
        </div>
      </Panel>
    </div>
  );
}

// ---------------------------------------------------------------- Settings
export function SettingsPanel({
  settings, onChange, onBack, note,
}: { settings: Settings; onChange: (s: Settings) => void; onBack: () => void; note?: string }) {
  const set = <K extends keyof Settings>(k: K, v: Settings[K]) => onChange({ ...settings, [k]: v });
  const h = Math.floor(settings.timeOfDay);
  const mm = Math.floor((settings.timeOfDay - h) * 60);
  return (
    <div className="pointer-events-auto flex h-full w-full items-center justify-center p-4 md:p-8">
      <Panel className="w-full max-w-2xl" title="Settings" subtitle="Graphics · World · Controls">
        <div className="flex flex-col gap-5">
          <Segmented
            label="Graphics quality"
            value={settings.quality}
            options={[{ value: 'low', label: 'Low' }, { value: 'medium', label: 'Medium' }, { value: 'high', label: 'High' }]}
            onChange={(v) => set('quality', v)}
          />
          <p className="-mt-3 text-[11px] text-white/45">
            {settings.quality === 'low' && 'No shadows, 0.75× resolution, short draw distance, 6 traffic cars. Best for integrated GPUs.'}
            {settings.quality === 'medium' && '1024 shadow map, native resolution, 480 m draw distance, 10 traffic cars.'}
            {settings.quality === 'high' && '2048 shadow map, full device resolution, 700 m draw distance, 14 traffic cars.'}
          </p>
          <Segmented
            label="Weather"
            value={settings.weather}
            options={[{ value: 'clear', label: 'Clear' }, { value: 'cloudy', label: 'Cloudy' }, { value: 'rain', label: 'Rain' }, { value: 'fog', label: 'Fog' }]}
            onChange={(v) => set('weather', v)}
          />
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-widest text-white/60">Time of day</span>
              <span className="font-mono text-sm text-amber-300">{h.toString().padStart(2, '0')}:{mm.toString().padStart(2, '0')}</span>
            </div>
            <input
              type="range" min={0} max={23.99} step={0.25} value={settings.timeOfDay}
              onChange={(e) => set('timeOfDay', parseFloat(e.target.value))}
              className="accent-amber-400"
            />
            <div className="flex gap-1">
              {[{ l: 'Dawn', t: 6.2 }, { l: 'Noon', t: 12.5 }, { l: 'Golden', t: 17.6 }, { l: 'Dusk', t: 18.6 }, { l: 'Night', t: 23 }].map((p) => (
                <button key={p.l} onClick={() => set('timeOfDay', p.t)} className="border border-white/15 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-white/70 hover:border-amber-400 hover:text-white">
                  {p.l}
                </button>
              ))}
            </div>
          </div>
          <Toggle label="Time flows (24 h ≈ 20 min)" value={settings.timeFlow} onChange={(v) => set('timeFlow', v)} />
          <Segmented
            label="Camera"
            value={settings.camera}
            options={[{ value: 'chase', label: 'Chase' }, { value: 'hood', label: 'Hood' }, { value: 'top', label: 'Top-down' }, { value: 'cinematic', label: 'Cinematic' }]}
            onChange={(v) => set('camera', v)}
          />
          <Toggle label="AI traffic" value={settings.traffic} onChange={(v) => set('traffic', v)} />
          <Toggle label="Automatic headlights" value={settings.headlightsAuto} onChange={(v) => set('headlightsAuto', v)} />
          <Toggle label="Engine sound" value={settings.sound} onChange={(v) => set('sound', v)} />
          {note && <p className="text-[11px] text-amber-300/80">{note}</p>}
          <MenuButton primary onClick={onBack}>Done</MenuButton>
        </div>
      </Panel>
    </div>
  );
}
