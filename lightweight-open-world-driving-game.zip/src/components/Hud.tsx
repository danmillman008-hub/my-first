import type { RefObject } from 'react';
import type { HudState } from '../game/types';
import { formatTime, Key, MenuButton, Panel } from './ui';
import { cn } from '../utils/cn';

const WEATHER_ICON: Record<string, string> = { clear: '☀', cloudy: '☁', rain: '🌧', fog: '🌫' };

export function Hud({ hud, minimapRef, showDebug }: { hud: HudState | null; minimapRef: RefObject<HTMLCanvasElement | null>; showDebug: boolean }) {
  const speed = hud ? Math.round(hud.speed) : 0;
  const rpm = hud?.rpm ?? 0;
  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      {/* top-left: clock / weather / mission */}
      <div className="absolute left-4 top-4 flex flex-col gap-2 md:left-6 md:top-6">
        <div className="flex items-center gap-3 text-white">
          <span className="font-mono text-2xl font-bold tracking-tight drop-shadow">{hud?.clock ?? '--:--'}</span>
          <span className="text-lg drop-shadow">{WEATHER_ICON[hud?.weather ?? 'clear']}</span>
          {hud?.headlights && <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">● Lights</span>}
        </div>
        {hud?.mission && (
          <div className="border-l-4 border-amber-400 bg-black/50 px-3 py-2 backdrop-blur-sm">
            <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-amber-300">{hud.mission.name}</div>
            <div className="flex items-baseline gap-3">
              <span className="font-mono text-2xl font-bold text-white">{formatTime(hud.mission.time)}</span>
              <span className="text-xs text-white/60">
                CP {Math.min(hud.mission.checkpoint + 1, hud.mission.total)}/{hud.mission.total}
              </span>
            </div>
            <div className="flex gap-3 text-[11px] text-white/60">
              <span>Next: <span className="text-white">{Math.round(hud.mission.distance)} m</span></span>
              {hud.mission.best !== null && <span>Best: <span className="text-amber-300">{formatTime(hud.mission.best)}</span></span>}
            </div>
          </div>
        )}
      </div>

      {/* message */}
      {hud?.message && (
        <div className="absolute left-1/2 top-[18%] -translate-x-1/2 border border-amber-400/40 bg-black/60 px-6 py-2 text-center text-sm font-bold uppercase tracking-[0.2em] text-amber-200 backdrop-blur-sm">
          {hud.message}
        </div>
      )}

      {/* bottom-right: speedo */}
      <div className="absolute bottom-4 right-4 flex items-end gap-4 md:bottom-6 md:right-6">
        <div className="text-right">
          <div className="flex items-baseline justify-end gap-2">
            <span className="font-mono text-5xl font-black italic leading-none text-white drop-shadow-[0_3px_0_rgba(0,0,0,0.6)] md:text-6xl">{speed}</span>
            <span className="text-xs font-bold uppercase tracking-widest text-white/60">km/h</span>
          </div>
          <div className="mt-2 flex items-center justify-end gap-2">
            <div className="flex h-2 w-40 gap-0.5 overflow-hidden">
              {Array.from({ length: 20 }).map((_, i) => (
                <div
                  key={i}
                  className={cn('h-full flex-1', i / 20 < rpm ? (i > 16 ? 'bg-red-500' : i > 12 ? 'bg-amber-400' : 'bg-emerald-400') : 'bg-white/10')}
                />
              ))}
            </div>
            <span className="w-6 text-center font-mono text-lg font-bold text-white">{hud ? (hud.gear === 0 ? 'R' : hud.gear) : '-'}</span>
          </div>
          <div className="mt-1 flex justify-end gap-3 text-[10px] font-bold uppercase tracking-widest text-white/50">
            <span className={cn(hud?.handbrake && 'text-red-400')}>{hud?.handbrake ? '⦿ Handbrake' : hud?.surface}</span>
            <span>{hud?.camera}</span>
          </div>
        </div>
      </div>

      {/* bottom-left: minimap */}
      <div className="absolute bottom-4 left-4 md:bottom-6 md:left-6">
        <canvas ref={minimapRef} width={176} height={176} className="h-[132px] w-[132px] rounded-full border-2 border-black/60 shadow-2xl md:h-[176px] md:w-[176px]" />
        <div className="mt-1 text-center text-[10px] font-bold uppercase tracking-[0.25em] text-white/60">{hud?.vehicleName}</div>
      </div>

      {showDebug && hud && (
        <div className="absolute right-4 top-4 font-mono text-[10px] text-white/50">
          {Math.round(hud.fps)} fps · {hud.drawCalls} draw calls
        </div>
      )}
    </div>
  );
}

export function PauseMenu({
  onResume, onRestart, onGarage, onMissions, onSettings, onQuit, hasMission, onFreeRoam,
}: {
  onResume: () => void; onRestart: () => void; onGarage: () => void; onMissions: () => void; onSettings: () => void; onQuit: () => void; hasMission: boolean; onFreeRoam: () => void;
}) {
  return (
    <div className="pointer-events-auto flex h-full w-full items-center justify-center bg-black/40 p-4">
      <Panel className="w-full max-w-sm" title="Paused" subtitle="Sunfall City Drive">
        <div className="flex flex-col gap-2">
          <MenuButton primary onClick={onResume} hint="Esc">Resume</MenuButton>
          {hasMission && <MenuButton onClick={onRestart}>Restart route</MenuButton>}
          {hasMission && <MenuButton onClick={onFreeRoam}>Abandon → Free roam</MenuButton>}
          <MenuButton onClick={onMissions}>Routes &amp; missions</MenuButton>
          <MenuButton onClick={onGarage}>Garage</MenuButton>
          <MenuButton onClick={onSettings}>Settings</MenuButton>
          <MenuButton onClick={onQuit}>Quit to main menu</MenuButton>
        </div>
        <div className="mt-4 flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-white/50">
          <span><Key>C</Key> camera</span><span><Key>R</Key> reset</span><span><Key>N</Key> lights</span><span><Key>T</Key> +1h</span><span><Key>Space</Key> handbrake</span>
        </div>
      </Panel>
    </div>
  );
}

export function Results({
  result, onRetry, onContinue, onMissions,
}: { result: { name: string; time: number; best: number | null; isNewBest: boolean; par: number }; onRetry: () => void; onContinue: () => void; onMissions: () => void }) {
  const underPar = result.time <= result.par;
  return (
    <div className="pointer-events-auto flex h-full w-full items-center justify-center bg-black/30 p-4">
      <Panel className="w-full max-w-md text-center" title="Route complete" subtitle={result.name}>
        <div className="my-4">
          <div className="font-mono text-6xl font-black italic text-white">{formatTime(result.time)}</div>
          <div className="mt-2 flex justify-center gap-4 text-xs uppercase tracking-widest">
            <span className={underPar ? 'text-emerald-400' : 'text-white/50'}>{underPar ? '★ Under par' : `Par ${formatTime(result.par)}`}</span>
            {result.isNewBest ? <span className="text-amber-300">New best time!</span> : result.best !== null && <span className="text-white/50">Best {formatTime(result.best)}</span>}
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <MenuButton primary onClick={onRetry}>Retry route</MenuButton>
          <MenuButton onClick={onMissions}>Other routes</MenuButton>
          <MenuButton onClick={onContinue}>Continue free roam</MenuButton>
        </div>
      </Panel>
    </div>
  );
}
