import type { ReactNode } from 'react';
import { cn } from '../utils/cn';

export function MenuButton({
  children, onClick, primary, className, disabled, hint,
}: { children: ReactNode; onClick?: () => void; primary?: boolean; className?: string; disabled?: boolean; hint?: string }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'group relative flex w-full items-center justify-between overflow-hidden border-l-4 px-5 py-3 text-left uppercase tracking-wider transition-all',
        'font-bold text-sm md:text-base',
        primary
          ? 'border-amber-400 bg-amber-400 text-black hover:bg-amber-300'
          : 'border-white/20 bg-black/40 text-white hover:border-amber-400 hover:bg-white/10 hover:pl-7',
        disabled && 'cursor-not-allowed opacity-40 hover:pl-5',
        className,
      )}
    >
      <span>{children}</span>
      {hint && <span className="text-[10px] font-semibold tracking-widest text-white/40 group-hover:text-amber-300">{hint}</span>}
    </button>
  );
}

export function Panel({ children, className, title, subtitle }: { children: ReactNode; className?: string; title?: string; subtitle?: string }) {
  return (
    <div className={cn('relative border border-white/10 bg-[#0c0f14]/85 p-5 shadow-2xl backdrop-blur-md', className)}>
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-400/70 to-transparent" />
      {title && (
        <div className="mb-4">
          <h2 className="text-2xl font-black uppercase italic tracking-tight text-white md:text-3xl">{title}</h2>
          {subtitle && <p className="mt-1 text-xs uppercase tracking-[0.25em] text-amber-300/80">{subtitle}</p>}
        </div>
      )}
      {children}
    </div>
  );
}

export function StatBar({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex items-center gap-3 text-xs uppercase tracking-wider">
      <span className="w-20 text-white/60">{label}</span>
      <div className="h-2 flex-1 bg-white/10">
        <div className="h-full bg-gradient-to-r from-amber-500 to-amber-300" style={{ width: `${value}%` }} />
      </div>
      <span className="w-8 text-right font-mono text-white/80">{value}</span>
    </div>
  );
}

export function Segmented<T extends string>({
  label, value, options, onChange,
}: { label: string; value: T; options: { value: T; label: string }[]; onChange: (v: T) => void }) {
  return (
    <div className="flex flex-col gap-1.5 sm:flex-row sm:items-center sm:justify-between">
      <span className="text-xs font-semibold uppercase tracking-widest text-white/60">{label}</span>
      <div className="flex flex-wrap gap-1">
        {options.map((o) => (
          <button
            key={o.value}
            onClick={() => onChange(o.value)}
            className={cn(
              'border px-3 py-1.5 text-xs font-bold uppercase tracking-wider transition-colors',
              o.value === value ? 'border-amber-400 bg-amber-400 text-black' : 'border-white/15 bg-black/30 text-white/80 hover:border-white/50',
            )}
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs font-semibold uppercase tracking-widest text-white/60">{label}</span>
      <button
        onClick={() => onChange(!value)}
        className={cn('relative h-6 w-12 border transition-colors', value ? 'border-amber-400 bg-amber-400/80' : 'border-white/20 bg-black/40')}
      >
        <span className={cn('absolute top-0.5 h-4.5 w-4.5 bg-white transition-all', value ? 'left-7' : 'left-0.5')} style={{ height: 18, width: 18 }} />
      </button>
    </div>
  );
}

export function Key({ children }: { children: ReactNode }) {
  return <kbd className="inline-block min-w-[1.6rem] border border-white/25 bg-white/10 px-1.5 py-0.5 text-center font-mono text-[10px] font-bold text-white">{children}</kbd>;
}

export function formatTime(t: number) {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  const ms = Math.floor((t % 1) * 100);
  return `${m}:${s.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
}
