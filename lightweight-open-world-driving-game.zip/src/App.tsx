import { useCallback, useEffect, useRef, useState } from 'react';
import { Engine } from './game/Engine';
import { loadSave, writeSave, type SaveData } from './game/store';
import type { HudState, Settings } from './game/types';
import { getVehicle } from './game/vehicles';
import { MISSIONS } from './game/missions';
import { Garage, MainMenu, Missions, SettingsPanel } from './components/Screens';
import { Hud, PauseMenu, Results } from './components/Hud';

type Screen = 'loading' | 'menu' | 'garage' | 'missions' | 'settings' | 'playing' | 'paused' | 'results';

interface ResultData { id: string; name: string; time: number; best: number | null; isNewBest: boolean; par: number }

const VERSION = 'v1.0 · web build';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const minimapRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const saveRef = useRef<SaveData>(loadSave());
  const [save, setSaveState] = useState<SaveData>(saveRef.current);
  const [screen, setScreen] = useState<Screen>('loading');
  const [returnTo, setReturnTo] = useState<Screen>('menu'); // where sub-screens go back to
  const [hud, setHud] = useState<HudState | null>(null);
  const [result, setResult] = useState<ResultData | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [showDebug, setShowDebug] = useState(false);
  const screenRef = useRef<Screen>('loading');
  screenRef.current = screen;

  const updateSave = useCallback((patch: Partial<SaveData>) => {
    saveRef.current = { ...saveRef.current, ...patch };
    writeSave(saveRef.current);
    setSaveState(saveRef.current);
  }, []);

  // ---- boot engine
  useEffect(() => {
    const canvas = canvasRef.current!;
    const engine = new Engine(canvas, saveRef.current.settings, {
      onHud: (h) => setHud(h),
      onMissionComplete: (r) => {
        setResult(r);
        setScreen('results');
      },
      getBest: (id) => saveRef.current.bestTimes[id] ?? null,
      saveBest: (id, t) => updateSave({ bestTimes: { ...saveRef.current.bestTimes, [id]: t } }),
    });
    engineRef.current = engine;
    engine
      .init(saveRef.current.vehicleId, saveRef.current.colorIndex)
      .then(() => {
        engine.minimap = minimapRef.current;
        engine.setMode('attract');
        setScreen('menu');
      })
      .catch((e) => {
        console.error(e);
        setLoadError(String(e?.message || e));
      });
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, [updateSave]);

  // keep minimap ref synced (HUD mounts/unmounts)
  useEffect(() => {
    if (engineRef.current) engineRef.current.minimap = minimapRef.current;
  });

  // ---- global keys (Esc, F3)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'F3') {
        e.preventDefault();
        setShowDebug((v) => !v);
      }
      if (e.code !== 'Escape') return;
      const s = screenRef.current;
      const eng = engineRef.current;
      if (!eng) return;
      if (s === 'playing') {
        eng.setPaused(true);
        setScreen('paused');
      } else if (s === 'paused') {
        eng.setPaused(false);
        setScreen('playing');
      } else if (s === 'garage' || s === 'missions' || s === 'settings') {
        setScreen(returnTo);
        if (returnTo === 'playing') eng.setPaused(false);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [returnTo]);

  // ---- helpers
  const startPlaying = () => {
    const eng = engineRef.current!;
    eng.setMode('play');
    eng.setPaused(false);
    setScreen('playing');
  };
  const goFreeRoam = () => {
    engineRef.current!.startFreeRoam();
    startPlaying();
  };
  const startMission = (id: string) => {
    engineRef.current!.startMission(id);
    setResult(null);
    startPlaying();
  };
  const openSub = (s: Screen, from: Screen) => {
    setReturnTo(from);
    setScreen(s);
  };
  const back = () => {
    setScreen(returnTo);
    if (returnTo === 'paused') engineRef.current?.setPaused(true);
  };
  const applySettings = (s: Settings) => {
    updateSave({ settings: s });
    engineRef.current?.applySettings(s);
  };
  const quitToMenu = () => {
    const eng = engineRef.current!;
    eng.abortMission();
    eng.setPaused(false);
    eng.setMode('attract');
    setScreen('menu');
  };

  const inGame = returnTo === 'paused' || returnTo === 'playing';
  const showMenuBackdrop = screen !== 'playing' && screen !== 'loading';
  const vehicleName = getVehicle(save.vehicleId).name;

  return (
    <div className="relative h-full w-full text-white">
      <canvas ref={canvasRef} className="game-canvas" tabIndex={0} />

      {/* HUD */}
      {(screen === 'playing' || screen === 'paused' || screen === 'results') && <Hud hud={hud} minimapRef={minimapRef} showDebug={showDebug} />}

      {/* overlays */}
      {showMenuBackdrop && (
        <div className={`absolute inset-0 ${screen === 'menu' || screen === 'garage' || screen === 'missions' || screen === 'settings' ? (inGame ? 'bg-black/50' : 'menu-vignette scanlines') : ''}`}>
          <div className="fadein h-full w-full" key={screen}>
            {screen === 'menu' && (
              <MainMenu
                onFreeRoam={goFreeRoam}
                onMissions={() => openSub('missions', 'menu')}
                onGarage={() => openSub('garage', 'menu')}
                onSettings={() => openSub('settings', 'menu')}
                vehicleName={vehicleName}
                version={VERSION}
              />
            )}
            {screen === 'garage' && (
              <Garage
                vehicleId={save.vehicleId}
                colorIndex={save.colorIndex}
                inGame={inGame}
                onSelect={(id) => updateSave({ vehicleId: id, colorIndex: 0 })}
                onColor={(i) => updateSave({ colorIndex: i })}
                onBack={back}
                onDrive={() => {
                  engineRef.current?.setVehicle(saveRef.current.vehicleId, saveRef.current.colorIndex);
                  if (inGame) {
                    engineRef.current?.setPaused(false);
                    setScreen('playing');
                  } else goFreeRoam();
                }}
              />
            )}
            {screen === 'missions' && <Missions bestTimes={save.bestTimes} onStart={startMission} onBack={back} />}
            {screen === 'settings' && (
              <SettingsPanel
                settings={save.settings}
                onChange={applySettings}
                onBack={back}
                note="Anti-aliasing changes take effect after a page reload. Everything else applies instantly."
              />
            )}
            {screen === 'paused' && (
              <PauseMenu
                hasMission={!!hud?.mission}
                onResume={() => {
                  engineRef.current?.setPaused(false);
                  setScreen('playing');
                }}
                onRestart={() => hud?.mission && startMission(hud.mission.id)}
                onFreeRoam={goFreeRoam}
                onGarage={() => openSub('garage', 'paused')}
                onMissions={() => openSub('missions', 'paused')}
                onSettings={() => openSub('settings', 'paused')}
                onQuit={quitToMenu}
              />
            )}
            {screen === 'results' && result && (
              <Results
                result={result}
                onRetry={() => startMission(result.id)}
                onMissions={() => openSub('missions', 'playing')}
                onContinue={() => {
                  engineRef.current?.abortMission();
                  setScreen('playing');
                }}
              />
            )}
          </div>
        </div>
      )}

      {/* loading */}
      {screen === 'loading' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#07090c]">
          <div className="text-[10px] font-bold uppercase tracking-[0.4em] text-amber-300">Sunfall City Drive</div>
          <div className="mt-2 text-3xl font-black uppercase italic tracking-tight">{loadError ? 'Could not start' : 'Building the city…'}</div>
          {loadError ? (
            <p className="mt-3 max-w-md text-center text-sm text-red-300">{loadError}. Your browser needs WebGL 2 for this game.</p>
          ) : (
            <>
              <div className="mt-6 h-1 w-64 overflow-hidden bg-white/10">
                <div className="loader-bar h-full w-1/3 bg-amber-400" />
              </div>
              <p className="mt-3 text-xs text-white/40">Generating textures, roads and {MISSIONS.length} routes locally – nothing is downloaded.</p>
            </>
          )}
        </div>
      )}
    </div>
  );
}
