/**
 * Behavioural tests: the real `runTurn` + the offline model + the in-memory
 * store. They assert that evidence has CONSEQUENCES and that consequences are
 * REVISABLE — the brief's core requirement — through the same code path the
 * product uses (only the store and model are swapped).
 */
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { runTurn, type TurnInput } from "../src/lib/agent/turn";
import { deriveState, DAY } from "../src/lib/core/model";
import type { Condition, TurnTrace } from "../src/lib/core/types";
import { getLLM } from "../src/lib/llm";
import { MemoryStore } from "../src/lib/store/memory";

const T0 = Date.UTC(2026, 0, 5, 9);

function harness(condition: Condition = "layer") {
  const store = new MemoryStore();
  const llm = getLLM("mock");
  let clock = 0;
  const learnerId = `t-${Math.random().toString(36).slice(2)}`;
  async function say(sessionId: string, day: number, text: string, hints?: TurnInput["mockHints"]) {
    let reply = "";
    let trace: TurnTrace | null = null;
    for await (const ev of runTurn({ store, llm, learnerId, sessionId, userMessage: text, condition, now: new Date(T0 + day * DAY + clock++ * 60_000), mockHints: hints })) {
      if (ev.type === "text") reply += ev.text;
      if (ev.type === "trace") trace = ev.trace;
    }
    return { reply, trace: trace!, action: trace!.mockAction ?? "" };
  }
  const state = async (day: number) => deriveState(await store.listEvidence(learnerId), new Date(T0 + day * DAY + clock * 60_000));
  return { store, learnerId, say, state };
}

describe("evidence → behavioural consequence → revision", () => {
  it("claim → light verification (not trust, not re-teach); success → treated as known next session", async () => {
    const h = harness();
    await h.say("s1", 0, "I already know recursion.");
    const r1 = await h.say("s1", 0, "Teach me recursion.", { skill: "recursion" });
    assert.match(r1.action, /^verify_claim/);
    await h.say("s1", 0, "My answer: a base case stops it.", { skill: "recursion", answerCorrect: true });
    const st = await h.state(0);
    assert.equal(st.skills[0].verifiedClaim, true);
    const r2 = await h.say("s2", 3, "Teach me recursion.", { skill: "recursion" });
    assert.match(r2.action, /^check/);
  });

  it("explained ≠ known: after an explanation the next session checks rather than re-teaches; a fail then re-teaches differently", async () => {
    const h = harness();
    const r1 = await h.say("s1", 0, "Teach me closures.", { skill: "closures" });
    assert.match(r1.action, /^explain:conceptual_explanation/);
    await h.say("s1", 0, "Okay, that made sense.");
    const r2 = await h.say("s2", 0.2, "Teach me closures.", { skill: "closures" });
    assert.match(r2.action, /^check/, "same-day follow-up on an explained topic should be a check");
    await h.say("s2", 0.2, "My answer: not sure.", { skill: "closures", answerCorrect: false });
    const st = await h.state(0.2);
    assert.equal(st.skills[0].status, "struggling");
    const r3 = await h.say("s2", 0.2, "Teach me closures.", { skill: "closures" });
    assert.match(r3.action, /^explain:worked_example/, "a failed attempt after a conceptual explanation should switch approach");
  });

  it("forgetting has consequences: a long gap turns a demonstrated skill into a brief re-teach, not a bare quiz", async () => {
    const h = harness();
    await h.say("s1", 0, "Teach me SQL joins.", { skill: "sql-joins" });
    await h.say("s1", 0, "Okay, that made sense.");
    await h.say("s2", 1, "Teach me SQL joins.", { skill: "sql-joins" });
    await h.say("s2", 1, "My answer: inner keeps matches, left keeps all left rows.", { skill: "sql-joins", answerCorrect: true });
    const soon = await h.say("s3", 2, "Teach me SQL joins.", { skill: "sql-joins" });
    assert.match(soon.action, /^check/);
    const late = await h.say("s4", 60, "Teach me SQL joins.", { skill: "sql-joins" });
    assert.match(late.action, /^explain/);
    assert.match(late.trace.brief, /probably forgotten/);
  });

  it("stated preference is respected, a correction retires it immediately, and a weak signal cannot bring it back", async () => {
    const h = harness();
    await h.say("s1", 0, "Don't give me the answer, give me hints so I can work it out.");
    const q1 = await h.say("s1", 0, "How do I reverse a linked list?");
    assert.match(q1.action, /socratic_question/);
    await h.say("s2", 2, "Actually, stop with the hints, just give me the answer directly from now on.");
    const q2 = await h.say("s2", 2, "How do I reverse a linked list?");
    assert.match(q2.action, /direct_answer/);
    const st = await h.state(2);
    assert.ok(st.doNotAssume.length >= 1);
    await h.say("s3", 5, "Hmm, let me think about that one myself for a second.");
    const q3 = await h.say("s3", 5, "How do I pick between a map and a set here?");
    assert.match(q3.action, /direct_answer/, "reaction-level evidence must not re-create a corrected belief inside the guard window");
  });

  it("observed behaviour adapts the approach without the person ever stating a preference (needs two sessions)", async () => {
    const h = harness();
    await h.say("s1", 0, "Teach me recursion.", { skill: "recursion" });
    await h.say("s1", 0, "I'm a bit lost. Examples really help me more than definitions.");
    const same = await h.say("s1", 0, "Teach me closures.", { skill: "closures" });
    assert.match(same.action, /conceptual_explanation/, "one observation in one session is only a candidate");
    await h.say("s1", 0, "I'm a bit lost. Examples really help me more than definitions.");
    await h.say("s2", 2, "Teach me big O notation.", { skill: "big-o-notation" });
    await h.say("s2", 2, "I'm a bit lost. Examples really help me more than definitions.");
    const later = await h.say("s2", 2, "Teach me SQL joins.", { skill: "sql-joins" });
    assert.match(later.action, /worked_example/);
    const st = await h.state(2);
    assert.equal(st.beliefs.find((b) => b.dimension === "examples")!.status, "active");
  });

  it("approach outcomes are attributed on the NEXT turn and shown as statistics", async () => {
    const h = harness();
    await h.say("s1", 0, "Teach me closures.", { skill: "closures" });
    let st = await h.state(0);
    assert.equal(st.approaches[0].worked + st.approaches[0].didNotWork, 0, "no outcome until the next turn");
    await h.say("s1", 0, "Okay, that made sense.");
    st = await h.state(0);
    assert.equal(st.approaches.find((a) => a.approach === "conceptual_explanation")!.worked, 1);
    assert.equal(st.beliefs.length, 0, "outcomes never become beliefs");
  });

  it("remember / forget tools: the person controls the record", async () => {
    const h = harness();
    const r = await h.say("s1", 0, "Remember that I am preparing for a backend interview.");
    assert.ok(r.trace.toolCalls.some((t) => t.name === "remember"));
    let st = await h.state(0);
    assert.ok(st.facts.some((f) => /backend interview/.test(f.value)));
    const f = await h.say("s1", 0, "Forget about the backend interview.");
    assert.ok(f.trace.toolCalls.some((t) => t.name === "forget"));
    st = await h.state(0);
    assert.ok(!st.facts.some((x) => /backend interview/.test(x.value)));
  });

  it("baselines run through the same path and differ only in context", async () => {
    for (const c of ["none", "transcript", "flat_memory", "layer"] as Condition[]) {
      const h = harness(c);
      await h.say("s1", 0, "I already know recursion.");
      const r = await h.say("s2", 1, "Teach me recursion.", { skill: "recursion" });
      assert.equal(r.trace.condition, c);
      if (c === "none") assert.match(r.action, /^explain/);
      if (c === "layer") assert.match(r.action, /^verify_claim/);
      if (c === "flat_memory") assert.match(r.action, /^check/); // trusts the claim outright
      if (c === "transcript") assert.match(r.action, /^check/);
    }
  });

  it("the brief stays small as evidence grows", async () => {
    const h = harness();
    for (let s = 0; s < 8; s++) {
      for (const skill of ["recursion", "closures", "sql-joins", "big-o-notation"]) {
        const r = await h.say(`s${s}`, s * 3, `Teach me ${skill.replace(/-/g, " ")}.`, { skill });
        if (/check|verify/.test(r.action)) await h.say(`s${s}`, s * 3, "My answer: …", { skill, answerCorrect: true });
        else await h.say(`s${s}`, s * 3, "Okay, that made sense.");
      }
    }
    const r = await h.say("s9", 30, "Teach me recursion.", { skill: "recursion" });
    assert.ok(r.trace.briefTokens < 500, `brief grew to ${r.trace.briefTokens} tokens`);
    assert.ok((await h.store.listEvidence(h.learnerId)).length > 60);
  });
});
