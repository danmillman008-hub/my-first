import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { approxTokens, compileBrief, compileFlatMemory } from "../src/lib/core/brief";
import { CORRECTION_GUARD_DAYS, DAY, deriveState, slugify } from "../src/lib/core/model";
import { reflectionToEvidence, validateReflection } from "../src/lib/core/reflect";
import type { EvidenceItem, Payload } from "../src/lib/core/types";

const T0 = new Date("2026-01-05T09:00:00Z");
let id = 1;
const ev = (payload: Payload, subject: string, dayOffset = 0, sessionId = "s1"): EvidenceItem => ({
  id: id++,
  learnerId: "l",
  sessionId,
  messageId: null,
  kind: payload.kind,
  subject,
  payload,
  source: "lab",
  createdAt: new Date(T0.getTime() + dayOffset * DAY + id * 1000),
  retractedAt: null,
});
const at = (days: number) => new Date(T0.getTime() + days * DAY + 60_000 * 10);

describe("skill semantics", () => {
  it("claimed ≠ demonstrated: a bare claim stays 'claimed' and unverified", () => {
    const s = deriveState([ev({ kind: "skill", event: "claimed" }, "recursion")], at(0)).skills[0];
    assert.equal(s.status, "claimed");
    assert.equal(s.verifiedClaim, false);
    assert.ok(s.recall < 0.7);
  });
  it("a claim verified by an unaided demonstration becomes stable prior knowledge", () => {
    const s = deriveState([ev({ kind: "skill", event: "claimed" }, "recursion"), ev({ kind: "skill", event: "demonstrated", aided: false }, "recursion")], at(0)).skills[0];
    assert.equal(s.verifiedClaim, true);
    assert.ok(s.halfLifeDays >= 14);
    assert.ok(s.recall >= 0.85);
  });
  it("explained ≠ known: explanation alone never yields 'demonstrated'", () => {
    const s = deriveState([ev({ kind: "skill", event: "explained" }, "closures")], at(0)).skills[0];
    assert.equal(s.status, "explained");
    assert.equal(s.demonstratedUnaided, 0);
  });
  it("recall decays with time and the status becomes 'fading'", () => {
    const items = [ev({ kind: "skill", event: "explained" }, "closures"), ev({ kind: "skill", event: "demonstrated", aided: false }, "closures")];
    const fresh = deriveState(items, at(0)).skills[0];
    const later = deriveState(items, at(20)).skills[0];
    assert.ok(later.recall < fresh.recall);
    assert.equal(later.status, "fading");
  });
  it("spaced retrieval strengthens far more than massed retrieval", () => {
    const massed = deriveState([ev({ kind: "skill", event: "explained" }, "x"), ev({ kind: "skill", event: "demonstrated", aided: false }, "x", 0.01)], at(0.02)).skills[0];
    const spaced = deriveState([ev({ kind: "skill", event: "explained" }, "x"), ev({ kind: "skill", event: "demonstrated", aided: false }, "x", 2)], at(2.01)).skills[0];
    assert.ok(spaced.halfLifeDays > massed.halfLifeDays * 1.5);
  });
  it("one slip after repeated unaided success lowers the estimate but does not mark 'struggling'", () => {
    const items = [
      ev({ kind: "skill", event: "demonstrated", aided: false }, "x", 0),
      ev({ kind: "skill", event: "demonstrated", aided: false }, "x", 2),
      ev({ kind: "skill", event: "demonstrated", aided: false }, "x", 6),
      ev({ kind: "skill", event: "failed" }, "x", 9),
    ];
    const s = deriveState(items, at(9)).skills[0];
    assert.notEqual(s.status, "struggling");
    assert.ok(s.recall < 0.7 && s.recall > 0.3);
  });
  it("two consecutive failures do mark 'struggling' and keep the misconception", () => {
    const items = [ev({ kind: "skill", event: "explained" }, "x"), ev({ kind: "skill", event: "failed", misconception: "thinks == compares refs" }, "x", 1), ev({ kind: "skill", event: "failed" }, "x", 2)];
    const s = deriveState(items, at(2)).skills[0];
    assert.equal(s.status, "struggling");
    assert.deepEqual(s.misconceptions, ["thinks == compares refs"]);
  });
  it("a correction on a skill wipes earlier skill evidence", () => {
    const items = [ev({ kind: "skill", event: "demonstrated", aided: false }, "x"), ev({ kind: "correction", target: "skill:x" }, "skill:x", 1)];
    assert.equal(deriveState(items, at(1)).skills.length, 0);
  });
});

describe("belief lifecycle", () => {
  it("a stated preference acts immediately; an inferred one needs two sessions", () => {
    const stated = deriveState([ev({ kind: "style", dimension: "directness", value: -1, basis: "stated" }, "directness")], at(0)).beliefs[0];
    assert.equal(stated.status, "active");
    const inferred1 = deriveState([ev({ kind: "style", dimension: "examples", value: 1, basis: "demonstrated" }, "examples"), ev({ kind: "style", dimension: "examples", value: 1, basis: "demonstrated" }, "examples")], at(0)).beliefs[0];
    assert.equal(inferred1.status, "candidate");
    const inferred2 = deriveState([ev({ kind: "style", dimension: "examples", value: 1, basis: "demonstrated" }, "examples"), ev({ kind: "style", dimension: "examples", value: 1, basis: "demonstrated" }, "examples", 2, "s2")], at(2)).beliefs[0];
    assert.equal(inferred2.status, "active");
  });
  it("confidence is capped and grows with evidence", () => {
    const one = deriveState([ev({ kind: "style", dimension: "depth", value: 1, basis: "stated" }, "depth")], at(0)).beliefs[0];
    const many = deriveState(Array.from({ length: 8 }, (_, i) => ev({ kind: "style", dimension: "depth", value: 1, basis: "demonstrated" }, "depth", i, `s${i}`)), at(8)).beliefs[0];
    assert.ok(many.confidence > one.confidence);
    assert.ok(many.confidence <= 0.92);
  });
  it("what they say vs what works: disagreement becomes a contested belief with a tension", () => {
    const items = [
      ev({ kind: "style", dimension: "depth", value: 1, basis: "stated" }, "depth"),
      ev({ kind: "style", dimension: "depth", value: -1, basis: "demonstrated" }, "depth", 1, "s2"),
      ev({ kind: "style", dimension: "depth", value: -1, basis: "demonstrated" }, "depth", 2, "s3"),
    ];
    const b = deriveState(items, at(2)).beliefs[0];
    assert.equal(b.status, "contested");
    assert.match(b.tension ?? "", /says .* but responds better to/);
  });
  it("a correction retires the belief, guards re-inference from weak signals for 14 days, but lets a new stated preference through", () => {
    const base = [ev({ kind: "style", dimension: "directness", value: -1, basis: "stated" }, "directness"), ev({ kind: "correction", target: "style:directness" }, "style:directness", 2)];
    const retired = deriveState(base, at(2)).beliefs.find((b) => b.dimension === "directness")!;
    assert.equal(retired.status, "retired");
    assert.ok(deriveState(base, at(2)).doNotAssume.length === 1);
    const weak = [...base, ev({ kind: "style", dimension: "directness", value: -1, basis: "reaction" }, "directness", 3)];
    assert.equal(deriveState(weak, at(3)).beliefs.find((b) => b.dimension === "directness")!.status, "retired");
    const stated = [...base, ev({ kind: "style", dimension: "directness", value: 1, basis: "stated" }, "directness", 3)];
    const b = deriveState(stated, at(3)).beliefs.find((b) => b.dimension === "directness")!;
    assert.equal(b.status, "active");
    assert.ok(b.value > 0);
    // after the guard window, weak evidence counts again
    const afterGuard = deriveState(weak, at(CORRECTION_GUARD_DAYS + 3)).beliefs.find((b) => b.dimension === "directness")!;
    assert.notEqual(afterGuard.status, "retired");
  });
  it("beliefs are derived: deleting evidence re-derives honestly", () => {
    const items = [ev({ kind: "style", dimension: "pace", value: 1, basis: "stated" }, "pace")];
    assert.equal(deriveState(items, at(0)).beliefs.length, 1);
    items[0].retractedAt = at(0);
    assert.equal(deriveState(items, at(0)).beliefs.length, 0);
  });
});

describe("facts and approaches", () => {
  it("latest fact wins; corrections drop earlier facts", () => {
    const items = [ev({ kind: "fact", key: "occupation", value: "nurse" }, "occupation"), ev({ kind: "fact", key: "occupation", value: "nurse practitioner" }, "occupation", 1)];
    assert.equal(deriveState(items, at(1)).facts[0].value, "nurse practitioner");
    items.push(ev({ kind: "correction", target: "fact:occupation" }, "fact:occupation", 2));
    assert.equal(deriveState(items, at(2)).facts.length, 0);
  });
  it("approach outcomes are statistics, never beliefs; the open one is pending", () => {
    const items = [ev({ kind: "approach", approach: "worked_example", outcome: "worked" }, "worked_example"), ev({ kind: "approach", approach: "socratic_question", outcome: null }, "socratic_question", 0.1)];
    const st = deriveState(items, at(1));
    assert.equal(st.approaches.find((a) => a.approach === "worked_example")!.worked, 1);
    assert.equal(st.pendingApproachId, items[1].id);
    assert.equal(st.beliefs.length, 0);
  });
});

describe("brief compiler", () => {
  it("is compact and epistemically labelled", () => {
    const items = [
      ev({ kind: "skill", event: "claimed" }, "sql-joins"),
      ev({ kind: "skill", event: "explained" }, "closures"),
      ev({ kind: "skill", event: "demonstrated", aided: false }, "closures", 1, "s2"),
      ev({ kind: "style", dimension: "examples", value: 1, basis: "demonstrated" }, "examples"),
      ev({ kind: "fact", key: "occupation", value: "nurse" }, "occupation"),
      ev({ kind: "correction", target: "style:directness", note: "wants direct answers" }, "style:directness", 1),
    ];
    const brief = compileBrief(deriveState(items, at(1)));
    assert.match(brief, /CLAIMS to know it — unverified/);
    assert.match(brief, /shown unaided 1×/);
    assert.match(brief, /Do NOT assume/);
    assert.match(brief, /occupation: nurse/);
    assert.ok(approxTokens(brief) < 450, `brief too long: ${approxTokens(brief)} tokens`);
  });
  it("tells the model to let them try after two explanations without a demonstration", () => {
    const items = [ev({ kind: "skill", event: "explained" }, "x"), ev({ kind: "skill", event: "explained" }, "x", 2, "s2")];
    assert.match(compileBrief(deriveState(items, at(3))), /have them attempt it before explaining a third time/);
  });
  it("first meeting brief says so", () => {
    assert.match(compileBrief(deriveState([], at(0))), /first meeting/);
  });
  it("flat memory baseline has no lifecycle: a claim reads as 'Knows'", () => {
    assert.match(compileFlatMemory([ev({ kind: "skill", event: "claimed" }, "x")]), /Knows x/);
  });
});

describe("reflection validation", () => {
  it("clamps, slugs, dedups and drops garbage", () => {
    const r = validateReflection({
      skills: [{ name: "SQL Joins", event: "demonstrated", aided: "yes" }, { name: "SQL joins", event: "demonstrated" }, { name: "x", event: "bogus" }, { name: "", event: "claimed" }],
      style: [{ dimension: "depth", value: 7, basis: "stated" }, { dimension: "nope", value: 1, basis: "stated" }],
      facts: [{ key: "Occupation", value: "  nurse " }, { key: 1 }],
      corrections: [{ target: "style:directness" }, { target: "style:banana" }, { target: "skill:Recursion" }, { target: "nonsense" }],
      reaction: "2",
      previous_approach_outcome: "worked",
      approach_used: "worked_example",
    });
    assert.deepEqual(r.skills, [{ name: "sql-joins", event: "demonstrated", aided: true, misconception: undefined }]);
    assert.equal(r.style.length, 1);
    assert.equal(r.style[0].value, 1);
    assert.deepEqual(r.facts, [{ key: "occupation", value: "nurse" }]);
    assert.deepEqual(
      r.corrections.map((c) => c.target),
      ["style:directness", "skill:recursion"],
    );
    assert.equal(r.reaction, 1);
    assert.equal(r.approachUsed, "worked_example");
    const rows = reflectionToEvidence(r, { learnerId: "l", sessionId: "s", messageId: 1, source: "reflection" });
    assert.ok(rows.some((x) => x.kind === "approach" && x.payload.kind === "approach" && x.payload.outcome === null));
  });
  it("survives non-objects", () => {
    assert.equal(validateReflection(null).skills.length, 0);
    assert.equal(validateReflection("x").approachUsed, null);
  });
  it("slugify is stable", () => {
    assert.equal(slugify("  Big O Notation! "), "big-o-notation");
    assert.equal(slugify("C++ templates"), "c++-templates");
  });
});
