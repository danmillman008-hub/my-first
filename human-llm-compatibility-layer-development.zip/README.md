# Compatibility Layer — an assistant that learns how *you* learn

A chat assistant (Gemini Flash behind a plain chat window) with an **evidence-driven human–LLM compatibility layer** behind it. You talk naturally; the layer keeps an honest, inspectable record of what you have shown, said and corrected, compiles it into a ~300-token brief the model can reason over, and lets the model teach freely with increasingly good evidence about you.

```
you ──► chat ──► [ evidence log → derived state → brief ] ──► Gemini ──► reply
                              ▲                                   │
                              └──── reflection (what did this exchange show?) ◄──┘
```

- **Model decides, layer informs.** No teaching policy, no curriculum, no quizzes forced on you.
- **Everything about you is derived** from an append-only evidence log; nothing is a permanent truth. Mark anything "not true" and it is retired and not re-inferred for 14 days.
- **Epistemics survive to the prompt**: the model is told *how* it knows each thing (you said it / you showed it / it was explained / you corrected it).
- **Two-sided**: the AI also keeps a record of which of *its* approaches actually worked with you.
- **Measured, not asserted**: four context conditions run through the identical code path; see `docs/EVALUATION.md`.

## Quick start

```bash
npm install
# .env: DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
#       GEMINI_API_KEY=…            # optional; without it a clearly-labelled offline mock runs
#       GEMINI_MODEL=gemini-3.6-flash   # optional; resolved against /models with fallbacks
npx drizzle-kit push
npm run dev
```

Open http://localhost:3000. Try: *"Teach me recursion"*, then tomorrow *"Teach me recursion"* again; *"I already know SQL joins"*; *"Just give me the answer"*; *"Actually stop giving me hints"*; *"What did we talk about last time?"*. Click **What it knows about you** to see beliefs, skills, facts, the exact brief, raw evidence — and to correct or erase any of it. Each reply has a **why this turn** trace.

## Commands

| command | what |
| --- | --- |
| `npm run dev` / `npm run build` / `npm start` | Next.js app |
| `npm test` | 31 unit + behavioural tests (in-memory store, offline model) |
| `npm run lab` | longitudinal laboratory, 4 conditions × 6 learners × 6 sessions → `lab/out/summary.md` |
| `npm run lab:live` | same lab with Gemini as tutor, answer-verbaliser and judge (needs `GEMINI_API_KEY`) |
| `npx drizzle-kit push` | apply schema |

## Configuration

| variable | default | notes |
| --- | --- | --- |
| `DATABASE_URL` | — | Postgres |
| `GEMINI_API_KEY` (or `GOOGLE_API_KEY`) | — | absent ⇒ offline mock, banner shown in UI |
| `GEMINI_MODEL` | `gemini-3.6-flash` | if the id does not exist the client falls back through known flash ids |
| `GEMINI_BASE_URL` | `https://generativelanguage.googleapis.com/v1beta` | |

## API

| route | |
| --- | --- |
| `POST /api/chat` `{message, sessionId?, condition?}` | SSE: `session`, `text`, `tool`, `trace`, `error`, `done` |
| `GET /api/sessions`, `GET /api/sessions/:id` | conversations |
| `GET /api/memory` | derived state + exact brief + raw evidence |
| `POST /api/memory` `{target:"style:depth"\|"skill:x"\|"fact:k", note?}` | correction (retire + 14-day guard) |
| `DELETE /api/memory/:id` | retract one evidence item |
| `DELETE /api/memory` | erase the whole relationship |
| `GET /api/status`, `GET /api/health` | |

Identity is one httpOnly cookie = one relationship. `condition` (`layer` default; `none`, `transcript`, `flat_memory`) exists for research and is exposed in the sidebar.

## Layout

```
src/lib/core/      types · model.ts (evidence → state, pure) · brief.ts · reflect.ts
src/lib/agent/     prompt.ts · tools.ts · turn.ts (the turn; all conditions are modes of it)
src/lib/llm/       gemini.ts (REST, streaming, tools, JSON) · mock.ts (offline) · index.ts
src/lib/store/     Store interface · pg.ts · memory.ts
src/app/api/       chat · sessions · memory · status · health
src/components/    Chat.tsx · MemoryPanel.tsx
scripts/lab/       run.ts · sim.ts        tests/  core.test.ts · behaviour.test.ts
docs/              RESEARCH · FORENSICS · ARCHITECTURE · CAPABILITY_MAP · MEMORY_AND_LEARNER_MODEL · EVALUATION · DECISIONS
```

## Documents

- [Research report](docs/RESEARCH.md) — what was investigated, run, learned; why this direction
- [Forensics of previous attempts](docs/FORENSICS.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Capability map](docs/CAPABILITY_MAP.md) — what the model does vs what the app provides
- [Memory & learner model specification](docs/MEMORY_AND_LEARNER_MODEL.md)
- [Evaluation](docs/EVALUATION.md) and the latest run in [`lab/out/summary.md`](lab/out/summary.md)
- [Decision log](docs/DECISIONS.md)

## Honest limits

No Gemini key was available while building, so all reported numbers measure the **layer** with a scripted reader of its own brief, never Gemini's prose. The live path is implemented against the current Gemini REST API (streaming, function calling with thought-signature passthrough, structured output) and is the first thing to run when a key is present: `GEMINI_API_KEY=… npm run lab:live`.

## Operations

Stateless Next.js server; all state in Postgres (4 tables). Reflection failures are logged and never break a conversation. Evidence is append-only; deleting a learner cascades manually in `PgStore.deleteLearner`. No secrets are ever sent to the browser; the model key is read server-side only.
