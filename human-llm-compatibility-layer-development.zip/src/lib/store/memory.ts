import type { EvidenceItem, NewEvidence, Payload, TurnTrace } from "@/lib/core/types";
import type { MessageRow, SessionRow, Store } from "./types";

// ------------------------------------------------------------ in-memory ---

export class MemoryStore implements Store {
  private learners = new Set<string>();
  private sessions = new Map<string, SessionRow>();
  private messages: MessageRow[] = [];
  private evidence: EvidenceItem[] = [];
  private nextMsg = 1;
  private nextEv = 1;

  async ensureLearner(id: string) {
    this.learners.add(id);
  }
  async deleteLearner(id: string) {
    this.learners.delete(id);
    for (const [k, s] of this.sessions) if (s.learnerId === id) this.sessions.delete(k);
    this.messages = this.messages.filter((m) => m.learnerId !== id);
    this.evidence = this.evidence.filter((e) => e.learnerId !== id);
  }
  async listSessions(learnerId: string) {
    return [...this.sessions.values()].filter((s) => s.learnerId === learnerId).sort((a, b) => b.lastActiveAt.getTime() - a.lastActiveAt.getTime());
  }
  async getSession(id: string) {
    return this.sessions.get(id) ?? null;
  }
  async createSession(learnerId: string, id: string, at = new Date()) {
    const s: SessionRow = { id, learnerId, title: "New conversation", summary: null, startedAt: at, lastActiveAt: at };
    this.sessions.set(id, s);
    return s;
  }
  async updateSession(id: string, patch: Partial<Pick<SessionRow, "title" | "summary" | "lastActiveAt">>) {
    const s = this.sessions.get(id);
    if (s) Object.assign(s, patch);
  }
  async listMessages(sessionId: string) {
    return this.messages.filter((m) => m.sessionId === sessionId);
  }
  async listAllMessages(learnerId: string) {
    return this.messages.filter((m) => m.learnerId === learnerId);
  }
  async addMessage(m: Omit<MessageRow, "id" | "createdAt"> & { createdAt?: Date }) {
    const row: MessageRow = { ...m, id: this.nextMsg++, createdAt: m.createdAt ?? new Date() };
    this.messages.push(row);
    return row;
  }
  async updateMessageTrace(id: number, trace: TurnTrace) {
    const m = this.messages.find((x) => x.id === id);
    if (m) m.trace = trace;
  }
  async listEvidence(learnerId: string, includeRetracted = false) {
    return this.evidence.filter((e) => e.learnerId === learnerId && (includeRetracted || !e.retractedAt)).map((e) => ({ ...e, payload: { ...e.payload } as Payload }));
  }
  async addEvidence(items: NewEvidence[]) {
    const rows = items.map((i) => ({ ...i, id: this.nextEv++, createdAt: i.createdAt ?? new Date(), retractedAt: null }) as EvidenceItem);
    this.evidence.push(...rows);
    return rows;
  }
  async retractEvidence(learnerId: string, id: number, at = new Date()) {
    const e = this.evidence.find((x) => x.id === id && x.learnerId === learnerId);
    if (!e) return false;
    e.retractedAt = at;
    return true;
  }
  async setApproachOutcome(id: number, outcome: "worked" | "did_not_work" | "unclear") {
    const e = this.evidence.find((x) => x.id === id);
    if (e && e.payload.kind === "approach") e.payload.outcome = outcome;
  }
  async searchMessages(learnerId: string, query: string, limit = 6) {
    const terms = query.toLowerCase().split(/\s+/).filter((t) => t.length > 2);
    return this.messages
      .filter((m) => m.learnerId === learnerId)
      .map((m) => ({ m, score: terms.filter((t) => m.content.toLowerCase().includes(t)).length }))
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score || b.m.createdAt.getTime() - a.m.createdAt.getTime())
      .slice(0, limit)
      .map((x) => x.m);
  }
}

