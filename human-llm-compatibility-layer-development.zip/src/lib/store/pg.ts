import { and, asc, desc, eq, ilike, isNull, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { evidence, learners, messages, sessions } from "@/db/schema";
import type { EvidenceItem, NewEvidence, Payload, TurnTrace } from "@/lib/core/types";
import type { MessageRow, SessionRow, Store } from "./types";

// ------------------------------------------------------------- postgres ---

const toMsg = (r: typeof messages.$inferSelect): MessageRow => ({
  id: r.id,
  sessionId: r.sessionId,
  learnerId: r.learnerId,
  role: r.role as "user" | "assistant",
  content: r.content,
  trace: (r.trace as TurnTrace | null) ?? null,
  createdAt: r.createdAt,
});

const toEv = (r: typeof evidence.$inferSelect): EvidenceItem => ({
  id: r.id,
  learnerId: r.learnerId,
  sessionId: r.sessionId,
  messageId: r.messageId,
  kind: r.kind as EvidenceItem["kind"],
  subject: r.subject,
  payload: r.payload as Payload,
  source: r.source as EvidenceItem["source"],
  createdAt: r.createdAt,
  retractedAt: r.retractedAt,
});

export class PgStore implements Store {
  async ensureLearner(id: string) {
    await db.insert(learners).values({ id }).onConflictDoNothing();
  }
  async deleteLearner(id: string) {
    await db.delete(evidence).where(eq(evidence.learnerId, id));
    await db.delete(messages).where(eq(messages.learnerId, id));
    await db.delete(sessions).where(eq(sessions.learnerId, id));
    await db.delete(learners).where(eq(learners.id, id));
  }
  async listSessions(learnerId: string) {
    return db.select().from(sessions).where(eq(sessions.learnerId, learnerId)).orderBy(desc(sessions.lastActiveAt));
  }
  async getSession(id: string) {
    const [s] = await db.select().from(sessions).where(eq(sessions.id, id));
    return s ?? null;
  }
  async createSession(learnerId: string, id: string, at = new Date()) {
    const [s] = await db.insert(sessions).values({ id, learnerId, startedAt: at, lastActiveAt: at }).returning();
    return s;
  }
  async updateSession(id: string, patch: Partial<Pick<SessionRow, "title" | "summary" | "lastActiveAt">>) {
    await db.update(sessions).set(patch).where(eq(sessions.id, id));
  }
  async listMessages(sessionId: string) {
    return (await db.select().from(messages).where(eq(messages.sessionId, sessionId)).orderBy(asc(messages.id))).map(toMsg);
  }
  async listAllMessages(learnerId: string) {
    return (await db.select().from(messages).where(eq(messages.learnerId, learnerId)).orderBy(asc(messages.id))).map(toMsg);
  }
  async addMessage(m: Omit<MessageRow, "id" | "createdAt"> & { createdAt?: Date }) {
    const [row] = await db
      .insert(messages)
      .values({ sessionId: m.sessionId, learnerId: m.learnerId, role: m.role, content: m.content, trace: m.trace ?? null, createdAt: m.createdAt })
      .returning();
    return toMsg(row);
  }
  async updateMessageTrace(id: number, trace: TurnTrace) {
    await db.update(messages).set({ trace }).where(eq(messages.id, id));
  }
  async listEvidence(learnerId: string, includeRetracted = false) {
    const rows = await db
      .select()
      .from(evidence)
      .where(includeRetracted ? eq(evidence.learnerId, learnerId) : and(eq(evidence.learnerId, learnerId), isNull(evidence.retractedAt)))
      .orderBy(asc(evidence.id));
    return rows.map(toEv);
  }
  async addEvidence(items: NewEvidence[]) {
    if (!items.length) return [];
    const rows = await db
      .insert(evidence)
      .values(items.map((i) => ({ learnerId: i.learnerId, sessionId: i.sessionId, messageId: i.messageId, kind: i.kind, subject: i.subject, payload: i.payload, source: i.source, createdAt: i.createdAt })))
      .returning();
    return rows.map(toEv);
  }
  async retractEvidence(learnerId: string, id: number, at = new Date()) {
    const r = await db.update(evidence).set({ retractedAt: at }).where(and(eq(evidence.id, id), eq(evidence.learnerId, learnerId))).returning({ id: evidence.id });
    return r.length > 0;
  }
  async setApproachOutcome(id: number, outcome: "worked" | "did_not_work" | "unclear") {
    await db
      .update(evidence)
      .set({ payload: sql`jsonb_set(${evidence.payload}, '{outcome}', ${JSON.stringify(outcome)}::jsonb)` })
      .where(eq(evidence.id, id));
  }
  async searchMessages(learnerId: string, query: string, limit = 6) {
    const terms = query.toLowerCase().split(/\s+/).filter((t) => t.length > 2).slice(0, 5);
    if (!terms.length) return [];
    const rows = await db
      .select()
      .from(messages)
      .where(and(eq(messages.learnerId, learnerId), or(...terms.map((t) => ilike(messages.content, `%${t}%`)))))
      .orderBy(desc(messages.id))
      .limit(limit);
    return rows.map(toMsg);
  }
}

