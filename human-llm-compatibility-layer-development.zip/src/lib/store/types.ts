import type { EvidenceItem, NewEvidence, Payload, TurnTrace } from "@/lib/core/types";

/**
 * Storage behind one small interface so the product uses Postgres while the
 * laboratory and unit tests can use an in-memory store (fast, hermetic,
 * thousands of turns per second). Same semantics either way.
 */

export interface SessionRow {
  id: string;
  learnerId: string;
  title: string;
  summary: string | null;
  startedAt: Date;
  lastActiveAt: Date;
}

export interface MessageRow {
  id: number;
  sessionId: string;
  learnerId: string;
  role: "user" | "assistant";
  content: string;
  trace: TurnTrace | null;
  createdAt: Date;
}

export interface Store {
  ensureLearner(id: string): Promise<void>;
  deleteLearner(id: string): Promise<void>;
  listSessions(learnerId: string): Promise<SessionRow[]>;
  getSession(id: string): Promise<SessionRow | null>;
  createSession(learnerId: string, id: string, at?: Date): Promise<SessionRow>;
  updateSession(id: string, patch: Partial<Pick<SessionRow, "title" | "summary" | "lastActiveAt">>): Promise<void>;
  listMessages(sessionId: string): Promise<MessageRow[]>;
  listAllMessages(learnerId: string): Promise<MessageRow[]>;
  addMessage(m: Omit<MessageRow, "id" | "createdAt"> & { createdAt?: Date }): Promise<MessageRow>;
  updateMessageTrace(id: number, trace: TurnTrace): Promise<void>;
  listEvidence(learnerId: string, includeRetracted?: boolean): Promise<EvidenceItem[]>;
  addEvidence(items: NewEvidence[]): Promise<EvidenceItem[]>;
  retractEvidence(learnerId: string, id: number, at?: Date): Promise<boolean>;
  setApproachOutcome(id: number, outcome: "worked" | "did_not_work" | "unclear"): Promise<void>;
  searchMessages(learnerId: string, query: string, limit?: number): Promise<MessageRow[]>;
}

