import { PgStore } from "./pg";
import type { Store } from "./types";

export type { MessageRow, SessionRow, Store } from "./types";
export { MemoryStore } from "./memory";
export { PgStore } from "./pg";

let pg: PgStore | null = null;
/** The product store (Postgres). The lab and tests import MemoryStore directly. */
export function getStore(): Store {
  return (pg ??= new PgStore());
}
