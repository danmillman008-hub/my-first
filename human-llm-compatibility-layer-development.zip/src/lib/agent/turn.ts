import { approxTokens, compileBrief, compileFlatMemory } from "@/lib/core/brief";
import { deriveState } from "@/lib/core/model";
import { REFLECTION_SCHEMA, reflectionToEvidence, validateReflection } from "@/lib/core/reflect";
import type { Approach, Condition, DerivedState, Reflection, TurnTrace } from "@/lib/core/types";
import type { LLM } from "@/lib/llm";
import type { MockAction, MockTurnContext } from "@/lib/llm/mock";
import type { ChatMessage } from "@/lib/llm/types";
import type { MessageRow, Store } from "@/lib/store/types";
import { REFLECTION_SYSTEM, systemPrompt } from "./prompt";
import { TOOL_DECLS, runTool } from "./tools";

/**
 * One conversational turn through the compatibility layer.
 *
 *   load evidence → derive state → compile brief → model replies (with tools)
 *   → reflection extracts evidence → book it → attribute previous approach
 *
 * All baselines are *modes of this same function* so the only difference
 * between conditions is what the model is told about the past.
 */

export interface TurnInput {
  store: Store;
  llm: LLM;
  learnerId: string;
  sessionId: string;
  userMessage: string;
  condition?: Condition;
  now?: Date;
  /** Lab only: oracle information for the offline mock's reflection. */
  mockHints?: MockTurnContext["hints"];
  historyLimit?: number;
}

export type TurnEvent =
  | { type: "session"; sessionId: string }
  | { type: "text"; text: string }
  | { type: "tool"; name: string; args: unknown }
  | { type: "trace"; trace: TurnTrace; messageId: number }
  | { type: "error"; message: string };

export const TRANSCRIPT_BUDGET_CHARS = 6000; // ≈ 4× a typical brief, in the transcript baseline's favour

function transcriptOfOtherSessions(all: MessageRow[], currentSessionId: string): string {
  const others = all.filter((m) => m.sessionId !== currentSessionId);
  const bySession = new Map<string, MessageRow[]>();
  for (const m of others) bySession.set(m.sessionId, [...(bySession.get(m.sessionId) ?? []), m]);
  const blocks = [...bySession.values()].sort((a, b) => b[0].createdAt.getTime() - a[0].createdAt.getTime());
  let out = "";
  for (const b of blocks) {
    const text = `--- session ${b[0].createdAt.toISOString().slice(0, 10)} ---\n${b.map((m) => `${m.role}: ${m.content.replace(/\[\[mock:[^\]]*\]\]\s*/g, "")}`).join("\n")}\n`;
    if (out.length + text.length > TRANSCRIPT_BUDGET_CHARS) {
      out += text.slice(0, Math.max(0, TRANSCRIPT_BUDGET_CHARS - out.length));
      break;
    }
    out += text;
  }
  return out || "(no earlier conversations)";
}

export async function* runTurn(input: TurnInput): AsyncGenerator<TurnEvent> {
  const t0 = Date.now();
  const { store, llm, learnerId, sessionId, userMessage } = input;
  const condition = input.condition ?? "layer";
  const now = input.now ?? new Date();

  await store.ensureLearner(learnerId);
  let session = await store.getSession(sessionId);
  if (!session) session = await store.createSession(learnerId, sessionId, now);
  yield { type: "session", sessionId };

  // ---- context ----
  const history = await store.listMessages(sessionId);
  const prevAssistant = [...history].reverse().find((m) => m.role === "assistant") ?? null;
  const allEvidence = condition === "none" || condition === "transcript" ? [] : await store.listEvidence(learnerId);
  let state: DerivedState | null = null;
  let brief = "";
  let mockCtx: MockTurnContext = { condition, userMessage, hints: input.mockHints, history: history.map((m) => `${m.role}: ${m.content}`).join("\n") };

  if (condition === "layer") {
    state = deriveState(allEvidence, now);
    const prior = (await store.listSessions(learnerId)).find((s) => s.id !== sessionId && s.summary);
    brief = compileBrief(state, { lastSessionSummary: prior?.summary ?? null });
    mockCtx = { ...mockCtx, state };
  } else if (condition === "flat_memory") {
    brief = compileFlatMemory(allEvidence);
    mockCtx = { ...mockCtx, flatLines: brief.split("\n").slice(1) };
  } else if (condition === "transcript") {
    brief = transcriptOfOtherSessions(await store.listAllMessages(learnerId), sessionId);
    mockCtx = { ...mockCtx, transcript: brief };
  }

  const system = systemPrompt(condition, brief);
  const limit = input.historyLimit ?? 30;
  const messages: ChatMessage[] = [...history.slice(-limit).map((m) => ({ role: m.role, content: m.content })), { role: "user", content: userMessage }];

  const userRow = await store.addMessage({ sessionId, learnerId, role: "user", content: userMessage, trace: null, createdAt: now });

  // ---- model ----
  const toolCalls: TurnTrace["toolCalls"] = [];
  let text = "";
  let mockAction: string | undefined;
  let mockSkill: string | null = null;
  try {
    const gen = llm.stream({
      system,
      messages,
      tools: condition === "layer" ? TOOL_DECLS : undefined,
      mockContext: mockCtx,
      onTool: async (call) => {
        const result = condition === "layer" ? await runTool(call, { store, learnerId, sessionId, now }) : "Tools are not available.";
        toolCalls.push({ name: call.name, args: call.args, result: result.slice(0, 500) });
        return result;
      },
    });
    for await (const ev of gen) {
      if (ev.type === "text") {
        // strip the mock's action marker from what the user sees, keep it for the trace
        const m = /^\[\[mock:([a-z_]+):([a-z_]+):([a-z0-9+#.-]*)\]\]\s*/.exec(ev.text);
        let out = ev.text;
        if (m) {
          mockAction = `${m[1]}:${m[2]}`;
          mockSkill = m[3] || null;
          out = ev.text.slice(m[0].length);
        }
        text += out;
        if (out) yield { type: "text", text: out };
      } else if (ev.type === "tool_call") {
        yield { type: "tool", name: ev.call.name, args: ev.call.args };
      }
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    yield { type: "error", message };
    text = text || `_(The model request failed: ${message})_`;
  }

  const assistantRow = await store.addMessage({ sessionId, learnerId, role: "assistant", content: text, trace: null, createdAt: new Date(now.getTime() + 1) });

  // ---- reflection & bookkeeping (memory conditions only) ----
  let reflection: Reflection | null = null;
  let evidenceAdded = 0;
  if (condition === "layer" || condition === "flat_memory") {
    try {
      const [act, appr] = (mockAction ?? ":").split(":") as [MockAction | "", Approach | ""];
      const raw = await llm.json({
        system: REFLECTION_SYSTEM,
        prompt: [
          state ? `Known so far (for context, do not re-record):\n${brief.slice(0, 2500)}\n` : "",
          prevAssistant ? `PREVIOUS assistant message:\n${prevAssistant.content.slice(0, 1500)}\n` : "",
          `PERSON's message:\n${userMessage.slice(0, 3000)}\n`,
          `ASSISTANT's reply:\n${text.slice(0, 3000)}`,
        ].join("\n"),
        schema: REFLECTION_SCHEMA,
        mockContext: {
          user: userMessage,
          assistant: text,
          action: act || undefined,
          approach: appr || undefined,
          skill: mockCtx.hints?.skill ?? mockSkill,
          hints: input.mockHints,
          hadPrevious: !!prevAssistant,
        },
      });
      reflection = validateReflection(raw);
      // correction from the tool path is already booked; don't double count "forget" corrections
      if (toolCalls.some((t) => t.name === "forget")) reflection.corrections = [];

      const rows = reflectionToEvidence(reflection, { learnerId, sessionId, messageId: assistantRow.id, source: "reflection", createdAt: new Date(now.getTime() + 2) });
      const added = await store.addEvidence(rows);
      evidenceAdded = added.length;

      // Attribution: the previous assistant turn's approach is judged by THIS user message.
      if (condition === "layer" && state?.pendingApproachId && reflection.previousApproachOutcome && prevAssistant) {
        const pending = allEvidence.find((e) => e.id === state!.pendingApproachId);
        if (pending && pending.messageId === prevAssistant.id) await store.setApproachOutcome(pending.id, reflection.previousApproachOutcome);
      }
      if (reflection.sessionTitle && session.title === "New conversation") await store.updateSession(sessionId, { title: reflection.sessionTitle });
    } catch (err) {
      // Reflection failure must never break the conversation; it just means no new evidence this turn.
      reflection = null;
      if (process.env.NODE_ENV !== "test") console.warn("reflection failed:", err instanceof Error ? err.message : err);
    }
  }
  if (session.title === "New conversation" && !reflection?.sessionTitle) {
    await store.updateSession(sessionId, { title: userMessage.replace(/\s+/g, " ").slice(0, 48) || "New conversation" });
  }
  await store.updateSession(sessionId, { lastActiveAt: now, summary: summarise(history, userMessage, text) });

  const trace: TurnTrace = {
    condition,
    model: llm.name,
    brief,
    briefTokens: approxTokens(brief),
    promptChars: system.length + messages.reduce((n, m) => n + m.content.length, 0),
    toolCalls,
    reflection,
    evidenceAdded,
    mockAction,
    ms: Date.now() - t0,
  };
  await store.updateMessageTrace(assistantRow.id, trace);
  void userRow;
  yield { type: "trace", trace, messageId: assistantRow.id };
}


/** Cheap extractive session summary: first user request + last exchange. Good enough as a "last time" cue. */
function summarise(history: MessageRow[], userMessage: string, reply: string): string {
  const firstUser = history.find((m) => m.role === "user")?.content ?? userMessage;
  const clean = (s: string) => s.replace(/\[\[mock:[^\]]*\]\]\s*/g, "").replace(/\s+/g, " ").trim();
  return `started with "${clean(firstUser).slice(0, 80)}"; most recently they said "${clean(userMessage).slice(0, 80)}" and you replied "${clean(reply).slice(0, 100)}…"`;
}
