import { compileBrief } from "@/lib/core/brief";
import { deriveState, slugify } from "@/lib/core/model";
import type { NewEvidence, StyleDimension } from "@/lib/core/types";
import { STYLE_DIMENSIONS } from "@/lib/core/types";
import type { ToolCall, ToolDecl } from "@/lib/llm/types";
import type { Store } from "@/lib/store/types";

/** Three tools. The brief handles the common case; tools handle the long tail. */
export const TOOL_DECLS: ToolDecl[] = [
  {
    name: "recall_memory",
    description: "Search earlier conversations and stored evidence about this person. Use when they refer to something specific from before ('that bug we fixed', 'what did I say about X').",
    parameters: { type: "object", properties: { query: { type: "string" } }, required: ["query"] },
  },
  {
    name: "remember",
    description: "Store something the person explicitly asked you to remember about them (a fact, preference or constraint).",
    parameters: { type: "object", properties: { note: { type: "string" } }, required: ["note"] },
  },
  {
    name: "forget",
    description: "Retract stored evidence when the person asks you to forget something or says an assumption about them is wrong. Pass what to forget in their words.",
    parameters: { type: "object", properties: { what: { type: "string" } }, required: ["what"] },
  },
];

export interface ToolCtx {
  store: Store;
  learnerId: string;
  sessionId: string;
  now: Date;
}

const DIM_WORDS: Record<StyleDimension, RegExp> = {
  depth: /\b(depth|detail|thorough|brief|short|long)\b/i,
  examples: /\b(example|concrete|abstract|code|trace|analog)/i,
  checks: /\b(quiz|check|test|practice|exercise)/i,
  directness: /\b(hint|direct|answer|socratic|work it out)/i,
  pace: /\b(pace|fast|slow|speed|basics)/i,
};

export async function runTool(call: ToolCall, ctx: ToolCtx): Promise<string> {
  const { store, learnerId, sessionId, now } = ctx;
  switch (call.name) {
    case "recall_memory": {
      const q = String(call.args.query ?? "").slice(0, 200);
      const msgs = await store.searchMessages(learnerId, q, 6);
      const ev = await store.listEvidence(learnerId);
      const state = deriveState(ev, now);
      const terms = q.toLowerCase().split(/\s+/).filter((t) => t.length > 2);
      const skills = state.skills.filter((s) => terms.some((t) => s.skill.includes(t)));
      const lines: string[] = [];
      if (skills.length) lines.push("Evidence:", compileBrief({ ...state, beliefs: [], facts: [], approaches: [], doNotAssume: [], skills }, { maxSkills: 5 }));
      if (msgs.length) {
        lines.push("Earlier messages:");
        for (const m of msgs) lines.push(`[${m.createdAt.toISOString().slice(0, 10)} ${m.role}] ${m.content.replace(/\s+/g, " ").slice(0, 300)}`);
      }
      return lines.length ? lines.join("\n") : "Nothing relevant found in earlier conversations.";
    }
    case "remember": {
      const note = String(call.args.note ?? "").trim().slice(0, 200);
      if (!note) return "Nothing to remember.";
      const key = `note-${slugify(note.split(/\s+/).slice(0, 4).join(" "))}`;
      const items: NewEvidence[] = [{ learnerId, sessionId, messageId: null, kind: "fact", subject: key, payload: { kind: "fact", key, value: note }, source: "tool", createdAt: now }];
      await store.addEvidence(items);
      return `Stored: "${note}". The person can see and delete this in their memory panel.`;
    }
    case "forget": {
      const what = String(call.args.what ?? "").trim().slice(0, 200);
      const ev = await store.listEvidence(learnerId);
      const terms = what.toLowerCase().split(/\s+/).filter((t) => t.length > 2);
      let retracted = 0;
      const corrections: NewEvidence[] = [];
      const targets = new Set<string>();
      for (const e of ev) {
        const hay = `${e.subject} ${JSON.stringify(e.payload)}`.toLowerCase();
        const hit = terms.some((t) => hay.includes(t));
        if (!hit) continue;
        if (e.payload.kind === "fact" || e.payload.kind === "skill") {
          await store.retractEvidence(learnerId, e.id, now);
          retracted++;
          targets.add(`${e.payload.kind}:${e.subject}`);
        }
      }
      for (const dim of STYLE_DIMENSIONS) {
        if (DIM_WORDS[dim].test(what)) targets.add(`style:${dim}`);
      }
      for (const t of targets) corrections.push({ learnerId, sessionId, messageId: null, kind: "correction", subject: t, payload: { kind: "correction", target: t, note: what }, source: "tool", createdAt: now });
      if (corrections.length) await store.addEvidence(corrections);
      if (!retracted && !corrections.length) return `No stored evidence matched "${what}".`;
      return `Retracted ${retracted} item(s) and recorded a correction for ${[...targets].join(", ")}. Related beliefs will not be re-inferred for 14 days.`;
    }
    default:
      return `Unknown tool ${call.name}`;
  }
}
