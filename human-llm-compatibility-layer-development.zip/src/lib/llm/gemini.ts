import type { ChatMessage, GenerateOptions, JsonOptions, LLM, StreamEvent, ToolDecl } from "./types";

/**
 * Gemini via the public REST API (generativelanguage.googleapis.com), no SDK.
 *
 * - streamGenerateContent?alt=sse for text + function calls
 * - generateContent with responseMimeType/responseSchema for structured output
 * - Parts (including `thoughtSignature` on Gemini 3 models) are passed back
 *   opaquely during tool loops, as the docs require.
 * - The model id is configurable (GEMINI_MODEL). Because model names churn,
 *   the client resolves the id once against /models and falls back through a
 *   list of known flash ids if the configured one does not exist.
 */

const BASE = process.env.GEMINI_BASE_URL ?? "https://generativelanguage.googleapis.com/v1beta";
export const DEFAULT_MODEL = process.env.GEMINI_MODEL ?? "gemini-3.6-flash";
const FALLBACKS = ["gemini-3.7-flash", "gemini-3.5-flash", "gemini-3-flash-preview", "gemini-2.5-flash", "gemini-2.0-flash"];

export function geminiApiKey(): string | undefined {
  return process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || process.env.GOOGLE_GENERATIVE_AI_API_KEY || undefined;
}

type Part = Record<string, any>;
interface Content {
  role: "user" | "model";
  parts: Part[];
}

let resolvedModel: string | null = null;

export async function resolveModel(apiKey: string): Promise<string> {
  if (resolvedModel) return resolvedModel;
  const candidates = [DEFAULT_MODEL, ...FALLBACKS.filter((m) => m !== DEFAULT_MODEL)];
  try {
    const res = await fetch(`${BASE}/models?pageSize=200`, { headers: { "x-goog-api-key": apiKey } });
    if (res.ok) {
      const data = (await res.json()) as { models?: { name: string; supportedGenerationMethods?: string[] }[] };
      const names = new Set((data.models ?? []).map((m) => m.name.replace(/^models\//, "")));
      for (const c of candidates) if (names.has(c)) return (resolvedModel = c);
      // any flash model that supports generateContent, newest-looking first
      const flash = [...names].filter((n) => /flash/.test(n) && !/lite|image|tts|live|audio|embedding|native/.test(n)).sort().reverse();
      if (flash[0]) return (resolvedModel = flash[0]);
    }
  } catch {
    /* fall through */
  }
  return (resolvedModel = DEFAULT_MODEL);
}

function toContents(messages: ChatMessage[]): Content[] {
  return messages.map((m) => ({ role: m.role === "user" ? "user" : "model", parts: [{ text: m.content }] }));
}

function toTools(tools?: ToolDecl[]) {
  if (!tools?.length) return undefined;
  return [{ functionDeclarations: tools.map((t) => ({ name: t.name, description: t.description, parameters: t.parameters })) }];
}

async function* sseParts(res: Response): AsyncGenerator<Part[]> {
  const reader = res.body!.getReader();
  const dec = new TextDecoder();
  let buf = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let idx: number;
    while ((idx = buf.indexOf("\n\n")) >= 0) {
      const chunk = buf.slice(0, idx);
      buf = buf.slice(idx + 2);
      for (const line of chunk.split("\n")) {
        if (!line.startsWith("data:")) continue;
        const json = line.slice(5).trim();
        if (!json || json === "[DONE]") continue;
        try {
          const obj = JSON.parse(json);
          const parts: Part[] = obj?.candidates?.[0]?.content?.parts ?? [];
          if (parts.length) yield parts;
          if (obj?.promptFeedback?.blockReason) yield [{ text: `\n\n_(Response blocked: ${obj.promptFeedback.blockReason})_` }];
        } catch {
          /* ignore partial */
        }
      }
    }
  }
}

export class GeminiLLM implements LLM {
  readonly live = true;
  constructor(
    private apiKey: string,
    public name: string = DEFAULT_MODEL,
  ) {}

  private async model() {
    this.name = await resolveModel(this.apiKey);
    return this.name;
  }

  async *stream(opts: GenerateOptions): AsyncGenerator<StreamEvent> {
    const model = await this.model();
    const contents = toContents(opts.messages);
    const tools = toTools(opts.tools);
    for (let round = 0; round < 6; round++) {
      const res = await fetch(`${BASE}/models/${model}:streamGenerateContent?alt=sse`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-goog-api-key": this.apiKey },
        signal: opts.signal,
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: opts.system }] },
          contents,
          tools,
          generationConfig: { temperature: 0.7 },
        }),
      });
      if (!res.ok || !res.body) {
        const txt = await res.text().catch(() => "");
        throw new Error(`Gemini ${res.status}: ${txt.slice(0, 400)}`);
      }
      const modelParts: Part[] = [];
      const calls: Part[] = [];
      for await (const parts of sseParts(res)) {
        for (const p of parts) {
          if (p.thought) continue; // thinking summaries are not shown
          if (typeof p.text === "string" && p.text) {
            yield { type: "text", text: p.text };
            modelParts.push(p);
          } else if (p.functionCall) {
            calls.push(p);
            modelParts.push(p);
          } else {
            modelParts.push(p); // thoughtSignature-only parts etc.
          }
        }
      }
      if (!calls.length || !opts.onTool) break;
      contents.push({ role: "model", parts: modelParts });
      const responses: Part[] = [];
      for (const c of calls) {
        const call = { name: String(c.functionCall.name), args: (c.functionCall.args ?? {}) as Record<string, unknown> };
        yield { type: "tool_call", call };
        const result = await opts.onTool(call);
        responses.push({ functionResponse: { name: call.name, response: { result } } });
      }
      contents.push({ role: "user", parts: responses });
    }
    yield { type: "done" };
  }

  async json<T = unknown>(opts: JsonOptions): Promise<T> {
    const model = await this.model();
    const res = await fetch(`${BASE}/models/${model}:generateContent`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": this.apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: opts.system }] },
        contents: [{ role: "user", parts: [{ text: opts.prompt }] }],
        generationConfig: { temperature: 0.1, responseMimeType: "application/json", responseSchema: opts.schema },
      }),
    });
    if (!res.ok) throw new Error(`Gemini ${res.status}: ${(await res.text()).slice(0, 400)}`);
    const data = await res.json();
    const text: string = (data?.candidates?.[0]?.content?.parts ?? [])
      .filter((p: Part) => typeof p.text === "string" && !p.thought)
      .map((p: Part) => p.text)
      .join("");
    return JSON.parse(text) as T;
  }
}
