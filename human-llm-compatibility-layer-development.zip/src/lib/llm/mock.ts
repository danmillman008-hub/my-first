import type { DerivedState, Approach, Condition, StyleDimension } from "@/lib/core/types";
import type { GenerateOptions, JsonOptions, LLM, StreamEvent } from "./types";

/**
 * OFFLINE MOCK MODEL.
 *
 * Exists so that the product boots, the tests run and the laboratory can
 * measure the LAYER (bookkeeping, brief, lifecycle) without an API key.
 * Its "pedagogy" is a tiny scripted policy that reads the same context the
 * real model gets — structured for `layer`, flat lines for `flat_memory`,
 * raw text for `transcript`, nothing for `none`.
 *
 * Nothing it says is evidence about Gemini. It is clearly labelled in the UI.
 */

export interface MockTurnContext {
  condition: Condition;
  state?: DerivedState;
  flatLines?: string[];
  transcript?: string;
  /** current-session messages (a real model always sees these) as "role: text" lines */
  history?: string;
  userMessage: string;
  /** Lab oracle for reflection: whether the learner's answer was correct. */
  hints?: { skill?: string; answerCorrect?: boolean; previousApproach?: Approach | null; day?: number };
}

export type MockAction = "explain" | "check" | "refresh_check" | "verify_claim" | "answer" | "chat";

const TOPIC_RE = /(?:teach me|explain|what is|what are|how do(?:es)? .* work|help me (?:understand|with)|show me|about)\s+(.+?)[?.!]*$/i;

export function extractTopic(msg: string): string | null {
  const m = TOPIC_RE.exec(msg.trim());
  if (!m) return null;
  return m[1]
    .toLowerCase()
    .replace(/^(?:the|a|an)\s+/, "")
    .replace(/\s+(?:please|again|now)$/, "")
    .replace(/[^a-z0-9+#.\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-");
}

function prefFromState(state: DerivedState | undefined, dim: StyleDimension): number {
  const b = state?.beliefs.find((x) => x.dimension === dim);
  if (!b || b.status === "retired" || b.status === "candidate") return 0;
  if (b.status === "contested") return b.demonstratedValue ?? 0; // trust behaviour over words when they disagree
  return b.value;
}

function prefFromFlat(lines: string[] | undefined, dim: StyleDimension): number {
  if (!lines) return 0;
  // A naive reader: the last "Prefers …" line about this dimension wins; a later correction line clears it.
  let v = 0;
  for (const l of lines) {
    if (/Correction noted about style:/.test(l) && l.includes(dim)) v = 0;
    if (dim === "directness" && /Prefers direct answers/.test(l)) v = 1;
    if (dim === "directness" && /Prefers hints/.test(l)) v = -1;
    if (dim === "examples" && /Prefers concrete/.test(l)) v = 1;
    if (dim === "examples" && /Prefers abstract/.test(l)) v = -1;
  }
  return v;
}

function prefFromTranscript(t: string | undefined, dim: StyleDimension): number {
  if (!t) return 0;
  let v = 0;
  // transcripts are given most-recent-first; a careful reader processes them chronologically so the latest statement wins
  const blocks = t.split(/^--- session [^\n]*---$/m).reverse();
  for (const line of blocks.join("\n").split("\n")) {
    if (!/^user:/i.test(line)) continue;
    if (dim === "directness") {
      if (/(give me hints|don't give me the answer|let me work it out)/i.test(line)) v = -1;
      if (/(just give me the answer|answer directly|stop (the|with the) hints)/i.test(line)) v = 1;
    }
  }
  return v;
}

export function mockDecide(ctx: MockTurnContext): { action: MockAction; approach: Approach; skill: string | null } {
  const msg = ctx.userMessage;
  const topic = extractTopic(msg);
  const isTeach = /(teach me|explain|what is|what are|how do|help me understand|show me)/i.test(msg);
  const isAnswer = /^(answer|my answer|i think|it is|it's|because)/i.test(msg.trim());
  // Every condition sees the current conversation; memory conditions additionally see their memory.
  const inSession = prefFromTranscript(ctx.history, "directness");
  const remembered =
    ctx.condition === "layer" ? prefFromState(ctx.state, "directness") : ctx.condition === "flat_memory" ? prefFromFlat(ctx.flatLines, "directness") : ctx.condition === "transcript" ? prefFromTranscript(ctx.transcript, "directness") : 0;
  const directness = inSession !== 0 ? inSession : remembered;
  const examples = ctx.condition === "layer" ? prefFromState(ctx.state, "examples") : ctx.condition === "flat_memory" ? prefFromFlat(ctx.flatLines, "examples") : 0;
  const explainApproach: Approach = examples > 0 ? "worked_example" : examples < 0 ? "conceptual_explanation" : "conceptual_explanation";

  if (isAnswer && !isTeach) return { action: "answer", approach: directness < 0 ? "socratic_question" : "direct_answer", skill: null };
  if (!isTeach || !topic) return { action: "chat", approach: directness < 0 ? "socratic_question" : "direct_answer", skill: null };

  // What do we believe about this topic?
  if (ctx.condition === "layer" && ctx.state) {
    const s = ctx.state.skills.find((k) => k.skill === topic);
    if (s) {
      if (s.explained >= 2 && s.demonstratedUnaided === 0 && s.status !== "struggling") return { action: "refresh_check", approach: "retrieval_check", skill: topic };
      if (s.status === "demonstrated") return { action: "check", approach: "retrieval_check", skill: topic };
      if (s.status === "fading") return s.recall < 0.3 ? { action: "explain", approach: explainApproach, skill: topic } : { action: "refresh_check", approach: "retrieval_check", skill: topic };
      if (s.status === "claimed") return { action: "verify_claim", approach: "retrieval_check", skill: topic };
      if (s.status === "struggling") {
        const alt: Approach = s.explained > 0 && explainApproach === "conceptual_explanation" ? "worked_example" : explainApproach;
        return { action: "explain", approach: alt, skill: topic };
      }
      if (s.status === "explained" && s.recall >= 0.6) return { action: "check", approach: "retrieval_check", skill: topic };
    }
    return { action: "explain", approach: explainApproach, skill: topic };
  }
  if (ctx.condition === "flat_memory" && ctx.flatLines) {
    const knows = ctx.flatLines.some((l) => l.startsWith(`- Knows ${topic}`));
    if (knows) return { action: "check", approach: "retrieval_check", skill: topic };
    return { action: "explain", approach: explainApproach, skill: topic };
  }
  if (ctx.condition === "transcript" && ctx.transcript) {
    const t = ctx.transcript.toLowerCase();
    const human = topic.replace(/-/g, " ");
    const claimed = new RegExp(`user:.*already know.*${human}`).test(t);
    const shown = t.includes(`✅ ${human}`) || t.includes(`✅ ${topic}`);
    if (claimed || shown) return { action: "check", approach: "retrieval_check", skill: topic };
  }
  return { action: "explain", approach: explainApproach, skill: topic };
}

function render(action: MockAction, approach: Approach, skill: string | null, msg: string, hints?: MockTurnContext["hints"]): string {
  const h = skill ? skill.replace(/-/g, " ") : "this";
  switch (action) {
    case "check":
      return `You've shown you can handle ${h} before, so rather than re-explaining: quick check — in your own words, what is the key idea of ${h}, and where would it break?`;
    case "refresh_check":
      return `We covered ${h} a while ago and it may have faded. One-line reminder: it's the idea we practised earlier. Now try it yourself: how would you apply ${h} to a small case?`;
    case "verify_claim":
      return `You mentioned you already know ${h}. Let's quickly confirm so I don't waste your time: what's the one thing people usually get wrong about ${h}?`;
    case "explain":
      return approach === "worked_example"
        ? `Let's look at ${h} through a concrete example first.\n\nStep 1 … Step 2 … Step 3 — and here's the trace of what happens at each step.\n\nNow you try: apply the same steps to a slightly different case.`
        : `${h[0].toUpperCase()}${h.slice(1)} is the general principle that … (definition, then the two properties that matter, then the common pitfall).\n\nTry a case yourself to see if it holds.`;
    case "answer":
      if (hints?.answerCorrect === false) return approach === "socratic_question" ? `Not quite. What happens at the boundary case? Think about the first step again.` : `Not quite — the key point you missed is the boundary case. Here's the correct reasoning: …`;
      if (hints?.answerCorrect === true) return `✅ ${h === "this" ? "Correct" : h} — that's right, and your reasoning is sound.`;
      return approach === "socratic_question" ? `Interesting — what makes you say that? Check it against one small example.` : `Here's the direct answer: …`;
    case "chat":
      return approach === "socratic_question" ? `Before I answer: what do you already think about "${msg.slice(0, 60)}"?` : `Sure. Short answer: … Let me know if you want more depth.`;
  }
}

export class MockLLM implements LLM {
  readonly name = "offline-mock";
  readonly live = false;

  async *stream(opts: GenerateOptions): AsyncGenerator<StreamEvent> {
    const ctx = opts.mockContext as MockTurnContext | undefined;
    const last = opts.messages[opts.messages.length - 1]?.content ?? "";
    const c: MockTurnContext = ctx ?? { condition: "none", userMessage: last };
    const d = mockDecide(c);
    // Honour explicit remember / forget requests through the same tools as the real model.
    const rem = /^(?:please )?remember (?:that )?(.+)$/i.exec(last.trim());
    if (rem && opts.onTool) {
      const r = await opts.onTool({ name: "remember", args: { note: rem[1] } });
      yield { type: "tool_call", call: { name: "remember", args: { note: rem[1] } } };
      yield { type: "text", text: `Noted — ${r}` };
      yield { type: "done" };
      return;
    }
    const fg = /^(?:please )?forget (?:that |about )?(.+)$/i.exec(last.trim());
    if (fg && opts.onTool) {
      const r = await opts.onTool({ name: "forget", args: { what: fg[1] } });
      yield { type: "tool_call", call: { name: "forget", args: { what: fg[1] } } };
      yield { type: "text", text: `Done — ${r}` };
      yield { type: "done" };
      return;
    }
    const text = render(d.action, d.approach, d.skill, last, c.hints);
    yield { type: "text", text: `[[mock:${d.action}:${d.approach}:${d.skill ?? ""}]] ${text}` };
    yield { type: "done" };
  }

  async json<T = unknown>(opts: JsonOptions): Promise<T> {
    const ctx = (opts.mockContext ?? {}) as { user?: string; assistant?: string; action?: MockAction; approach?: Approach; skill?: string | null; hints?: MockTurnContext["hints"]; hadPrevious?: boolean };
    const user = ctx.user ?? "";
    const skills: unknown[] = [];
    const style: unknown[] = [];
    const facts: unknown[] = [];
    const corrections: unknown[] = [];
    let reaction = 0;

    // Lab oracle / lexical cues for the learner's message
    const claim = /already know (?:about )?(.+?)[.,!]?$/i.exec(user);
    if (claim) skills.push({ name: claim[1], event: "claimed" });
    if (ctx.hints?.answerCorrect !== undefined && ctx.hints.skill) {
      skills.push({ name: ctx.hints.skill, event: ctx.hints.answerCorrect ? "demonstrated" : "failed", aided: false });
      reaction = ctx.hints.answerCorrect ? 1 : 0;
    }
    if (/(give me hints|don't give me the answer|let me work it out)/i.test(user)) style.push({ dimension: "directness", value: -1, basis: "stated" });
    if (/(just give me the answer|answer directly|stop (the|with the) hints)/i.test(user)) {
      style.push({ dimension: "directness", value: 1, basis: "stated" });
      if (/(actually|stop|changed my mind|no longer)/i.test(user)) corrections.push({ target: "style:directness", note: "asked for direct answers now" });
    }
    if (/(examples? (really )?help|show me (an )?example|walk me through)/i.test(user)) style.push({ dimension: "examples", value: 1, basis: "demonstrated" });
    if (/(let me (think|try)|figure it out myself)/i.test(user)) style.push({ dimension: "directness", value: -1, basis: "reaction" });
    if (/(that (made sense|helped|was clear)|got it|makes sense)/i.test(user)) reaction = 1;
    if (/(confus|lost|didn't help|don't get it|too much)/i.test(user)) reaction = -1;
    const fact = /(?:i am|i'm) an? ([a-z ]{3,30}?)(?: and| who| that|[.,]|$)/i.exec(user);
    if (fact && !/sure|bit|little|not/.test(fact[1])) facts.push({ key: "occupation", value: fact[1].trim() });
    const goal = /(?:my goal is|i want to learn|i'm learning) (.+?)[.!]?$/i.exec(user);
    if (goal) facts.push({ key: "goal", value: goal[1].trim().slice(0, 60) });
    const forget = /(?:that's (?:not|no longer) true|i (?:never|don't) (?:said|want) that|stop assuming) (?:about |that )?(.+)$/i.exec(user);
    if (forget && /hint|direct/i.test(forget[1])) corrections.push({ target: "style:directness", note: forget[1] });

    // The assistant's own action
    if (ctx.action === "explain" && ctx.skill) skills.push({ name: ctx.skill, event: "explained" });
    const prevOutcome = !ctx.hadPrevious ? undefined : ctx.hints?.answerCorrect === true ? "worked" : ctx.hints?.answerCorrect === false ? "did_not_work" : reaction > 0 ? "worked" : reaction < 0 ? "did_not_work" : "unclear";

    return {
      skills,
      style,
      facts,
      corrections,
      reaction,
      previous_approach_outcome: prevOutcome,
      approach_used: ctx.approach ?? "other",
      approach_skill: ctx.skill ?? undefined,
      session_title: undefined,
    } as T;
  }
}
