/** Minimal provider contract. Only what the product needs; no speculative abstraction. */

export type Role = "user" | "assistant";

export interface ChatMessage {
  role: Role;
  content: string;
}

export interface ToolDecl {
  name: string;
  description: string;
  parameters: Record<string, unknown>; // JSON schema (object)
}

export interface ToolCall {
  name: string;
  args: Record<string, unknown>;
}

export type StreamEvent = { type: "text"; text: string } | { type: "tool_call"; call: ToolCall } | { type: "done" };

export interface GenerateOptions {
  system: string;
  messages: ChatMessage[];
  tools?: ToolDecl[];
  /** Called when the model requests a tool; return the string result. */
  onTool?: (call: ToolCall) => Promise<string>;
  /** Optional structured hint the mock can use; real models ignore it. */
  mockContext?: unknown;
  signal?: AbortSignal;
}

export interface JsonOptions {
  system: string;
  prompt: string;
  schema: Record<string, unknown>;
  mockContext?: unknown;
}

export interface LLM {
  readonly name: string;
  readonly live: boolean;
  /** Streams assistant text; handles tool-call loops internally via onTool. */
  stream(opts: GenerateOptions): AsyncGenerator<StreamEvent>;
  /** Structured output. */
  json<T = unknown>(opts: JsonOptions): Promise<T>;
}
