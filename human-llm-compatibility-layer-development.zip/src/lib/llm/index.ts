import { GeminiLLM, geminiApiKey, DEFAULT_MODEL } from "./gemini";
import { MockLLM } from "./mock";
import type { LLM } from "./types";

export type { LLM } from "./types";

let cached: LLM | null = null;

/** Gemini when a key is configured, otherwise the clearly-labelled offline mock. */
export function getLLM(force?: "mock" | "gemini"): LLM {
  if (force === "mock") return new MockLLM();
  const key = geminiApiKey();
  if (force === "gemini" && !key) throw new Error("GEMINI_API_KEY is not set");
  if (!key) return new MockLLM();
  if (!cached) cached = new GeminiLLM(key, DEFAULT_MODEL);
  return cached;
}

export function llmStatus() {
  const key = geminiApiKey();
  return { live: !!key, provider: key ? "gemini" : "offline-mock", model: key ? DEFAULT_MODEL : "offline-mock" };
}
