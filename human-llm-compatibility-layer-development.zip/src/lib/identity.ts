import { cookies } from "next/headers";
import { randomUUID } from "node:crypto";

export const LEARNER_COOKIE = "cl_learner";

/** One cookie = one relationship. No accounts; the person can erase everything from the UI. */
export async function getLearnerId(create = true): Promise<string | null> {
  const jar = await cookies();
  const existing = jar.get(LEARNER_COOKIE)?.value;
  if (existing && /^[a-zA-Z0-9-]{8,64}$/.test(existing)) return existing;
  if (!create) return null;
  const id = randomUUID();
  jar.set(LEARNER_COOKIE, id, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 365 });
  return id;
}
