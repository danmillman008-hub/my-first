import { describe } from "./model";
import type { DerivedState, EvidenceItem, SkillState, StyleBelief } from "./types";

/**
 * The brief is the layer's interface to the model: a compact, epistemically
 * labelled summary (~150–400 tokens) the model can reason over freely.
 *
 * Every line says HOW we know something (stated / demonstrated / explained /
 * corrected) so that the model can weigh it rather than obey it.
 */

export const approxTokens = (s: string) => Math.ceil(s.length / 4);

const ago = (d: number) => (d < 0.05 ? "just now" : d < 1 ? "earlier today" : d < 2 ? "yesterday" : `${Math.round(d)}d ago`);

function skillLine(s: SkillState): string {
  const parts: string[] = [];
  if (s.verifiedClaim) parts.push("knew this before we covered it (claimed, then shown unaided)");
  else if (s.claimed && s.demonstratedUnaided === 0) parts.push("CLAIMS to know it — unverified");
  if (s.explained) parts.push(`explained ${s.explained}×`);
  if (s.demonstratedUnaided) parts.push(`shown unaided ${s.demonstratedUnaided}×`);
  if (s.demonstratedAided) parts.push(`shown with help ${s.demonstratedAided}×`);
  if (s.failed) parts.push(`missed ${s.failed}×`);
  parts.push(`last ${ago(s.daysSince)}`);
  parts.push(`est. recall now ${Math.round(s.recall * 100)}%`);
  let hint = "";
  if (s.explained >= 2 && s.demonstratedUnaided === 0 && s.status !== "struggling") {
    hint = ` → explained ${s.explained}× but never shown unaided: have them attempt it before explaining a third time (explanation alone gives no evidence of learning)`;
  } else switch (s.status) {
    case "fading":
      hint = s.recall < 0.3 ? " → probably forgotten: a brief re-teach followed by letting them try beats a bare quiz" : " → likely fading: a quick check is more useful than a full re-explanation";
      break;
    case "demonstrated":
      hint = " → do not re-teach from scratch unless they ask";
      break;
    case "struggling":
      hint = " → last attempt failed; a different route than before may help";
      break;
    case "claimed":
      hint = " → verify lightly before building on it";
      break;
    case "explained":
      hint = " → explained but never shown unaided";
      break;
  }
  const mis = s.misconceptions.length ? ` Misconception seen: ${s.misconceptions.join("; ")}.` : "";
  return `- ${s.skill} [${s.status}]: ${parts.join(", ")}${hint}.${mis}`;
}

function beliefLine(b: StyleBelief): string | null {
  if (b.status === "retired") return null;
  const how: string[] = [];
  if (b.statedValue !== null) how.push("stated");
  if (b.demonstratedValue !== null) how.push("observed");
  const tag = b.status === "candidate" ? "tentative" : b.status === "contested" ? "CONTESTED" : "active";
  if (b.tension) return `- ${b.dimension}: ${b.tension} (${tag}; ${b.n} observations over ${b.sessions} session${b.sessions === 1 ? "" : "s"})`;
  return `- ${b.dimension}: prefers ${describe(b.dimension, b.value)} (${tag}, ${how.join("+")}, confidence ${b.confidence}, ${b.n} obs.)`;
}

export function compileBrief(state: DerivedState, opts: { maxSkills?: number; lastSessionSummary?: string | null } = {}): string {
  const out: string[] = [];
  const maxSkills = opts.maxSkills ?? 12;

  if (state.evidenceCount === 0) {
    return "No prior evidence about this person yet. This is effectively a first meeting: observe rather than assume.";
  }

  out.push(`Evidence from ${state.sessionsSeen} session${state.sessionsSeen === 1 ? "" : "s"} (${state.evidenceCount} observations). Labels tell you how each item is known; weigh them, do not obey them.`);

  if (state.doNotAssume.length) {
    out.push("", "Do NOT assume (the person corrected this recently):");
    for (const d of state.doNotAssume) out.push(`- ${d}`);
  }

  if (state.facts.length) {
    out.push("", "About them (stated):");
    for (const f of state.facts.slice(0, 8)) out.push(`- ${f.key}: ${f.value}`);
  }

  const bl = state.beliefs.map(beliefLine).filter((x): x is string => !!x);
  if (bl.length) {
    out.push("", "How they work best with you:");
    out.push(...bl);
  }

  if (state.skills.length) {
    out.push("", "Skills / topics (recall estimates are a memory model, not a judgement):");
    const shown = state.skills.slice(0, maxSkills);
    for (const s of shown) out.push(skillLine(s));
    if (state.skills.length > maxSkills) out.push(`- …and ${state.skills.length - maxSkills} more (use recall_memory to look one up)`);
  }

  const ap = state.approaches.filter((a) => a.worked + a.didNotWork > 0);
  if (ap.length) {
    out.push("", "What has actually worked with this person (outcome judged on their next message):");
    for (const a of ap) out.push(`- ${a.approach.replace(/_/g, " ")}: ${a.worked} worked / ${a.didNotWork} did not (of ${a.tried})`);
  }

  if (opts.lastSessionSummary) out.push("", `Last session: ${opts.lastSessionSummary}`);

  return out.join("\n");
}

/**
 * Baseline "memory without lifecycle": the same extracted observations, but
 * written out flat — no derivation, no decay, no claimed/demonstrated
 * distinction, no correction guard. This is what "just store what the model
 * extracts" looks like, and it is what most memory products ship.
 */
export function compileFlatMemory(all: EvidenceItem[], max = 40): string {
  const items = all.filter((e) => !e.retractedAt).slice(-max);
  if (items.length === 0) return "No saved memories yet.";
  const lines = items.map((e) => {
    const p = e.payload;
    switch (p.kind) {
      case "skill":
        return `- ${p.event === "claimed" ? "Knows" : p.event === "explained" ? "Was taught" : p.event === "demonstrated" ? "Knows" : "Struggled with"} ${e.subject}${p.misconception ? ` (misconception: ${p.misconception})` : ""}`;
      case "style":
        return `- Prefers ${describe(p.dimension, p.value)}`;
      case "fact":
        return `- ${e.subject}: ${p.value}`;
      case "correction":
        return `- Correction noted about ${p.target}`;
      case "approach":
        return `- Used ${p.approach.replace(/_/g, " ")}${p.outcome ? ` (${p.outcome})` : ""}`;
      case "reaction":
        return `- Reaction: ${p.value > 0 ? "positive" : p.value < 0 ? "negative" : "neutral"}`;
    }
  });
  return `Saved memories about this user:\n${lines.join("\n")}`;
}
