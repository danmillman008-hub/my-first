/**
 * Core types of the compatibility layer.
 *
 * Everything the layer "knows" about a person is DERIVED from an append-only
 * list of `EvidenceItem`s. Nothing below `DerivedState` is ever persisted.
 */

export type SkillEvent = "claimed" | "explained" | "demonstrated" | "failed";

export type StyleDimension =
  | "depth" // -1 = just the answer / brief, +1 = deep, thorough
  | "examples" // -1 = abstract / formal, +1 = concrete examples, traces, code
  | "checks" // -1 = dislikes being quizzed, +1 = wants to be checked / practise
  | "directness" // -1 = wants hints & discovery, +1 = wants direct answers
  | "pace"; // -1 = slow, step by step, +1 = fast, skip the basics

export const STYLE_DIMENSIONS: StyleDimension[] = ["depth", "examples", "checks", "directness", "pace"];

export type StyleBasis = "stated" | "demonstrated" | "reaction";

export type Approach =
  | "direct_answer"
  | "worked_example"
  | "conceptual_explanation"
  | "analogy"
  | "socratic_question"
  | "retrieval_check"
  | "exercise"
  | "debug_together"
  | "other";

export const APPROACHES: Approach[] = [
  "direct_answer",
  "worked_example",
  "conceptual_explanation",
  "analogy",
  "socratic_question",
  "retrieval_check",
  "exercise",
  "debug_together",
  "other",
];

export type Payload =
  | { kind: "skill"; event: SkillEvent; aided?: boolean; misconception?: string; note?: string }
  | { kind: "style"; dimension: StyleDimension; value: number; basis: StyleBasis; note?: string }
  | { kind: "fact"; key: string; value: string }
  | { kind: "correction"; target: string; note?: string } // target = 'style:depth' | 'skill:recursion' | 'fact:occupation'
  | { kind: "approach"; approach: Approach; skill?: string; outcome: "worked" | "did_not_work" | "unclear" | null }
  | { kind: "reaction"; value: -1 | 0 | 1; note?: string };

export interface EvidenceItem {
  id: number;
  learnerId: string;
  sessionId: string;
  messageId: number | null;
  kind: Payload["kind"];
  subject: string;
  payload: Payload;
  source: "reflection" | "tool" | "user" | "lab";
  createdAt: Date;
  retractedAt: Date | null;
}

export type NewEvidence = Omit<EvidenceItem, "id" | "createdAt" | "retractedAt"> & { createdAt?: Date };

// ---------------------------------------------------------------- derived ---

export type SkillStatus = "claimed" | "explained" | "demonstrated" | "fading" | "struggling";

export interface SkillState {
  skill: string;
  status: SkillStatus;
  recall: number; // estimated probability the person can do it unaided right now
  halfLifeDays: number;
  explained: number;
  demonstratedUnaided: number;
  demonstratedAided: number;
  failed: number;
  claimed: boolean;
  verifiedClaim: boolean; // claimed and then shown unaided without our teaching
  misconceptions: string[];
  lastEvent: SkillEvent;
  lastAt: Date;
  daysSince: number;
}

export type BeliefStatus = "candidate" | "active" | "contested" | "retired";

export interface StyleBelief {
  dimension: StyleDimension;
  value: number; // -1..1
  confidence: number; // 0..0.92
  status: BeliefStatus;
  statedValue: number | null;
  demonstratedValue: number | null;
  tension: string | null;
  sessions: number;
  n: number;
  guardUntil: Date | null;
  lastAt: Date;
}

export interface FactState {
  key: string;
  value: string;
  at: Date;
  evidenceId: number;
}

export interface ApproachStat {
  approach: Approach;
  tried: number;
  worked: number;
  didNotWork: number;
}

export interface DerivedState {
  skills: SkillState[];
  beliefs: StyleBelief[];
  facts: FactState[];
  approaches: ApproachStat[];
  doNotAssume: string[]; // recent corrections inside the guard window
  pendingApproachId: number | null; // approach from the previous assistant turn whose outcome is still open
  sessionsSeen: number;
  evidenceCount: number;
}

// ------------------------------------------------------------- reflection ---

export interface Reflection {
  skills: { name: string; event: SkillEvent; aided?: boolean; misconception?: string }[];
  style: { dimension: StyleDimension; value: number; basis: StyleBasis; note?: string }[];
  facts: { key: string; value: string }[];
  corrections: { target: string; note?: string }[];
  reaction: -1 | 0 | 1;
  previousApproachOutcome: "worked" | "did_not_work" | "unclear" | null;
  approachUsed: Approach | null;
  approachSkill?: string;
  sessionTitle?: string;
}

// -------------------------------------------------------------- run modes ---

/** What the model is told about the past. `layer` is the product. */
export type Condition = "none" | "transcript" | "flat_memory" | "layer";

export interface TurnTrace {
  condition: Condition;
  model: string;
  brief: string;
  briefTokens: number;
  promptChars: number;
  toolCalls: { name: string; args: unknown; result: string }[];
  reflection: Reflection | null;
  evidenceAdded: number;
  mockAction?: string; // offline model only: what it decided to do
  ms: number;
}
