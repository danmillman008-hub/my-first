import {
  APPROACHES,
  STYLE_DIMENSIONS,
  type Approach,
  type ApproachStat,
  type DerivedState,
  type EvidenceItem,
  type FactState,
  type SkillEvent,
  type SkillState,
  type StyleBelief,
  type StyleDimension,
} from "./types";

/**
 * Pure derivation: evidence -> state. No I/O, deterministic for a given `now`.
 *
 * Semantics carried over from the archive because they were measured to matter
 * (see docs/FORENSICS.md): claimed != demonstrated != explained; aided != unaided;
 * spaced != massed; corrections retire a belief AND guard against immediate
 * re-derivation; inferred beliefs need more than one session before they are
 * acted on; confidence is capped so nothing becomes unquestionable.
 */

export const DAY = 86_400_000;
export const CORRECTION_GUARD_DAYS = 14;
export const CONFIDENCE_CAP = 0.92;
export const FADING_THRESHOLD = 0.6;

const clamp = (x: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, x));
const days = (a: Date, b: Date) => Math.max(0, (b.getTime() - a.getTime()) / DAY);

export function slugify(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9+#.]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

export function deriveState(all: EvidenceItem[], now: Date = new Date()): DerivedState {
  const items = all
    .filter((e) => !e.retractedAt)
    .slice()
    .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime() || a.id - b.id);

  const sessions = new Set(items.map((e) => e.sessionId));

  // ---- corrections (need them first: they retire beliefs / reset skills) ----
  const corrections = items.filter((e) => e.payload.kind === "correction");
  const guardFor = (target: string): Date | null => {
    let latest: Date | null = null;
    for (const c of corrections) {
      if (c.payload.kind !== "correction" || c.payload.target !== target) continue;
      const until = new Date(c.createdAt.getTime() + CORRECTION_GUARD_DAYS * DAY);
      if (until > now && (!latest || until > latest)) latest = until;
    }
    return latest;
  };
  const lastCorrectionAt = (target: string): Date | null => {
    let at: Date | null = null;
    for (const c of corrections) {
      if (c.payload.kind === "correction" && c.payload.target === target && (!at || c.createdAt > at)) at = c.createdAt;
    }
    return at;
  };

  // ------------------------------------------------------------- skills ----
  const bySkill = new Map<string, EvidenceItem[]>();
  for (const e of items) {
    if (e.payload.kind !== "skill") continue;
    const cut = lastCorrectionAt(`skill:${e.subject}`);
    if (cut && e.createdAt <= cut) continue; // a correction wipes earlier skill evidence
    const arr = bySkill.get(e.subject) ?? [];
    arr.push(e);
    bySkill.set(e.subject, arr);
  }

  const skills: SkillState[] = [];
  for (const [skill, evs] of bySkill) {
    let p = 0; // recall right after the last event
    let hl = 1; // half-life in days
    let explained = 0,
      dU = 0,
      dA = 0,
      failed = 0;
    let claimed = false,
      verifiedClaim = false;
    const misconceptions: string[] = [];
    let lastAt = evs[0].createdAt;
    let lastEvent: SkillEvent = evs[0].payload.kind === "skill" ? evs[0].payload.event : "claimed";
    let touched = false;
    let consecutiveFails = 0;

    for (const e of evs) {
      if (e.payload.kind !== "skill") continue;
      const gap = days(lastAt, e.createdAt);
      // decay to the moment of this event
      if (touched) p = p * Math.pow(2, -gap / hl);
      const ev = e.payload.event;
      switch (ev) {
        case "claimed":
          claimed = true;
          if (!touched) {
            p = 0.6;
            hl = 7; // an unverified claim: moderate prior, decays
          }
          break;
        case "explained":
          explained++;
          p = touched ? Math.max(p, 0.7) : 0.7;
          hl = Math.max(hl, 1) * (explained > 1 ? 1.3 : 1);
          break;
        case "demonstrated":
          if (e.payload.aided) {
            dA++;
            p = Math.max(p, 0.8);
            hl = hl * 1.2;
          } else {
            dU++;
            if (claimed && explained === 0 && dU === 1) {
              verifiedClaim = true; // they had it before us: stable prior knowledge
              p = 0.9;
              hl = Math.max(hl, 14);
            } else {
              p = 0.95;
              hl = hl * (gap >= 1 ? 2.5 : 1.25); // spaced retrieval strengthens far more than massed
            }
          }
          break;
        case "failed":
          failed++;
          consecutiveFails++;
          if (dU + (verifiedClaim ? 1 : 0) >= 2 && consecutiveFails === 1) {
            // one slip after repeated unaided success: lower the estimate, do not reset it
            p = Math.min(p, 0.65);
            hl = Math.max(1, hl * 0.7);
          } else {
            p = 0.35;
            hl = Math.max(0.5, hl * 0.6);
          }
          if (e.payload.misconception) misconceptions.push(e.payload.misconception);
          break;
      }
      if (ev !== "failed") consecutiveFails = 0;
      touched = true;
      lastAt = e.createdAt;
      lastEvent = ev;
    }
    const since = days(lastAt, now);
    const recall = clamp(p * Math.pow(2, -since / hl), 0, 1);

    let status: SkillState["status"];
    const solid = dU + (verifiedClaim ? 1 : 0) >= 2;
    if (lastEvent === "failed" && (consecutiveFails >= 2 || !solid)) status = "struggling";
    else if (dU > 0 || verifiedClaim) status = recall < FADING_THRESHOLD ? "fading" : "demonstrated";
    else if (explained > 0 || dA > 0) status = recall < FADING_THRESHOLD ? "fading" : "explained";
    else status = "claimed";

    skills.push({
      skill,
      status,
      recall: Math.round(recall * 100) / 100,
      halfLifeDays: Math.round(hl * 10) / 10,
      explained,
      demonstratedUnaided: dU,
      demonstratedAided: dA,
      failed,
      claimed,
      verifiedClaim,
      misconceptions: [...new Set(misconceptions)].slice(-3),
      lastEvent,
      lastAt,
      daysSince: Math.round(since * 10) / 10,
    });
  }
  skills.sort((a, b) => b.lastAt.getTime() - a.lastAt.getTime());

  // ----------------------------------------------------------- beliefs ----
  const beliefs: StyleBelief[] = [];
  for (const dim of STYLE_DIMENSIONS) {
    const target = `style:${dim}`;
    const cut = lastCorrectionAt(target);
    const guardUntil = guardFor(target);
    const evs = items.filter(
      (e) =>
        e.payload.kind === "style" &&
        e.subject === dim &&
        (!cut || e.createdAt > cut) &&
        // inside the guard window only what they SAY counts; reactions/inferences may not re-create a corrected belief
        (!guardUntil || e.createdAt >= guardUntil || e.payload.basis === "stated"),
    );
    if (evs.length === 0 && !guardUntil) continue;

    let wsum = 0,
      vsum = 0;
    let sSum = 0,
      sW = 0,
      dSum = 0,
      dW = 0;
    const sess = new Set<string>();
    let lastAt = now;
    for (const e of evs) {
      if (e.payload.kind !== "style") continue;
      const age = days(e.createdAt, now);
      const recency = Math.pow(0.5, age / 45); // 45-day half-life on style evidence
      const w = (e.payload.basis === "demonstrated" ? 1.0 : e.payload.basis === "stated" ? 0.6 : 0.25) * recency;
      wsum += w;
      vsum += w * e.payload.value;
      if (e.payload.basis === "stated") {
        sSum += recency * e.payload.value;
        sW += recency;
      } else if (e.payload.basis === "demonstrated") {
        dSum += recency * e.payload.value;
        dW += recency;
      }
      sess.add(e.sessionId);
      lastAt = e.createdAt;
    }
    const value = wsum > 0 ? clamp(vsum / wsum, -1, 1) : 0;
    const statedValue = sW > 0 ? sSum / sW : null;
    const demonstratedValue = dW > 0 ? dSum / dW : null;
    // confidence grows with weighted evidence mass and shrinks with disagreement
    const spread =
      statedValue !== null && demonstratedValue !== null ? Math.abs(statedValue - demonstratedValue) / 2 : 0;
    const confidence = clamp((1 - Math.exp(-wsum / 1.5)) * (1 - spread) * Math.abs(value), 0, CONFIDENCE_CAP);

    let tension: string | null = null;
    if (statedValue !== null && demonstratedValue !== null && Math.sign(statedValue) !== Math.sign(demonstratedValue) && Math.abs(statedValue - demonstratedValue) > 0.6) {
      tension = `says ${describe(dim, statedValue)} but responds better to ${describe(dim, demonstratedValue)}`;
    }

    let status: StyleBelief["status"];
    if (guardUntil && evs.length === 0) status = "retired";
    else if (tension) status = "contested";
    else if (Math.abs(value) < 0.2 || confidence < 0.25) status = "candidate";
    else if (sess.size < 2 && !(statedValue !== null && sW > 0)) status = "candidate"; // inferred needs 2 sessions; stated may act at once
    else status = "active";

    beliefs.push({
      dimension: dim,
      value: Math.round(value * 100) / 100,
      confidence: Math.round(confidence * 100) / 100,
      status,
      statedValue: statedValue === null ? null : Math.round(statedValue * 100) / 100,
      demonstratedValue: demonstratedValue === null ? null : Math.round(demonstratedValue * 100) / 100,
      tension,
      sessions: sess.size,
      n: evs.length,
      guardUntil,
      lastAt,
    });
  }

  // -------------------------------------------------------------- facts ----
  const facts: FactState[] = [];
  const factMap = new Map<string, FactState>();
  for (const e of items) {
    if (e.payload.kind !== "fact") continue;
    const cut = lastCorrectionAt(`fact:${e.subject}`);
    if (cut && e.createdAt <= cut) continue;
    factMap.set(e.subject, { key: e.subject, value: e.payload.value, at: e.createdAt, evidenceId: e.id });
  }
  for (const f of factMap.values()) facts.push(f);
  facts.sort((a, b) => b.at.getTime() - a.at.getTime());

  // --------------------------------------------------------- approaches ----
  const stats = new Map<Approach, ApproachStat>();
  let pendingApproachId: number | null = null;
  for (const e of items) {
    if (e.payload.kind !== "approach") continue;
    const s = stats.get(e.payload.approach) ?? { approach: e.payload.approach, tried: 0, worked: 0, didNotWork: 0 };
    s.tried++;
    if (e.payload.outcome === "worked") s.worked++;
    if (e.payload.outcome === "did_not_work") s.didNotWork++;
    stats.set(e.payload.approach, s);
    if (e.payload.outcome === null) pendingApproachId = e.id; // latest open one
  }
  const approaches = APPROACHES.map((a) => stats.get(a)).filter((s): s is ApproachStat => !!s && s.tried > 0);

  // ------------------------------------------------------- do-not-assume ----
  const doNotAssume: string[] = [];
  for (const c of corrections) {
    if (c.payload.kind !== "correction") continue;
    if (c.createdAt.getTime() + CORRECTION_GUARD_DAYS * DAY < now.getTime()) continue;
    doNotAssume.push(c.payload.note ? `${humanTarget(c.payload.target)} — ${c.payload.note}` : humanTarget(c.payload.target));
  }

  return {
    skills,
    beliefs,
    facts,
    approaches,
    doNotAssume: [...new Set(doNotAssume)].slice(-5),
    pendingApproachId,
    sessionsSeen: sessions.size,
    evidenceCount: items.length,
  };
}

export function describe(dim: StyleDimension, v: number): string {
  const hi = v > 0;
  switch (dim) {
    case "depth":
      return hi ? "thorough, in-depth explanations" : "brief answers without much elaboration";
    case "examples":
      return hi ? "concrete examples, traces and code" : "abstract / formal explanations";
    case "checks":
      return hi ? "being checked and given practice" : "not being quizzed";
    case "directness":
      return hi ? "direct answers" : "hints and working it out themselves";
    case "pace":
      return hi ? "a fast pace that skips basics" : "a slow, step-by-step pace";
  }
}

export function humanTarget(target: string): string {
  const [kind, ...rest] = target.split(":");
  const name = rest.join(":");
  if (kind === "style") return `the earlier belief about ${name} preference`;
  if (kind === "skill") return `earlier evidence about "${name}"`;
  if (kind === "fact") return `the earlier fact "${name}"`;
  return target;
}
