import { slugify } from "./model";
import { APPROACHES, STYLE_DIMENSIONS, type Approach, type NewEvidence, type Reflection, type StyleBasis, type StyleDimension } from "./types";

/**
 * Reflection = the model reads the exchange and extracts evidence as JSON.
 * The application validates, clamps and books it. The model reads; the layer
 * keeps the books. (Archive lesson: regex "perception" was the main bug source;
 * fully model-managed notes had no lifecycle.)
 */

export const REFLECTION_SCHEMA = {
  type: "object",
  properties: {
    skills: {
      type: "array",
      description: "Concepts/skills the exchange produced evidence about.",
      items: {
        type: "object",
        properties: {
          name: { type: "string", description: "short canonical topic name, e.g. 'recursion', 'sql joins'" },
          event: {
            type: "string",
            enum: ["claimed", "explained", "demonstrated", "failed"],
            description:
              "claimed = person says they know it; explained = assistant taught it; demonstrated = person correctly applied/answered it; failed = person attempted and got it wrong",
          },
          aided: { type: "boolean", description: "for demonstrated: true if hints/answer were visible" },
          misconception: { type: "string", description: "for failed: the specific wrong idea, if identifiable" },
        },
        required: ["name", "event"],
      },
    },
    style: {
      type: "array",
      description: "Evidence about how this person works with you. Only include when the exchange actually shows it.",
      items: {
        type: "object",
        properties: {
          dimension: { type: "string", enum: STYLE_DIMENSIONS },
          value: { type: "number", description: "-1..1, see dimension semantics" },
          basis: {
            type: "string",
            enum: ["stated", "demonstrated", "reaction"],
            description: "stated = they said so; demonstrated = their behaviour showed it worked/failed; reaction = a mild signal",
          },
          note: { type: "string" },
        },
        required: ["dimension", "value", "basis"],
      },
    },
    facts: {
      type: "array",
      description: "Durable facts the person stated about themselves (occupation, goal, language, tools). Not moods.",
      items: { type: "object", properties: { key: { type: "string" }, value: { type: "string" } }, required: ["key", "value"] },
    },
    corrections: {
      type: "array",
      description: "The person explicitly said an earlier assumption about them is wrong.",
      items: {
        type: "object",
        properties: {
          target: { type: "string", description: "'style:<dimension>' | 'skill:<name>' | 'fact:<key>'" },
          note: { type: "string" },
        },
        required: ["target"],
      },
    },
    reaction: { type: "integer", description: "the person's reaction to the PREVIOUS assistant message: -1 negative, 0 neutral, 1 positive" },
    previous_approach_outcome: {
      type: "string",
      enum: ["worked", "did_not_work", "unclear"],
      description: "Did the previous assistant approach work, judged by this user message (understanding shown, not politeness)?",
    },
    approach_used: { type: "string", enum: APPROACHES, description: "main approach of the assistant's reply just given" },
    approach_skill: { type: "string" },
    session_title: { type: "string", description: "3-6 word title for this conversation" },
  },
  required: ["skills", "style", "facts", "corrections", "reaction", "approach_used"],
} as const;

const clamp = (x: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, x));

export function validateReflection(raw: any): Reflection {
  const r: Reflection = {
    skills: [],
    style: [],
    facts: [],
    corrections: [],
    reaction: 0,
    previousApproachOutcome: null,
    approachUsed: null,
  };
  if (!raw || typeof raw !== "object") return r;
  const seenSkills = new Set<string>();
  for (const s of Array.isArray(raw.skills) ? raw.skills : []) {
    if (!s || typeof s.name !== "string" || !["claimed", "explained", "demonstrated", "failed"].includes(s.event)) continue;
    const name = slugify(s.name);
    if (!name || name.length < 2) continue;
    const key = `${name}:${s.event}`;
    if (seenSkills.has(key)) continue;
    seenSkills.add(key);
    r.skills.push({
      name,
      event: s.event,
      aided: s.event === "demonstrated" ? !!s.aided : undefined,
      misconception: typeof s.misconception === "string" && s.misconception.trim() ? s.misconception.trim().slice(0, 140) : undefined,
    });
    if (r.skills.length >= 8) break;
  }
  const seenDims = new Set<string>();
  for (const s of Array.isArray(raw.style) ? raw.style : []) {
    if (!s || !STYLE_DIMENSIONS.includes(s.dimension) || typeof s.value !== "number" || !Number.isFinite(s.value)) continue;
    const basis: StyleBasis = ["stated", "demonstrated", "reaction"].includes(s.basis) ? s.basis : "reaction";
    const k = `${s.dimension}:${basis}`;
    if (seenDims.has(k)) continue;
    seenDims.add(k);
    r.style.push({ dimension: s.dimension as StyleDimension, value: clamp(s.value, -1, 1), basis, note: typeof s.note === "string" ? s.note.slice(0, 140) : undefined });
  }
  for (const f of Array.isArray(raw.facts) ? raw.facts : []) {
    if (!f || typeof f.key !== "string" || typeof f.value !== "string") continue;
    const key = slugify(f.key);
    if (!key || !f.value.trim()) continue;
    r.facts.push({ key, value: f.value.trim().slice(0, 200) });
    if (r.facts.length >= 6) break;
  }
  for (const c of Array.isArray(raw.corrections) ? raw.corrections : []) {
    if (!c || typeof c.target !== "string") continue;
    const m = /^(style|skill|fact):(.+)$/.exec(c.target.trim());
    if (!m) continue;
    const kind = m[1];
    const name = kind === "style" ? m[2].trim() : slugify(m[2]);
    if (kind === "style" && !STYLE_DIMENSIONS.includes(name as StyleDimension)) continue;
    r.corrections.push({ target: `${kind}:${name}`, note: typeof c.note === "string" ? c.note.slice(0, 140) : undefined });
  }
  const rx = Number(raw.reaction);
  r.reaction = rx > 0 ? 1 : rx < 0 ? -1 : 0;
  r.previousApproachOutcome = ["worked", "did_not_work", "unclear"].includes(raw.previous_approach_outcome) ? raw.previous_approach_outcome : null;
  r.approachUsed = APPROACHES.includes(raw.approach_used) ? (raw.approach_used as Approach) : null;
  r.approachSkill = typeof raw.approach_skill === "string" ? slugify(raw.approach_skill) : undefined;
  r.sessionTitle = typeof raw.session_title === "string" && raw.session_title.trim() ? raw.session_title.trim().slice(0, 60) : undefined;
  return r;
}

/** Turn a validated reflection into evidence rows (pure). */
export function reflectionToEvidence(
  r: Reflection,
  ctx: { learnerId: string; sessionId: string; messageId: number | null; source: NewEvidence["source"]; createdAt?: Date },
): NewEvidence[] {
  const base = { learnerId: ctx.learnerId, sessionId: ctx.sessionId, messageId: ctx.messageId, source: ctx.source, createdAt: ctx.createdAt };
  const out: NewEvidence[] = [];
  for (const c of r.corrections) out.push({ ...base, kind: "correction", subject: c.target, payload: { kind: "correction", target: c.target, note: c.note } });
  for (const s of r.skills) out.push({ ...base, kind: "skill", subject: s.name, payload: { kind: "skill", event: s.event, aided: s.aided, misconception: s.misconception } });
  for (const s of r.style) out.push({ ...base, kind: "style", subject: s.dimension, payload: { kind: "style", dimension: s.dimension, value: s.value, basis: s.basis, note: s.note } });
  for (const f of r.facts) out.push({ ...base, kind: "fact", subject: f.key, payload: { kind: "fact", key: f.key, value: f.value } });
  if (r.reaction !== 0) out.push({ ...base, kind: "reaction", subject: "reaction", payload: { kind: "reaction", value: r.reaction } });
  if (r.approachUsed) out.push({ ...base, kind: "approach", subject: r.approachUsed, payload: { kind: "approach", approach: r.approachUsed, skill: r.approachSkill, outcome: null } });
  return out;
}
