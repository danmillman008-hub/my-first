import {
  pgTable,
  text,
  timestamp,
  integer,
  serial,
  jsonb,
  index,
} from "drizzle-orm/pg-core";

/**
 * Storage is deliberately minimal: one relationship per learner, sessions and
 * messages for the conversation, and ONE append-only evidence log from which
 * every belief, skill estimate and fact is *derived* (never stored).
 *
 * Only two mutations are ever applied to evidence rows:
 *   - `retracted_at`  (the person or the model retracts an observation)
 *   - `payload.outcome` on `approach` rows (filled in by the following turn)
 */

export const learners = pgTable("learners", {
  id: text("id").primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    title: text("title").notNull().default("New conversation"),
    summary: text("summary"),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sessions_learner_idx").on(t.learnerId)],
);

export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    sessionId: text("session_id").notNull(),
    learnerId: text("learner_id").notNull(),
    role: text("role").notNull(), // 'user' | 'assistant'
    content: text("content").notNull(),
    trace: jsonb("trace"), // TurnTrace for assistant messages (why this turn)
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("messages_session_idx").on(t.sessionId), index("messages_learner_idx").on(t.learnerId)],
);

export const evidence = pgTable(
  "evidence",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id").notNull(),
    messageId: integer("message_id"),
    kind: text("kind").notNull(), // 'skill' | 'style' | 'fact' | 'correction' | 'approach' | 'reaction'
    subject: text("subject").notNull(), // skill slug | style dimension | fact key | correction target | approach name
    payload: jsonb("payload").notNull(),
    source: text("source").notNull().default("reflection"), // 'reflection' | 'tool' | 'user' | 'lab'
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    retractedAt: timestamp("retracted_at", { withTimezone: true }),
  },
  (t) => [index("evidence_learner_idx").on(t.learnerId), index("evidence_subject_idx").on(t.learnerId, t.subject)],
);
