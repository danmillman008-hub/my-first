"use client";

import { useState } from "react";
import type { MemoryView } from "./Chat";

const pct = (x: number) => `${Math.round(x * 100)}%`;

export function MemoryPanel({ memory, onChange }: { memory: MemoryView | null; onChange: () => void }) {
  const [tab, setTab] = useState<"beliefs" | "brief" | "evidence">("beliefs");
  if (!memory) return <p className="p-4 text-sm text-slate-500">Loading…</p>;
  const { state, brief, evidence } = memory;

  const correct = async (target: string, note?: string) => {
    await fetch("/api/memory", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ target, note }) });
    onChange();
  };
  const retract = async (id: number) => {
    await fetch(`/api/memory/${id}`, { method: "DELETE" });
    onChange();
  };
  const eraseAll = async () => {
    if (!confirm("Erase everything the assistant has learned about you, including all conversations?")) return;
    await fetch("/api/memory", { method: "DELETE" });
    onChange();
    location.reload();
  };

  return (
    <div className="p-4 text-sm">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-semibold">What it knows about you</h2>
        <button onClick={eraseAll} className="text-xs text-rose-600 hover:underline">
          erase all
        </button>
      </div>
      <p className="mb-3 text-xs text-slate-500">
        Everything below is <em>derived</em> from {state.evidenceCount} observations across {state.sessionsSeen} session{state.sessionsSeen === 1 ? "" : "s"}. Nothing is a permanent truth: mark anything as “not true” and it is retired and not re-inferred for 14 days.
      </p>
      <div className="mb-3 flex gap-1 text-xs">
        {(["beliefs", "brief", "evidence"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`rounded-md px-2 py-1 ${tab === t ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-600"}`}>
            {t === "beliefs" ? "beliefs & skills" : t === "brief" ? "exact brief" : "raw evidence"}
          </button>
        ))}
      </div>

      {tab === "beliefs" && (
        <div className="space-y-4">
          {state.doNotAssume.length > 0 && (
            <section>
              <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-rose-600">Do not assume (corrected)</h3>
              <ul className="space-y-1 text-xs text-slate-600">
                {state.doNotAssume.map((d, i) => (
                  <li key={i}>• {d}</li>
                ))}
              </ul>
            </section>
          )}
          <section>
            <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-500">How you work best</h3>
            {state.beliefs.filter((b) => b.status !== "retired").length === 0 && <p className="text-xs text-slate-400">Nothing inferred yet.</p>}
            <ul className="space-y-2">
              {state.beliefs
                .filter((b) => b.status !== "retired")
                .map((b) => (
                  <li key={b.dimension} className="rounded-lg border border-slate-200 p-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{b.dimension}</span>
                      <span className={`rounded px-1.5 py-0.5 text-[10px] uppercase ${b.status === "active" ? "bg-emerald-100 text-emerald-700" : b.status === "contested" ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-500"}`}>{b.status}</span>
                    </div>
                    <div className="mt-1 h-1.5 w-full rounded bg-slate-100">
                      <div className="h-1.5 rounded bg-slate-700" style={{ marginLeft: `${50 + Math.min(0, b.value) * 50}%`, width: `${Math.abs(b.value) * 50}%` }} />
                    </div>
                    <p className="mt-1 text-[11px] text-slate-500">
                      value {b.value} · confidence {b.confidence} · {b.n} obs. / {b.sessions} session{b.sessions === 1 ? "" : "s"}
                      {b.statedValue !== null && ` · stated ${b.statedValue}`}
                      {b.demonstratedValue !== null && ` · observed ${b.demonstratedValue}`}
                    </p>
                    {b.tension && <p className="mt-1 text-[11px] text-amber-700">tension: {b.tension}</p>}
                    <button onClick={() => correct(`style:${b.dimension}`, "marked not true by the person")} className="mt-1 text-[11px] text-rose-600 hover:underline">
                      not true
                    </button>
                  </li>
                ))}
            </ul>
          </section>
          <section>
            <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-500">Skills & topics</h3>
            {state.skills.length === 0 && <p className="text-xs text-slate-400">No topics yet.</p>}
            <ul className="space-y-1">
              {state.skills.map((s) => (
                <li key={s.skill} className="flex items-start justify-between gap-2 rounded-lg border border-slate-200 p-2 text-xs">
                  <div>
                    <span className="font-medium">{s.skill}</span> <span className="text-slate-400">[{s.status}]</span>
                    <div className="text-[11px] text-slate-500">
                      recall {pct(s.recall)} · half-life {s.halfLifeDays}d · explained {s.explained}× · shown {s.demonstratedUnaided}× · missed {s.failed}× · {s.daysSince}d ago
                    </div>
                    {s.misconceptions.length > 0 && <div className="text-[11px] text-amber-700">misconception: {s.misconceptions.join("; ")}</div>}
                  </div>
                  <button onClick={() => correct(`skill:${s.skill}`, "reset by the person")} className="shrink-0 text-[11px] text-rose-600 hover:underline">
                    reset
                  </button>
                </li>
              ))}
            </ul>
          </section>
          {state.facts.length > 0 && (
            <section>
              <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-500">About you (stated)</h3>
              <ul className="space-y-1 text-xs">
                {state.facts.map((f) => (
                  <li key={f.key} className="flex justify-between gap-2">
                    <span>
                      <span className="text-slate-500">{f.key}:</span> {f.value}
                    </span>
                    <button onClick={() => retract(f.evidenceId)} className="text-[11px] text-rose-600 hover:underline">
                      no longer true
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          )}
          {state.approaches.length > 0 && (
            <section>
              <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-500">What has worked (the AI&apos;s own record)</h3>
              <ul className="text-xs text-slate-600">
                {state.approaches.map((a) => (
                  <li key={a.approach}>
                    {a.approach.replace(/_/g, " ")}: {a.worked} worked / {a.didNotWork} did not (of {a.tried})
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
      )}

      {tab === "brief" && (
        <div>
          <p className="mb-2 text-xs text-slate-500">This is the exact text the model receives about you on the next turn.</p>
          <pre className="whitespace-pre-wrap rounded-lg bg-slate-50 p-3 font-mono text-[11px] text-slate-700">{brief}</pre>
        </div>
      )}

      {tab === "evidence" && (
        <ul className="space-y-1">
          {evidence.length === 0 && <p className="text-xs text-slate-400">No evidence yet.</p>}
          {evidence.map((e) => (
            <li key={e.id} className={`flex items-start justify-between gap-2 rounded-md border border-slate-100 p-2 text-[11px] ${e.retractedAt ? "opacity-40 line-through" : ""}`}>
              <div>
                <span className="rounded bg-slate-100 px-1 text-[10px] uppercase">{e.kind}</span> <b>{e.subject}</b> <span className="text-slate-500">{JSON.stringify(e.payload)}</span>
                <div className="text-slate-400">
                  {new Date(e.createdAt).toLocaleString()} · {e.source}
                </div>
              </div>
              {!e.retractedAt && (
                <button onClick={() => retract(e.id)} className="shrink-0 text-rose-600 hover:underline">
                  delete
                </button>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
