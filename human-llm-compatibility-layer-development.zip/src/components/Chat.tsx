"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import type { Condition, DerivedState, EvidenceItem, TurnTrace } from "@/lib/core/types";
import { MemoryPanel } from "./MemoryPanel";

interface Msg {
  id?: number;
  role: "user" | "assistant";
  content: string;
  trace?: TurnTrace | null;
  tools?: { name: string; args: unknown }[];
  streaming?: boolean;
}
interface SessionRow {
  id: string;
  title: string;
  lastActiveAt: string;
}
export interface MemoryView {
  state: DerivedState;
  brief: string;
  evidence: EvidenceItem[];
}

const uuid = () => (typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`);

export default function Chat() {
  const [status, setStatus] = useState<{ live: boolean; provider: string; model: string } | null>(null);
  const [sessions, setSessions] = useState<SessionRow[]>([]);
  const [sessionId, setSessionId] = useState<string>(() => uuid());
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [showMemory, setShowMemory] = useState(false);
  const [memory, setMemory] = useState<MemoryView | null>(null);
  const [condition, setCondition] = useState<Condition>("layer");
  const [openTrace, setOpenTrace] = useState<number | null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const textarea = useRef<HTMLTextAreaElement>(null);

  const loadSessions = useCallback(async () => {
    const r = await fetch("/api/sessions");
    if (r.ok) setSessions((await r.json()).sessions);
  }, []);
  const loadMemory = useCallback(async () => {
    const r = await fetch("/api/memory");
    if (r.ok) setMemory(await r.json());
  }, []);

  useEffect(() => {
    fetch("/api/status").then((r) => r.json()).then(setStatus).catch(() => null);
    loadSessions();
    loadMemory();
  }, [loadSessions, loadMemory]);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs]);

  const openSession = async (id: string) => {
    const r = await fetch(`/api/sessions/${id}`);
    if (!r.ok) return;
    const data = await r.json();
    setSessionId(id);
    setMsgs(data.messages.map((m: Msg) => ({ id: m.id, role: m.role, content: m.content, trace: m.trace })));
    setOpenTrace(null);
  };

  const newChat = () => {
    setSessionId(uuid());
    setMsgs([]);
    setOpenTrace(null);
    textarea.current?.focus();
  };

  const send = async () => {
    const message = input.trim();
    if (!message || busy) return;
    setInput("");
    setBusy(true);
    setMsgs((m) => [...m, { role: "user", content: message }, { role: "assistant", content: "", streaming: true, tools: [] }]);
    try {
      const res = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ message, sessionId, condition }) });
      if (!res.ok || !res.body) throw new Error(`request failed (${res.status})`);
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i: number;
        while ((i = buf.indexOf("\n\n")) >= 0) {
          const line = buf.slice(0, i).trim();
          buf = buf.slice(i + 2);
          if (!line.startsWith("data:")) continue;
          const ev = JSON.parse(line.slice(5));
          setMsgs((m) => {
            const copy = m.slice();
            const last = { ...copy[copy.length - 1] };
            if (ev.type === "text") last.content += ev.text;
            else if (ev.type === "tool") last.tools = [...(last.tools ?? []), { name: ev.name, args: ev.args }];
            else if (ev.type === "trace") {
              last.trace = ev.trace;
              last.id = ev.messageId;
              last.streaming = false;
            } else if (ev.type === "error") last.content += `\n\n_(${ev.message})_`;
            copy[copy.length - 1] = last;
            return copy;
          });
        }
      }
    } catch (err) {
      setMsgs((m) => {
        const copy = m.slice();
        copy[copy.length - 1] = { role: "assistant", content: `_(${err instanceof Error ? err.message : "error"})_` };
        return copy;
      });
    } finally {
      setBusy(false);
      loadSessions();
      loadMemory();
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 text-slate-900">
      {/* sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-200 bg-white md:flex">
        <div className="p-4">
          <button onClick={newChat} className="w-full rounded-xl bg-slate-900 px-3 py-2 text-sm font-medium text-white hover:bg-slate-700">
            + New conversation
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto px-2">
          {sessions.map((s) => (
            <button
              key={s.id}
              onClick={() => openSession(s.id)}
              className={`mb-1 block w-full truncate rounded-lg px-3 py-2 text-left text-sm hover:bg-slate-100 ${s.id === sessionId ? "bg-slate-100 font-medium" : "text-slate-700"}`}
              title={s.title}
            >
              {s.title}
            </button>
          ))}
          {sessions.length === 0 && <p className="px-3 py-2 text-xs text-slate-400">No conversations yet.</p>}
        </nav>
        <div className="border-t border-slate-200 p-3 text-xs text-slate-500">
          <div className="mb-2 flex items-center gap-2">
            <span className={`inline-block h-2 w-2 rounded-full ${status?.live ? "bg-emerald-500" : "bg-amber-500"}`} />
            {status ? (status.live ? `Gemini · ${status.model}` : "Offline mock model") : "…"}
          </div>
          <label className="block">
            <span className="text-[11px] uppercase tracking-wide text-slate-400">Context mode (research)</span>
            <select value={condition} onChange={(e) => setCondition(e.target.value as Condition)} className="mt-1 w-full rounded-md border border-slate-200 bg-white px-2 py-1 text-xs">
              <option value="layer">layer — compatibility layer (product)</option>
              <option value="flat_memory">flat_memory — saved notes, no lifecycle</option>
              <option value="transcript">transcript — raw past chats</option>
              <option value="none">none — no memory</option>
            </select>
          </label>
        </div>
      </aside>

      {/* main */}
      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3">
          <div>
            <h1 className="text-base font-semibold">Assistant</h1>
            <p className="text-xs text-slate-500">Talk naturally. It learns how you learn — and you can see and correct everything it believes.</p>
          </div>
          <button onClick={() => setShowMemory((v) => !v)} className="rounded-lg border border-slate-200 px-3 py-1.5 text-sm hover:bg-slate-100">
            {showMemory ? "Hide" : "What it knows about you"}
            {memory && memory.state.evidenceCount > 0 && <span className="ml-2 rounded-full bg-slate-900 px-2 py-0.5 text-[10px] text-white">{memory.state.evidenceCount}</span>}
          </button>
        </header>

        {status && !status.live && (
          <div className="border-b border-amber-200 bg-amber-50 px-4 py-2 text-xs text-amber-800">
            No <code>GEMINI_API_KEY</code> configured — running the clearly-labelled offline mock so the memory layer can still be exercised. Set the key to use Gemini.
          </div>
        )}

        <div className="flex min-h-0 flex-1">
          <section className="flex min-w-0 flex-1 flex-col">
            <div className="flex-1 overflow-y-auto px-4 py-6">
              <div className="mx-auto max-w-3xl space-y-5">
                {msgs.length === 0 && (
                  <div className="rounded-2xl border border-dashed border-slate-300 p-6 text-sm text-slate-500">
                    <p className="font-medium text-slate-700">Try things like</p>
                    <ul className="mt-2 list-disc space-y-1 pl-5">
                      <li>“Teach me recursion” — then come back tomorrow and ask again.</li>
                      <li>“Just give me the answer, no explanation.”</li>
                      <li>“I already know SQL joins.” (it will verify lightly rather than trust or re-teach)</li>
                      <li>“Actually, stop giving me hints — I want direct answers.” (a correction; watch the memory panel)</li>
                      <li>“What did we talk about last time?”</li>
                    </ul>
                  </div>
                )}
                {msgs.map((m, i) => (
                  <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${m.role === "user" ? "bg-slate-900 text-white" : "bg-white shadow-sm ring-1 ring-slate-200"}`}>
                      {m.role === "assistant" ? (
                        <div className="prose prose-sm max-w-none prose-pre:bg-slate-900 prose-pre:text-slate-100">
                          {m.tools && m.tools.length > 0 && (
                            <p className="m-0 mb-1 text-[11px] text-slate-400">{m.tools.map((t) => `⚙ ${t.name}(${JSON.stringify(t.args).slice(0, 60)})`).join(" · ")}</p>
                          )}
                          {m.content ? <ReactMarkdown>{m.content}</ReactMarkdown> : m.streaming ? <span className="animate-pulse text-slate-400">…</span> : null}
                          {m.trace && (
                            <button onClick={() => setOpenTrace(openTrace === i ? null : i)} className="mt-2 text-[11px] text-slate-400 hover:text-slate-600">
                              {openTrace === i ? "hide" : "why this turn"} · {m.trace.evidenceAdded} new observation{m.trace.evidenceAdded === 1 ? "" : "s"} · {m.trace.briefTokens} brief tokens
                            </button>
                          )}
                          {openTrace === i && m.trace && <TraceView trace={m.trace} />}
                        </div>
                      ) : (
                        <p className="whitespace-pre-wrap">{m.content}</p>
                      )}
                    </div>
                  </div>
                ))}
                <div ref={bottom} />
              </div>
            </div>
            <div className="border-t border-slate-200 bg-white p-3">
              <div className="mx-auto flex max-w-3xl items-end gap-2">
                <textarea
                  ref={textarea}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      send();
                    }
                  }}
                  rows={2}
                  placeholder="Ask anything, or ask to be taught something…"
                  className="flex-1 resize-none rounded-xl border border-slate-300 px-3 py-2 text-sm focus:border-slate-500 focus:outline-none"
                />
                <button onClick={send} disabled={busy || !input.trim()} className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-40">
                  Send
                </button>
              </div>
            </div>
          </section>

          {showMemory && (
            <aside className="w-[380px] shrink-0 overflow-y-auto border-l border-slate-200 bg-white">
              <MemoryPanel memory={memory} onChange={loadMemory} />
            </aside>
          )}
        </div>
      </main>
    </div>
  );
}

function TraceView({ trace }: { trace: TurnTrace }) {
  return (
    <div className="mt-2 rounded-lg bg-slate-50 p-3 text-[11px] text-slate-600 not-prose">
      <p className="mb-1">
        <b>mode</b> {trace.condition} · <b>model</b> {trace.model} · <b>prompt</b> {trace.promptChars} chars · {trace.ms} ms{trace.mockAction ? ` · mock action ${trace.mockAction}` : ""}
      </p>
      <details>
        <summary className="cursor-pointer">Brief the model received</summary>
        <pre className="mt-1 whitespace-pre-wrap font-mono text-[10px]">{trace.brief || "(empty)"}</pre>
      </details>
      {trace.reflection && (
        <details className="mt-1">
          <summary className="cursor-pointer">What was noted from this exchange</summary>
          <pre className="mt-1 whitespace-pre-wrap font-mono text-[10px]">{JSON.stringify(trace.reflection, null, 1)}</pre>
        </details>
      )}
      {trace.toolCalls.length > 0 && (
        <details className="mt-1">
          <summary className="cursor-pointer">Tool calls</summary>
          <pre className="mt-1 whitespace-pre-wrap font-mono text-[10px]">{JSON.stringify(trace.toolCalls, null, 1)}</pre>
        </details>
      )}
    </div>
  );
}
