import { randomUUID } from "node:crypto";
import { runTurn } from "@/lib/agent/turn";
import type { Condition } from "@/lib/core/types";
import { getLearnerId } from "@/lib/identity";
import { getLLM } from "@/lib/llm";
import { getStore } from "@/lib/store";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

/** POST { message, sessionId?, condition? } → SSE stream of TurnEvents. */
export async function POST(req: Request) {
  const learnerId = (await getLearnerId())!;
  const body = (await req.json().catch(() => ({}))) as { message?: string; sessionId?: string; condition?: Condition };
  const message = (body.message ?? "").toString().trim();
  if (!message) return Response.json({ error: "message required" }, { status: 400 });
  const sessionId = body.sessionId && /^[a-zA-Z0-9-]{8,64}$/.test(body.sessionId) ? body.sessionId : randomUUID();
  const condition: Condition = ["none", "transcript", "flat_memory", "layer"].includes(body.condition ?? "") ? body.condition! : "layer";

  const store = getStore();
  const session = await store.getSession(sessionId);
  if (session && session.learnerId !== learnerId) return Response.json({ error: "not your session" }, { status: 403 });

  const enc = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: unknown) => controller.enqueue(enc.encode(`data: ${JSON.stringify(obj)}\n\n`));
      try {
        for await (const ev of runTurn({ store, llm: getLLM(), learnerId, sessionId, userMessage: message.slice(0, 8000), condition })) send(ev);
      } catch (err) {
        send({ type: "error", message: err instanceof Error ? err.message : String(err) });
      } finally {
        send({ type: "done" });
        controller.close();
      }
    },
  });
  return new Response(stream, { headers: { "content-type": "text/event-stream", "cache-control": "no-cache, no-transform", connection: "keep-alive" } });
}
