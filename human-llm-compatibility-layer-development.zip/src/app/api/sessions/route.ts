import { getLearnerId } from "@/lib/identity";
import { getStore } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET() {
  const learnerId = (await getLearnerId())!;
  const sessions = await getStore().listSessions(learnerId);
  return Response.json({ sessions });
}
