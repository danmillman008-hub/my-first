import { getLearnerId } from "@/lib/identity";
import { getStore } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const learnerId = (await getLearnerId())!;
  const store = getStore();
  const session = await store.getSession(id);
  if (!session || session.learnerId !== learnerId) return Response.json({ error: "not found" }, { status: 404 });
  const messages = await store.listMessages(id);
  return Response.json({ session, messages });
}
