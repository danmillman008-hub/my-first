import { compileBrief } from "@/lib/core/brief";
import { deriveState } from "@/lib/core/model";
import type { NewEvidence } from "@/lib/core/types";
import { getLearnerId } from "@/lib/identity";
import { getStore } from "@/lib/store";

export const dynamic = "force-dynamic";

/** GET → derived state + the exact brief + raw evidence (inspectability). */
export async function GET() {
  const learnerId = (await getLearnerId())!;
  const store = getStore();
  const evidence = await store.listEvidence(learnerId, true);
  const state = deriveState(evidence);
  const prior = (await store.listSessions(learnerId)).find((s) => s.summary);
  return Response.json({ learnerId, state, brief: compileBrief(state, { lastSessionSummary: prior?.summary ?? null }), evidence: evidence.slice(-200).reverse() });
}

/** POST { target, note? } → the person says a belief/skill/fact is wrong: retire + guard. */
export async function POST(req: Request) {
  const learnerId = (await getLearnerId())!;
  const body = (await req.json().catch(() => ({}))) as { target?: string; note?: string };
  const target = (body.target ?? "").trim();
  if (!/^(style|skill|fact):[a-z0-9+#.-]+$/.test(target)) return Response.json({ error: "bad target" }, { status: 400 });
  const store = getStore();
  const sessions = await store.listSessions(learnerId);
  const sessionId = sessions[0]?.id ?? "ui";
  if (!sessions[0]) await store.createSession(learnerId, sessionId);
  const row: NewEvidence = { learnerId, sessionId, messageId: null, kind: "correction", subject: target, payload: { kind: "correction", target, note: body.note?.slice(0, 140) }, source: "user" };
  await store.addEvidence([row]);
  return Response.json({ ok: true });
}

/** DELETE → erase the whole relationship. */
export async function DELETE() {
  const learnerId = (await getLearnerId())!;
  await getStore().deleteLearner(learnerId);
  return Response.json({ ok: true });
}
