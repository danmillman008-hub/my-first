import { getLearnerId } from "@/lib/identity";
import { getStore } from "@/lib/store";

export const dynamic = "force-dynamic";

/** DELETE → retract one evidence item. Everything derived from it disappears honestly. */
export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const learnerId = (await getLearnerId())!;
  const ok = await getStore().retractEvidence(learnerId, Number(id));
  return Response.json({ ok }, { status: ok ? 200 : 404 });
}
