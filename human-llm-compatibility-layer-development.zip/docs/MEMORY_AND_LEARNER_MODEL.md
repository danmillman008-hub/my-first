# Memory and learner model — specification

**Answer to the brief's open questions:** an explicit learner model *is not stored*; it is **derived on every read from an append-only evidence log** by a pure function, and presented to the model as a short, epistemically labelled brief. This is "persistent evidence + deterministic derivation + LLM-native reasoning".

## 1. Evidence (the only persisted memory)

Table `evidence` — append-only. Row: `learner_id, session_id, message_id, kind, subject, payload, source, created_at, retracted_at`.

| kind | subject | payload | produced by |
| --- | --- | --- | --- |
| `skill` | topic slug | `event ∈ claimed · explained · demonstrated · failed`, `aided?`, `misconception?` | reflection |
| `style` | dimension ∈ `depth · examples · checks · directness · pace` | `value ∈ [-1,1]`, `basis ∈ stated · demonstrated · reaction`, `note?` | reflection |
| `fact` | key | `value` | reflection, `remember` tool |
| `correction` | target `style:<dim>` / `skill:<slug>` / `fact:<key>` | `note?` | reflection, `forget` tool, UI button |
| `approach` | approach name | `skill?`, `outcome ∈ null · worked · did_not_work · unclear` | reflection (outcome filled by the *next* turn) |
| `reaction` | `reaction` | `value ∈ -1 · 0 · 1` | reflection |

Mutations allowed: `retracted_at` (person deletes / model `forget`s), `payload.outcome` on approach rows. Nothing else. Provenance = `message_id` + `source ∈ reflection · tool · user · lab`.

## 2. Derivation (`deriveState`, pure)

### Skills → `SkillState`
Per topic, replay events in order with exponential decay between them (`recall = p · 2^(−Δdays / halfLife)`):

| event | effect |
| --- | --- |
| `claimed` (first event) | p = 0.6, half-life 7 d, `claimed = true` |
| `explained` | p = max(p, 0.7); half-life ×1.3 from the second explanation |
| `demonstrated` aided | p = max(p, 0.8); half-life ×1.2 |
| `demonstrated` unaided | p = 0.95; half-life ×2.5 if ≥1 day since last event (spaced) else ×1.25. **If it was claimed and never explained by us** → `verifiedClaim`: p = 0.9, half-life ≥ 14 d (they had it before us). |
| `failed` | if ≥2 unaided successes (or verified claim) and it is the first consecutive failure: p = min(p, 0.65), half-life ×0.7 (a slip). Otherwise p = 0.35, half-life ×0.6 (min 0.5 d). Misconception text kept (last 3). |
| `correction skill:<x>` | all earlier events for x are discarded |

Status: `struggling` (last event failed and either two in a row or no solid history) · `demonstrated` / `fading` (unaided success exists; fading if recall < 0.6) · `explained` / `fading` (explained only) · `claimed`.

### Style beliefs → `StyleBelief`
Per dimension: recency-weighted mean (45-day half-life) with basis weights demonstrated 1.0 · stated 0.6 · reaction 0.25. `confidence = (1 − e^(−mass/1.5)) · (1 − disagreement) · |value|`, capped at **0.92**. Separate stated and demonstrated means; if they disagree in sign by > 0.6 the belief is **contested** with a `tension` sentence ("says X but responds better to Y") — surfaced, not resolved.

Lifecycle: `candidate` (weak, or inferred from only one session) → `active` (stated preferences act immediately; inferred ones need two sessions) → `contested` → `retired` (after a correction). **Guard:** for 14 days after a correction only *stated* evidence counts; reactions and inferences cannot re-create the belief. Retired beliefs appear in the brief as "Do NOT assume …".

### Facts
Latest value per key wins; a `correction fact:<key>` drops earlier values; the UI's "no longer true" retracts the row.

### Approaches (the AI's self-model)
Counts of tried / worked / did-not-work per approach. The latest row with `outcome = null` is `pendingApproachId`; it is filled on the next turn only if it belongs to the immediately previous assistant message. **Never converted into a belief.**

## 3. The brief (`compileBrief`)

≈250–320 tokens, sections in this order: header with session/observation counts and the instruction to weigh not obey → *Do NOT assume* → *About them (stated)* → *How they work best with you* (tagged tentative / active / CONTESTED, with stated+observed and confidence) → *Skills / topics* (≤12 most recent, each with status, counts, last seen, recall %, and a hint tied to the status) → *What has actually worked* → *Last session* one-liner. Empty history yields a one-line "first meeting" brief.

## 4. Lifecycle summary

| question from the brief | answer |
| --- | --- |
| what is persisted | evidence rows, messages, sessions |
| what stays transient | derived state, brief, prompts |
| what is inferred dynamically | everything about the person, on every turn, from valid evidence |
| what expires | recall (continuously); style evidence (45-day recency weighting); corrections' guard (14 days) |
| what is revisable | all of it: retraction, correction, new evidence; the person has buttons for each |
| what improves future interaction | measured in `docs/EVALUATION.md`: redundancy ↓, stale beliefs → 0, missed refresh → 0, context ≈ ⅓ of transcripts |

## 5. Evaluation of the memory itself

- Learner-model accuracy: MAE 0.08 against the lab's hidden recall (uncalibrated).
- Stale memory: 0/30 stale-preference violations (flat notes 12/30; transcripts 0/30 with a careful reader but at 2.6× tokens and 30 missed refreshes).
- Growth: brief < 500 tokens after 8 sessions × 4 topics (behaviour test), 316 tokens on average in the lab.
- Revisability: unit tests for retraction re-derivation, correction guard, contested beliefs, slip handling.

## 6. Known gaps / next steps

Per-learner calibration of the forgetting scale (archive: MAE 0.18→0.14); topic aliasing (`sql joins` vs `joins`) currently relies on the model's canonical naming plus slugging; embeddings for `recall_memory` if lexical search proves insufficient with real transcripts.
