# Research report

**Question.** How can an adaptive layer reduce the gap between one particular human and one particular LLM so that they work — and in particular *teach and learn* — better together over time, while preserving the freedom of both?

This document records what was investigated, what was run, what failed, what worked, and why the final direction was chosen. Numbers come from the laboratory in this repository (`npm run lab`, output in `lab/out/summary.md`) and from the previous generations' own recorded results.

## 1. Starting evidence: the archive

`danmillman008-hub/my-first` is not one project; it is an archive of **16 zipped generations** of the same mission (plus an unrelated driving game). `build-adaptive-learning-agent` — the "second repository" in the brief — is recoverable there as `build-adaptive-learning-agent.zip`; it was unpacked and read in full together with `adaptive-human-llm-compatibility-layer`, `human-ai-co-adaptation-research`, `synthesize-self-adapting-learning-agent` and `private-self-adapting-learning-agent (4)`. Full forensic analysis: [FORENSICS.md](./FORENSICS.md).

The archive splits into two lineages:

| lineage | generations | premise | what their own labs measured |
| --- | --- | --- | --- |
| **Deterministic controller** | ≈14 (`private-*`, `synthesize-*`, `build-adaptive-learning-agent`, graph/MCP variants) | The application decides pedagogy (BKT/half-life models, Thompson-sampling style bandits, affect engines, concept graphs, item banks); the LLM writes prose or is optional. | Style bandits ≈ 0 learning effect; affect engines ≈ 0; concept graphs never paid for themselves; the *epistemic* distinctions (claimed ≠ demonstrated, aided ≠ unaided, spaced ≠ massed, corrections need a guard, credit on the next turn) mattered every time they were measured. |
| **Model decides, layer informs** | 2 (`adaptive-human-llm-compatibility-layer`, `human-ai-co-adaptation-research`) | The model teaches freely; the layer keeps an evidence log, derives beliefs, compiles a short brief, reflects after each turn. | Raw-transcript memory fails on retraction (12/24 stale violations) and costs 3–12× the context; derived beliefs improve "fit" monotonically over 30 sessions while transcripts *degrade*; asking people about themselves creates false stated commitments (the "co-adaptation trap"). |

Both lineages agree on one thing neither could test: **no generation ever had an LLM key at build time.** Every number in the archive measures bookkeeping, not a model. That is also true of this generation (see §6).

## 2. Graphify

Installed (`pip install graphifyy`, v8 CLI) and run code-only over three generations (`--code-only`; the semantic pass needs an LLM key): 596 nodes, 1,171 edges, 47 communities in a few seconds. Degree centrality reproduced the forensic story mechanically: the deterministic generation has a god-node `core/engine.ts` (56 edges) while the "model decides" generations spread responsibility (`model.ts` 42/30 edges, `turn.ts` 35). Useful as a five-second sanity check of "where does complexity concentrate"; **not** more informative than the generations' own DECISIONS/EVALUATION files, and not needed in the product. Verdict matches the previous generation's: a lab tool, not a component.

## 3. Real software examined for mechanisms

The problem is not novel in its parts. What people have actually built:

| system | mechanism | what we took / rejected |
| --- | --- | --- |
| **mem0** (memory layer for agents) | LLM extracts candidate memories from each exchange, then an LLM decides ADD / UPDATE / DELETE / NOOP against similar stored memories; vector search for retrieval. | **Took:** extraction by the model as structured output after each turn. **Rejected:** letting the model also decide the *lifecycle*. Prior generations showed model-managed notes have no provenance, no guard against re-inference and no decay; our `flat_memory` baseline is precisely "mem0-style notes without lifecycle" and it loses on stale preferences (12/30 violations) and on trusting claims (9 missed refreshes). |
| **Letta / MemGPT** | Model-editable "core memory" blocks (persona / human) + archival memory reached through tools; the model manages its own memory via function calls. | **Took:** a small tool set the model can call (`recall_memory`, `remember`, `forget`) for the long tail and for explicit requests. **Rejected:** having the model be the sole author of what it believes about the person; epistemic labels (stated vs demonstrated) would be lost. |
| **Zep / Graphiti** | Temporal knowledge graph: facts as edges with `valid_at` / `invalid_at`; contradictions invalidate rather than delete. | **Took:** temporal validity in spirit — evidence is append-only, `retracted_at` invalidates, corrections cut everything before them, and beliefs are re-derived from what is currently valid. **Rejected:** the graph itself; at one-person scale a flat evidence log and a pure derivation function give the same guarantees with ~300 lines. |
| **FSRS / Anki (ts-fsrs)** | Stability & difficulty per item, retrievability decays exponentially, spaced successful retrieval multiplies stability. | **Took:** the shape (half-life recall, spaced success ×2.5, failure shrinks), the same shape three archive labs validated. **Rejected (for now):** full FSRS parameters and per-learner calibration — the archive measured MAE 0.18→0.14 from calibration; our uncalibrated model scores 0.08 against the lab's hidden truth, so calibration is a documented next step, not a need. `ts-fsrs` is a drop-in if it becomes one. |
| **ChatGPT / Gemini "memory" features** | Free-text notes saved from conversation, injected into context. | This is the `flat_memory` baseline. It is good at *facts* and bad at *epistemics*: it cannot tell "says they know" from "showed they know", and it cannot forget on schedule. |
| **Intelligent tutoring systems (BKT-style knowledge tracing, ASSISTments, OATutor)** | Skill → mastery probability from graded item responses; policies pick next items. | **Took:** the idea that unaided correct performance is the evidence that matters. **Rejected:** item banks, graders and next-item policies — the archive built all of them; they constrained the model and never showed an adaptation benefit. The LLM grades free-form answers and picks the next move itself. |
| **Coding assistants' repo/user memory (Cursor rules, Claude memory files, Copilot instructions)** | Short, human-editable instruction files injected each turn. | **Took:** the *brief* is exactly this — ≈250–320 tokens, visible and correctable by the person in the UI. |

## 4. The central architectural question: what should the model do vs the application?

Tested by construction: every baseline is a *mode of the same turn function*, differing only in what the model is told about the past.

Findings (offline lab, 6 learners × 3 seeds × 6 sessions over 75 simulated days, 3,828 turns):

| capability | verdict | evidence |
| --- | --- | --- |
| Deciding *how* to teach this turn (explain / check / hint / answer) | **Model.** No policy engine. | Every pedagogy metric in the lab is achieved by a policy that merely *reads the brief*; the archive's bandits/controllers added nothing measurable. |
| Reading an exchange and saying what it shows about the person | **Model** (structured output), **validated by the app**. | Regex perception was the archive's main bug source; the reflection schema + clamping gives the same data with no parsers. |
| Remembering across sessions | **Application.** | `none` re-teaches known skills 36/36 times. Trivially necessary. |
| Remembering *with epistemics* (claimed vs shown vs explained) | **Application.** | `flat_memory` (no epistemics) trusts claims: 9 missed refreshes on the over-claimer vs 0 for the layer; `transcript` re-teaches 6/36 and misses 30 refreshes. |
| Forgetting on schedule | **Application.** | Decay is what turns "demonstrated" into "probably forgotten — re-teach briefly" after a 60-day gap (behaviour test); notes and transcripts have no clock. |
| Honouring corrections and not re-inferring them from weak signals | **Application (guard)**. | Layer 0/30 stale-preference violations vs `flat_memory` 12/30 after a single "let me think about it myself" re-created the retired belief. |
| Knowing what has actually worked with this person | **Application (ledger), model (judgement).** | Outcomes are attributed on the *next* turn by the model's judgement and kept as statistics, never beliefs (archive: outcome-derived "preferences" self-reinforce). |
| Handling a false negative (one slip on a known skill) | **Shared.** | First lab run: the layer re-taught a slipped skill forever because explanation yields no evidence of knowing. Fixed by a brief line ("explained 2× but never shown unaided — have them attempt before explaining a third time"); the model decides, the layer makes the trap visible. Redundant re-explanations fell 10/36 → 4/36 and recover to 0 by session 4. |

## 5. What failed, and what it taught

1. **Baselines that were accidentally weak.** The first offline run made the transcript baseline look terrible (18/18 stale violations). It was our mock ignoring the current session and reading most-recent-first blocks in the wrong order. Fixed; the honest transcript baseline has 0 stale violations. Lesson: a lab that flatters the product is worthless — the previous generations' 12/24 transcript result should be read with the same suspicion.
2. **A miscalibrated hint.** "Fading → quick check" was emitted at 17% estimated recall, where a bare check mostly fails and wastes the turn. The hint now depends on the estimate.
3. **The explain-forever trap** (§4, last row). A single false negative locked in because the state never got new evidence. General lesson: *any belief that cannot be contradicted by the actions it causes is a trap.* The brief must steer toward evidence-producing actions.
4. **The guard admitted new evidence immediately.** A corrected belief was re-created two sessions later by a reaction. Now only *stated* evidence counts inside the 14-day window.
5. **Hidden-outcome metrics are not evidence about humans.** In our declared dynamics a re-explanation can out-teach a failed retrieval attempt, so `flat_memory` sometimes wins on "hidden final recall" (0.90 vs 0.87). We report it anyway; it shows the lab is not rigged, and it shows why *behavioural* metrics (redundancy, stale memory, missed refresh) are the right ones to compare layers on.

## 6. Limits of the evidence

- **No live model numbers.** The sandbox has no `GEMINI_API_KEY`, so every number measures the layer with a scripted reader of its own brief. The live path (`npm run lab:live`) uses Gemini as tutor, as answer-verbaliser and as judge; it is implemented against the current REST API but unvalidated here. This is the same limitation as all 16 previous generations and it is the single most important thing to do next.
- **Synthetic learners are passive.** The co-adaptation generation showed humans change their behaviour in response to the AI (trust, restatements). Our learners do not.
- **The mock cannot grade.** Offline, a human typing answers gets "unclear" attributions; only Gemini can turn free-form answers into `demonstrated`/`failed` evidence.

## 7. Why this direction

Because it is the smallest thing that the evidence supports: the model already does within-turn pedagogy well when informed; what it cannot do is *remember with epistemics, forget on schedule, honour corrections, and keep an honest record of what worked*. Those four are ≈600 lines of pure functions over one append-only table, they are fully inspectable and correctable by the person, and every baseline that lacks one of them fails a measurable behaviour.
