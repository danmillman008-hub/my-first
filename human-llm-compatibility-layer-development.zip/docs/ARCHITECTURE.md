# Architecture

```
 person ──► Chat UI ──► POST /api/chat (SSE) ──► runTurn()
                                                   │
      ┌────────────────────────────────────────────┼─────────────────────────────────────────┐
      │  1. load evidence (append-only log)        │                                          │
      │  2. deriveState(evidence, now)   ← pure    │   Postgres: learners · sessions ·        │
      │  3. compileBrief(state)          ← pure    │             messages · evidence          │
      │  4. system prompt = persona + evidence     │   (MemoryStore for tests & lab)          │
      │     guide + brief;   tools: recall_memory, │                                          │
      │     remember, forget                       │                                          │
      │  5. Gemini streams the reply (model decides│                                          │
      │     what to do pedagogically)              │                                          │
      │  6. reflection: model → JSON evidence      │                                          │
      │     validateReflection() → evidence rows   │                                          │
      │  7. attribute previous approach's outcome  │                                          │
      │  8. trace stored on the message ("why")    │                                          │
      └────────────────────────────────────────────┴─────────────────────────────────────────┘
```

## Components (≈1,300 lines of product code)

| file | role | LLM or app? |
| --- | --- | --- |
| `src/db/schema.ts` | 4 tables. `evidence` is append-only; only `retracted_at` and `payload.outcome` (approach rows) ever change. | app |
| `src/lib/core/types.ts` | Evidence payloads, derived state, reflection shape, conditions. | – |
| `src/lib/core/model.ts` | `deriveState(evidence, now)`: skills (half-life recall, status), style beliefs (lifecycle), facts, approach statistics, do-not-assume list. Pure, deterministic. | app |
| `src/lib/core/brief.ts` | `compileBrief(state)` → ≈250–320 tokens of epistemically labelled notes. `compileFlatMemory` is the no-lifecycle baseline. | app |
| `src/lib/core/reflect.ts` | Reflection JSON schema, validation/clamping, evidence rows. | model reads, app books |
| `src/lib/agent/prompt.ts` | Persona (freedom + principles), evidence guide, reflection instructions. | – |
| `src/lib/agent/tools.ts` | `recall_memory`, `remember`, `forget`. | model calls, app executes |
| `src/lib/agent/turn.ts` | The turn (above). All four conditions are modes of this function. | – |
| `src/lib/llm/gemini.ts` | REST client: SSE streaming, function-calling loop (parts incl. `thoughtSignature` passed back opaquely), structured output, model-id resolution with fallbacks. | – |
| `src/lib/llm/mock.ts` | Offline stand-in that reads the same context. Clearly labelled; never evidence about Gemini. | – |
| `src/lib/store/*` | `Store` interface; `PgStore` (product) and `MemoryStore` (lab/tests). | app |
| `src/app/api/*` | `chat` (SSE), `sessions`, `memory` (inspect / correct / retract / erase), `status`, `health`. | – |
| `src/components/*` | Chat with per-turn "why this turn" trace; memory panel with beliefs, skills, facts, exact brief, raw evidence, corrections. | – |

## Key design properties

**Everything is derived.** No learner document, no mutable belief rows. Delete one piece of evidence and every belief re-derives honestly; corrections are themselves evidence. This removed the archive's "batch vs online divergence" class of bugs entirely.

**Epistemic labels survive to the prompt.** The model is told *how* each item is known (stated / observed / claimed / explained / corrected) and asked to weigh, not obey.

**The model decides; the layer makes traps visible.** The brief contains hints ("probably forgotten: re-teach briefly", "explained 2× but never shown unaided: have them attempt") that were each added because the lab caught a failure mode. They are advice to a free reasoner, not a policy.

**Two-sided adaptation.** The human side: beliefs, skills, facts, corrections. The model side: the approach ledger ("what has actually worked with this person"), attributed on the next turn by the model's own judgement and shown as statistics. The person can see both and correct the former.

**Baselines are modes.** `condition ∈ {none, transcript, flat_memory, layer}` changes only step 3–4. The UI exposes the selector for demonstration; the lab uses it for measurement.

**Model-evolvable without an abstraction tower.** One 5-method `LLM` interface. Swapping the provider changes nothing stored; the brief is plain text.

## Data flow of a correction

```
person clicks "not true" on belief directness   (or says "stop assuming I want hints")
  → POST /api/memory {target:"style:directness"}   (or the model calls forget())
  → evidence row {kind:"correction", target}
  → deriveState: evidence about directness before the correction is cut;
                 for 14 days only *stated* evidence counts; brief gets a "Do NOT assume" line
  → next turn: model sees the line, does not hint; reflection may record a new stated preference,
    which is allowed to act immediately
```

## What is deliberately absent

Embeddings/vector store (lexical search covers "what did we say about X" at one-person scale; interface isolated in `Store.searchMessages`), concept graphs, item banks, graders, policy engines, affect models, MCP, accounts (one httpOnly cookie = one relationship). Each is re-addable behind the same store if evidence ever demands it.
