# Forensic analysis of previous attempts

Source: `https://github.com/danmillman008-hub/my-first` (8 "Add files via upload" commits, 16 mission zips). The second repository named in the brief, `build-adaptive-learning-agent`, is **recovered from that archive** (`build-adaptive-learning-agent.zip`); no separate remote exists. Five generations were unpacked and read end to end; Graphify (code-only) was run over three of them.

## Generations and lineage

```
private-self-adapting-learning-agent (×6)   ─┐
self-adapting-learning-agent-mission         │  deterministic controller lineage
synthesize-self-adapting-learning-agent      │  (BKT/half-life + bandit + affect + graph + MCP)
build-adaptive-graph-ai-tutor (×2)           │
build-graph-native-ai-tutor, graph-native-*  │
build-adaptive-learning-agent               ─┘  ← strongest of the lineage; "LLM optional, never decisive"
adaptive-human-llm-compatibility-layer       ─┐  "model decides, layer informs"
human-ai-co-adaptation-research             ─┘  derived beliefs + self-model + co-adaptation lab
```

## What each major component was trying to solve — and what happened

| component (archive) | problem it addressed | measured result in their own labs | fate here |
| --- | --- | --- | --- |
| Wikipedia research → concept graph → prerequisites | "Teach any subject" without content | 4 attempts; thousands of lines; recurring disambiguation bugs; no measured adaptation benefit | **Removed.** The LLM has the subject knowledge; the layer never needs it. |
| Curated packs (Bash, OOP) with 5 explanation styles | Reliable content for demos | Hidden subject list; contradicts generality | **Removed.** |
| BKT + Beta pseudo-counts | Mastery estimate with uncertainty | Replaced in-lineage by half-life model (fewer guessed parameters; forgetting first-class) | Half-life shape **kept** (`core/model.ts`), BKT not. |
| Thompson-sampling over explanation styles | Learn *how* to teach this person | Optimised reactions ("that makes sense"), ≈0 learning effect; outcome-derived preferences self-reinforced | **Removed.** Approach outcomes are kept only as statistics in the brief; the model chooses. |
| Affect engine (frustration/fatigue from latency & lexical cues) | React to emotional state | ≈0 measured benefit; brittle | **Removed.** A modern model reads tone itself. |
| Regex "perceive" step | Extract evidence from text | Main bug source across generations | **Replaced** by model-side structured extraction + app-side validation. |
| Item banks + graders + attribution rules | Evidence of learning | Necessary *in a controller design*; the strongest generation's gain 0.62 vs 0.17 explain-only — but measured against synthetic learners whose dynamics reward retrieval | Item banks/graders **removed**; the *attribution principle* (credit judged on the next turn; performance ≠ learning) **kept**. |
| Belief lifecycle: candidate/active/contested/retired, cap 0.92, cross-session requirement, 14-day correction guard | Stop temporary states becoming traits; make corrections stick | Correction only held with the guard (adversarial suites, 3 generations) | **Kept**, and tightened: inside the guard only *stated* evidence counts (our lab found a reaction re-created a retired belief). |
| claimed ≠ demonstrated ≠ explained; aided ≠ unaided; spaced ≠ massed | Do not confuse exposure with knowledge | Without these, skills became "secure" without ever being retrieved unaided (lab bugs 2–4 in the archive) | **Kept** verbatim as semantics; unit-tested. |
| Append-only evidence + single mutable learner document | Provenance + simplicity | Worked; "batch consolidation diverged from online" when they tried batching | **Simplified further**: no learner document at all — everything is derived from the evidence log on read. |
| MCP server (11 tools) | Interoperability | Orthogonal to the product question | **Removed.** |
| Provider abstraction (Anthropic/OpenAI/Gemini) | Model independence | Never exercised live | **Minimal**: one `LLM` interface with two implementations (Gemini REST, offline mock). |
| Self-model ledger (what the AI tried, outcome filled next turn) | Let the AI disagree with a belief using its own record | Contributed to the best "fit" condition in the co-adaptation lab | **Kept** as the `approach` evidence kind. |
| Probing the person about themselves | Faster fit | The co-adaptation trap: fast trust, then erosion when the AI follows behaviour over words | **Not done.** The prompt says "observe; one light question only when it changes what you'd do". |

## Structural observation (Graphify, code-only)

596 nodes / 1,171 edges over three generations. Highest-degree nodes: `build-adaptive-learning-agent/core/engine.ts` (56) — the controller god-node — vs `human-ai-co-adaptation-research/core/model.ts` (42, a pure function) and `adaptive-human-llm-compatibility-layer/memory/model.ts` (30). The "model decides" generations already had the right shape; this generation keeps that shape and shrinks it.

## Failed assumptions worth naming

1. *"The application must decide pedagogy for adaptation to be real."* Fourteen generations; never demonstrated. The two that dropped it matched or beat them on every adaptation metric with a fraction of the code.
2. *"More representation = better model of the learner."* Concept graphs, affect states and trait tables did not move outcome metrics; the four epistemic distinctions did.
3. *"Reactions are outcomes."* Repeatedly falsified; the reason bandits looked good and were not.
4. *"A lab without a live model is enough."* Every generation, including this one, has had to say so. The live path exists in each; none has run it.

## Reusable infrastructure taken forward

- Half-life recall semantics and status vocabulary (rewritten, ~120 lines).
- Belief lifecycle rules (rewritten, ~80 lines).
- The "same turn function, different context" evaluation design.
- Synthetic-learner archetypes (novice, knowledgeable, corrector, forgetter, over-claimer) with hidden state.

Everything else was re-derived from the brief and the evidence rather than copied.
