# Evaluation

Three layers, kept distinct:

1. **Unit tests** (`npm test`, 22 in `tests/core.test.ts`): pure semantics — skill events, decay, spacing, slips, corrections, belief lifecycle and guard, contested beliefs, derived-ness (retraction re-derives), facts, approach statistics, brief compilation, reflection validation.
2. **Behavioural tests** (9 in `tests/behaviour.test.ts`): the real `runTurn` + offline model + in-memory store. Each asserts an *observation → behavioural consequence → new observation → revision* chain: claim → light verification → treated as known; explained → checked → failed → different approach; long gap → brief re-teach; stated preference → correction → weak signal cannot bring it back; observed behaviour changes approach after two sessions; next-turn attribution; remember/forget; baselines through the same path; brief stays small.
3. **Longitudinal laboratory** (`npm run lab`, `lab/out/summary.md`): does the layer improve a long-term interaction versus baselines?

## Laboratory design

Same `runTurn`, four conditions:

| condition | what the model receives about the past |
| --- | --- |
| `none` | nothing beyond the current conversation |
| `transcript` | raw prior transcripts, most-recent-first, cut at 6,000 chars (≈4× the layer's brief budget, in the baseline's favour) |
| `flat_memory` | the *same extracted observations* written out flat — no derivation, no decay, claims read as "Knows", corrections as a note, no guard. This is what "save what the model extracts" (ChatGPT-style memory, mem0 without lifecycle) looks like. |
| `layer` | compiled brief + tools + reflection with lifecycle (the product) |

Six synthetic learners with **hidden** state the tutor never sees (knowledge `k`, half-life, last practice; declared dynamics: explanation `k += g(approach)·(1−k)`; correct unaided retrieval `k += 0.25(1−k)`, half-life ×2.5 if spaced; failed retrieval with feedback `k += 0.12(1−k)`; answers correct with probability = hidden recall, so ~8% slips exist even for mastered skills):

- **novice** — learns far better from worked examples (gain 0.45 vs 0.15) but never says so
- **knowledgeable** — already solid on two of four topics and says so
- **corrector** — asks for hints in session 1, retracts in session 2, emits a weak "let me think about it myself" in session 3
- **fast_forgetter** — half-life ≈ 1 day
- **long_gap** — normal, but returns after 45- and 75-day gaps
- **overclaimer** — claims two topics it does not know

Six sessions at days 0 / 2 / 9 / 30 / 45 / 75, three seeds, identical scripts across conditions: 3,828 turns in 0.3 s.

Offline, the "model" is a scripted policy that reads the same context a real model would get (structured brief, flat lines, transcript, or nothing) and the reflection is an oracle for answer correctness. **Offline numbers therefore measure the layer's bookkeeping, not Gemini's prose.** The live path (`npm run lab:live`) uses Gemini as tutor, as answer-verbaliser (correctness still dictated by hidden state) and as judge of the tutor's action; no key was available in this sandbox, so no live numbers are reported.

## Metrics (all behavioural, two-sided where possible)

- **redundant re-explanations** — explained a topic the person still knew (hidden recall ≥ 0.6) → over-teaching / ignoring memory
- **missed refresh** — only quizzed a topic they had forgotten (hidden recall < 0.3) after prior teaching → over-trusting memory
- **hint preference respected** before retraction; **stale-preference violations** after retraction → memory usefulness vs stale memory
- **examples adapted** — worked example chosen for the novice from session 2 on → adaptation from *observed* (never stated) behaviour
- **model MAE** vs hidden recall (layer only) → learner-model accuracy
- **prompt chars / brief tokens** → context efficiency
- **hidden final recall / retention +60d** → reported for completeness; **not evidence about humans**, and not tuned to the layer

## Results (offline, `lab/out/summary.md`)

| condition | redundant re-explanations | missed refresh | pref respected | stale violations | examples adapted | model MAE | prompt chars | brief tokens | hidden final recall |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| none | 36/36 (1.00) | 0/330 | 6/6 | 0/30 | 0/60 | – | 1,785 | 0 | 0.85 |
| transcript | 6/36 (0.17) | 30/330 (0.09) | 6/6 | 0/30 | 0/60 | – | 5,277 | 827 | 0.83 |
| flat_memory | 0/36 (0.00) | 9/330 (0.03) | 6/6 | **12/30 (0.40)** | 60/60 | – | 2,756 | 203 | 0.90 |
| **layer** | 4/36 (0.11) | **0/330** | 6/6 | **0/30** | 33/36 (0.92) | **0.08** | 4,303 | 316 | 0.87 |

Longitudinal (layer): redundant re-explanations per session 0 → 2 → 2 → 0 → 0 → 0; stale violations 0 in every session; examples adapted 9/12 in session 2 (belief still a candidate for part of it), 12/12 afterwards. `flat_memory` stale violations: 0 → 0 → 6 → 6 → 0 → 0 (the weak signal in session 3 re-created the preference until the note scrolled out of its window). `none` re-teaches 6/6 known topics every session; `transcript` re-teaches all 6 in session 1 (before the claim is in any transcript) and none afterwards.

### Reading

- **Every memory helps; only the layer avoids both failure modes.** Transcripts over-teach (6) and over-trust nothing but miss 30 refreshes because they cannot see decay; flat notes never over-teach but trust claims (9 missed refreshes on the over-claimer) and re-create corrected beliefs (12 violations). The layer has 0 of each and pays 4 redundant explanations — the cost of *recovering from its own false negative* (a slip on session 1's verification), which it does by session 4 because the brief steers toward evidence-producing actions.
- **Adaptation from observed behaviour is real and needs two sessions by design**; that is the 9/12 in session 2, and it is the intended guard against one-off reactions.
- **Context efficiency:** the brief is 316 tokens vs 827 for a transcript cut that also loses information; the layer's total prompt is larger than `flat_memory`'s only because its system guide (evidence semantics + tool descriptions) is ≈1.5k characters longer — a fixed cost.
- **Learner-model accuracy** 0.08 MAE without calibration to the hidden dynamics.
- **Hidden outcomes are close and not in the layer's favour** (0.87 vs 0.90 for flat notes): under the declared dynamics a full re-explanation can out-teach a failed retrieval attempt. Reported to show the lab is not rigged; it is why behaviour, not synthetic "learning", is the comparison basis.

### What the first runs got wrong (and how the lab was corrected)

The first offline run showed transcript stale violations 18/18. That was the *mock* ignoring the current session and misreading most-recent-first transcripts — a handicap no real model has. Baselines were strengthened before any number was kept. Two further failures (a miscalibrated "fading" hint; the explain-forever trap after a slip) were found the same way and fixed in the brief, not with policy code. See `docs/RESEARCH.md` §5.

## Reproducing

```
npm test                 # unit + behavioural (in-memory store, offline model)
npm run lab              # offline lab, writes lab/out/summary.md and raw.json
npm run lab -- --seeds 5 --sessions 6
GEMINI_API_KEY=… npm run lab:live   # Gemini as tutor/verbaliser/judge, writes summary-live.md
```
