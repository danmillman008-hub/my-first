# Capability map: model vs application

Where the boundary sits after this generation's research and lab work. "Model" = a current frontier model such as Gemini Flash given a good brief; "App" = the compatibility layer. Evidence column cites the lab (`lab/out/summary.md`), behaviour tests (`tests/behaviour.test.ts`), the archive's recorded results, or documented provider capabilities.

## LLM can do reliably (do not rebuild)

| capability | evidence |
| --- | --- |
| Within-turn pedagogy: choose to explain / check / hint / answer / give an example when informed | Every lab metric reached with zero policy code; archive controllers added nothing measurable |
| Diagnose a misconception from a wrong answer and name it | Structured-output extraction field `misconception`; provider docs; archive's free-text grading channel |
| Grade free-form answers as correct / incorrect / aided | Reflection schema; archive used the LLM for open-answer grading when available |
| Read the current conversation (in-session corrections, "just the answer") | By construction; our first lab run wrongly denied this to baselines and had to be fixed |
| Produce strictly structured JSON on a schema | `responseMimeType: application/json` + `responseSchema` (Gemini API docs) |
| Use a small tool set correctly (recall / remember / forget) | Function calling with thought-signature passthrough (Gemini API docs) |
| Explain the same idea via different representations (code trace, analogy, formal) on request | Native capability; the brief only tells it which has worked |

## LLM can sometimes do (inconsistent; make reliable with evidence)

| capability | how the app makes it reliable |
| --- | --- |
| Distinguish "they said they know it" from "they showed they know it" across a long history | Labels in the brief: `CLAIMS to know it — unverified` vs `shown unaided 2×` |
| Avoid re-teaching what the person already demonstrated | `transcript` baseline re-teaches 6/36 known skills; layer 4/36 with recovery to 0 by session 4 |
| Notice that a preference stated long ago was later retracted | Transcript ordering/budget makes this fragile (archive 12/24); layer retires + "Do NOT assume" |
| Not over-adapt to a single reaction | Belief lifecycle: inferred beliefs need 2 sessions; weak signals blocked inside the correction guard |
| Judge whether its previous approach worked | It judges; the app attributes to the right turn and keeps it as a statistic, never a belief |
| Decide when to let the person try instead of explaining again | Brief line after 2 explanations without a demonstration (fixed the explain-forever trap) |

## LLM cannot reliably do (application must provide)

| capability | why | app mechanism |
| --- | --- | --- |
| Remember across sessions at all | No persistent state between API calls | Evidence log + sessions + messages |
| Forget on a schedule | No clock, no decay | Half-life recall model → `fading` / `probably forgotten` |
| Keep provenance (which message produced which belief) | Would have to be re-derived from text each time | `evidence.message_id`, source, timestamps |
| Guarantee a correction sticks for N days against re-inference | Stateless | 14-day guard in `deriveState` |
| Keep the context cost bounded as history grows | Context grows linearly | Brief stays ≈250–320 tokens after 8+ sessions (behaviour test) vs 830 for transcripts at a hard cut |
| Give the person inspection, correction and erasure rights | Not addressable inside a model | Memory panel, `/api/memory` correction / retraction / erase |

## Application should verify (model output that is checked)

| output | check |
| --- | --- |
| Reflection JSON | Schema validation, enum whitelists, clamping to [-1,1], slug normalisation, dedup, per-turn caps |
| Tool arguments | Length limits, learner scoping (a session can only be read by its cookie owner) |
| Approach attribution | Only applied if the pending approach belongs to the immediately previous assistant message |
| Session titles | Length-capped, only set once |

## Shared responsibility

| task | model | app |
| --- | --- | --- |
| Learner model | Interprets labelled evidence in context; can override it when the present contradicts it | Derives it deterministically from evidence; keeps it small and revisable |
| Teaching approach selection | Chooses | Reports what has actually worked and what was corrected |
| Memory writing | Extracts what the exchange shows | Decides what persists, expires, retires; never lets the model rewrite history |
| Memory reading | Calls `recall_memory` for the long tail | Answers the common case with the brief |
| Trust | Acts on beliefs | Caps confidence at 0.92; marks stated-vs-observed tensions instead of resolving them |

## Open (needs a live model to settle)

- Whether Gemini honours the "Do NOT assume" line as reliably as the scripted reader does.
- Whether the model's `previous_approach_outcome` judgements are stable enough for the ledger to be informative.
- Whether the brief's hints are read as advice (intended) or as rules (would violate model autonomy). The live lab's judge is set up to detect both.
