/**
 * The laboratory. Does the compatibility layer improve a LONG-TERM interaction
 * versus baselines, holding everything else constant?
 *
 *   npx tsx scripts/lab/run.ts               # offline (mock model): measures the LAYER
 *   npx tsx scripts/lab/run.ts --live        # Gemini as tutor + judge (needs GEMINI_API_KEY)
 *   npx tsx scripts/lab/run.ts --seeds 5 --sessions 6
 *
 * All conditions run through the identical `runTurn`; only what the model is
 * told about the past differs.
 */
import { mkdirSync, writeFileSync } from "node:fs";
import { runTurn } from "../../src/lib/agent/turn";
import { deriveState } from "../../src/lib/core/model";
import type { Approach, Condition, TurnTrace } from "../../src/lib/core/types";
import { getLLM, type LLM } from "../../src/lib/llm";
import type { MockAction } from "../../src/lib/llm/mock";
import { MemoryStore } from "../../src/lib/store/memory";
import { DAY, LEARNERS, QUESTIONS, SKILLS, applyExplanation, applyRetrieval, human, initHidden, recallAt, rng, type Learner, type Skill } from "./sim";

const args = process.argv.slice(2);
const flag = (n: string, d: number) => {
  const i = args.indexOf(`--${n}`);
  return i >= 0 ? Number(args[i + 1]) : d;
};
const LIVE = args.includes("--live");
const SEEDS = flag("seeds", 3);
const SESSION_DAYS = [0, 2, 9, 30, 45, 75].slice(0, flag("sessions", 6));
const CONDITIONS: Condition[] = ["none", "transcript", "flat_memory", "layer"];
const BASE = Date.UTC(2026, 0, 5, 9);

interface Metrics {
  turns: number;
  knownRequests: number;
  redundant: number; // explained something they still knew
  weakRequests: number;
  missedRefresh: number; // bare check when they had forgotten (after prior teaching/failure)
  prefOpp: number;
  prefRespected: number; // socratic used while hints were wanted (session 1 of corrector)
  staleOpp: number;
  staleViolations: number; // socratic used after the retraction
  exOpp: number;
  exMatch: number; // worked example used for the examples-learner in sessions ≥ 2
  maeN: number;
  mae: number;
  promptChars: number;
  briefTokens: number;
  ms: number;
  finalK: number[];
  retention90: number[];
  perSession: { redundant: number; known: number; exMatch: number; exOpp: number; stale: number; staleOpp: number }[];
}
const zero = (): Metrics => ({ turns: 0, knownRequests: 0, redundant: 0, weakRequests: 0, missedRefresh: 0, prefOpp: 0, prefRespected: 0, staleOpp: 0, staleViolations: 0, exOpp: 0, exMatch: 0, maeN: 0, mae: 0, promptChars: 0, briefTokens: 0, ms: 0, finalK: [], retention90: [], perSession: SESSION_DAYS.map(() => ({ redundant: 0, known: 0, exMatch: 0, exOpp: 0, stale: 0, staleOpp: 0 })) });

interface Action {
  action: MockAction;
  approach: Approach;
}

async function classifyLive(llm: LLM, userMsg: string, reply: string): Promise<Action> {
  return llm.json<Action>({
    system: "You classify a tutor's reply. Return JSON only.",
    prompt: `Learner said: ${userMsg}\n\nTutor replied:\n${reply}\n\nClassify: action = explain (taught the topic substantively) | check (asked the learner to recall/apply without teaching) | refresh_check (brief reminder then asked them to try) | verify_claim (asked them to confirm claimed knowledge) | answer (responded to the learner's answer) | chat. approach = main approach.`,
    schema: { type: "object", properties: { action: { type: "string", enum: ["explain", "check", "refresh_check", "verify_claim", "answer", "chat"] }, approach: { type: "string", enum: ["direct_answer", "worked_example", "conceptual_explanation", "analogy", "socratic_question", "retrieval_check", "exercise", "debug_together", "other"] } }, required: ["action", "approach"] },
  });
}

async function verbaliseAnswer(llm: LLM | null, skill: Skill, correct: boolean): Promise<string> {
  if (!llm) return correct ? `My answer: ${CORRECT[skill]}` : `My answer: ${WRONG[skill]}`;
  const r = await llm.json<{ text: string }>({
    system: "You role-play a learner answering a tutor's check question in 1–2 sentences. Return JSON {text}.",
    prompt: `Topic: ${human(skill)}. Write a ${correct ? "CORRECT, competent" : "WRONG (plausible misconception)"} short answer in the first person.`,
    schema: { type: "object", properties: { text: { type: "string" } }, required: ["text"] },
  });
  return r.text;
}
const CORRECT: Record<Skill, string> = {
  recursion: "a function calls itself on a smaller input and a base case stops it; without the base case it never terminates",
  closures: "an inner function keeps access to variables of its enclosing scope even after that scope has returned",
  "sql-joins": "an inner join keeps only matching rows, a left join keeps all rows from the left table with NULLs where there is no match",
  "big-o-notation": "it describes how running time grows with input size, ignoring constants; nested loops over n give O(n²)",
};
const WRONG: Record<Skill, string> = {
  recursion: "the function keeps calling itself until the computer decides it is done",
  closures: "a closure is just a function that has been closed and can't be called any more",
  "sql-joins": "a left join returns only the rows on the left that don't match",
  "big-o-notation": "O(n²) means the program takes exactly n squared seconds",
};

async function runOne(learner: Learner, seed: number, condition: Condition, llm: LLM, m: Metrics) {
  const store = new MemoryStore();
  const learnerId = `${learner.name}-${seed}-${condition}`;
  const hidden = initHidden(learner);
  const rand = rng(seed * 7919 + learner.name.length * 131 + CONDITIONS.indexOf(condition) * 17);
  let clock = 0;
  let lastFailed = new Set<Skill>();
  let taught = new Set<Skill>();
  lastFailed = new Set();
  taught = new Set();

  const turn = async (sessionId: string, day: number, text: string, hints?: { skill?: Skill; answerCorrect?: boolean }): Promise<{ trace: TurnTrace; reply: string }> => {
    const now = new Date(BASE + day * DAY + clock++ * 60_000);
    let reply = "";
    let trace: TurnTrace | null = null;
    for await (const ev of runTurn({ store, llm, learnerId, sessionId, userMessage: text, condition, now, mockHints: hints })) {
      if (ev.type === "text") reply += ev.text;
      if (ev.type === "trace") trace = ev.trace;
    }
    m.turns++;
    m.promptChars += trace!.promptChars;
    m.briefTokens += trace!.briefTokens;
    m.ms += trace!.ms;
    return { trace: trace!, reply };
  };
  const actionOf = async (t: TurnTrace, userMsg: string, reply: string): Promise<Action> => {
    if (t.mockAction) {
      const [a, b] = t.mockAction.split(":");
      return { action: a as MockAction, approach: b as Approach };
    }
    return classifyLive(llm, userMsg, reply);
  };

  for (let si = 0; si < SESSION_DAYS.length; si++) {
    const day = SESSION_DAYS[si];
    const sessionId = `${learnerId}-s${si}`;
    for (const s of learner.says[si] ?? []) await turn(sessionId, day, s);
    if (si === 0) for (const s of learner.claimsAtStart) await turn(sessionId, day, `I already know ${human(s)}.`);

    const order = [...SKILLS.slice(si % SKILLS.length), ...SKILLS.slice(0, si % SKILLS.length)];
    for (const skill of order) {
      const r = recallAt(hidden[skill], day);
      // learner-model accuracy (layer only, for skills with evidence)
      if (condition === "layer") {
        const st = deriveState(await store.listEvidence(learnerId), new Date(BASE + day * DAY + clock * 60_000));
        const est = st.skills.find((k) => k.skill === skill);
        if (est) {
          m.mae += Math.abs(est.recall - r);
          m.maeN++;
        }
      }
      const req = `Teach me ${human(skill)}.`;
      const res = await turn(sessionId, day, req, { skill });
      const act = await actionOf(res.trace, req, res.reply);

      if (r >= 0.6) {
        m.knownRequests++;
        m.perSession[si].known++;
        if (act.action === "explain") {
          m.redundant++;
          m.perSession[si].redundant++;
          if (process.env.LAB_DEBUG) {
            const st = deriveState(await store.listEvidence(learnerId), new Date(BASE + day * DAY + clock * 60_000));
            console.error(`[redundant] ${learnerId} day ${day} ${skill} hidden=${r.toFixed(2)} layer=${JSON.stringify(st.skills.find((k) => k.skill === skill) ?? null)}`);
          }
        }
      }
      if (r < 0.3 && (taught.has(skill) || lastFailed.has(skill))) {
        m.weakRequests++;
        if (act.action === "check" || act.action === "verify_claim") m.missedRefresh++;
      }

      if (act.action === "check" || act.action === "refresh_check" || act.action === "verify_claim") {
        if (act.action === "refresh_check") hidden[skill].k += 0.1 * (1 - hidden[skill].k); // the one-line reminder helps a little
        const correct = rand() < recallAt(hidden[skill], day);
        applyRetrieval(learner, hidden[skill], correct, day);
        if (correct) lastFailed.delete(skill);
        else lastFailed.add(skill);
        await turn(sessionId, day, await verbaliseAnswer(LIVE ? llm : null, skill, correct), { skill, answerCorrect: correct });
      } else if (act.action === "explain") {
        applyExplanation(learner, hidden[skill], act.approach, day);
        taught.add(skill);
        if (learner.needsExamples) {
          if (si >= 1) {
            m.exOpp++;
            m.perSession[si].exOpp++;
            if (act.approach === "worked_example") {
              m.exMatch++;
              m.perSession[si].exMatch++;
            }
          }
          await turn(sessionId, day, act.approach === "worked_example" ? "That made sense — the example helped." : "I'm a bit lost. Examples really help me more than definitions.");
        } else {
          await turn(sessionId, day, "Okay, that made sense.");
        }
      } else {
        await turn(sessionId, day, "Okay.");
      }
    }

    if (learner.asksQuestions) {
      for (const q of QUESTIONS.slice(0, 2)) {
        const res = await turn(sessionId, day, q);
        const act = await actionOf(res.trace, q, res.reply);
        const socratic = act.approach === "socratic_question";
        if (si === 0) {
          m.prefOpp++;
          if (socratic) m.prefRespected++;
        } else {
          m.staleOpp++;
          m.perSession[si].staleOpp++;
          if (socratic) {
            m.staleViolations++;
            m.perSession[si].stale++;
          }
        }
        await turn(sessionId, day, "Thanks.");
      }
    }
  }
  const lastDay = SESSION_DAYS[SESSION_DAYS.length - 1];
  m.finalK.push(SKILLS.reduce((a, s) => a + recallAt(hidden[s], lastDay), 0) / SKILLS.length);
  m.retention90.push(SKILLS.reduce((a, s) => a + recallAt(hidden[s], lastDay + 60), 0) / SKILLS.length);
}

const mean = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);
const f2 = (x: number) => x.toFixed(2);
const ratio = (a: number, b: number) => (b ? `${a}/${b} (${f2(a / b)})` : "–");

async function main() {
  const llm = LIVE ? getLLM("gemini") : getLLM("mock");
  const t0 = Date.now();
  const byCond = new Map<Condition, Metrics>();
  const byLearner = new Map<string, Metrics>();
  for (const condition of CONDITIONS) {
    const m = zero();
    byCond.set(condition, m);
    for (const learner of LEARNERS) {
      const ml = zero();
      for (let seed = 1; seed <= SEEDS; seed++) await runOne(learner, seed, condition, llm, ml);
      byLearner.set(`${condition}/${learner.name}`, ml);
      // merge
      for (const k of Object.keys(ml) as (keyof Metrics)[]) {
        if (k === "finalK" || k === "retention90") (m[k] as number[]).push(...(ml[k] as number[]));
        else if (k === "perSession") ml.perSession.forEach((s, i) => Object.keys(s).forEach((kk) => ((m.perSession[i] as unknown as Record<string, number>)[kk] += (s as unknown as Record<string, number>)[kk])));
        else (m[k] as number) += ml[k] as number;
      }
    }
  }
  const total = [...byCond.values()].reduce((a, m) => a + m.turns, 0);
  const lines: string[] = [];
  lines.push(`# Lab summary (${LIVE ? `LIVE: ${llm.name}` : "offline mock model — measures the layer, not Gemini"})`, "");
  lines.push(`${LEARNERS.length} learners × ${SEEDS} seeds × ${CONDITIONS.length} conditions × ${SESSION_DAYS.length} sessions (days ${SESSION_DAYS.join("/")}) = ${total} turns in ${((Date.now() - t0) / 1000).toFixed(1)} s.`, "");
  lines.push("| condition | redundant re-explanations (still knew it) | missed refresh (had forgotten, only quizzed) | hint preference respected (before retraction) | stale-preference violations (after retraction) | examples adapted (novice, sessions ≥2) | model MAE vs hidden recall | avg prompt chars | avg brief tokens | hidden final recall | hidden retention +60d | ms/turn |");
  lines.push("| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |");
  for (const c of CONDITIONS) {
    const m = byCond.get(c)!;
    lines.push(`| ${c} | ${ratio(m.redundant, m.knownRequests)} | ${ratio(m.missedRefresh, m.weakRequests)} | ${ratio(m.prefRespected, m.prefOpp)} | ${ratio(m.staleViolations, m.staleOpp)} | ${ratio(m.exMatch, m.exOpp)} | ${m.maeN ? f2(m.mae / m.maeN) : "–"} | ${Math.round(m.promptChars / m.turns)} | ${Math.round(m.briefTokens / m.turns)} | ${f2(mean(m.finalK))} | ${f2(mean(m.retention90))} | ${(m.ms / m.turns).toFixed(1)} |`);
  }
  lines.push("", "## Longitudinal view (does behaviour improve across sessions?)", "");
  lines.push("| condition | session | redundant re-explanations | examples adapted | stale violations |", "| --- | --- | --- | --- | --- |");
  for (const c of CONDITIONS) {
    const m = byCond.get(c)!;
    m.perSession.forEach((s, i) => lines.push(`| ${c} | ${i + 1} (day ${SESSION_DAYS[i]}) | ${ratio(s.redundant, s.known)} | ${ratio(s.exMatch, s.exOpp)} | ${ratio(s.stale, s.staleOpp)} |`));
  }
  lines.push("", "## Per learner (layer vs flat_memory vs transcript)", "");
  lines.push("| learner | condition | redundant | missed refresh | stale violations | examples adapted | final recall | retention +60d |", "| --- | --- | --- | --- | --- | --- | --- | --- |");
  for (const l of LEARNERS)
    for (const c of ["transcript", "flat_memory", "layer"] as Condition[]) {
      const m = byLearner.get(`${c}/${l.name}`)!;
      lines.push(`| ${l.name} | ${c} | ${ratio(m.redundant, m.knownRequests)} | ${ratio(m.missedRefresh, m.weakRequests)} | ${ratio(m.staleViolations, m.staleOpp)} | ${ratio(m.exMatch, m.exOpp)} | ${f2(mean(m.finalK))} | ${f2(mean(m.retention90))} |`);
    }
  lines.push("", "Learners:", ...LEARNERS.map((l) => `- **${l.name}** — ${l.description}`));
  const out = lines.join("\n");
  console.log(out);
  mkdirSync("lab/out", { recursive: true });
  writeFileSync(LIVE ? "lab/out/summary-live.md" : "lab/out/summary.md", out + "\n");
  writeFileSync(LIVE ? "lab/out/raw-live.json" : "lab/out/raw.json", JSON.stringify({ byCond: [...byCond], byLearner: [...byLearner] }, null, 1));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
