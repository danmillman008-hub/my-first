import type { Approach } from "../../src/lib/core/types";

/**
 * Synthetic learners with HIDDEN state the tutor never sees.
 *
 * The hidden dynamics are declared here, not tuned to the layer. They encode
 * three things the learning-science literature is confident about (testing
 * effect, spacing, feedback) and one thing the archive measured repeatedly
 * (people are often wrong about how they learn best).
 */

export const DAY = 86_400_000;
export const SKILLS = ["recursion", "closures", "sql-joins", "big-o-notation"] as const;
export type Skill = (typeof SKILLS)[number];

export interface HiddenSkill {
  k: number; // knowledge 0..1
  hl: number; // half-life in days
  last: number; // day of last strengthening event
}

export interface Learner {
  name: string;
  description: string;
  baseHalfLife: number;
  /** k gain multiplier by approach: how much each explanation style actually teaches THIS person */
  gain: Partial<Record<Approach, number>>;
  /** what they SAY at session start (may be wrong or later retracted) */
  says: Partial<Record<number, string[]>>; // session index → messages
  knownAtStart: Skill[];
  claimsAtStart: Skill[]; // claims to know (may be false)
  asksQuestions: boolean; // the corrector archetype asks "how do I…" questions
  needsExamples: boolean; // reacts to abstract explanations with "show me an example"
}

export const LEARNERS: Learner[] = [
  {
    name: "novice",
    description: "Knows nothing; learns much better from worked examples but never says so.",
    baseHalfLife: 3,
    gain: { worked_example: 0.45, conceptual_explanation: 0.15, analogy: 0.2 },
    says: {},
    knownAtStart: [],
    claimsAtStart: [],
    asksQuestions: false,
    needsExamples: true,
  },
  {
    name: "knowledgeable",
    description: "Already solid on recursion and SQL joins (says so); new to the rest.",
    baseHalfLife: 4,
    gain: { worked_example: 0.3, conceptual_explanation: 0.3 },
    says: {},
    knownAtStart: ["recursion", "sql-joins"],
    claimsAtStart: ["recursion", "sql-joins"],
    asksQuestions: false,
    needsExamples: false,
  },
  {
    name: "corrector",
    description: "Asks for hints in session 1, retracts in session 2 and wants direct answers from then on.",
    baseHalfLife: 4,
    gain: { worked_example: 0.3, conceptual_explanation: 0.3 },
    says: {
      0: ["Don't give me the answer, give me hints so I can work it out."],
      1: ["Actually, stop with the hints, just give me the answer directly from now on."],
      2: ["Hmm, let me think about that one myself for a second."], // a weak signal that must NOT re-create the retired belief
    },
    knownAtStart: [],
    claimsAtStart: [],
    asksQuestions: true,
    needsExamples: false,
  },
  {
    name: "fast_forgetter",
    description: "Learns normally but forgets quickly (half-life ≈ 1 day).",
    baseHalfLife: 1,
    gain: { worked_example: 0.3, conceptual_explanation: 0.3 },
    says: {},
    knownAtStart: [],
    claimsAtStart: [],
    asksQuestions: false,
    needsExamples: false,
  },
  {
    name: "long_gap",
    description: "Normal learner who demonstrates early, then returns after long gaps (45 and 75 days).",
    baseHalfLife: 4,
    gain: { worked_example: 0.3, conceptual_explanation: 0.3 },
    says: {},
    knownAtStart: [],
    claimsAtStart: [],
    asksQuestions: false,
    needsExamples: false,
  },
  {
    name: "overclaimer",
    description: "Claims to know closures and big-O; actually does not.",
    baseHalfLife: 3,
    gain: { worked_example: 0.3, conceptual_explanation: 0.3 },
    says: {},
    knownAtStart: [],
    claimsAtStart: ["closures", "big-o-notation"],
    asksQuestions: false,
    needsExamples: false,
  },
];

export function initHidden(l: Learner): Record<Skill, HiddenSkill> {
  const h = {} as Record<Skill, HiddenSkill>;
  for (const s of SKILLS) h[s] = l.knownAtStart.includes(s) ? { k: 0.92, hl: 90, last: -30 } : { k: 0, hl: l.baseHalfLife, last: 0 };
  return h;
}

export const recallAt = (h: HiddenSkill, day: number) => (h.k <= 0 ? 0 : h.k * Math.pow(2, -Math.max(0, day - h.last) / h.hl));

/** Hidden update when the tutor explains. */
export function applyExplanation(l: Learner, h: HiddenSkill, approach: Approach, day: number) {
  const g = l.gain[approach] ?? 0.25;
  h.k = h.k + g * (1 - h.k);
  h.hl = Math.max(h.hl, l.baseHalfLife);
  h.last = day;
}

/** Hidden update when the learner attempts a retrieval (testing effect + spacing + feedback). */
export function applyRetrieval(l: Learner, h: HiddenSkill, correct: boolean, day: number) {
  const spaced = day - h.last >= 1;
  if (correct) {
    h.k = h.k + 0.25 * (1 - h.k);
    h.hl = h.hl * (spaced ? 2.5 : 1.2);
  } else {
    h.k = h.k + 0.12 * (1 - h.k); // feedback after a failed attempt still teaches a little
    h.hl = Math.max(l.baseHalfLife * 0.8, h.hl * 0.8);
  }
  h.last = day;
}

/** Deterministic PRNG so runs are reproducible. */
export function rng(seed: number) {
  let s = seed >>> 0 || 1;
  return () => {
    s ^= s << 13;
    s ^= s >>> 17;
    s ^= s << 5;
    return ((s >>> 0) % 1_000_000) / 1_000_000;
  };
}

export const human = (s: Skill) => (s === "sql-joins" ? "SQL joins" : s === "big-o-notation" ? "big O notation" : s);

export const QUESTIONS = ["How do I reverse a linked list in place?", "How do I pick between a map and a set here?", "How do I stop this loop from running forever?"];
