import { pgTable, text, timestamp, integer, real, boolean, jsonb, index } from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// Evidence is append-only. Beliefs are mutable but bi-temporal: they are never
// deleted, only invalidated (invalid_at / invalid_reason / superseded_by).
// ---------------------------------------------------------------------------

export const learners = pgTable("learners", {
  id: text("id").primaryKey(),
  name: text("name"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull().references(() => learners.id),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull(),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }).notNull(),
    domain: text("domain"),
    concept: text("concept"),
    summary: text("summary"),
    turnCount: integer("turn_count").notNull().default(0),
    probeCount: integer("probe_count").notNull().default(0),
  },
  (t) => [index("sessions_learner_idx").on(t.learnerId, t.lastActiveAt)],
);

export const turns = pgTable(
  "turns",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull().references(() => learners.id),
    sessionId: text("session_id").notNull().references(() => sessions.id),
    role: text("role").notNull(), // learner | tutor
    content: text("content").notNull(),
    strategy: text("strategy"),
    domain: text("domain"),
    concept: text("concept"),
    probe: boolean("probe").notNull().default(false),
    meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("turns_session_idx").on(t.sessionId, t.createdAt), index("turns_learner_idx").on(t.learnerId, t.createdAt)],
);

// Short-term observations: what happened. Never deleted, never edited.
export const observations = pgTable(
  "observations",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull().references(() => learners.id),
    sessionId: text("session_id").notNull().references(() => sessions.id),
    turnId: text("turn_id"),
    kind: text("kind").notNull(),
    content: text("content").notNull(),
    domain: text("domain"),
    concepts: jsonb("concepts").$type<string[]>().notNull().default([]),
    signals: jsonb("signals").$type<Record<string, unknown>>().notNull().default({}),
    source: text("source").notNull(), // learner | model | external | system
    dedupeKey: text("dedupe_key"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("obs_learner_idx").on(t.learnerId, t.createdAt), index("obs_dedupe_idx").on(t.sessionId, t.dedupeKey)],
);

// Long-term beliefs: claims that earned durability. Bi-temporal, revisable.
export const beliefs = pgTable(
  "beliefs",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull().references(() => learners.id),
    kind: text("kind").notNull(), // preference | strategy_fit | tendency | goal | context
    key: text("key").notNull(),
    statement: text("statement").notNull(),
    domain: text("domain"),
    concepts: jsonb("concepts").$type<string[]>().notNull().default([]),
    source: text("source").notNull(), // stated | inferred | external
    polarity: integer("polarity").notNull().default(1),
    status: text("status").notNull(), // candidate | active | contested | dormant | retired
    confidence: real("confidence").notNull(),
    supportCount: integer("support_count").notNull().default(0),
    contradictionCount: integer("contradiction_count").notNull().default(0),
    sessionIds: jsonb("session_ids").$type<string[]>().notNull().default([]),
    validFrom: timestamp("valid_from", { withTimezone: true }).notNull(),
    invalidAt: timestamp("invalid_at", { withTimezone: true }),
    invalidReason: text("invalid_reason"),
    supersededBy: text("superseded_by"),
    lastConfirmedAt: timestamp("last_confirmed_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("beliefs_learner_idx").on(t.learnerId, t.status), index("beliefs_key_idx").on(t.learnerId, t.key)],
);

// Provenance edges: belief -> observation (supports | contradicts | correction).
export const beliefEvidence = pgTable(
  "belief_evidence",
  {
    id: text("id").primaryKey(),
    beliefId: text("belief_id").notNull().references(() => beliefs.id),
    observationId: text("observation_id").notNull().references(() => observations.id),
    relation: text("relation").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("bev_belief_idx").on(t.beliefId)],
);

// Concept mastery: behaviour channel (BKT) and self-report channel kept apart.
export const conceptStates = pgTable(
  "concept_states",
  {
    id: text("id").primaryKey(), // learnerId|concept
    learnerId: text("learner_id").notNull().references(() => learners.id),
    concept: text("concept").notNull(),
    domain: text("domain").notNull(),
    pKnown: real("p_known").notNull(),
    basis: text("basis").notNull(), // prior | claimed | demonstrated
    attempts: integer("attempts").notNull().default(0),
    successes: integer("successes").notNull().default(0),
    claimedLevel: real("claimed_level"),
    claimedAt: timestamp("claimed_at", { withTimezone: true }),
    lastEvidenceAt: timestamp("last_evidence_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("concept_learner_idx").on(t.learnerId, t.domain)],
);

// Strategy outcomes: one row per attributed tutor turn. Append-only.
export const strategyOutcomes = pgTable(
  "strategy_outcomes",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull().references(() => learners.id),
    sessionId: text("session_id").notNull(),
    tutorTurnId: text("tutor_turn_id").notNull(),
    strategy: text("strategy").notNull(),
    domain: text("domain").notNull(),
    concept: text("concept"),
    outcome: real("outcome").notNull(), // -1..1
    weight: real("weight").notNull(),
    signal: text("signal").notNull(), // reaction | task | mixed | request
    createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("outcomes_learner_idx").on(t.learnerId, t.createdAt)],
);

export const traces = pgTable(
  "traces",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull().references(() => learners.id),
    sessionId: text("session_id").notNull(),
    turnId: text("turn_id"),
    kind: text("kind").notNull(),
    payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("traces_learner_idx").on(t.learnerId, t.createdAt)],
);

// Research is isolated from learner memory: keyed by topic, with provenance.
export const researchCache = pgTable("research_cache", {
  topic: text("topic").primaryKey(),
  summary: text("summary").notNull(),
  sourceUrl: text("source_url"),
  provider: text("provider").notNull(),
  fetchedAt: timestamp("fetched_at", { withTimezone: true }).notNull(),
});

export const labRuns = pgTable("lab_runs", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  config: jsonb("config").$type<Record<string, unknown>>().notNull(),
  summary: jsonb("summary").$type<Record<string, unknown>>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
