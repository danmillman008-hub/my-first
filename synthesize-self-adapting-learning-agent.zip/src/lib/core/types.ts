// Shared, storage-agnostic types for the learner model.

export const STRATEGIES = [
  "direct_explanation",
  "worked_example",
  "analogy",
  "step_by_step",
  "socratic",
  "hands_on_task",
  "concise_summary",
] as const;
export type Strategy = (typeof STRATEGIES)[number];

export const STRATEGY_LABEL: Record<Strategy, string> = {
  direct_explanation: "direct explanation",
  worked_example: "worked example",
  analogy: "analogy",
  step_by_step: "step-by-step walkthrough",
  socratic: "guiding questions",
  hands_on_task: "hands-on task",
  concise_summary: "concise summary",
};

export type ObservationKind =
  | "statement"
  | "question"
  | "self_report"
  | "success"
  | "mistake"
  | "reaction"
  | "request"
  | "topic_switch"
  | "correction"
  | "code_shared"
  | "context"
  | "goal";

export type ObservationSource = "learner" | "model" | "external" | "system";

export interface Observation {
  id: string;
  learnerId: string;
  sessionId: string;
  turnId: string | null;
  kind: ObservationKind;
  content: string;
  domain: string | null;
  concepts: string[];
  signals: Record<string, unknown>;
  source: ObservationSource;
  dedupeKey: string | null;
  createdAt: Date;
}

export type BeliefKind = "preference" | "strategy_fit" | "tendency" | "goal" | "context";
export type BeliefStatus = "candidate" | "active" | "contested" | "dormant" | "retired";
export type BeliefSource = "stated" | "inferred" | "external";

export interface Belief {
  id: string;
  learnerId: string;
  kind: BeliefKind;
  key: string;
  statement: string;
  domain: string | null;
  concepts: string[];
  source: BeliefSource;
  polarity: 1 | -1;
  status: BeliefStatus;
  confidence: number;
  supportCount: number;
  contradictionCount: number;
  sessionIds: string[];
  validFrom: Date;
  invalidAt: Date | null;
  invalidReason: string | null;
  supersededBy: string | null;
  lastConfirmedAt: Date;
  createdAt: Date;
  updatedAt: Date;
}

export type EvidenceRelation = "supports" | "contradicts" | "correction";
export interface BeliefEvidence {
  id: string;
  beliefId: string;
  observationId: string;
  relation: EvidenceRelation;
  createdAt: Date;
}

export interface ConceptState {
  id: string;
  learnerId: string;
  concept: string;
  domain: string;
  pKnown: number;
  basis: "prior" | "claimed" | "demonstrated";
  attempts: number;
  successes: number;
  claimedLevel: number | null;
  claimedAt: Date | null;
  lastEvidenceAt: Date;
}

export type OutcomeSignal = "reaction" | "task" | "mixed" | "request";
export interface StrategyOutcome {
  id: string;
  learnerId: string;
  sessionId: string;
  tutorTurnId: string;
  strategy: Strategy;
  domain: string;
  concept: string | null;
  outcome: number; // -1..1
  weight: number; // 0..1 attribution weight
  signal: OutcomeSignal;
  createdAt: Date;
}

export interface Turn {
  id: string;
  learnerId: string;
  sessionId: string;
  role: "learner" | "tutor";
  content: string;
  strategy: Strategy | null;
  domain: string | null;
  concept: string | null;
  probe: boolean;
  meta: Record<string, unknown>;
  createdAt: Date;
}

export interface Session {
  id: string;
  learnerId: string;
  startedAt: Date;
  lastActiveAt: Date;
  domain: string | null;
  concept: string | null;
  summary: string | null;
  turnCount: number;
  probeCount: number;
}

export interface Trace {
  id: string;
  learnerId: string;
  sessionId: string;
  turnId: string | null;
  kind: string;
  payload: Record<string, unknown>;
  createdAt: Date;
}

export interface Learner {
  id: string;
  name: string | null;
  createdAt: Date;
}

export interface ResearchNote {
  topic: string;
  summary: string;
  sourceUrl: string | null;
  provider: string;
  fetchedAt: Date;
}

export type Ablation =
  | "none"
  | "no_long_term" // beliefs are not created or used
  | "no_adaptation" // fixed strategy
  | "no_drift" // no discounting of old outcomes
  | "no_hierarchy" // no shrunk global prior across domains
  | "no_correction" // learner corrections ignored
  | "no_probe";

export type Policy = "ucb" | "thompson";

export interface EngineOptions {
  ablation?: Ablation;
  policy?: Policy;
  seed?: number;
  sessionGapMs?: number;
}

export interface BeliefView extends Belief {
  influence: number;
  evidence: { supports: string[]; contradicts: string[]; correction: string[] };
}

export interface TurnContext {
  learnerId: string;
  session: Session;
  isNewSession: boolean;
  gapMs: number | null;
  domain: string;
  concept: string | null;
  beliefs: BeliefView[];
  concepts: ConceptState[];
  recentObservations: Observation[];
  recentTurns: Turn[];
  previousSessionSummary: string | null;
  research: ResearchNote | null;
}
