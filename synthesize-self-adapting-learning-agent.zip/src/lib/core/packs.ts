// Compact seed knowledge. Each concept carries a teaching kernel and one check
// question with acceptable answer tokens. Unknown domains are researched.
import type { Strategy } from "./types";

export interface Concept {
  id: string;
  label: string;
  kernel: string;
  analogy: string;
  example: string;
  steps: string[];
  task: string;
  check: { question: string; accept: string[] };
  keywords: string[];
}

export interface Pack {
  domain: string;
  label: string;
  keywords: string[];
  concepts: Concept[];
}

export const PACKS: Pack[] = [
  {
    domain: "bash",
    label: "Bash",
    keywords: ["bash", "shell", "terminal", "script", "grep", "pipe", "chmod", "stdin", "stdout"],
    concepts: [
      { id: "variables", label: "shell variables", kernel: "A shell variable is assigned with NAME=value (no spaces) and read with $NAME.", analogy: "a labelled jar: you put a value in once and read the label later", example: 'name="Ada"; echo "Hello $name"', steps: ["write NAME=value with no spaces", "read it with $NAME", "quote it when expanding"], task: "Create a variable holding your name and echo it inside a greeting.", check: { question: "How do you read the value of a variable called count?", accept: ["$count", "${count}"] }, keywords: ["variable", "assign", "export", "$"] },
      { id: "quoting", label: "quoting", kernel: "Double quotes allow $expansion but keep the result as one word; single quotes are literal.", analogy: "double quotes are a window (you can see through to variables), single quotes are a wall", example: 'f="my file.txt"; cat "$f"   # works;   cat $f   # splits into two words', steps: ["decide whether you want expansion", "use double quotes for expansion", "use single quotes to keep text literal"], task: "Make a variable containing a space and cat that file safely.", check: { question: "Which quotes still expand $variables: single or double?", accept: ["double"] }, keywords: ["quote", "quoting", "word splitting", "literal"] },
      { id: "pipes", label: "pipes", kernel: "A pipe | sends the standard output of one command into the standard input of the next.", analogy: "a factory conveyor belt: each station transforms what it receives", example: "cat access.log | grep 404 | wc -l", steps: ["run the producer command", "add | and a consumer", "chain as many filters as needed"], task: "Count the lines containing ERROR in a log file using a pipe.", check: { question: "Which stream of the first command does a pipe connect to the second command?", accept: ["stdout", "standard output", "output"] }, keywords: ["pipe", "|", "stream", "redirect"] },
      { id: "loops", label: "for loops", kernel: "for x in list; do ...; done runs the body once per item.", analogy: "dealing cards: one card per player until the deck is empty", example: 'for f in *.txt; do echo "$f"; done', steps: ["write for name in items", "open with do", "close with done"], task: "Print the size of every .log file in the current directory.", check: { question: "Which keyword closes a for loop body in bash?", accept: ["done"] }, keywords: ["loop", "for", "while", "iterate"] },
      { id: "exit-codes", label: "exit codes", kernel: "Every command returns an exit status: 0 means success; $? holds the last status.", analogy: "a receipt: 0 means the purchase went through", example: "grep foo file.txt; echo $?", steps: ["run a command", "inspect $? immediately", "branch with if or &&/||"], task: "Write a one-liner that prints ok only if mkdir succeeds.", check: { question: "Which exit status means success?", accept: ["0", "zero"] }, keywords: ["exit", "status", "$?", "&&", "||"] },
      { id: "functions", label: "shell functions", kernel: "name() { ...; } defines a function; arguments arrive as $1, $2 ...", analogy: "a recipe card you can reuse with different ingredients", example: 'greet() { echo "hi $1"; }; greet Ada', steps: ["write name() {", "use $1 for the first argument", "close with }"], task: "Write a function that prints its first two arguments in reverse order.", check: { question: "How do you access the first argument inside a bash function?", accept: ["$1"] }, keywords: ["function", "argument", "$1"] },
    ],
  },
  {
    domain: "python",
    label: "Python",
    keywords: ["python", "def ", "list", "dict", "pip", "import", "lambda", "recursion", "comprehension"],
    concepts: [
      { id: "lists", label: "lists", kernel: "A list is an ordered, mutable sequence; index from 0, slice with [a:b].", analogy: "a row of numbered lockers", example: "xs = [3, 1, 2]; xs.append(5); xs[0]  # 3", steps: ["create with []", "index with xs[i]", "mutate with append/insert"], task: "Reverse a list without using reversed().", check: { question: "What index does the first element of a Python list have?", accept: ["0", "zero"] }, keywords: ["list", "append", "index", "slice"] },
      { id: "dicts", label: "dictionaries", kernel: "A dict maps keys to values with O(1) average lookup; keys must be hashable.", analogy: "a phone book: look up a name, get a number", example: "ages = {'ada': 36}; ages['ada']", steps: ["create with {}", "read with d[key] or d.get(key)", "iterate with .items()"], task: "Count word frequencies in a sentence with a dict.", check: { question: "Which method returns None instead of raising KeyError for a missing key?", accept: ["get", ".get"] }, keywords: ["dict", "dictionary", "key", "hash"] },
      { id: "functions", label: "functions", kernel: "def name(params): defines a function; return sends a value back.", analogy: "a vending machine: input coins, get a snack", example: "def area(w, h): return w * h", steps: ["write def name(params):", "indent the body", "return a value"], task: "Write a function that returns the larger of two numbers without max().", check: { question: "Which keyword sends a value back from a Python function?", accept: ["return"] }, keywords: ["function", "def", "return", "parameter"] },
      { id: "recursion", label: "recursion", kernel: "A recursive function calls itself on a smaller input and needs a base case to stop.", analogy: "Russian dolls: open one, find a smaller one, until the tiniest", example: "def fact(n): return 1 if n <= 1 else n * fact(n - 1)", steps: ["identify the base case", "define the smaller subproblem", "combine the result"], task: "Write a recursive function that sums a list.", check: { question: "What must every recursive function have to terminate?", accept: ["base case", "base"] }, keywords: ["recursion", "recursive", "base case", "stack"] },
      { id: "comprehensions", label: "comprehensions", kernel: "[f(x) for x in xs if cond] builds a list in one expression.", analogy: "a sieve and a stamp: filter, then transform", example: "[x * x for x in range(5) if x % 2 == 0]", steps: ["start with the output expression", "add for x in iterable", "optionally add if condition"], task: "Build a list of the lengths of words longer than three letters.", check: { question: "In [x*2 for x in xs if x > 0], which part filters?", accept: ["if", "if x > 0", "condition"] }, keywords: ["comprehension", "generator"] },
      { id: "classes", label: "classes", kernel: "class defines a type; __init__ sets up instance state; self refers to the instance.", analogy: "a blueprint versus the houses built from it", example: "class Dog:\n  def __init__(self, name): self.name = name", steps: ["write class Name:", "define __init__(self, ...)", "store state on self"], task: "Write a Counter class with increment and value methods.", check: { question: "What is the conventional name of the first parameter of an instance method?", accept: ["self"] }, keywords: ["class", "self", "__init__", "method", "object"] },
    ],
  },
  {
    domain: "oop",
    label: "Object-oriented programming",
    keywords: ["oop", "object-oriented", "object oriented", "inheritance", "polymorphism", "encapsulation", "interface", "composition"],
    concepts: [
      { id: "classes-objects", label: "classes and objects", kernel: "A class describes structure and behaviour; an object is one instance with its own state.", analogy: "cookie cutter and cookies", example: "class Account { balance = 0 }; const a = new Account();", steps: ["define the class", "instantiate objects", "each object keeps its own fields"], task: "Model a bank account with deposit and withdraw.", check: { question: "Is a class or an object the runtime instance?", accept: ["object", "instance"] }, keywords: ["class", "object", "instance"] },
      { id: "encapsulation", label: "encapsulation", kernel: "Encapsulation hides internal state behind methods so invariants cannot be broken from outside.", analogy: "a vending machine: buttons, not wires", example: "private balance; deposit(x) { if (x > 0) this.balance += x }", steps: ["make fields private", "expose intent-revealing methods", "validate inside them"], task: "Refactor a class with public fields so balance can never go negative.", check: { question: "What visibility keeps a field hidden from outside the class?", accept: ["private"] }, keywords: ["encapsulation", "private", "getter", "invariant"] },
      { id: "inheritance", label: "inheritance", kernel: "A subclass extends a base class, reusing and specialising its behaviour (is-a relation).", analogy: "a family tree of traits", example: "class Dog extends Animal { speak() { return 'woof' } }", steps: ["identify the shared base", "extend it", "override what differs"], task: "Create Shape with area(), and Circle and Square subclasses.", check: { question: "Which relationship does inheritance express: is-a or has-a?", accept: ["is-a", "is a"] }, keywords: ["inheritance", "extends", "subclass", "base class", "override"] },
      { id: "polymorphism", label: "polymorphism", kernel: "Polymorphism lets code call the same method on different types and get type-specific behaviour.", analogy: "a universal remote: one play button, many devices", example: "for (const s of shapes) total += s.area();", steps: ["define a common method", "implement per type", "call through the common interface"], task: "Compute the total area of a mixed list of shapes.", check: { question: "Which mechanism picks the implementation at run time based on the object's type?", accept: ["dynamic dispatch", "dispatch", "late binding", "polymorphism", "override"] }, keywords: ["polymorphism", "dispatch", "virtual"] },
      { id: "composition", label: "composition", kernel: "Composition builds objects from other objects (has-a) and is usually more flexible than inheritance.", analogy: "LEGO bricks rather than a family tree", example: "class Car { engine = new Engine() }", steps: ["identify the part", "hold it as a field", "delegate to it"], task: "Replace a deep inheritance chain with composed behaviours.", check: { question: "Which relationship does composition express: is-a or has-a?", accept: ["has-a", "has a"] }, keywords: ["composition", "has-a", "delegate"] },
      { id: "interfaces", label: "interfaces", kernel: "An interface is a contract of methods without implementation; classes promise to fulfil it.", analogy: "a job description: what you must be able to do, not how", example: "interface Printable { print(): string }", steps: ["list required methods", "declare the interface", "implement it in classes"], task: "Define a Serializable interface and implement it twice.", check: { question: "Does an interface contain method implementations?", accept: ["no", "not"] }, keywords: ["interface", "contract", "abstract"] },
    ],
  },
  {
    domain: "sql",
    label: "SQL",
    keywords: ["sql", "select", "join", "postgres", "query", "table", "index", "group by"],
    concepts: [
      { id: "select", label: "SELECT", kernel: "SELECT columns FROM table WHERE condition returns matching rows.", analogy: "asking a librarian for books matching a description", example: "SELECT name FROM users WHERE age > 30;", steps: ["choose columns", "name the table", "filter with WHERE"], task: "Select the emails of users created this year.", check: { question: "Which clause filters rows in a SELECT?", accept: ["where"] }, keywords: ["select", "where", "from"] },
      { id: "joins", label: "joins", kernel: "A JOIN combines rows from two tables on a matching condition; INNER keeps matches only, LEFT keeps all left rows.", analogy: "matching socks from two drawers", example: "SELECT o.id, u.name FROM orders o JOIN users u ON u.id = o.user_id;", steps: ["pick the join key", "choose INNER vs LEFT", "write ON condition"], task: "List every user and their order count, including users with no orders.", check: { question: "Which join keeps rows from the left table that have no match?", accept: ["left", "left join", "left outer"] }, keywords: ["join", "inner", "left", "on"] },
      { id: "group-by", label: "GROUP BY", kernel: "GROUP BY collapses rows sharing a value so aggregates like COUNT apply per group.", analogy: "sorting coins into piles and counting each pile", example: "SELECT country, COUNT(*) FROM users GROUP BY country;", steps: ["choose the grouping column", "add an aggregate", "filter groups with HAVING"], task: "Find countries with more than 100 users.", check: { question: "Which clause filters groups after aggregation?", accept: ["having"] }, keywords: ["group", "aggregate", "count", "having"] },
      { id: "indexes", label: "indexes", kernel: "An index is a sorted structure that makes lookups on a column fast at the cost of slower writes.", analogy: "the index at the back of a book", example: "CREATE INDEX users_email_idx ON users(email);", steps: ["find slow WHERE/JOIN columns", "create the index", "verify with EXPLAIN"], task: "Speed up a query filtering orders by customer_id.", check: { question: "Do indexes make writes faster or slower?", accept: ["slower"] }, keywords: ["index", "explain", "b-tree"] },
      { id: "transactions", label: "transactions", kernel: "A transaction groups statements so they all commit or all roll back (atomicity).", analogy: "a bank transfer: debit and credit happen together or not at all", example: "BEGIN; UPDATE a ...; UPDATE b ...; COMMIT;", steps: ["BEGIN", "run statements", "COMMIT or ROLLBACK"], task: "Transfer money between two accounts safely.", check: { question: "Which statement undoes an open transaction?", accept: ["rollback"] }, keywords: ["transaction", "commit", "rollback", "atomic"] },
    ],
  },
];

export function findPack(domain: string): Pack | undefined {
  return PACKS.find((p) => p.domain === domain);
}

export function findConcept(domain: string, id: string): Concept | undefined {
  return findPack(domain)?.concepts.find((c) => c.id === id);
}

export function detectDomain(text: string): string | null {
  const t = text.toLowerCase();
  let best: { domain: string; score: number } | null = null;
  for (const p of PACKS) {
    let score = 0;
    for (const k of p.keywords) if (t.includes(k)) score += k.length > 4 ? 2 : 1;
    for (const c of p.concepts) if (t.includes(c.label.toLowerCase())) score += 2;
    if (score > 0 && (!best || score > best.score)) best = { domain: p.domain, score };
  }
  return best?.domain ?? null;
}

export function detectConcepts(domain: string | null, text: string): string[] {
  const pack = domain ? findPack(domain) : undefined;
  if (!pack) return [];
  const t = text.toLowerCase();
  return pack.concepts.filter((c) => t.includes(c.label.toLowerCase()) || c.keywords.some((k) => k.length > 2 && t.includes(k.toLowerCase()))).map((c) => c.id);
}

export const REQUEST_PATTERNS: { strategy: Strategy; re: RegExp }[] = [
  { strategy: "worked_example", re: /\b(show me|give me|can i see|see|want|prefer|need)?\s*(an?|some|concrete|another)?\s*(worked\s+)?examples?\b/i },
  { strategy: "analogy", re: /\b(analogy|metaphor|compare it to|like in real life)\b/i },
  { strategy: "step_by_step", re: /\b(step[- ]by[- ]step|walk me through|one step at a time|break it down)\b/i },
  { strategy: "socratic", re: /\b(quiz me|ask me questions|let me figure it out|guide me with questions)\b/i },
  { strategy: "hands_on_task", re: /\b(exercise|practice|hands[- ]on|let me try|give me a task|challenge me)\b/i },
  { strategy: "concise_summary", re: /\b(shorter|briefly|concise|tl;?dr|just the summary|in one sentence|too long)\b/i },
  { strategy: "direct_explanation", re: /\b(just explain|explain it directly|the theory|stop asking me questions|tell me directly|just tell me)\b/i },
];
