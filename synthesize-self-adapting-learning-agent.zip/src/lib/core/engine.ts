// The agent loop: perceive -> attribute previous turn -> record evidence ->
// update concepts & beliefs -> retrieve context -> (research) -> select strategy
// -> compose -> trace. Deterministic code owns every invariant; providers only
// interpret language and write prose.
import { perceive, type Perception, type ObservationDraft } from "./perceive";
import { attribute, applyClaim, applyContradiction, applySupport, applyTaskResult, discrepancy, effectiveStatus, influenceOf, PREF_STATEMENT, retirePatch, retainedPKnown, statusFor, confidenceFor } from "./model";
import { decideProbe, mulberry32, selectStrategy } from "./bandit";
import { findPack, type Concept } from "./packs";
import { STRATEGIES, STRATEGY_LABEL, type Belief, type BeliefView, type ConceptState, type EngineOptions, type Observation, type Session, type Strategy, type StrategyOutcome, type Turn, type TurnContext } from "./types";
import type { Store } from "./store";
import type { Provider } from "../providers";
import { researchTopic, type ResearchFn } from "../research";

export interface EngineDeps {
  store: Store;
  provider: Provider;
  research?: ResearchFn | null;
  idFn?: () => string;
}

export interface TurnResult {
  reply: string;
  strategy: Strategy;
  domain: string;
  concept: string | null;
  probe: boolean;
  sessionId: string;
  isNewSession: boolean;
  turnId: string;
  perception: Perception;
  attribution: { strategy: Strategy; outcome: number; weight: number; signal: string; reasons: string[] } | null;
  selection: { reasons: string[]; source: string; posterior: Record<string, number> };
  changes: { created: string[]; supported: string[]; contradicted: string[]; retired: string[] };
}

let counter = 0;
const defaultId = () => `${Date.now().toString(36)}${(counter++).toString(36)}${Math.random().toString(36).slice(2, 8)}`;

const OPPOSITE: Partial<Record<Strategy, Strategy[]>> = {
  socratic: ["direct_explanation"],
  direct_explanation: ["socratic"],
  concise_summary: ["step_by_step"],
  step_by_step: ["concise_summary"],
};

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40);

export class Engine {
  private store: Store;
  private provider: Provider;
  private research: ResearchFn | null;
  private id: () => string;
  private rnd: () => number;
  private opts: Required<Pick<EngineOptions, "ablation" | "policy" | "sessionGapMs">>;

  constructor(deps: EngineDeps, opts: EngineOptions = {}) {
    this.store = deps.store;
    this.provider = deps.provider;
    this.research = deps.research ?? null;
    this.id = deps.idFn ?? defaultId;
    this.rnd = opts.seed != null ? mulberry32(opts.seed) : Math.random;
    this.opts = { ablation: opts.ablation ?? "none", policy: opts.policy ?? "ucb", sessionGapMs: opts.sessionGapMs ?? 45 * 60_000 };
  }

  // -------------------------------------------------------------------------
  async turn(learnerId: string, message: string, now: Date = new Date()): Promise<TurnResult> {
    const { store } = this;
    const ab = this.opts.ablation;
    await store.ensureLearner(learnerId);
    const changes = { created: [] as string[], supported: [] as string[], contradicted: [] as string[], retired: [] as string[] };

    // 1. Session continuity is inferred from time, never managed by the learner.
    let session = await store.latestSession(learnerId);
    const gapMs = session ? now.getTime() - session.lastActiveAt.getTime() : null;
    const isNewSession = !session || gapMs! > this.opts.sessionGapMs;
    let previousSessionSummary: string | null = null;
    if (isNewSession) {
      if (session) {
        previousSessionSummary = session.summary ?? summarise(session);
        await store.updateSession(session.id, { summary: previousSessionSummary });
      }
      session = { id: this.id(), learnerId, startedAt: now, lastActiveAt: now, domain: session?.domain ?? null, concept: null, summary: null, turnCount: 0, probeCount: 0 };
      await store.createSession(session);
    } else {
      const prev = (await store.listSessions(learnerId, 2))[1];
      previousSessionSummary = prev?.summary ?? null;
    }
    const sessionTurns = isNewSession ? [] : await store.listTurns(session!.id, 30);
    const prevTutor = [...sessionTurns].reverse().find((t) => t.role === "tutor") ?? null; // the exact turn we attribute to

    // 2. Perception (deterministic first; model may enrich, never override safety-net fields).
    const perception = perceive(message, prevTutor, session!.domain);
    if (this.provider.online) {
      const pack = findPack(perception.domain ?? session!.domain ?? "");
      const patch = await this.provider.perceive({ message, previousTutor: prevTutor, domain: perception.domain ?? "general", knownConcepts: pack?.concepts.map((c) => c.id) ?? [] });
      if (patch) {
        if (perception.reaction === "neutral" && patch.reaction) perception.reaction = patch.reaction;
        if (!perception.requestStrategy && patch.requestStrategy) perception.requestStrategy = patch.requestStrategy;
        if (!perception.selfReport && patch.selfReport) perception.selfReport = patch.selfReport;
        if (!perception.correction && patch.correction) perception.correction = patch.correction;
        if (!perception.goal && patch.goal) perception.goal = patch.goal;
        for (const o of patch.observations ?? []) perception.observations.push(o);
      }
    }
    let domain = perception.domain ?? session!.domain ?? null;
    if (!domain && perception.goal) domain = slug(perception.goal) || "general";
    if (!domain) domain = "general";
    const topicSwitch = Boolean(session!.domain && domain !== session!.domain);

    // 3. Attribute the learner's response to the PREVIOUS tutor turn (before selecting a new one).
    let attribution: TurnResult["attribution"] = null;
    const conceptStates = await store.listConcepts(learnerId);
    const cs = (concept: string) => conceptStates.find((c) => c.concept === concept && c.learnerId === learnerId);
    if (prevTutor && prevTutor.strategy && prevTutor.domain && !prevTutor.probe) {
      const prior = prevTutor.concept ? cs(prevTutor.concept) : undefined;
      const a = attribute({
        reaction: perception.reaction,
        taskResult: perception.taskResult,
        requestedDifferentStrategy: Boolean(perception.requestStrategy && perception.requestStrategy !== prevTutor.strategy),
        isCorrection: Boolean(perception.correction),
        topicSwitch,
        priorPKnown: prior ? retainedPKnown(prior, now) : null,
      });
      if (a) {
        const row: StrategyOutcome = { id: this.id(), learnerId, sessionId: session!.id, tutorTurnId: prevTutor.id, strategy: prevTutor.strategy, domain: prevTutor.domain, concept: prevTutor.concept, outcome: a.outcome, weight: a.weight, signal: a.signal, createdAt: now };
        await store.insertOutcome(row);
        attribution = { strategy: prevTutor.strategy, outcome: a.outcome, weight: a.weight, signal: a.signal, reasons: a.reasons };
      }
    }

    // 4. Record the learner turn and observations (short-term evidence, deduped per session).
    const learnerTurn: Turn = { id: this.id(), learnerId, sessionId: session!.id, role: "learner", content: message, strategy: null, domain, concept: null, probe: false, meta: {}, createdAt: now };
    await store.insertTurn(learnerTurn);
    const stored: { obs: Observation; draft: ObservationDraft }[] = [];
    for (const d of perception.observations) {
      if (d.dedupeKey && (await store.hasObservation(session!.id, d.dedupeKey))) continue;
      const obs: Observation = { id: this.id(), learnerId, sessionId: session!.id, turnId: learnerTurn.id, kind: d.kind, content: d.content, domain, concepts: d.concepts, signals: d.signals, source: d.signals.model ? "model" : "learner", dedupeKey: d.dedupeKey, createdAt: now };
      await store.insertObservation(obs);
      stored.push({ obs, draft: d });
    }
    const obsOf = (kind: string) => stored.find((s) => s.obs.kind === kind)?.obs ?? null;

    // 5. Concept states: behaviour channel and self-report channel.
    const pack = findPack(domain);
    const currentConcept = perception.concepts[0] ?? session!.concept ?? null;
    const check = prevTutor?.meta?.check as { concept: string } | undefined;
    if (perception.taskResult && check) {
      const c = cs(check.concept) ?? newConcept(learnerId, check.concept, prevTutor!.domain ?? domain, now);
      const patched = { ...c, ...applyTaskResult(c, perception.taskResult === "correct", now) };
      await store.upsertConcept(patched);
      replace(conceptStates, patched);
    }
    if (perception.selfReport) {
      const targets = perception.selfReport.concepts.length ? perception.selfReport.concepts : pack ? (currentConcept ? [currentConcept] : pack.concepts.map((c) => c.id)) : [];
      for (const id of targets) {
        const c = cs(id) ?? newConcept(learnerId, id, domain, now);
        const patched = { ...c, ...applyClaim(c, perception.selfReport.level, now) };
        await store.upsertConcept(patched);
        replace(conceptStates, patched);
      }
    }

    // 6. Long-term beliefs.
    let beliefs = ab === "no_long_term" ? [] : await store.listBeliefs(learnerId, true);
    if (ab !== "no_long_term") {
      const corrObs = obsOf("correction");
      if (perception.correction && corrObs && ab !== "no_correction") {
        const targets = matchCorrection(perception.correction, beliefs.filter((b) => b.status !== "retired"));
        for (const target of targets) {
          if (target.status === "retired") continue;
          await this.retire(target, corrObs.id, now, `learner correction: ${perception.correction.slice(0, 140)}`, null, changes, beliefs);
          for (const sib of beliefs.filter((b) => b.key === target.key && b.id !== target.id && b.status !== "retired")) await this.retire(sib, corrObs.id, now, `learner correction (shared key ${target.key})`, null, changes, beliefs);
        }
        if (targets.length) await store.insertTrace({ id: this.id(), learnerId, sessionId: session!.id, turnId: learnerTurn.id, kind: "correction", payload: { beliefs: targets.map((t) => t.id), statements: targets.map((t) => t.statement) }, createdAt: now });
      }
      const goalObs = obsOf("goal");
      if (perception.goal && goalObs) await this.upsert({ learnerId, kind: "goal", key: `goal:${slug(perception.goal)}`, statement: `Goal: ${perception.goal}`, domain: null, concepts: [], source: "stated", polarity: 1 }, goalObs.id, session!.id, now, changes, beliefs);
      const reqObs = obsOf("request");
      if (perception.requestStrategy && reqObs) {
        const s = perception.requestStrategy;
        await this.upsert({ learnerId, kind: "preference", key: `pref:${s}`, statement: PREF_STATEMENT[s], domain, concepts: [s], source: "inferred", polarity: 1 }, reqObs.id, session!.id, now, changes, beliefs);
        for (const opp of OPPOSITE[s] ?? []) {
          const b = beliefs.find((x) => x.key === `pref:${opp}` && x.domain === domain && x.status !== "retired" && x.polarity === 1);
          if (b) await this.contradict(b, reqObs.id, now, `asked for ${STRATEGY_LABEL[s]} instead`, changes, beliefs);
        }
      }
      // Self-report vs behaviour: a durable discrepancy becomes an observed tendency; alignment retires it.
      const ev = obsOf("success") ?? obsOf("mistake");
      if (ev && check) {
        const c = cs(check.concept);
        const d = c ? discrepancy(c) : null;
        if (d === "overclaims" || d === "underclaims") {
          await this.upsert({ learnerId, kind: "tendency", key: `tend:${d}`, statement: d === "overclaims" ? "Self-assessment tends to run ahead of demonstrated ability" : "Self-assessment tends to run behind demonstrated ability", domain: c!.domain, concepts: [c!.concept], source: "inferred", polarity: 1 }, ev.id, session!.id, now, changes, beliefs);
        } else if (d === "aligned") {
          for (const b of beliefs.filter((x) => x.kind === "tendency" && x.domain === c!.domain && x.status !== "retired")) await this.contradict(b, ev.id, now, "self-report and behaviour agree again", changes, beliefs);
        }
      }
      // Strategy fit derived from attributed outcomes, strictly per domain, only from post-correction data.
      if (attribution) await this.deriveFit(learnerId, session!.id, prevTutor!.domain!, now, changes, beliefs, ev?.id ?? obsOf("reaction")?.id ?? learnerTurn.id);
      beliefs = await store.listBeliefs(learnerId, true);
    }

    // 7. Retrieval: rank by influence, scope to the current domain, keep it small.
    const live = beliefs.filter((b) => b.status !== "retired");
    const views = await this.views(live, now, domain);
    const outcomes = await store.listOutcomes(learnerId);
    const recentObservations = await store.listObservations(learnerId, 8);
    const research = !pack && domain !== "general" ? await researchTopic(store, domain, this.research, now) : null;
    const ctx: TurnContext = { learnerId, session: session!, isNewSession, gapMs, domain, concept: currentConcept, beliefs: views.slice(0, 12), concepts: conceptStates.filter((c) => c.domain === domain), recentObservations, recentTurns: sessionTurns.slice(-10), previousSessionSummary, research };

    // 8. Strategy selection (after attribution, so adaptation is never one turn late).
    const recentRequest = sessionTurns.length ? await this.recentRequest(learnerId, session!.id, domain, now) : null;
    let consecutiveBad = 0;
    if (prevTutor?.strategy) {
      for (const o of [...outcomes].reverse()) {
        if (o.domain !== domain || o.strategy !== prevTutor.strategy) continue;
        if (o.outcome <= -0.3 && o.weight >= 0.5) consecutiveBad++;
        else break;
      }
    }
    const selection = selectStrategy({
      outcomes,
      domain,
      beliefs: ab === "no_long_term" ? [] : live,
      currentStrategy: prevTutor?.strategy ?? null,
      lastOutcome: attribution?.outcome ?? null,
      lastWeight: attribution?.weight ?? null,
      now,
      rnd: this.rnd,
      policy: this.opts.policy,
      ablation: ab,
      requested: perception.requestStrategy,
      recentRequest: perception.requestStrategy ? null : recentRequest,
      consecutiveBad,
    });
    const lastProbe = await store.lastProbeTurn(learnerId);
    const probe = decideProbe({ posterior: selection.posterior, sessionTurn: session!.turnCount, sessionProbes: session!.probeCount, turnsSinceLastProbe: lastProbe ? await store.countTurnsSince(learnerId, lastProbe.createdAt) : null, requested: Boolean(perception.requestStrategy || perception.correction), ablation: ab });

    // 9. Concept choice: stay on a concept while it is not yet known; otherwise advance.
    const concept = chooseConcept(pack?.concepts ?? [], currentConcept, perception, conceptStates, now);

    // 10. Compose and record the tutor turn.
    const out = await this.provider.compose({ message, context: ctx, strategy: selection.strategy, concept, domainLabel: pack?.label ?? domain.replace(/-/g, " "), probe: probe.probe ? { options: probe.options! } : null, perception, research, now });
    const tutorTurn: Turn = { id: this.id(), learnerId, sessionId: session!.id, role: "tutor", content: out.reply, strategy: selection.strategy, domain, concept: concept?.id ?? null, probe: probe.probe, meta: { check: out.check, options: probe.options, reasons: selection.reasons, source: selection.source }, createdAt: new Date(now.getTime() + 1) };
    await store.insertTurn(tutorTurn);
    const posteriorMeans = Object.fromEntries(STRATEGIES.map((s) => [s, Number(selection.posterior[s].mean.toFixed(3))]));
    await store.insertTrace({ id: this.id(), learnerId, sessionId: session!.id, turnId: tutorTurn.id, kind: "strategy_selection", payload: { strategy: selection.strategy, source: selection.source, reasons: selection.reasons, posterior: posteriorMeans, probe: probe.probe ? probe.reason : null, attribution, changes }, createdAt: now });
    await store.updateSession(session!.id, { lastActiveAt: now, domain, concept: concept?.id ?? currentConcept, turnCount: session!.turnCount + 1, probeCount: session!.probeCount + (probe.probe ? 1 : 0) });

    return { reply: out.reply, strategy: selection.strategy, domain, concept: concept?.id ?? null, probe: probe.probe, sessionId: session!.id, isNewSession, turnId: tutorTurn.id, perception, attribution, selection: { reasons: selection.reasons, source: selection.source, posterior: posteriorMeans }, changes };
  }

  // -------------------------------------------------------------------------
  // Public model access (UI, API, MCP)
  // -------------------------------------------------------------------------
  async model(learnerId: string, now: Date = new Date(), domain: string | null = null) {
    const all = await this.store.listBeliefs(learnerId, true);
    const views = await this.views(all, now, domain ?? (await this.store.latestSession(learnerId))?.domain ?? null);
    const concepts = (await this.store.listConcepts(learnerId)).map((c) => ({ ...c, pKnownNow: retainedPKnown(c, now), discrepancy: discrepancy(c) }));
    const sessions = await this.store.listSessions(learnerId, 5);
    const observations = await this.store.listObservations(learnerId, 30);
    const traces = await this.store.listTraces(learnerId, 10);
    return { beliefs: views, concepts, sessions, observations, traces };
  }

  /** "That's not true about me." Retire (evidence kept), optionally record what is true instead. */
  async challengeBelief(learnerId: string, beliefId: string, replacement: string | null, now: Date = new Date()) {
    const b = await this.store.getBelief(beliefId);
    if (!b || b.learnerId !== learnerId) return { ok: false as const, error: "belief not found" };
    if (b.status === "retired") return { ok: true as const, retired: b.id, replacement: b.supersededBy };
    const session = (await this.store.latestSession(learnerId)) ?? (await this.newSession(learnerId, now));
    const obs: Observation = { id: this.id(), learnerId, sessionId: session.id, turnId: null, kind: "correction", content: replacement ? `Not true: "${b.statement}". Instead: ${replacement}` : `Not true: "${b.statement}"`, domain: b.domain, concepts: b.concepts, signals: { beliefId }, source: "learner", dedupeKey: null, createdAt: now };
    await this.store.insertObservation(obs);
    let replacementId: string | null = null;
    if (replacement) {
      replacementId = this.id();
      const nb: Belief = { id: replacementId, learnerId, kind: b.kind, key: b.key, statement: replacement, domain: b.domain, concepts: b.concepts, source: "stated", polarity: b.polarity === 1 ? -1 : 1, status: "active", confidence: 0.85, supportCount: 1, contradictionCount: 0, sessionIds: [session.id], validFrom: now, invalidAt: null, invalidReason: null, supersededBy: null, lastConfirmedAt: now, createdAt: now, updatedAt: now };
      await this.store.insertBelief(nb);
      await this.store.insertEvidence({ id: this.id(), beliefId: replacementId, observationId: obs.id, relation: "supports", createdAt: now });
    }
    const changes = { created: [] as string[], supported: [] as string[], contradicted: [] as string[], retired: [] as string[] };
    const beliefs = await this.store.listBeliefs(learnerId, true);
    await this.retire(b, obs.id, now, "learner correction: challenged via memory panel", replacementId, changes, beliefs);
    for (const sib of beliefs.filter((x) => x.key === b.key && x.id !== b.id && x.status !== "retired" && x.id !== replacementId)) await this.retire(sib, obs.id, now, `learner correction (shared key ${b.key})`, replacementId, changes, beliefs);
    await this.store.insertTrace({ id: this.id(), learnerId, sessionId: session.id, turnId: null, kind: "correction", payload: { belief: b.id, replacement: replacementId }, createdAt: now });
    return { ok: true as const, retired: b.id, replacement: replacementId };
  }

  /** External evidence (MCP). It enters as an observation and must earn belief status like anything else. */
  async recordObservation(learnerId: string, kind: Observation["kind"], content: string, domain: string | null, concepts: string[], now: Date = new Date()) {
    await this.store.ensureLearner(learnerId);
    const session = (await this.store.latestSession(learnerId)) ?? (await this.newSession(learnerId, now));
    const obs: Observation = { id: this.id(), learnerId, sessionId: session.id, turnId: null, kind, content: content.slice(0, 500), domain, concepts, signals: { external: true }, source: "external", dedupeKey: null, createdAt: now };
    await this.store.insertObservation(obs);
    return obs;
  }

  // -------------------------------------------------------------------------
  private async newSession(learnerId: string, now: Date): Promise<Session> {
    const s: Session = { id: this.id(), learnerId, startedAt: now, lastActiveAt: now, domain: null, concept: null, summary: null, turnCount: 0, probeCount: 0 };
    await this.store.createSession(s);
    return s;
  }

  private async views(beliefs: Belief[], now: Date, domain: string | null): Promise<BeliefView[]> {
    const ev = await this.store.listEvidence(beliefs.map((b) => b.id));
    return beliefs
      .map((b) => {
        const mine = ev.filter((e) => e.beliefId === b.id);
        const status = effectiveStatus(b, now);
        return { ...b, status, influence: influenceOf({ ...b, status }, now, domain), evidence: { supports: mine.filter((e) => e.relation === "supports").map((e) => e.observationId), contradicts: mine.filter((e) => e.relation === "contradicts").map((e) => e.observationId), correction: mine.filter((e) => e.relation === "correction").map((e) => e.observationId) } };
      })
      .sort((a, b) => b.influence - a.influence || b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  private async recentRequest(learnerId: string, sessionId: string, domain: string, now: Date): Promise<Strategy | null> {
    const obs = await this.store.listObservations(learnerId, 12);
    // A correction invalidates session working memory recorded before it.
    const lastCorrection = obs.find((o) => o.sessionId === sessionId && o.kind === "correction");
    const since = lastCorrection?.createdAt.getTime() ?? 0;
    // Scoped to the current domain: "show me an example" in bash is not a standing order for SQL.
    // A forced-choice probe answer is weaker than a spontaneous request: it is honoured on the
    // spot but is not a standing order for the session (ablation showed probes otherwise hurt).
    const r = obs.find((o) => o.sessionId === sessionId && o.kind === "request" && o.domain === domain && !o.signals.viaProbe && o.createdAt.getTime() > since && now.getTime() - o.createdAt.getTime() < 6 * 3_600_000);
    const s = r?.signals.strategy as Strategy | undefined;
    return s && (STRATEGIES as readonly string[]).includes(s) ? s : null;
  }

  private async upsert(p: { learnerId: string; kind: Belief["kind"]; key: string; statement: string; domain: string | null; concepts: string[]; source: Belief["source"]; polarity: 1 | -1 }, obsId: string, sessionId: string, now: Date, changes: TurnResult["changes"], beliefs: Belief[]) {
    const existing = beliefs.find((b) => b.key === p.key && b.domain === p.domain && b.status !== "retired" && b.polarity === p.polarity);
    if (existing) {
      const patch = applySupport(existing, sessionId, now);
      await this.store.updateBelief(existing.id, patch);
      Object.assign(existing, patch);
      await this.store.insertEvidence({ id: this.id(), beliefId: existing.id, observationId: obsId, relation: "supports", createdAt: now });
      changes.supported.push(existing.id);
      return existing;
    }
    // Opposite-polarity sibling: new evidence contradicts it rather than silently coexisting.
    const opposite = beliefs.find((b) => b.key === p.key && b.domain === p.domain && b.status !== "retired" && b.polarity !== p.polarity);
    if (opposite) await this.contradict(opposite, obsId, now, "opposite evidence observed", changes, beliefs);
    const status = statusFor(p.source, 1, 0, 1, "candidate");
    const b: Belief = { id: this.id(), ...p, status, confidence: confidenceFor(p.source, 1, 0), supportCount: 1, contradictionCount: 0, sessionIds: [sessionId], validFrom: now, invalidAt: null, invalidReason: null, supersededBy: null, lastConfirmedAt: now, createdAt: now, updatedAt: now };
    await this.store.insertBelief(b);
    await this.store.insertEvidence({ id: this.id(), beliefId: b.id, observationId: obsId, relation: "supports", createdAt: now });
    beliefs.push(b);
    changes.created.push(b.id);
    return b;
  }

  private async contradict(b: Belief, obsId: string, now: Date, reason: string, changes: TurnResult["changes"], _beliefs: Belief[]) {
    const patch = applyContradiction(b, now, reason);
    await this.store.updateBelief(b.id, patch);
    Object.assign(b, patch);
    await this.store.insertEvidence({ id: this.id(), beliefId: b.id, observationId: obsId, relation: "contradicts", createdAt: now });
    (patch.status === "retired" ? changes.retired : changes.contradicted).push(b.id);
  }

  private async retire(b: Belief, obsId: string, now: Date, reason: string, supersededBy: string | null, changes: TurnResult["changes"], _beliefs: Belief[]) {
    const patch = retirePatch(b, now, reason, supersededBy);
    await this.store.updateBelief(b.id, patch);
    Object.assign(b, patch);
    await this.store.insertEvidence({ id: this.id(), beliefId: b.id, observationId: obsId, relation: "correction", createdAt: now });
    changes.retired.push(b.id);
  }

  /** Strategy-fit beliefs: derived per domain from discounted outcomes recorded after any learner correction. */
  private async deriveFit(learnerId: string, sessionId: string, domain: string, now: Date, changes: TurnResult["changes"], beliefs: Belief[], obsId: string) {
    const all = (await this.store.listOutcomes(learnerId)).filter((o) => o.domain === domain);
    const correctedAt = new Map<string, number>();
    for (const b of beliefs) if (b.kind === "strategy_fit" && b.domain === domain && b.status === "retired" && b.invalidReason?.startsWith("learner correction") && b.invalidAt) correctedAt.set(b.key, Math.max(correctedAt.get(b.key) ?? 0, b.invalidAt.getTime()));
    for (const s of STRATEGIES) {
      const key = `fit:${s}`;
      const rows = all.filter((o) => o.strategy === s && o.createdAt.getTime() > (correctedAt.get(key) ?? 0)).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
      if (rows.length < 4) continue;
      let num = 0,
        den = 0;
      rows.forEach((o, i) => {
        const w = o.weight * Math.pow(0.9, i);
        num += o.outcome * w;
        den += w;
      });
      const mean = den ? num / den : 0;
      const sessions = new Set(rows.map((r) => r.sessionId));
      const pos = beliefs.find((b) => b.key === key && b.domain === domain && b.status !== "retired" && b.polarity === 1);
      const neg = beliefs.find((b) => b.key === key && b.domain === domain && b.status !== "retired" && b.polarity === -1);
      const recentFailures = rows.slice(0, 3).every((r) => r.outcome <= -0.3);
      if (mean >= 0.35) {
        if (neg) await this.retire(neg, obsId, now, `outcomes changed: ${s} now averages ${mean.toFixed(2)}`, null, changes, beliefs);
        if (!pos) {
          const b: Belief = { id: this.id(), learnerId, kind: "strategy_fit", key, statement: `${STRATEGY_LABEL[s]} works well in ${domain}`, domain, concepts: [s], source: "inferred", polarity: 1, status: sessions.size >= 2 || rows.length >= 6 ? "active" : "candidate", confidence: Math.min(0.9, 0.5 + mean / 2), supportCount: rows.length, contradictionCount: 0, sessionIds: [...sessions], validFrom: now, invalidAt: null, invalidReason: null, supersededBy: null, lastConfirmedAt: now, createdAt: now, updatedAt: now };
          await this.store.insertBelief(b);
          await this.store.insertEvidence({ id: this.id(), beliefId: b.id, observationId: obsId, relation: "supports", createdAt: now });
          beliefs.push(b);
          changes.created.push(b.id);
        } else {
          const patch: Partial<Belief> = { status: recentFailures ? "contested" : pos.status === "contested" || pos.status === "candidate" ? (sessions.size >= 2 ? "active" : pos.status) : pos.status, confidence: Math.min(0.9, 0.5 + mean / 2), supportCount: rows.length, sessionIds: [...sessions], lastConfirmedAt: now, updatedAt: now };
          await this.store.updateBelief(pos.id, patch);
          Object.assign(pos, patch);
          (recentFailures ? changes.contradicted : changes.supported).push(pos.id);
        }
      } else if (mean <= -0.3) {
        if (pos) await this.retire(pos, obsId, now, `outcomes changed: ${s} now averages ${mean.toFixed(2)}`, null, changes, beliefs);
        if (!neg) {
          const b: Belief = { id: this.id(), learnerId, kind: "strategy_fit", key, statement: `${STRATEGY_LABEL[s]} has not worked well in ${domain}`, domain, concepts: [s], source: "inferred", polarity: -1, status: sessions.size >= 2 || rows.length >= 6 ? "active" : "candidate", confidence: Math.min(0.9, 0.5 - mean / 2), supportCount: rows.length, contradictionCount: 0, sessionIds: [...sessions], validFrom: now, invalidAt: null, invalidReason: null, supersededBy: null, lastConfirmedAt: now, createdAt: now, updatedAt: now };
          await this.store.insertBelief(b);
          await this.store.insertEvidence({ id: this.id(), beliefId: b.id, observationId: obsId, relation: "supports", createdAt: now });
          beliefs.push(b);
          changes.created.push(b.id);
        }
      } else {
        // Evidence has become ambiguous: contest (keep both sides), retire only when it clearly flips.
        if (pos && pos.status === "active" && (mean < 0.1 || recentFailures)) {
          const patch: Partial<Belief> = { status: "contested", contradictionCount: pos.contradictionCount + 1, updatedAt: now };
          await this.store.updateBelief(pos.id, patch);
          Object.assign(pos, patch);
          await this.store.insertEvidence({ id: this.id(), beliefId: pos.id, observationId: obsId, relation: "contradicts", createdAt: now });
          changes.contradicted.push(pos.id);
        }
        if (pos && mean < -0.1) await this.retire(pos, obsId, now, `outcomes changed: ${s} now averages ${mean.toFixed(2)}`, null, changes, beliefs);
        if (neg && neg.status === "active" && mean > 0) {
          const patch: Partial<Belief> = { status: "contested", contradictionCount: neg.contradictionCount + 1, updatedAt: now };
          await this.store.updateBelief(neg.id, patch);
          Object.assign(neg, patch);
          changes.contradicted.push(neg.id);
        }
        if (neg && mean > 0.15) await this.retire(neg, obsId, now, `outcomes changed: ${s} now averages ${mean.toFixed(2)}`, null, changes, beliefs);
      }
    }
    void sessionId;
  }
}

// ---------------------------------------------------------------------------
function summarise(s: Session): string {
  return `Worked on ${s.domain ?? "general topics"}${s.concept ? ` (${s.concept.replace(/-/g, " ")})` : ""} for ${s.turnCount} turn${s.turnCount === 1 ? "" : "s"}.`;
}

function newConcept(learnerId: string, concept: string, domain: string, now: Date): ConceptState {
  return { id: `${learnerId}|${concept}`, learnerId, concept, domain, pKnown: 0.25, basis: "prior", attempts: 0, successes: 0, claimedLevel: null, claimedAt: null, lastEvidenceAt: now };
}

function replace(list: ConceptState[], c: ConceptState) {
  const i = list.findIndex((x) => x.id === c.id);
  if (i >= 0) list[i] = c;
  else list.push(c);
}

function chooseConcept(concepts: Concept[], current: string | null, p: Perception, states: ConceptState[], now: Date): Concept | null {
  if (!concepts.length) return null;
  const p_ = (id: string) => {
    const s = states.find((x) => x.concept === id);
    return s ? retainedPKnown(s, now) : 0.25;
  };
  // A graded answer is not a topic mention: "return" answering a check about functions
  // must not pin the tutor to the functions concept.
  const mentioned = p.taskResult ? undefined : p.concepts.map((id) => concepts.find((c) => c.id === id)).find(Boolean);
  if (mentioned) return mentioned;
  const cur = current ? concepts.find((c) => c.id === current) : undefined;
  if (cur && (p.reaction === "confused" || p.taskResult === "incorrect" || p.requestStrategy)) return cur;
  if (cur && p_(cur.id) < 0.8) return cur;
  // Advance to the first concept not yet known; when everything is known, review the weakest.
  return concepts.find((c) => p_(c.id) < 0.8) ?? [...concepts].sort((a, b) => p_(a.id) - p_(b.id))[0];
}

/**
 * Which beliefs does a correction refer to? If it names a teaching approach, every
 * live belief about that approach (preference AND strategy fit) is denied; otherwise
 * the single best word-overlap match.
 */
export function matchCorrection(text: string, beliefs: Belief[]): Belief[] {
  const t = text.toLowerCase();
  const scored = beliefs
    .filter((b) => b.kind !== "goal")
    .map((b) => {
      let score = 0;
      const s = b.concepts[0];
      if (s && (STRATEGIES as readonly string[]).includes(s)) {
        const label = STRATEGY_LABEL[s as Strategy];
        if (t.includes(label) || t.includes(s.replace(/_/g, " ")) || label.split(/[\s-]+/).some((w) => w.length > 4 && t.includes(w))) score += 3;
      }
      const words = b.statement.toLowerCase().split(/[^a-z]+/).filter((w) => w.length > 4);
      score += words.filter((w) => t.includes(w)).length;
      return { b, score };
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score || b.b.confidence - a.b.confidence);
  if (!scored.length) return [];
  const top = scored[0];
  const topStrategy = top.b.concepts[0];
  if (top.score >= 3 && topStrategy) return scored.filter((x) => x.b.concepts[0] === topStrategy && x.score >= 3).map((x) => x.b);
  return [top.b];
}
