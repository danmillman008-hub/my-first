// Deterministic perception: cheap signals from natural language. It flags
// evidence about THIS turn; it never classifies the person. The model provider
// may add observations, but goals / corrections / requests / reactions found
// here are never dropped (safety net learned from attempt 4).
import { REQUEST_PATTERNS, detectConcepts, detectDomain } from "./packs";
import type { ObservationKind, Strategy, Turn } from "./types";

export type Reaction = "understood" | "confused" | "neutral" | "disagree";

export interface ObservationDraft {
  kind: ObservationKind;
  content: string;
  concepts: string[];
  signals: Record<string, unknown>;
  dedupeKey: string | null;
}

export interface Perception {
  reaction: Reaction;
  requestStrategy: Strategy | null;
  selfReport: { level: number; concepts: string[] } | null; // 1 know, 0.5 partial, 0 don't
  correction: string | null;
  goal: string | null;
  domain: string | null;
  concepts: string[];
  codeShared: boolean;
  taskResult: "correct" | "incorrect" | null;
  isQuestion: boolean;
  observations: ObservationDraft[];
}

const UNDERSTOOD = /\b(makes sense|got it|i see|that helps|clear now|understood|i understand now|perfect|thanks?,? that|ah+,? ok|clicks|that's clear|now i get it|nice,? that)\b/i;
const CONFUSED = /\b(confus\w*|don'?t (get|understand|follow)|lost me|not clear|unclear|what do you mean|huh\??|doesn'?t make sense|still don'?t|i'?m stuck|too abstract|too complicated|no idea)\b/i;
const DISAGREE = /\b(that'?s (not|wrong)|i disagree|not true|incorrect|you'?re wrong|actually,? no)\b/i;
const CORRECTION = /\b(that'?s not true about me|not true about me|i (don'?t|do not) actually|you'?ve got me wrong|that isn'?t me|stop assuming|i never said i|i'?m not (a|an|the) .* (person|learner)|you think i .* but i)\b/i;
const CLAIM_KNOW = /\b(i (already )?(know|understand|get|am (good|comfortable|familiar|fluent) (at|with)|have used|am an? expert (in|at)))\b/i;
const CLAIM_DONT = /\b(i (don'?t|do not|never) (know|understand|get)|i'?m (new to|a beginner (at|in)|unfamiliar with)|no experience with|never used)\b/i;
const CLAIM_PARTIAL = /\b(i (sort of|kind of|roughly|vaguely|partly|partially) (know|understand|get)|i'?m rusty|a bit rusty|somewhat familiar)\b/i;
const GOAL = /\b(i want to (learn|understand|master|get better at|be able to)|my goal is|i'?m trying to (learn|understand|build)|teach me|help me learn|i need to learn)\s+([^.!?\n]{2,80})/i;
const CODE = /(```|\bdef \w+\(|\bfunction\s+\w+\(|\bclass \w+|#!\/bin\/bash|\$\(|=>|;\s*$|SELECT .* FROM)/i;

function norm(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9$?{}.\-_ ]+/g, " ").replace(/\s+/g, " ").trim();
}

export function gradeAnswer(message: string, accept: string[]): "correct" | "incorrect" | null {
  const m = norm(message);
  if (!m) return null;
  for (const a of accept) {
    const n = norm(a);
    if (!n) continue;
    if (m === n || m.includes(n)) return "correct";
  }
  // A short, on-task attempt that does not contain an accepted token is a miss —
  // including hesitant attempts like "hmm, baz?". Real questions are not graded.
  const questionWord = /^(what|why|how|when|which|where|can|could|does|do|is|are|should|would)\b/.test(m);
  if (m.length <= 60 && !questionWord) return "incorrect";
  return null;
}

export function perceive(message: string, previous: Turn | null, currentDomain: string | null): Perception {
  const text = message.trim();
  const lower = text.toLowerCase();
  const observations: ObservationDraft[] = [];

  const detectedDomain = detectDomain(text);
  const domain = detectedDomain ?? currentDomain;
  const concepts = detectConcepts(domain, text);
  const codeShared = CODE.test(text) || text.split("\n").length > 3;
  const questionWord = /^(what|why|how|when|which|where|can|could|does|do|is|are|should|would)\b/i.test(text);
  const isQuestion = questionWord || (/\?\s*$/.test(text) && text.length > 40);

  // --- correction (checked before anything else: strongest signal) ---
  const correction = CORRECTION.test(text) || (DISAGREE.test(text) && /\b(me|i am|i'm|about me)\b/i.test(text)) ? text : null;

  // --- reaction to the previous tutor turn ---
  let reaction: Reaction = "neutral";
  if (correction || DISAGREE.test(text)) reaction = "disagree";
  else if (CONFUSED.test(text)) reaction = "confused";
  else if (UNDERSTOOD.test(text)) reaction = "understood";

  // --- explicit request for an approach ---
  let requestStrategy: Strategy | null = null;
  if (!correction) {
    for (const p of REQUEST_PATTERNS) {
      if (p.re.test(text)) {
        requestStrategy = p.strategy;
        break;
      }
    }
    // "example" alone inside a correction sentence is not a request; also ignore
    // pure mentions like "for example, ..." at the start of an explanation.
    if (requestStrategy === "worked_example" && /^for example\b/i.test(text)) requestStrategy = null;
  }

  // --- answer grading against the check the tutor asked last turn ---
  let taskResult: "correct" | "incorrect" | null = null;
  const check = previous?.meta?.check as { concept: string; accept: string[] } | undefined;
  if (previous && check && !previous.probe && !requestStrategy && !correction) {
    taskResult = gradeAnswer(text, check.accept);
    if (taskResult === "incorrect" && (reaction !== "neutral" || isQuestion)) taskResult = null; // reactions/questions are not answers
  }

  // --- probe answer: the previous tutor turn asked which approach they prefer ---
  const probeOptions = previous?.probe ? (previous.meta?.options as Strategy[] | undefined) : undefined;
  if (probeOptions && !requestStrategy) {
    if (/\b(first|former|1)\b/i.test(lower)) requestStrategy = probeOptions[0];
    else if (/\b(second|latter|2)\b/i.test(lower)) requestStrategy = probeOptions[1];
  }

  // --- self-report ---
  let selfReport: Perception["selfReport"] = null;
  if (!correction) {
    if (CLAIM_PARTIAL.test(text)) selfReport = { level: 0.5, concepts };
    else if (CLAIM_DONT.test(text)) selfReport = { level: 0, concepts };
    else if (CLAIM_KNOW.test(text)) selfReport = { level: 1, concepts };
  }

  // --- goal ---
  const g = GOAL.exec(text);
  const goal = g ? g[g.length - 1].trim() : null;

  // --- observations (what happened) ---
  if (correction) observations.push({ kind: "correction", content: text.slice(0, 300), concepts, signals: {}, dedupeKey: null });
  if (goal) observations.push({ kind: "goal", content: goal, concepts, signals: { key: `goal:${norm(goal).slice(0, 40)}` }, dedupeKey: `goal|${norm(goal).slice(0, 40)}` });
  if (requestStrategy) observations.push({ kind: "request", content: text.slice(0, 200), concepts, signals: { strategy: requestStrategy, viaProbe: Boolean(probeOptions) }, dedupeKey: `request|${requestStrategy}` });
  if (selfReport) observations.push({ kind: "self_report", content: text.slice(0, 200), concepts, signals: { level: selfReport.level }, dedupeKey: `self_report|${selfReport.level}|${concepts.join(",")}` });
  if (reaction !== "neutral" && !correction) observations.push({ kind: "reaction", content: text.slice(0, 200), concepts, signals: { reaction, previousTurnId: previous?.id ?? null, strategy: previous?.strategy ?? null }, dedupeKey: null });
  if (taskResult) observations.push({ kind: taskResult === "correct" ? "success" : "mistake", content: text.slice(0, 200), concepts: check ? [check.concept] : concepts, signals: { concept: check?.concept, previousTurnId: previous?.id ?? null }, dedupeKey: null });
  if (codeShared) observations.push({ kind: "code_shared", content: text.slice(0, 500), concepts, signals: {}, dedupeKey: null });
  if (detectedDomain && currentDomain && detectedDomain !== currentDomain) observations.push({ kind: "topic_switch", content: `${currentDomain} -> ${detectedDomain}`, concepts, signals: { from: currentDomain, to: detectedDomain }, dedupeKey: null });
  if (isQuestion && !requestStrategy) observations.push({ kind: "question", content: text.slice(0, 200), concepts, signals: {}, dedupeKey: null });
  else if (observations.length === 0) observations.push({ kind: "statement", content: text.slice(0, 200), concepts, signals: {}, dedupeKey: null });

  return { reaction, requestStrategy, selfReport, correction, goal, domain, concepts, codeShared, taskResult, isQuestion, observations };
}
