// Strategy selection: a contextual bandit over teaching approaches.
//
// Evidence model (synthesised from attempts 3 and 4):
//   * per-outcome discounting (gamma) + slow wall-clock decay -> drift is picked up
//   * hierarchical prior: shrunk global evidence seeds each domain (no raw leakage)
//   * preference / strategy-fit beliefs shift the prior, domain-scoped
//   * hysteresis: keep what just worked unless something is clearly better
//   * two policies (UCB+epsilon vs Thompson) so the lab can compare them
import { STRATEGIES, type Ablation, type Belief, type Policy, type Strategy, type StrategyOutcome } from "./types";
import { influenceOf } from "./model";

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function sampleGamma(k: number, rnd: () => number): number {
  if (k < 1) return sampleGamma(k + 1, rnd) * Math.pow(Math.max(rnd(), 1e-12), 1 / k);
  const d = k - 1 / 3;
  const c = 1 / Math.sqrt(9 * d);
  for (;;) {
    let x: number, v: number;
    do {
      const u1 = Math.max(rnd(), 1e-12);
      const u2 = rnd();
      x = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
      v = 1 + c * x;
    } while (v <= 0);
    v = v * v * v;
    const u = rnd();
    if (u < 1 - 0.0331 * x ** 4) return d * v;
    if (Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
  }
}
function sampleBeta(a: number, b: number, rnd: () => number): number {
  const x = sampleGamma(a, rnd);
  const y = sampleGamma(b, rnd);
  return x / (x + y);
}

// Per-arm discounting (memory ~1/(1-GAMMA) outcomes of that arm) keeps what was learned
// about every approach; domain-wide discounting was tried and forgot too much (README).
// An abandoned arm is revisited through STALENESS: its exploration bonus regrows the
// longer it goes untried, so a favourite dropped after an unlucky streak is re-tested.
const GAMMA = Number(process.env.STRATEGY_GAMMA ?? 0.9);
const STALE = Number(process.env.STRATEGY_STALE ?? 1); // 1 = disabled: a staleness bonus was tried and lowered best-rate (README)
const CB = Number(process.env.STRATEGY_CB ?? 2);
const MAX_PSEUDO = 24;
const GLOBAL_CAP = 4; // shrinkage: global evidence counts for at most ~4 pseudo-observations

function wallClock(createdAt: Date, now: Date): number {
  const days = Math.max(0, (now.getTime() - createdAt.getTime()) / 86_400_000);
  return 0.35 + 0.65 * Math.exp(-days / 45);
}

export interface Posterior {
  a: number;
  b: number;
  mean: number;
  n: number; // raw local outcomes
  w: number; // effective evidence weight (local + shrunk global)
  stale: number; // domain outcomes recorded since this arm was last used
}

export interface SelectionInput {
  outcomes: StrategyOutcome[];
  domain: string;
  beliefs: Belief[];
  currentStrategy: Strategy | null;
  lastOutcome: number | null;
  /** attribution weight of lastOutcome; low-weight signals must not drive hysteresis */
  lastWeight?: number | null;
  now: Date;
  rnd: () => number;
  policy: Policy;
  ablation: Ablation;
  /** the learner asked for an approach this turn (or answered a probe) */
  requested: Strategy | null;
  /** an approach requested earlier this session that has not failed since */
  recentRequest: Strategy | null;
  /** consecutive poor outcomes (<= -0.3, weight >= 0.5) for the current strategy in this domain */
  consecutiveBad: number;
}

export interface Selection {
  strategy: Strategy;
  reasons: string[];
  posterior: Record<Strategy, Posterior>;
  exploring: boolean;
  source: "request" | "working_memory" | "bandit" | "fixed";
}

export function posteriors(outcomes: StrategyOutcome[], domain: string, beliefs: Belief[], now: Date, ablation: Ablation): Record<Strategy, Posterior> {
  const global = new Map<Strategy, { a: number; b: number }>();
  const local = new Map<Strategy, { a: number; b: number; n: number }>();
  for (const s of STRATEGIES) {
    global.set(s, { a: 0, b: 0 });
    local.set(s, { a: 0, b: 0, n: 0 });
  }
  const sorted = [...outcomes].sort((x, y) => y.createdAt.getTime() - x.createdAt.getTime());
  const seenLocal = new Map<string, number>();
  const staleness = new Map<string, number>();
  let domainCount = 0;
  let seenGlobal = 0;
  for (const o of sorted) {
    if (!(STRATEGIES as readonly string[]).includes(o.strategy)) continue;
    const p = (o.outcome + 1) / 2;
    const tw = ablation === "no_drift" ? 1 : wallClock(o.createdAt, now);
    if (o.domain !== domain) {
      // Hierarchical prior = pooled evidence from OTHER domains, shrunk. Including the
      // current domain here double-counted its own outcomes (found by ablation).
      const gw = tw * o.weight * (ablation === "no_drift" ? 1 : Math.pow(GAMMA, seenGlobal));
      seenGlobal++;
      const g = global.get(o.strategy)!;
      g.a += p * gw;
      g.b += (1 - p) * gw;
    } else {
      const k = seenLocal.get(o.strategy) ?? 0;
      if (k === 0) staleness.set(o.strategy, domainCount);
      domainCount++;
      const lw = tw * o.weight * (ablation === "no_drift" ? 1 : Math.pow(GAMMA, k));
      seenLocal.set(o.strategy, k + 1);
      const l = local.get(o.strategy)!;
      l.a += p * lw;
      l.b += (1 - p) * lw;
      l.n += 1;
    }
  }
  // Preference / fit beliefs shift the prior. Strategy-fit is strictly domain-scoped
  // (influenceOf returns 0 out of scope); stated preferences travel weakly.
  const boost = new Map<Strategy, number>();
  if (ablation !== "no_long_term") {
    for (const b of beliefs) {
      if (b.kind !== "preference" && b.kind !== "strategy_fit") continue;
      if (b.status === "retired") continue;
      const s = b.concepts[0] as Strategy | undefined;
      if (!s || !(STRATEGIES as readonly string[]).includes(s)) continue;
      const inf = influenceOf(b, now, domain);
      if (inf <= 0) continue;
      boost.set(s, (boost.get(s) ?? 0) + inf * b.polarity);
    }
  }
  const out = {} as Record<Strategy, Posterior>;
  for (const s of STRATEGIES) {
    const g = global.get(s)!;
    const l = local.get(s)!;
    const gN = g.a + g.b;
    const shrink = ablation === "no_hierarchy" ? 0 : gN > 0 ? Math.min(1, GLOBAL_CAP / gN) : 0;
    let a = 1 + g.a * shrink + l.a;
    let b = 1 + g.b * shrink + l.b;
    const bo = boost.get(s) ?? 0;
    if (bo > 0) a += bo * 3;
    if (bo < 0) b += -bo * 3;
    const total = a + b;
    if (total > MAX_PSEUDO) {
      a *= MAX_PSEUDO / total;
      b *= MAX_PSEUDO / total;
    }
    out[s] = { a, b, mean: a / (a + b), n: l.n, w: a + b - 2, stale: l.n ? (staleness.get(s) ?? 0) : domainCount };
  }
  return out;
}

export function selectStrategy(i: SelectionInput): Selection {
  const post = posteriors(i.outcomes, i.domain, i.beliefs, i.now, i.ablation);
  // 1. The present outranks memory: an explicit request this turn wins.
  if (i.requested) return { strategy: i.requested, reasons: ["learner asked for this approach just now"], posterior: post, exploring: false, source: "request" };
  if (i.ablation === "no_adaptation") return { strategy: "direct_explanation", reasons: ["ablation: adaptation disabled"], posterior: post, exploring: false, source: "fixed" };
  // 2. Working memory: a request earlier this session that has not failed since.
  if (i.recentRequest && (i.lastOutcome ?? 0) > -0.3) {
    return { strategy: i.recentRequest, reasons: ["learner asked for this approach earlier this session"], posterior: post, exploring: false, source: "working_memory" };
  }
  // 3. Bandit over posteriors.
  const reasons: string[] = [];
  const totalW = STRATEGIES.reduce((s, k) => s + post[k].w, 0);
  const score: Record<string, number> = {};
  let exploring = false;
  if (i.policy === "thompson") {
    for (const s of STRATEGIES) score[s] = sampleBeta(post[s].a, post[s].b, i.rnd);
  } else {
    const eps = Math.max(0.04, 0.3 / (1 + totalW / 6));
    if (i.rnd() < eps) {
      exploring = true;
      for (const s of STRATEGIES) score[s] = i.rnd();
      reasons.push("exploring (epsilon) so a changed learner is noticed");
    } else {
      for (const s of STRATEGIES) {
        const wEff = i.ablation === "no_drift" ? post[s].w : post[s].w * Math.pow(STALE, post[s].stale);
        score[s] = post[s].mean + 0.3 * Math.sqrt(Math.log(totalW + 2) / (wEff + 1)) + i.rnd() * 0.01;
      }
    }
  }
  let best = (STRATEGIES as readonly Strategy[]).reduce((b, s) => (score[s] > score[b] ? s : b), STRATEGIES[0]);
  const cur = i.currentStrategy;
  if (cur && !exploring) {
    const strong = (i.lastWeight ?? 1) >= 0.5;
    const lastGood = strong && (i.lastOutcome ?? 0) >= 0.3;
    const lastBad = strong && (i.lastOutcome ?? 0) <= -0.3;
    const established = post[cur].n >= 4 && post[cur].mean >= 0.62;
    if (lastBad && best === cur && (!established || i.consecutiveBad >= CB)) {
      // Change detector: one bad turn is noise for an established approach; two in a row is a signal.
      best = (STRATEGIES as readonly Strategy[]).filter((s) => s !== cur).sort((x, y) => score[y] - score[x])[0];
      reasons.push(i.consecutiveBad >= CB ? `switched away from ${cur}: it did not land ${i.consecutiveBad} times in a row` : `switched away from ${cur}: it did not land last turn`);
    } else if (lastBad && best === cur) {
      reasons.push(`kept ${cur} despite a poor turn: strong track record in ${i.domain}`);
    } else if (best !== cur && lastGood && post[cur].mean >= 0.55 && post[best].mean - post[cur].mean < 0.1) {
      best = cur; // win-stay hysteresis: no oscillation on lucky samples
      reasons.push(`kept ${cur}: it just worked and nothing is clearly better`);
    }
  }
  const p = post[best];
  if (p.n === 0 && p.w < 1) reasons.push(`little evidence for ${best} in ${i.domain} yet; trying it`);
  else reasons.push(`${best}: expected fit ${(p.mean * 100).toFixed(0)}% in ${i.domain} from ${p.n} local outcomes (evidence weight ${p.w.toFixed(1)})`);
  const boosted = i.beliefs.filter((b) => (b.kind === "preference" || b.kind === "strategy_fit") && b.concepts[0] === best && influenceOf(b, i.now, i.domain) > 0);
  if (boosted.length) reasons.push(`prior shifted by belief: ${boosted[0].statement}`);
  return { strategy: best, reasons, posterior: post, exploring, source: "bandit" };
}

// ---------------------------------------------------------------------------
// Probing: only when uncertainty materially affects the current decision.
// ---------------------------------------------------------------------------
export interface ProbeInput {
  posterior: Record<Strategy, Posterior>;
  sessionTurn: number;
  sessionProbes: number;
  turnsSinceLastProbe: number | null;
  requested: boolean;
  ablation: Ablation;
}

export function decideProbe(i: ProbeInput): { probe: boolean; options: [Strategy, Strategy] | null; reason: string } {
  if (i.ablation === "no_probe") return { probe: false, options: null, reason: "ablation" };
  if (i.requested || i.sessionTurn < 2 || i.sessionProbes >= 1) return { probe: false, options: null, reason: "not needed / budget" };
  if (i.turnsSinceLastProbe != null && i.turnsSinceLastProbe < 12) return { probe: false, options: null, reason: "recent probe" };
  const ranked = (STRATEGIES as readonly Strategy[]).map((s) => ({ s, ...i.posterior[s] })).sort((x, y) => y.mean - x.mean);
  const [top, second] = ranked;
  const totalW = ranked.reduce((s, r) => s + r.w, 0);
  if (totalW < 2) {
    // Cold start: one question along the most discriminative axis (concrete vs abstract)
    // is worth more than guessing; after that, evidence must accumulate before asking again.
    return { probe: true, options: ["worked_example", "direct_explanation"], reason: "cold start: no evidence about what works yet" };
  }
  const uncertain = top.w < 3 && second.w < 3 && top.mean - second.mean < 0.08;
  if (!uncertain) return { probe: false, options: null, reason: "decision not sensitive to uncertainty" };
  return { probe: true, options: [top.s, second.s], reason: `top two approaches indistinguishable (${top.mean.toFixed(2)} vs ${second.mean.toFixed(2)}) with little evidence` };
}
