// Storage boundary. The engine only talks to this interface, so the same core
// runs against Postgres (src/lib/store/pg.ts) and in memory (lab, tests).
import type { Belief, BeliefEvidence, ConceptState, Learner, Observation, ResearchNote, Session, StrategyOutcome, Trace, Turn } from "./types";

export interface Store {
  ensureLearner(id: string, name?: string | null): Promise<Learner>;
  latestSession(learnerId: string): Promise<Session | null>;
  createSession(s: Session): Promise<void>;
  updateSession(id: string, patch: Partial<Session>): Promise<void>;
  listSessions(learnerId: string, limit: number): Promise<Session[]>;

  insertTurn(t: Turn): Promise<void>;
  listTurns(sessionId: string, limit: number): Promise<Turn[]>; // chronological
  countTurnsSince(learnerId: string, since: Date): Promise<number>;
  lastProbeTurn(learnerId: string): Promise<Turn | null>;

  insertObservation(o: Observation): Promise<void>;
  hasObservation(sessionId: string, dedupeKey: string): Promise<boolean>;
  listObservations(learnerId: string, limit: number): Promise<Observation[]>; // newest first

  listBeliefs(learnerId: string, includeRetired: boolean): Promise<Belief[]>;
  getBelief(id: string): Promise<Belief | null>;
  insertBelief(b: Belief): Promise<void>;
  updateBelief(id: string, patch: Partial<Belief>): Promise<void>;
  insertEvidence(e: BeliefEvidence): Promise<void>;
  listEvidence(beliefIds: string[]): Promise<BeliefEvidence[]>;

  listConcepts(learnerId: string): Promise<ConceptState[]>;
  upsertConcept(c: ConceptState): Promise<void>;

  listOutcomes(learnerId: string): Promise<StrategyOutcome[]>;
  insertOutcome(o: StrategyOutcome): Promise<void>;

  insertTrace(t: Trace): Promise<void>;
  listTraces(learnerId: string, limit: number): Promise<Trace[]>;

  getResearch(topic: string): Promise<ResearchNote | null>;
  putResearch(n: ResearchNote): Promise<void>;
}

export class InMemoryStore implements Store {
  learners = new Map<string, Learner>();
  sessions: Session[] = [];
  turns: Turn[] = [];
  observations: Observation[] = [];
  beliefs: Belief[] = [];
  evidence: BeliefEvidence[] = [];
  concepts = new Map<string, ConceptState>();
  outcomes: StrategyOutcome[] = [];
  traces: Trace[] = [];
  research = new Map<string, ResearchNote>();

  async ensureLearner(id: string, name: string | null = null) {
    let l = this.learners.get(id);
    if (!l) {
      l = { id, name, createdAt: new Date(0) };
      this.learners.set(id, l);
    }
    return l;
  }
  async latestSession(learnerId: string) {
    const s = this.sessions.filter((x) => x.learnerId === learnerId);
    return s.length ? s[s.length - 1] : null;
  }
  async createSession(s: Session) {
    this.sessions.push({ ...s });
  }
  async updateSession(id: string, patch: Partial<Session>) {
    const s = this.sessions.find((x) => x.id === id);
    if (s) Object.assign(s, patch);
  }
  async listSessions(learnerId: string, limit: number) {
    return this.sessions.filter((x) => x.learnerId === learnerId).slice(-limit).reverse();
  }
  async insertTurn(t: Turn) {
    this.turns.push({ ...t });
  }
  async listTurns(sessionId: string, limit: number) {
    return this.turns.filter((t) => t.sessionId === sessionId).slice(-limit);
  }
  async countTurnsSince(learnerId: string, since: Date) {
    return this.turns.filter((t) => t.learnerId === learnerId && t.role === "learner" && t.createdAt > since).length;
  }
  async lastProbeTurn(learnerId: string) {
    for (let i = this.turns.length - 1; i >= 0; i--) if (this.turns[i].learnerId === learnerId && this.turns[i].probe) return this.turns[i];
    return null;
  }
  async insertObservation(o: Observation) {
    this.observations.push({ ...o });
  }
  async hasObservation(sessionId: string, dedupeKey: string) {
    return this.observations.some((o) => o.sessionId === sessionId && o.dedupeKey === dedupeKey);
  }
  async listObservations(learnerId: string, limit: number) {
    return this.observations.filter((o) => o.learnerId === learnerId).slice(-limit).reverse();
  }
  async listBeliefs(learnerId: string, includeRetired: boolean) {
    return this.beliefs.filter((b) => b.learnerId === learnerId && (includeRetired || b.status !== "retired")).map((b) => ({ ...b }));
  }
  async getBelief(id: string) {
    const b = this.beliefs.find((x) => x.id === id);
    return b ? { ...b } : null;
  }
  async insertBelief(b: Belief) {
    this.beliefs.push({ ...b });
  }
  async updateBelief(id: string, patch: Partial<Belief>) {
    const b = this.beliefs.find((x) => x.id === id);
    if (b) Object.assign(b, patch);
  }
  async insertEvidence(e: BeliefEvidence) {
    this.evidence.push(e);
  }
  async listEvidence(beliefIds: string[]) {
    const set = new Set(beliefIds);
    return this.evidence.filter((e) => set.has(e.beliefId));
  }
  async listConcepts(learnerId: string) {
    return [...this.concepts.values()].filter((c) => c.learnerId === learnerId).map((c) => ({ ...c }));
  }
  async upsertConcept(c: ConceptState) {
    this.concepts.set(c.id, { ...c });
  }
  async listOutcomes(learnerId: string) {
    return this.outcomes.filter((o) => o.learnerId === learnerId);
  }
  async insertOutcome(o: StrategyOutcome) {
    this.outcomes.push(o);
  }
  async insertTrace(t: Trace) {
    this.traces.push(t);
  }
  async listTraces(learnerId: string, limit: number) {
    return this.traces.filter((t) => t.learnerId === learnerId).slice(-limit).reverse();
  }
  async getResearch(topic: string) {
    return this.research.get(topic) ?? null;
  }
  async putResearch(n: ResearchNote) {
    this.research.set(n.topic, n);
  }
}
