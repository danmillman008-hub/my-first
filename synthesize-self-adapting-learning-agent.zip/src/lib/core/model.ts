// Pure epistemic rules: belief lifecycle, mastery tracing, outcome attribution.
// No I/O. Everything here is unit-testable and deterministic.
import type { Belief, BeliefSource, BeliefStatus, ConceptState, OutcomeSignal, Strategy } from "./types";

export const DAY = 86_400_000;

// ---------------------------------------------------------------------------
// Belief lifecycle
// ---------------------------------------------------------------------------

/** Long-unconfirmed inferred beliefs lose influence but never vanish. */
export function recencyFactor(lastConfirmedAt: Date, now: Date, halfLifeDays = 60): number {
  const days = Math.max(0, (now.getTime() - lastConfirmedAt.getTime()) / DAY);
  return Math.pow(0.5, days / halfLifeDays);
}

export function confidenceFor(source: BeliefSource, support: number, contradiction: number): number {
  if (source === "stated") return Math.max(0.15, Math.min(0.95, 0.85 + 0.05 * support - 0.3 * contradiction));
  // Beta posterior mean with a weak uniform prior; capped so no inferred belief becomes a verdict.
  return Math.min(0.92, (support + 1) / (support + contradiction + 2));
}

export function statusFor(source: BeliefSource, support: number, contradiction: number, distinctSessions: number, prev: BeliefStatus): BeliefStatus {
  if (prev === "retired") return "retired";
  if (contradiction > 0 && contradiction >= Math.max(2, support)) return "retired";
  if (contradiction > 0 && contradiction / Math.max(1, support) >= 0.34) return "contested";
  if (source === "stated" || source === "external") return support > 0 || prev !== "candidate" ? "active" : "candidate";
  // Inferred beliefs must earn durability: independent supports across sessions.
  if (support >= 2 && (distinctSessions >= 2 || support >= 3)) return "active";
  return prev === "active" || prev === "contested" ? "active" : "candidate";
}

export const STATUS_WEIGHT: Record<BeliefStatus, number> = { active: 1, contested: 0.5, candidate: 0.3, dormant: 0.15, retired: 0 };

/** Influence = confidence x status x recency x scope. Used to rank beliefs for context and priors. */
export function influenceOf(b: Belief, now: Date, domain: string | null): number {
  const scope = !b.domain ? 0.85 : b.domain === domain ? 1 : b.kind === "strategy_fit" ? 0 : 0.1;
  const status = b.status === "active" && b.source === "inferred" && recencyFactor(b.lastConfirmedAt, now) < 0.25 ? STATUS_WEIGHT.dormant : STATUS_WEIGHT[b.status];
  return b.confidence * status * (0.4 + 0.6 * recencyFactor(b.lastConfirmedAt, now)) * scope;
}

/** Dormancy is computed lazily at read time and is reversible. */
export function effectiveStatus(b: Belief, now: Date): BeliefStatus {
  if (b.status === "active" && b.source === "inferred" && recencyFactor(b.lastConfirmedAt, now) < 0.25) return "dormant";
  if (b.status === "dormant" && recencyFactor(b.lastConfirmedAt, now) >= 0.25) return "active";
  return b.status;
}

export function applySupport(b: Belief, sessionId: string, now: Date): Partial<Belief> {
  const sessionIds = b.sessionIds.includes(sessionId) ? b.sessionIds : [...b.sessionIds, sessionId];
  const supportCount = b.supportCount + 1;
  const prev = b.status === "dormant" ? "active" : b.status;
  const status = statusFor(b.source, supportCount, b.contradictionCount, sessionIds.length, prev);
  return { supportCount, sessionIds, status, confidence: confidenceFor(b.source, supportCount, b.contradictionCount), lastConfirmedAt: now, updatedAt: now };
}

export function applyContradiction(b: Belief, now: Date, reason: string): Partial<Belief> {
  const contradictionCount = b.contradictionCount + 1;
  const status = statusFor(b.source, b.supportCount, contradictionCount, b.sessionIds.length, b.status);
  return {
    contradictionCount,
    status,
    confidence: confidenceFor(b.source, b.supportCount, contradictionCount),
    updatedAt: now,
    ...(status === "retired" ? { invalidAt: now, invalidReason: reason } : {}),
  };
}

export function retirePatch(b: Belief, now: Date, reason: string, supersededBy: string | null): Partial<Belief> {
  return { status: "retired", invalidAt: now, invalidReason: reason, supersededBy, contradictionCount: b.contradictionCount + 1, confidence: Math.min(b.confidence, 0.1), updatedAt: now };
}

// ---------------------------------------------------------------------------
// Concept mastery: behaviour channel (BKT) kept apart from self-report channel
// ---------------------------------------------------------------------------

export const BKT = { learn: 0.15, slip: 0.1, guess: 0.2 };

export function bktUpdate(pKnown: number, correct: boolean): number {
  const { learn, slip, guess } = BKT;
  const pCorrectGivenKnown = 1 - slip;
  const pCorrectGivenUnknown = guess;
  const evidence = correct ? pKnown * pCorrectGivenKnown + (1 - pKnown) * pCorrectGivenUnknown : pKnown * slip + (1 - pKnown) * (1 - guess);
  const posterior = correct ? (pKnown * pCorrectGivenKnown) / evidence : (pKnown * slip) / evidence;
  return Math.min(0.99, Math.max(0.01, posterior + (1 - posterior) * learn));
}

/**
 * Forgetting on read (half-life regression style): a concept demonstrated once has a
 * half-life of ~4 days; every further success doubles stability. Knowledge drifts
 * toward uncertainty (0.5), never toward "unknown", so history keeps counting.
 */
export function retainedPKnown(c: ConceptState, now: Date): number {
  if (c.basis !== "demonstrated") return c.pKnown;
  const days = Math.max(0, (now.getTime() - c.lastEvidenceAt.getTime()) / DAY);
  const halfLife = 2 * Math.pow(2, Math.min(8, c.successes));
  const r = Math.pow(0.5, days / halfLife);
  return 0.5 + (c.pKnown - 0.5) * r;
}

/** A claim sets a prior when nothing has been demonstrated; it never overrides behaviour. */
export function applyClaim(c: ConceptState, level: number, now: Date): Partial<ConceptState> {
  const patch: Partial<ConceptState> = { claimedLevel: level, claimedAt: now };
  if (c.attempts === 0) {
    patch.pKnown = level >= 1 ? 0.6 : level > 0 ? 0.4 : 0.15;
    patch.basis = "claimed";
  }
  return patch;
}

export function applyTaskResult(c: ConceptState, correct: boolean, now: Date): Partial<ConceptState> {
  return {
    pKnown: bktUpdate(c.basis === "demonstrated" ? retainedPKnown(c, now) : c.pKnown, correct),
    basis: "demonstrated",
    attempts: c.attempts + 1,
    successes: c.successes + (correct ? 1 : 0),
    lastEvidenceAt: now,
  };
}

/** Self-report vs demonstrated behaviour. Returns a discrepancy direction once evidence is meaningful. */
export function discrepancy(c: ConceptState): "overclaims" | "underclaims" | "aligned" | null {
  if (c.claimedLevel == null || c.attempts < 3 || c.basis !== "demonstrated") return null;
  const gap = c.claimedLevel - c.pKnown;
  if (gap >= 0.45) return "overclaims";
  if (gap <= -0.45) return "underclaims";
  return "aligned";
}

// ---------------------------------------------------------------------------
// Outcome attribution: strategy signal is separated from task/mastery signal
// ---------------------------------------------------------------------------

export interface AttributionInput {
  reaction: "understood" | "confused" | "neutral" | "disagree";
  taskResult: "correct" | "incorrect" | null;
  requestedDifferentStrategy: boolean;
  isCorrection: boolean;
  topicSwitch: boolean;
  /** learner's p(known) for the concept BEFORE this turn's evidence */
  priorPKnown: number | null;
}

export interface Attribution {
  outcome: number;
  weight: number;
  signal: OutcomeSignal;
  reasons: string[];
}

/**
 * Attribute the learner's response to the PREVIOUS tutor turn. Reaction signals
 * (understood / confused) speak about the teaching; task results speak mostly
 * about mastery and count at half weight — and at quarter weight when the
 * learner demonstrably did not know the concept beforehand (mastery confound).
 */
export function attribute(i: AttributionInput): Attribution | null {
  if (i.isCorrection || i.topicSwitch) return null; // cannot be attributed to the teaching approach
  const parts: { v: number; w: number; s: OutcomeSignal; why: string }[] = [];
  const knownBefore = i.priorPKnown != null && i.priorPKnown >= 0.75;
  if (i.reaction === "understood") parts.push({ v: 1, w: knownBefore ? 0.5 : 1, s: "reaction", why: knownBefore ? "learner signalled understanding, but already knew the concept (reduced weight)" : "learner signalled understanding" });
  if (i.reaction === "confused") parts.push({ v: -1, w: 1, s: "reaction", why: "learner signalled confusion" });
  if (i.reaction === "disagree") parts.push({ v: -0.4, w: 0.5, s: "reaction", why: "learner pushed back" });
  if (i.requestedDifferentStrategy) parts.push({ v: -0.6, w: 0.7, s: "request", why: "learner asked for a different approach" });
  if (i.taskResult === "correct") {
    // Positive mastery confound: a correct answer on a concept the learner already
    // knew says almost nothing about the teaching approach.
    parts.push({ v: 0.7, w: knownBefore ? 0.15 : 0.5, s: "task", why: knownBefore ? "answered correctly, but the concept was already known (minimal weight)" : "answered the check correctly (task signal, half weight)" });
  }
  if (i.taskResult === "incorrect") {
    const unknownBefore = i.priorPKnown != null && i.priorPKnown < 0.35;
    parts.push({ v: -0.7, w: unknownBefore ? 0.25 : 0.5, s: "task", why: unknownBefore ? "missed the check, but the concept was not yet known (quarter weight)" : "missed the check (task signal, half weight)" });
  }
  if (!parts.length) return null;
  const wsum = parts.reduce((s, p) => s + p.w, 0);
  const outcome = parts.reduce((s, p) => s + p.v * p.w, 0) / wsum;
  const signals = new Set(parts.map((p) => p.s));
  const signal: OutcomeSignal = signals.size > 1 ? "mixed" : parts[0].s;
  return { outcome: Math.max(-1, Math.min(1, outcome)), weight: Math.min(1, wsum), signal, reasons: parts.map((p) => p.why) };
}

export const PREF_STATEMENT: Record<Strategy, string> = {
  direct_explanation: "Prefers direct explanation over being quizzed",
  worked_example: "Prefers a concrete worked example over abstract explanation",
  analogy: "Finds analogies and real-world comparisons helpful",
  step_by_step: "Prefers being walked through step by step",
  socratic: "Responds well to guiding questions",
  hands_on_task: "Likes to practise with a hands-on task",
  concise_summary: "Prefers brief, concise explanations",
};
