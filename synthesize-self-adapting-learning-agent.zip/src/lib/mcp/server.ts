// Dependency-free MCP (JSON-RPC 2.0, Streamable HTTP, stateless). External
// assistants read and contribute to the SAME learner model; contributions enter
// as observations and must earn belief status like any other evidence.
import type { Engine } from "../core/engine";
import type { ObservationKind } from "../core/types";

type Json = Record<string, unknown>;
interface Tool { name: string; description: string; inputSchema: Json }

const LEARNER = { type: "string", description: "Learner id (3-64 chars, [a-zA-Z0-9_-])" };
export const TOOLS: Tool[] = [
  { name: "get_learner_context", description: "Working beliefs (status, confidence, scope, evidence), concept evidence and recent sessions for a learner. Beliefs are priors, not verdicts.", inputSchema: { type: "object", properties: { learnerId: LEARNER, domain: { type: "string" } }, required: ["learnerId"] } },
  { name: "tutor_turn", description: "Send one learner message through the tutor and get the reply plus decision metadata.", inputSchema: { type: "object", properties: { learnerId: LEARNER, message: { type: "string" } }, required: ["learnerId", "message"] } },
  { name: "record_observation", description: "Contribute evidence about the learner (source=external). It becomes an observation; it does not create beliefs directly.", inputSchema: { type: "object", properties: { learnerId: LEARNER, kind: { type: "string", enum: ["statement", "success", "mistake", "self_report", "context", "code_shared", "request"] }, content: { type: "string" }, domain: { type: "string" }, concepts: { type: "array", items: { type: "string" } } }, required: ["learnerId", "kind", "content"] } },
  { name: "list_beliefs", description: "List beliefs including retired ones (history is invalidated, never deleted).", inputSchema: { type: "object", properties: { learnerId: LEARNER, includeRetired: { type: "boolean" } }, required: ["learnerId"] } },
  { name: "challenge_belief", description: "The learner says a belief is not true about them: it is retired with evidence kept and optionally replaced.", inputSchema: { type: "object", properties: { learnerId: LEARNER, beliefId: { type: "string" }, replacement: { type: "string" } }, required: ["learnerId", "beliefId"] } },
];

function validId(x: unknown): string | null {
  return typeof x === "string" && /^[a-zA-Z0-9_-]{3,64}$/.test(x) ? x : null;
}

export async function callTool(engine: Engine, name: string, args: Json): Promise<unknown> {
  const learnerId = validId(args.learnerId);
  if (!learnerId) throw new Error("invalid learnerId");
  switch (name) {
    case "get_learner_context": {
      const m = await engine.model(learnerId, new Date(), typeof args.domain === "string" ? args.domain : null);
      return { beliefs: m.beliefs.filter((b) => b.status !== "retired").slice(0, 20).map(pubBelief), concepts: m.concepts.map((c) => ({ concept: c.concept, domain: c.domain, pKnown: Number(c.pKnownNow.toFixed(2)), basis: c.basis, claimed: c.claimedLevel, discrepancy: c.discrepancy })), sessions: m.sessions.map((s) => ({ startedAt: s.startedAt, domain: s.domain, summary: s.summary, turns: s.turnCount })) };
    }
    case "tutor_turn": {
      if (typeof args.message !== "string" || !args.message.trim()) throw new Error("message required");
      const r = await engine.turn(learnerId, args.message.slice(0, 4000));
      return { reply: r.reply, strategy: r.strategy, domain: r.domain, concept: r.concept, probe: r.probe, reasons: r.selection.reasons, attribution: r.attribution, changes: r.changes };
    }
    case "record_observation": {
      const kinds: ObservationKind[] = ["statement", "success", "mistake", "self_report", "context", "code_shared", "request"];
      if (!kinds.includes(args.kind as ObservationKind)) throw new Error("invalid kind");
      if (typeof args.content !== "string") throw new Error("content required");
      const o = await engine.recordObservation(learnerId, args.kind as ObservationKind, args.content, typeof args.domain === "string" ? args.domain : null, Array.isArray(args.concepts) ? (args.concepts as unknown[]).filter((c): c is string => typeof c === "string").slice(0, 5) : []);
      return { observationId: o.id, source: o.source };
    }
    case "list_beliefs": {
      const m = await engine.model(learnerId);
      return { beliefs: m.beliefs.filter((b) => args.includeRetired || b.status !== "retired").map(pubBelief) };
    }
    case "challenge_belief": {
      if (typeof args.beliefId !== "string") throw new Error("beliefId required");
      return engine.challengeBelief(learnerId, args.beliefId, typeof args.replacement === "string" && args.replacement.trim() ? args.replacement.slice(0, 200) : null);
    }
    default:
      throw new Error(`unknown tool ${name}`);
  }
}

function pubBelief(b: { id: string; kind: string; statement: string; status: string; confidence: number; domain: string | null; source: string; supportCount: number; contradictionCount: number; updatedAt: Date; invalidReason: string | null; evidence: { supports: string[]; contradicts: string[]; correction: string[] } }) {
  return { id: b.id, kind: b.kind, statement: b.statement, status: b.status, confidence: Number(b.confidence.toFixed(2)), scope: b.domain ?? "general", source: b.source, support: b.supportCount, contradiction: b.contradictionCount, updatedAt: b.updatedAt, invalidReason: b.invalidReason, evidence: b.evidence };
}

export async function handleJsonRpc(engine: Engine, body: unknown): Promise<Json | null> {
  const req = body as { jsonrpc?: string; id?: unknown; method?: string; params?: Json };
  const id = req?.id ?? null;
  const ok = (result: unknown) => ({ jsonrpc: "2.0", id, result }) as Json;
  const err = (code: number, message: string) => ({ jsonrpc: "2.0", id, error: { code, message } }) as Json;
  if (!req || req.jsonrpc !== "2.0" || typeof req.method !== "string") return err(-32600, "invalid request");
  switch (req.method) {
    case "initialize":
      return ok({ protocolVersion: "2025-06-18", capabilities: { tools: {} }, serverInfo: { name: "private-learning-agent", version: "1.0.0" } });
    case "notifications/initialized":
      return null;
    case "ping":
      return ok({});
    case "tools/list":
      return ok({ tools: TOOLS });
    case "resources/list":
      return ok({ resources: [] });
    case "prompts/list":
      return ok({ prompts: [] });
    case "tools/call": {
      const name = req.params?.name as string;
      const args = (req.params?.arguments as Json) ?? {};
      try {
        const result = await callTool(engine, name, args);
        return ok({ content: [{ type: "text", text: JSON.stringify(result) }], structuredContent: result });
      } catch (e) {
        return ok({ content: [{ type: "text", text: (e as Error).message }], isError: true });
      }
    }
    default:
      return err(-32601, "method not found");
  }
}
