// Postgres adapter for the Store boundary (Drizzle). Evidence tables are
// append-only from the application's point of view; beliefs are patched only
// through the lifecycle functions in the core.
import { and, desc, eq, gt, inArray } from "drizzle-orm";
import { db } from "@/db";
import { beliefEvidence, beliefs, conceptStates, learners, observations, researchCache, sessions, strategyOutcomes, traces, turns } from "@/db/schema";
import type { Store } from "../core/store";
import type { Belief, BeliefEvidence, ConceptState, Learner, Observation, ResearchNote, Session, StrategyOutcome, Trace, Turn } from "../core/types";

type Row<T> = { [K in keyof T]: T[K] };

export class PgStore implements Store {
  async ensureLearner(id: string, name: string | null = null): Promise<Learner> {
    const [existing] = await db.select().from(learners).where(eq(learners.id, id)).limit(1);
    if (existing) return existing;
    const [row] = await db.insert(learners).values({ id, name }).onConflictDoNothing().returning();
    return row ?? { id, name, createdAt: new Date() };
  }
  async latestSession(learnerId: string) {
    const [s] = await db.select().from(sessions).where(eq(sessions.learnerId, learnerId)).orderBy(desc(sessions.lastActiveAt)).limit(1);
    return (s as Session | undefined) ?? null;
  }
  async createSession(s: Session) {
    await db.insert(sessions).values(s);
  }
  async updateSession(id: string, patch: Partial<Session>) {
    await db.update(sessions).set(patch).where(eq(sessions.id, id));
  }
  async listSessions(learnerId: string, limit: number) {
    return (await db.select().from(sessions).where(eq(sessions.learnerId, learnerId)).orderBy(desc(sessions.lastActiveAt)).limit(limit)) as Session[];
  }
  async insertTurn(t: Turn) {
    await db.insert(turns).values(t);
  }
  async listTurns(sessionId: string, limit: number) {
    const rows = await db.select().from(turns).where(eq(turns.sessionId, sessionId)).orderBy(desc(turns.createdAt)).limit(limit);
    return rows.reverse() as Turn[];
  }
  async countTurnsSince(learnerId: string, since: Date) {
    const rows = await db.select({ id: turns.id }).from(turns).where(and(eq(turns.learnerId, learnerId), eq(turns.role, "learner"), gt(turns.createdAt, since)));
    return rows.length;
  }
  async lastProbeTurn(learnerId: string) {
    const [t] = await db.select().from(turns).where(and(eq(turns.learnerId, learnerId), eq(turns.probe, true))).orderBy(desc(turns.createdAt)).limit(1);
    return (t as Turn | undefined) ?? null;
  }
  async insertObservation(o: Observation) {
    await db.insert(observations).values(o);
  }
  async hasObservation(sessionId: string, dedupeKey: string) {
    const [r] = await db.select({ id: observations.id }).from(observations).where(and(eq(observations.sessionId, sessionId), eq(observations.dedupeKey, dedupeKey))).limit(1);
    return Boolean(r);
  }
  async listObservations(learnerId: string, limit: number) {
    return (await db.select().from(observations).where(eq(observations.learnerId, learnerId)).orderBy(desc(observations.createdAt)).limit(limit)) as Observation[];
  }
  async listBeliefs(learnerId: string, includeRetired: boolean) {
    const rows = await db.select().from(beliefs).where(eq(beliefs.learnerId, learnerId)).orderBy(desc(beliefs.updatedAt));
    return (includeRetired ? rows : rows.filter((b) => b.status !== "retired")) as Belief[];
  }
  async getBelief(id: string) {
    const [b] = await db.select().from(beliefs).where(eq(beliefs.id, id)).limit(1);
    return (b as Belief | undefined) ?? null;
  }
  async insertBelief(b: Belief) {
    await db.insert(beliefs).values(b);
  }
  async updateBelief(id: string, patch: Partial<Belief>) {
    await db.update(beliefs).set(patch as Row<typeof beliefs.$inferInsert>).where(eq(beliefs.id, id));
  }
  async insertEvidence(e: BeliefEvidence) {
    await db.insert(beliefEvidence).values(e);
  }
  async listEvidence(beliefIds: string[]) {
    if (!beliefIds.length) return [];
    return (await db.select().from(beliefEvidence).where(inArray(beliefEvidence.beliefId, beliefIds))) as BeliefEvidence[];
  }
  async listConcepts(learnerId: string) {
    return (await db.select().from(conceptStates).where(eq(conceptStates.learnerId, learnerId))) as ConceptState[];
  }
  async upsertConcept(c: ConceptState) {
    const { id, ...rest } = c;
    await db.insert(conceptStates).values({ id, ...rest }).onConflictDoUpdate({ target: conceptStates.id, set: rest });
  }
  async listOutcomes(learnerId: string) {
    return (await db.select().from(strategyOutcomes).where(eq(strategyOutcomes.learnerId, learnerId)).orderBy(strategyOutcomes.createdAt)) as StrategyOutcome[];
  }
  async insertOutcome(o: StrategyOutcome) {
    await db.insert(strategyOutcomes).values(o);
  }
  async insertTrace(t: Trace) {
    await db.insert(traces).values(t);
  }
  async listTraces(learnerId: string, limit: number) {
    return (await db.select().from(traces).where(eq(traces.learnerId, learnerId)).orderBy(desc(traces.createdAt)).limit(limit)) as Trace[];
  }
  async getResearch(topic: string) {
    const [r] = await db.select().from(researchCache).where(eq(researchCache.topic, topic)).limit(1);
    return (r as ResearchNote | undefined) ?? null;
  }
  async putResearch(n: ResearchNote) {
    await db.insert(researchCache).values(n).onConflictDoUpdate({ target: researchCache.topic, set: { summary: n.summary, sourceUrl: n.sourceUrl, provider: n.provider, fetchedAt: n.fetchedAt } });
  }
}
