// Research is isolated from learner memory: results live in research_cache with
// provenance and are handed to the composer as background, never as learner evidence.
import type { ResearchNote } from "../core/types";
import type { Store } from "../core/store";

export type ResearchFn = (topic: string) => Promise<ResearchNote | null>;

export const wikipediaResearch: ResearchFn = async (topic) => {
  try {
    const q = encodeURIComponent(topic.replace(/-/g, " "));
    const search = await fetch(`https://en.wikipedia.org/w/api.php?action=opensearch&format=json&limit=1&search=${q}`, { signal: AbortSignal.timeout(6000), headers: { "user-agent": "private-learning-agent/1.0" } });
    if (!search.ok) return null;
    const arr = (await search.json()) as [string, string[], string[], string[]];
    const title = arr[1]?.[0];
    if (!title) return null;
    const res = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`, { signal: AbortSignal.timeout(6000), headers: { "user-agent": "private-learning-agent/1.0" } });
    if (!res.ok) return null;
    const data = (await res.json()) as { extract?: string; content_urls?: { desktop?: { page?: string } } };
    if (!data.extract) return null;
    return { topic, summary: data.extract.slice(0, 900), sourceUrl: data.content_urls?.desktop?.page ?? null, provider: "wikipedia", fetchedAt: new Date() };
  } catch {
    return null;
  }
};

export async function researchTopic(store: Store, topic: string, fn: ResearchFn | null, now: Date): Promise<ResearchNote | null> {
  const cached = await store.getResearch(topic);
  if (cached && now.getTime() - cached.fetchedAt.getTime() < 30 * 86_400_000) return cached;
  if (!fn) return cached;
  const note = await fn(topic);
  if (note) await store.putResearch({ ...note, fetchedAt: now });
  return note ?? cached;
}
