// Model provider boundary. The core never depends on a vendor: providers only
// (a) optionally enrich perception with a validated structured patch and
// (b) compose the reply for an already-decided strategy.
import { STRATEGIES, STRATEGY_LABEL, type ConceptState, type ResearchNote, type Strategy, type TurnContext, type Turn } from "../core/types";
import type { Perception, ObservationDraft, Reaction } from "../core/perceive";
import type { Concept } from "../core/packs";
import { retainedPKnown } from "../core/model";

export interface ModelPerception {
  reaction?: Reaction;
  requestStrategy?: Strategy | null;
  selfReport?: { level: number; concepts: string[] } | null;
  correction?: string | null;
  goal?: string | null;
  observations?: ObservationDraft[];
}

export interface PerceiveInput {
  message: string;
  previousTutor: Turn | null;
  domain: string;
  knownConcepts: string[];
}

export interface ComposeInput {
  message: string;
  context: TurnContext;
  strategy: Strategy;
  concept: Concept | null;
  domainLabel: string;
  probe: { options: [Strategy, Strategy] } | null;
  perception: Perception;
  research: ResearchNote | null;
  now: Date;
}

export interface ComposeOutput {
  reply: string;
  check: { concept: string; accept: string[] } | null;
}

export interface Provider {
  name: string;
  online: boolean;
  perceive(input: PerceiveInput): Promise<ModelPerception | null>;
  compose(input: ComposeInput): Promise<ComposeOutput>;
  research?(topic: string): Promise<ResearchNote | null>;
}

// ---------------------------------------------------------------------------
// Offline provider: deterministic templates. Explanations are outlines, but the
// entire learner-model machinery runs for real, which is what the lab measures.
// ---------------------------------------------------------------------------
function continuity(ctx: TurnContext): string {
  if (!ctx.isNewSession || ctx.gapMs == null) return "";
  const days = Math.round(ctx.gapMs / 86_400_000);
  if (days < 1) return "";
  const goal = ctx.beliefs.find((b) => b.kind === "goal" && b.status === "active");
  return `Welcome back — it has been ${days} day${days === 1 ? "" : "s"}.${goal ? ` You wanted to ${goal.statement.replace(/^Goal: /, "")}.` : ""} `;
}

function explain(c: Concept, s: Strategy): string {
  switch (s) {
    case "direct_explanation":
      return `${c.label}: ${c.kernel}`;
    case "worked_example":
      return `Here is a concrete example of ${c.label}:\n\n    ${c.example}\n\nWhat happens: ${c.kernel}`;
    case "analogy":
      return `Think of ${c.label} as ${c.analogy}. In technical terms: ${c.kernel}`;
    case "step_by_step":
      return `Let's build ${c.label} one step at a time:\n${c.steps.map((st, i) => `  ${i + 1}. ${st}`).join("\n")}\nTogether: ${c.kernel}`;
    case "socratic":
      return `Before I explain ${c.label}: consider this — ${c.example}. What do you think the result is, and why? (Hint: ${c.kernel.split(";")[0].replace(/\.$/, "")}.)`;
    case "hands_on_task":
      return `Try this with ${c.label}: ${c.task}\nWhat you need: ${c.kernel}`;
    case "concise_summary":
      return `${c.label} in one line: ${c.kernel.split(";")[0].replace(/\.$/, "")}.`;
  }
}

export class OfflineProvider implements Provider {
  name = "offline";
  online = false;
  async perceive(): Promise<ModelPerception | null> {
    return null;
  }
  async compose(i: ComposeInput): Promise<ComposeOutput> {
    const parts: string[] = [];
    const intro = continuity(i.context);
    if (intro) parts.push(intro.trim());
    if (i.perception.correction) parts.push("Understood — I have updated what I believe about you and kept the evidence so you can inspect it.");
    if (i.perception.goal) parts.push(`Noted your goal: ${i.perception.goal}.`);
    let check: ComposeOutput["check"] = null;
    if (i.concept) {
      if (i.perception.reaction === "confused") parts.push(`Let me take a different angle on ${i.concept.label}.`);
      parts.push(explain(i.concept, i.strategy));
      if (!i.probe) {
        parts.push(`Quick check: ${i.concept.check.question}`);
        check = { concept: i.concept.id, accept: i.concept.check.accept };
      }
    } else {
      const topic = i.domainLabel;
      if (i.research) parts.push(`On ${topic}: ${i.research.summary}${i.research.sourceUrl ? ` (source: ${i.research.sourceUrl})` : ""}`);
      else parts.push(`Let's work on ${topic}. Tell me what you already know or paste what you are working on, and I will start from there.`);
    }
    if (i.probe) {
      const [a, b] = i.probe.options;
      parts.push(`So I can teach you better: would you rather I continue with a ${STRATEGY_LABEL[a]} (first) or ${STRATEGY_LABEL[b]} (second)?`);
    }
    return { reply: parts.join("\n\n"), check };
  }
}

// ---------------------------------------------------------------------------
// OpenAI-compatible provider via fetch. Structured outputs are validated; any
// failure degrades to the offline composer so provider errors never corrupt memory.
// ---------------------------------------------------------------------------
export interface OpenAIConfig {
  apiKey: string;
  baseUrl?: string;
  model?: string;
  fetchImpl?: typeof fetch;
}

const PERCEPTION_SCHEMA_HINT = `Return ONLY JSON: {"reaction":"understood|confused|neutral|disagree","requestStrategy":null|one of ${STRATEGIES.join("|")},"selfReport":null|{"level":0|0.5|1,"concepts":[string]},"correction":null|string,"goal":null|string,"observations":[{"kind":"statement|question|self_report|success|mistake|reaction|request|context|code_shared","content":string,"concepts":[string]}]}`;

function isStrategy(x: unknown): x is Strategy {
  return typeof x === "string" && (STRATEGIES as readonly string[]).includes(x);
}

export function validatePerception(raw: unknown): ModelPerception | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  const out: ModelPerception = {};
  if (["understood", "confused", "neutral", "disagree"].includes(r.reaction as string)) out.reaction = r.reaction as Reaction;
  if (r.requestStrategy === null || isStrategy(r.requestStrategy)) out.requestStrategy = (r.requestStrategy as Strategy | null) ?? null;
  if (r.selfReport && typeof r.selfReport === "object") {
    const s = r.selfReport as Record<string, unknown>;
    if ([0, 0.5, 1].includes(s.level as number)) out.selfReport = { level: s.level as number, concepts: Array.isArray(s.concepts) ? s.concepts.filter((c): c is string => typeof c === "string").slice(0, 5) : [] };
  }
  if (typeof r.correction === "string" && r.correction.trim()) out.correction = r.correction.slice(0, 300);
  if (typeof r.goal === "string" && r.goal.trim()) out.goal = r.goal.slice(0, 120);
  if (Array.isArray(r.observations)) {
    const kinds = new Set(["statement", "question", "self_report", "success", "mistake", "reaction", "request", "context", "code_shared"]);
    out.observations = r.observations
      .filter((o): o is Record<string, unknown> => Boolean(o) && typeof o === "object")
      .filter((o) => kinds.has(o.kind as string) && typeof o.content === "string" && (o.content as string).trim().length > 0)
      .slice(0, 6)
      .map((o) => ({ kind: o.kind as ObservationDraft["kind"], content: (o.content as string).slice(0, 300), concepts: Array.isArray(o.concepts) ? (o.concepts as unknown[]).filter((c): c is string => typeof c === "string").slice(0, 5) : [], signals: { model: true }, dedupeKey: `${o.kind}|${(o.content as string).toLowerCase().slice(0, 60)}` }));
  }
  return out;
}

function beliefBlock(ctx: TurnContext): string {
  const lines = ctx.beliefs.slice(0, 8).map((b) => {
    const strength = b.confidence >= 0.75 && b.status === "active" ? "strong" : b.status === "active" ? "moderate" : "weak";
    return `- [${b.status}, ${strength} evidence${b.domain ? `, ${b.domain}` : ""}] ${b.statement}`;
  });
  return lines.length ? lines.join("\n") : "- (no durable beliefs yet)";
}

function conceptBlock(concepts: ConceptState[], now: Date): string {
  const rows = concepts.slice(0, 10).map((c) => `- ${c.concept}: p(known)=${retainedPKnown(c, now).toFixed(2)} (${c.basis}${c.claimedLevel != null ? `, claims ${c.claimedLevel}` : ""})`);
  return rows.length ? rows.join("\n") : "- (nothing demonstrated yet)";
}

export class OpenAIProvider implements Provider {
  name = "openai-compatible";
  online = true;
  private fallback = new OfflineProvider();
  constructor(private cfg: OpenAIConfig) {}

  private async chat(system: string, user: string, json: boolean): Promise<string | null> {
    const f = this.cfg.fetchImpl ?? fetch;
    const base = (this.cfg.baseUrl ?? "https://api.openai.com/v1").replace(/\/$/, "");
    try {
      const res = await f(`${base}/chat/completions`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${this.cfg.apiKey}` },
        body: JSON.stringify({
          model: this.cfg.model ?? "gpt-4o-mini",
          temperature: 0.3,
          ...(json ? { response_format: { type: "json_object" } } : {}),
          messages: [
            { role: "system", content: system },
            { role: "user", content: user },
          ],
        }),
        signal: AbortSignal.timeout(30_000),
      });
      if (!res.ok) return null;
      const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      return data.choices?.[0]?.message?.content ?? null;
    } catch {
      return null;
    }
  }

  async perceive(i: PerceiveInput): Promise<ModelPerception | null> {
    const system = `You extract evidence from ONE learner message in a tutoring conversation. Describe what happened; do not characterise the person. Known concepts in ${i.domain}: ${i.knownConcepts.join(", ") || "none"}. ${PERCEPTION_SCHEMA_HINT}`;
    const user = `Previous tutor turn (${i.previousTutor?.strategy ?? "none"}): ${i.previousTutor?.content.slice(0, 600) ?? "(none)"}\n\nLearner message:\n${i.message.slice(0, 2000)}`;
    const text = await this.chat(system, user, true);
    if (!text) return null;
    try {
      return validatePerception(JSON.parse(text));
    } catch {
      return null;
    }
  }

  async compose(i: ComposeInput): Promise<ComposeOutput> {
    const ctx = i.context;
    const system = [
      "You are one continuous private tutor for this learner. Speak naturally; never mention internal modes, beliefs, or strategies by name.",
      `Teaching approach for THIS reply: ${STRATEGY_LABEL[i.strategy]}. Commit to it.`,
      i.concept ? `Concept focus: ${i.concept.label}. Kernel: ${i.concept.kernel}. End with one short check question whose acceptable answers are: ${i.concept.check.accept.join(" / ")}.` : "No fixed concept; respond to the learner's actual question.",
      i.research ? `Background research (NOT knowledge the learner has): ${i.research.summary}` : "",
      "Working hypotheses about the learner (priors, not verdicts):\n" + beliefBlock(ctx),
      "Concept evidence:\n" + conceptBlock(ctx.concepts, i.now),
      ctx.previousSessionSummary ? `Last session: ${ctx.previousSessionSummary}` : "",
      i.probe ? `Also ask, briefly, whether they would rather continue with ${STRATEGY_LABEL[i.probe.options[0]]} (first) or ${STRATEGY_LABEL[i.probe.options[1]]} (second).` : "",
      i.perception.correction ? "The learner corrected something you believed about them. Acknowledge briefly and move on." : "",
      'Return ONLY JSON: {"reply": string}',
    ]
      .filter(Boolean)
      .join("\n\n");
    const history = ctx.recentTurns
      .slice(-6)
      .map((t) => `${t.role === "learner" ? "Learner" : "Tutor"}: ${t.content.slice(0, 500)}`)
      .join("\n");
    const text = await this.chat(system, `${history}\nLearner: ${i.message.slice(0, 3000)}`, true);
    if (text) {
      try {
        const parsed = JSON.parse(text) as { reply?: unknown };
        if (typeof parsed.reply === "string" && parsed.reply.trim()) {
          return { reply: parsed.reply.trim(), check: i.concept && !i.probe ? { concept: i.concept.id, accept: i.concept.check.accept } : null };
        }
      } catch {
        /* fall through */
      }
    }
    return this.fallback.compose(i); // graceful degradation; memory is untouched by the failure
  }
}

export function createProvider(env: NodeJS.ProcessEnv = process.env): Provider {
  if (env.OPENAI_API_KEY) return new OpenAIProvider({ apiKey: env.OPENAI_API_KEY, baseUrl: env.OPENAI_BASE_URL, model: env.OPENAI_MODEL });
  return new OfflineProvider();
}
