// Process-wide wiring: one Postgres store, one provider, one engine.
import { Engine } from "./core/engine";
import { PgStore } from "./store/pg";
import { createProvider } from "./providers";
import { wikipediaResearch } from "./research";

const g = globalThis as typeof globalThis & { __pla?: { engine: Engine; providerName: string } };

export function runtime() {
  if (!g.__pla) {
    const provider = createProvider();
    const research = process.env.RESEARCH_DISABLED === "1" ? null : wikipediaResearch;
    const engine = new Engine({ store: new PgStore(), provider, research }, { policy: (process.env.STRATEGY_POLICY as "ucb" | "thompson") || "ucb" });
    g.__pla = { engine, providerName: provider.name };
  }
  return g.__pla;
}

/** Learner identity: a private cookie id (no accounts). Callers may pass an explicit id (MCP). */
export function learnerIdFrom(cookieValue: string | undefined | null, explicit?: string | null): { id: string; isNew: boolean } {
  if (explicit && /^[a-zA-Z0-9_-]{3,64}$/.test(explicit)) return { id: explicit, isNew: false };
  if (cookieValue && /^[a-zA-Z0-9_-]{3,64}$/.test(cookieValue)) return { id: cookieValue, isNew: false };
  return { id: `l_${crypto.randomUUID().replace(/-/g, "").slice(0, 20)}`, isNew: true };
}
