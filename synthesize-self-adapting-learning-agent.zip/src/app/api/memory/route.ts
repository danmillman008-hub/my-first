import { NextRequest, NextResponse } from "next/server";
import { runtime, learnerIdFrom } from "@/lib/runtime";

export const dynamic = "force-dynamic";
const COOKIE = "pla_learner";

export async function GET(req: NextRequest) {
  const { id, isNew } = learnerIdFrom(req.cookies.get(COOKIE)?.value);
  if (isNew) return NextResponse.json({ learnerId: null, beliefs: [], concepts: [], sessions: [], observations: [], traces: [] });
  const m = await runtime().engine.model(id);
  return NextResponse.json({ learnerId: id, ...m });
}

/** Correction endpoint: { beliefId, replacement? } -> retire (evidence kept), optional replacement. */
export async function POST(req: NextRequest) {
  const { id, isNew } = learnerIdFrom(req.cookies.get(COOKIE)?.value);
  if (isNew) return NextResponse.json({ error: "no learner" }, { status: 400 });
  const body = (await req.json().catch(() => null)) as { beliefId?: string; replacement?: string } | null;
  if (!body?.beliefId) return NextResponse.json({ error: "beliefId required" }, { status: 400 });
  const r = await runtime().engine.challengeBelief(id, body.beliefId, body.replacement?.trim() ? body.replacement.slice(0, 200) : null);
  return NextResponse.json(r, { status: r.ok ? 200 : 404 });
}
