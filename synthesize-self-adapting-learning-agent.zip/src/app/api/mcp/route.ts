import { NextRequest, NextResponse } from "next/server";
import { runtime } from "@/lib/runtime";
import { handleJsonRpc, TOOLS } from "@/lib/mcp/server";

export const dynamic = "force-dynamic";

function authorised(req: NextRequest): boolean {
  const token = process.env.MCP_ACCESS_TOKEN;
  if (!token) return true;
  return req.headers.get("authorization") === `Bearer ${token}`;
}

export async function GET() {
  return NextResponse.json({ name: "private-learning-agent", transport: "streamable-http (stateless, JSON)", tools: TOOLS.map((t) => t.name) });
}

export async function POST(req: NextRequest) {
  if (!authorised(req)) return NextResponse.json({ error: "unauthorised" }, { status: 401 });
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ jsonrpc: "2.0", id: null, error: { code: -32700, message: "parse error" } }, { status: 400 });
  }
  const { engine } = runtime();
  if (Array.isArray(body)) {
    const out = (await Promise.all(body.map((b) => handleJsonRpc(engine, b)))).filter(Boolean);
    return NextResponse.json(out);
  }
  const res = await handleJsonRpc(engine, body);
  if (!res) return new NextResponse(null, { status: 202 });
  return NextResponse.json(res);
}
