import { NextRequest, NextResponse } from "next/server";
import { runtime, learnerIdFrom } from "@/lib/runtime";

export const dynamic = "force-dynamic";
const COOKIE = "pla_learner";

export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => null)) as { message?: string } | null;
  const message = body?.message?.trim();
  if (!message) return NextResponse.json({ error: "message required" }, { status: 400 });
  const { id, isNew } = learnerIdFrom(req.cookies.get(COOKIE)?.value);
  const { engine } = runtime();
  try {
    const r = await engine.turn(id, message.slice(0, 4000));
    const res = NextResponse.json({ reply: r.reply, strategy: r.strategy, domain: r.domain, concept: r.concept, probe: r.probe, isNewSession: r.isNewSession, reasons: r.selection.reasons, source: r.selection.source, attribution: r.attribution, changes: r.changes });
    if (isNew) res.cookies.set(COOKIE, id, { httpOnly: true, sameSite: "lax", maxAge: 60 * 60 * 24 * 365 * 3, path: "/" });
    return res;
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "tutor unavailable" }, { status: 500 });
  }
}
