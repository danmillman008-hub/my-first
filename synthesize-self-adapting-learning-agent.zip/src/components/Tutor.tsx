"use client";
import { useCallback, useEffect, useRef, useState } from "react";

type Msg = { role: "learner" | "tutor"; content: string; meta?: { strategy: string; reasons: string[]; source: string; probe: boolean; changes?: { created: string[]; retired: string[]; contradicted: string[] } } };
type Belief = { id: string; kind: string; statement: string; status: string; confidence: number; domain: string | null; source: string; supportCount: number; contradictionCount: number; updatedAt: string; invalidReason: string | null; evidence: { supports: string[]; contradicts: string[]; correction: string[] } };
type Concept = { concept: string; domain: string; pKnownNow: number; basis: string; claimedLevel: number | null; discrepancy: string | null };
type Obs = { id: string; kind: string; content: string; domain: string | null; createdAt: string; source: string };
type Session = { id: string; startedAt: string; domain: string | null; summary: string | null; turnCount: number };
type Model = { learnerId: string | null; beliefs: Belief[]; concepts: Concept[]; observations: Obs[]; sessions: Session[] };

const STATUS_STYLE: Record<string, string> = {
  active: "bg-emerald-100 text-emerald-800",
  contested: "bg-amber-100 text-amber-800",
  candidate: "bg-slate-100 text-slate-700",
  dormant: "bg-slate-100 text-slate-500",
  retired: "bg-rose-50 text-rose-700 line-through",
};

export default function Tutor() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [model, setModel] = useState<Model | null>(null);
  const [showRetired, setShowRetired] = useState(false);
  const [open, setOpen] = useState<string | null>(null);
  const [tab, setTab] = useState<"beliefs" | "concepts" | "evidence">("beliefs");
  const endRef = useRef<HTMLDivElement>(null);

  const refresh = useCallback(async () => {
    const r = await fetch("/api/memory", { cache: "no-store" });
    if (r.ok) setModel(await r.json());
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function send(text?: string) {
    const message = (text ?? input).trim();
    if (!message || busy) return;
    setInput("");
    setBusy(true);
    setMessages((m) => [...m, { role: "learner", content: message }]);
    try {
      const r = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ message }) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error ?? "failed");
      setMessages((m) => [...m, { role: "tutor", content: data.reply, meta: { strategy: data.strategy, reasons: data.reasons, source: data.source, probe: data.probe, changes: data.changes } }]);
      void refresh();
    } catch (e) {
      setMessages((m) => [...m, { role: "tutor", content: `Something went wrong (${(e as Error).message}). Your message was not lost from memory if it was recorded.` }]);
    } finally {
      setBusy(false);
    }
  }

  async function challenge(b: Belief) {
    const replacement = window.prompt(`"${b.statement}"\n\nYou are telling the tutor this is not true about you. The belief will be retired (its evidence is kept). Optionally, what IS true instead?`, "");
    if (replacement === null) return;
    await fetch("/api/memory", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ beliefId: b.id, replacement: replacement.trim() || undefined }) });
    void refresh();
    setMessages((m) => [...m, { role: "tutor", content: `Noted — I no longer believe "${b.statement}".${replacement.trim() ? ` I have recorded: ${replacement.trim()}.` : ""} The old evidence stays visible in your memory panel.` }]);
  }

  const beliefs = (model?.beliefs ?? []).filter((b) => showRetired || b.status !== "retired");
  const obsById = new Map((model?.observations ?? []).map((o) => [o.id, o]));
  const lastSession = model?.sessions?.[1];

  return (
    <div className="grid h-screen grid-cols-1 lg:grid-cols-[1fr_380px]">
      <section className="flex flex-col border-r border-slate-200">
        <header className="flex items-center justify-between border-b border-slate-200 px-5 py-3">
          <div>
            <h1 className="text-base font-semibold text-slate-900">Your tutor</h1>
            <p className="text-xs text-slate-500">One continuous relationship. Ask, paste code, disagree, come back whenever.</p>
          </div>
          {lastSession && <span className="text-xs text-slate-500">last time: {lastSession.summary ?? lastSession.domain ?? "—"}</span>}
        </header>
        <div className="flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {messages.length === 0 && (
            <div className="mx-auto max-w-lg rounded-xl border border-dashed border-slate-300 p-5 text-sm text-slate-600">
              <p className="mb-3 font-medium text-slate-800">Start anywhere.</p>
              <div className="flex flex-wrap gap-2">
                {["I want to learn bash", "Teach me OOP, I already know the basics of classes", "Can you show me an example of a SQL join?", "I want to understand recursion in Python"].map((s) => (
                  <button key={s} onClick={() => send(s)} className="rounded-full border border-slate-300 px-3 py-1 text-xs hover:bg-slate-50">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === "learner" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${m.role === "learner" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-900"}`}>
                {m.content}
                {m.meta && (
                  <details className="mt-2 text-[11px] text-slate-500">
                    <summary className="cursor-pointer select-none">why this approach · {m.meta.strategy.replace(/_/g, " ")}{m.meta.probe ? " · asked a quick preference question" : ""}</summary>
                    <ul className="mt-1 list-disc pl-4">
                      {m.meta.reasons.map((r, j) => (
                        <li key={j}>{r}</li>
                      ))}
                      {m.meta.changes && (m.meta.changes.created.length || m.meta.changes.retired.length || m.meta.changes.contradicted.length) ? (
                        <li>
                          memory: {m.meta.changes.created.length} new, {m.meta.changes.contradicted.length} contested, {m.meta.changes.retired.length} retired
                        </li>
                      ) : null}
                    </ul>
                  </details>
                )}
              </div>
            </div>
          ))}
          <div ref={endRef} />
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void send();
          }}
          className="border-t border-slate-200 p-3"
        >
          <div className="flex gap-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send();
                }
              }}
              rows={2}
              placeholder="Ask anything, paste code, or tell me what you want to learn…"
              className="flex-1 resize-none rounded-xl border border-slate-300 px-3 py-2 text-sm focus:border-slate-500 focus:outline-none"
            />
            <button disabled={busy} className="rounded-xl bg-slate-900 px-4 text-sm font-medium text-white disabled:opacity-50">
              {busy ? "…" : "Send"}
            </button>
          </div>
        </form>
      </section>

      <aside className="flex flex-col overflow-hidden bg-slate-50">
        <div className="border-b border-slate-200 px-4 py-3">
          <h2 className="text-sm font-semibold text-slate-900">What I currently think about you</h2>
          <p className="text-[11px] text-slate-500">Working hypotheses, not verdicts. Anything wrong? Say so and it is retired with its evidence kept.</p>
          <div className="mt-2 flex gap-1 text-xs">
            {(["beliefs", "concepts", "evidence"] as const).map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`rounded-md px-2 py-1 ${tab === t ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-200"}`}>
                {t}
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-3 text-sm">
          {tab === "beliefs" && (
            <>
              <label className="mb-2 flex items-center gap-2 text-[11px] text-slate-500">
                <input type="checkbox" checked={showRetired} onChange={(e) => setShowRetired(e.target.checked)} /> show retired history
              </label>
              {beliefs.length === 0 && <p className="text-xs text-slate-500">Nothing durable yet. Beliefs earn their place through repeated, independent evidence.</p>}
              <ul className="space-y-2">
                {beliefs.map((b) => (
                  <li key={b.id} className="rounded-lg border border-slate-200 bg-white p-2.5">
                    <div className="flex items-start justify-between gap-2">
                      <button onClick={() => setOpen(open === b.id ? null : b.id)} className="text-left text-[13px] text-slate-900">
                        {b.statement}
                      </button>
                      <span className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] ${STATUS_STYLE[b.status] ?? ""}`}>{b.status}</span>
                    </div>
                    <div className="mt-1 flex flex-wrap gap-x-3 text-[11px] text-slate-500">
                      <span>{b.kind.replace(/_/g, " ")}</span>
                      <span>scope: {b.domain ?? "general"}</span>
                      <span>confidence {(b.confidence * 100).toFixed(0)}%</span>
                      <span>
                        +{b.supportCount} / −{b.contradictionCount}
                      </span>
                    </div>
                    {open === b.id && (
                      <div className="mt-2 space-y-1 border-t border-slate-100 pt-2 text-[11px] text-slate-600">
                        <p>
                          <b>Why I think this:</b> {b.source === "stated" ? "you told me" : `inferred from ${b.supportCount} observation${b.supportCount === 1 ? "" : "s"}`}
                          {b.contradictionCount ? `, with ${b.contradictionCount} contradicting` : ""}. Last updated {new Date(b.updatedAt).toLocaleString()}.
                        </p>
                        {b.invalidReason && <p className="text-rose-700">Retired: {b.invalidReason}</p>}
                        {b.evidence.supports.slice(-3).map((id) => (
                          <p key={id} className="truncate text-emerald-700">
                            + {obsById.get(id)?.content ?? id}
                          </p>
                        ))}
                        {b.evidence.contradicts.slice(-3).map((id) => (
                          <p key={id} className="truncate text-amber-700">
                            − {obsById.get(id)?.content ?? id}
                          </p>
                        ))}
                        {b.status !== "retired" && (
                          <button onClick={() => challenge(b)} className="mt-1 rounded border border-rose-200 px-2 py-0.5 text-rose-700 hover:bg-rose-50">
                            That&apos;s not true about me
                          </button>
                        )}
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            </>
          )}
          {tab === "concepts" && (
            <ul className="space-y-1.5">
              {(model?.concepts ?? []).length === 0 && <p className="text-xs text-slate-500">No concept evidence yet.</p>}
              {(model?.concepts ?? [])
                .sort((a, b) => a.domain.localeCompare(b.domain))
                .map((c) => (
                  <li key={`${c.domain}/${c.concept}`} className="rounded-lg border border-slate-200 bg-white p-2">
                    <div className="flex items-center justify-between text-[12px]">
                      <span className="text-slate-900">
                        {c.domain} · {c.concept.replace(/-/g, " ")}
                      </span>
                      <span className="text-slate-500">{c.basis}</span>
                    </div>
                    <div className="mt-1 h-1.5 w-full rounded bg-slate-100">
                      <div className="h-1.5 rounded bg-emerald-500" style={{ width: `${Math.round(c.pKnownNow * 100)}%` }} />
                    </div>
                    <div className="mt-1 flex gap-3 text-[11px] text-slate-500">
                      <span>demonstrated {(c.pKnownNow * 100).toFixed(0)}%</span>
                      {c.claimedLevel != null && <span>you said: {c.claimedLevel >= 1 ? "know it" : c.claimedLevel > 0 ? "partly" : "don't know"}</span>}
                      {c.discrepancy && c.discrepancy !== "aligned" && <span className="text-amber-700">{c.discrepancy}</span>}
                    </div>
                  </li>
                ))}
            </ul>
          )}
          {tab === "evidence" && (
            <ul className="space-y-1">
              {(model?.observations ?? []).map((o) => (
                <li key={o.id} className="rounded border border-slate-200 bg-white px-2 py-1 text-[11px]">
                  <span className="mr-1 rounded bg-slate-100 px-1 text-slate-600">{o.kind}</span>
                  <span className="text-slate-800">{o.content}</span>
                  <span className="ml-1 text-slate-400">
                    {o.domain ?? ""} · {o.source}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </aside>
    </div>
  );
}
