// Synthetic-learner laboratory. Learners have HIDDEN ground truth (per-domain
// strategy affinities, mastery, noise, drift...). The tutor only ever sees text.
import { Engine } from "../../src/lib/core/engine";
import { InMemoryStore } from "../../src/lib/core/store";
import { OfflineProvider } from "../../src/lib/providers";
import { mulberry32 } from "../../src/lib/core/bandit";
import { findPack } from "../../src/lib/core/packs";
import { STRATEGIES, STRATEGY_LABEL, type Ablation, type Policy, type Strategy } from "../../src/lib/core/types";

export interface LearnerSpec {
  name: string;
  domains: string[];
  /** hidden: which approaches land, per domain (0..1) */
  affinity: Record<string, Record<Strategy, number>>;
  learnRate: number;
  noise: number; // probability a reaction is flipped
  articulate: number; // probability of saying how it landed
  overconfidence: number; // -1 (underclaims) .. 1 (overclaims)
  requestRate: number; // probability of asking for the favourite approach when confused
  switching: number; // probability of switching domain on a turn
  gapDays: number; // days between sessions
  drift: { atSession: number } | null;
  correctionAt: number | null; // session index at which the learner challenges the tutor's top preference belief
  initialMastery: number;
}

export interface Condition {
  name: string;
  ablation: Ablation;
  policy: Policy;
}

export interface RunConfig {
  sessions: number;
  turnsPerSession: number;
  seed: number;
}

export interface LearnerReport {
  learner: string;
  condition: string;
  seed: number;
  turns: number;
  bestRateEarly: number;
  bestRateLate: number;
  understoodEarly: number;
  understoodLate: number;
  regretLate: number;
  oracleUnderstood: number;
  randomUnderstood: number;
  probeRate: number;
  activeBeliefs: number;
  totalBeliefs: number;
  observations: number;
  falseActiveBeliefs: number;
  leakedFitBeliefs: number;
  driftRecoveryTurns: number | null;
  correctionRecreated: boolean | null;
  goalSurvived: boolean | null;
  meanMastery: number;
  msPerTurn: number;
}

const REQUEST_PHRASE: Record<Strategy, string> = {
  worked_example: "Can you show me a concrete example?",
  analogy: "Could you give me an analogy for that?",
  step_by_step: "Can you walk me through it step by step?",
  socratic: "Ask me questions and let me figure it out.",
  hands_on_task: "Give me an exercise so I can practice.",
  concise_summary: "Can you keep it shorter? Just the summary.",
  direct_explanation: "Just explain it directly, please.",
};

export function affinityFor(rnd: () => number, favourite: Strategy, second?: Strategy): Record<Strategy, number> {
  const out = {} as Record<Strategy, number>;
  for (const s of STRATEGIES) out[s] = 0.25 + rnd() * 0.25; // 0.25..0.5 for the rest
  out[favourite] = 0.88;
  if (second) out[second] = 0.7;
  return out;
}

function bestOf(aff: Record<Strategy, number>): Strategy[] {
  const max = Math.max(...STRATEGIES.map((s) => aff[s]));
  return STRATEGIES.filter((s) => aff[s] >= max - 0.05);
}

export async function runLearner(spec: LearnerSpec, cond: Condition, cfg: RunConfig): Promise<LearnerReport> {
  const rnd = mulberry32(cfg.seed * 7919 + hash(spec.name));
  const store = new InMemoryStore();
  const engine = new Engine({ store, provider: new OfflineProvider(), research: null }, { ablation: cond.ablation, policy: cond.policy, seed: cfg.seed * 31 + hash(spec.name) });
  const learnerId = `sim_${spec.name}`;
  const affinity: Record<string, Record<Strategy, number>> = JSON.parse(JSON.stringify(spec.affinity));
  const mastery = new Map<string, number>();
  for (const d of spec.domains) for (const c of findPack(d)?.concepts ?? []) mastery.set(`${d}/${c.id}`, spec.initialMastery);

  let now = new Date(Date.UTC(2025, 0, 6, 9, 0, 0));
  let domain = spec.domains[0];
  const log: { session: number; turn: number; domain: string; strategy: Strategy; best: boolean; understood: boolean; probe: boolean; regret: number }[] = [];
  let driftTurnIndex: number | null = null;
  let correctionKey: string | null = null;
  let correctionRecreated: boolean | null = null;
  let goalSurvived: boolean | null = null;
  const t0 = Date.now();

  for (let s = 0; s < cfg.sessions; s++) {
    if (spec.drift && s === spec.drift.atSession) {
      // Preference drift: a new favourite in every domain.
      for (const d of spec.domains) {
        const old = bestOf(affinity[d])[0];
        const others = STRATEGIES.filter((x) => x !== old);
        affinity[d] = affinityFor(rnd, others[Math.floor(rnd() * others.length)]);
      }
      driftTurnIndex = log.length;
    }
    let pendingReply: { strategy: Strategy; concept: string | null; domain: string; probe: boolean; options: Strategy[] | null; check: { accept: string[] } | null } | null = null;
    for (let t = 0; t < cfg.turnsPerSession; t++) {
      // ---- learner composes a message from hidden state + last tutor reply ----
      let msg: string;
      let understood = false;
      if (t === 0) {
        if (spec.correctionAt === s && correctionKey === null) {
          const m = await engine.model(learnerId, now);
          const top = m.beliefs.find((b) => b.kind === "preference" && b.status === "active") ?? m.beliefs.find((b) => b.kind === "strategy_fit" && b.status === "active");
          if (top) {
            correctionKey = top.key;
            const label = STRATEGY_LABEL[top.concepts[0] as Strategy] ?? top.statement;
            msg = `That's not true about me — I don't actually prefer ${label}.`;
          } else msg = s === 0 ? `I want to learn ${domain}` : `Let's continue with ${domain}`;
        } else if (s === 0) {
          msg = `I want to learn ${domain}`;
          if (spec.overconfidence > 0.3) msg += `. I already know the basics of ${findPack(domain)?.concepts[0].label ?? domain}`;
          if (spec.overconfidence < -0.3) msg += `. I don't really understand any of it`;
        } else {
          if (rnd() < spec.switching && spec.domains.length > 1) domain = spec.domains[(spec.domains.indexOf(domain) + 1) % spec.domains.length];
          msg = `Back to ${domain}. Where were we?`;
        }
      } else {
        if (rnd() < spec.switching && spec.domains.length > 1) {
          domain = spec.domains[(spec.domains.indexOf(domain) + 1) % spec.domains.length];
          msg = `Actually, can we switch to ${domain}?`;
        } else if (pendingReply?.probe && pendingReply.options) {
          const fav = bestOf(affinity[domain])[0];
          const idx = pendingReply.options.indexOf(fav);
          msg = idx === 1 ? "The second one." : idx === 0 ? "The first one." : "Neither really, whatever works.";
        } else if (pendingReply) {
          const aff = affinity[pendingReply.domain]?.[pendingReply.strategy] ?? 0.4;
          const key = `${pendingReply.domain}/${pendingReply.concept}`;
          const m = mastery.get(key) ?? 0.3;
          let p = 0.75 * aff + 0.25 * m;
          understood = rnd() < p;
          if (rnd() < spec.noise) understood = !understood;
          if (understood) mastery.set(key, m + spec.learnRate * (1 - m));
          const m2 = mastery.get(key) ?? m;
          const parts: string[] = [];
          if (rnd() < spec.articulate) parts.push(understood ? pick(rnd, ["That makes sense.", "Got it, thanks.", "Okay, I see it now."]) : pick(rnd, ["I'm confused.", "I don't get it.", "That's still not clear to me."]));
          if (!understood && rnd() < spec.requestRate) parts.push(REQUEST_PHRASE[bestOf(affinity[domain])[0]]);
          else if (pendingReply.check) {
            // An explanation that landed makes the immediate check likely; otherwise mastery carries it.
            const correct = rnd() < (understood ? 0.75 + 0.2 * m2 : 0.1 + 0.4 * m2);
            parts.push(correct ? pendingReply.check.accept[0] : pick(rnd, ["maybe foo", "not sure, bar", "hmm, baz?"]));
          }
          if (spec.overconfidence > 0.3 && rnd() < 0.15) parts.push("I already know this part.");
          msg = parts.join(" ") || "ok";
          p = 0;
        } else msg = "Go on.";
      }

      // ---- tutor turn ----
      const r = await engine.turn(learnerId, msg, now);
      if (process.env.LAB_TRACE === spec.name && cond.name === (process.env.LAB_TRACE_COND ?? "full")) {
        const top = Object.entries(r.selection.posterior).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k, v]) => `${k}=${v}`).join(" ");
        console.log(`s${s}t${t} u=${understood ? 1 : 0} [${domain}] "${msg.slice(0, 30)}" attr=${r.attribution ? `${r.attribution.strategy}:${r.attribution.outcome.toFixed(2)}x${r.attribution.weight}` : "-"} -> ${r.strategy}${r.probe ? " (probe)" : ""} via ${r.selection.source} | ${top} | ${r.selection.reasons[0]?.slice(0, 70)}`);
      }
      if (correctionKey && spec.correctionAt === s && t === 0) {
        const m = await engine.model(learnerId, now);
        correctionRecreated = m.beliefs.some((b) => b.key === correctionKey && b.status !== "retired");
      }
      if (r.domain !== domain && affinity[r.domain]) domain = r.domain;
      const aff = affinity[r.domain];
      const best = aff ? bestOf(aff) : [];
      log.push({ session: s, turn: t, domain: r.domain, strategy: r.strategy, best: best.includes(r.strategy), understood, probe: r.probe, regret: aff ? Math.max(...STRATEGIES.map((x) => aff[x])) - aff[r.strategy] : 0 });
      pendingReply = { strategy: r.strategy, concept: r.concept, domain: r.domain, probe: r.probe, options: r.probe ? ((await store.listTurns(r.sessionId, 1))[0].meta.options as Strategy[]) : null, check: (await store.listTurns(r.sessionId, 1))[0].meta.check as { accept: string[] } | null };
      now = new Date(now.getTime() + 2 * 60_000);
    }
    now = new Date(now.getTime() + spec.gapDays * 86_400_000 + 3_600_000);
    // Forgetting between sessions: hidden mastery decays with the gap, so there is always something to learn.
    const keep = 1 - 0.5 * Math.min(1, spec.gapDays / 7);
    for (const [k, v] of mastery) mastery.set(k, 0.1 + (v - 0.1) * keep);
  }
  const ms = Date.now() - t0;
  const finalModel = await engine.model(learnerId, now);
  if (spec.gapDays >= 20) goalSurvived = finalModel.beliefs.some((b) => b.kind === "goal" && b.status === "active");

  const teaching = log.filter((l) => !l.probe);
  const q = Math.max(1, Math.floor(teaching.length / 4));
  const early = teaching.slice(0, q);
  const late = teaching.slice(-q);
  const reacted = log.slice(1);
  const rate = (xs: typeof log, f: (l: (typeof log)[number]) => boolean) => (xs.length ? xs.filter(f).length / xs.length : 0);
  // Drift recovery: turns after the drift until a window of 6 teaching turns contains >= 4 best picks.
  let driftRecoveryTurns: number | null = null;
  if (driftTurnIndex != null) {
    const after = log.slice(driftTurnIndex).filter((l) => !l.probe);
    for (let i = 0; i + 6 <= after.length; i++) {
      if (after.slice(i, i + 6).filter((l) => l.best).length >= 4) {
        driftRecoveryTurns = i;
        break;
      }
    }
  }
  const live = finalModel.beliefs.filter((b) => b.status === "active" || b.status === "contested");
  const falseActive = live.filter((b) => (b.kind === "preference" || b.kind === "strategy_fit") && b.status === "active" && b.domain && affinity[b.domain] && b.polarity === 1 && affinity[b.domain][b.concepts[0] as Strategy] < 0.6).length;
  const leaked = finalModel.beliefs.filter((b) => b.kind === "strategy_fit" && b.status !== "retired" && (!b.domain || !spec.domains.includes(b.domain))).length;
  const oracle = average(teaching.map((l) => Math.max(...STRATEGIES.map((x) => affinity[l.domain]?.[x] ?? 0))));
  const random = average(teaching.map((l) => average(STRATEGIES.map((x) => affinity[l.domain]?.[x] ?? 0))));
  return {
    learner: spec.name,
    condition: cond.name,
    seed: cfg.seed,
    turns: log.length,
    bestRateEarly: rate(early, (l) => l.best),
    bestRateLate: rate(late, (l) => l.best),
    understoodEarly: rate(reacted.slice(0, q), (l) => l.understood),
    understoodLate: rate(reacted.slice(-q), (l) => l.understood),
    regretLate: average(late.map((l) => l.regret)),
    oracleUnderstood: oracle,
    randomUnderstood: random,
    probeRate: rate(log, (l) => l.probe),
    activeBeliefs: live.length,
    totalBeliefs: finalModel.beliefs.length,
    observations: store.observations.length,
    falseActiveBeliefs: falseActive,
    leakedFitBeliefs: leaked,
    driftRecoveryTurns,
    correctionRecreated,
    goalSurvived,
    meanMastery: average([...mastery.values()]),
    msPerTurn: ms / Math.max(1, log.length),
  };
}

export function archetypes(seed: number): LearnerSpec[] {
  const r = mulberry32(seed + 1);
  const base = (name: string, domains: string[], fav: Record<string, Strategy>, extra: Partial<LearnerSpec> = {}): LearnerSpec => ({
    name,
    domains,
    affinity: Object.fromEntries(domains.map((d) => [d, affinityFor(r, fav[d])])),
    learnRate: 0.25,
    noise: 0.1,
    articulate: 0.7,
    overconfidence: 0,
    requestRate: 0.15,
    switching: 0,
    gapDays: 2,
    drift: null,
    correctionAt: null,
    initialMastery: 0.2,
    ...extra,
  });
  return [
    base("example_lover", ["bash", "python"], { bash: "worked_example", python: "worked_example" }),
    base("theory_direct", ["oop"], { oop: "direct_explanation" }),
    base("socratic_fan", ["python"], { python: "socratic" }),
    base("context_dependent", ["bash", "sql"], { bash: "worked_example", sql: "concise_summary" }, { switching: 0.15 }),
    base("drifter", ["python"], { python: "analogy" }, { drift: { atSession: 4 } }),
    base("overconfident", ["bash"], { bash: "step_by_step" }, { overconfidence: 0.8, articulate: 0.5 }),
    base("underconfident", ["python"], { python: "hands_on_task" }, { overconfidence: -0.8, initialMastery: 0.55 }),
    base("noisy", ["oop"], { oop: "analogy" }, { noise: 0.35, articulate: 0.6 }),
    base("silent", ["bash"], { bash: "socratic" }, { articulate: 0.1, requestRate: 0 }),
    base("switcher", ["bash", "python", "sql"], { bash: "step_by_step", python: "worked_example", sql: "direct_explanation" }, { switching: 0.3 }),
    base("long_gap", ["python"], { python: "worked_example" }, { gapDays: 40 }),
    base("corrector", ["bash"], { bash: "hands_on_task" }, { requestRate: 0.5, correctionAt: 4 }),
    base("slow_learner", ["sql"], { sql: "step_by_step" }, { learnRate: 0.08, articulate: 0.4 }),
    base("fast_articulate", ["oop"], { oop: "concise_summary" }, { learnRate: 0.5, articulate: 0.95 }),
  ];
}

export function summarise(reports: LearnerReport[]) {
  const by = new Map<string, LearnerReport[]>();
  for (const r of reports) by.set(r.condition, [...(by.get(r.condition) ?? []), r]);
  const out: Record<string, Record<string, number | null>> = {};
  for (const [c, rs] of by) {
    const drift = rs.filter((r) => r.driftRecoveryTurns != null);
    out[c] = {
      learnerRuns: rs.length,
      bestRateEarly: round(average(rs.map((r) => r.bestRateEarly))),
      bestRateLate: round(average(rs.map((r) => r.bestRateLate))),
      understoodEarly: round(average(rs.map((r) => r.understoodEarly))),
      understoodLate: round(average(rs.map((r) => r.understoodLate))),
      oracleUnderstood: round(average(rs.map((r) => r.oracleUnderstood))),
      randomUnderstood: round(average(rs.map((r) => r.randomUnderstood))),
      regretLate: round(average(rs.map((r) => r.regretLate))),
      probeRate: round(average(rs.map((r) => r.probeRate))),
      activeBeliefs: round(average(rs.map((r) => r.activeBeliefs))),
      falseActiveBeliefs: round(average(rs.map((r) => r.falseActiveBeliefs))),
      leakedFitBeliefs: round(average(rs.map((r) => r.leakedFitBeliefs))),
      driftRecoveryTurns: drift.length ? round(average(drift.map((r) => r.driftRecoveryTurns!))) : null,
      driftUnrecovered: rs.filter((r) => r.learner === "drifter" && r.driftRecoveryTurns == null).length,
      correctionRecreated: rs.filter((r) => r.correctionRecreated === true).length,
      goalSurvived: rs.filter((r) => r.goalSurvived === true).length,
      meanMastery: round(average(rs.map((r) => r.meanMastery))),
      msPerTurn: round(average(rs.map((r) => r.msPerTurn))),
    };
  }
  return out;
}

export function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
}
export const average = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);
const round = (x: number) => Math.round(x * 1000) / 1000;
const pick = <T>(rnd: () => number, xs: T[]) => xs[Math.floor(rnd() * xs.length)];
