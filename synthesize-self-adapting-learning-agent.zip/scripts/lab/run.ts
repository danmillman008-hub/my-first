// Benchmark + ablations. Usage:
//   npx tsx scripts/lab/run.ts [--seeds=2] [--sessions=8] [--turns=10] [--conditions=full,no_adaptation] [--ablations]
import { mkdirSync, writeFileSync } from "node:fs";
import { archetypes, runLearner, summarise, type Condition, type LearnerReport } from "./harness";

const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, "").split("=") as [string, string | undefined]));
const seeds = Number(args.seeds ?? 2);
const sessions = Number(args.sessions ?? 8);
const turns = Number(args.turns ?? 10);

const ALL: Condition[] = [
  { name: "full", ablation: "none", policy: "ucb" },
  { name: "thompson", ablation: "none", policy: "thompson" },
  { name: "no_long_term", ablation: "no_long_term", policy: "ucb" },
  { name: "no_adaptation", ablation: "no_adaptation", policy: "ucb" },
  { name: "no_drift", ablation: "no_drift", policy: "ucb" },
  { name: "no_hierarchy", ablation: "no_hierarchy", policy: "ucb" },
  { name: "no_correction", ablation: "no_correction", policy: "ucb" },
  { name: "no_probe", ablation: "no_probe", policy: "ucb" },
];
const wanted = "ablations" in args ? ALL.map((c) => c.name) : (args.conditions ?? "full,thompson,no_long_term,no_adaptation").split(",");
const conditions = ALL.filter((c) => wanted.includes(c.name));

async function main() {
  const reports: LearnerReport[] = [];
  const t0 = Date.now();
  for (let seed = 1; seed <= seeds; seed++) {
    for (const spec of archetypes(seed)) {
      for (const cond of conditions) {
        reports.push(await runLearner(spec, cond, { sessions, turnsPerSession: turns, seed }));
      }
    }
  }
  const summary = summarise(reports);
  const config = { seeds, sessions, turns, conditions: conditions.map((c) => c.name), archetypes: archetypes(1).map((a) => a.name), seconds: (Date.now() - t0) / 1000 };
  mkdirSync("lab/out", { recursive: true });
  writeFileSync("lab/out/summary.json", JSON.stringify({ config, summary, reports }, null, 2));
  const cols = ["bestRateEarly", "bestRateLate", "understoodEarly", "understoodLate", "oracleUnderstood", "randomUnderstood", "regretLate", "probeRate", "activeBeliefs", "falseActiveBeliefs", "leakedFitBeliefs", "driftRecoveryTurns", "driftUnrecovered", "correctionRecreated", "goalSurvived"];
  console.log(`\n${reports.reduce((s, r) => s + r.turns, 0)} turns in ${config.seconds}s  (seeds=${seeds}, sessions=${sessions}, turns=${turns})\n`);
  console.log(["condition", ...cols].join(" | "));
  console.log(["---", ...cols.map(() => "---")].join(" | "));
  for (const [c, row] of Object.entries(summary)) console.log([c, ...cols.map((k) => (row[k] == null ? "-" : String(row[k])))].join(" | "));
  console.log("\nPer-learner late best-rate (full):");
  for (const r of reports.filter((r) => r.condition === conditions[0].name)) console.log(`  ${r.learner.padEnd(18)} seed${r.seed}  early ${r.bestRateEarly.toFixed(2)} → late ${r.bestRateLate.toFixed(2)}  understood ${r.understoodLate.toFixed(2)} (oracle ${r.oracleUnderstood.toFixed(2)})  beliefs ${r.activeBeliefs} probes ${r.probeRate.toFixed(2)}${r.driftRecoveryTurns != null ? ` drift-recovery ${r.driftRecoveryTurns}` : ""}${r.correctionRecreated != null ? ` correctionRecreated=${r.correctionRecreated}` : ""}`);
  console.log("\nwritten lab/out/summary.json");
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
});
