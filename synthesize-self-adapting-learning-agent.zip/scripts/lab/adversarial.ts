// Mechanism-level attempts to break the guarantees. Each check is a regression
// test for a failure mode discovered in this or a previous attempt.
import { Engine } from "../../src/lib/core/engine";
import { InMemoryStore } from "../../src/lib/core/store";
import { OfflineProvider, OpenAIProvider, validatePerception } from "../../src/lib/providers";
import { influenceOf } from "../../src/lib/core/model";

const results: { name: string; ok: boolean; detail: string }[] = [];
const check = (name: string, ok: boolean, detail = "") => {
  results.push({ name, ok, detail });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? `  — ${detail}` : ""}`);
};
const T0 = Date.UTC(2025, 0, 6, 9);
const min = (n: number) => n * 60_000;
const day = (n: number) => n * 86_400_000;

function fresh(seed = 1) {
  const store = new InMemoryStore();
  const engine = new Engine({ store, provider: new OfflineProvider(), research: null }, { seed });
  return { store, engine };
}

async function main() {
  // 1. Correction attack: the correction sentence quotes the belief; it must not recreate it.
  {
    const { store, engine } = fresh();
    let t = T0;
    for (const s of [0, 1]) {
      await engine.turn("a", "I want to learn bash", new Date(t));
      await engine.turn("a", "Can you show me a concrete example?", new Date((t += min(2))));
      await engine.turn("a", "Got it. Another example please?", new Date((t += min(2))));
      t += day(1) * (s + 1);
    }
    const before = (await engine.model("a", new Date(t))).beliefs.find((b) => b.key === "pref:worked_example");
    check("correction: preference belief exists before correction", Boolean(before && before.status === "active"), before?.status);
    await engine.turn("a", "That's not true about me — I don't actually prefer worked examples.", new Date((t += min(1))));
    const after = (await engine.model("a", new Date(t))).beliefs.filter((b) => b.key === "pref:worked_example");
    check("correction: belief retired, evidence kept", after.every((b) => b.status === "retired") && after.some((b) => b.evidence.correction.length > 0), after.map((b) => b.status).join(","));
    const reqObs = store.observations.filter((o) => o.kind === "request" && o.createdAt.getTime() === t);
    check("correction: quoted text did not become fresh request evidence", reqObs.length === 0);
    await engine.turn("a", "ok, continue", new Date((t += min(1))));
    const again = (await engine.model("a", new Date(t))).beliefs.filter((b) => b.key === "pref:worked_example" && b.status !== "retired");
    check("correction: not recreated next turn from old evidence", again.length === 0);
  }
  // 1b. Correction also clears session working memory about that approach.
  {
    const { engine } = fresh(17);
    let t = T0;
    await engine.turn("p", "I want to learn python", new Date(t));
    await engine.turn("p", "walk me through it step by step", new Date((t += min(2))));
    const r = await engine.turn("p", "That's not true about me, I don't prefer step by step", new Date((t += min(2))));
    const r2 = await engine.turn("p", "ok", new Date((t += min(2))));
    check("correction: session working memory no longer enforces the denied approach", r.strategy !== "step_by_step" && r2.strategy !== "step_by_step", `${r.strategy}, ${r2.strategy}`);
  }
  // 2. Domain leakage: strategy fit learned in OOP must not become a bash belief or bash prior.
  {
    const { engine } = fresh(2);
    let t = T0;
    for (const s of [0, 1]) {
      await engine.turn("b", "Teach me OOP", new Date(t));
      for (let i = 0; i < 8; i++) await engine.turn("b", "Can you show me a concrete example? That makes sense.", new Date((t += min(2))));
      t += day(2);
    }
    const m = await engine.model("b", new Date(t), "bash");
    const fits = m.beliefs.filter((b) => b.kind === "strategy_fit" && b.status !== "retired");
    check("leakage: strategy-fit beliefs are domain-scoped", fits.length > 0 && fits.every((b) => b.domain === "oop"), fits.map((b) => b.domain).join(","));
    check("leakage: OOP fit has zero influence in bash", fits.every((b) => influenceOf(b, new Date(t), "bash") === 0));
    await engine.turn("b", "Now let's switch to bash", new Date((t += min(1))));
    const m2 = await engine.model("b", new Date(t));
    check("leakage: no bash fit belief created by switching", !m2.beliefs.some((b) => b.kind === "strategy_fit" && b.domain === "bash"));
  }
  // 3. Stale turn: every outcome must reference the immediately preceding tutor turn.
  {
    const { store, engine } = fresh(3);
    let t = T0;
    await engine.turn("c", "I want to learn python", new Date(t));
    let ok = true;
    for (let i = 0; i < 12; i++) {
      const prev = [...store.turns].reverse().find((x) => x.role === "tutor")!;
      const r = await engine.turn("c", i % 2 ? "I'm confused" : "That makes sense", new Date((t += min(2))));
      const out = store.outcomes[store.outcomes.length - 1];
      if (r.attribution && out.tutorTurnId !== prev.id) ok = false;
    }
    check("stale turn: outcomes always attributed to the exact previous tutor turn", ok);
  }
  // 4. One-turn-late: after a clear failure the tutor changes approach in the SAME turn.
  {
    const { engine } = fresh(4);
    let t = T0;
    const r0 = await engine.turn("d", "I want to learn sql", new Date(t));
    await engine.turn("d", "That makes sense", new Date((t += min(2))));
    const r = await engine.turn("d", "I'm confused, I don't get it", new Date((t += min(2))));
    check("adaptation is not one turn late", r.strategy !== r0.strategy || r.selection.reasons.some((x) => /track record/.test(x)), `${r0.strategy} -> ${r.strategy}`);
  }
  // 5. Contradiction: sustained failure contests then retires a 'works well' belief.
  {
    const { engine } = fresh(5);
    let t = T0;
    for (const s of [0, 1]) {
      await engine.turn("e", "I want to learn bash", new Date(t));
      for (let i = 0; i < 8; i++) await engine.turn("e", "Just explain it directly. That makes sense.", new Date((t += min(2))));
      t += day(2);
    }
    const fit = (await engine.model("e", new Date(t))).beliefs.find((b) => b.key === "fit:direct_explanation" && b.status === "active");
    check("contradiction: fit belief active after consistent success", Boolean(fit));
    await engine.turn("e", "Back to bash", new Date(t));
    const seen = new Set<string>();
    for (let i = 0; i < 10; i++) {
      await engine.turn("e", "Just explain it directly. I'm confused, that doesn't make sense.", new Date((t += min(2))));
      for (const b of (await engine.model("e", new Date(t))).beliefs.filter((b) => b.key === "fit:direct_explanation")) seen.add(b.status);
    }
    check("contradiction: belief passed through contested and was retired (history kept)", seen.has("contested") && seen.has("retired"), [...seen].join(","));
  }
  // 6. Noise: 400 random turns keep memory bounded.
  {
    const { store, engine } = fresh(6);
    let t = T0;
    const msgs = ["That makes sense", "I'm confused", "show me an example", "0", "maybe foo", "why?", "I already know this", "keep it shorter", "ok"];
    let x = 7;
    for (let i = 0; i < 400; i++) {
      x = (x * 1103515245 + 12345) % 2147483648;
      await engine.turn("f", i % 40 === 0 ? "I want to learn python" : msgs[x % msgs.length], new Date((t += i % 40 === 0 ? day(1) : min(2))));
    }
    const m = await engine.model("f", new Date(t));
    const active = m.beliefs.filter((b) => b.status === "active" || b.status === "contested").length;
    check("noise: active beliefs bounded after 400 noisy turns", active <= 15, `${active} active, ${m.beliefs.length} total, ${store.observations.length} observations`);
    check("noise: observations grow linearly, not explosively", store.observations.length <= 400 * 3);
  }
  // 7. Long gap: goals and continuity survive months.
  {
    const { engine } = fresh(7);
    let t = T0;
    await engine.turn("g", "I want to learn recursion in python", new Date(t));
    await engine.turn("g", "That makes sense", new Date((t += min(2))));
    const r = await engine.turn("g", "Hi again", new Date((t += day(90))));
    const goal = (await engine.model("g", new Date(t))).beliefs.find((b) => b.kind === "goal");
    check("long gap: goal still active after 90 days", goal?.status === "active");
    check("long gap: new session greets with continuity", r.isNewSession && /Welcome back/.test(r.reply));
  }
  // 8. Session boundary: first message of a new session is not attributed to a week-old turn.
  {
    const { store, engine } = fresh(8);
    let t = T0;
    await engine.turn("h", "I want to learn sql", new Date(t));
    await engine.turn("h", "That makes sense", new Date((t += min(2))));
    const n = store.outcomes.length;
    await engine.turn("h", "That makes sense", new Date((t += day(7))));
    check("session boundary: no attribution across sessions", store.outcomes.length === n);
  }
  // 9. Mastery confound: task failures on unknown concepts do not destroy a good strategy belief.
  {
    const { engine } = fresh(9);
    let t = T0;
    await engine.turn("i", "I want to learn oop", new Date(t));
    for (let i = 0; i < 10; i++) await engine.turn("i", i % 2 ? "That makes sense. wrong answer" : "That makes sense. maybe foo", new Date((t += min(2))));
    const traces = (await engine.model("i", new Date(t))).traces;
    const post = traces[0]?.payload.posterior as Record<string, number>;
    const used = traces[0]?.payload.strategy as string;
    check("mastery confound: strategy still rated positively despite failed checks", post[used] > 0.5, `${used}=${post[used]}`);
  }
  // 10. Self-report vs behaviour: discrepancy becomes a tendency, retires when aligned.
  {
    const { engine } = fresh(10);
    let t = T0;
    await engine.turn("j", "I want to learn python. I already know recursion", new Date(t));
    for (let i = 0; i < 4; i++) await engine.turn("j", "maybe foo", new Date((t += min(2))));
    const tend = (await engine.model("j", new Date(t))).beliefs.find((b) => b.key === "tend:overclaims");
    check("self-report: over-claiming tendency observed (not a verdict)", Boolean(tend), tend?.status);
    const cs = (await engine.model("j", new Date(t))).concepts.find((c) => c.concept === "recursion");
    check("self-report: claim and behaviour stored as separate channels", cs?.claimedLevel === 1 && (cs?.pKnownNow ?? 1) < 0.4, `claimed=${cs?.claimedLevel} p=${cs?.pKnownNow?.toFixed(2)}`);
  }
  // 11. Probe budget: at most one probe per session.
  {
    const { store, engine } = fresh(11);
    let t = T0;
    await engine.turn("k", "I want to learn bash", new Date(t));
    for (let i = 0; i < 20; i++) await engine.turn("k", "ok", new Date((t += min(2))));
    const probes = store.turns.filter((x) => x.probe).length;
    check("probe budget: <= 1 probe in a 21-turn session", probes <= 1, `${probes}`);
  }
  // 12. Provider failure: a broken model endpoint never corrupts memory.
  {
    const store = new InMemoryStore();
    const failing = new OpenAIProvider({ apiKey: "x", baseUrl: "http://127.0.0.1:9", fetchImpl: (async () => { throw new Error("down"); }) as unknown as typeof fetch });
    const engine = new Engine({ store, provider: failing, research: null }, { seed: 12 });
    const r = await engine.turn("l", "I want to learn bash", new Date(T0));
    check("provider failure: reply produced via fallback, turn persisted", r.reply.length > 0 && store.turns.length === 2);
  }
  // 13. Schema violation: garbage structured output is rejected/sanitised.
  {
    const bad = validatePerception({ reaction: "elated", requestStrategy: "hypnosis", selfReport: { level: 7 }, observations: [{ kind: "verdict", content: "is dumb" }, { kind: "statement", content: "mentions loops" }, 5] });
    check("schema: invalid enum values dropped, valid items kept", bad !== null && bad.reaction === undefined && bad.requestStrategy === undefined && bad.selfReport === undefined && bad.observations?.length === 1);
    check("schema: non-object output rejected", validatePerception("nope") === null);
  }
  // 14. Research isolation: research never becomes learner evidence.
  {
    const store = new InMemoryStore();
    const engine = new Engine({ store, provider: new OfflineProvider(), research: async (topic) => ({ topic, summary: "Photosynthesis converts light to chemical energy.", sourceUrl: "https://example.org", provider: "test", fetchedAt: new Date(T0) }) }, { seed: 14 });
    await engine.turn("m", "I want to learn photosynthesis", new Date(T0));
    const leaked = store.observations.some((o) => /chemical energy/i.test(o.content)) || store.beliefs.some((b) => /chemical energy/i.test(b.statement));
    check("research: cached with provenance, never written into learner memory", store.research.size === 1 && !leaked);
  }
  // 15. Topic switching: retrieval stays scoped after rapid switches.
  {
    const { engine } = fresh(15);
    let t = T0;
    const seq = ["I want to learn bash", "show me an example", "switch to python please", "just explain it directly", "back to sql", "walk me through it step by step", "bash again"];
    for (const m of seq) await engine.turn("n", m, new Date((t += min(2))));
    const m = await engine.model("n", new Date(t), "bash");
    const prefs = m.beliefs.filter((b) => b.kind === "preference" && b.status !== "retired");
    check("topic switching: preferences recorded per domain, none global", prefs.length >= 2 && prefs.every((b) => b.domain), prefs.map((b) => `${b.domain}:${b.concepts[0]}`).join(" "));
  }
  // 16. Challenge via API path with replacement: supersession recorded.
  {
    const { engine } = fresh(16);
    let t = T0;
    for (const s of [0, 1]) {
      await engine.turn("o", "I want to learn sql", new Date(t));
      await engine.turn("o", "quiz me with questions", new Date((t += min(2))));
      t += day(1 + s);
    }
    const b = (await engine.model("o", new Date(t))).beliefs.find((x) => x.key === "pref:socratic")!;
    const r = await engine.challengeBelief("o", b.id, "I only like questions after a direct explanation", new Date(t));
    const after = await engine.model("o", new Date(t));
    const old = after.beliefs.find((x) => x.id === b.id)!;
    check("challenge: retired with supersession link and replacement recorded", r.ok && old.status === "retired" && old.supersededBy === r.replacement && after.beliefs.some((x) => x.id === r.replacement && x.status === "active"));
  }

  const failed = results.filter((r) => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
  if (failed.length) process.exit(1);
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
});
