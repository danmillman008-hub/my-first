# Private Self-Adapting Learning Agent

**One tutor. One continuous relationship.** You talk naturally — "I want to learn Bash", paste code, ask why, disagree, come back three weeks later — and the agent adapts around that conversation using a persistent, inspectable, *correctable* model of you that it builds from what you actually do, not only what you say.

This repository is the synthesis of sixteen earlier attempts (see [Lessons From the 16 Previous Attempts](#lessons-from-the-16-previous-attempts)). It is not the newest attempt cleaned up; it is a new architecture whose important decisions were chosen by re-running the experiments those attempts disagreed about.

```
learner message
  → perceive          deterministic signals (+ optional validated model patch)      src/lib/core/perceive.ts
  → attribute         outcome of the PREVIOUS tutor turn, by id, before selecting  src/lib/core/model.ts
  → record            observations (short-term evidence, append-only, deduped)     src/lib/core/engine.ts
  → update            concept states (behaviour vs self-report), beliefs (lifecycle)
  → retrieve          beliefs ranked by influence = confidence × status × recency × scope
  → research          unknown domain → isolated research cache (never learner memory) src/lib/research
  → select            request > working memory > contextual bandit (UCB+ε, discounted, hierarchical)
  → probe?            only when uncertainty materially affects this decision (≤1/session)
  → compose           provider writes prose for an already-decided strategy        src/lib/providers
  → trace             why this approach, what changed in memory
```

## Contents

- [What it is](#what-it-is) · [Architecture](#architecture) · [Memory model](#memory-model) · [Strategy adaptation](#strategy-adaptation) · [Research](#research) · [MCP](#mcp) · [Database](#database)
- [Running locally](#running-locally) · [Docker](#docker) · [Environment variables](#environment-variables)
- [The laboratory](#the-laboratory) · [Evaluation methodology](#evaluation-methodology) · [Results](#results) · [Adversarial tests](#adversarial-tests)
- [Limitations](#limitations) · [What has NOT been proven](#what-has-not-been-proven) · [Future real-world validation](#future-real-world-validation)
- [Lessons From the 16 Previous Attempts](#lessons-from-the-16-previous-attempts)

## What it is

A Next.js + PostgreSQL application with a **pure, storage-agnostic core** (`src/lib/core`). The core owns every invariant deterministically — schema validation, persistence, belief lifecycle, evidence counting, timestamps, invalidation, deduplication, domain scoping, attribution. A model provider (OpenAI-compatible via `fetch`, or a deterministic offline provider) is used only for interpretation and prose.

The same core runs against Postgres in the app and against an in-memory store in the lab. That is what makes 27,000 simulated turns run in ~3 seconds with fixed seeds, and what makes every mechanism unit-testable.

## Architecture

| Layer | Where | Responsibility |
| --- | --- | --- |
| Types & taxonomy | `src/lib/core/types.ts` | Observations, beliefs (bi-temporal), concept states, outcomes, turns, sessions, traces; 7 teaching strategies |
| Perception | `src/lib/core/perceive.ts` | Reaction (understood/confused/disagree), explicit approach requests, self-reports, corrections, goals, code, topic switches, answer grading against the previous check. Flags evidence; never classifies the person |
| Epistemic rules | `src/lib/core/model.ts` | Belief status/confidence/dormancy, BKT with a half-life forgetting curve, self-report vs behaviour discrepancy, outcome attribution |
| Strategy bandit | `src/lib/core/bandit.ts` | Discounted per-arm posteriors, hierarchical (other-domain) prior, belief-shifted priors, UCB+ε / Thompson, weight-gated hysteresis, change detector, probe policy |
| Engine | `src/lib/core/engine.ts` | The loop above; `model()`, `challengeBelief()`, `recordObservation()` |
| Store boundary | `src/lib/core/store.ts` (interface + in-memory), `src/lib/store/pg.ts` (Drizzle/Postgres) | Only place that touches storage |
| Providers | `src/lib/providers/index.ts` | `OfflineProvider` (deterministic templates), `OpenAIProvider` (fetch, JSON mode, validated, falls back to offline on any failure) |
| Research | `src/lib/research/index.ts` | Wikipedia summary with provenance, cached in `research_cache`, isolated from learner memory |
| MCP | `src/lib/mcp/server.ts`, `src/app/api/mcp` | Dependency-free JSON-RPC 2.0 / Streamable HTTP (stateless), optional bearer token |
| HTTP | `src/app/api/{chat,memory,health,mcp}` | Chat, memory inspection + correction, health |
| UI | `src/components/Tutor.tsx` | Conversation first; side panel shows beliefs (status, confidence, scope, why, evidence), concept evidence, raw observations; "That's not true about me" |
| Lab | `scripts/lab/*` | Synthetic learners with hidden ground truth, benchmark + ablations, adversarial suite |
| Tests | `tests/core.test.ts` | Unit tests for the pure core |

## Memory model

**Two timescales.**

- **Observations** (short-term, append-only, never edited): `statement, question, self_report, success, mistake, reaction, request, topic_switch, correction, code_shared, context, goal`. Deduplicated per session by a `dedupe_key` so a repeated sentence is not double evidence. An observation can stay an observation forever.
- **Beliefs** (long-term): `preference, strategy_fit, tendency, goal, context`. Status `candidate → active → contested → dormant/retired`. Every belief keeps provenance (`belief_evidence` → observations, relation `supports | contradicts | correction`), support/contradiction counts, the distinct sessions that supported it, a scope (`domain` or general), `valid_from / invalid_at / invalid_reason / superseded_by`, polarity, and timestamps.

**Memory is a prior, not a verdict.**

- Inferred beliefs need ≥2 independent supports across ≥2 sessions (or ≥3 supports) to become active; confidence is a capped Beta mean (never above 0.92). Stated goals are facts and are active immediately.
- Opposite evidence *contests* first (both sides kept); contradiction ≥ max(2, support) retires. Retired beliefs remain inspectable history and are shown in the UI on request.
- Dormancy is computed at read time from recency (60-day half-life on confirmation) and is reversible; nothing decays into oblivion.
- **Corrections.** "That's not true about me" retires every live belief about the named approach (preference *and* strategy fit), records a `correction` evidence edge, optionally records what is true instead with a `superseded_by` link, and — the failure mode found in attempt 4 — the correction sentence itself is never parsed as a fresh request, and strategy-fit beliefs may only re-derive from outcomes recorded *after* the correction.
- **Self-report vs behaviour** are separate channels on each concept state (`claimed_level` vs BKT `p_known`; `basis ∈ prior | claimed | demonstrated`). A claim sets a prior when nothing has been demonstrated and never overrides behaviour. A durable discrepancy (≥3 attempts, gap ≥0.45) becomes an *observed tendency* belief; when the channels agree again it is contradicted and retires naturally.
- **Scope.** Preferences are domain-scoped. Strategy-fit beliefs have zero influence outside their domain — cross-domain information travels only through the shrunk hierarchical prior.
- **Sessions** are inferred from time (45-minute gap), never managed by the learner. The first message of a new session is not attributed to a week-old tutor turn.

## Strategy adaptation

Seven approaches: `direct_explanation, worked_example, analogy, step_by_step, socratic, hands_on_task, concise_summary` (chance = 0.14).

Selection order, recovered from the mission attempt (best historical style match): **the present outranks memory.**

1. An explicit request this turn (or a probe answer) wins.
2. A spontaneous request earlier this session in the same domain, unless it has since failed. Probe answers are honoured on the spot but are *not* standing orders — the ablation showed forced-choice answers otherwise hurt.
3. The bandit over per-domain posteriors.

Evidence model (`bandit.ts`):

- Each attributed outcome ∈ [−1, 1] with an attribution weight. **Per-arm discounting** γ = 0.9 (effective memory ≈ 10 outcomes of that arm) plus slow wall-clock decay (floor 0.35). Domain-wide discounting was tried and forgot too much; a staleness bonus for abandoned arms was tried and lowered best-rate (both kept behind env flags, off by default).
- **Hierarchical prior:** pooled evidence from *other* domains, capped at ~4 pseudo-observations. Including the current domain double-counted its own evidence (found by ablation).
- Preference / strategy-fit beliefs shift the prior by their influence (domain-scoped; contested beliefs at half weight).
- **Policy:** UCB with an uncertainty bonus and ε = max(0.04, 0.3/(1+W/6)). Thompson sampling is implemented and selectable (`STRATEGY_POLICY=thompson`); it lost the head-to-head again (see Results), replicating attempt 3's finding.
- **Hysteresis gated on evidence weight:** win-stay only when the last outcome was strong (weight ≥ 0.5), the current arm is decent (mean ≥ 0.55) and nothing is clearly better; after a strong failure the tutor switches unless the arm is established — and switches anyway after two strong failures in a row (change detector).
- **Attribution** (`model.ts`) separates teaching signal from mastery signal: reactions count fully; task results at half weight; a failure on a concept the learner did not yet know at quarter weight (mastery confound); a success — or "makes sense" — on a concept already known at minimal weight (the positive confound, new in this version). Requests for a different approach count against the previous one. Corrections and topic switches are not attributed at all.
- Strategy-fit beliefs are derived per domain from ≥4 discounted outcomes (mean ≥ 0.35 → "works well", ≤ −0.3 → "has not worked"), contested when the mean drops below 0.1 or after three recent failures, retired when it flips.

**Probing** is rare by construction: once per session at most, ≥12 turns apart, only when the top two arms are within 0.08 with little evidence — plus one cold-start question along the most discriminative axis (concrete vs abstract). Observed rate: ~2 probes per 100 turns.

## Research

An unknown domain (anything without a seed pack) is looked up on Wikipedia (`opensearch` → REST summary) and cached in `research_cache` with source URL, provider and time. Research is handed to the composer as *background* only. Adversarial check 14 verifies that research text never appears in observations or beliefs. Set `RESEARCH_DISABLED=1` to turn it off; the lab always runs without network.

## MCP

`POST /api/mcp` — JSON-RPC 2.0, MCP Streamable HTTP in stateless JSON mode (`initialize`, `ping`, `tools/list`, `tools/call`, batch). Tools: `get_learner_context`, `tutor_turn`, `record_observation`, `list_beliefs`, `challenge_belief`. External assistants share the *same* learner model instead of keeping disconnected memories; anything they contribute enters as an `external` observation and must earn belief status like any other evidence. Set `MCP_ACCESS_TOKEN` to require `Authorization: Bearer …`. Learner ids are validated (`[a-zA-Z0-9_-]{3,64}`).

## Database

`src/db/schema.ts`: `learners, sessions, turns, observations, beliefs, belief_evidence, concept_states, strategy_outcomes, traces, research_cache, lab_runs`. Evidence tables (`observations, belief_evidence, strategy_outcomes, turns, traces`) are append-only from the application's point of view. Beliefs are only patched through the lifecycle functions and are never deleted. Foreign keys enforce referential integrity. Schema is applied with `npx drizzle-kit push` (idempotent; the Docker image does this on start).

## Running locally

```bash
cp .env.example .env            # set DATABASE_URL (a local Postgres)
npm install
npx drizzle-kit push            # create tables
npm run build && npm start      # http://localhost:3000
```

Without `OPENAI_API_KEY` the app runs in offline mode: the entire learner-model machinery is live; explanations are compact templates from the seed packs (Bash, Python, OOP, SQL). With a key, any OpenAI-compatible endpoint is used for perception enrichment and prose; every structured output is validated and any failure degrades to the offline composer without touching memory.

```bash
npm test                        # unit tests (pure core)
npm run adversarial             # 26 mechanism-level checks
npm run lab                     # benchmark: full vs thompson vs no_long_term vs no_adaptation
npm run ablation                # all 8 conditions; writes lab/out/summary.json
LAB_TRACE=drifter npm run lab   # per-turn trace of one archetype
```

## Docker

```bash
docker compose up --build       # Postgres + app on :3000, schema applied on start
```

Secrets are injected through environment variables (`OPENAI_API_KEY`, `MCP_ACCESS_TOKEN`, …); nothing is baked into the image. `.env` is git- and docker-ignored.

## Environment variables

| Variable | Purpose |
| --- | --- |
| `DATABASE_URL` | PostgreSQL connection (required) |
| `OPENAI_API_KEY`, `OPENAI_BASE_URL`, `OPENAI_MODEL` | Optional OpenAI-compatible provider (default model `gpt-4o-mini`) |
| `STRATEGY_POLICY` | `ucb` (default) or `thompson` |
| `MCP_ACCESS_TOKEN` | Optional bearer token for `/api/mcp` |
| `RESEARCH_DISABLED` | `1` disables Wikipedia research |
| `STRATEGY_GAMMA`, `STRATEGY_STALE`, `STRATEGY_CB` | Lab knobs (defaults 0.9, 1 = off, 2) — documented so the sweeps are reproducible |

## The laboratory

`scripts/lab/harness.ts` drives the real engine (in-memory store, offline provider, fixed seeds) with synthetic learners whose ground truth is hidden: per-domain strategy affinities (favourite 0.88, others 0.25–0.5), hidden mastery with a learning rate and *forgetting between sessions*, reaction noise, articulateness (silent learners only answer checks), over/under-confidence (self-reports), request rate, topic switching, session gaps, preference drift at a given session, and a scripted correction of the tutor's top belief. The tutor only ever sees text.

14 archetypes: `example_lover, theory_direct, socratic_fan, context_dependent (bash≠sql), drifter, overconfident, underconfident, noisy (35% flips), silent, switcher (3 domains), long_gap (40 days), corrector, slow_learner, fast_articulate`.

Conditions: `full, thompson, no_long_term, no_adaptation, no_drift, no_hierarchy, no_correction, no_probe`.

Metrics per learner: best-strategy rate early/late (chance 0.14), understood rate vs oracle and random, regret vs oracle, probe rate, active/total beliefs, false active beliefs (active positive preference/fit whose true affinity < 0.6), leaked fit beliefs (outside the learner's domains), drift recovery (turns after the flip until 4 of 6 picks are best), correction recreation, goal survival over long gaps, memory growth, ms/turn.

## Evaluation methodology

- Deterministic: `seed` fixes the learner's RNG and the tutor's RNG; the same command reproduces the same numbers. Configuration, seeds, archetypes and per-learner reports are written to `lab/out/summary.json`.
- No gaming: the tutor has no access to affinities or hidden mastery; no test names or expected answers are special-cased in `src/`. The learner model in the harness was changed twice during development for *realism* (immediate checks became informative after understanding; forgetting between sessions) — both changes made the benchmark harder, not easier, and are documented in the lessons below.
- Ablations remove one mechanism at a time inside the same engine; policies are compared inside the same run.

## Results

3 seeds × 14 archetypes × 8 conditions × 8 sessions × 10 turns = **26,880 turns in ~3 s** (`npm run ablation`, `--seeds=3`):

| condition | best-rate early | best-rate late | understood late | regret late | probes/turn | active beliefs | false active | drift recovery (turns) | correction recreated |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **full** | 0.39 | **0.65** | 0.59 | **0.17** | 0.02 | 5.7 | 0.29 | 24 | 0 |
| thompson | 0.39 | 0.54 | 0.57 | 0.22 | 0.02 | 6.6 | 0.26 | 12 | 0 |
| no_long_term | 0.37 | 0.46 | 0.53 | 0.26 | 0.03 | 0 | 0 | 5 (2 unrecovered) | 0 |
| no_adaptation | 0.18 | 0.22 | 0.44 | 0.39 | 0.03 | 4.3 | 0.07 | – | 0 |
| no_drift | 0.39 | 0.59 | 0.58 | 0.20 | 0.02 | 5.8 | 0.19 | 28 (1 unrecovered) | 0 |
| no_hierarchy | 0.40 | 0.64 | 0.59 | 0.17 | 0.02 | 5.5 | 0.31 | 24 | 0 |
| no_correction | 0.39 | 0.65 | 0.59 | 0.17 | 0.02 | 5.6 | 0.29 | 24 | **3 / 3** |
| no_probe | 0.39 | 0.67 | 0.58 | 0.16 | 0 | 5.5 | 0.26 | 23 | 0 |

Oracle understood rate 0.88, random 0.45. Leaked fit beliefs: 0 in every condition. Goals survived 40-day gaps in every condition that keeps beliefs.

Reading the table honestly:

- **Adaptation works** (0.65 vs 0.22 fixed, chance 0.14) and **the belief layer adds value beyond the bandit** (0.65 vs 0.46 without long-term memory) — the same qualitative result attempts 3 and 4 reported, reproduced here in one harness.
- **UCB+ε beats Thompson** (0.65 vs 0.54), replicating attempt 3 and contradicting attempt 4's choice. Discount-capped counts keep Thompson posteriors wide.
- **Discounting matters for drift** (no_drift: 1 unrecovered drifter, lower late rate) but the gap is modest at this horizon.
- **The hierarchical prior is roughly neutral** on this cohort (0.64 vs 0.65): most archetypes are single-domain, where it cannot help. It is kept because it is cheap, correctly formulated (other-domain pooling only), and the multi-domain archetypes are where it applies; we do not claim it is proven.
- **Probing is neutral to slightly negative** (0.67 without). One question per session buys little in simulation because synthetic learners never volunteer more than their favourite. It is kept at a very low rate for real learners, where a single well-placed question can be worth more than ten turns of exploration — but this is a hypothesis, not a result.
- **The correction mechanism does exactly one thing**: without it, every scripted correction was recreated (3/3); with it, none. It costs nothing elsewhere.
- Per-learner variance is high (single-domain learners typically reach 0.8–1.0 late; `switcher`, `noisy` and `silent` are the hard cases at 0.3–0.6). Silent learners provide only task signal, which is deliberately down-weighted; that is the price of not confusing mastery with teaching.

## Adversarial tests

`npm run adversarial` — 26/26 passing. Each check is a regression test for a failure mode found in this or a previous attempt:

correction attack (belief retired, evidence kept, quoted text not re-ingested, not recreated next turn) · domain leakage (fit beliefs domain-scoped, zero influence elsewhere, no belief created by switching) · stale turn (every outcome references the exact previous tutor turn) · adaptation not one turn late · contradiction (active → contested → retired, history kept) · noise (≤15 active beliefs after 400 noisy turns; observations linear) · long gap (goal survives 90 days; continuity greeting) · session boundary (no cross-session attribution) · mastery confound (failed checks on unknown concepts do not destroy a good strategy) · self-report vs behaviour (tendency observed; channels separate) · probe budget · provider failure (fallback reply, memory intact) · schema violations sanitised · research isolation · topic switching (per-domain preferences, none global) · challenge with replacement (supersession link).

## Limitations

- Offline explanations are templates over four seed packs; pedagogy quality with a real model is not measured here.
- The synthetic reaction model is simple by design (affinity + mastery + noise). It measures the adaptation machinery, not learning.
- Perception is regex-based offline; with a model, its structured patch is merged but never allowed to override the deterministic safety-net fields.
- The concept graph from the four graph-native attempts was not carried forward: none of them measured an adaptation gain from it, and the belief→evidence and belief→superseding-belief edges plus domain scoping cover the provenance needs here. A prerequisite graph remains a reasonable future addition *if* a measured benefit appears.
- No accounts: identity is a private cookie (or an explicit id via MCP). Multi-device continuity would need an identity layer.

## What has NOT been proven

- Any effect on real human learning outcomes, retention, transfer, or satisfaction.
- That the seven-strategy taxonomy is the right one for real learners.
- That the hierarchical prior or the probe policy help real learners (both are neutral in simulation).
- Robustness of model-based perception across providers (structurally tested with a failing endpoint and schema fuzzing only).

## Future real-world validation

The architecture already records what such a study needs: every tutor turn stores its strategy and reasons; every learner turn stores attributed outcomes; concept states carry behaviour and self-report separately; beliefs are bi-temporal. A real-user protocol would: (1) randomise learners between `full` and `no_adaptation` via `EngineOptions.ablation`; (2) measure time-to-understanding per concept, delayed retention checks (the forgetting curve is already modelled), error recovery after confusion, preference stability, and satisfaction; (3) audit corrections (how often learners say "that's not true" and whether beliefs are recreated); (4) compare probe frequency against annoyance.

## Lessons From the 16 Previous Attempts

The repository held 16 archives (two exact duplicates, one unrelated driving game, one conventional LMS). They were read as a research history, not as candidates. Summary of the evidence map:

| Attempt(s) | What it was | Recovered | Rejected / negative evidence |
| --- | --- | --- | --- |
| `private-self-adapting-learning-agent (4)` | Most complete epistemics: candidate/active/contested/dormant/retired, bi-temporal beliefs, correction fix, domain-scoped fit, self-report channel, discounted Thompson | The belief lifecycle, correction semantics, half-weight task attribution, observation taxonomy, MCP tool set | Thompson (best-rate ≈0.5); its per-domain discount keyed correctly but its selection under-exploited |
| `(3)` | 20 archetypes, 3 conditions, UCB vs Thompson head-to-head, 25 adversarial checks, mock-LLM tests | UCB+ε, effective-weight stale guard, base-rate caution for preferences, "let's continue" must not read as a request, adversarial-suite style | Consolidation as a separate batch pass (added latency and a second code path; here consolidation happens per turn deterministically) |
| `private-self-adapting-agent-mission` | Present > working memory > scoped beliefs > default; VoI-gated probing; "claims never set p_known"; touch counts never used | The selection ordering (best historical style match, 0.88), probe rationing, self-report as prior | Single style ladder without domain scoping |
| `(1)/(2)` (duplicates) | Memory graph + explorer UI | Evidence-trail UI idea | A graph as the primary store made retrieval and invalidation harder |
| `build-self-adapting-learning-agent`, root README attempt | Curriculum-first: Wikipedia research, RefD prerequisites, packs, affect | Isolated research with provenance; seed packs; "self-report becomes a prior, never evidence" | Curriculum and affect engines dominated the code with no measured adaptation gain |
| `agentic-software-build-mission` | Deterministic rule policy, BKT with modulated guess/slip, ACT-R dormancy, official MCP SDK | Deterministic policy over model output; dormancy as reversible read-time state | Official SDK as a hard dependency (portability) |
| `adaptive-teaching-mcp-integration` | Dependency-free JSON-RPC MCP layer over existing functions | The dispatcher design (kept verbatim in spirit) | – |
| `build-graph-native-ai-tutor`, `graph-native-adaptive-*`, `build-adaptive-graph-ai-tutor` (×2) | Graphify corpus graphs, Bloom-level downgrades | Nothing structural | Four attempts, no measured adaptation benefit from the graph; heavy tooling |
| `edtech-platform-development-prompt` | Courses, profiles, dashboards | – | The opposite of "one continuous relationship"; negative evidence for manual profile management |
| `lightweight-open-world-driving-game` | Unrelated | – | – |

Contradictions resolved by experiment in this version:

1. **Thompson vs UCB** — attempt 4 chose discounted Thompson, attempt 3 found UCB+ε decisively better. Re-run here in one harness: UCB 0.65 vs Thompson 0.54 late best-rate. UCB is the default; Thompson stays selectable.
2. **Where to discount** — per-arm (attempt 4's effect) vs domain-wide (textbook discounted UCB). Domain-wide forgot too much with seven arms (0.43–0.52); per-arm wins. The known weakness of per-arm discounting (an abandoned arm frozen at its worst moment) was addressed not by a staleness bonus (tried: worse) but by weight-gated hysteresis, so low-weight "already known" successes can no longer keep a mediocre arm alive.
3. **The hierarchical prior** must pool *other* domains. Every previous version (and my first one) pooled all domains, double-counting the current domain's evidence for single-domain learners.

Failures discovered and fixed in this version (each has a regression test or lab metric):

- The learner's *answer* to a check ("return", "self") matched concept keywords and pinned the tutor to the same concept for many turns — perception now ignores concept mentions in graded answers.
- Hesitant wrong attempts ending in "?" ("hmm, baz?") were treated as questions and dropped, biasing every arm upward — the grader now uses question words, not punctuation.
- "I'm confused" was never detected (regex boundary bug) — caught by unit tests.
- Forced-choice probe answers became standing orders for the whole session — probe answers are honoured once.
- Positive mastery confound: a correct answer or "makes sense" on an already-known concept rewarded whatever strategy happened to be running — attribution now down-weights it, mirroring attempt 4's negative-confound fix.
- Mastery without forgetting made the tutor overconfident that concepts were "known", discarding real signal — replaced by a half-life model whose stability doubles with each success.
- Two simulator-realism fixes that made the benchmark *harder*: immediate checks are informative after understanding; hidden mastery decays between sessions.

Why the final architecture differs from every earlier attempt: the core is pure and storage-agnostic (no earlier attempt could run its lab without a database, which is why their evaluation loops were slow and rarely re-run); the provider is only allowed to interpret and write, never to decide; and every disagreement between attempts became a switch in the lab rather than an opinion in a README.
