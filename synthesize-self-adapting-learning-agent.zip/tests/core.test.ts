import { test } from "node:test";
import assert from "node:assert/strict";
import { perceive, gradeAnswer } from "../src/lib/core/perceive";
import { attribute, bktUpdate, statusFor, applyClaim, discrepancy, retainedPKnown, effectiveStatus } from "../src/lib/core/model";
import { posteriors, selectStrategy, decideProbe, mulberry32 } from "../src/lib/core/bandit";
import { matchCorrection } from "../src/lib/core/engine";
import type { Belief, ConceptState, StrategyOutcome, Turn } from "../src/lib/core/types";

const now = new Date(Date.UTC(2025, 0, 6));
const tutor = (over: Partial<Turn> = {}): Turn => ({ id: "t1", learnerId: "l", sessionId: "s", role: "tutor", content: "", strategy: "worked_example", domain: "bash", concept: "pipes", probe: false, meta: { check: { concept: "pipes", accept: ["stdout"] } }, createdAt: now, ...over });

test("perception: reactions, requests, corrections, self-reports", () => {
  assert.equal(perceive("That makes sense now", tutor(), "bash").reaction, "understood");
  assert.equal(perceive("I'm confused by this", tutor(), "bash").reaction, "confused");
  assert.equal(perceive("Can you show me an example?", tutor(), "bash").requestStrategy, "worked_example");
  assert.equal(perceive("walk me through it step by step", tutor(), "bash").requestStrategy, "step_by_step");
  const c = perceive("That's not true about me, I don't prefer examples", tutor(), "bash");
  assert.ok(c.correction);
  assert.equal(c.requestStrategy, null, "a correction never doubles as a request");
  assert.equal(perceive("I already know pipes", tutor(), "bash").selfReport?.level, 1);
  assert.equal(perceive("I want to learn python", null, null).goal, "python");
  assert.equal(perceive("I want to learn python", null, null).domain, "python");
});

test("perception: grading against the previous check", () => {
  assert.equal(perceive("stdout", tutor(), "bash").taskResult, "correct");
  assert.equal(perceive("hmm, baz?", tutor(), "bash").taskResult, "incorrect");
  assert.equal(perceive("what does a pipe do?", tutor(), "bash").taskResult, null);
  assert.equal(perceive("stdout", tutor({ probe: true }), "bash").taskResult, null);
  assert.equal(gradeAnswer("It goes to standard output I think", ["stdout", "standard output"]), "correct");
});

test("attribution: reaction vs task signal and mastery confound", () => {
  const und = attribute({ reaction: "understood", taskResult: null, requestedDifferentStrategy: false, isCorrection: false, topicSwitch: false, priorPKnown: 0.2 })!;
  assert.equal(und.outcome, 1);
  const fail = attribute({ reaction: "neutral", taskResult: "incorrect", requestedDifferentStrategy: false, isCorrection: false, topicSwitch: false, priorPKnown: 0.2 })!;
  assert.equal(fail.weight, 0.25, "failure on an unknown concept is quarter weight");
  const failKnown = attribute({ reaction: "neutral", taskResult: "incorrect", requestedDifferentStrategy: false, isCorrection: false, topicSwitch: false, priorPKnown: 0.6 })!;
  assert.equal(failKnown.weight, 0.5);
  const known = attribute({ reaction: "neutral", taskResult: "correct", requestedDifferentStrategy: false, isCorrection: false, topicSwitch: false, priorPKnown: 0.9 })!;
  assert.equal(known.weight, 0.15, "success on a known concept says little about teaching");
  assert.equal(attribute({ reaction: "understood", taskResult: null, requestedDifferentStrategy: false, isCorrection: true, topicSwitch: false, priorPKnown: null }), null);
  assert.equal(attribute({ reaction: "understood", taskResult: null, requestedDifferentStrategy: false, isCorrection: false, topicSwitch: true, priorPKnown: null }), null);
});

test("beliefs: inferred beliefs must earn activation; contradictions contest then retire", () => {
  assert.equal(statusFor("inferred", 1, 0, 1, "candidate"), "candidate");
  assert.equal(statusFor("inferred", 2, 0, 1, "candidate"), "candidate", "two supports in one session is not enough");
  assert.equal(statusFor("inferred", 2, 0, 2, "candidate"), "active");
  assert.equal(statusFor("inferred", 3, 0, 1, "candidate"), "active");
  assert.equal(statusFor("inferred", 3, 1, 2, "active"), "active", "one dissent against three supports lowers confidence but does not contest");
  assert.equal(statusFor("inferred", 2, 1, 2, "active"), "contested");
  assert.equal(statusFor("inferred", 3, 3, 2, "contested"), "retired");
  assert.equal(statusFor("stated", 1, 0, 1, "candidate"), "active", "stated goals are facts, not hypotheses");
  assert.equal(statusFor("inferred", 5, 0, 3, "retired"), "retired", "retired stays retired");
});

test("beliefs: dormancy is computed at read time and reversible", () => {
  const b: Belief = { id: "b", learnerId: "l", kind: "preference", key: "pref:analogy", statement: "", domain: "bash", concepts: ["analogy"], source: "inferred", polarity: 1, status: "active", confidence: 0.7, supportCount: 3, contradictionCount: 0, sessionIds: ["a", "b"], validFrom: now, invalidAt: null, invalidReason: null, supersededBy: null, lastConfirmedAt: now, createdAt: now, updatedAt: now };
  assert.equal(effectiveStatus(b, now), "active");
  assert.equal(effectiveStatus(b, new Date(now.getTime() + 200 * 86_400_000)), "dormant");
  assert.equal(effectiveStatus({ ...b, status: "dormant", lastConfirmedAt: now }, now), "active");
});

test("mastery: BKT moves with evidence, claims set a prior only, forgetting regresses to 0.5", () => {
  assert.ok(bktUpdate(0.3, true) > 0.3);
  assert.ok(bktUpdate(0.3, false) < 0.3);
  const c: ConceptState = { id: "l|recursion", learnerId: "l", concept: "recursion", domain: "python", pKnown: 0.25, basis: "prior", attempts: 0, successes: 0, claimedLevel: null, claimedAt: null, lastEvidenceAt: now };
  const claimed = { ...c, ...applyClaim(c, 1, now) };
  assert.equal(claimed.basis, "claimed");
  const demonstrated: ConceptState = { ...claimed, basis: "demonstrated", attempts: 4, successes: 0, pKnown: 0.1 };
  assert.equal(discrepancy(demonstrated), "overclaims");
  assert.equal(applyClaim(demonstrated, 1, now).pKnown, undefined, "a claim never overrides demonstrated behaviour");
  const later = retainedPKnown({ ...demonstrated, pKnown: 0.95, successes: 1 }, new Date(now.getTime() + 4 * 86_400_000));
  assert.ok(later < 0.95 && later > 0.5);
});

test("bandit: learns from outcomes, explicit request wins, hierarchy pools OTHER domains only", () => {
  const rnd = mulberry32(1);
  const mk = (strategy: StrategyOutcome["strategy"], domain: string, outcome: number, i: number): StrategyOutcome => ({ id: `o${i}`, learnerId: "l", sessionId: "s", tutorTurnId: `t${i}`, strategy, domain, concept: null, outcome, weight: 1, signal: "reaction", createdAt: new Date(now.getTime() + i * 60_000) });
  const outcomes = [...Array(8)].map((_, i) => mk("analogy", "bash", 1, i)).concat([...Array(8)].map((_, i) => mk("socratic", "bash", -1, 10 + i)));
  const p = posteriors(outcomes, "bash", [], now, "none");
  assert.ok(p.analogy.mean > 0.8 && p.socratic.mean < 0.3);
  const pOther = posteriors(outcomes, "sql", [], now, "none");
  assert.ok(pOther.analogy.mean > 0.5 && pOther.analogy.mean < p.analogy.mean, "shrunk prior carries information without copying it");
  assert.ok(pOther.analogy.w <= 4.01, "global influence capped");
  const pNoH = posteriors(outcomes, "sql", [], now, "no_hierarchy");
  assert.equal(pNoH.analogy.mean, 0.5);
  const sel = selectStrategy({ outcomes, domain: "bash", beliefs: [], currentStrategy: "analogy", lastOutcome: 1, now, rnd, policy: "ucb", ablation: "none", requested: null, recentRequest: null, consecutiveBad: 0 });
  assert.equal(sel.strategy, "analogy");
  const req = selectStrategy({ outcomes, domain: "bash", beliefs: [], currentStrategy: "analogy", lastOutcome: 1, now, rnd, policy: "ucb", ablation: "none", requested: "hands_on_task", recentRequest: null, consecutiveBad: 0 });
  assert.equal(req.strategy, "hands_on_task");
  assert.equal(req.source, "request");
});

test("bandit: change detector switches an established strategy after repeated failures", () => {
  const rnd = mulberry32(2);
  const mk = (strategy: StrategyOutcome["strategy"], outcome: number, i: number): StrategyOutcome => ({ id: `o${i}`, learnerId: "l", sessionId: "s", tutorTurnId: `t${i}`, strategy, domain: "bash", concept: null, outcome, weight: 1, signal: "reaction", createdAt: new Date(now.getTime() + i * 60_000) });
  const outcomes = [...Array(10)].map((_, i) => mk("analogy", 1, i)).concat([mk("analogy", -1, 20), mk("analogy", -1, 21)]);
  const sel = selectStrategy({ outcomes, domain: "bash", beliefs: [], currentStrategy: "analogy", lastOutcome: -1, lastWeight: 1, now, rnd, policy: "ucb", ablation: "none", requested: null, recentRequest: null, consecutiveBad: 2 });
  assert.notEqual(sel.strategy, "analogy");
});

test("probe: rare, budgeted, and only when the decision is sensitive to uncertainty", () => {
  const flat = posteriors([], "bash", [], now, "none");
  assert.equal(decideProbe({ posterior: flat, sessionTurn: 1, sessionProbes: 0, turnsSinceLastProbe: null, requested: false, ablation: "none" }).probe, false);
  assert.equal(decideProbe({ posterior: flat, sessionTurn: 3, sessionProbes: 0, turnsSinceLastProbe: null, requested: false, ablation: "none" }).probe, true);
  assert.equal(decideProbe({ posterior: flat, sessionTurn: 3, sessionProbes: 1, turnsSinceLastProbe: null, requested: false, ablation: "none" }).probe, false);
  assert.equal(decideProbe({ posterior: flat, sessionTurn: 3, sessionProbes: 0, turnsSinceLastProbe: 3, requested: false, ablation: "none" }).probe, false);
});

test("correction matching denies every belief about the named approach", () => {
  const mk = (id: string, kind: Belief["kind"], statement: string, s: string): Belief => ({ id, learnerId: "l", kind, key: `${kind}:${s}`, statement, domain: "bash", concepts: [s], source: "inferred", polarity: 1, status: "active", confidence: 0.7, supportCount: 3, contradictionCount: 0, sessionIds: ["a"], validFrom: now, invalidAt: null, invalidReason: null, supersededBy: null, lastConfirmedAt: now, createdAt: now, updatedAt: now });
  const beliefs = [mk("1", "preference", "Prefers a concrete worked example", "worked_example"), mk("2", "strategy_fit", "worked example works well in bash", "worked_example"), mk("3", "preference", "Finds analogies helpful", "analogy")];
  const hit = matchCorrection("that's not true about me, I don't prefer worked examples", beliefs);
  assert.deepEqual(hit.map((b) => b.id).sort(), ["1", "2"]);
});
