# Data types

Every value has a type: int, float, str, bool, list, dict... The type determines what operations make sense.

## In plain words
Numbers, text, and true/false are different kinds of things and behave differently.

## Deeper
Python is dynamically but strongly typed: names have no fixed type, but values do, and Python refuses silent coercions like 1 + '1'. `type(v)` reveals the runtime type; `isinstance` checks membership including subclasses.

## Example
```python
print(type(3), type(3.0), type('3'), type(True))
```

## Analogy
Types are like units in physics: you can add metres to metres, but not metres to seconds.

## Common misconceptions
- '3' + '4' equals 7.
