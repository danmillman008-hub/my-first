# Hashing

A hash function maps a value to an integer so it can be placed in a bucket; dicts and sets rely on it.

## In plain words
Hashing turns a value into a number that says which drawer it belongs in, so you can find it quickly.

## Deeper
Equal objects must have equal hashes. Collisions are resolved by probing; a good hash spreads keys uniformly, giving O(1) average operations but O(n) worst case. Mutable objects are unhashable because mutation would move them to the wrong bucket.

## Example
```python
print(hash('a') == hash('a'))
print(hash((1, 2)))
```

## Analogy
Hashing is like sorting mail into pigeonholes by the first letter of the surname.

## Common misconceptions
- Hashes are unique.
