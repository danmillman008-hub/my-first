# Functions

def defines a reusable block with parameters; return sends a value back to the caller.

## In plain words
A function is a named recipe: give it ingredients (arguments) and it hands back a result.

## Deeper
Functions are first-class objects: they can be passed, returned and stored. Default arguments are evaluated once at definition time (the mutable default pitfall). A function without an explicit return returns None.

## Example
```python
def square(n):
    return n * n
print(square(4))
```

## Analogy
A function is a vending machine: same input button, same output, and you do not care what happens inside.

## Common misconceptions
- print and return are the same thing.
