# Closures

An inner function that remembers variables from its enclosing scope after that scope has finished.

## In plain words
A closure is a function that carries a little backpack of variables from where it was created.

## Deeper
Free variables are stored in cell objects referenced by __closure__. Late binding: closures created in a loop all see the final loop value unless you bind a default argument.

## Example
```python
def make_adder(k):
    def add(x):
        return x + k
    return add
print(make_adder(3)(4))
```

## Analogy
A closure is like a to-do note that includes the context you wrote it in.

## Common misconceptions
- Inner functions lose access to outer variables once the outer returns.
