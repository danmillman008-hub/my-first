# Tuples

Tuples are immutable ordered sequences, often used for fixed records and multiple return values.

## In plain words
A tuple is a list you cannot change after creating it.

## Deeper
Immutability makes tuples hashable (if their elements are), so they can be dict keys and set members. Tuple unpacking `a, b = b, a` is evaluated right-to-left as one tuple, which is why swapping works without a temporary.

## Example
```python
p = (3, 4)
x, y = p
print(x * y)
```

## Analogy
A tuple is like a sealed envelope with a fixed set of items.

## Common misconceptions
- Tuples are just slower lists.
