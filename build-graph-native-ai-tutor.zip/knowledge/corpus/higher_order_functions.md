# Higher-order functions

Functions that take or return functions: map, filter, sorted(key=...), and custom combinators.

## In plain words
A higher-order function treats other functions as ingredients.

## Deeper
Because functions are objects, strategy can be injected as data. key= functions in sorted/min/max avoid comparator boilerplate; functools.reduce folds a sequence; lambda creates small anonymous functions.

## Example
```python
words = ['bb', 'a', 'ccc']
print(sorted(words, key=len))
```

## Analogy
A higher-order function is a manager who delegates the actual work to whichever specialist you hand over.

## Common misconceptions
- map returns a list.
