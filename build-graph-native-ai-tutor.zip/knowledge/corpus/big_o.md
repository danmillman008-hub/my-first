# Big-O complexity

Big-O describes how running time or memory grows with input size, ignoring constants.

## In plain words
Big-O tells you how much slower a program gets when you give it much more data.

## Deeper
O(1) < O(log n) < O(n) < O(n log n) < O(n^2). It is an upper bound on growth; constants and lower-order terms are dropped. Amortised analysis explains why list.append is O(1) despite occasional resizes.

## Example
```python
# linear search: O(n)
def find(xs, t):
    for i, x in enumerate(xs):
        if x == t: return i
    return -1
```

## Analogy
Big-O is like asking how a commute scales: walking grows with distance, teleporting does not.

## Common misconceptions
- O(n) code is always slower than O(1) code for small inputs.
