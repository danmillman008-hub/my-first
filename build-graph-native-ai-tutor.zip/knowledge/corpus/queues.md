# Queues

A FIFO structure: enqueue at the back, dequeue at the front. Use collections.deque.

## In plain words
A queue is a line at a shop: first to arrive is first served.

## Deeper
deque gives O(1) appends and pops at both ends via a doubly linked block list. Breadth-first search, task scheduling and buffering are queue-shaped problems.

## Example
```python
from collections import deque
q = deque([1, 2, 3])
q.append(4)
print(q.popleft(), list(q))
```

## Analogy
A queue is a conveyor belt at a checkout.

## Common misconceptions
- list.pop(0) is O(1).
