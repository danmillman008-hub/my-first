# Strings

Strings are immutable sequences of characters supporting indexing, slicing, and rich methods.

## In plain words
A string is text. You can pick characters out of it and glue strings together, but you cannot change one in place.

## Deeper
Because str is immutable, every 'modification' creates a new object; building a large string in a loop is O(n^2) unless you collect parts and join. Slicing s[a:b] is half-open and never raises on out-of-range bounds.

## Example
```python
s = 'python'
print(s[0], s[-1], s[1:4], s.upper())
```

## Analogy
A string is like a printed word: to change a letter you have to print a new word.

## Common misconceptions
- s[1:4] includes index 4.
