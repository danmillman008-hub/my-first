# Inheritance

A subclass reuses and specialises a parent class; method lookup follows the MRO.

## In plain words
Inheritance lets a new class start from an existing one and change only what differs.

## Deeper
Python uses C3 linearisation for the method resolution order, which is what makes super() cooperative in multiple inheritance. Prefer composition when the relationship is not truly 'is-a'.

## Example
```python
class Animal:
    def speak(self): return '...'
class Dog(Animal):
    def speak(self): return 'woof'
print(Dog().speak())
```

## Analogy
Inheritance is like a family recipe passed down and tweaked by each generation.

## Common misconceptions
- A subclass must re-implement every method.
