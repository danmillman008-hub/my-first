# Scope

Names are resolved with the LEGB rule: Local, Enclosing, Global, Built-in.

## In plain words
Scope decides which x you mean when several exist: the nearest one wins.

## Deeper
Assignment inside a function makes a name local for the entire function body, which is why reading a global then assigning it raises UnboundLocalError. `global` and `nonlocal` declare intent to rebind an outer name.

## Example
```python
x = 'global'
def f():
    x = 'local'
    return x
print(f(), x)
```

## Analogy
Scope is like rooms in a house: you look for your keys in the room you are in before checking the hallway.

## Common misconceptions
- Assigning x inside a function changes the global x.
