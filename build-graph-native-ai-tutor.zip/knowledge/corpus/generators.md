# Generators

A function with yield returns a lazy iterator that resumes where it paused.

## In plain words
A generator hands out values one at a time and remembers where it left off.

## Deeper
Each yield suspends the frame, preserving locals. Generators enable pipelines over unbounded streams with constant memory. send() and yield-from build coroutines and delegation.

## Example
```python
def countdown(n):
    while n > 0:
        yield n
        n -= 1
print(list(countdown(3)))
```

## Analogy
A generator is a pez dispenser: one candy per push, nothing prepared in advance.

## Common misconceptions
- Calling a generator function runs its body immediately.
