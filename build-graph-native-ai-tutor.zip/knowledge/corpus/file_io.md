# File I/O

open() returns a file object; the with statement closes it automatically.

## In plain words
Reading and writing files is like opening a notebook, reading or writing, and closing it.

## Deeper
with uses the context-manager protocol (__enter__/__exit__) so the file closes even on exceptions. Iterating a file yields lines lazily; text mode decodes with an encoding you should specify explicitly.

## Example
```python
with open('notes.txt', 'w') as f:
    f.write('hello\n')
```

## Analogy
A with block is like borrowing a library book: it is returned automatically when you leave.

## Common misconceptions
- You never need to close files.
