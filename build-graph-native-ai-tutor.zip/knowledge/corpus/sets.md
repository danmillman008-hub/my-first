# Sets

Sets are unordered collections of unique hashable items with fast membership tests.

## In plain words
A set is a bag where each item can appear only once.

## Deeper
Sets share the hash-table machinery of dicts; membership is O(1) average versus O(n) for lists. Set algebra (|, &, -, ^) expresses union, intersection, difference and symmetric difference directly.

## Example
```python
a = {1, 2, 3}
b = {3, 4}
print(a & b, a | b, a - b)
```

## Analogy
A set is like a guest list where duplicate names are simply ignored.

## Common misconceptions
- Sets keep insertion order.
