# Binary search

Find a target in a sorted sequence by repeatedly halving the search interval: O(log n).

## In plain words
Binary search is how you find a word in a dictionary: open in the middle, decide left or right, repeat.

## Deeper
Invariant: the target, if present, lies in [lo, hi). Off-by-one errors are the classic pitfall; the bisect module provides tested implementations. Requires random access and sorted input.

## Example
```python
def bsearch(xs, t):
    lo, hi = 0, len(xs)
    while lo < hi:
        mid = (lo + hi) // 2
        if xs[mid] < t: lo = mid + 1
        else: hi = mid
    return lo
```

## Analogy
Binary search is the 'higher or lower' number guessing game played optimally.

## Common misconceptions
- Binary search works on unsorted lists.
