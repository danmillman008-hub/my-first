# Conditionals

if / elif / else selects a branch based on truthiness of expressions.

## In plain words
Conditionals let a program choose between paths, like a fork in the road.

## Deeper
Python evaluates truthiness: 0, '', [], None are falsy. `and`/`or` short-circuit and return an operand, not necessarily a bool. Chained comparisons `a < b < c` mean `a < b and b < c`.

## Example
```python
n = 7
if n % 2 == 0:
    print('even')
else:
    print('odd')
```

## Analogy
A conditional is a bouncer at a door: if you meet the rule you go one way, otherwise another.

## Common misconceptions
- elif branches are all checked even after one matches.
