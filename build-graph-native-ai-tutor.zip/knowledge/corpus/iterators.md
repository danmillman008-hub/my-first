# Iterators

An iterator produces values one at a time via __next__ and signals the end with StopIteration.

## In plain words
An iterator is like a ticket dispenser: each pull gives the next ticket until the roll is empty.

## Deeper
iter(obj) calls __iter__; for-loops, unpacking and comprehensions all drive this protocol. Iterators are one-shot: once exhausted they stay empty, a common source of 'my loop ran zero times' bugs.

## Example
```python
it = iter([1, 2])
print(next(it), next(it))
```

## Analogy
An iterator is a bookmark that moves forward one page per read.

## Common misconceptions
- An iterator can be restarted by iterating again.
