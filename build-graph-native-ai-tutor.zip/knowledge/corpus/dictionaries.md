# Dictionaries

Dictionaries map hashable keys to values with average O(1) lookup, insertion, and deletion.

## In plain words
A dictionary is like a phone book: look up a name (key) to get a number (value).

## Deeper
dict is a hash table with insertion-ordered iteration (since 3.7). Keys must be hashable and immutable in practice. Missing keys raise KeyError; use .get(k, default) or collections.defaultdict for counting patterns.

## Example
```python
counts = {}
for ch in 'banana':
    counts[ch] = counts.get(ch, 0) + 1
print(counts)
```

## Analogy
A dictionary is a coat check: hand over a ticket (key), get back exactly your coat (value).

## Common misconceptions
- Dicts are ordered by key.
- Lists can be dict keys.
