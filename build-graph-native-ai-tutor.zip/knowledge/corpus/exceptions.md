# Exceptions

Errors are objects raised at runtime; try/except catches them, finally always runs.

## In plain words
An exception is Python shouting that something went wrong; try/except lets you catch the shout and respond.

## Deeper
Exceptions propagate up the call stack until caught. Catching broad Exception hides bugs; catch specific types. `else` runs when no exception occurred; `finally` runs regardless, even after return.

## Example
```python
try:
    int('x')
except ValueError as e:
    print('bad input:', e)
finally:
    print('done')
```

## Analogy
try/except is like a safety net under a trapeze artist.

## Common misconceptions
- finally does not run after an exception.
