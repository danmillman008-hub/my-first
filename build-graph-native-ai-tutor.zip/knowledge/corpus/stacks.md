# Stacks

A LIFO structure: push and pop from the same end. Lists implement it with append/pop.

## In plain words
A stack is a pile of plates: the last one you put on is the first one you take off.

## Deeper
Call stacks, undo histories and bracket matching are stacks. append/pop on the end of a list are O(1); popping from the front is O(n), which is why queues use deque.

## Example
```python
stack = []
for ch in '([])':
    if ch in '([': stack.append(ch)
    else: stack.pop()
print('balanced' if not stack else 'unbalanced')
```

## Analogy
A stack is the browser back button: the most recent page comes back first.

## Common misconceptions
- Stacks are FIFO.
