# List comprehensions

A compact expression that builds a list from an iterable with optional filtering.

## In plain words
A list comprehension is a one-line loop that builds a new list.

## Deeper
[f(x) for x in xs if p(x)] desugars to a loop with append. Comprehensions have their own scope in Python 3. Generator expressions use parentheses and are lazy, which matters for memory.

## Example
```python
squares = [n * n for n in range(5) if n % 2 == 0]
print(squares)
```

## Analogy
A comprehension is like a factory line: items go in one end, get transformed and filtered, and come out as a list.

## Common misconceptions
- The if filter applies after squaring.
