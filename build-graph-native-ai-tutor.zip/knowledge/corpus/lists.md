# Lists

Lists are ordered, mutable sequences. Append, index, slice, and iterate over them.

## In plain words
A list is a row of slots holding values in order; you can add, remove, and replace items.

## Deeper
Lists are dynamic arrays: indexing is O(1), append is amortised O(1), insertion at the front is O(n). Aliasing matters: `b = a` does not copy; `b = a[:]` or `list(a)` does a shallow copy.

## Example
```python
a = [1, 2, 3]
b = a
b.append(4)
print(a)  # [1, 2, 3, 4]
```

## Analogy
A list is like a train: cars in order, and you can couple new cars on the end.

## Common misconceptions
- b = a makes an independent copy.
