# Decorators

A decorator is a callable that takes a function and returns a replacement, applied with @ syntax.

## In plain words
A decorator wraps a function with extra behaviour, like gift-wrapping a present.

## Deeper
@deco above def f is exactly f = deco(f). Decorators compose bottom-up. functools.wraps preserves metadata. Decorators with arguments are factories returning decorators.

## Example
```python
def shout(fn):
    def wrapper(*a):
        return fn(*a).upper()
    return wrapper
@shout
def hi(name): return 'hi ' + name
print(hi('sam'))
```

## Analogy
A decorator is a phone case: same phone inside, extra behaviour outside.

## Common misconceptions
- Decorators change the function in place.
