# Classes

A class bundles data (attributes) and behaviour (methods); instances are created by calling the class.

## In plain words
A class is a blueprint; each object built from it is a house with its own furniture.

## Deeper
__init__ initialises a new instance; self is the instance passed explicitly. Class attributes are shared, instance attributes are per-object. Everything in Python is an object, including classes themselves.

## Example
```python
class Counter:
    def __init__(self):
        self.n = 0
    def inc(self):
        self.n += 1
c = Counter(); c.inc(); print(c.n)
```

## Analogy
A class is a cookie cutter; instances are the cookies.

## Common misconceptions
- self is a keyword.
