# Sorting

sorted() and list.sort() use Timsort, a stable O(n log n) algorithm; key= customises order.

## In plain words
Sorting puts things in order; Python's built-in sort is fast and keeps equal items in their original order.

## Deeper
Stability lets you sort by multiple keys in successive passes. Timsort exploits existing runs, so nearly-sorted data approaches O(n). reverse=True flips order without breaking stability.

## Example
```python
pairs = [(2, 'b'), (1, 'z'), (2, 'a')]
print(sorted(pairs, key=lambda p: p[0]))
```

## Analogy
Sorting with a key is like ordering books by author while keeping same-author books in the order you found them.

## Common misconceptions
- sorted() sorts the list in place.
