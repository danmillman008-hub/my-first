# Recursion

A recursive function calls itself on a smaller input and stops at a base case.

## In plain words
Recursion solves a big problem by solving a slightly smaller copy of the same problem, until the problem is tiny.

## Deeper
Each call gets its own frame on the call stack; without a base case the stack overflows (RecursionError near depth 1000). Many recursions map to loops or an explicit stack; tree-shaped problems are where recursion shines.

## Example
```python
def fact(n):
    if n <= 1:
        return 1
    return n * fact(n - 1)
print(fact(5))
```

## Analogy
Recursion is like Russian nesting dolls: open one, find a smaller one, until you reach the solid one.

## Common misconceptions
- Recursion always loops forever.
- The base case is optional.
