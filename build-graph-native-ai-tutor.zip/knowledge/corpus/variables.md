# Variables

A variable is a name bound to a value. Assignment with = binds the name; reassigning rebinds it.

## In plain words
Think of a variable as a labelled box you can put a value in and look at later.

## Deeper
In Python, names are references to objects, not memory slots. `x = 5` makes the name x point at an int object. Rebinding changes what x points to, not the object itself. This matters for mutable objects: two names can refer to the same list.

## Example
```python
x = 5
y = x
x = x + 1
print(x, y)  # 6 5
```

## Analogy
A variable is like a nametag stuck on a thing; you can move the nametag to a different thing.

## Common misconceptions
- Assignment copies the object (it does not; it binds a name).
