# Loops

for iterates over any iterable; while repeats while a condition holds. break and continue alter flow.

## In plain words
A loop repeats a block of code, once per item or until a condition stops being true.

## Deeper
for calls iter() on the iterable and next() until StopIteration, so it works on generators, files and dict views. The loop variable persists after the loop. `for ... else` runs the else block only when no break occurred.

## Example
```python
total = 0
for i in range(1, 5):
    total += i
print(total)  # 10
```

## Analogy
A for loop is like dealing cards: one card per player until the deck is empty.

## Common misconceptions
- range(1, 5) includes 5.
