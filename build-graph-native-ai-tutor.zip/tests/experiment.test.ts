// Small synthetic-data stability experiment (engineering check, not an efficacy study).
import { test } from "node:test";
import assert from "node:assert/strict";
import { TutorService } from "@/tutor/session";
import { MemoryStore } from "@/tutor/store";
import { DEPTHS, STYLES } from "@/adaptive/types";

process.env.TUTOR_DISABLE_LLM = "1";
const DAY = 86_400_000;
const T0 = Date.parse("2026-04-01T09:00:00Z");

type Hist = { id: string; script: { msg: string; gapMs?: number }[]; expect: string };
const H: Hist[] = [
  { id: "A-clarifier", expect: "concise depth, low deep pref, confusion handled", script: ["explain scope", "I don't understand", "what do you mean?", "still confused", "can you clarify again?", "huh?"].map((m) => ({ msg: m })) },
  { id: "B-deep", expect: "deep depth, DEEPEN/EXPLORE actions", script: ["explain iterators", "more detail please", "go deeper under the hood", "elaborate, interesting", "what about the internals?"].map((m) => ({ msg: m })) },
  { id: "C-examples", expect: "example style", script: ["explain sorting", "show me an example", "another example please", "example with code?", "one more sample"].map((m) => ({ msg: m })) },
  { id: "D-visual", expect: "visual style", script: ["explain hashing", "can you draw a diagram?", "show me a picture of how it connects", "visualize it", "map it out"].map((m) => ({ msg: m })) },
  { id: "E-inactive", expect: "branch decays to dormant, then reactivates", script: [{ msg: "explain queues" }, { msg: "got it" }, { msg: "remind me about queues", gapMs: 45 * DAY }] },
  { id: "F-repeat", expect: "activation saturates, strategy varies", script: Array.from({ length: 10 }, () => ({ msg: "explain exceptions" })) },
  { id: "G-changing", expect: "preference reverses without wild oscillation", script: [...["explain classes", "simpler please", "simpler", "easier please"], ...["now more detail", "go deeper", "elaborate under the hood", "more depth please", "deeper still"]].map((m) => ({ msg: m })) },
];

test("synthetic learner histories: bounded, stable, sensitive", async () => {
  const svc = new TutorService(new MemoryStore());
  const rows: string[] = [];
  const results: Record<string, Awaited<ReturnType<TutorService["handleTurn"]>>[]> = {};
  for (const h of H) {
    let t = T0;
    const out = [];
    for (const step of h.script) {
      t += step.gapMs ?? 60_000;
      const r = await svc.handleTurn(h.id, step.msg, { now: t, allowLlm: false });
      out.push(r);
      // Invariants on every turn.
      for (const v of Object.values(r.trace.affect)) assert.ok(Number.isFinite(v) && v >= 0 && v <= 1, `affect bounded ${h.id}`);
      for (const d of DEPTHS) assert.ok(r.trace.preferences.depth[d] >= 0.05 && r.trace.preferences.depth[d] <= 0.95);
      for (const s of STYLES) assert.ok(r.trace.preferences.style[s] >= 0.05 && r.trace.preferences.style[s] <= 0.95);
      for (const b of [...r.state.branches.active, ...r.state.branches.weak, ...r.state.branches.dormant]) assert.ok(b.activation >= 0 && b.activation <= 1 && b.mastery >= 0 && b.mastery <= 1);
    }
    results[h.id] = out;
    const last = out.at(-1)!;
    rows.push(`${h.id.padEnd(12)} depth=${last.state.depth.padEnd(8)} style=${last.state.style.padEnd(12)} actions=${out.map((r) => r.trace.decision.action.slice(0, 6)).join(">")}  conf=${last.trace.affect.confusion} cur=${last.trace.affect.curiosity}`);
  }
  console.log("\n" + rows.join("\n") + "\n");

  // Sensitivity: each profile lands where it should.
  assert.equal(results["A-clarifier"].at(-1)!.state.depth, "concise");
  assert.equal(results["B-deep"].at(-1)!.state.depth, "deep");
  assert.equal(results["C-examples"].at(-1)!.state.style, "example");
  assert.equal(results["D-visual"].at(-1)!.state.style, "visual");
  // Sparse/noisy: a single unrelated visual request in a deep learner's history must not flip style.
  const deepPrefs = results["B-deep"].at(-1)!.trace.preferences;
  assert.ok(deepPrefs.style.visual < deepPrefs.style.example + 0.2);

  // E: dormancy + reactivation across 45 days.
  const e = results["E-inactive"];
  assert.ok(e.at(-1)!.trace.reactivated.includes("queues"));
  assert.ok(e.at(-1)!.trace.signals.some((s) => s.type === "abandonment"));
  assert.equal(e.at(-1)!.trace.decision.action, "REACTIVATE_BRANCH");

  // F: repeated identical messages -> activation saturates below 1, actions vary, no confusion drift.
  const f = results["F-repeat"];
  const fAct = f.at(-1)!.state.branches.active.find((b) => b.conceptId === "exceptions")!.activation;
  assert.ok(fAct > 0.9 && fAct <= 1, `saturates: ${fAct}`);
  assert.ok(new Set(f.map((r) => r.trace.decision.action)).size >= 3, "varies strategy");
  assert.ok(f.at(-1)!.trace.affect.confusion < 0.2);

  // G: preference reversal without oscillation: count sign changes of (deep - concise) over time.
  const g = results["G-changing"];
  const series = g.map((r) => r.trace.preferences.depth.deep - r.trace.preferences.depth.concise);
  let flips = 0;
  for (let i = 1; i < series.length; i++) if (Math.sign(series[i]) !== Math.sign(series[i - 1]) && series[i] !== 0) flips++;
  assert.ok(flips <= 2, `at most one real reversal (+ initial): flips=${flips} series=${series.map((x) => x.toFixed(2)).join(",")}`);
  assert.ok(series[3] < 0 && series.at(-1)! > 0, "concise first, deep later");
  assert.equal(g.at(-1)!.state.depth, "deep");

  // Sparse data: one interaction gives a sane, near-prior state.
  const [one] = [await svc.handleTurn("sparse", "explain strings", { now: T0, allowLlm: false })];
  assert.equal(one.trace.decision.action, "DIRECT_EXPLANATION");
  assert.equal(one.state.depth, "standard");
  assert.ok(one.state.branches.active.length === 1);
  assert.ok(one.trace.delta.mastery.after - one.trace.delta.mastery.before < 0.1, "one exposure barely moves mastery");
});
