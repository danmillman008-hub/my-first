import { test } from "node:test";
import assert from "node:assert/strict";
import { activation, status, reinforce, newConceptState, updateMastery, HALF_LIFE_DAYS } from "@/adaptive/knowledge";
import { newLearnerModel, updatePreferences, updateAffect, updateTendencies, PREFERENCE_PRIOR } from "@/adaptive/learner";
import { extractSignals, judgePrediction } from "@/adaptive/signals";
import { decide } from "@/adaptive/policy";
import type { PolicyInput, Signal } from "@/adaptive/types";

const DAY = 86_400_000;
const T0 = Date.parse("2026-01-01T00:00:00Z");

test("decay is deterministic, bounded and halves per half-life", () => {
  const s = { ...newConceptState("lists", T0), strength: 1, interactionCount: 1 };
  assert.equal(activation(s, T0), 1);
  assert.ok(Math.abs(activation(s, T0 + HALF_LIFE_DAYS * DAY) - 0.5) < 1e-9);
  assert.ok(Math.abs(activation(s, T0 + 2 * HALF_LIFE_DAYS * DAY) - 0.25) < 1e-9);
  assert.equal(activation(s, T0 - DAY), 1, "future timestamps clamp to age 0");
  assert.equal(activation(s, T0 + 365 * DAY) >= 0, true);
});

test("branch lifecycle: active -> weak -> dormant -> reactivated, history kept", () => {
  let s = newConceptState("recursion", T0);
  assert.equal(status(s, T0), "untouched");
  s = reinforce(s, T0).state;
  s = reinforce(s, T0 + 1000).state;
  s = { ...s, mastery: 0.8 };
  assert.equal(status(s, T0 + 1000), "active");
  assert.equal(status(s, T0 + 12 * DAY), "weak");
  const later = T0 + 40 * DAY;
  assert.equal(status(s, later), "dormant");
  assert.equal(s.mastery, 0.8, "dormant keeps mastery");
  assert.equal(s.interactionCount, 2, "dormant keeps history");
  const r = reinforce(s, later);
  assert.equal(r.reactivated, true);
  assert.equal(status(r.state, later), "active");
  assert.equal(r.state.interactionCount, 3);
});

test("reinforcement saturates at 1 and never overflows", () => {
  let s = newConceptState("x", T0);
  for (let i = 0; i < 200; i++) s = reinforce(s, T0 + i * 1000, 1).state;
  assert.ok(s.strength <= 1 && s.strength > 0.99);
});

test("mastery is a bounded belief; confident beliefs move slower", () => {
  let s = newConceptState("x", T0);
  for (let i = 0; i < 50; i++) s = updateMastery(s, 1, 1);
  assert.ok(s.mastery <= 1 && s.mastery > 0.9);
  const before = s.mastery;
  const s2 = updateMastery(s, -1, 1);
  const fresh = updateMastery(newConceptState("y", T0), -1, 1);
  assert.ok(before - s2.mastery < 0.2 - fresh.mastery + 0.2, "high-confidence belief moves less than a fresh one");
  assert.ok(s2.mastery >= 0);
});

test("preferences are bounded, evolve with evidence and regress without it", () => {
  const m = newLearnerModel();
  let p = m.preferences;
  const simp: Signal[] = [{ type: "simplification_request", weight: 0.9 }];
  for (let i = 0; i < 5; i++) p = updatePreferences(p, simp);
  assert.ok(p.depth.concise > 0.7, `concise rose: ${p.depth.concise}`);
  assert.ok(p.depth.deep < 0.15, `deep fell: ${p.depth.deep}`);
  for (let i = 0; i < 300; i++) p = updatePreferences(p, simp);
  assert.ok(p.depth.concise <= 0.95 && p.depth.deep >= 0.05, "bounded");
  // reversal: deep engagement should overturn it
  const deep: Signal[] = [{ type: "depth_request", weight: 0.9 }];
  for (let i = 0; i < 8; i++) p = updatePreferences(p, deep);
  assert.ok(p.depth.deep > p.depth.concise, `preference reversed: deep=${p.depth.deep} concise=${p.depth.concise}`);
  // regression toward prior with neutral turns
  const neutral: Signal[] = [{ type: "direct_question", weight: 0.5 }];
  const beforeRegress = p.depth.deep;
  for (let i = 0; i < 40; i++) p = updatePreferences(p, neutral);
  assert.ok(p.depth.deep < beforeRegress && p.depth.deep > PREFERENCE_PRIOR.depth.deep, "regresses toward but not past prior");
});

test("one noisy interaction does not dominate preferences", () => {
  const p = updatePreferences(newLearnerModel().preferences, [{ type: "visual_request", weight: 0.85 }]);
  assert.ok(p.style.visual < 0.6, `single visual request only nudges: ${p.style.visual}`);
  assert.ok(p.style.example > 0.5, "example still competitive");
});

test("affect is short-lived and needs repetition for frustration", () => {
  const m = newLearnerModel();
  const conf: Signal[] = [{ type: "clarification_request", weight: 0.8 }, { type: "confusion_signal", weight: 0.7 }];
  let t = updateTendencies(m.tendencies, conf);
  let a = updateAffect(m.affect, conf, t);
  assert.ok(a.confusion > 0.3);
  assert.ok(a.frustration < 0.05, "first stumble is not frustration");
  for (let i = 0; i < 3; i++) {
    t = updateTendencies(t, conf);
    a = updateAffect(a, conf, t);
  }
  assert.ok(a.frustration > 0.1, `repeated confusion -> some frustration: ${a.frustration}`);
  const ok: Signal[] = [{ type: "successful_continuation", weight: 0.7 }];
  for (let i = 0; i < 4; i++) a = updateAffect(a, ok, t);
  assert.ok(a.confusion < 0.1, `confusion fades: ${a.confusion}`);
});

test("signal extraction: contradictory and empty inputs are safe", () => {
  const ctx = { session: { recentActions: [], turnsOnFocus: 0 }, now: T0, mentioned: [], relatedToFocus: [] };
  const s1 = extractSignals("simpler please but also go much deeper under the hood", ctx);
  assert.ok(s1.some((s) => s.type === "simplification_request") && s1.some((s) => s.type === "depth_request"));
  const s2 = extractSignals("", ctx);
  assert.ok(s2.some((s) => s.type === "direct_question"));
  assert.equal(new Set(s2.map((s) => s.type)).size, s2.length, "no duplicate signal types");
});

test("prediction judging tolerates formatting", () => {
  assert.equal(judgePrediction("6 5", "6 5").correct, true);
  assert.equal(judgePrediction("I think it prints 6 and 5", "6 5").correct, true);
  assert.equal(judgePrediction("7 5", "6 5").correct, false);
  assert.equal(judgePrediction("", "6 5").correct, false);
});

function baseInput(over: Partial<PolicyInput> = {}): PolicyInput {
  const learner = newLearnerModel();
  const st = { ...newConceptState("lists", T0), interactionCount: 1, strength: 0.6, mastery: 0.4 };
  return {
    now: T0,
    focus: { id: "lists", state: st, status: "active", activation: 0.6, hasCode: true, wasDormant: false },
    prerequisites: [{ id: "variables", state: { ...newConceptState("variables", T0), mastery: 0.2 }, status: "untouched", activation: 0 }],
    related: [{ id: "tuples", state: newConceptState("tuples", T0), status: "untouched", activation: 0 }],
    mentioned: ["lists"],
    learner,
    signals: [{ type: "direct_question", weight: 0.5 }],
    tools: { python: true },
    ...over,
  };
}

test("policy: confusion + weak prerequisite -> PREREQUISITE; curiosity + mastery -> EXPLORE/DEEPEN", () => {
  const confused = baseInput();
  confused.learner.affect.confusion = 0.7;
  confused.signals = [{ type: "clarification_request", weight: 0.8 }, { type: "confusion_signal", weight: 0.7 }];
  confused.focus.state.mastery = 0.25;
  const d1 = decide(confused);
  assert.ok(["PREREQUISITE", "SIMPLIFY"].includes(d1.action), `got ${d1.action}`);
  assert.equal(d1.depth, "concise");

  const curious = baseInput();
  curious.learner.affect.curiosity = 0.8;
  curious.focus.state.mastery = 0.85;
  curious.signals = [{ type: "curiosity_signal", weight: 0.6 }, { type: "successful_continuation", weight: 0.7 }];
  const d2 = decide(curious);
  assert.ok(["EXPLORE_RELATED", "DEEPEN"].includes(d2.action), `got ${d2.action}`);
  assert.ok(d2.reasons.length > 5, "decision is explainable");
});

test("policy: tools are vetoed when unavailable; dormant known focus -> REACTIVATE", () => {
  const noPy = baseInput({ tools: { python: false } });
  noPy.signals = [{ type: "step_request", weight: 0.85 }];
  const d = decide(noPy);
  assert.notEqual(d.action, "EXECUTE");
  assert.notEqual(d.action, "PREDICT");
  const dormant = baseInput();
  dormant.focus.status = "dormant";
  dormant.focus.wasDormant = true;
  dormant.focus.state.mastery = 0.8;
  assert.equal(decide(dormant).action, "REACTIVATE_BRANCH");
});
