// End-to-end conversations through the real application layer (Graphify CLI,
// python tracer, template realiser), in-memory store, LLM disabled for determinism.
import { test } from "node:test";
import assert from "node:assert/strict";
import { TutorService } from "@/tutor/session";
import { MemoryStore } from "@/tutor/store";

process.env.TUTOR_DISABLE_LLM = "1";
const DAY = 86_400_000;
const T0 = Date.parse("2026-03-01T09:00:00Z");
const VERBOSE = !!process.env.VERBOSE;

async function run(svc: TutorService, id: string, msgs: string[], start = T0, gapMs = 60_000) {
  const out = [];
  let t = start;
  for (const m of msgs) {
    const r = await svc.handleTurn(id, m, { now: t, allowLlm: false });
    if (VERBOSE) console.log(`[${id}] "${m}" -> ${r.trace.decision.action}/${r.trace.decision.depth}/${r.trace.decision.style}/${r.trace.tool} focus=${r.trace.focus} conf=${r.trace.affect.confusion} cur=${r.trace.affect.curiosity}`);
    out.push(r);
    t += gapMs;
  }
  return out;
}

test("Scenario A: repeated simplification requests shift depth to concise and change the action", async () => {
  const svc = new TutorService(new MemoryStore());
  const rs = await run(svc, "A", ["explain closures", "can you make that simpler?", "still too complex, simpler please", "simpler, plain english"]);
  const first = rs[0].trace.decision;
  const last = rs.at(-1)!;
  assert.equal(first.action, "DIRECT_EXPLANATION");
  assert.notEqual(last.trace.decision.action, "DIRECT_EXPLANATION");
  assert.equal(last.state.depth, "concise");
  assert.ok(last.trace.preferences.depth.concise > 0.7);
  // A neutral follow-up on a new concept now inherits the learned depth.
  const [next] = await run(svc, "A", ["what are decorators?"], T0 + 10 * 60_000);
  assert.equal(next.trace.decision.depth, "concise", `new concept respects learned depth: ${next.trace.decision.depth}`);
  assert.ok(next.reply.length < rs[0].reply.length, "concise reply is shorter than the first standard one");
});

test("Scenario B: deep engagement raises depth; C: confusion changes strategy", async () => {
  const svc = new TutorService(new MemoryStore());
  const b = await run(svc, "B", ["explain generators", "tell me more detail about how it works internally", "go deeper, what about the internals of the frame?", "elaborate more, this is interesting"]);
  assert.ok(b.slice(1).every((r) => r.trace.decision.action === "DEEPEN" || r.trace.decision.action === "EXPLORE_RELATED"), b.map((r) => r.trace.decision.action).join(","));
  assert.equal(b.at(-1)!.state.depth, "deep");
  assert.ok(b.at(-1)!.trace.preferences.depth.deep > 0.6, `deep pref: ${b.at(-1)!.trace.preferences.depth.deep}`);

  const c = await run(svc, "C", ["how does recursion work", "I don't understand", "what do you mean? I'm confused", "still don't get it"]);
  const actions = c.map((r) => r.trace.decision.action);
  assert.ok(actions.slice(1).some((a) => ["SIMPLIFY", "PREREQUISITE", "EXAMPLE", "ANALOGY", "EXECUTE"].includes(a)), actions.join(","));
  assert.ok(c.at(-1)!.trace.affect.confusion > 0.5);
  assert.ok(c.at(-1)!.trace.decision.depth === "concise" || c.at(-1)!.trace.decision.depth === "standard");
  assert.ok(c.at(-1)!.trace.delta.mastery.after <= c[0].trace.delta.mastery.after, "confusion does not raise mastery");
});

test("Scenario D: curiosity with mastery leads to exploration of related concepts", async () => {
  const svc = new TutorService(new MemoryStore());
  const rs = await run(svc, "D", ["explain stacks", "got it, makes sense", "interesting! what else connects to this?", "cool, what about related ideas, what's next?"]);
  const actions = rs.map((r) => r.trace.decision.action);
  assert.ok(actions.some((a) => a === "EXPLORE_RELATED" || a === "DEEPEN" || a === "COMPARE"), actions.join(","));
  assert.ok(rs.at(-1)!.trace.affect.curiosity > 0.4);
});

test("Scenarios E-H: strengthening, decay, dormancy (not deleted), reactivation", async () => {
  const svc = new TutorService(new MemoryStore());
  await run(svc, "E", ["explain dictionaries", "show me an example of dictionaries", "got it", "dictionaries again please"]);
  const r1 = await run(svc, "E", ["explain sets"], T0 + 10 * 60_000);
  let snap = r1[0].state;
  const dictActivation = snap.branches.active.find((b) => b.conceptId === "dictionaries")!.activation;
  assert.ok(dictActivation > 0.7, `repeated use strengthens: ${dictActivation}`);

  // Advance 12 days: dictionaries decays to weak; 40 days: dormant.
  snap = await svc.snapshot("E", T0 + 12 * DAY);
  assert.ok(snap.branches.weak.some((b) => b.conceptId === "dictionaries"), JSON.stringify(snap.branches));
  snap = await svc.snapshot("E", T0 + 40 * DAY);
  const dormant = snap.branches.dormant.find((b) => b.conceptId === "dictionaries");
  assert.ok(dormant, "dormant after long inactivity");
  assert.ok(dormant!.interactionCount >= 4 && dormant!.mastery > 0.2, "history retained");

  // Reactivation by asking again.
  const [back] = await run(svc, "E", ["remind me how dictionaries work"], T0 + 40 * DAY);
  assert.ok(back.trace.reactivated.includes("dictionaries"), JSON.stringify(back.trace));
  assert.equal(back.trace.decision.action, "REACTIVATE_BRANCH");
  assert.ok(back.state.branches.active.some((b) => b.conceptId === "dictionaries"));
  assert.ok(back.trace.signals.some((s) => s.type === "abandonment"));
});

test("Scenario I: same message, different histories -> different teaching actions", async () => {
  const svc = new TutorService(new MemoryStore());
  await run(svc, "novice", ["what are list comprehensions", "I don't understand", "confused, simpler please"]);
  await run(svc, "expert", ["what are list comprehensions", "go deeper into the internals", "interesting, more detail please"]);
  const [n] = await run(svc, "novice", ["ok, tell me about generators"], T0 + 60 * 60_000);
  const [x] = await run(svc, "expert", ["ok, tell me about generators"], T0 + 60 * 60_000);
  assert.notEqual(n.trace.decision.depth, x.trace.decision.depth, `novice=${n.trace.decision.depth} expert=${x.trace.decision.depth}`);
  assert.notEqual(n.reply, x.reply);
  // Prerequisite path differs: novice with confusion gets stepped back or simplified more readily.
  const [n2] = await run(svc, "novice", ["I don't get generators at all"], T0 + 61 * 60_000);
  const [x2] = await run(svc, "expert", ["I don't get generators at all"], T0 + 61 * 60_000);
  assert.ok(n2.trace.decision.action !== x2.trace.decision.action || n2.trace.decision.depth !== x2.trace.decision.depth, `same confusion, different response: ${n2.trace.decision.action}/${n2.trace.decision.depth} vs ${x2.trace.decision.action}/${x2.trace.decision.depth}`);
  assert.ok(["SIMPLIFY", "PREREQUISITE", "EXAMPLE", "ANALOGY", "EXECUTE"].includes(n2.trace.decision.action));
});

test("Prediction loop: predict -> answer -> feedback becomes mastery evidence", async () => {
  const svc = new TutorService(new MemoryStore());
  const [a] = await run(svc, "P", ["explain variables"]);
  // Nudge into the learning zone with engagement, then expect a PREDICT at some point.
  const rs = await run(svc, "P", ["ok that makes sense, because a name just points at an object, so rebinding x should not change y I think", "right", "makes sense"], T0 + 60_000);
  const all = [a, ...rs];
  const predictTurn = all.find((r) => r.trace.decision.action === "PREDICT");
  assert.ok(predictTurn, `expected a PREDICT turn: ${all.map((r) => r.trace.decision.action).join(",")}`);
  assert.equal(predictTurn!.state.pendingPrediction, "variables");
  const [answer] = await run(svc, "P", ["6 5"], T0 + 10 * 60_000);
  assert.ok(answer.trace.predictionOutcome?.correct, JSON.stringify(answer.trace.predictionOutcome));
  assert.ok(answer.trace.delta.mastery.after > answer.trace.delta.mastery.before, "correct prediction raises mastery");
  assert.ok(/✅/.test(answer.reply));
  assert.equal(answer.state.pendingPrediction, undefined);
});

test("Tools: step-by-step request triggers visible execution; diagram request triggers graph visual; compare uses Graphify path", async () => {
  const svc = new TutorService(new MemoryStore());
  const rs = await run(svc, "T", ["explain binary search", "walk me through it step by step", "show me a diagram of how it connects", "compare stacks vs queues"]);
  assert.equal(rs[1].trace.decision.action, "EXECUTE");
  assert.equal(rs[1].trace.tool, "python_tracer");
  assert.ok(/Step-by-step:/.test(rs[1].reply) && /Output:/.test(rs[1].reply), rs[1].reply.slice(0, 300));
  assert.equal(rs[2].trace.decision.action, "VISUALIZE");
  assert.ok(/mermaid/.test(rs[2].reply));
  assert.equal(rs[3].trace.decision.action, "COMPARE");
  assert.ok(/Shortest path|vs/.test(rs[3].reply));
});

test("Edge cases: unknown concept, duplicate event, malformed state, empty history", async () => {
  const store = new MemoryStore();
  const svc = new TutorService(store);
  const [u] = await run(svc, "Z", ["tell me about quantum chromodynamics"]);
  assert.ok(/couldn't map/i.test(u.reply));
  const r1 = await svc.handleTurn("Z", "explain loops", { now: T0, eventId: "evt-1", allowLlm: false });
  const r2 = await svc.handleTurn("Z", "explain loops", { now: T0 + 1, eventId: "evt-1", allowLlm: false });
  assert.equal(r2.duplicate, true);
  assert.equal(r2.reply, r1.reply);
  assert.equal(r2.state.tendencies.turns, r1.state.tendencies.turns, "duplicate did not mutate state");
  // Malformed persisted learner model: merge over defaults.
  store.learners.set("M", { preferences: { depth: { concise: "bad" } } } as never);
  const [m] = await run(svc, "M", ["explain tuples"]);
  assert.ok(m.trace.decision.action);
  const snap = await svc.snapshot("nobody");
  assert.equal(snap.branches.active.length, 0);
  assert.equal(snap.depth, "standard");
});

test("Rapid topic switching and repeated identical messages stay stable", async () => {
  const svc = new TutorService(new MemoryStore());
  const rs = await run(svc, "R", ["explain lists", "explain classes", "explain big-o complexity", "explain file i/o", "explain lists", "explain lists", "explain lists"]);
  const last = rs.at(-1)!;
  assert.ok(last.trace.affect.confusion < 0.3);
  const acts = rs.slice(-3).map((r) => r.trace.decision.action);
  assert.ok(new Set(acts).size >= 2, `varies strategy on repeats: ${acts.join(",")}`);
  for (const r of rs) for (const v of Object.values(r.trace.affect)) assert.ok(v >= 0 && v <= 1);
});
