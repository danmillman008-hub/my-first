// Live validation against a running server: HTTP chat, persistence, and real MCP interop.
// Usage: npx tsx tests/live.ts [baseUrl]
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

const BASE = process.argv[2] ?? "http://127.0.0.1:3000";
const learnerId = `live-${Date.now().toString(36)}`;
const ok = (cond: unknown, msg: string) => {
  if (!cond) throw new Error(`FAIL: ${msg}`);
  console.log(`  ok  ${msg}`);
};

async function chat(message: string) {
  const res = await fetch(`${BASE}/api/chat`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ learnerId, message, eventId: crypto.randomUUID() }) });
  const j = await res.json();
  if (!res.ok) throw new Error(`chat ${res.status}: ${JSON.stringify(j)}`);
  console.log(`  > "${message}" -> ${j.trace.decision.action}/${j.trace.decision.depth}/${j.trace.tool} llm=${j.trace.llmUsed}${j.trace.llmError ? `(${j.trace.llmError})` : ""} via=${j.trace.resolvedVia}`);
  return j;
}

async function main() {
  console.log(`\n[1] HTTP chat + LLM path (${BASE}) learner=${learnerId}`);
  const r1 = await chat("explain recursion");
  ok(r1.trace.resolvedVia === "graphify-query", "concept resolved through Graphify CLI");
  ok(typeof r1.reply === "string" && r1.reply.length > 40, "reply produced (LLM or template fallback)");
  const r2 = await chat("can you make that simpler?");
  ok(r2.trace.decision.action === "SIMPLIFY", "simplification changes action");
  const r3 = await chat("walk me through it step by step");
  ok(r3.trace.tool === "python_tracer" && /Step-by-step/.test(r3.reply), "visible execution tool selected");
  const health = await fetch(`${BASE}/api/health`).then((r) => r.json());
  ok(health.ok === true, "health endpoint ok");

  console.log("\n[2] Persistence across requests (Postgres)");
  const st = await fetch(`${BASE}/api/chat?learnerId=${learnerId}`).then((r) => r.json());
  ok(st.state.focusConcept === "recursion", "focus persisted");
  ok(st.state.branches.active.some((b: { conceptId: string }) => b.conceptId === "recursion"), "branch activation persisted");
  ok(st.history.filter((h: { role: string }) => h.role === "tutor").length === 3, "evidence log persisted (3 tutor turns)");
  ok(st.state.preferences.depth.concise > 0.45, `learned preference persisted (concise=${st.state.preferences.depth.concise})`);

  console.log("\n[3] MCP interoperability (official client, Streamable HTTP)");
  const client = new Client({ name: "live-test", version: "0.0.1" });
  const transport = new StreamableHTTPClientTransport(new URL(`${BASE}/api/mcp`));
  await client.connect(transport);
  const tools = await client.listTools();
  const names = tools.tools.map((t) => t.name).sort();
  console.log("  tools:", names.join(", "));
  for (const n of ["get_graph_context", "get_concept", "get_related_concepts", "get_learning_state", "get_user_preferences", "get_active_branches", "get_dormant_branches", "get_current_policy", "record_interaction", "record_learning_signal", "reactivate_branch"]) ok(names.includes(n), `tool ${n} listed`);
  const prompts = await client.listPrompts();
  ok(prompts.prompts.length === 3, `3 prompts listed (${prompts.prompts.map((p) => p.name).join(", ")})`);
  const templates = await client.listResourceTemplates();
  ok(templates.resourceTemplates.length === 3, `3 resource templates (${templates.resourceTemplates.map((t) => t.uriTemplate).join(", ")})`);

  const state = await client.callTool({ name: "get_learning_state", arguments: { learnerId } });
  const stateJson = JSON.parse((state.content as { text: string }[])[0].text);
  ok(stateJson.focusConcept === "recursion", "MCP get_learning_state sees the same persisted state as HTTP");
  const policy = await client.callTool({ name: "get_current_policy", arguments: { learnerId } });
  const pol = JSON.parse((policy.content as { text: string }[])[0].text);
  ok(pol.action === "EXECUTE" && Array.isArray(pol.reasons), "MCP get_current_policy exposes last decision with reasons");
  const rec = await client.callTool({ name: "record_interaction", arguments: { learnerId, message: "tell me more detail about the call stack", eventId: crypto.randomUUID() } });
  const recJson = JSON.parse((rec.content as { text: string }[])[0].text);
  ok(recJson.decision.action === "DEEPEN", `MCP record_interaction runs the adaptive loop (action=${recJson.decision.action})`);
  const sig = await client.callTool({ name: "record_learning_signal", arguments: { learnerId, conceptId: "recursion", signal: "example_request" } });
  ok(!sig.isError, "MCP record_learning_signal accepted");
  const bad = await client.callTool({ name: "get_concept", arguments: { conceptId: "does_not_exist" } });
  ok(bad.isError === true, "unknown concept -> isError (fails safely)");
  const res = await client.readResource({ uri: `user://${learnerId}/preferences` });
  const prefs = JSON.parse((res.contents[0] as { text: string }).text);
  ok(typeof prefs.depth.concise === "number", "resource user://{id}/preferences readable");
  const gc = await client.callTool({ name: "get_graph_context", arguments: { question: "why does my list change when I copy it" } });
  const gcj = JSON.parse((gc.content as { text: string }[])[0].text);
  ok(gcj.concepts.some((c: { id: string }) => c.id === "lists"), "MCP get_graph_context resolves via Graphify");
  await client.close();

  console.log("\n[4] Duplicate event idempotency over HTTP");
  const evt = crypto.randomUUID();
  const body = JSON.stringify({ learnerId, message: "got it, thanks", eventId: evt });
  const a = await fetch(`${BASE}/api/chat`, { method: "POST", headers: { "content-type": "application/json" }, body }).then((r) => r.json());
  const b = await fetch(`${BASE}/api/chat`, { method: "POST", headers: { "content-type": "application/json" }, body }).then((r) => r.json());
  ok(b.duplicate === true && a.state.tendencies.turns === b.state.tendencies.turns, "duplicate event did not double-count");

  console.log("\nALL LIVE CHECKS PASSED\n");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
