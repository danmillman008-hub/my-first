#!/usr/bin/env python3
"""Visible-execution tracer (Python-Tutor style, minimal).

Reads a program from stdin, executes it with sys.settrace, and prints JSON:
  {"ok": bool, "stdout": str, "events": [{"line": int, "event": str, "func": str, "locals": {...}}], "error": str|null}
Only corpus-authored snippets are ever executed (never learner-supplied code).
"""
import io
import json
import signal
import sys

MAX_EVENTS = 80
MAX_REPR = 60


def main() -> None:
    code = sys.stdin.read()
    events = []
    out = io.StringIO()

    def snap(frame):
        d = {}
        for k, v in list(frame.f_locals.items())[:8]:
            if k.startswith("__"):
                continue
            try:
                r = repr(v)
            except Exception:
                r = "<unrepr>"
            d[k] = r if len(r) <= MAX_REPR else r[:MAX_REPR] + "…"
        return d

    def tracer(frame, event, arg):
        if frame.f_code.co_filename != "<lesson>":
            return None
        if len(events) < MAX_EVENTS and event in ("line", "call", "return"):
            e = {"line": frame.f_lineno, "event": event, "func": frame.f_code.co_name, "locals": snap(frame)}
            if event == "return":
                try:
                    e["value"] = repr(arg)[:MAX_REPR]
                except Exception:
                    e["value"] = "<unrepr>"
            events.append(e)
        return tracer

    def on_alarm(signum, frame):
        raise TimeoutError("execution exceeded time limit")

    signal.signal(signal.SIGALRM, on_alarm)
    signal.alarm(3)
    err = None
    real_stdout = sys.stdout
    sys.stdout = out
    try:
        compiled = compile(code, "<lesson>", "exec")
        sys.settrace(tracer)
        exec(compiled, {"__name__": "__lesson__"})
    except BaseException as exc:  # noqa: BLE001 - report anything to the learner
        err = f"{type(exc).__name__}: {exc}"
    finally:
        sys.settrace(None)
        signal.alarm(0)
        sys.stdout = real_stdout
    print(json.dumps({"ok": err is None, "stdout": out.getvalue(), "events": events, "error": err, "truncated": len(events) >= MAX_EVENTS}))


if __name__ == "__main__":
    main()
