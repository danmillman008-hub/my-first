#!/usr/bin/env python3
"""Build the canonical concept graph with Graphify's own pipeline.

knowledge/concepts.json  ->  knowledge/corpus/*.md (source docs)
                         ->  Graphify extraction dict (validated by graphify.validate)
                         ->  graphify.build.build_from_json
                         ->  graphify.cluster.cluster
                         ->  graphify.export.to_json  => graphify-out/graph.json

The concept corpus is a custom *extractor input* (Graphify's documented extension
point). Graphify remains the graph engine; nothing here re-implements it.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONCEPTS = ROOT / "knowledge" / "concepts.json"
CORPUS = ROOT / "knowledge" / "corpus"
OUT_DIR = ROOT / "graphify-out"


def main() -> int:
    try:
        from graphify.validate import assert_valid
        from graphify.build import build_from_json
        from graphify.cluster import cluster
        from graphify.export import to_json
    except ImportError as exc:  # pragma: no cover
        print(f"graphify not importable: {exc}. pip install 'graphifyy[mcp]'", file=sys.stderr)
        return 2

    data = json.loads(CONCEPTS.read_text(encoding="utf-8"))
    CORPUS.mkdir(parents=True, exist_ok=True)
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    nodes, edges = [], []
    for c in data["concepts"]:
        rel = f"knowledge/corpus/{c['id']}.md"
        doc = (
            f"# {c['label']}\n\n{c['summary']}\n\n## In plain words\n{c['simple']}\n\n"
            f"## Deeper\n{c['deep']}\n\n## Example\n```python\n{c['example']}\n```\n\n"
            f"## Analogy\n{c['analogy']}\n\n## Common misconceptions\n"
            + "\n".join(f"- {m}" for m in c["misconceptions"])
            + "\n"
        )
        (ROOT / rel).write_text(doc, encoding="utf-8")
        nodes.append({
            "id": c["id"],
            "label": c["label"],
            "file_type": "concept",
            "source_file": rel,
            "source_location": "L1",
        })
        for p in c["prerequisites"]:
            edges.append({
                "source": p, "target": c["id"], "relation": "prerequisite_of",
                "confidence": "EXTRACTED", "source_file": rel,
            })
        for r in c["related"]:
            edges.append({
                "source": c["id"], "target": r, "relation": "related_to",
                "confidence": "INFERRED", "source_file": rel,
            })

    extraction = {"nodes": nodes, "edges": edges}
    assert_valid(extraction)  # Graphify schema gate
    (OUT_DIR / "extraction.json").write_text(json.dumps(extraction, indent=1), encoding="utf-8")

    G = build_from_json(extraction, directed=True, root=ROOT)
    communities = cluster(G)
    for cid, members in communities.items():
        for n in members:
            G.nodes[n]["community"] = cid
    out = OUT_DIR / "graph.json"
    to_json(G, communities, str(out), force=True)
    print(f"graph.json: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges, "
          f"{len(communities)} communities -> {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
