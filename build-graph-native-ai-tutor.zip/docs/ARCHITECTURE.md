# Graph-native adaptive tutor — architecture & ownership

## Layers

```
Experience      src/app/page.tsx (minimal chat)   ·   src/app/api/mcp (MCP clients)
                          │
Application     src/tutor/session.ts  TutorService.handleTurn  (only writer of state)
                src/tutor/realize.ts  language realisation (template ⟂ Gemini)
                src/tutor/tools.ts    python tracer · graph diagram · corpus content
                          │
Adaptivity      src/adaptive/index.ts     adaptiveStep(): pure state transition
core            src/adaptive/signals.ts   interaction → weighted evidence
                src/adaptive/learner.ts   preferences · affect · tendencies · session
                src/adaptive/knowledge.ts mastery · strength · decay · dormancy · reactivation
                src/adaptive/policy.ts    next-best-action (additive, explainable scores)
                          │
Knowledge /     src/tutor/store.ts  Postgres (learner_models, concept_states, interactions)
memory          keyed by Graphify node ids — an overlay, never a second graph
                          │
Graphify        graphify-out/graph.json   built by scripts/graphify_build.py through
core            graphify.validate → build_from_json → cluster → export.to_json
                src/graph/graphify.ts     read-only loader + CLI bridge (query/path/explain)
```

## State ownership

| State | Lives in | Mutated by |
|---|---|---|
| Graph topology, concept identity, prerequisites, communities | `graphify-out/graph.json` (Graphify) | `scripts/graphify_build.py` only |
| Traversal, ranking, paths, explain | Graphify CLI (`graphify query/path/explain`) | — (read) |
| Knowledge/mastery/activation per concept | `concept_states` (overlay keyed by node id) | adaptive core via `TutorService` |
| Preferences, affect, tendencies | `learner_models` | adaptive core via `TutorService` |
| Short-term session (focus, pending prediction, recent actions) | `learner_models.session` | adaptive core via `TutorService` |
| Interaction evidence | `interactions` (append-only, idempotent on eventId) | `TutorService` |
| Policy / teaching strategy | computed each turn (`policy.ts`), logged in `interactions.decision` | policy only |
| Conversation text | `interactions` | `TutorService` |
| MCP exposure | `src/mcp/server.ts` | thin adapter → `TutorService` |

The LLM receives a finished `Decision` and a draft; its output is text only and never feeds back into state.
MCP tools call the same `TutorService` methods as the UI; there is no path from MCP to the database.

## Reuse map

| Capability | Source | Status |
|---|---|---|
| Graph model / persistence / query / path / explain / clustering | Graphify (`graphifyy` 0.9.53) | **directly reused** (real pipeline + CLI) |
| Extraction schema (`file_type: concept`) | Graphify `validate.py` | reused as the corpus extension point |
| Half-life decay form | Graphify `reflect._decay` | reused conceptually (`0.5 ** (age/half_life)`) |
| Sidecar-overlay pattern (`.graphify_learning.json`) | Graphify | reused as the *pattern* for `concept_states` |
| Graphify MCP server (`graphify.serve`) | Graphify | available unchanged for raw graph access; tutor MCP composes the app layer instead |
| Socratic / Bloom / scaffold-down-on-confusion / off-topic parking / "quote the material" / background-driven depth | auto-tutor `learning-engine` SKILL.md | adapted as policy actions (`ASK_GUIDING_QUESTION`, `PREREQUISITE`, `SIMPLIFY`, topic-switch signal, LLM source-doc constraint) |
| Lesson primitives (summary/simple/deep/example/analogy/misconceptions) | auto-tutor lesson template | adapted into `knowledge/concepts.json` |
| Visible execution + prediction-before-execution | Python Tutor / UUhistle ideas | minimal new tool (`scripts/trace_runner.py`) |
| Adaptive core, policy, learner model, MCP tutor surface, chat UI | — | new (minimal) |

auto-tutor has no runtime code (it is a set of Claude Code skills + markdown conventions), so reuse is of its
teaching flow and content model, not of modules.

## Commands

```
python3 scripts/graphify_build.py                      # rebuild graph.json via Graphify
npx drizzle-kit push                                   # apply schema
npx tsx --env-file=.env --test tests/*.test.ts         # unit + scenarios + synthetic experiment
npx tsx tests/live.ts http://127.0.0.1:3000            # live HTTP + MCP interop against a running server
```
