// Signal extraction: turn one learner message (+ context) into weighted evidence.
// Deterministic lexical heuristics. A signal is evidence, not a verdict; the
// learner model accumulates it over time.
import type { Signal, SignalType, SessionContext } from "./types";

interface Rule {
  type: SignalType;
  weight: number;
  patterns: RegExp[];
}

const RULES: Rule[] = [
  {
    type: "simplification_request",
    weight: 0.9,
    patterns: [/\bsimpl(er|ify|e)\b/i, /\beasier\b/i, /too (hard|complex|complicated|advanced|technical)/i, /\beli5\b/i, /plain (english|words|language)/i, /dumb(ed)? (it )?down/i, /\bbasics?\b/i, /less (detail|jargon)/i],
  },
  {
    type: "clarification_request",
    weight: 0.8,
    patterns: [/what do you mean/i, /\bclarify\b/i, /i (don'?t|do not|still don'?t) (get|understand|follow)/i, /\bnot sure i follow\b/i, /explain (that|it) again/i, /\bhuh\b/i, /\bconfus(ed|ing)\b/i, /\blost\b/i, /\bwhy is that\b/i, /\bwhat\?$/i],
  },
  {
    type: "depth_request",
    weight: 0.9,
    patterns: [/more detail/i, /\bdeeper\b/i, /in[- ]depth/i, /under the hood/i, /\binternals?\b/i, /\belaborate\b/i, /\badvanced\b/i, /\bformally\b/i, /\brigorous\b/i, /\bwhy does (it|this|that) (actually|really)\b/i, /how does .* (work|happen) (internally|exactly)/i, /tell me more/i, /go (further|deeper)/i, /\bmore about\b/i],
  },
  {
    type: "example_request",
    weight: 0.85,
    patterns: [/\bexamples?\b/i, /\bshow me\b/i, /for instance/i, /\bsample\b/i, /\bdemo(nstrate)?\b/i, /concrete/i, /\bcode\b/i],
  },
  {
    type: "analogy_request",
    weight: 0.85,
    patterns: [/\banalog(y|ies)\b/i, /\bmetaphor\b/i, /\bintuition\b/i, /\bintuitive(ly)?\b/i, /like what\b/i, /compare (it|this) to something/i, /real[- ]world/i],
  },
  {
    type: "visual_request",
    weight: 0.85,
    patterns: [/\bvisuali[sz]e\b/i, /\bvisual(ly)?\b/i, /\bdiagram\b/i, /\bdraw\b/i, /\bpicture\b/i, /\bmap\b/i, /\bgraph\b/i, /how (does|is) (it|this) (connect|related)/i, /\bsee (it|the connections)\b/i],
  },
  {
    type: "step_request",
    weight: 0.85,
    patterns: [/step[- ]by[- ]step/i, /walk me through/i, /\btrace\b/i, /\bline by line\b/i, /what happens when (it|this|the code) runs/i, /\brun (it|this|the code)\b/i, /\bexecute\b/i],
  },
  {
    type: "correction",
    weight: 0.8,
    patterns: [/that'?s (wrong|incorrect|not right)/i, /\bincorrect\b/i, /\bactually,/i, /you said/i, /\bmistake\b/i, /not true/i, /\bno,/i],
  },
  {
    type: "curiosity_signal",
    weight: 0.6,
    patterns: [/what about\b/i, /what if\b/i, /\bis (it|this|that) related\b/i, /how about\b/i, /\binteresting\b/i, /\bcool\b/i, /\bcurious\b/i, /what else\b/i, /\bwhat'?s next\b/i, /\bnext\b/i, /\bmove on\b/i, /\bwhere does this lead\b/i, /\bconnects? to\b/i],
  },
  {
    type: "frustration_signal",
    weight: 0.8,
    patterns: [/\bugh\b/i, /frustrat/i, /annoy/i, /still (don'?t|do not) (get|understand)/i, /this is (hard|impossible|pointless)/i, /give up/i, /!{2,}/, /\bwhatever\b/i, /\bnot helping\b/i],
  },
  {
    type: "fatigue_signal",
    weight: 0.7,
    patterns: [/\btired\b/i, /\benough\b/i, /\blater\b/i, /\bbreak\b/i, /\bstop\b/i, /\bwrap up\b/i, /\bsummari[sz]e\b/i, /\brecap\b/i, /\bquick(ly)?\b/i, /\bbrief(ly)?\b/i, /\btl;?dr\b/i],
  },
  {
    type: "successful_continuation",
    weight: 0.7,
    patterns: [/\bgot it\b/i, /makes sense/i, /\bi see\b/i, /\bunderstood\b/i, /\bthanks?\b/i, /\bclear\b/i, /\bok(ay)?[,.! ]/i, /\bright\b/i, /\bnice\b/i, /\bperfect\b/i],
  },
  {
    type: "compare_request",
    weight: 0.9,
    patterns: [/\bcompare\b/i, /\bdifference between\b/i, /\bvs\.?\b/i, /\bversus\b/i, /\bor\b.*\?\s*$/i, /how (is|are) .* different/i],
  },
];

export interface SignalContext {
  session: SessionContext;
  now: number;
  mentioned: string[]; // resolved concept ids
  relatedToFocus: string[]; // ids related to / prerequisites of the focus concept
}

export function extractSignals(message: string, ctx: SignalContext): Signal[] {
  const text = message.trim();
  const signals: Signal[] = [];
  const seen = new Set<SignalType>();
  const push = (s: Signal) => {
    if (seen.has(s.type)) return;
    seen.add(s.type);
    signals.push(s);
  };

  for (const rule of RULES) {
    const hit = rule.patterns.find((p) => p.test(text));
    if (hit) push({ type: rule.type, weight: rule.weight, evidence: hit.toString() });
  }

  // Derived affect-ish signals from lexical ones.
  if (seen.has("clarification_request") || seen.has("simplification_request")) {
    push({ type: "confusion_signal", weight: seen.has("clarification_request") ? 0.7 : 0.5, evidence: "clarification/simplification" });
  }
  if (seen.has("frustration_signal") && !seen.has("confusion_signal")) {
    push({ type: "confusion_signal", weight: 0.4, evidence: "frustration implies difficulty" });
  }

  // Engagement: substantive messages (length, code, reasoning connectives).
  const words = text.split(/\s+/).filter(Boolean).length;
  if (words >= 18 || /\bbecause\b|\bso if\b|\bthen\b.*\bwould\b|```|\bdef\b|\bprint\(/.test(text)) {
    push({ type: "engagement_signal", weight: Math.min(1, 0.4 + words / 60), evidence: `words=${words}` });
  }
  // Fatigue: terse messages late in a long session.
  if (words <= 3 && ctx.session.turnsOnFocus >= 4 && !seen.has("successful_continuation")) {
    push({ type: "fatigue_signal", weight: 0.35, evidence: "terse after long focus" });
  }

  // Follow-up: continuing on the same focus concept.
  const focus = ctx.session.focusConcept;
  if (focus && (ctx.mentioned.length === 0 || ctx.mentioned.includes(focus))) {
    push({ type: "follow_up_request", weight: 0.6, evidence: "same focus" });
  }
  // Topic switch: message resolves to a concept unrelated to the focus.
  if (focus && ctx.mentioned.length && !ctx.mentioned.includes(focus)) {
    const related = ctx.mentioned.some((m) => ctx.relatedToFocus.includes(m));
    push({ type: "topic_switch", weight: related ? 0.3 : 0.8, evidence: related ? "adjacent concept" : "unrelated concept" });
    if (related) push({ type: "curiosity_signal", weight: 0.4, evidence: "moved to adjacent concept" });
  }

  // Abandonment: long gap since last turn.
  if (ctx.session.lastTurnAt) {
    const gapH = (ctx.now - ctx.session.lastTurnAt) / 3_600_000;
    if (gapH > 20) push({ type: "abandonment", weight: Math.min(1, gapH / 168), evidence: `gap=${gapH.toFixed(1)}h` });
  }

  if (signals.length === 0 || (signals.length === 1 && seen.has("follow_up_request"))) {
    push({ type: "direct_question", weight: 0.5 });
  }
  return signals;
}

/** Compare a learner's prediction with the actual program output. */
export function judgePrediction(prediction: string, expected: string): { correct: boolean; score: number } {
  const norm = (s: string) => s.toLowerCase().replace(/\s+/g, " ").replace(/[`'"[\](){},]/g, "").trim();
  const p = norm(prediction);
  const e = norm(expected);
  if (!p) return { correct: false, score: 0 };
  if (p === e || p.includes(e) || e.includes(p)) return { correct: true, score: 1 };
  const eTokens = e.split(" ").filter(Boolean);
  const pTokens = new Set(p.split(" ").filter(Boolean));
  const overlap = eTokens.filter((t) => pTokens.has(t)).length / Math.max(1, eTokens.length);
  return { correct: overlap >= 0.7, score: overlap };
}
