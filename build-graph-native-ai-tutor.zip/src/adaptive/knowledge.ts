// Knowledge state: per-learner, per-concept overlay keyed by Graphify node ids.
// Mastery is an evolving belief; strength/activation is branch dynamics.
//
//   activation(t) = strength * 0.5 ^ ((t - lastActiveAt) / HALF_LIFE)   (same form as graphify.reflect._decay)
//   status: active >= 0.40 > weak >= 0.15 > dormant     (untouched if never interacted)
//   dormant branches keep mastery/strength/history; they are never deleted.
import type { BranchStatus, ConceptState, Signal } from "./types";

export const HALF_LIFE_DAYS = 7;
export const ACTIVE_THRESHOLD = 0.4;
export const DORMANT_THRESHOLD = 0.15;
export const REACTIVATION_FLOOR = 0.45;
const DAY_MS = 86_400_000;

const clamp = (v: number, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, v));

export function newConceptState(conceptId: string, now: number): ConceptState {
  return { conceptId, mastery: 0.2, confidence: 0, strength: 0, lastActiveAt: now, interactionCount: 0 };
}

export function activation(s: ConceptState, now: number, halfLifeDays = HALF_LIFE_DAYS): number {
  const ageDays = Math.max(0, (now - s.lastActiveAt) / DAY_MS);
  return clamp(s.strength * Math.pow(0.5, ageDays / halfLifeDays));
}

export function status(s: ConceptState, now: number): BranchStatus {
  if (s.interactionCount === 0) return "untouched";
  const a = activation(s, now);
  if (a >= ACTIVE_THRESHOLD) return "active";
  if (a >= DORMANT_THRESHOLD) return "weak";
  return "dormant";
}

/**
 * Reinforce a branch after an interaction touches it. Growth is computed from
 * the *decayed* activation so a long-dormant branch climbs back gradually, and
 * saturates at 1. If the branch was dormant, apply the reactivation floor so
 * it is immediately usable again (history is preserved in mastery/count).
 */
export function reinforce(s: ConceptState, now: number, weight = 1): { state: ConceptState; reactivated: boolean } {
  const wasDormant = status(s, now) === "dormant";
  const a = activation(s, now);
  let strength = clamp(a + (1 - a) * 0.45 * clamp(weight));
  if (wasDormant) strength = Math.max(strength, REACTIVATION_FLOOR);
  return {
    state: { ...s, strength: round(strength), lastActiveAt: now, interactionCount: s.interactionCount + 1 },
    reactivated: wasDormant,
  };
}

/** Mastery outcome derived from this turn's signals for the focus concept. Range [-1, 1] with a weight. */
export function masteryEvidence(signals: Signal[], actionDelivered: boolean): { outcome: number; weight: number } {
  const w = (t: Signal["type"]) => signals.find((x) => x.type === t)?.weight ?? 0;
  let outcome = 0;
  let weight = 0;
  const add = (o: number, ww: number) => {
    if (ww <= 0) return;
    outcome += o * ww;
    weight += ww;
  };
  add(1, w("prediction_correct"));
  add(-1, w("prediction_incorrect"));
  add(0.5, w("successful_continuation") * 0.6);
  add(-0.6, w("clarification_request") * 0.7);
  add(-0.4, w("simplification_request") * 0.6);
  add(0.3, w("depth_request") * 0.5); // wanting to go deeper is weak evidence of readiness
  add(0.25, w("engagement_signal") * 0.3);
  if (actionDelivered) add(0.15, 0.2); // exposure: tiny positive
  if (weight === 0) return { outcome: 0, weight: 0 };
  return { outcome: clamp(outcome / weight, -1, 1), weight: clamp(weight) };
}

/** Update mastery belief: move toward 1 or 0 by lr scaled with evidence; confidence grows with evidence. */
export function updateMastery(s: ConceptState, outcome: number, weight: number): ConceptState {
  if (weight <= 0) return s;
  const target = outcome > 0 ? 1 : 0;
  const magnitude = Math.abs(outcome);
  // Strongly-held beliefs (high confidence) move more slowly; noise cannot dominate.
  const lr = 0.25 * weight * magnitude * (1 - 0.5 * s.confidence);
  const mastery = clamp(s.mastery + lr * (target - s.mastery));
  const confidence = clamp(s.confidence + (1 - s.confidence) * 0.12 * weight);
  return { ...s, mastery: round(mastery), confidence: round(confidence) };
}

export function describe(s: ConceptState, now: number) {
  return {
    conceptId: s.conceptId,
    mastery: s.mastery,
    confidence: s.confidence,
    strength: s.strength,
    activation: round(activation(s, now)),
    status: status(s, now),
    interactionCount: s.interactionCount,
    lastActiveAt: new Date(s.lastActiveAt).toISOString(),
  };
}

function round(v: number) {
  return Math.round(v * 1000) / 1000;
}
