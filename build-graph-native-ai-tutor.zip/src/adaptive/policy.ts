// Next-best-action policy. Consumes PolicyInput, produces a Decision.
// Each action accumulates additive, named evidence contributions so every
// decision is explainable ("reasons"). No LLM involvement.
import { ACTIONS, DEPTHS } from "./types";
import type { Action, Decision, Depth, PolicyInput, Style, Tool } from "./types";
import { preferredDepth, preferredStyle } from "./learner";

const NEG_INF = -Infinity;

export function decide(input: PolicyInput): Decision {
  const { focus, prerequisites, related, learner, signals, tools } = input;
  const { affect, preferences: prefs, session } = learner;
  const w = (t: (typeof signals)[number]["type"]) => signals.find((s) => s.type === t)?.weight ?? 0;

  const scores = Object.fromEntries(ACTIONS.map((a) => [a, 0])) as Record<Action, number>;
  const reasons: string[] = [];
  const add = (a: Action, v: number, why: string) => {
    if (v === 0 || Number.isNaN(v)) return;
    scores[a] += v;
    reasons.push(`${a} ${v > 0 ? "+" : ""}${v.toFixed(2)} ${why}`);
  };
  const veto = (a: Action, why: string) => {
    scores[a] = NEG_INF;
    reasons.push(`${a} vetoed: ${why}`);
  };

  const mastery = focus.state.mastery;
  const last = session.recentActions.at(-1);
  const lastOnFocus = last?.conceptId === focus.id ? last.action : undefined;
  const recent = session.recentActions.slice(-3).map((r) => r.action);
  const count = (a: Action) => recent.filter((x) => x === a).length;
  const weakestPrereq = [...prerequisites].sort((a, b) => a.state.mastery - b.state.mastery)[0];
  const dormantKnown = [...related, ...prerequisites].filter((r) => r.status === "dormant" && r.state.mastery >= 0.5);
  const focusDormantKnown = (focus.wasDormant || focus.status === "dormant") && (mastery >= 0.4 || focus.state.interactionCount >= 3);
  const exploreTarget = pickExploreTarget(related);
  // First contact: the concept has never been taught in this session (adaptiveStep already counted this touch).
  const firstContact = focus.state.interactionCount <= 1 && !session.recentActions.some((r) => r.conceptId === focus.id);
  const explicitCuriosity = w("curiosity_signal");

  // --- baseline -----------------------------------------------------------
  add("DIRECT_EXPLANATION", 0.5, "baseline");
  if (lastOnFocus === "DIRECT_EXPLANATION") add("DIRECT_EXPLANATION", -0.35, "just explained; vary strategy");
  add("DIRECT_EXPLANATION", 0.3 * w("direct_question"), "direct question");
  if (focus.state.interactionCount === 0) add("DIRECT_EXPLANATION", 0.25, "first contact with concept");

  // --- SIMPLIFY -----------------------------------------------------------
  if (firstContact && w("simplification_request") === 0) veto("SIMPLIFY", "nothing to simplify yet; depth preference flows through explanation");
  add("SIMPLIFY", 1.0 * w("simplification_request"), "asked to simplify");
  add("SIMPLIFY", 0.6 * w("clarification_request"), "asked to clarify");
  add("SIMPLIFY", 0.8 * affect.confusion, "confusion");
  add("SIMPLIFY", 0.4 * affect.frustration, "frustration");
  add("SIMPLIFY", 0.35 * prefs.depth.concise, "prefers concise");
  if (mastery > 0.7) add("SIMPLIFY", -0.4, "already high mastery");

  // --- DEEPEN -------------------------------------------------------------
  add("DEEPEN", 1.0 * w("depth_request"), "asked for depth");
  add("DEEPEN", 0.7 * affect.curiosity * mastery, "curious and capable");
  add("DEEPEN", 0.5 * prefs.depth.deep + 0.3 * prefs.depth.detailed, "prefers depth");
  add("DEEPEN", -0.9 * affect.confusion, "confused");
  add("DEEPEN", -0.4 * affect.fatigue, "fatigued");
  if (mastery < 0.3 && w("depth_request") === 0) add("DEEPEN", -0.5, "low mastery, no request");
  if (lastOnFocus === "DEEPEN") add("DEEPEN", -0.3, "just deepened");

  // --- EXAMPLE / ANALOGY --------------------------------------------------
  add("EXAMPLE", 1.0 * w("example_request"), "asked for example");
  add("EXAMPLE", 0.6 * prefs.style.example, "prefers examples");
  add("EXAMPLE", 0.3 * affect.confusion, "concrete helps confusion");
  if (lastOnFocus === "DIRECT_EXPLANATION" || lastOnFocus === "SIMPLIFY") add("EXAMPLE", 0.25, "natural follow-up");
  if (count("EXAMPLE") >= 1) add("EXAMPLE", -0.35, "recent example");

  add("ANALOGY", 1.0 * w("analogy_request"), "asked for analogy");
  add("ANALOGY", 0.6 * prefs.style.analogy, "prefers analogies");
  add("ANALOGY", 0.4 * affect.confusion * (1 - mastery), "intuition for a confused novice");
  if (count("ANALOGY") >= 1) add("ANALOGY", -0.4, "recent analogy");

  // --- VISUALIZE (graph diagram of the neighbourhood) ---------------------
  add("VISUALIZE", 1.0 * w("visual_request"), "asked for visual");
  add("VISUALIZE", 0.55 * prefs.style.visual, "prefers visual");
  add("VISUALIZE", 0.15 * Math.min(related.length + prerequisites.length, 4) / 4, "rich neighbourhood");
  if (count("VISUALIZE") >= 1) add("VISUALIZE", -0.5, "recent visual");

  // --- EXECUTE (visible execution trace) ----------------------------------
  if (!focus.hasCode || !tools.python) veto("EXECUTE", "no runnable code / python");
  else if (firstContact && w("step_request") === 0) veto("EXECUTE", "teach before tracing on first contact");
  else {
    add("EXECUTE", 0.9 * w("step_request"), "asked for step-by-step");
    add("EXECUTE", 0.5 * prefs.style.step_by_step, "prefers step-by-step");
    add("EXECUTE", 0.35 * affect.confusion, "seeing execution helps confusion");
    add("EXECUTE", 0.6 * w("prediction_incorrect"), "show what actually happened");
    if (count("EXECUTE") >= 1) add("EXECUTE", -0.5, "recent execution");
  }

  // --- PREDICT (prediction before execution) ------------------------------
  if (!focus.hasCode || !tools.python) veto("PREDICT", "no runnable code / python");
  else if (session.pendingPrediction) veto("PREDICT", "prediction already pending");
  else if (firstContact) veto("PREDICT", "teach before testing on first contact");
  else {
    add("PREDICT", 0.5 * affect.engagement, "engaged");
    add("PREDICT", 0.4 * bump(mastery, 0.3, 0.8), "mastery in learning zone");
    add("PREDICT", 0.25 * affect.curiosity, "curious");
    if (lastOnFocus === "DIRECT_EXPLANATION" || lastOnFocus === "EXAMPLE" || lastOnFocus === "DEEPEN") add("PREDICT", 0.35, "test after explanation");
    add("PREDICT", -1.0 * affect.confusion, "confused");
    add("PREDICT", -0.7 * affect.fatigue, "fatigued");
    add("PREDICT", -0.5 * w("simplification_request"), "wants simpler, not a test");
    if (count("PREDICT") >= 1) add("PREDICT", -0.6, "recent prediction");
    if (w("depth_request") + w("example_request") + w("analogy_request") + w("visual_request") > 0) add("PREDICT", -0.5, "explicit content request");
  }

  // --- PREREQUISITE -------------------------------------------------------
  if (!weakestPrereq) veto("PREREQUISITE", "no prerequisites");
  else {
    const pm = weakestPrereq.state.mastery;
    const gap = Math.max(0, 0.45 - pm);
    add("PREREQUISITE", 1.6 * gap * (affect.confusion + w("clarification_request")), "weak prerequisite while confused");
    if (pm < 0.35 && mastery < 0.35 && affect.confusion > 0.35) add("PREREQUISITE", 0.5, "both focus and prerequisite weak");
    if (weakestPrereq.status === "untouched" && affect.confusion > 0.5) add("PREREQUISITE", 0.3, "never seen prerequisite");
    if (count("PREREQUISITE") >= 1) add("PREREQUISITE", -0.5, "recent prerequisite");
    if (w("depth_request") > 0) add("PREREQUISITE", -0.4, "wants depth, not review");
  }

  // --- EXPLORE_RELATED ----------------------------------------------------
  if (!exploreTarget) veto("EXPLORE_RELATED", "no related concepts");
  else {
    add("EXPLORE_RELATED", 0.9 * affect.curiosity * mastery, "curious with mastery");
    add("EXPLORE_RELATED", 0.5 * w("successful_continuation") * mastery, "ready to move on");
    add("EXPLORE_RELATED", 1.0 * explicitCuriosity, "explicit curiosity");
    add("EXPLORE_RELATED", 0.2 * prefs.depth.deep, "prefers depth");
    add("EXPLORE_RELATED", -0.8 * affect.confusion, "confused");
    add("EXPLORE_RELATED", -0.4 * affect.fatigue, "fatigued");
    if (session.turnsOnFocus >= 4 && mastery >= 0.5) add("EXPLORE_RELATED", 0.3, "long dwell with mastery");
    if (mastery < 0.35 && explicitCuriosity === 0) add("EXPLORE_RELATED", -0.4, "focus not yet mastered");
    if (firstContact) add("EXPLORE_RELATED", -0.6, "just arrived at this concept");
  }

  // --- REACTIVATE_BRANCH --------------------------------------------------
  if (focusDormantKnown) add("REACTIVATE_BRANCH", 1.2 + 0.5 * w("abandonment"), "focus concept is dormant but previously learned");
  else if (dormantKnown.length && (affect.curiosity > 0.4 || w("curiosity_signal") > 0)) add("REACTIVATE_BRANCH", 0.6, "dormant known neighbour is relevant");
  else veto("REACTIVATE_BRANCH", "nothing dormant to reactivate");

  // --- RECAP --------------------------------------------------------------
  add("RECAP", 0.9 * w("abandonment") * (focus.state.interactionCount > 0 ? 1 : 0), "returning after a gap");
  add("RECAP", 0.6 * affect.fatigue * (session.turnsOnFocus >= 3 ? 1 : 0.3), "fatigue after dwell");
  add("RECAP", 0.7 * w("fatigue_signal"), "asked to wrap up");
  if (session.turnsOnFocus >= 5 && w("successful_continuation") > 0) add("RECAP", 0.4, "consolidate long focus");
  if (count("RECAP") >= 1) add("RECAP", -0.6, "recent recap");

  // --- COMPARE ------------------------------------------------------------
  const twoConcepts = input.mentioned.length >= 2;
  if (!twoConcepts && related.length === 0) veto("COMPARE", "nothing to compare");
  else {
    add("COMPARE", 1.0 * w("compare_request") * (twoConcepts ? 1 : 0.5), "asked to compare");
    if (twoConcepts) add("COMPARE", 0.5, "two concepts mentioned");
    add("COMPARE", 0.2 * affect.curiosity * mastery, "curious");
  }

  // --- ASK_GUIDING_QUESTION (Socratic) ------------------------------------
  if (firstContact) veto("ASK_GUIDING_QUESTION", "teach before probing on first contact");
  add("ASK_GUIDING_QUESTION", 0.7 * w("correction"), "learner asserted something: probe it");
  add("ASK_GUIDING_QUESTION", 0.35 * bump(mastery, 0.4, 0.75) * affect.engagement, "engaged mid-mastery");
  add("ASK_GUIDING_QUESTION", -0.8 * affect.confusion, "confused");
  add("ASK_GUIDING_QUESTION", -0.5 * affect.fatigue, "fatigued");
  if (count("ASK_GUIDING_QUESTION") >= 1) add("ASK_GUIDING_QUESTION", -0.5, "recent question");
  if (w("example_request") + w("simplification_request") + w("depth_request") > 0) add("ASK_GUIDING_QUESTION", -0.4, "explicit content request");

  // --- choose -------------------------------------------------------------
  const ranked = ACTIONS.filter((a) => scores[a] !== NEG_INF).sort((a, b) => scores[b] - scores[a] || ACTIONS.indexOf(a) - ACTIONS.indexOf(b));
  const action = ranked[0] ?? "DIRECT_EXPLANATION";

  let auxConcept: string | undefined;
  if (action === "PREREQUISITE") auxConcept = weakestPrereq?.id;
  if (action === "EXPLORE_RELATED") auxConcept = exploreTarget?.id;
  if (action === "REACTIVATE_BRANCH") auxConcept = focusDormantKnown ? undefined : dormantKnown[0]?.id;
  if (action === "COMPARE") auxConcept = input.mentioned.find((m) => m !== focus.id) ?? related[0]?.id;

  const depth = chooseDepth(action, prefs, affect, input);
  const style = chooseStyle(action, prefs);
  const tool = chooseTool(action);

  const finite = Object.fromEntries(Object.entries(scores).filter(([, v]) => v !== NEG_INF).map(([k, v]) => [k, Math.round(v * 100) / 100])) as Partial<Record<Action, number>>;
  return { action, targetConcept: focus.id, auxConcept, depth, style, tool, scores: finite, reasons };
}

function pickExploreTarget(related: PolicyInput["related"]) {
  if (!related.length) return undefined;
  // Prefer concepts not yet mastered, not dormant-known (those go to REACTIVATE), most recently active.
  return [...related].sort((a, b) => {
    const am = a.state.mastery < 0.6 ? 0 : 1;
    const bm = b.state.mastery < 0.6 ? 0 : 1;
    if (am !== bm) return am - bm;
    return b.activation - a.activation;
  })[0];
}

function chooseDepth(action: Action, prefs: PolicyInput["learner"]["preferences"], affect: PolicyInput["learner"]["affect"], input: PolicyInput): Depth {
  let d = preferredDepth(prefs);
  const shift = (by: number) => {
    const i = Math.max(0, Math.min(DEPTHS.length - 1, DEPTHS.indexOf(d) + by));
    d = DEPTHS[i];
  };
  if (action === "SIMPLIFY") d = "concise";
  else if (action === "DEEPEN") d = prefs.depth.deep >= prefs.depth.detailed || input.learner.session.recentActions.at(-1)?.action === "DEEPEN" ? "deep" : "detailed";
  else if (action === "RECAP") d = "concise";
  if (action !== "DEEPEN" && affect.confusion > 0.5) shift(-1);
  if (action !== "SIMPLIFY" && affect.fatigue > 0.5) shift(-1);
  if (input.focus.state.mastery > 0.75 && affect.confusion < 0.2 && action === "DIRECT_EXPLANATION") shift(1);
  return d;
}

function chooseStyle(action: Action, prefs: PolicyInput["learner"]["preferences"]): Style {
  switch (action) {
    case "EXAMPLE":
      return "example";
    case "ANALOGY":
      return "analogy";
    case "VISUALIZE":
      return "visual";
    case "EXECUTE":
    case "PREDICT":
      return "step_by_step";
    case "DEEPEN":
      return prefs.style.formal > 0.5 ? "formal" : preferredStyle(prefs);
    default:
      return preferredStyle(prefs);
  }
}

function chooseTool(action: Action): Tool {
  if (action === "EXECUTE") return "python_tracer";
  if (action === "VISUALIZE") return "graph_diagram";
  return "llm";
}

/** 1 inside [lo,hi], falling linearly to 0 at distance 0.3 outside. */
function bump(x: number, lo: number, hi: number): number {
  if (x >= lo && x <= hi) return 1;
  const d = x < lo ? lo - x : x - hi;
  return Math.max(0, 1 - d / 0.3);
}
