// Learner model: preferences, affect and interaction tendencies.
// All updates are pure functions: (model, evidence) -> new model.
//
//   new_preference = old + lr * evidence * (target - old)  -  slow regression to prior
//   affect_t       = baseline + (affect_{t-1} - baseline) * carry  + evidence lift
import { DEPTHS, STYLES } from "./types";
import type { Affect, Depth, LearnerModel, Preferences, Signal, Style, Tendencies, SessionContext } from "./types";

export const PREFERENCE_PRIOR: Preferences = {
  depth: { concise: 0.4, standard: 0.6, detailed: 0.4, deep: 0.25 },
  style: { example: 0.55, analogy: 0.45, visual: 0.45, formal: 0.3, step_by_step: 0.5 },
};

export const AFFECT_BASELINE: Affect = {
  confusion: 0,
  curiosity: 0.2,
  engagement: 0.5,
  frustration: 0,
  fatigue: 0,
  confidence: 0.5,
};

const AFFECT_CARRY = 0.65; // per-turn carry-over; affect is short-lived
const PREF_LR = 0.28; // learning rate per unit of evidence
const PREF_REGRESSION = 0.02; // per-turn pull toward prior (forgetting)
const PREF_MIN = 0.05;
const PREF_MAX = 0.95;

export function emptyTendencies(): Tendencies {
  return {
    turns: 0,
    followUps: 0,
    clarifications: 0,
    simplifications: 0,
    depthRequests: 0,
    exampleRequests: 0,
    visualRequests: 0,
    corrections: 0,
    topicSwitches: 0,
    predictions: 0,
    predictionsCorrect: 0,
    abandonments: 0,
  };
}

export function newLearnerModel(): LearnerModel {
  return {
    preferences: structuredClone(PREFERENCE_PRIOR),
    affect: { ...AFFECT_BASELINE },
    tendencies: emptyTendencies(),
    session: { recentActions: [], turnsOnFocus: 0 },
  };
}

const clamp = (v: number, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, v));

/** Move `cur` toward `target` proportionally to evidence weight. */
function nudge(cur: number, target: number, w: number): number {
  return clamp(cur + PREF_LR * w * (target - cur), PREF_MIN, PREF_MAX);
}

function regress(cur: number, prior: number): number {
  return cur + PREF_REGRESSION * (prior - cur);
}

export function updatePreferences(prefs: Preferences, signals: Signal[]): Preferences {
  const depth = { ...prefs.depth };
  const style = { ...prefs.style };
  const w = (t: Signal["type"]) => signals.find((s) => s.type === t)?.weight ?? 0;

  // Depth evidence. Requests push their own bucket up and the opposite pole down.
  const simp = w("simplification_request") + 0.5 * w("clarification_request");
  if (simp > 0) {
    depth.concise = nudge(depth.concise, 1, simp);
    depth.standard = nudge(depth.standard, 0.7, simp * 0.5);
    depth.detailed = nudge(depth.detailed, 0, simp * 0.7);
    depth.deep = nudge(depth.deep, 0, simp);
  }
  const deep = w("depth_request") + 0.4 * w("engagement_signal") * (w("curiosity_signal") > 0 ? 1 : 0);
  if (deep > 0) {
    depth.deep = nudge(depth.deep, 1, deep);
    depth.detailed = nudge(depth.detailed, 0.8, deep * 0.5);
    depth.standard = nudge(depth.standard, 0.3, deep * 0.5);
    depth.concise = nudge(depth.concise, 0, deep * 0.7);
  }
  const brief = w("fatigue_signal");
  if (brief > 0) {
    depth.concise = nudge(depth.concise, 1, brief * 0.5);
    depth.deep = nudge(depth.deep, 0, brief * 0.4);
  }

  // Style evidence.
  const styleEvidence: [Style, number][] = [
    ["example", w("example_request")],
    ["analogy", w("analogy_request")],
    ["visual", w("visual_request")],
    ["step_by_step", w("step_request")],
    ["formal", w("depth_request") * 0.4],
  ];
  for (const [s, ev] of styleEvidence) {
    if (ev > 0) {
      style[s] = nudge(style[s], 1, ev);
      // Mild competition so one style does not dominate purely by accumulation.
      for (const other of STYLES) if (other !== s) style[other] = nudge(style[other], PREFERENCE_PRIOR.style[other], ev * 0.15);
    }
  }
  // Prediction outcomes are evidence that step-by-step/execution helps.
  if (w("prediction_incorrect") > 0) style.step_by_step = nudge(style.step_by_step, 1, 0.4);

  // Slow regression toward prior every turn (forgetting).
  for (const d of DEPTHS) depth[d] = regress(depth[d], PREFERENCE_PRIOR.depth[d]);
  for (const s of STYLES) style[s] = regress(style[s], PREFERENCE_PRIOR.style[s]);

  return { depth, style };
}

export function updateAffect(prev: Affect, signals: Signal[], tendencies: Tendencies): Affect {
  const w = (t: Signal["type"]) => signals.find((s) => s.type === t)?.weight ?? 0;
  const carry = (k: keyof Affect) => AFFECT_BASELINE[k] + (prev[k] - AFFECT_BASELINE[k]) * AFFECT_CARRY;
  const lift = (cur: number, ev: number, gain = 0.5) => clamp(cur + (1 - cur) * ev * gain);
  const drop = (cur: number, ev: number, gain = 0.5) => clamp(cur - cur * ev * gain);

  let confusion = carry("confusion");
  let curiosity = carry("curiosity");
  let engagement = carry("engagement");
  let frustration = carry("frustration");
  let fatigue = carry("fatigue");
  let confidence = carry("confidence");

  confusion = lift(confusion, w("confusion_signal"), 0.6);
  confusion = lift(confusion, w("prediction_incorrect"), 0.4);
  confusion = drop(confusion, w("successful_continuation"), 0.6);
  confusion = drop(confusion, w("prediction_correct"), 0.5);

  curiosity = lift(curiosity, w("curiosity_signal"), 0.6);
  curiosity = lift(curiosity, w("depth_request"), 0.4);
  curiosity = lift(curiosity, w("topic_switch") * 0.5, 0.3);
  curiosity = drop(curiosity, w("fatigue_signal"), 0.4);

  engagement = lift(engagement, w("engagement_signal"), 0.5);
  engagement = lift(engagement, w("prediction_attempt"), 0.4);
  engagement = lift(engagement, w("successful_continuation"), 0.2);
  engagement = drop(engagement, w("fatigue_signal"), 0.5);
  engagement = drop(engagement, w("abandonment"), 0.4);

  // Frustration grows when confusion is repeated, not on the first stumble.
  const repeatedConfusion = tendencies.clarifications + tendencies.simplifications >= 2 ? 0.3 : 0;
  frustration = lift(frustration, w("frustration_signal"), 0.7);
  frustration = lift(frustration, w("confusion_signal") * repeatedConfusion, 0.5);
  frustration = drop(frustration, w("successful_continuation"), 0.6);

  fatigue = lift(fatigue, w("fatigue_signal"), 0.6);
  fatigue = lift(fatigue, tendencies.turns > 12 ? 0.1 : 0, 0.3);
  fatigue = drop(fatigue, w("curiosity_signal"), 0.3);

  confidence = lift(confidence, w("prediction_correct"), 0.5);
  confidence = lift(confidence, w("successful_continuation"), 0.2);
  confidence = drop(confidence, w("prediction_incorrect"), 0.4);
  confidence = drop(confidence, w("confusion_signal"), 0.3);

  return {
    confusion: round(confusion),
    curiosity: round(curiosity),
    engagement: round(engagement),
    frustration: round(frustration),
    fatigue: round(fatigue),
    confidence: round(confidence),
  };
}

export function updateTendencies(t: Tendencies, signals: Signal[]): Tendencies {
  const has = (k: Signal["type"]) => signals.some((s) => s.type === k);
  return {
    turns: t.turns + 1,
    followUps: t.followUps + (has("follow_up_request") ? 1 : 0),
    clarifications: t.clarifications + (has("clarification_request") ? 1 : 0),
    simplifications: t.simplifications + (has("simplification_request") ? 1 : 0),
    depthRequests: t.depthRequests + (has("depth_request") ? 1 : 0),
    exampleRequests: t.exampleRequests + (has("example_request") ? 1 : 0),
    visualRequests: t.visualRequests + (has("visual_request") ? 1 : 0),
    corrections: t.corrections + (has("correction") ? 1 : 0),
    topicSwitches: t.topicSwitches + (has("topic_switch") ? 1 : 0),
    predictions: t.predictions + (has("prediction_attempt") ? 1 : 0),
    predictionsCorrect: t.predictionsCorrect + (has("prediction_correct") ? 1 : 0),
    abandonments: t.abandonments + (has("abandonment") ? 1 : 0),
  };
}

export function preferredDepth(p: Preferences): Depth {
  return DEPTHS.reduce((best, d) => (p.depth[d] > p.depth[best] ? d : best), "standard" as Depth);
}
export function preferredStyle(p: Preferences): Style {
  return STYLES.reduce((best, s) => (p.style[s] > p.style[best] ? s : best), "example" as Style);
}

export function updateSession(
  s: SessionContext,
  patch: { focusConcept: string; action: import("./types").Action; now: number; pendingPrediction?: import("./types").PendingPrediction | null },
): SessionContext {
  const sameFocus = s.focusConcept === patch.focusConcept;
  return {
    focusConcept: patch.focusConcept,
    pendingPrediction: patch.pendingPrediction === null ? undefined : (patch.pendingPrediction ?? undefined),
    recentActions: [...s.recentActions, { action: patch.action, conceptId: patch.focusConcept }].slice(-6),
    turnsOnFocus: sameFocus ? s.turnsOnFocus + 1 : 1,
    lastTurnAt: patch.now,
  };
}

/** Coerce arbitrary persisted/foreign data into a valid LearnerModel (defaults fill gaps; wrong types are dropped). */
export function coerceLearnerModel(value: unknown): LearnerModel {
  const fresh = newLearnerModel();
  if (!value || typeof value !== "object") return fresh;
  const v = value as Partial<Record<keyof LearnerModel, unknown>>;
  const model: LearnerModel = {
    preferences: mergeSafe(fresh.preferences, v.preferences),
    affect: mergeSafe(fresh.affect, v.affect),
    tendencies: mergeSafe(fresh.tendencies, v.tendencies),
    session: mergeSafe(fresh.session, v.session),
  };
  for (const d of DEPTHS) model.preferences.depth[d] = clamp(Number(model.preferences.depth[d]) || PREFERENCE_PRIOR.depth[d], PREF_MIN, PREF_MAX);
  for (const s of STYLES) model.preferences.style[s] = clamp(Number(model.preferences.style[s]) || PREFERENCE_PRIOR.style[s], PREF_MIN, PREF_MAX);
  for (const k of Object.keys(AFFECT_BASELINE) as (keyof Affect)[]) model.affect[k] = clamp(Number(model.affect[k]) || AFFECT_BASELINE[k]);
  if (!Array.isArray(model.session.recentActions)) model.session.recentActions = [];
  if (model.session.pendingPrediction && (typeof model.session.pendingPrediction.expected !== "string" || typeof model.session.pendingPrediction.conceptId !== "string")) model.session.pendingPrediction = undefined;
  return model;
}

function mergeSafe<T extends object>(defaults: T, value: unknown): T {
  if (!value || typeof value !== "object" || Array.isArray(value)) return defaults;
  const out: Record<string, unknown> = { ...(defaults as Record<string, unknown>) };
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    const d = out[k];
    if (d && typeof d === "object" && !Array.isArray(d) && v && typeof v === "object" && !Array.isArray(v)) out[k] = mergeSafe(d as object, v);
    else if (v !== undefined && v !== null && (d === undefined || typeof v === typeof d)) out[k] = v;
  }
  return out as T;
}

function round(v: number) {
  return Math.round(v * 1000) / 1000;
}
