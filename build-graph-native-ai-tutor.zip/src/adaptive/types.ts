// Adaptive core types. Pure data; no I/O.

export const DEPTHS = ["concise", "standard", "detailed", "deep"] as const;
export type Depth = (typeof DEPTHS)[number];

export const STYLES = ["example", "analogy", "visual", "formal", "step_by_step"] as const;
export type Style = (typeof STYLES)[number];

export interface Preferences {
  depth: Record<Depth, number>;
  style: Record<Style, number>;
}

export interface Affect {
  confusion: number;
  curiosity: number;
  engagement: number;
  frustration: number;
  fatigue: number;
  confidence: number;
}

export interface Tendencies {
  turns: number;
  followUps: number;
  clarifications: number;
  simplifications: number;
  depthRequests: number;
  exampleRequests: number;
  visualRequests: number;
  corrections: number;
  topicSwitches: number;
  predictions: number;
  predictionsCorrect: number;
  abandonments: number;
}

export interface PendingPrediction {
  conceptId: string;
  expected: string; // actual program output, computed before asking
  askedAt: number;
  askedTurn: number; // tendencies.turns when asked; expires after a few turns
}

export interface SessionContext {
  focusConcept?: string;
  pendingPrediction?: PendingPrediction;
  recentActions: { action: Action; conceptId: string }[];
  turnsOnFocus: number;
  lastTurnAt?: number;
}

export interface LearnerModel {
  preferences: Preferences;
  affect: Affect;
  tendencies: Tendencies;
  session: SessionContext;
}

export interface ConceptState {
  conceptId: string;
  mastery: number; // evolving belief in [0,1]
  confidence: number; // how much evidence supports the mastery belief
  strength: number; // historical branch strength at lastActiveAt
  lastActiveAt: number; // epoch ms
  interactionCount: number;
}

export type BranchStatus = "untouched" | "active" | "weak" | "dormant";

export const SIGNAL_TYPES = [
  "follow_up_request",
  "clarification_request",
  "simplification_request",
  "depth_request",
  "example_request",
  "analogy_request",
  "visual_request",
  "step_request",
  "correction",
  "successful_continuation",
  "abandonment",
  "curiosity_signal",
  "confusion_signal",
  "frustration_signal",
  "engagement_signal",
  "fatigue_signal",
  "topic_switch",
  "prediction_correct",
  "prediction_incorrect",
  "prediction_attempt",
  "compare_request",
  "direct_question",
] as const;
export type SignalType = (typeof SIGNAL_TYPES)[number];

export interface Signal {
  type: SignalType;
  weight: number; // 0..1
  evidence?: string;
}

export const ACTIONS = [
  "DIRECT_EXPLANATION",
  "SIMPLIFY",
  "DEEPEN",
  "EXAMPLE",
  "ANALOGY",
  "VISUALIZE",
  "PREDICT",
  "EXECUTE",
  "COMPARE",
  "RECAP",
  "PREREQUISITE",
  "EXPLORE_RELATED",
  "REACTIVATE_BRANCH",
  "ASK_GUIDING_QUESTION",
] as const;
export type Action = (typeof ACTIONS)[number];

export type Tool = "llm" | "template" | "python_tracer" | "graph_diagram";

export interface Decision {
  action: Action;
  targetConcept: string;
  auxConcept?: string;
  depth: Depth;
  style: Style;
  tool: Tool;
  scores: Partial<Record<Action, number>>;
  reasons: string[];
}

/** Everything the policy is allowed to look at. Assembled by the application layer. */
export interface PolicyInput {
  now: number;
  focus: { id: string; state: ConceptState; status: BranchStatus; activation: number; hasCode: boolean; wasDormant: boolean };
  prerequisites: { id: string; state: ConceptState; status: BranchStatus; activation: number }[];
  related: { id: string; state: ConceptState; status: BranchStatus; activation: number }[];
  mentioned: string[]; // concept ids resolved from the message (Graphify)
  learner: LearnerModel;
  signals: Signal[];
  tools: { python: boolean };
}
