// Adaptive core entry point: one pure state transition per learner turn.
//
//   (learner model, concept overlay, message, graph context, now)
//        -> signals -> updated learner model -> updated overlay -> decision
//
// No I/O here. The application layer supplies graph structure and persists results.
import { extractSignals, judgePrediction } from "./signals";
import { updateAffect, updatePreferences, updateTendencies, updateSession, newLearnerModel } from "./learner";
import { newConceptState, reinforce, masteryEvidence, updateMastery, status, activation } from "./knowledge";
import { decide } from "./policy";
import type { ConceptState, Decision, LearnerModel, PendingPrediction, Signal, Action } from "./types";

export * from "./types";
export { extractSignals, judgePrediction } from "./signals";
export { newLearnerModel, updatePreferences, updateAffect, updateTendencies, preferredDepth, preferredStyle, PREFERENCE_PRIOR } from "./learner";
export { newConceptState, reinforce, masteryEvidence, updateMastery, status, activation, describe, HALF_LIFE_DAYS } from "./knowledge";
export { decide } from "./policy";

export interface GraphContext {
  focusId: string;
  mentioned: string[];
  prerequisites: string[];
  related: string[];
  hasCode: boolean;
}

export interface StepInput {
  now: number;
  message: string;
  learner: LearnerModel;
  concepts: Map<string, ConceptState>;
  graph: GraphContext;
  tools: { python: boolean };
}

export interface StepResult {
  signals: Signal[];
  learner: LearnerModel; // updated (session not yet finalised: see finalize)
  concepts: Map<string, ConceptState>;
  decision: Decision;
  reactivated: string[];
  predictionOutcome?: { correct: boolean; expected: string; score: number };
  delta: { mastery: { before: number; after: number }; activation: { before: number; after: number } };
}

/** Run signal extraction, state update and policy for one learner message. */
export function adaptiveStep(input: StepInput): StepResult {
  const { now, message, graph, tools } = input;
  const learner = input.learner ?? newLearnerModel();
  const concepts = new Map(input.concepts);
  const get = (id: string) => concepts.get(id) ?? newConceptState(id, now);

  // 1. Signals (including resolving a pending prediction, which is real outcome evidence).
  const signals = extractSignals(message, {
    session: learner.session,
    now,
    mentioned: graph.mentioned,
    relatedToFocus: [...graph.prerequisites, ...graph.related],
  });
  let predictionOutcome: StepResult["predictionOutcome"];
  const pending = learner.session.pendingPrediction;
  const onPendingConcept = !!pending && (graph.mentioned.length === 0 || graph.mentioned.includes(pending.conceptId));
  if (pending && onPendingConcept && looksLikeAnswer(message, signals)) {
    const j = judgePrediction(message, pending.expected);
    predictionOutcome = { correct: j.correct, expected: pending.expected, score: j.score };
    signals.push({ type: "prediction_attempt", weight: 1, evidence: "answered pending prediction" });
    signals.push({ type: j.correct ? "prediction_correct" : "prediction_incorrect", weight: 1, evidence: `score=${j.score.toFixed(2)}` });
    // A prediction answer is not a direct question.
    const i = signals.findIndex((s) => s.type === "direct_question");
    if (i >= 0) signals.splice(i, 1);
  }

  // 2. Learner model update (preferences, affect, tendencies).
  const tendencies = updateTendencies(learner.tendencies, signals);
  const preferences = updatePreferences(learner.preferences, signals);
  const affect = updateAffect(learner.affect, signals, tendencies);
  const updatedLearner: LearnerModel = { preferences, affect, tendencies, session: learner.session };

  // 3. Knowledge overlay update for the focus concept (and touched mentions).
  const focusBefore = get(graph.focusId);
  const activationBefore = activation(focusBefore, now);
  const reactivated: string[] = [];
  const touch = (id: string, weight: number) => {
    const r = reinforce(get(id), now, weight);
    if (r.reactivated) reactivated.push(id);
    concepts.set(id, r.state);
  };
  touch(graph.focusId, 1);
  for (const m of graph.mentioned) if (m !== graph.focusId) touch(m, 0.5);
  const ev = masteryEvidence(signals, true);
  concepts.set(graph.focusId, updateMastery(get(graph.focusId), ev.outcome, ev.weight));
  // Evidence about the focus concept says a little about its prerequisites too (they were exercised).
  if (ev.outcome > 0) for (const p of graph.prerequisites) concepts.set(p, updateMastery(get(p), 0.3, ev.weight * 0.3));

  // 4. Policy.
  const wrap = (id: string) => {
    const s = get(id);
    return { id, state: s, status: status(s, now), activation: activation(s, now) };
  };
  const decision = decide({
    now,
    focus: { ...wrap(graph.focusId), hasCode: graph.hasCode, wasDormant: status(focusBefore, now) === "dormant" },
    prerequisites: graph.prerequisites.map(wrap),
    related: graph.related.map(wrap),
    mentioned: graph.mentioned,
    learner: updatedLearner,
    signals,
    tools,
  });

  const focusAfter = get(graph.focusId);
  return {
    signals,
    learner: updatedLearner,
    concepts,
    decision,
    reactivated,
    predictionOutcome,
    delta: {
      mastery: { before: focusBefore.mastery, after: focusAfter.mastery },
      activation: { before: round(activationBefore), after: round(activation(focusAfter, now)) },
    },
  };
}

/** Finalise the session context once the teaching action has actually been delivered. */
export function finalizeTurn(learner: LearnerModel, action: Action, focusConcept: string, now: number, pendingPrediction: PendingPrediction | null): LearnerModel {
  return { ...learner, session: updateSession(learner.session, { focusConcept, action, now, pendingPrediction }) };
}

/**
 * A pending prediction is only judged when the message plausibly *is* an answer:
 * it carries a value (digits/quotes/brackets/code-ish tokens) or an answer frame,
 * and it is not an explicit strategy request. Otherwise the learner moved on and
 * we must not manufacture a "wrong prediction" out of an unrelated message.
 */
export function looksLikeAnswer(message: string, signals: Signal[]): boolean {
  const t = message.trim();
  const strategy = new Set<Signal["type"]>(["simplification_request", "depth_request", "example_request", "analogy_request", "visual_request", "step_request", "compare_request", "curiosity_signal", "fatigue_signal"]);
  if (signals.some((s) => strategy.has(s.type) && s.weight >= 0.6)) return false;
  if (/\d|["'`\[\]{}()]|\b(none|true|false|error)\b/i.test(t)) return true;
  if (/^(i think|it (will|would|prints?|returns?|outputs?)|the (output|result|answer)|prints?|output:?|result:?|answer:?|probably|maybe)/i.test(t)) return true;
  return false;
}

function round(v: number) {
  return Math.round(v * 1000) / 1000;
}
