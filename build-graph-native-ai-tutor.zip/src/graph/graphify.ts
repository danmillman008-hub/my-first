// Thin adapter over Graphify. Graphify owns graph topology, identity, ranking,
// traversal and paths. This module only:
//   1. reads Graphify's canonical artifact (graphify-out/graph.json, node-link format)
//      for cheap structural lookups (never writes it), and
//   2. shells out to Graphify's own CLI (`graphify query|path|explain`) for
//      ranked semantic resolution, with a bounded fallback when Python is absent.
import fs from "node:fs";
import path from "node:path";
import { execFile } from "node:child_process";

export interface GraphNode {
  id: string;
  label: string;
  community?: number;
  source_file?: string;
  file_type?: string;
}
export interface GraphEdge {
  source: string;
  target: string;
  relation: string;
  confidence: string;
}

const GRAPH_PATH = path.join(process.cwd(), "graphify-out", "graph.json");

class GraphifyGraphReader {
  private nodes = new Map<string, GraphNode>();
  private out = new Map<string, GraphEdge[]>();
  private in = new Map<string, GraphEdge[]>();
  private labelIndex = new Map<string, string>();
  private mtime = 0;
  loaded = false;

  private ensure() {
    let stat: fs.Stats;
    try {
      stat = fs.statSync(GRAPH_PATH);
    } catch {
      this.loaded = false;
      return;
    }
    if (this.loaded && stat.mtimeMs === this.mtime) return;
    const raw = JSON.parse(fs.readFileSync(GRAPH_PATH, "utf8"));
    const links: GraphEdge[] = raw.links ?? raw.edges ?? [];
    this.nodes.clear();
    this.out.clear();
    this.in.clear();
    this.labelIndex.clear();
    for (const n of raw.nodes as GraphNode[]) {
      this.nodes.set(n.id, n);
      this.labelIndex.set(n.label.toLowerCase(), n.id);
      this.labelIndex.set(n.id.toLowerCase(), n.id);
    }
    for (const e of links) {
      if (!this.out.has(e.source)) this.out.set(e.source, []);
      if (!this.in.has(e.target)) this.in.set(e.target, []);
      this.out.get(e.source)!.push(e);
      this.in.get(e.target)!.push(e);
    }
    this.mtime = stat.mtimeMs;
    this.loaded = true;
  }

  available(): boolean {
    this.ensure();
    return this.loaded;
  }
  node(id: string): GraphNode | undefined {
    this.ensure();
    return this.nodes.get(id);
  }
  allIds(): string[] {
    this.ensure();
    return [...this.nodes.keys()];
  }
  idForLabel(label: string): string | undefined {
    this.ensure();
    return this.labelIndex.get(label.toLowerCase().trim());
  }
  /** Concepts that must come before `id` (incoming prerequisite_of edges). */
  prerequisitesOf(id: string): string[] {
    this.ensure();
    return (this.in.get(id) ?? []).filter((e) => e.relation === "prerequisite_of").map((e) => e.source);
  }
  /** Concepts that build on `id` (outgoing prerequisite_of edges). */
  dependentsOf(id: string): string[] {
    this.ensure();
    return (this.out.get(id) ?? []).filter((e) => e.relation === "prerequisite_of").map((e) => e.target);
  }
  relatedTo(id: string): string[] {
    this.ensure();
    const s = new Set<string>();
    for (const e of this.out.get(id) ?? []) if (e.relation === "related_to") s.add(e.target);
    for (const e of this.in.get(id) ?? []) if (e.relation === "related_to") s.add(e.source);
    return [...s];
  }
  neighbors(id: string): { id: string; relation: string; direction: "out" | "in"; confidence: string }[] {
    this.ensure();
    return [
      ...(this.out.get(id) ?? []).map((e) => ({ id: e.target, relation: e.relation, direction: "out" as const, confidence: e.confidence })),
      ...(this.in.get(id) ?? []).map((e) => ({ id: e.source, relation: e.relation, direction: "in" as const, confidence: e.confidence })),
    ];
  }
  /** Bounded fallback matcher used only when the Graphify CLI is unavailable. */
  fallbackMatch(text: string): string[] {
    this.ensure();
    const t = text.toLowerCase();
    const hits: { id: string; score: number }[] = [];
    for (const n of this.nodes.values()) {
      const label = n.label.toLowerCase();
      const idw = n.id.replace(/_/g, " ");
      let score = 0;
      if (t.includes(label)) score += label.length * 2;
      else if (t.includes(idw)) score += idw.length * 2;
      else {
        const stem = label.replace(/(ies|s)$/, "");
        if (stem.length > 3 && t.includes(stem)) score += stem.length;
      }
      if (score > 0) hits.push({ id: n.id, score });
    }
    return hits.sort((a, b) => b.score - a.score).map((h) => h.id);
  }
}

export const graph = new GraphifyGraphReader();

// ---------------------------------------------------------------------------
// Graphify CLI bridge (python3 -m graphify ...). Bounded, non-fatal.
// ---------------------------------------------------------------------------
let cliHealthy: boolean | null = null;

function runGraphify(args: string[], timeoutMs = 8000): Promise<string | null> {
  if (cliHealthy === false) return Promise.resolve(null);
  const py = process.env.GRAPHIFY_PYTHON || "python3";
  return new Promise((resolve) => {
    execFile(
      py,
      ["-m", "graphify", ...args],
      { cwd: process.cwd(), timeout: timeoutMs, maxBuffer: 2_000_000, env: { ...process.env, PYTHONWARNINGS: "ignore" } },
      (err, stdout) => {
        if (err) {
          if ((err as NodeJS.ErrnoException).code === "ENOENT" || /No module named/.test(String(err))) cliHealthy = false;
          resolve(null);
          return;
        }
        cliHealthy = true;
        resolve(stdout);
      },
    );
  });
}

export interface ConceptResolution {
  conceptIds: string[];
  via: "graphify-query" | "fallback" | "none";
  raw?: string;
}

/** Resolve free text to concept node ids using Graphify's ranked query seeds. */
export async function resolveConcepts(question: string): Promise<ConceptResolution> {
  const cleaned = question.replace(/\s+/g, " ").trim().slice(0, 400);
  if (!cleaned) return { conceptIds: [], via: "none" };
  const out = await runGraphify(["query", cleaned, "--depth", "1", "--budget", "600"]);
  if (out) {
    const m = out.match(/Start:\s*\[([^\]]*)\]/);
    if (m) {
      const labels = [...m[1].matchAll(/'([^']+)'/g)].map((x) => x[1]);
      const ids = labels.map((l) => graph.idForLabel(l)).filter((x): x is string => !!x);
      if (ids.length) return { conceptIds: ids, via: "graphify-query", raw: out };
    }
    if (/no nodes found|0 nodes found/i.test(out)) return { conceptIds: [], via: "graphify-query", raw: out };
  }
  const ids = graph.fallbackMatch(cleaned);
  return { conceptIds: ids, via: ids.length ? "fallback" : "none" };
}

export async function graphifyExplain(id: string): Promise<string | null> {
  const n = graph.node(id);
  if (!n) return null;
  return runGraphify(["explain", n.label]);
}

export async function graphifyPath(a: string, b: string): Promise<string | null> {
  const na = graph.node(a);
  const nb = graph.node(b);
  if (!na || !nb) return null;
  return runGraphify(["path", na.label, nb.label]);
}

export function graphifyCliStatus(): "unknown" | "healthy" | "unavailable" {
  return cliHealthy === null ? "unknown" : cliHealthy ? "healthy" : "unavailable";
}
