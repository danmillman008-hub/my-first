// MCP adapter (thin). Exposes tutor capabilities over the Model Context
// Protocol using the official SDK. Every tool/resource delegates to the
// application service; there is no business logic and no direct DB access here.
import { McpServer, ResourceTemplate } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { tutor } from "@/tutor/session";
import { graph, graphifyExplain, graphifyPath, resolveConcepts } from "@/graph/graphify";
import { SIGNAL_TYPES } from "@/adaptive/types";

const learnerId = z.string().min(1).max(64).regex(/^[a-zA-Z0-9_\-.]+$/);
const conceptId = z.string().min(1).max(128);

const text = (v: unknown) => ({ content: [{ type: "text" as const, text: typeof v === "string" ? v : JSON.stringify(v, null, 2) }] });
const fail = (msg: string) => ({ content: [{ type: "text" as const, text: msg }], isError: true });

export function createTutorMcpServer(): McpServer {
  const server = new McpServer({ name: "adaptive-tutor", version: "0.1.0" });

  // ---- read tools ---------------------------------------------------------
  server.registerTool(
    "get_graph_context",
    { title: "Graph context", description: "Resolve free text to concepts via Graphify and return the concept neighbourhood.", inputSchema: { question: z.string().min(1).max(400) } },
    async ({ question }) => {
      const r = await resolveConcepts(question);
      const ctx = r.conceptIds.slice(0, 3).map((id) => ({
        id,
        label: graph.node(id)?.label,
        prerequisites: graph.prerequisitesOf(id),
        dependents: graph.dependentsOf(id),
        related: graph.relatedTo(id),
      }));
      return text({ via: r.via, concepts: ctx });
    },
  );
  server.registerTool(
    "get_concept",
    { title: "Concept", description: "Graphify explain output for one concept plus the learner's state on it (if learnerId given).", inputSchema: { conceptId, learnerId: learnerId.optional() } },
    async ({ conceptId: id, learnerId: lid }) => {
      if (!graph.node(id)) return fail(`unknown concept: ${id}`);
      const explain = await graphifyExplain(id);
      const view = lid ? await tutor().conceptView(lid, id) : await tutor().conceptView("__anon__", id);
      return text({ graphify: explain?.trim() ?? null, ...view });
    },
  );
  server.registerTool(
    "get_related_concepts",
    { title: "Related concepts", description: "Neighbours of a concept in the Graphify graph, or the shortest path between two concepts.", inputSchema: { conceptId, otherConceptId: conceptId.optional() } },
    async ({ conceptId: a, otherConceptId: b }) => {
      if (!graph.node(a)) return fail(`unknown concept: ${a}`);
      if (b) {
        if (!graph.node(b)) return fail(`unknown concept: ${b}`);
        return text((await graphifyPath(a, b))?.trim() ?? "no path");
      }
      return text(graph.neighbors(a).map((n) => ({ ...n, label: graph.node(n.id)?.label })));
    },
  );
  server.registerTool("get_learning_state", { title: "Learning state", description: "Learner snapshot: focus, preferences, affect, tendencies, branch activation.", inputSchema: { learnerId } }, async ({ learnerId: lid }) =>
    text(await tutor().snapshot(lid)),
  );
  server.registerTool("get_user_preferences", { title: "Preferences", description: "Learned explanation preferences (depth/style).", inputSchema: { learnerId } }, async ({ learnerId: lid }) => text((await tutor().snapshot(lid)).preferences));
  server.registerTool("get_active_branches", { title: "Active branches", description: "Concept branches currently active or weak for a learner.", inputSchema: { learnerId } }, async ({ learnerId: lid }) => {
    const s = await tutor().snapshot(lid);
    return text({ active: s.branches.active, weak: s.branches.weak });
  });
  server.registerTool("get_dormant_branches", { title: "Dormant branches", description: "Concept branches that decayed to dormant (retained, not deleted).", inputSchema: { learnerId } }, async ({ learnerId: lid }) =>
    text((await tutor().snapshot(lid)).branches.dormant),
  );
  server.registerTool("get_current_policy", { title: "Current policy", description: "The last policy decision with its scored reasons.", inputSchema: { learnerId } }, async ({ learnerId: lid }) => {
    const h = await tutor().history(lid, 10);
    const last = [...h].reverse().find((r) => r.role === "tutor" && r.decision);
    return text(last?.decision ?? { note: "no decisions yet" });
  });

  // ---- safe mutations (all routed through the adaptive core) -------------
  server.registerTool(
    "record_interaction",
    { title: "Record interaction", description: "Send a learner message through the full adaptive loop and get the tutor's response, decision and state.", inputSchema: { learnerId, message: z.string().min(1).max(2000), eventId: z.string().max(128).optional() } },
    async ({ learnerId: lid, message, eventId }) => {
      const r = await tutor().handleTurn(lid, message, { eventId, allowLlm: true });
      return text({ reply: r.reply, decision: r.trace.decision, signals: r.trace.signals, state: r.state });
    },
  );
  server.registerTool(
    "record_learning_signal",
    { title: "Record learning signal", description: "Record an explicit learning signal about a concept (e.g. from another client).", inputSchema: { learnerId, conceptId, signal: z.enum(SIGNAL_TYPES), weight: z.number().min(0).max(1).optional() } },
    async ({ learnerId: lid, conceptId: cid, signal, weight }) => {
      try {
        const r = await tutor().recordSignal(lid, cid, signal, weight);
        return text({ decision: r.trace.decision, state: r.state });
      } catch (e) {
        return fail(e instanceof Error ? e.message : "failed");
      }
    },
  );
  server.registerTool("reactivate_branch", { title: "Reactivate branch", description: "Bring a dormant concept branch back into active learning.", inputSchema: { learnerId, conceptId } }, async ({ learnerId: lid, conceptId: cid }) => {
    try {
      const r = await tutor().reactivate(lid, cid);
      return text({ reply: r.reply, reactivated: r.trace.reactivated, state: r.state });
    } catch (e) {
      return fail(e instanceof Error ? e.message : "failed");
    }
  });

  // ---- resources ----------------------------------------------------------
  server.registerResource("learner-state", new ResourceTemplate("user://{learnerId}/state", { list: undefined }), { title: "Learner state", mimeType: "application/json" }, async (uri, { learnerId: lid }) => ({
    contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify(await tutor().snapshot(String(lid)), null, 2) }],
  }));
  server.registerResource("learner-preferences", new ResourceTemplate("user://{learnerId}/preferences", { list: undefined }), { title: "Learner preferences", mimeType: "application/json" }, async (uri, { learnerId: lid }) => ({
    contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify((await tutor().snapshot(String(lid))).preferences, null, 2) }],
  }));
  server.registerResource("concept", new ResourceTemplate("graph://concept/{conceptId}", { list: undefined }), { title: "Concept", mimeType: "application/json" }, async (uri, { conceptId: cid }) => {
    const view = await tutor().conceptView("__anon__", String(cid));
    return { contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify(view ?? { error: "unknown concept" }, null, 2) }] };
  });

  // ---- prompts ------------------------------------------------------------
  server.registerPrompt("explain_current_concept", { title: "Explain current concept", description: "Ask the tutor to explain the learner's current focus concept.", argsSchema: { learnerId: z.string() } }, async ({ learnerId: lid }) => {
    const s = await tutor().snapshot(lid);
    return { messages: [{ role: "user", content: { type: "text", text: `Explain ${s.focusLabel ?? "the concept I am on"} (call record_interaction for learner ${lid}).` } }] };
  });
  server.registerPrompt("continue_learning_path", { title: "Continue learning path", description: "Continue from the learner's current state.", argsSchema: { learnerId: z.string() } }, async ({ learnerId: lid }) => ({
    messages: [{ role: "user", content: { type: "text", text: `Continue my learning path from where I left off (learner ${lid}); use get_learning_state then record_interaction.` } }],
  }));
  server.registerPrompt("review_current_state", { title: "Review current state", description: "Summarise learner state, active/dormant branches and the last policy decision.", argsSchema: { learnerId: z.string() } }, async ({ learnerId: lid }) => ({
    messages: [{ role: "user", content: { type: "text", text: `Review learner ${lid}: call get_learning_state, get_dormant_branches and get_current_policy, then summarise.` } }],
  }));

  return server;
}
