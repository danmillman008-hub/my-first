// Teaching tools (helpers selected by the policy, never deciding on their own).
import fs from "node:fs";
import path from "node:path";
import { execFile, spawnSync } from "node:child_process";
import { graph } from "@/graph/graphify";

// ---------------------------------------------------------------------------
// Content: the teaching corpus (auto-tutor style lesson primitives per concept).
// The graph topology comes from Graphify; this only supplies the prose/code
// attached to each Graphify node id.
// ---------------------------------------------------------------------------
export interface ConceptContent {
  id: string;
  label: string;
  summary: string;
  simple: string;
  deep: string;
  example: string;
  analogy: string;
  code: string;
  prediction: string;
  misconceptions: string[];
  prerequisites: string[];
  related: string[];
}

let contentCache: Map<string, ConceptContent> | null = null;
export function content(id: string): ConceptContent | undefined {
  if (!contentCache) {
    const raw = JSON.parse(fs.readFileSync(path.join(process.cwd(), "knowledge", "concepts.json"), "utf8"));
    contentCache = new Map((raw.concepts as ConceptContent[]).map((c) => [c.id, c]));
  }
  return contentCache.get(id);
}
export function allContentIds(): string[] {
  content("variables");
  return [...(contentCache?.keys() ?? [])];
}

// ---------------------------------------------------------------------------
// Visible execution (python tracer)
// ---------------------------------------------------------------------------
export interface TraceEvent {
  line: number;
  event: "line" | "call" | "return";
  func: string;
  locals: Record<string, string>;
  value?: string;
}
export interface TraceResult {
  ok: boolean;
  stdout: string;
  events: TraceEvent[];
  error: string | null;
  truncated?: boolean;
}

let pythonHealthy: boolean | null = null;
/** Eager, cached probe so the policy sees real tool availability before deciding. */
export function pythonAvailable(): boolean {
  if (pythonHealthy === null) {
    const py = process.env.TUTOR_PYTHON || process.env.GRAPHIFY_PYTHON || "python3";
    try {
      const r = spawnSync(py, ["-I", "-c", "print(1)"], { timeout: 4000 });
      pythonHealthy = r.status === 0;
    } catch {
      pythonHealthy = false;
    }
  }
  return pythonHealthy;
}

export function runTrace(code: string, timeoutMs = 6000): Promise<TraceResult | null> {
  if (pythonHealthy === false) return Promise.resolve(null);
  const py = process.env.TUTOR_PYTHON || process.env.GRAPHIFY_PYTHON || "python3";
  const script = path.join(process.cwd(), "scripts", "trace_runner.py");
  return new Promise((resolve) => {
    const child = execFile(py, ["-I", script], { timeout: timeoutMs, maxBuffer: 1_000_000 }, (err, stdout) => {
      if (err) {
        if ((err as NodeJS.ErrnoException).code === "ENOENT") pythonHealthy = false;
        resolve(null);
        return;
      }
      pythonHealthy = true;
      try {
        resolve(JSON.parse(stdout) as TraceResult);
      } catch {
        resolve(null);
      }
    });
    child.stdin?.end(code);
  });
}

/** Render a trace compactly for the learner (bounded). */
export function renderTrace(code: string, t: TraceResult, maxSteps = 14): string {
  const lines = code.split("\n");
  const steps = t.events.filter((e) => e.event === "line" || e.event === "return").slice(0, maxSteps);
  const out: string[] = ["```", ...code.split("\n"), "```", "", "Step-by-step:"];
  steps.forEach((e, i) => {
    const src = (lines[e.line - 1] ?? "").trim();
    const vars = Object.entries(e.locals)
      .filter(([k]) => !["__builtins__", "__name__", "self"].includes(k))
      .slice(0, 5)
      .map(([k, v]) => `${k}=${v}`)
      .join(", ");
    const tag = e.event === "return" ? ` → returns ${e.value ?? "None"}` : "";
    out.push(`${i + 1}. L${e.line}${e.func !== "<module>" ? ` (${e.func})` : ""}: ${src}${vars ? `   [${vars}]` : ""}${tag}`);
  });
  if (t.events.length > steps.length) out.push(`… ${t.events.length - steps.length} more steps`);
  out.push("", `Output:`, "```", (t.stdout || "(no output)").trimEnd(), "```");
  if (t.error) out.push(`Error: ${t.error}`);
  return out.join("\n");
}

// ---------------------------------------------------------------------------
// Graph diagram (Mermaid + ASCII) of a concept's Graphify neighbourhood.
// ---------------------------------------------------------------------------
export function renderNeighbourhood(id: string, masteryOf: (id: string) => number | undefined): string {
  const node = graph.node(id);
  if (!node) return "";
  const label = (x: string) => graph.node(x)?.label ?? x;
  const pre = graph.prerequisitesOf(id);
  const dep = graph.dependentsOf(id);
  const rel = graph.relatedTo(id);
  const mark = (x: string) => {
    const m = masteryOf(x);
    return m === undefined ? "" : m >= 0.6 ? " ✓" : m >= 0.35 ? " ~" : " ·";
  };
  const ascii: string[] = [];
  if (pre.length) ascii.push(`  prerequisites : ${pre.map((p) => label(p) + mark(p)).join(", ")}`);
  ascii.push(`  ▶ ${node.label}${mark(id)}`);
  if (dep.length) ascii.push(`  builds toward : ${dep.map((p) => label(p) + mark(p)).join(", ")}`);
  if (rel.length) ascii.push(`  related       : ${rel.map((p) => label(p) + mark(p)).join(", ")}`);
  const mm: string[] = ["```mermaid", "graph LR"];
  const nid = (x: string) => x.replace(/[^a-zA-Z0-9_]/g, "_");
  for (const p of pre) mm.push(`  ${nid(p)}["${label(p)}"] --> ${nid(id)}(["${node.label}"])`);
  for (const d of dep) mm.push(`  ${nid(id)} --> ${nid(d)}["${label(d)}"]`);
  for (const r of rel) mm.push(`  ${nid(id)} -.- ${nid(r)}["${label(r)}"]`);
  if (!pre.length && !dep.length && !rel.length) mm.push(`  ${nid(id)}(["${node.label}"])`);
  mm.push("```");
  return [`Where **${node.label}** sits in the concept graph (✓ solid, ~ developing, · new):`, "", ...ascii, "", ...mm].join("\n");
}
