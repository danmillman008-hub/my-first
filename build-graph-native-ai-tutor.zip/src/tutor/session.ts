// Application layer: tutor session orchestration.
//
//   message -> Graphify concept resolution -> adaptive core step -> realisation
//           -> persist evidence + state -> response (+ observability trace)
//
// This is the ONLY place that mutates learner/knowledge state. MCP and the UI
// call into this service; they never touch the store directly.
import { adaptiveStep, finalizeTurn, describe, status as branchStatus, activation } from "@/adaptive";
import { coerceLearnerModel } from "@/adaptive/learner";
import type { ConceptState, Decision, LearnerModel, Signal } from "@/adaptive/types";
import { graph, resolveConcepts, graphifyCliStatus } from "@/graph/graphify";
import { realise } from "./realize";
import { content, pythonAvailable } from "./tools";
import { defaultStore, type TutorStore } from "./store";

export interface TurnOptions {
  eventId?: string;
  now?: number;
  allowLlm?: boolean;
}

export interface TurnTrace {
  resolvedVia: string;
  mentioned: string[];
  focus: string;
  signals: Signal[];
  decision: Decision;
  tool: string;
  llmUsed: boolean;
  llmError?: string;
  reactivated: string[];
  predictionOutcome?: { correct: boolean; expected: string; score: number };
  delta: { mastery: { before: number; after: number }; activation: { before: number; after: number } };
  affect: LearnerModel["affect"];
  preferences: LearnerModel["preferences"];
}

export interface TurnResult {
  reply: string;
  duplicate?: boolean;
  state: LearnerSnapshot;
  trace: TurnTrace;
}

export interface LearnerSnapshot {
  learnerId: string;
  focusConcept?: string;
  focusLabel?: string;
  depth: string;
  style: string;
  lastAction?: string;
  affect: LearnerModel["affect"];
  preferences: LearnerModel["preferences"];
  tendencies: LearnerModel["tendencies"];
  pendingPrediction?: string;
  branches: { active: BranchView[]; weak: BranchView[]; dormant: BranchView[] };
  graphify: string;
}
export interface BranchView {
  conceptId: string;
  label: string;
  mastery: number;
  activation: number;
  status: string;
  interactionCount: number;
}

export class TutorService {
  constructor(private store: TutorStore = defaultStore()) {}

  async handleTurn(learnerId: string, message: string, opts: TurnOptions = {}): Promise<TurnResult> {
    const now = opts.now ?? Date.now();
    const text = (message ?? "").toString().slice(0, 2000);
    const eventId = opts.eventId ?? `${now}-${hash(text)}`;

    const [rawLearner, rawConcepts] = await Promise.all([this.store.loadLearner(learnerId), this.store.loadConcepts(learnerId)]);
    const learner = coerceLearnerModel(rawLearner); // adaptive core defines validity; persistence may be stale/malformed
    const concepts = new Map([...rawConcepts].filter(([, c]) => c && typeof c.mastery === "number" && typeof c.lastActiveAt === "number"));

    // Idempotency: a duplicate event must not update state twice.
    const fresh = await this.store.appendInteraction(learnerId, { eventId, role: "learner", content: text });
    if (!fresh) {
      const prior = (await this.store.recentInteractions(learnerId, 50)).filter((r) => r.role === "tutor" && r.eventId === `${eventId}:reply`).at(-1);
      return { reply: prior?.content ?? "(already processed)", duplicate: true, state: await this.snapshot(learnerId, now), trace: emptyTrace(learner) };
    }

    // Graph context from Graphify.
    const resolution = await resolveConcepts(text);
    const candidates = resolution.conceptIds.filter((id) => graph.node(id));
    const { focusId, mentioned: known } = pickFocus(candidates, learner, text);
    if (!focusId) {
      const reply = graph.available()
        ? `I couldn't map that to a concept in the graph. Try asking about ${sample()}.`
        : "The concept graph is not built yet (run `python3 scripts/graphify_build.py`).";
      await this.store.appendInteraction(learnerId, { eventId: `${eventId}:reply`, role: "tutor", content: reply });
      return { reply, state: await this.snapshot(learnerId, now), trace: emptyTrace(learner, resolution.via, known) };
    }

    const graphCtx = {
      focusId,
      mentioned: known,
      prerequisites: graph.prerequisitesOf(focusId),
      related: [...graph.relatedTo(focusId), ...graph.dependentsOf(focusId)].filter((x, i, a) => a.indexOf(x) === i),
      hasCode: !!content(focusId)?.code,
    };

    // Adaptive core: pure state transition + decision.
    const step = adaptiveStep({ now, message: text, learner, concepts, graph: graphCtx, tools: { python: pythonAvailable() } });

    // Realise the chosen teaching action (tools/LLM are helpers here).
    const masteryOf = (id: string) => step.concepts.get(id)?.mastery;
    const out = await realise({
      decision: step.decision,
      masteryOf,
      predictionOutcome: step.predictionOutcome,
      learnerMessage: text,
      allowLlm: opts.allowLlm ?? true,
    });

    // Finalise session context now that the action was delivered; persist.
    const nextFocus = step.decision.action === "PREREQUISITE" || step.decision.action === "EXPLORE_RELATED" || (step.decision.action === "REACTIVATE_BRANCH" && step.decision.auxConcept)
      ? (step.decision.auxConcept ?? focusId)
      : focusId;
    // Pending prediction lifecycle: new ask -> set; answered -> clear; carried
    // for up to 3 turns on the same focus, then expired (learner moved on).
    const prev = step.learner.session.pendingPrediction;
    const carry = prev && !step.predictionOutcome && prev.conceptId === nextFocus && step.learner.tendencies.turns - prev.askedTurn <= 3 ? prev : null;
    const pending = out.pendingPrediction ? { ...out.pendingPrediction, askedAt: now, askedTurn: step.learner.tendencies.turns } : carry;
    const finalLearner = finalizeTurn(step.learner, step.decision.action, nextFocus, now, pending);
    if (nextFocus !== focusId) {
      // Moving focus touches the new branch lightly (it was surfaced, not yet learned).
      const s = step.concepts.get(nextFocus);
      if (!s) step.concepts.set(nextFocus, { conceptId: nextFocus, mastery: 0.2, confidence: 0, strength: 0.2, lastActiveAt: now, interactionCount: 0 });
    }

    await Promise.all([
      this.store.saveLearner(learnerId, finalLearner),
      this.store.saveConcepts(learnerId, step.concepts.values()),
      this.store.appendInteraction(learnerId, {
        eventId: `${eventId}:reply`,
        role: "tutor",
        content: out.text,
        conceptId: focusId,
        signals: step.signals,
        decision: { ...step.decision, tool: out.tool, llmUsed: out.llmUsed, reactivated: step.reactivated, delta: step.delta },
      }),
    ]);

    const trace: TurnTrace = {
      resolvedVia: resolution.via,
      mentioned: known,
      focus: focusId,
      signals: step.signals,
      decision: step.decision,
      tool: out.tool,
      llmUsed: out.llmUsed,
      llmError: out.llmError,
      reactivated: step.reactivated,
      predictionOutcome: step.predictionOutcome,
      delta: step.delta,
      affect: finalLearner.affect,
      preferences: finalLearner.preferences,
    };
    return { reply: out.text, state: await this.snapshot(learnerId, now, finalLearner, step.concepts), trace };
  }

  /** Explicit learning signal from an external client (e.g. MCP). Routed through the same core. */
  async recordSignal(learnerId: string, conceptId: string, signalType: Signal["type"], weight = 0.8, now = Date.now()) {
    if (!graph.node(conceptId)) throw new Error(`unknown concept: ${conceptId}`);
    const phrase: Partial<Record<Signal["type"], string>> = {
      simplification_request: "can you make that simpler",
      depth_request: "tell me more detail, go deeper",
      example_request: "show me an example",
      analogy_request: "give me an analogy",
      visual_request: "show me a diagram",
      clarification_request: "I don't understand, what do you mean",
      successful_continuation: "got it, makes sense",
      curiosity_signal: "interesting, what about related ideas",
      frustration_signal: "ugh this is frustrating",
      fatigue_signal: "let's wrap up quickly",
    };
    const msg = `${phrase[signalType] ?? "ok"} (${graph.node(conceptId)!.label})`;
    return this.handleTurn(learnerId, msg, { now, allowLlm: false, eventId: `signal-${now}-${signalType}-${conceptId}` });
  }

  async reactivate(learnerId: string, conceptId: string, now = Date.now()) {
    if (!graph.node(conceptId)) throw new Error(`unknown concept: ${conceptId}`);
    return this.handleTurn(learnerId, `let's revisit ${graph.node(conceptId)!.label}`, { now, allowLlm: false, eventId: `reactivate-${now}-${conceptId}` });
  }

  async snapshot(learnerId: string, now = Date.now(), learner?: LearnerModel, concepts?: Map<string, ConceptState>): Promise<LearnerSnapshot> {
    const l = coerceLearnerModel(learner ?? (await this.store.loadLearner(learnerId)));
    const c = concepts ?? (await this.store.loadConcepts(learnerId));
    const views: BranchView[] = [...c.values()]
      .filter((s) => s.interactionCount > 0)
      .map((s) => ({ conceptId: s.conceptId, label: graph.node(s.conceptId)?.label ?? s.conceptId, mastery: s.mastery, activation: round(activation(s, now)), status: branchStatus(s, now), interactionCount: s.interactionCount }))
      .sort((a, b) => b.activation - a.activation);
    const best = (r: Record<string, number>) => Object.entries(r).sort((a, b) => b[1] - a[1])[0][0];
    return {
      learnerId,
      focusConcept: l.session.focusConcept,
      focusLabel: l.session.focusConcept ? graph.node(l.session.focusConcept)?.label : undefined,
      depth: best(l.preferences.depth),
      style: best(l.preferences.style),
      lastAction: l.session.recentActions.at(-1)?.action,
      affect: l.affect,
      preferences: l.preferences,
      tendencies: l.tendencies,
      pendingPrediction: l.session.pendingPrediction?.conceptId,
      branches: {
        active: views.filter((v) => v.status === "active"),
        weak: views.filter((v) => v.status === "weak"),
        dormant: views.filter((v) => v.status === "dormant"),
      },
      graphify: graphifyCliStatus(),
    };
  }

  async conceptView(learnerId: string, conceptId: string, now = Date.now()) {
    const node = graph.node(conceptId);
    if (!node) return null;
    const c = (await this.store.loadConcepts(learnerId)).get(conceptId);
    return {
      node,
      prerequisites: graph.prerequisitesOf(conceptId).map((id) => ({ id, label: graph.node(id)?.label })),
      dependents: graph.dependentsOf(conceptId).map((id) => ({ id, label: graph.node(id)?.label })),
      related: graph.relatedTo(conceptId).map((id) => ({ id, label: graph.node(id)?.label })),
      learnerState: c ? describe(c, now) : null,
    };
  }

  async history(learnerId: string, limit = 40) {
    return this.store.recentInteractions(learnerId, limit);
  }
}

/**
 * Focus selection. Graphify ranks candidates; the session decides whether the
 * learner actually moved. Mid-conversation meta-requests ("simpler", "too
 * complex") must not hijack the focus just because a word collides with a
 * label, so with an existing focus we only switch on a literal mention or a
 * genuine new direct question.
 */
function pickFocus(candidates: string[], learner: LearnerModel, text: string): { focusId?: string; mentioned: string[] } {
  const focus = learner.session.focusConcept && graph.node(learner.session.focusConcept) ? learner.session.focusConcept : undefined;
  const t = text.toLowerCase();
  const literal = candidates.filter((id) => {
    const n = graph.node(id)!;
    const label = n.label.toLowerCase();
    const idWords = id.replace(/_/g, " ");
    const stem = label.replace(/(ies|s)$/, "");
    return t.includes(label) || t.includes(idWords) || (stem.length > 4 && t.includes(stem));
  });
  const meta = /\b(simpl|easier|complex|complicated|detail|deeper|example|analog|diagram|visual|step|confus|understand|clarify|again|more|less|recap|summar|got it|makes sense|thanks|ok|yes|no|right)\b/i.test(t);

  if (!focus) {
    const id = literal[0] ?? candidates[0];
    return { focusId: id, mentioned: id ? [id, ...literal.filter((x) => x !== id)].slice(0, 3) : [] };
  }
  if (literal.length) {
    const id = literal.includes(focus) ? focus : literal[0];
    return { focusId: id, mentioned: literal.slice(0, 3) };
  }
  // No literal mention: only a plain new question (not a meta-request) may switch focus via Graphify's seed.
  if (candidates.length && !meta && candidates[0] !== focus && /\?|^(what|how|why|explain|tell me|teach)/i.test(t)) {
    return { focusId: candidates[0], mentioned: [candidates[0]] };
  }
  return { focusId: focus, mentioned: [] };
}

function emptyTrace(learner: LearnerModel, via = "none", mentioned: string[] = []): TurnTrace {
  return {
    resolvedVia: via,
    mentioned,
    focus: "",
    signals: [],
    decision: { action: "DIRECT_EXPLANATION", targetConcept: "", depth: "standard", style: "example", tool: "template", scores: {}, reasons: ["no concept resolved"] },
    tool: "none",
    llmUsed: false,
    reactivated: [],
    delta: { mastery: { before: 0, after: 0 }, activation: { before: 0, after: 0 } },
    affect: learner.affect,
    preferences: learner.preferences,
  };
}

function sample(): string {
  return graph.allIds().slice(0, 5).map((id) => graph.node(id)?.label ?? id).join(", ");
}
function hash(s: string): string {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
}
function round(v: number) {
  return Math.round(v * 1000) / 1000;
}

let singleton: TutorService | null = null;
export function tutor(): TutorService {
  if (!singleton) singleton = new TutorService();
  return singleton;
}
