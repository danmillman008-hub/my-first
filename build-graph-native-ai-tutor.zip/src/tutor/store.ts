// Persistence boundary. The application layer is the only writer.
import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { conceptStates, interactions, learnerModels, learners } from "@/db/schema";
import type { ConceptState, LearnerModel } from "@/adaptive/types";
import { newLearnerModel } from "@/adaptive/learner";

export interface InteractionRecord {
  eventId: string;
  role: "learner" | "tutor" | "signal";
  content: string;
  conceptId?: string;
  signals?: unknown;
  decision?: unknown;
}

export interface TutorStore {
  loadLearner(id: string): Promise<LearnerModel>;
  saveLearner(id: string, model: LearnerModel): Promise<void>;
  loadConcepts(id: string): Promise<Map<string, ConceptState>>;
  saveConcepts(id: string, states: Iterable<ConceptState>): Promise<void>;
  /** Returns false when eventId already exists for this learner (idempotent). */
  appendInteraction(id: string, rec: InteractionRecord): Promise<boolean>;
  recentInteractions(id: string, limit: number): Promise<(InteractionRecord & { createdAt: Date })[]>;
}

// ---------------------------------------------------------------------------
export class MemoryStore implements TutorStore {
  learners = new Map<string, LearnerModel>();
  concepts = new Map<string, Map<string, ConceptState>>();
  events = new Map<string, (InteractionRecord & { createdAt: Date })[]>();

  async loadLearner(id: string) {
    return structuredClone(this.learners.get(id) ?? newLearnerModel());
  }
  async saveLearner(id: string, model: LearnerModel) {
    this.learners.set(id, structuredClone(model));
  }
  async loadConcepts(id: string) {
    return new Map(structuredClone([...(this.concepts.get(id) ?? new Map<string, ConceptState>())]));
  }
  async saveConcepts(id: string, states: Iterable<ConceptState>) {
    const m = this.concepts.get(id) ?? new Map<string, ConceptState>();
    for (const s of states) m.set(s.conceptId, structuredClone(s));
    this.concepts.set(id, m);
  }
  async appendInteraction(id: string, rec: InteractionRecord) {
    const list = this.events.get(id) ?? [];
    if (list.some((e) => e.eventId === rec.eventId)) return false;
    list.push({ ...rec, createdAt: new Date() });
    this.events.set(id, list);
    return true;
  }
  async recentInteractions(id: string, limit: number) {
    return (this.events.get(id) ?? []).slice(-limit);
  }
}

// ---------------------------------------------------------------------------
export class PgStore implements TutorStore {
  async loadLearner(id: string): Promise<LearnerModel> {
    const rows = await db.select().from(learnerModels).where(eq(learnerModels.learnerId, id)).limit(1);
    if (!rows.length) return newLearnerModel();
    const r = rows[0];
    return { preferences: r.preferences, affect: r.affect, tendencies: r.tendencies, session: r.session } as LearnerModel;
  }
  async saveLearner(id: string, model: LearnerModel) {
    await db.insert(learners).values({ id }).onConflictDoNothing();
    await db
      .insert(learnerModels)
      .values({ learnerId: id, preferences: model.preferences, affect: model.affect, tendencies: model.tendencies, session: model.session })
      .onConflictDoUpdate({
        target: learnerModels.learnerId,
        set: { preferences: model.preferences, affect: model.affect, tendencies: model.tendencies, session: model.session, updatedAt: sql`now()` },
      });
  }
  async loadConcepts(id: string) {
    const rows = await db.select().from(conceptStates).where(eq(conceptStates.learnerId, id));
    const m = new Map<string, ConceptState>();
    for (const r of rows) {
      m.set(r.conceptId, {
        conceptId: r.conceptId,
        mastery: r.mastery,
        confidence: r.confidence,
        strength: r.strength,
        lastActiveAt: r.lastActiveAt.getTime(),
        interactionCount: r.interactionCount,
      });
    }
    return m;
  }
  async saveConcepts(id: string, states: Iterable<ConceptState>) {
    const list = [...states];
    if (!list.length) return;
    await db.insert(learners).values({ id }).onConflictDoNothing();
    for (const s of list) {
      await db
        .insert(conceptStates)
        .values({
          learnerId: id,
          conceptId: s.conceptId,
          mastery: s.mastery,
          confidence: s.confidence,
          strength: s.strength,
          lastActiveAt: new Date(s.lastActiveAt),
          interactionCount: s.interactionCount,
        })
        .onConflictDoUpdate({
          target: [conceptStates.learnerId, conceptStates.conceptId],
          set: {
            mastery: s.mastery,
            confidence: s.confidence,
            strength: s.strength,
            lastActiveAt: new Date(s.lastActiveAt),
            interactionCount: s.interactionCount,
            updatedAt: sql`now()`,
          },
        });
    }
  }
  async appendInteraction(id: string, rec: InteractionRecord) {
    await db.insert(learners).values({ id }).onConflictDoNothing();
    const res = await db
      .insert(interactions)
      .values({ learnerId: id, eventId: rec.eventId, role: rec.role, content: rec.content, conceptId: rec.conceptId, signals: rec.signals, decision: rec.decision })
      .onConflictDoNothing()
      .returning({ id: interactions.id });
    return res.length > 0;
  }
  async recentInteractions(id: string, limit: number) {
    const rows = await db
      .select()
      .from(interactions)
      .where(and(eq(interactions.learnerId, id)))
      .orderBy(desc(interactions.id))
      .limit(limit);
    return rows.reverse().map((r) => ({
      eventId: r.eventId,
      role: r.role as InteractionRecord["role"],
      content: r.content,
      conceptId: r.conceptId ?? undefined,
      signals: r.signals,
      decision: r.decision,
      createdAt: r.createdAt,
    }));
  }
}

let pgStore: PgStore | null = null;
export function defaultStore(): TutorStore {
  if (!pgStore) pgStore = new PgStore();
  return pgStore;
}
