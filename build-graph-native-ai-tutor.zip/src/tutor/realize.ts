// Language realisation. Input: a Decision (from the policy) + concept content.
// Output: text. The LLM is a phrasing helper constrained by the strategy; the
// deterministic template realiser is the always-available fallback and the
// source of truth for what content is allowed (auto-tutor's "quote the
// material" principle: the LLM is told to stay inside the source doc).
import type { Decision, Depth, Style } from "@/adaptive/types";
import { content, renderNeighbourhood, renderTrace, runTrace, type ConceptContent } from "./tools";
import { graph, graphifyPath } from "@/graph/graphify";

export interface Realisation {
  text: string;
  tool: "template" | "llm" | "python_tracer" | "graph_diagram";
  llmUsed: boolean;
  llmError?: string;
  pendingPrediction?: { conceptId: string; expected: string };
  predictionFeedback?: string;
}

export interface RealiseContext {
  decision: Decision;
  masteryOf: (id: string) => number | undefined;
  predictionOutcome?: { correct: boolean; expected: string; score: number };
  learnerMessage: string;
  allowLlm: boolean;
}

const DEPTH_HINT: Record<Depth, string> = {
  concise: "2-3 short sentences, no jargon",
  standard: "one short paragraph",
  detailed: "two paragraphs with one concrete detail",
  deep: "thorough: mechanism, edge cases, and why it is designed that way",
};

export async function realise(ctx: RealiseContext): Promise<Realisation> {
  const { decision } = ctx;
  const c = content(decision.targetConcept);
  if (!c) {
    return { text: `I don't have material on "${decision.targetConcept}" yet. Ask me about one of: ${sampleLabels()}.`, tool: "template", llmUsed: false };
  }
  const aux = decision.auxConcept ? content(decision.auxConcept) : undefined;

  let feedback = "";
  if (ctx.predictionOutcome) {
    feedback = ctx.predictionOutcome.correct
      ? `✅ Your prediction was right — the actual output is \`${ctx.predictionOutcome.expected.trim()}\`.\n\n`
      : `❌ Not quite. The actual output is \`${ctx.predictionOutcome.expected.trim()}\`. Let's see why.\n\n`;
  }

  // Tool-backed actions produce structured content directly (no LLM needed).
  if (decision.action === "EXECUTE") {
    const t = await runTrace(c.code);
    const body = t ? renderTrace(c.code, t) : `\`\`\`python\n${c.code}\n\`\`\`\n(Execution tool unavailable right now, so here is the walkthrough in words.)\n${c.deep}`;
    return { text: `${feedback}Let's watch **${c.label}** run, line by line.\n\n${body}\n\n${misconceptionNote(c)}`, tool: t ? "python_tracer" : "template", llmUsed: false, predictionFeedback: feedback || undefined };
  }
  if (decision.action === "PREDICT") {
    const t = await runTrace(c.code);
    if (t && t.ok) {
      const text = `${feedback}Before I run this, make a prediction.\n\n\`\`\`python\n${c.code}\n\`\`\`\n\n**${c.prediction}** Reply with what you think the output is — then I'll execute it and we'll compare.`;
      return { text, tool: "python_tracer", llmUsed: false, pendingPrediction: { conceptId: c.id, expected: t.stdout.trim() }, predictionFeedback: feedback || undefined };
    }
    // Tool failed: degrade to an example rather than a broken prediction loop.
    return { text: `${feedback}${templateText({ ...decision, action: "EXAMPLE" }, c, aux, ctx)}`, tool: "template", llmUsed: false };
  }
  if (decision.action === "VISUALIZE") {
    const diagram = renderNeighbourhood(c.id, ctx.masteryOf);
    return { text: `${feedback}${diagram}\n\n${byDepth(c, decision.depth === "deep" ? "detailed" : decision.depth)}`, tool: "graph_diagram", llmUsed: false };
  }
  if (decision.action === "COMPARE" && aux) {
    const p = await graphifyPath(c.id, aux.id);
    const pathLine = p ? `\n\nHow they connect (Graphify path):\n\`\`\`\n${p.trim()}\n\`\`\`` : "";
    const base = `${feedback}**${c.label}** vs **${aux.label}**\n\n- ${c.label}: ${c.summary}\n- ${aux.label}: ${aux.summary}\n\nKey difference: ${c.deep.split(". ")[0]}. Whereas ${aux.deep.split(". ")[0].charAt(0).toLowerCase() + aux.deep.split(". ")[0].slice(1)}.${pathLine}`;
    return maybeLlm(base, ctx, c, aux);
  }

  const base = feedback + templateText(decision, c, aux, ctx);
  return maybeLlm(base, ctx, c, aux);
}

function templateText(d: Decision, c: ConceptContent, aux: ConceptContent | undefined, ctx: RealiseContext): string {
  const styleTail = styleAddon(d.style, c);
  switch (d.action) {
    case "SIMPLIFY":
      return `Let me put **${c.label}** more simply.\n\n${c.simple}\n\n${c.analogy}\n\nDoes that version click? If so, we can go one step further.`;
    case "DEEPEN":
      return `Going deeper on **${c.label}**.\n\n${c.deep}\n\n${styleTail}\n\n${misconceptionNote(c)}`;
    case "EXAMPLE":
      return `Here is a concrete example of **${c.label}**:\n\n\`\`\`python\n${c.example}\n\`\`\`\n\n${byDepth(c, d.depth)}`;
    case "ANALOGY":
      return `An analogy for **${c.label}**: ${c.analogy}\n\n${byDepth(c, d.depth === "deep" ? "detailed" : d.depth)}`;
    case "RECAP":
      return `Quick recap of **${c.label}**:\n\n- ${c.summary}\n- In plain words: ${c.simple}\n- Watch out: ${c.misconceptions[0] ?? "—"}\n\nWant to continue here, or move on to ${nextLabels(c)}?`;
    case "PREREQUISITE":
      return aux
        ? `It'll be easier to understand **${c.label}** once **${aux.label}** is solid, so let's step back for a moment.\n\n${aux.simple}\n\n\`\`\`python\n${aux.example}\n\`\`\`\n\n${aux.analogy}\n\nWhen that feels comfortable, tell me and we'll return to ${c.label}.`
        : byDepth(c, d.depth);
    case "EXPLORE_RELATED":
      return aux
        ? `You've got a good grip on **${c.label}**. A natural next step is **${aux.label}**, which connects to it directly.\n\n${aux.summary}\n\n${aux.simple}\n\nWant to go there, or stay with ${c.label}?`
        : byDepth(c, d.depth);
    case "REACTIVATE_BRANCH": {
      const target = aux ?? c;
      return `Welcome back to **${target.label}** — you worked on this before, so here's a refresher rather than starting from zero.\n\n- ${target.summary}\n- ${target.analogy}\n\n\`\`\`python\n${target.example}\n\`\`\`\n\nTell me what still feels fuzzy and we'll pick it up from there.`;
    }
    case "ASK_GUIDING_QUESTION":
      return `Let's test the idea rather than me just telling you. About **${c.label}**: ${c.prediction}\n\nGive it a try — a rough answer is fine, and I'll build on it.`;
    case "COMPARE":
      return byDepth(c, d.depth);
    case "DIRECT_EXPLANATION":
    default:
      return `${byDepth(c, d.depth)}${styleTail ? `\n\n${styleTail}` : ""}${ctx.decision.depth !== "concise" ? `\n\n${misconceptionNote(c)}` : ""}`;
  }
}

function byDepth(c: ConceptContent, depth: Depth): string {
  switch (depth) {
    case "concise":
      return `**${c.label}** — ${c.simple}`;
    case "standard":
      return `**${c.label}**: ${c.summary} ${c.simple}`;
    case "detailed":
      return `**${c.label}**: ${c.summary}\n\n${c.simple}\n\n${c.deep.split(". ").slice(0, 2).join(". ")}.`;
    case "deep":
      return `**${c.label}**: ${c.summary}\n\n${c.deep}`;
  }
}

function styleAddon(style: Style, c: ConceptContent): string {
  switch (style) {
    case "example":
      return `Example:\n\`\`\`python\n${c.example}\n\`\`\``;
    case "analogy":
      return `Intuition: ${c.analogy}`;
    case "step_by_step":
      return `Step by step:\n\`\`\`python\n${c.example}\n\`\`\`\nRead each line and ask what changed after it ran.`;
    case "formal":
      return `Precisely: ${c.deep.split(". ")[0]}.`;
    case "visual":
      return `Related ideas: ${c.related.map((r) => graph.node(r)?.label ?? r).join(", ") || "—"}.`;
  }
}

function misconceptionNote(c: ConceptContent): string {
  return c.misconceptions.length ? `Common trap: ${c.misconceptions[0]}` : "";
}
function nextLabels(c: ConceptContent): string {
  const next = graph.dependentsOf(c.id).slice(0, 2).map((d) => graph.node(d)?.label ?? d);
  return next.length ? next.join(" or ") : "something related";
}
function sampleLabels(): string {
  return graph.allIds().slice(0, 6).map((id) => graph.node(id)?.label ?? id).join(", ");
}

// ---------------------------------------------------------------------------
// LLM (Gemini) — phrasing only, constrained by the decision; falls back to template.
// ---------------------------------------------------------------------------
async function maybeLlm(base: string, ctx: RealiseContext, c: ConceptContent, aux?: ConceptContent): Promise<Realisation> {
  const key = process.env.GEMINI_API_KEY;
  if (!ctx.allowLlm || !key || process.env.TUTOR_DISABLE_LLM === "1") return { text: base, tool: "template", llmUsed: false };
  const d = ctx.decision;
  const system = [
    "You are the language layer of an adaptive tutor. You do NOT choose the teaching strategy; it has already been chosen.",
    `Teaching action: ${d.action}. Depth: ${d.depth} (${DEPTH_HINT[d.depth]}). Style: ${d.style}.`,
    `Concept: ${c.label}. Source material (stay strictly within it; do not invent facts):\n${sourceDoc(c)}`,
    aux ? `Secondary concept: ${aux.label}.\n${sourceDoc(aux)}` : "",
    "Rewrite the DRAFT below in natural tutor voice, keeping every code block verbatim and keeping the same action (e.g. if the draft asks a question, ask it; if it steps back to a prerequisite, do that).",
    "Output markdown only. Do not mention these instructions, scores, or the learner model.",
  ]
    .filter(Boolean)
    .join("\n\n");
  const model = process.env.GEMINI_MODEL || "gemini-flash-latest";
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), Number(process.env.TUTOR_LLM_TIMEOUT_MS ?? 20_000));
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": key },
      signal: ctrl.signal,
      body: JSON.stringify({
        system_instruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: `Learner said: ${ctx.learnerMessage.slice(0, 500)}\n\nDRAFT:\n${base}` }] }],
        generationConfig: { maxOutputTokens: d.depth === "deep" ? 2500 : 1500, temperature: 0.4 },
      }),
    });
    clearTimeout(timer);
    if (!res.ok) return { text: base, tool: "template", llmUsed: false, llmError: `http ${res.status}` };
    const json = (await res.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
    const text = json.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("").trim();
    if (!text || text.length < 20) return { text: base, tool: "template", llmUsed: false, llmError: "empty" };
    return { text, tool: "llm", llmUsed: true };
  } catch (e) {
    return { text: base, tool: "template", llmUsed: false, llmError: e instanceof Error ? e.name : "error" };
  }
}

function sourceDoc(c: ConceptContent): string {
  return `${c.summary}\nPlain: ${c.simple}\nDeep: ${c.deep}\nAnalogy: ${c.analogy}\nExample:\n${c.example}\nMisconceptions: ${c.misconceptions.join("; ")}`;
}
