// Persistence for the adaptive tutor.
//
// Ownership (see docs/ARCHITECTURE.md):
//   - Graph topology / concept identity  -> Graphify (graphify-out/graph.json). NOT stored here.
//   - learner_models   -> Adaptive core (preferences, affect, tendencies, short-term session context)
//   - concept_states   -> Adaptive core (per-learner overlay keyed by Graphify node ids)
//   - interactions     -> Application layer (append-only evidence log with idempotency key)
import {
  pgTable,
  text,
  timestamp,
  jsonb,
  real,
  integer,
  primaryKey,
  serial,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const learners = pgTable("learners", {
  id: text("id").primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const learnerModels = pgTable("learner_models", {
  learnerId: text("learner_id").primaryKey(),
  preferences: jsonb("preferences").notNull(),
  affect: jsonb("affect").notNull(),
  tendencies: jsonb("tendencies").notNull(),
  session: jsonb("session").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const conceptStates = pgTable(
  "concept_states",
  {
    learnerId: text("learner_id").notNull(),
    conceptId: text("concept_id").notNull(), // Graphify node id
    mastery: real("mastery").notNull(),
    confidence: real("confidence").notNull(),
    strength: real("strength").notNull(),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }).notNull(),
    interactionCount: integer("interaction_count").notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [primaryKey({ columns: [t.learnerId, t.conceptId] })],
);

export const interactions = pgTable(
  "interactions",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    eventId: text("event_id").notNull(),
    role: text("role").notNull(), // learner | tutor | signal
    content: text("content").notNull(),
    conceptId: text("concept_id"),
    signals: jsonb("signals"),
    decision: jsonb("decision"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("interactions_event_id_idx").on(t.learnerId, t.eventId)],
);
