// MCP Streamable HTTP endpoint (spec 2025-03-26+). Stateless: a fresh transport
// per request, as required by the SDK to avoid JSON-RPC id collisions.
import { WebStandardStreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js";
import { createTutorMcpServer } from "@/mcp/server";

export const dynamic = "force-dynamic";

async function handle(req: Request): Promise<Response> {
  const required = process.env.MCP_API_KEY;
  if (required) {
    const auth = req.headers.get("authorization") ?? "";
    const key = req.headers.get("x-api-key") ?? (auth.toLowerCase().startsWith("bearer ") ? auth.slice(7).trim() : "");
    if (key !== required) return Response.json({ error: "unauthorized" }, { status: 401 });
  }
  const server = createTutorMcpServer();
  const transport = new WebStandardStreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
  try {
    await server.connect(transport);
    return await transport.handleRequest(req);
  } catch (e) {
    console.error("[mcp] request failed", e instanceof Error ? e.message : e);
    return Response.json({ jsonrpc: "2.0", error: { code: -32603, message: "Internal server error" }, id: null }, { status: 500 });
  }
}

export const POST = handle;
export const GET = handle;
export const DELETE = handle;
