import { tutor } from "@/tutor/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  let body: { learnerId?: string; message?: string; eventId?: string };
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "invalid json" }, { status: 400 });
  }
  const learnerId = sanitizeId(body.learnerId);
  const message = (body.message ?? "").toString().trim();
  if (!learnerId || !message) return Response.json({ error: "learnerId and message are required" }, { status: 400 });
  try {
    const result = await tutor().handleTurn(learnerId, message, { eventId: body.eventId });
    return Response.json(result);
  } catch (e) {
    console.error("[chat] turn failed", e instanceof Error ? e.message : e);
    return Response.json({ error: "tutor unavailable" }, { status: 500 });
  }
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const learnerId = sanitizeId(url.searchParams.get("learnerId") ?? "");
  if (!learnerId) return Response.json({ error: "learnerId required" }, { status: 400 });
  try {
    const [state, history] = await Promise.all([tutor().snapshot(learnerId), tutor().history(learnerId, 40)]);
    return Response.json({ state, history: history.map((h) => ({ role: h.role, content: h.content, decision: h.decision ?? null, createdAt: h.createdAt })) });
  } catch (e) {
    console.error("[chat] state failed", e instanceof Error ? e.message : e);
    return Response.json({ error: "state unavailable" }, { status: 500 });
  }
}

function sanitizeId(v: unknown): string {
  return (typeof v === "string" ? v : "").replace(/[^a-zA-Z0-9_\-.]/g, "").slice(0, 64);
}
