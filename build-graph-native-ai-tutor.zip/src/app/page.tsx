"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type Msg = { role: "learner" | "tutor"; content: string; decision?: { action?: string; tool?: string; depth?: string; style?: string } | null };
type State = {
  focusLabel?: string;
  depth: string;
  style: string;
  lastAction?: string;
  pendingPrediction?: string;
  affect: { confusion: number; curiosity: number; engagement: number; fatigue: number };
  branches: { active: { label: string }[]; weak: { label: string }[]; dormant: { label: string }[] };
};

function getLearnerId(): string {
  if (typeof window === "undefined") return "";
  const k = "tutor-learner-id";
  let id = window.localStorage.getItem(k);
  if (!id) {
    id = "learner-" + Math.random().toString(36).slice(2, 10);
    window.localStorage.setItem(k, id);
  }
  return id;
}

export default function Home() {
  const [learnerId, setLearnerId] = useState("");
  const [messages, setMessages] = useState<Msg[]>([]);
  const [state, setState] = useState<State | null>(null);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [showWhy, setShowWhy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  const load = useCallback(async (id: string) => {
    const res = await fetch(`/api/chat?learnerId=${encodeURIComponent(id)}`);
    if (!res.ok) return;
    const data = await res.json();
    setState(data.state);
    setMessages(
      (data.history as Msg[]).filter((m) => m.role === "learner" || m.role === "tutor").map((m) => ({ role: m.role, content: m.content, decision: m.decision })),
    );
  }, []);

  useEffect(() => {
    const id = getLearnerId();
    setLearnerId(id);
    load(id);
  }, [load]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, busy]);

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    setBusy(true);
    setMessages((m) => [...m, { role: "learner", content: text }]);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ learnerId, message: text, eventId: crypto.randomUUID() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "failed");
      setMessages((m) => [...m, { role: "tutor", content: data.reply, decision: { ...data.trace.decision, tool: data.trace.tool } }]);
      setState(data.state);
    } catch (e) {
      setMessages((m) => [...m, { role: "tutor", content: `Sorry — something went wrong (${e instanceof Error ? e.message : "error"}). Try again.` }]);
    } finally {
      setBusy(false);
    }
  }

  function resetLearner() {
    const id = "learner-" + Math.random().toString(36).slice(2, 10);
    window.localStorage.setItem("tutor-learner-id", id);
    setLearnerId(id);
    setMessages([]);
    setState(null);
  }

  return (
    <main className="mx-auto flex h-dvh max-w-3xl flex-col bg-white text-zinc-900">
      <header className="flex items-center justify-between border-b border-zinc-200 px-4 py-3">
        <div>
          <h1 className="text-base font-semibold">Adaptive Tutor</h1>
          <p className="text-xs text-zinc-500">Graphify-backed · learns how you learn</p>
        </div>
        <div className="flex items-center gap-3 text-xs text-zinc-500">
          <label className="flex items-center gap-1">
            <input type="checkbox" checked={showWhy} onChange={(e) => setShowWhy(e.target.checked)} /> why
          </label>
          <button onClick={resetLearner} className="rounded border border-zinc-300 px-2 py-1 hover:bg-zinc-50" title="Start as a new learner">
            new learner
          </button>
        </div>
      </header>

      <section className="flex-1 space-y-4 overflow-y-auto px-4 py-4">
        {messages.length === 0 && (
          <div className="rounded-lg bg-zinc-50 p-4 text-sm text-zinc-600">
            Ask about Python fundamentals — e.g. <em>“how do lists work?”</em>, <em>“explain recursion”</em>, <em>“what’s the difference between a stack and a queue?”</em>. Then push back: ask for simpler, deeper, an example, a diagram, or a step-by-step run. The tutor adapts.
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={m.role === "learner" ? "flex justify-end" : "flex justify-start"}>
            <div className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2 text-sm leading-relaxed ${m.role === "learner" ? "bg-zinc-900 text-white" : "bg-zinc-100 text-zinc-900"}`}>
              {m.content}
              {showWhy && m.role === "tutor" && m.decision?.action && (
                <div className="mt-2 border-t border-zinc-200 pt-1 text-[11px] text-zinc-500">
                  {m.decision.action} · {m.decision.depth} · {m.decision.style} · {m.decision.tool}
                </div>
              )}
            </div>
          </div>
        ))}
        {busy && <div className="text-xs text-zinc-400">thinking…</div>}
        <div ref={endRef} />
      </section>

      {state && (
        <div className="flex flex-wrap gap-x-4 gap-y-1 border-t border-zinc-100 px-4 py-2 text-[11px] text-zinc-500">
          <span>Concept: <b className="text-zinc-700">{state.focusLabel ?? "—"}</b></span>
          <span>Depth: <b className="text-zinc-700">{state.depth}</b></span>
          <span>Style: <b className="text-zinc-700">{state.style.replace("_", " ")}</b></span>
          <span>State: <b className="text-zinc-700">{state.pendingPrediction ? "awaiting your prediction" : state.affect.confusion > 0.45 ? "confused" : state.affect.curiosity > 0.5 ? "curious" : state.affect.fatigue > 0.45 ? "tired" : "steady"}</b></span>
          <span>Branches: <b className="text-zinc-700">{state.branches.active.length} active</b>{state.branches.dormant.length ? ` · ${state.branches.dormant.length} dormant` : ""}</span>
        </div>
      )}

      <form
        className="flex gap-2 border-t border-zinc-200 px-4 py-3"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask something…"
          className="flex-1 rounded-lg border border-zinc-300 px-3 py-2 text-sm outline-none focus:border-zinc-500"
          disabled={busy || !learnerId}
        />
        <button type="submit" disabled={busy || !input.trim()} className="rounded-lg bg-zinc-900 px-4 py-2 text-sm text-white disabled:opacity-40">
          Send
        </button>
      </form>
    </main>
  );
}
