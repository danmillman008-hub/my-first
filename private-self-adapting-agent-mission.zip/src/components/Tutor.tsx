"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type Msg = { id: number; role: string; content: string; createdAt: string; meta?: { move?: string; strategy?: string; reasons?: string[]; probe?: unknown } | null };
type Belief = { id: number; kind: string; subject: string; scope: string; value: string; statement: string; confidence: number; effective: number; status: string; supportCount: number; contradictionCount: number; history: { at: string; event: string; note?: string }[] };
type Concept = { id: number; slug: string; label: string; domain: string; status: string; state: { pKnown: number; demonstratedCorrect: number; demonstratedIncorrect: number; claimed: string | null } | null };
type Obs = { id: number; kind: string; content: string; interpretation: string | null; createdAt: string; consolidated: boolean; context: { domain?: string } };
type State = {
  learner: { id: string; name: string; goals: { text: string; status: string }[] };
  provider: string;
  sessions: { id: string; startedAt: string; topics: string[]; turnCount: number }[];
  messages: Msg[];
  beliefs: Belief[];
  retiredBeliefs: Belief[];
  concepts: Concept[];
  observations: Obs[];
};

function renderMarkdown(text: string) {
  // Minimal, safe rendering: code fences, inline code, bold, line breaks.
  const parts = text.split(/(```[\s\S]*?```)/g);
  return parts.map((part, i) => {
    if (part.startsWith("```")) {
      const body = part.replace(/^```[a-z]*\n?/, "").replace(/```$/, "");
      return (
        <pre key={i} className="my-2 overflow-x-auto rounded-lg bg-slate-900 p-3 text-[13px] leading-relaxed text-slate-100">
          <code>{body}</code>
        </pre>
      );
    }
    const lines = part.split("\n");
    return (
      <span key={i}>
        {lines.map((line, j) => (
          <span key={j}>
            {line.split(/(`[^`]+`|\*\*[^*]+\*\*)/g).map((seg, k) => {
              if (seg.startsWith("`") && seg.endsWith("`")) return <code key={k} className="rounded bg-slate-200/70 px-1 py-0.5 text-[13px] text-slate-800">{seg.slice(1, -1)}</code>;
              if (seg.startsWith("**") && seg.endsWith("**")) return <strong key={k}>{seg.slice(2, -2)}</strong>;
              return <span key={k}>{seg}</span>;
            })}
            {j < lines.length - 1 && <br />}
          </span>
        ))}
      </span>
    );
  });
}

const STATUS_STYLE: Record<string, string> = {
  active: "bg-emerald-100 text-emerald-800",
  hypothesis: "bg-amber-100 text-amber-800",
  dormant: "bg-slate-200 text-slate-600",
  retired: "bg-rose-100 text-rose-700",
};

export default function Tutor() {
  const [state, setState] = useState<State | null>(null);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showTrace, setShowTrace] = useState(false);
  const [tab, setTab] = useState<"memory" | "graph" | "recent">("memory");
  const [name, setName] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const refresh = useCallback(async () => {
    const res = await fetch("/api/state", { cache: "no-store" });
    if (res.ok) setState(await res.json());
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [state?.messages.length, busy]);

  async function send(text?: string) {
    const t = (text ?? input).trim();
    if (!t || busy) return;
    setInput("");
    setBusy(true);
    setError(null);
    setState((s) => (s ? { ...s, messages: [...s.messages, { id: -Date.now(), role: "user", content: t, createdAt: new Date().toISOString() }] } : s));
    try {
      const res = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ text: t }) });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error ?? "Request failed");
      await refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setBusy(false);
      inputRef.current?.focus();
    }
  }

  async function saveName() {
    if (!name.trim()) return;
    await fetch("/api/learner", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: name.trim() }) });
    setName("");
    refresh();
  }

  async function startFresh() {
    if (!confirm("Start over as a brand-new learner? Your current memory stays in the database but won't be used.")) return;
    await fetch("/api/learner", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ reset: true }) });
    refresh();
  }

  const msgs = state?.messages ?? [];
  const beliefs = state?.beliefs ?? [];
  const concepts = state?.concepts ?? [];
  const domains = Array.from(new Set(concepts.map((c) => c.domain)));

  return (
    <div className="mx-auto grid min-h-screen max-w-7xl grid-cols-1 gap-6 px-4 py-6 lg:grid-cols-[1fr_380px]">
      {/* Conversation */}
      <section className="flex min-h-[80vh] flex-col rounded-2xl border border-slate-200 bg-white shadow-sm">
        <header className="flex items-center justify-between border-b border-slate-100 px-5 py-3">
          <div>
            <h1 className="text-base font-semibold text-slate-900">Your tutor</h1>
            <p className="text-xs text-slate-500">
              One continuous conversation · {state ? `${state.sessions.length} session${state.sessions.length === 1 ? "" : "s"}` : "…"} · engine: {state?.provider ?? "…"}
            </p>
          </div>
          <label className="flex items-center gap-2 text-xs text-slate-500">
            <input type="checkbox" checked={showTrace} onChange={(e) => setShowTrace(e.target.checked)} /> show reasoning
          </label>
        </header>

        <div className="flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {msgs.length === 0 && (
            <div className="rounded-xl bg-slate-50 p-5 text-sm text-slate-600">
              <p className="font-medium text-slate-800">Talk to me like a person who knows the subject.</p>
              <p className="mt-1">Say what you want to learn, ask why something works, paste code, disagree with me, change your mind — I&apos;ll adapt around you and remember what actually helps.</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {["I want to learn Bash", "Teach me Rust ownership", "What is recursion?", "I want to learn about photosynthesis"].map((s) => (
                  <button key={s} onClick={() => send(s)} className="rounded-full border border-slate-300 bg-white px-3 py-1 text-xs hover:bg-slate-100">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}
          {msgs.map((m) => (
            <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-[15px] leading-relaxed ${m.role === "user" ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-900"}`}>
                <div className="whitespace-pre-wrap [&_pre]:whitespace-pre">{renderMarkdown(m.content)}</div>
                {showTrace && m.role === "agent" && m.meta && (
                  <div className="mt-2 border-t border-slate-300/60 pt-2 text-[11px] text-slate-500">
                    <span className="font-mono">{m.meta.move}{m.meta.strategy ? ` · ${m.meta.strategy}` : ""}</span>
                    {m.meta.reasons?.length ? <div className="mt-1">{m.meta.reasons.join(" · ")}</div> : null}
                  </div>
                )}
              </div>
            </div>
          ))}
          {busy && (
            <div className="flex justify-start">
              <div className="rounded-2xl bg-slate-100 px-4 py-3 text-sm text-slate-500">thinking…</div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {error && <div className="mx-5 mb-2 rounded-lg bg-rose-50 px-3 py-2 text-xs text-rose-700">{error}</div>}
        <form
          className="flex items-end gap-2 border-t border-slate-100 p-3"
          onSubmit={(e) => {
            e.preventDefault();
            send();
          }}
        >
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            rows={2}
            placeholder="Ask, paste code, disagree, change topic… (Enter to send, Shift+Enter for newline)"
            className="flex-1 resize-none rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-indigo-400"
          />
          <button type="submit" disabled={busy || !input.trim()} className="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-40">
            Send
          </button>
        </form>
      </section>

      {/* Memory panel */}
      <aside className="space-y-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs uppercase tracking-wide text-slate-500">Learner</p>
              <p className="text-sm font-semibold text-slate-900">{state?.learner.name ?? "…"}</p>
            </div>
            <button onClick={startFresh} className="text-xs text-slate-400 hover:text-rose-600">start fresh</button>
          </div>
          <div className="mt-2 flex gap-2">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" className="flex-1 rounded-lg border border-slate-300 px-2 py-1 text-xs" />
            <button onClick={saveName} className="rounded-lg bg-slate-800 px-2 py-1 text-xs text-white">save</button>
          </div>
          {state?.learner.goals?.length ? (
            <ul className="mt-3 space-y-1 text-xs text-slate-600">
              {state.learner.goals.map((g, i) => (
                <li key={i}>🎯 {g.text.replace(/^Learner stated a goal: /, "").replace(/^"|"$/g, "")}</li>
              ))}
            </ul>
          ) : null}
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
          <div className="flex border-b border-slate-100 text-xs">
            {(["memory", "graph", "recent"] as const).map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`flex-1 px-3 py-2 capitalize ${tab === t ? "border-b-2 border-indigo-500 font-semibold text-slate-900" : "text-slate-500"}`}>
                {t === "memory" ? "What I've learned about you" : t === "graph" ? "Knowledge map" : "Recent observations"}
              </button>
            ))}
          </div>
          <div className="max-h-[70vh] overflow-y-auto p-4 text-sm">
            {tab === "memory" && (
              <div className="space-y-3">
                {beliefs.length === 0 && <p className="text-xs text-slate-500">Nothing durable yet. As we work together I&apos;ll form tentative hypotheses, confirm them through what actually helps you, and revise them when you change.</p>}
                {beliefs.map((b) => (
                  <div key={b.id} className="rounded-lg border border-slate-100 p-2">
                    <div className="flex items-center gap-2">
                      <span className={`rounded px-1.5 py-0.5 text-[10px] font-medium ${STATUS_STYLE[b.status] ?? ""}`}>{b.status}</span>
                      <span className="text-[10px] text-slate-400">{b.scope === "*" ? "in general" : b.scope.replace(/domain:|activity:/g, "").replace(/_/g, " ")}</span>
                      <span className="ml-auto text-[10px] text-slate-400">{Math.round(b.effective * 100)}%</span>
                    </div>
                    <p className="mt-1 text-xs text-slate-800">{b.statement}</p>
                    <div className="mt-1 h-1 w-full rounded bg-slate-100">
                      <div className="h-1 rounded bg-indigo-400" style={{ width: `${Math.round(b.effective * 100)}%` }} />
                    </div>
                    <p className="mt-1 text-[10px] text-slate-400">
                      {b.supportCount.toFixed(1)} for · {b.contradictionCount.toFixed(1)} against · {b.history.length} revisions
                    </p>
                  </div>
                ))}
                {state?.retiredBeliefs.length ? (
                  <details className="text-xs text-slate-500">
                    <summary className="cursor-pointer">Revised / retired beliefs ({state.retiredBeliefs.length})</summary>
                    <ul className="mt-1 space-y-1">
                      {state.retiredBeliefs.map((b) => (
                        <li key={b.id} className="line-through">{b.statement}</li>
                      ))}
                    </ul>
                  </details>
                ) : null}
              </div>
            )}
            {tab === "graph" && (
              <div className="space-y-4">
                {domains.length === 0 && <p className="text-xs text-slate-500">No concepts mapped yet. Name a topic and I&apos;ll research it and build a map as we go.</p>}
                {domains.map((d) => (
                  <div key={d}>
                    <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-500">{d.replace(/_/g, " ")}</p>
                    <ul className="space-y-1">
                      {concepts
                        .filter((c) => c.domain === d)
                        .map((c) => {
                          const pk = c.state?.pKnown ?? 0.2;
                          const ev = (c.state?.demonstratedCorrect ?? 0) + (c.state?.demonstratedIncorrect ?? 0);
                          return (
                            <li key={c.id} className="flex items-center gap-2 text-xs">
                              <div className="h-2 w-16 rounded bg-slate-100">
                                <div className={`h-2 rounded ${pk >= 0.7 ? "bg-emerald-400" : pk >= 0.4 ? "bg-amber-400" : "bg-slate-300"}`} style={{ width: `${Math.round(pk * 100)}%` }} />
                              </div>
                              <span className={`${c.status === "dormant" ? "text-slate-400" : "text-slate-800"}`}>{c.label}</span>
                              <span className="ml-auto text-[10px] text-slate-400">
                                {ev ? `${c.state?.demonstratedCorrect}✓ ${c.state?.demonstratedIncorrect}✗` : c.state?.claimed ? `claims ${c.state.claimed}` : c.status}
                              </span>
                            </li>
                          );
                        })}
                    </ul>
                  </div>
                ))}
                <p className="text-[10px] text-slate-400">Bars show evidence-based estimates of understanding — from what you demonstrate, not how often a topic comes up.</p>
              </div>
            )}
            {tab === "recent" && (
              <ul className="space-y-2">
                {(state?.observations ?? []).length === 0 && <p className="text-xs text-slate-500">Nothing observed yet.</p>}
                {(state?.observations ?? []).slice().reverse().map((o) => (
                  <li key={o.id} className="rounded-lg border border-slate-100 p-2 text-xs">
                    <span className="mr-1 rounded bg-slate-100 px-1 font-mono text-[10px] text-slate-600">{o.kind}</span>
                    <span className="text-slate-800">{o.content}</span>
                    {o.interpretation && <p className="mt-0.5 text-[11px] italic text-slate-500">maybe: {o.interpretation}</p>}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
        <p className="px-1 text-[11px] text-slate-400">
          Working memory keeps what happened; long-term beliefs form only from repeated evidence and stay revisable. <a className="underline" href="/lab">Lab results →</a>
        </p>
      </aside>
    </div>
  );
}
