/**
 * LLM provider abstraction.
 *
 * The agent works with or without a real model. When OPENAI_API_KEY (or an
 * OpenAI-compatible OPENAI_BASE_URL) or ANTHROPIC_API_KEY is present, the
 * real model handles perception, research and response generation. Otherwise
 * the offline engine (src/agent/offline.ts) provides the same capabilities
 * from curated domain packs, live Wikipedia research and adaptive templates.
 */

export type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

export interface LLM {
  name: string;
  complete(opts: { system?: string; messages: ChatMessage[]; maxTokens?: number; json?: boolean; temperature?: number }): Promise<string>;
}

const TIMEOUT_MS = 40_000;

async function fetchWithTimeout(url: string, init: RequestInit): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

class OpenAICompatible implements LLM {
  name: string;
  constructor(private apiKey: string, private baseUrl: string, private model: string) {
    this.name = `openai:${model}`;
  }
  async complete(opts: { system?: string; messages: ChatMessage[]; maxTokens?: number; json?: boolean; temperature?: number }) {
    const msgs: ChatMessage[] = [];
    if (opts.system) msgs.push({ role: "system", content: opts.system });
    msgs.push(...opts.messages);
    const body: Record<string, unknown> = {
      model: this.model,
      messages: msgs,
      max_tokens: opts.maxTokens ?? 900,
      temperature: opts.temperature ?? 0.6,
    };
    if (opts.json) body.response_format = { type: "json_object" };
    const res = await fetchWithTimeout(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${this.apiKey}` },
      body: JSON.stringify(body),
    });
    if (!res.ok) throw new Error(`LLM ${res.status}: ${(await res.text()).slice(0, 300)}`);
    const data = (await res.json()) as { choices: { message: { content: string } }[] };
    return data.choices?.[0]?.message?.content ?? "";
  }
}

class Anthropic implements LLM {
  name: string;
  constructor(private apiKey: string, private model: string) {
    this.name = `anthropic:${model}`;
  }
  async complete(opts: { system?: string; messages: ChatMessage[]; maxTokens?: number; json?: boolean; temperature?: number }) {
    const system = (opts.system ?? "") + (opts.json ? "\nRespond with a single valid JSON object and nothing else." : "");
    const res = await fetchWithTimeout("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": this.apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: this.model,
        max_tokens: opts.maxTokens ?? 900,
        temperature: opts.temperature ?? 0.6,
        system,
        messages: opts.messages.filter((m) => m.role !== "system"),
      }),
    });
    if (!res.ok) throw new Error(`LLM ${res.status}: ${(await res.text()).slice(0, 300)}`);
    const data = (await res.json()) as { content: { type: string; text?: string }[] };
    return data.content?.map((c) => c.text ?? "").join("") ?? "";
  }
}

let cached: LLM | null | undefined;

export function getLLM(): LLM | null {
  if (cached !== undefined) return cached;
  if (process.env.LEARNING_AGENT_OFFLINE === "1") return (cached = null);
  const openaiKey = process.env.OPENAI_API_KEY;
  const baseUrl = (process.env.OPENAI_BASE_URL ?? "https://api.openai.com/v1").replace(/\/$/, "");
  if (openaiKey) {
    cached = new OpenAICompatible(openaiKey, baseUrl, process.env.OPENAI_MODEL ?? "gpt-4o-mini");
    return cached;
  }
  const anthropicKey = process.env.ANTHROPIC_API_KEY;
  if (anthropicKey) {
    cached = new Anthropic(anthropicKey, process.env.ANTHROPIC_MODEL ?? "claude-sonnet-4-5");
    return cached;
  }
  cached = null;
  return cached;
}

/** Extract the first JSON object from a model response, tolerating code fences. */
export function parseJsonObject<T = Record<string, unknown>>(text: string): T | null {
  const cleaned = text.replace(/```json|```/g, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end < 0) return null;
  try {
    return JSON.parse(cleaned.slice(start, end + 1)) as T;
  } catch {
    return null;
  }
}
