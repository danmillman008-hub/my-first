import { db } from "@/db";
import {
  observations,
  beliefs,
  concepts,
  conceptEdges,
  conceptStates,
  learners,
  sessions,
  type ObsContext,
  type BeliefRevision,
  type KnowledgeEvidence,
  type GoalRecord,
} from "@/db/schema";
import { and, desc, eq, inArray, ne, sql } from "drizzle-orm";
import type { PerceivedObservation } from "@/agent/perceive";
import { ablation } from "@/lab/ablation";

export type BeliefRow = typeof beliefs.$inferSelect;
export type ObservationRow = typeof observations.$inferSelect;
export type ConceptRow = typeof concepts.$inferSelect;
export type StateRow = typeof conceptStates.$inferSelect;

export const STYLES = ["concrete_example", "concise", "step_by_step", "analogy", "detailed", "plain"] as const;
export type Style = (typeof STYLES)[number];

/* ------------------------------------------------------------------ */
/* Time helpers (the lab injects a simulated clock)                     */
/* ------------------------------------------------------------------ */
export type Clock = () => Date;
export const realClock: Clock = () => new Date();

export function daysBetween(a: Date, b: Date): number {
  return Math.abs(b.getTime() - a.getTime()) / 86_400_000;
}

/* ------------------------------------------------------------------ */
/* Confidence model                                                     */
/* ------------------------------------------------------------------ */

/** Beta-like confidence: contradictions weigh a little more than confirmations. */
export function rawConfidence(support: number, contradiction: number, prior = 1): number {
  const a = prior + support;
  const b = prior + contradiction * 1.5;
  return a / (a + b);
}

/**
 * Effective confidence at read time = stored confidence × recency factor.
 * Half-life 75 days, floor 0.35 so history remains a (weak) prior, never zero.
 * Nothing is destroyed here: this is influence management, not deletion.
 */
export function effectiveConfidence(b: BeliefRow, now: Date): number {
  const days = daysBetween(b.lastConfirmedAt, now);
  const recency = Math.max(0.35, Math.pow(0.5, days / 75));
  return b.confidence * recency;
}

export function scopeFor(ctx: ObsContext, level: "domain" | "activity" | "both" | "global"): string {
  if (level === "global") return "*";
  if (level === "domain") return ctx.domain ? `domain:${ctx.domain}` : "*";
  if (level === "activity") return ctx.activity ? `activity:${ctx.activity}` : "*";
  return ctx.domain && ctx.activity ? `domain:${ctx.domain}/activity:${ctx.activity}` : scopeFor(ctx, "domain");
}

/** How relevant is a belief scope to the current context? 0 = irrelevant. */
export function scopeRelevance(scope: string, ctx: ObsContext): number {
  if (scope === "*") return 0.6;
  const parts = scope.split("/");
  let score = 0;
  for (const p of parts) {
    const [k, v] = p.split(":");
    if (k === "domain") {
      if (v !== ctx.domain) return 0;
      score += 1;
    }
    if (k === "activity") {
      if (v !== ctx.activity) return 0;
      score += 0.6;
    }
  }
  return score;
}

/* ------------------------------------------------------------------ */
/* Working memory                                                       */
/* ------------------------------------------------------------------ */

export async function recordObservations(
  learnerId: string,
  sessionId: string,
  messageId: number | null,
  ctx: ObsContext,
  obs: PerceivedObservation[],
  now: Date,
): Promise<ObservationRow[]> {
  if (!obs.length) return [];
  return db
    .insert(observations)
    .values(
      obs.map((o) => ({
        learnerId,
        sessionId,
        messageId,
        kind: o.kind,
        content: o.content,
        interpretation: o.interpretation ?? null,
        context: ctx,
        payload: o.payload,
        strength: o.strength,
        createdAt: now,
      })),
    )
    .returning();
}

export async function getRecentObservations(learnerId: string, sessionId: string, limit = 40): Promise<ObservationRow[]> {
  const rows = await db
    .select()
    .from(observations)
    .where(eq(observations.learnerId, learnerId))
    .orderBy(desc(observations.id))
    .limit(limit);
  // Prefer current-session items but keep recent cross-session context
  return rows.sort((a, b) => a.id - b.id).filter((r, i, arr) => r.sessionId === sessionId || i >= arr.length - 15);
}

/* ------------------------------------------------------------------ */
/* Beliefs (long-term)                                                  */
/* ------------------------------------------------------------------ */

async function findBelief(learnerId: string, kind: string, subject: string, scope: string, value?: string): Promise<BeliefRow | undefined> {
  const conds = [eq(beliefs.learnerId, learnerId), eq(beliefs.kind, kind), eq(beliefs.subject, subject), eq(beliefs.scope, scope), ne(beliefs.status, "retired")];
  if (value) conds.push(eq(beliefs.value, value));
  const rows = await db.select().from(beliefs).where(and(...conds)).orderBy(desc(beliefs.confidence)).limit(1);
  return rows[0];
}

function pushHistory(b: BeliefRow, ev: BeliefRevision): BeliefRevision[] {
  return [...b.history, ev].slice(-40);
}

function recentTrend(b: BeliefRow): { contradictions: number; confirmations: number } {
  const recent = b.history.filter((h) => h.event === "confirmed" || h.event === "contradicted").slice(-4);
  return {
    contradictions: recent.filter((h) => h.event === "contradicted").length,
    confirmations: recent.filter((h) => h.event === "confirmed").length,
  };
}

function promotionStatus(b: { supportCount: number; contradictionCount: number; sessionsSeen: string[]; confidence: number; status: string }): string {
  if (b.status === "retired") return "retired";
  const crossSession = b.sessionsSeen.length >= 2;
  if ((b.supportCount >= 2 && crossSession && b.confidence >= 0.6) || (b.supportCount >= 4 && b.confidence >= 0.65)) return "active";
  return "hypothesis";
}

type EvidenceInput = {
  learnerId: string;
  sessionId: string;
  observationId: number;
  kind: string;
  subject: string;
  scope: string;
  value: string;
  statement: string;
  weight?: number; // 1 = normal; 0.5 = weak (self report / indirect)
  now: Date;
};

/** Confirm (or create) a belief with given value; contradict rival values on the same subject/scope. */
export async function upsertBeliefEvidence(e: EvidenceInput): Promise<BeliefRow> {
  const weight = e.weight ?? 1;
  const existing = await findBelief(e.learnerId, e.kind, e.subject, e.scope, e.value);
  let row: BeliefRow;
  if (existing) {
    // Avoid double counting the same observation
    if (existing.evidenceIds.includes(e.observationId)) return existing;
    const supportCount = existing.supportCount + weight;
    const confidence = rawConfidence(supportCount, existing.contradictionCount);
    const sessionsSeen = existing.sessionsSeen.includes(e.sessionId) ? existing.sessionsSeen : [...existing.sessionsSeen, e.sessionId];
    const wasDormant = existing.status === "dormant";
    const draft = { ...existing, supportCount, confidence, sessionsSeen };
    const status = promotionStatus({ ...draft, status: existing.status === "dormant" ? "hypothesis" : existing.status });
    const history = pushHistory(existing, { at: e.now.toISOString(), event: "confirmed", confidence });
    if (wasDormant) history.push({ at: e.now.toISOString(), event: "reactivated", confidence });
    if (status === "active" && existing.status !== "active") history.push({ at: e.now.toISOString(), event: "promoted", confidence });
    const [updated] = await db
      .update(beliefs)
      .set({
        supportCount,
        confidence,
        sessionsSeen,
        status,
        history,
        evidenceIds: [...existing.evidenceIds, e.observationId].slice(-60),
        lastConfirmedAt: e.now,
      })
      .where(eq(beliefs.id, existing.id))
      .returning();
    row = updated;
  } else {
    const confidence = rawConfidence(weight, 0);
    const [created] = await db
      .insert(beliefs)
      .values({
        learnerId: e.learnerId,
        kind: e.kind,
        subject: e.subject,
        scope: e.scope,
        value: e.value,
        statement: e.statement,
        confidence,
        supportCount: weight,
        status: "hypothesis",
        evidenceIds: [e.observationId],
        sessionsSeen: [e.sessionId],
        history: [{ at: e.now.toISOString(), event: "created", confidence }],
        firstSeenAt: e.now,
        lastConfirmedAt: e.now,
      })
      .returning();
    row = created;
  }

  // Rival values on same subject/scope are contradicted (single-valued subjects only)
  if (e.kind === "preference") {
    const rivals = await db
      .select()
      .from(beliefs)
      .where(and(eq(beliefs.learnerId, e.learnerId), eq(beliefs.kind, e.kind), eq(beliefs.subject, e.subject), eq(beliefs.scope, e.scope), ne(beliefs.value, e.value), ne(beliefs.status, "retired")));
    for (const r of rivals) await contradictBelief(r, e.observationId, e.now, weight, row.id, e.value);
  }
  return row;
}

async function contradictBelief(b: BeliefRow, observationId: number, now: Date, weight: number, rivalId: number, rivalValue: string) {
  if (b.evidenceIds.includes(observationId)) return;
  const contradictionCount = b.contradictionCount + weight;
  const confidence = rawConfidence(b.supportCount, contradictionCount);
  const history = pushHistory(b, { at: now.toISOString(), event: "contradicted", confidence, note: `evidence for '${rivalValue}'` });
  const trend = recentTrend({ ...b, history });
  let status = b.status;
  let supersededBy: number | null = null;
  let invalidatedAt: Date | null = null;
  // The learner in the present outranks stale memory: if recent evidence consistently
  // points the other way, retire (not delete) this belief and point to its successor.
  if (trend.contradictions >= 3 && trend.confirmations === 0) {
    status = "retired";
    supersededBy = rivalId;
    invalidatedAt = now;
    history.push({ at: now.toISOString(), event: "retired", confidence, note: `superseded by belief ${rivalId} ('${rivalValue}')` });
  } else if (status === "active" && confidence < 0.5) {
    status = "hypothesis";
    history.push({ at: now.toISOString(), event: "demoted", confidence });
  }
  await db
    .update(beliefs)
    .set({ contradictionCount, confidence, status, history, supersededBy, invalidatedAt, lastContradictedAt: now, evidenceIds: [...b.evidenceIds, observationId].slice(-60) })
    .where(eq(beliefs.id, b.id));
}

/** Read-time dormancy: mark long-unconfirmed active beliefs dormant (reversible). */
export async function applyDormancy(learnerId: string, now: Date) {
  const rows = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, learnerId), inArray(beliefs.status, ["active", "hypothesis"])));
  for (const b of rows) {
    if (daysBetween(b.lastConfirmedAt, now) > 120) {
      await db
        .update(beliefs)
        .set({ status: "dormant", history: pushHistory(b, { at: now.toISOString(), event: "demoted", confidence: b.confidence, note: "dormant: no confirmation for 120+ days" }) })
        .where(eq(beliefs.id, b.id));
    }
  }
}

/* ------------------------------------------------------------------ */
/* Knowledge state (BKT-style, evidence driven)                          */
/* ------------------------------------------------------------------ */

const BKT = { init: 0.2, learn: 0.18, guess: 0.2, slip: 0.15 };

export async function getState(learnerId: string, slug: string): Promise<StateRow> {
  const rows = await db.select().from(conceptStates).where(and(eq(conceptStates.learnerId, learnerId), eq(conceptStates.slug, slug))).limit(1);
  if (rows[0]) return rows[0];
  const [created] = await db.insert(conceptStates).values({ learnerId, slug, pKnown: BKT.init }).returning();
  return created;
}

export async function updateKnowledge(learnerId: string, slug: string, ev: KnowledgeEvidence, now: Date): Promise<StateRow> {
  const s = await getState(learnerId, slug);
  let p = s.pKnown;
  if (ev.kind === "self_report") {
    // Claims shift the prior only mildly and are kept separate from demonstration
    p = ev.correct ? Math.max(p, Math.min(0.45, p + 0.15)) : Math.min(p, 0.3);
    const [u] = await db
      .update(conceptStates)
      .set({ pKnown: p, claimed: ev.correct ? "knows" : "does_not_know", claimedAt: now, evidence: [...s.evidence, ev].slice(-30) })
      .where(eq(conceptStates.id, s.id))
      .returning();
    return u;
  }
  // Bayesian update on observed correctness
  const pCorrect = p * (1 - BKT.slip) + (1 - p) * BKT.guess;
  const post = ev.correct ? (p * (1 - BKT.slip)) / pCorrect : (p * BKT.slip) / (1 - pCorrect);
  p = post + (1 - post) * BKT.learn * 0.5; // small learning from the attempt itself
  const [u] = await db
    .update(conceptStates)
    .set({
      pKnown: Math.min(0.98, Math.max(0.02, p)),
      demonstratedCorrect: s.demonstratedCorrect + (ev.correct ? 1 : 0),
      demonstratedIncorrect: s.demonstratedIncorrect + (ev.correct ? 0 : 1),
      evidence: [...s.evidence, ev].slice(-30),
      lastEvidenceAt: now,
    })
    .where(eq(conceptStates.id, s.id))
    .returning();
  return u;
}

/** Exposure is not mastery: explanations alone can never push p_known past 0.45. */
export async function markExplained(learnerId: string, slug: string, now: Date) {
  const s = await getState(learnerId, slug);
  const p = s.pKnown < 0.45 ? Math.min(0.45, s.pKnown + (1 - s.pKnown) * BKT.learn) : s.pKnown;
  await db.update(conceptStates).set({ pKnown: p, lastExplainedAt: now }).where(eq(conceptStates.id, s.id));
}

/** A positive reaction ("got it") is weak evidence: it can lift p_known to at most 0.6 without a demonstration. */
export async function noteReaction(learnerId: string, slug: string, positive: boolean, now: Date) {
  const s = await getState(learnerId, slug);
  let p = s.pKnown;
  if (positive) p = s.demonstratedCorrect > 0 ? Math.min(0.95, p + (1 - p) * 0.1) : Math.min(0.6, p + (1 - p) * 0.25);
  else p = Math.max(0.05, p - 0.12);
  await db.update(conceptStates).set({ pKnown: p, lastEvidenceAt: s.lastEvidenceAt ?? null }).where(eq(conceptStates.id, s.id));
  void now;
}

/* ------------------------------------------------------------------ */
/* Graph helpers                                                        */
/* ------------------------------------------------------------------ */

export async function touchConcept(learnerId: string, slug: string, domain: string, label: string, now: Date, origin = "conversation") {
  const rows = await db.select().from(concepts).where(and(eq(concepts.learnerId, learnerId), eq(concepts.slug, slug))).limit(1);
  if (rows[0]) {
    await db
      .update(concepts)
      .set({ touchCount: rows[0].touchCount + 1, lastTouchedAt: now, status: rows[0].status === "dormant" ? "active" : rows[0].status })
      .where(eq(concepts.id, rows[0].id));
  } else {
    await db.insert(concepts).values({ learnerId, slug, label, domain, status: "emerging", origin, touchCount: 1, createdAt: now, lastTouchedAt: now });
  }
}

export async function reinforceEdge(learnerId: string, from: string, to: string, relation: string, delta = 0.1, origin = "conversation") {
  const rows = await db
    .select()
    .from(conceptEdges)
    .where(and(eq(conceptEdges.learnerId, learnerId), eq(conceptEdges.fromSlug, from), eq(conceptEdges.toSlug, to), eq(conceptEdges.relation, relation)))
    .limit(1);
  if (rows[0]) {
    await db
      .update(conceptEdges)
      .set({ weight: Math.min(1, rows[0].weight + delta), evidenceCount: rows[0].evidenceCount + 1 })
      .where(eq(conceptEdges.id, rows[0].id));
  } else {
    await db.insert(conceptEdges).values({ learnerId, fromSlug: from, toSlug: to, relation, weight: 0.3 + delta, evidenceCount: 1, origin });
  }
}

/** Concepts untouched for a long time go dormant (reactivated automatically when touched). */
export async function applyConceptDormancy(learnerId: string, now: Date) {
  const rows = await db.select().from(concepts).where(and(eq(concepts.learnerId, learnerId), eq(concepts.status, "active")));
  for (const c of rows) {
    if (daysBetween(c.lastTouchedAt, now) > 90) await db.update(concepts).set({ status: "dormant" }).where(eq(concepts.id, c.id));
  }
}

/* ------------------------------------------------------------------ */
/* Consolidation: working memory → long-term structure                   */
/* ------------------------------------------------------------------ */

const STYLE_LABEL: Record<string, string> = {
  concrete_example: "concrete examples",
  concise: "concise, direct answers",
  step_by_step: "step-by-step walkthroughs",
  analogy: "analogies and intuition first",
  detailed: "detailed explanations with the why",
  plain: "plain-language explanations",
};

export async function consolidate(learnerId: string, sessionId: string, now: Date): Promise<{ processed: number }> {
  const pending = await db
    .select()
    .from(observations)
    .where(and(eq(observations.learnerId, learnerId), eq(observations.consolidated, false)))
    .orderBy(observations.id)
    .limit(60);
  for (const o of pending) {
    const ctx = o.context;
    const p = o.payload as Record<string, unknown>;
    const signal = p.signal as string | undefined;
    const domainScope = scopeFor(ctx, "domain");
    const activityScope = scopeFor(ctx, "activity");

    if (o.kind === "goal") {
      // Stated goals are facts about intent, not hypotheses.
      const [l] = await db.select().from(learners).where(eq(learners.id, learnerId)).limit(1);
      if (l) {
        const text = String(p.text ?? o.content);
        const goals: GoalRecord[] = l.goals.some((g) => g.text === text) ? l.goals : [...l.goals, { text, domain: ctx.domain, statedAt: now.toISOString(), status: "active" }];
        await db.update(learners).set({ goals }).where(eq(learners.id, learnerId));
      }
    }

    if (signal === "stated_preference" && typeof p.style === "string") {
      // Self-report: real evidence, moderate weight, scoped to the context it was said in AND globally (weaker)
      const style = p.style;
      await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "preference", subject: "explanation_style", scope: domainScope, value: style, statement: `Prefers ${STYLE_LABEL[style] ?? style}${ctx.domain ? ` when working on ${ctx.domain.replace(/_/g, " ")}` : ""} (self-reported)`, weight: 1, now });
      if (domainScope !== "*") await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "preference", subject: "explanation_style", scope: "*", value: style, statement: `Prefers ${STYLE_LABEL[style] ?? style} (self-reported)`, weight: 0.5, now });
    }

    if (["wants_example", "wants_steps", "wants_concise", "wants_analogy", "wants_simpler", "wants_detail"].includes(signal ?? "") && typeof p.style === "string") {
      // A request is behavioral evidence for a style *in this context*; only a weak hint globally.
      const style = p.style === "plain" ? "plain" : p.style;
      await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "preference", subject: "explanation_style", scope: domainScope, value: style, statement: `Tends to ask for ${STYLE_LABEL[style] ?? style}${ctx.domain ? ` in ${ctx.domain.replace(/_/g, " ")}` : ""}`, weight: 1, now });
      if (domainScope !== "*") await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "preference", subject: "explanation_style", scope: "*", value: style, statement: `Tends to ask for ${STYLE_LABEL[style] ?? style}`, weight: 0.4, now });
      if (ctx.activity) await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "preference", subject: "explanation_style", scope: activityScope, value: style, statement: `Asks for ${STYLE_LABEL[style] ?? style} while ${ctx.activity}`, weight: 0.6, now });
    }

    if ((signal === "explanation_landed" || signal === "explanation_failed") && ctx.concept) {
      await noteReaction(learnerId, ctx.concept, signal === "explanation_landed", now);
    }
    if ((signal === "explanation_landed" || signal === "explanation_failed") && typeof (p.strategy ?? ctx.strategy) === "string") {
      const strategy = String(p.strategy ?? ctx.strategy);
      const worked = signal === "explanation_landed";
      // Strategy effectiveness tallies, scoped to the domain (outcome evidence, stronger than requests)
      const subject = `strategy:${strategy}`;
      const stmt = `${STYLE_LABEL[strategy] ?? strategy} ${worked ? "tend to work" : "tend not to work"}${ctx.domain ? ` for ${ctx.domain.replace(/_/g, " ")}` : ""}`;
      if (worked) {
        await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "strategy", subject, scope: domainScope, value: "works", statement: stmt, weight: 1, now });
      } else {
        const b = await findBelief(learnerId, "strategy", subject, domainScope, "works");
        if (b) await contradictBelief(b, o.id, now, 1, b.id, "did not land");
        else
          await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "strategy", subject, scope: domainScope, value: "fails", statement: stmt, weight: 1, now });
      }
    }

    if (o.kind === "attempt" && typeof p.concept === "string") {
      const correct = p.correct === true;
      await updateKnowledge(learnerId, p.concept, { at: now.toISOString(), kind: (p.kind as KnowledgeEvidence["kind"]) ?? "answer", correct, strategy: ctx.strategy, observationId: o.id }, now);
      // An attempt right after an explanation is outcome evidence for that strategy
      if (ctx.strategy) {
        const subject = `strategy:${ctx.strategy}`;
        if (correct) await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "strategy", subject, scope: domainScope, value: "works", statement: `${STYLE_LABEL[ctx.strategy] ?? ctx.strategy} tend to work for ${ctx.domain?.replace(/_/g, " ") ?? "this"}`, weight: 1.2, now });
        else {
          const b = await findBelief(learnerId, "strategy", subject, domainScope, "works");
          if (b) await contradictBelief(b, o.id, now, 0.8, b.id, "incorrect attempt after explanation");
        }
      }
      // Claim-vs-behavior: a claim of knowing followed by failure is worth remembering as a pattern
      const st = await getState(learnerId, p.concept);
      if (!correct && st.claimed === "knows") {
        await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "pattern", subject: "self_assessment", scope: domainScope, value: "overestimates", statement: `Self-assessment has run ahead of demonstrated ability${ctx.domain ? ` in ${ctx.domain.replace(/_/g, " ")}` : ""}; verify gently before building on claimed knowledge`, weight: 1, now });
      }
      if (correct && st.claimed === "does_not_know") {
        await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "pattern", subject: "self_assessment", scope: domainScope, value: "underestimates", statement: `Tends to underestimate own understanding${ctx.domain ? ` in ${ctx.domain.replace(/_/g, " ")}` : ""}; encouragement and evidence of success help`, weight: 1, now });
      }
    }

    if (signal === "claims_known" && ctx.concept) {
      await updateKnowledge(learnerId, ctx.concept, { at: now.toISOString(), kind: "self_report", correct: true, observationId: o.id }, now);
    }

    if (signal === "asks_why") {
      await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "pattern", subject: "curiosity", scope: domainScope, value: "mechanism", statement: `Wants to understand why things work, not just recipes${ctx.domain ? ` (${ctx.domain.replace(/_/g, " ")})` : ""}`, weight: 0.7, now });
    }
    if (signal === "wants_practice") {
      await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "pattern", subject: "practice", scope: domainScope, value: "wants_practice", statement: `Likes to practice actively${ctx.domain ? ` in ${ctx.domain.replace(/_/g, " ")}` : ""}`, weight: 0.8, now });
    }
    if (signal === "disagreement") {
      await upsertBeliefEvidence({ learnerId, sessionId, observationId: o.id, kind: "pattern", subject: "engagement", scope: "*", value: "critical", statement: "Engages critically and pushes back; welcomes being checked rather than reassured", weight: 0.6, now });
    }

    await db.update(observations).set({ consolidated: true }).where(eq(observations.id, o.id));
  }
  return { processed: pending.length };
}

/** A claimed-known prerequisite turned out to be the weak link: claim-vs-behaviour evidence. */
export async function noteClaimBehaviorGap(learnerId: string, sessionId: string, observationId: number, ctx: ObsContext, now: Date) {
  await upsertBeliefEvidence({ learnerId, sessionId, observationId, kind: "pattern", subject: "self_assessment", scope: scopeFor(ctx, "domain"), value: "overestimates", statement: `Self-assessment has run ahead of demonstrated ability${ctx.domain ? ` in ${ctx.domain.replace(/_/g, " ")}` : ""}; verify gently before building on claimed knowledge`, weight: 1, now });
}

/* ------------------------------------------------------------------ */
/* Context pack: what the agent sees                                    */
/* ------------------------------------------------------------------ */

export type ScoredBelief = BeliefRow & { effective: number; relevance: number };

export type ContextPack = {
  learner: typeof learners.$inferSelect;
  goals: GoalRecord[];
  beliefs: ScoredBelief[];
  recentObservations: ObservationRow[];
  domainConcepts: ConceptRow[];
  states: Map<string, StateRow>;
  edges: (typeof conceptEdges.$inferSelect)[];
  lastSession: typeof sessions.$inferSelect | null;
  gapDays: number;
  sessionCount: number;
};

export async function buildContext(learnerId: string, sessionId: string, ctx: ObsContext, now: Date): Promise<ContextPack> {
  const [learner] = await db.select().from(learners).where(eq(learners.id, learnerId)).limit(1);
  const allBeliefs = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, learnerId), ne(beliefs.status, "retired")));
  const scored: ScoredBelief[] = allBeliefs
    .map((b) => {
      const relevance = scopeRelevance(b.scope, ctx);
      const eff = effectiveConfidence(b, now) * (b.status === "dormant" ? 0.5 : 1);
      return { ...b, effective: eff, relevance };
    })
    .filter((b) => b.relevance > 0)
    .filter((b) => (ablation() === "no_ltm" ? false : ablation() === "stm_only" ? b.sessionsSeen.includes(sessionId) && b.sessionsSeen.length === 1 : true))
    .sort((a, b) => b.effective * b.relevance - a.effective * a.relevance);
  const recentObservations = await getRecentObservations(learnerId, sessionId);
  const domainConcepts = ctx.domain ? await db.select().from(concepts).where(and(eq(concepts.learnerId, learnerId), eq(concepts.domain, ctx.domain))) : [];
  const slugs = domainConcepts.map((c) => c.slug);
  const stateRows = slugs.length ? await db.select().from(conceptStates).where(and(eq(conceptStates.learnerId, learnerId), inArray(conceptStates.slug, slugs))) : [];
  const states = new Map(stateRows.map((s) => [s.slug, s]));
  const edges = slugs.length ? await db.select().from(conceptEdges).where(and(eq(conceptEdges.learnerId, learnerId), inArray(conceptEdges.toSlug, slugs))) : [];
  const prev = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.learnerId, learnerId), ne(sessions.id, sessionId)))
    .orderBy(desc(sessions.lastActiveAt))
    .limit(1);
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(sessions).where(eq(sessions.learnerId, learnerId));
  return {
    learner,
    goals: learner?.goals ?? [],
    beliefs: scored,
    recentObservations,
    domainConcepts,
    states,
    edges,
    lastSession: prev[0] ?? null,
    gapDays: prev[0] ? daysBetween(prev[0].lastActiveAt, now) : 0,
    sessionCount: count,
  };
}
