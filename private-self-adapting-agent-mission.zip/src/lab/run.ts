import { runExperiment } from "./simulate";
import { writeFileSync, mkdirSync } from "node:fs";
import type { Ablation } from "./ablation";

const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, "").split("=")));
const ablation = (args.ablation ?? "none") as Ablation;
const seeds = (args.seeds ?? "1,2").split(",").map(Number);
const sessions = Number(args.sessions ?? 6);
const turns = Number(args.turns ?? 8);
const archetypes = args.archetypes ? args.archetypes.split(",") : undefined;
const name = args.name ?? `lab_${ablation}`;

(async () => {
  const t0 = Date.now();
  const { summary, reports, transcripts } = await runExperiment({ name, ablation, seeds, sessions, turns, archetypes });
  mkdirSync("lab-results", { recursive: true });
  writeFileSync(`lab-results/${name}.json`, JSON.stringify({ summary, reports }, null, 2));
  writeFileSync(`lab-results/${name}.transcripts.txt`, Object.entries(transcripts).map(([k, v]) => `=== ${k} ===\n${v.join("\n")}`).join("\n\n"));
  console.log(JSON.stringify(summary, null, 2));
  console.log(`per-archetype:`);
  for (const r of reports) console.log(`${r.archetype.padEnd(24)} seed? match ${r.styleMatchEarly}→${r.styleMatchLate} landed ${r.landedRate}→${r.lateLandedRate} mastered ${r.conceptsMastered} probes ${r.probes}/${r.turns} prefAcc ${r.prefBeliefAccuracy} false ${r.falseActivePrefBeliefs} brier ${r.brier} over ${r.overconfidenceDetected} drift ${r.driftLag} beliefs ${r.beliefs}/${r.activeBeliefs}`);
  console.log(`elapsed ${(Date.now() - t0) / 1000}s`);
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
