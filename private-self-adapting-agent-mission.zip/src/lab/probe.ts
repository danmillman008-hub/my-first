import { runTurn } from "@/agent/run";

const id = `probe_${Date.now().toString(36)}`;
let now = new Date("2026-03-01T10:00:00Z");
async function say(text: string, gapMin = 2) {
  now = new Date(now.getTime() + gapMin * 60_000);
  const r = await runTurn({ learnerId: id, text, now });
  console.log(`\n\x1b[36mUSER:\x1b[0m ${text}`);
  console.log(`\x1b[33mAGENT [${r.trace.move}${r.trace.strategy ? "/" + r.trace.strategy : ""}]:\x1b[0m ${r.reply}`);
  console.log(`\x1b[90m  · ${r.trace.reasons.join(" · ")}\x1b[0m`);
}
(async () => {
  await say("I want to learn Bash");
  await say("Why does this work?");
  await say("here's my script:\n```bash\nfor f in $(ls *.txt); do\n  cp $f backup/\ndone\n```");
  await say("Actually, let's talk about OOP");
  await say("What is the capital of Portugal?");
  await say("That's wrong, a class is an object too");
  await say("next", 60 * 24 * 7);
  await say("I prefer short answers");
  await say("next");
  await say("I already know inheritance");
  await say("it means a subclass reuses the parent's code, is-a relationship, Liskov substitution matters");
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
