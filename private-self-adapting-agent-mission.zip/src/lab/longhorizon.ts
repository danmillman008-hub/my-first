import { runExperiment, ARCHETYPES } from "./simulate";
import { db } from "@/db";
import { beliefs, concepts, observations } from "@/db/schema";
import { eq } from "drizzle-orm";
(async () => {
  // 15 sessions with long, irregular gaps for a multi-domain learner
  const a = ARCHETYPES.find((x) => x.name === "context_split")!;
  a.gapDays = [1, 2, 7, 1, 30, 1, 1, 60, 1, 3, 1, 120, 1, 1];
  const { summary, reports } = await runExperiment({ name: "long_horizon", ablation: "none", seeds: [7], sessions: 15, turns: 8, archetypes: ["context_split"] });
  console.log(JSON.stringify(summary));
  const id = reports[0].learnerId;
  const bel = await db.select().from(beliefs).where(eq(beliefs.learnerId, id));
  const byStatus: Record<string, number> = {};
  for (const b of bel) byStatus[b.status] = (byStatus[b.status] ?? 0) + 1;
  const cons = await db.select().from(concepts).where(eq(concepts.learnerId, id));
  const obs = await db.select({ id: observations.id }).from(observations).where(eq(observations.learnerId, id));
  console.log("beliefs by status:", byStatus, "concepts:", cons.length, "dormant concepts:", cons.filter((c) => c.status === "dormant").length, "observations:", obs.length);
  console.log("reactivations:", bel.filter((b) => b.history.some((h) => h.event === "reactivated")).length, "narrow/retired:", bel.filter((b) => b.status === "retired").length);
  for (const b of bel.filter((b) => b.kind === "preference" && b.scope.startsWith("domain:"))) console.log(` ${b.status.padEnd(10)} ${b.scope.padEnd(12)} ${b.value.padEnd(17)} conf ${b.confidence.toFixed(2)} +${b.supportCount} -${b.contradictionCount} sessions ${b.sessionsSeen.length}`);
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
