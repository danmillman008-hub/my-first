import { runTurn } from "@/agent/run";
import { db } from "@/db";
import { beliefs, concepts } from "@/db/schema";
import { eq } from "drizzle-orm";
const id = `probe2_${Date.now().toString(36)}`;
let now = new Date("2026-03-01T10:00:00Z");
async function say(text: string, gapMin = 2) {
  now = new Date(now.getTime() + gapMin * 60_000);
  const r = await runTurn({ learnerId: id, text, now });
  console.log(`\nUSER: ${text}\nAGENT [${r.trace.move}${r.trace.strategy ? "/" + r.trace.strategy : ""}]: ${r.reply.slice(0, 600)}`);
}
(async () => {
  await say("I want to learn about photosynthesis");
  await say("why does this work?");
  await say("next");
  await say("Teach me Rust ownership");
  await say("I learn best from examples");
  await say("next");
  await say("give me an exercise");
  await say("no, exclusive access, you can't alias a mutable borrow");
  const cons = await db.select().from(concepts).where(eq(concepts.learnerId, id));
  console.log("\nconcepts:", cons.map((c) => `${c.domain}/${c.slug}(${c.origin})`).join(", "));
  const bel = await db.select().from(beliefs).where(eq(beliefs.learnerId, id));
  console.log("beliefs:", bel.map((b) => `[${b.status} ${b.scope}] ${b.statement} (${b.confidence.toFixed(2)})`).join("\n  "));
  // drift check on lab data
  const retired = await db.execute(`select learner_id, scope, value, status, superseded_by, history from beliefs where status='retired' and learner_id like 'sim_abl_none%drifter%' limit 3`);
  console.log("\nretired (drifter):", JSON.stringify(retired.rows.map((r) => ({ scope: r.scope, value: r.value, superseded_by: r.superseded_by, events: (r.history as {event:string}[]).map((h) => h.event).join(">") })), null, 0));
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
