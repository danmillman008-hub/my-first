/**
 * Ablation switches for counterfactual evaluation. Read once per process.
 *   LA_ABLATION=none | no_ltm | no_adapt | no_probe | stm_only
 */
export type Ablation = "none" | "no_ltm" | "no_adapt" | "no_probe" | "stm_only";

let current: Ablation | null = null;
export function ablation(): Ablation {
  if (current) return current;
  const v = (process.env.LA_ABLATION ?? "none") as Ablation;
  current = ["none", "no_ltm", "no_adapt", "no_probe", "stm_only"].includes(v) ? v : "none";
  return current;
}
export function setAblation(a: Ablation) {
  current = a;
}
