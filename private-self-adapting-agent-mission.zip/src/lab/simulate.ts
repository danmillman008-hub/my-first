/**
 * Synthetic-learner laboratory.
 *
 * Learners have HIDDEN traits the agent never sees. They react to what the
 * agent actually does (explanations land or not depending on style fit,
 * checks are answered according to hidden mastery). Metrics compare the
 * agent's behaviour and internal model against the hidden truth.
 */
import { runTurn, type TurnResult } from "@/agent/run";
import { SEED_PACKS } from "@/knowledge/seeds";
import { db } from "@/db";
import { beliefs, conceptStates, observations, concepts, labRuns, messages } from "@/db/schema";
import { and, eq, ne } from "drizzle-orm";
import { setAblation, type Ablation } from "./ablation";
import type { Style } from "@/memory";

/* ---------------- RNG ---------------- */
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ---------------- Archetypes ---------------- */
export type Archetype = {
  name: string;
  domains: string[]; // domains they will learn (seed slugs)
  pref: Record<string, Style>; // hidden true preferred style per domain
  driftTo?: { session: number; pref: Record<string, Style> }; // preference drift
  learnHigh: number; // p(understand) when style matches
  learnLow: number; // p(understand) otherwise
  articulate: number; // p(express the real preference when an explanation fails)
  statesPreference?: { style: Style; truthful: boolean }; // says a preference up front (maybe misleading)
  selfReport: "accurate" | "over" | "under";
  noise: number; // p(random casual/detour/greeting)
  switchProb: number; // p(topic switch)
  whyProb: number; // p(asks why)
  engagement: number; // p(responds substantively vs "ok")
  gapDays: number[]; // gaps between sessions
};

const S = (s: Style) => s;
export const ARCHETYPES: Archetype[] = [
  { name: "example_lover", domains: ["bash", "python"], pref: { bash: S("concrete_example"), python: S("concrete_example") }, learnHigh: 0.8, learnLow: 0.3, articulate: 0.6, selfReport: "accurate", noise: 0.05, switchProb: 0.05, whyProb: 0.05, engagement: 0.9, gapDays: [1, 2, 1, 7, 1, 3, 1, 14] },
  { name: "stepwise_debugger", domains: ["bash"], pref: { bash: S("step_by_step") }, learnHigh: 0.75, learnLow: 0.3, articulate: 0.5, selfReport: "accurate", noise: 0.05, switchProb: 0.02, whyProb: 0.1, engagement: 0.85, gapDays: [1, 1, 1, 1, 30, 1, 1, 1] },
  { name: "context_split", domains: ["bash", "oop"], pref: { bash: S("concise"), oop: S("analogy") }, learnHigh: 0.8, learnLow: 0.3, articulate: 0.5, selfReport: "accurate", noise: 0.05, switchProb: 0.2, whyProb: 0.05, engagement: 0.9, gapDays: [1, 3, 1, 1, 10, 1, 2, 1] },
  { name: "misleading_self_report", domains: ["recursion"], pref: { recursion: S("concrete_example") }, statesPreference: { style: "concise", truthful: false }, learnHigh: 0.8, learnLow: 0.25, articulate: 0.3, selfReport: "accurate", noise: 0.05, switchProb: 0.02, whyProb: 0.05, engagement: 0.9, gapDays: [1, 1, 2, 1, 1, 5, 1, 1] },
  { name: "truthful_self_report", domains: ["git"], pref: { git: S("step_by_step") }, statesPreference: { style: "step_by_step", truthful: true }, learnHigh: 0.8, learnLow: 0.3, articulate: 0.4, selfReport: "accurate", noise: 0.05, switchProb: 0.02, whyProb: 0.05, engagement: 0.9, gapDays: [1, 1, 1, 1, 1, 1, 1, 1] },
  { name: "overconfident", domains: ["oop"], pref: { oop: S("plain") }, learnHigh: 0.7, learnLow: 0.4, articulate: 0.4, selfReport: "over", noise: 0.05, switchProb: 0.02, whyProb: 0.05, engagement: 0.9, gapDays: [1, 2, 1, 1, 1, 7, 1, 1] },
  { name: "underconfident", domains: ["sql"], pref: { sql: S("concrete_example") }, learnHigh: 0.85, learnLow: 0.45, articulate: 0.4, selfReport: "under", noise: 0.05, switchProb: 0.02, whyProb: 0.05, engagement: 0.9, gapDays: [1, 1, 1, 1, 1, 1, 1, 1] },
  { name: "drifter", domains: ["python"], pref: { python: S("analogy") }, driftTo: { session: 5, pref: { python: S("concise") } }, learnHigh: 0.8, learnLow: 0.3, articulate: 0.6, selfReport: "accurate", noise: 0.05, switchProb: 0.02, whyProb: 0.05, engagement: 0.9, gapDays: [1, 1, 1, 1, 1, 1, 1, 1] },
  { name: "curious_switcher", domains: ["rust_ownership", "recursion", "git"], pref: { rust_ownership: S("detailed"), recursion: S("concrete_example"), git: S("concise") }, learnHigh: 0.75, learnLow: 0.35, articulate: 0.5, selfReport: "accurate", noise: 0.15, switchProb: 0.3, whyProb: 0.3, engagement: 0.9, gapDays: [1, 1, 5, 1, 1, 1, 20, 1] },
  { name: "low_engagement", domains: ["sql"], pref: { sql: S("step_by_step") }, learnHigh: 0.7, learnLow: 0.3, articulate: 0.2, selfReport: "accurate", noise: 0.1, switchProb: 0.02, whyProb: 0.02, engagement: 0.4, gapDays: [3, 5, 2, 9, 1, 4, 1, 2] },
  { name: "noisy_inconsistent", domains: ["bash"], pref: { bash: S("analogy") }, learnHigh: 0.65, learnLow: 0.4, articulate: 0.5, selfReport: "accurate", noise: 0.25, switchProb: 0.1, whyProb: 0.1, engagement: 0.7, gapDays: [1, 1, 1, 1, 1, 1, 1, 1] },
  { name: "long_gap_returner", domains: ["git"], pref: { git: S("concrete_example") }, learnHigh: 0.8, learnLow: 0.3, articulate: 0.5, selfReport: "accurate", noise: 0.05, switchProb: 0.02, whyProb: 0.05, engagement: 0.9, gapDays: [1, 60, 1, 90, 1, 1, 45, 1] },
];

/* ---------------- Learner simulator ---------------- */
type LearnerState = {
  mastery: Map<string, number>;
  domain: string | null;
  lastExplained?: { concept: string; style: Style; domain: string };
  pending?: { concept: string; answer: string[]; domain: string };
  pref: Record<string, Style>;
  saidPreference: boolean;
  explanations: { turn: number; session: number; domain: string; style: Style; truePref: Style; landed: boolean }[];
  probes: number;
  turns: number;
  claims: { concept: string; trueMastery: number }[];
};

const ASK_FOR: Record<Style, string[]> = {
  concrete_example: ["Can you show me a concrete example?", "Show me some code for that", "an example would help"],
  step_by_step: ["Can you walk me through it step by step?", "break it down one step at a time please"],
  concise: ["Shorter please, just the gist", "too long, just give me the answer", "tl;dr?"],
  analogy: ["Is there an analogy for this?", "what's the intuition here?"],
  detailed: ["I want the full detail and the why", "go deeper, why is it like that?"],
  plain: ["Can you say that in simpler words?", "simpler please"],
};

const CONFUSED = ["I don't get it", "still confused", "hmm, that didn't click", "I'm lost"];
const LANDED = ["got it", "makes sense", "ok that's clear", "I see", "next", "understood, next"];
const DETOURS = ["What is the capital of Portugal?", "Who invented the telephone?", "what's the weather like where you are"];
const DOMAIN_LABEL: Record<string, string> = { bash: "Bash", python: "Python", oop: "OOP", recursion: "recursion", git: "Git", sql: "SQL", rust_ownership: "Rust ownership" };

function conceptOf(domain: string, slug: string) {
  return SEED_PACKS.find((p) => p.slug === domain)?.concepts.find((c) => c.slug === slug) ?? null;
}

export async function simulateLearner(a: Archetype, seed: number, opts: { sessions: number; turns: number; runTag: string; start: Date; ablation: Ablation }) {
  const rnd = mulberry32(seed * 7919 + a.name.length);
  const learnerId = `sim_${opts.runTag}_${a.name}_${seed}`;
  const st: LearnerState = { mastery: new Map(), domain: null, pref: { ...a.pref }, saidPreference: false, explanations: [], probes: 0, turns: 0, claims: [] };
  let now = new Date(opts.start.getTime() + seed * 3600_000);
  const transcript: string[] = [];

  const talk = async (text: string) => {
    now = new Date(now.getTime() + (1 + Math.floor(rnd() * 3)) * 60_000);
    const r = await runTurn({ learnerId, text, now });
    st.turns++;
    transcript.push(`U: ${text}\nA[${r.trace.move}${r.trace.strategy ? "/" + r.trace.strategy : ""}]: ${r.reply.slice(0, 220).replace(/\n/g, " ")}`);
    return r;
  };

  for (let s = 0; s < opts.sessions; s++) {
    if (s > 0) now = new Date(now.getTime() + (a.gapDays[s - 1] ?? 1) * 86_400_000);
    if (a.driftTo && s + 1 === a.driftTo.session) st.pref = { ...st.pref, ...a.driftTo.pref };
    // Session opener
    let r: TurnResult;
    if (s === 0 || !st.domain || rnd() < 0.3) {
      st.domain = a.domains[Math.floor(rnd() * a.domains.length)];
      r = await talk(`${s === 0 ? "I want to learn" : "Let's do"} ${DOMAIN_LABEL[st.domain]}`);
    } else {
      r = await talk(rnd() < 0.5 ? "let's continue" : "next");
    }
    if (a.statesPreference && !st.saidPreference && s === 0) {
      st.saidPreference = true;
      const words: Record<Style, string> = { concise: "I prefer short answers", concrete_example: "I learn best from examples", step_by_step: "I prefer step by step explanations", analogy: "I like analogies", detailed: "I prefer detailed explanations", plain: "keep it simple" };
      r = await talk(words[a.statesPreference.style]);
    }
    for (let t = 0; t < opts.turns; t++) {
      // interpret the agent's last move
      const trace = r.trace;
      const dom = trace.domain ?? st.domain ?? a.domains[0];
      if (trace.domain && trace.domain !== st.domain) st.domain = trace.domain;
      if (trace.probe) {
        st.probes++;
        const spec = conceptOf(dom, trace.probe.concept);
        const m = st.mastery.get(trace.probe.concept) ?? 0.15;
        const correct = rnd() < m * 0.85 + (1 - m) * 0.15;
        if (spec?.checks?.length) {
          const chk = spec.checks.find((c) => c.prompt === r.reply.split(": ").pop()?.trim()) ?? spec.checks[0];
          const kws = chk.answer;
          const text = correct ? `I think it's ${kws.slice(0, 3).join(", ")} — ${kws[0]} basically.` : rnd() < 0.5 ? "I don't know" : "hmm, maybe it's about performance or memory?";
          r = await talk(text);
          continue;
        }
      }
      if (trace.strategy && trace.concept && ["explain", "reexplain", "introduce_domain", "next_concept", "answer"].includes(trace.move)) {
        const style = trace.strategy as Style;
        const truePref = st.pref[dom] ?? "plain";
        const fits = style === truePref || (truePref === "plain" && style === "concise");
        const base = fits ? a.learnHigh : a.learnLow;
        const landed = rnd() < base;
        st.explanations.push({ turn: st.turns, session: s, domain: dom, style, truePref, landed });
        if (landed) st.mastery.set(trace.concept, Math.min(1, (st.mastery.get(trace.concept) ?? 0.15) + 0.4));
        // noise / detours / switching
        const roll = rnd();
        if (roll < a.noise) {
          r = await talk(DETOURS[Math.floor(rnd() * DETOURS.length)]);
          continue;
        }
        if (roll < a.noise + a.switchProb && a.domains.length > 1) {
          const other = a.domains.filter((d) => d !== st.domain);
          st.domain = other[Math.floor(rnd() * other.length)];
          r = await talk(`Actually, let's talk about ${DOMAIN_LABEL[st.domain]}`);
          continue;
        }
        if (rnd() < a.whyProb) {
          r = await talk("Why does this work?");
          continue;
        }
        if (landed) {
          // self-report bias: overconfident learners claim to know upcoming things
          if (a.selfReport === "over" && rnd() < 0.35) {
            const pack = SEED_PACKS.find((p) => p.slug === dom)!;
            const target = pack.concepts.find((c) => (st.mastery.get(c.slug) ?? 0.15) < 0.4 && c.slug !== trace.concept);
            if (target) {
              st.claims.push({ concept: target.slug, trueMastery: st.mastery.get(target.slug) ?? 0.15 });
              r = await talk(`I already know ${target.label.toLowerCase()}`);
              continue;
            }
          }
          if (a.selfReport === "under" && rnd() < 0.35) {
            r = await talk("I'm not sure I really get it, but ok... next");
            continue;
          }
          r = await talk(rnd() < a.engagement ? LANDED[Math.floor(rnd() * LANDED.length)] : "ok");
        } else {
          if (rnd() < a.articulate) r = await talk(ASK_FOR[truePref][Math.floor(rnd() * ASK_FOR[truePref].length)]);
          else r = await talk(rnd() < a.engagement ? CONFUSED[Math.floor(rnd() * CONFUSED.length)] : "ok");
        }
        continue;
      }
      // Other moves (feedback, acknowledge, detour, ...): move forward
      if (trace.move === "acknowledge" && rnd() < 0.6) {
        const pack = SEED_PACKS.find((p) => p.slug === dom);
        const c = pack?.concepts[Math.floor(rnd() * pack.concepts.length)];
        if (c) {
          r = await talk(`can you explain ${c.label.toLowerCase()} again?`);
          continue;
        }
      }
      if (trace.move === "feedback" && rnd() < 0.3 && trace.concept) {
        // after feedback sometimes ask for practice
        r = await talk("give me another exercise");
        continue;
      }
      r = await talk(rnd() < 0.15 && a.domains.length > 1 ? `let's talk about ${DOMAIN_LABEL[a.domains[Math.floor(rnd() * a.domains.length)]]}` : "next");
    }
  }
  return { learnerId, state: st, transcript };
}

/* ---------------- Metrics vs hidden truth ---------------- */
export async function evaluateLearner(a: Archetype, learnerId: string, st: LearnerState) {
  const ex = st.explanations;
  const third = Math.max(1, Math.floor(ex.length / 3));
  const match = (xs: typeof ex) => (xs.length ? xs.filter((e) => e.style === e.truePref || (e.truePref === "plain" && e.style === "concise")).length / xs.length : 0);
  const early = match(ex.slice(0, third));
  const late = match(ex.slice(-third));
  const landedRate = ex.length ? ex.filter((e) => e.landed).length / ex.length : 0;
  const lateLanded = ex.slice(-third).length ? ex.slice(-third).filter((e) => e.landed).length / ex.slice(-third).length : 0;

  const bel = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, learnerId), ne(beliefs.status, "retired")));
  const finalPref = st.pref;
  const perDomain: Record<string, { truth: Style; top: string | null; correct: boolean; status?: string }> = {};
  for (const d of a.domains) {
    const cands = bel.filter((b) => b.kind === "preference" && b.subject === "explanation_style" && b.scope === `domain:${d}`).sort((x, y) => y.confidence - x.confidence);
    const top = cands[0];
    perDomain[d] = { truth: finalPref[d], top: top?.value ?? null, correct: !!top && (top.value === finalPref[d] || (finalPref[d] === "plain" && top.value === "concise")), status: top?.status };
  }
  const prefAcc = a.domains.filter((d) => st.explanations.some((e) => e.domain === d)).map((d) => perDomain[d].correct);
  const falseActive = bel.filter((b) => b.kind === "preference" && b.status === "active" && b.scope.startsWith("domain:") && b.value !== finalPref[b.scope.replace("domain:", "")] && a.domains.includes(b.scope.replace("domain:", ""))).length;

  // knowledge calibration
  const states = await db.select().from(conceptStates).where(eq(conceptStates.learnerId, learnerId));
  let brier = 0,
    n = 0;
  for (const s of states) {
    const truth = (st.mastery.get(s.slug) ?? 0.15) >= 0.5 ? 1 : 0;
    brier += (s.pKnown - truth) ** 2;
    n++;
  }
  const overBelief = bel.find((b) => b.subject === "self_assessment" && b.value === "overestimates");
  const underBelief = bel.find((b) => b.subject === "self_assessment" && b.value === "underestimates");
  const [obsCount] = await db.select({ c: observations.id }).from(observations).where(eq(observations.learnerId, learnerId));
  const obsAll = await db.select({ id: observations.id }).from(observations).where(eq(observations.learnerId, learnerId));
  const conAll = await db.select({ id: concepts.id, status: concepts.status }).from(concepts).where(eq(concepts.learnerId, learnerId));
  const msgs = await db.select({ id: messages.id }).from(messages).where(eq(messages.learnerId, learnerId));
  void obsCount;

  // drift responsiveness: explanations after drift until first 3 consecutive matches
  let driftLag: number | null = null;
  if (a.driftTo) {
    const after = ex.filter((e) => e.session >= a.driftTo!.session - 1);
    for (let i = 0; i < after.length; i++) {
      if (after.slice(i, i + 2).length === 2 && after.slice(i, i + 2).every((e) => e.style === e.truePref)) {
        driftLag = i;
        break;
      }
    }
    if (driftLag === null) driftLag = after.length;
  }
  const masteryVals = [...st.mastery.values()];
  return {
    archetype: a.name,
    learnerId,
    turns: st.turns,
    explanations: ex.length,
    styleMatchEarly: +early.toFixed(3),
    styleMatchLate: +late.toFixed(3),
    landedRate: +landedRate.toFixed(3),
    lateLandedRate: +lateLanded.toFixed(3),
    meanMastery: +(masteryVals.reduce((x, y) => x + y, 0) / Math.max(1, masteryVals.length)).toFixed(3),
    conceptsMastered: masteryVals.filter((m) => m >= 0.5).length,
    probes: st.probes,
    probeRate: +(st.probes / Math.max(1, st.turns)).toFixed(3),
    prefBeliefAccuracy: prefAcc.length ? +(prefAcc.filter(Boolean).length / prefAcc.length).toFixed(3) : null,
    perDomain,
    falseActivePrefBeliefs: falseActive,
    brier: n ? +(brier / n).toFixed(3) : null,
    overconfidenceDetected: !!overBelief,
    underconfidenceDetected: !!underBelief,
    driftLag,
    beliefs: bel.length,
    activeBeliefs: bel.filter((b) => b.status === "active").length,
    observations: obsAll.length,
    concepts: conAll.length,
    messages: msgs.length,
  };
}

export type LearnerReport = Awaited<ReturnType<typeof evaluateLearner>>;

export async function runExperiment(opts: { name: string; ablation: Ablation; seeds: number[]; sessions: number; turns: number; archetypes?: string[] }) {
  setAblation(opts.ablation);
  const tag = `${opts.name}_${Date.now().toString(36)}`;
  const reports: LearnerReport[] = [];
  const transcripts: Record<string, string[]> = {};
  const list = ARCHETYPES.filter((a) => !opts.archetypes || opts.archetypes.includes(a.name));
  for (const a of list) {
    for (const seed of opts.seeds) {
      const { learnerId, state, transcript } = await simulateLearner(a, seed, { sessions: opts.sessions, turns: opts.turns, runTag: tag, start: new Date("2026-01-05T09:00:00Z"), ablation: opts.ablation });
      reports.push(await evaluateLearner(a, learnerId, state));
      transcripts[`${a.name}_${seed}`] = transcript;
    }
  }
  const avg = (k: keyof LearnerReport) => {
    const xs = reports.map((r) => r[k]).filter((v): v is number => typeof v === "number");
    return xs.length ? +(xs.reduce((x, y) => x + y, 0) / xs.length).toFixed(3) : null;
  };
  const summary = {
    ablation: opts.ablation,
    learners: reports.length,
    turns: reports.reduce((x, r) => x + r.turns, 0),
    styleMatchEarly: avg("styleMatchEarly"),
    styleMatchLate: avg("styleMatchLate"),
    landedRate: avg("landedRate"),
    lateLandedRate: avg("lateLandedRate"),
    meanMastery: avg("meanMastery"),
    conceptsMastered: avg("conceptsMastered"),
    probeRate: avg("probeRate"),
    prefBeliefAccuracy: avg("prefBeliefAccuracy"),
    falseActivePrefBeliefs: avg("falseActivePrefBeliefs"),
    brier: avg("brier"),
    overconfidenceDetected: reports.filter((r) => r.archetype === "overconfident").map((r) => r.overconfidenceDetected),
    overconfidenceFalsePositives: reports.filter((r) => r.archetype !== "overconfident" && r.overconfidenceDetected).length,
    driftLag: avg("driftLag"),
    beliefsPerLearner: avg("beliefs"),
    activeBeliefsPerLearner: avg("activeBeliefs"),
    observationsPerLearner: avg("observations"),
  };
  await db.insert(labRuns).values({ name: opts.name, config: { ...opts }, results: { summary, reports } });
  return { summary, reports, transcripts };
}
