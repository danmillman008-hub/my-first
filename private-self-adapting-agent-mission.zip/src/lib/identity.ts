import { cookies } from "next/headers";

const COOKIE = "la_learner";

export async function getLearnerId(): Promise<{ id: string; isNew: boolean }> {
  const jar = await cookies();
  const existing = jar.get(COOKIE)?.value;
  if (existing) return { id: existing, isNew: false };
  const id = `l_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  return { id, isNew: true };
}

export function learnerCookie(id: string) {
  return { name: COOKIE, value: id, httpOnly: true, sameSite: "lax" as const, path: "/", maxAge: 60 * 60 * 24 * 365 };
}
