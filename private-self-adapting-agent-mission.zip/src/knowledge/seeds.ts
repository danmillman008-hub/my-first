import type { DomainPack } from "@/db/schema";

/**
 * Curated starter packs. They are NOT the limit of the system: unknown
 * domains are researched live (LLM or Wikipedia) and the graph grows from
 * conversation. Packs give the offline engine real pedagogical material.
 */

const bash: DomainPack = {
  slug: "bash",
  label: "Bash",
  aliases: ["bash", "shell", "shell scripting", "linux terminal", "command line", "zsh", "terminal"],
  summary: "Bash is the standard Unix shell: an interactive command interpreter and a scripting language for automating work with files, processes and text.",
  concepts: [
    {
      slug: "commands_and_arguments", label: "Commands & arguments",
      summary: "A shell line is a command word followed by whitespace-separated arguments; options usually start with '-'.",
      explain: {
        plain: "Every line you type is split on spaces: the first word is the program, the rest are arguments handed to it. Options like -l are just arguments that the program chooses to interpret.",
        example: "`ls -l /tmp` runs the program `ls` with two arguments: `-l` (an option) and `/tmp` (a path). `echo hello world` passes two arguments to echo, which prints them joined by a space.",
        steps: ["The shell reads the line.", "It splits it into words on unquoted whitespace.", "The first word is looked up as a builtin, function or program in $PATH.", "The remaining words are passed as arguments (argv)."],
        analogy: "Think of it as calling a function: `ls -l /tmp` is like ls('-l', '/tmp'). The shell does the parsing; the program decides what the arguments mean.",
        contrast: "Unlike most languages, the shell splits on whitespace before the program sees anything — that's why `echo a    b` prints `a b` unless you quote it.",
      },
      checks: [
        { prompt: "In `grep -i error app.log`, how many arguments does grep receive, and what are they?", answer: ["2", "two", "-i", "app.log"], hint: "Count the words after the program name." },
      ],
    },
    {
      slug: "quoting", label: "Quoting & word splitting",
      summary: "Quotes control how the shell splits words and expands variables: single quotes are literal, double quotes allow $expansion but prevent splitting.",
      explain: {
        plain: "Quoting tells the shell to stop interpreting. Single quotes: everything literal. Double quotes: variables and $(commands) still expand, but the result stays one word. Unquoted: expand AND split on spaces AND glob.",
        example: "```bash\nname=\"Ada Lovelace\"\necho $name      # 2 args: Ada, Lovelace\necho \"$name\"    # 1 arg: Ada Lovelace\necho '$name'    # 1 arg: $name (literal)\n```",
        steps: ["Decide if you need expansion. No → single quotes.", "Need $var or $(cmd) but as a single word → double quotes.", "Rule of thumb: always \"$quote\" variables unless you deliberately want splitting."],
        analogy: "Single quotes are a sealed envelope; double quotes are a clear envelope where the shell can still fill in blanks; no quotes means the contents may scatter on the floor.",
        contrast: "In Python 'x' and \"x\" are identical. In Bash they are different tools: only double quotes expand $variables.",
      },
      checks: [
        { prompt: "If `f=\"my file.txt\"`, what is the difference between `rm $f` and `rm \"$f\"`?", answer: ["two", "split", "my", "file.txt", "one argument", "single"], hint: "Think about word splitting on the space." },
      ],
      prereqs: ["commands_and_arguments"],
    },
    {
      slug: "variables", label: "Variables & expansion",
      summary: "Assign with NAME=value (no spaces); read with $NAME or ${NAME}; environment variables are exported to child processes.",
      explain: {
        plain: "Bash variables are strings. `x=5` assigns (no spaces around =). `$x` reads. `export x` makes it visible to programs you launch. `${x}` is the same as `$x` but lets you write `${x}abc` safely.",
        example: "```bash\ncount=3\necho \"count is $count\"\nexport EDITOR=vim   # child programs see it\necho \"${count}rd item\"\n```",
        steps: ["Assign: `name=value` (no spaces).", "Use: `\"$name\"`.", "Make available to child processes: `export name`.", "Parameter tricks: `${name:-default}`, `${#name}` for length."],
        analogy: "A shell variable is a sticky note on your desk; exporting it photocopies the note into every program you start.",
        contrast: "Unlike typed languages, everything is text — arithmetic needs `$(( ))`: `echo $((count + 1))`.",
      },
      checks: [
        { prompt: "Why does `x = 5` fail in Bash but `x=5` works?", answer: ["space", "command", "x is treated", "runs x"], hint: "What does Bash think the first word is?" },
      ],
      prereqs: ["commands_and_arguments"],
    },
    {
      slug: "pipes_redirection", label: "Pipes & redirection",
      summary: "`|` connects one command's stdout to the next's stdin; `>` `>>` `<` `2>` redirect streams to files.",
      explain: {
        plain: "Every process has three streams: stdin (0), stdout (1), stderr (2). A pipe feeds stdout of the left command into stdin of the right one. Redirections point a stream at a file instead.",
        example: "```bash\ncat access.log | grep 404 | wc -l      # count 404s\nsort names.txt > sorted.txt           # overwrite\necho done >> log.txt                  # append\nmake 2> errors.txt                    # only stderr\ncmd > out.txt 2>&1                    # both to file\n```",
        steps: ["Identify which stream you care about (stdout vs stderr).", "Use `|` to chain programs.", "Use `>` to write, `>>` to append, `2>` for errors.", "`2>&1` means 'send stderr wherever stdout is going' — order matters."],
        analogy: "Pipes are plumbing: water (text) flows out of one appliance into the next. Redirection is choosing which sink the water ends up in.",
        contrast: "A pipe passes text between processes; `>` writes to a file. `cmd > f | other` does NOT give `other` any data — it all went to f.",
      },
      checks: [
        { prompt: "What does `ls missing_dir 2>/dev/null` do?", answer: ["discard", "suppress", "hide", "error", "stderr", "null"], hint: "Stream 2 is stderr." },
        { prompt: "How would you count how many lines in `data.txt` contain the word 'error'?", answer: ["grep", "wc -l", "grep -c"], hint: "Combine grep with a counting command." },
      ],
      prereqs: ["commands_and_arguments"],
    },
    {
      slug: "exit_status_conditionals", label: "Exit status & conditionals",
      summary: "Every command returns an exit status (0 = success); if/&&/|| branch on it; [[ ]] tests conditions.",
      explain: {
        plain: "Programs end with a small number: 0 means success, anything else means failure. `if`, `&&` and `||` look only at that number, not at output. `$?` holds the last status.",
        example: "```bash\nif grep -q root /etc/passwd; then echo found; fi\nmkdir build && cd build          # cd only if mkdir succeeded\nping -c1 host || echo \"host down\"\n[[ -f config.yml ]] && echo exists\n```",
        steps: ["Run a command.", "Check `$?` (0 = ok).", "`a && b`: run b only if a succeeded.", "`a || b`: run b only if a failed.", "`[[ expr ]]` is itself a command that returns 0/1."],
        analogy: "Exit status is a thumbs-up/thumbs-down each program gives when it leaves. `if` just watches the thumbs.",
        contrast: "0 is 'true' here — the opposite of C/Python. That surprises everyone once.",
      },
      checks: [
        { prompt: "In Bash, which exit status means success, and what does `cmd1 || cmd2` do?", answer: ["0", "zero", "fails", "failure", "if cmd1"], hint: "Remember success is zero." },
      ],
      prereqs: ["commands_and_arguments"],
    },
    {
      slug: "loops_scripts", label: "Loops & scripts",
      summary: "for/while loops iterate over words or lines; scripts start with a shebang and are made executable with chmod +x.",
      explain: {
        plain: "A script is just commands in a file. The first line `#!/usr/bin/env bash` says which interpreter runs it. `for x in ...` loops over words; `while read -r line` loops over lines of input.",
        example: "```bash\n#!/usr/bin/env bash\nset -euo pipefail\nfor f in *.log; do\n  echo \"processing $f\"\n  gzip \"$f\"\ndone\nwhile read -r line; do echo \"got: $line\"; done < input.txt\n```",
        steps: ["Create file with `#!/usr/bin/env bash`.", "Add `set -euo pipefail` for safer failures.", "Write commands / loops.", "`chmod +x script.sh` then `./script.sh`."],
        analogy: "A script is a recipe card: the shebang says which chef reads it, and loops are 'repeat for each ingredient'.",
        contrast: "`for f in $(ls)` breaks on spaces; `for f in *` does not, because globbing produces proper words.",
      },
      checks: [
        { prompt: "Write a loop that prints each `.txt` file name in the current directory.", answer: ["for", "*.txt", "do", "done", "echo"], hint: "Use a glob, not ls." },
      ],
      prereqs: ["variables", "quoting", "exit_status_conditionals"],
    },
  ],
};

const oop: DomainPack = {
  slug: "oop",
  label: "Object-oriented programming",
  aliases: ["oop", "object oriented", "object-oriented", "classes", "objects", "inheritance", "polymorphism"],
  summary: "OOP organizes code around objects that bundle state and behavior, using classes, encapsulation, inheritance/composition and polymorphism.",
  concepts: [
    {
      slug: "classes_objects", label: "Classes & objects",
      summary: "A class is a blueprint; an object is an instance with its own state created from that blueprint.",
      explain: {
        plain: "A class describes what something has (fields) and can do (methods). An object is one concrete thing built from it. Many objects, one class.",
        example: "```python\nclass Dog:\n    def __init__(self, name):\n        self.name = name\n    def speak(self):\n        return f\"{self.name} says woof\"\n\nrex = Dog(\"Rex\"); fido = Dog(\"Fido\")\nprint(rex.speak())  # Rex says woof\n```",
        steps: ["Define the class with its fields.", "Write a constructor to initialize them.", "Add methods that operate on `self`.", "Instantiate as many objects as needed."],
        analogy: "A class is a cookie cutter; objects are cookies. Same shape, different sprinkles.",
        contrast: "A class is not an object you use directly (usually); calling it produces objects. Confusing `Dog` with `rex` is the classic first mistake.",
      },
      checks: [{ prompt: "In `car = Car('red')`, which is the class and which is the object?", answer: ["Car", "class", "car", "object", "instance"], hint: "Capitalized name is the blueprint." }],
    },
    {
      slug: "encapsulation", label: "Encapsulation",
      summary: "Keep an object's internal state private and expose behavior through a controlled interface so invariants hold.",
      explain: {
        plain: "Encapsulation means the object owns its data; other code interacts through methods, so the object can guarantee its rules (e.g. balance never negative).",
        example: "```python\nclass Account:\n    def __init__(self):\n        self._balance = 0\n    def deposit(self, amt):\n        if amt <= 0: raise ValueError\n        self._balance += amt\n    @property\n    def balance(self): return self._balance\n```",
        steps: ["Identify the invariant you must protect.", "Make the field private/underscored.", "Expose only methods that keep the invariant.", "Validate inputs in those methods."],
        analogy: "A vending machine: you press buttons (methods), you never reach inside to grab the snack (state).",
        contrast: "Getters/setters for every field is NOT encapsulation — it's public fields with extra typing. The point is protecting invariants.",
      },
      checks: [{ prompt: "Why would you make `balance` private instead of a public attribute?", answer: ["invariant", "negative", "validate", "control", "protect", "consistent"], hint: "What could go wrong if anyone could set it?" }],
      prereqs: ["classes_objects"],
    },
    {
      slug: "inheritance", label: "Inheritance",
      summary: "A subclass reuses and specializes a parent class ('is-a'); overuse creates fragile hierarchies.",
      explain: {
        plain: "Inheritance lets a new class start from an existing one, keep what fits, and override what differs. It models 'is-a' relationships.",
        example: "```python\nclass Animal:\n    def speak(self): return \"...\"\nclass Dog(Animal):\n    def speak(self): return \"woof\"\nprint(Dog().speak())  # woof\n```",
        steps: ["Find shared behavior.", "Put it in a base class.", "Subclass and override only what differs.", "Ask: is it truly 'is-a'? If not, prefer composition."],
        analogy: "A subclass is a customized edition of a book: same chapters unless the editor rewrites one.",
        contrast: "Inheritance = 'is-a' (Dog is an Animal). Composition = 'has-a' (Car has an Engine). Reaching for inheritance to share code is usually the wrong reason.",
      },
      checks: [{ prompt: "Should `Square` inherit from `Rectangle`? Why might that cause trouble?", answer: ["liskov", "setWidth", "substitut", "breaks", "no", "invariant", "width and height"], hint: "Think about setting width independently of height." }],
      prereqs: ["classes_objects"],
    },
    {
      slug: "polymorphism", label: "Polymorphism",
      summary: "Different objects respond to the same message in their own way, so callers don't need type checks.",
      explain: {
        plain: "Polymorphism means you can call `shape.area()` without knowing whether shape is a circle or square; each class supplies its own implementation.",
        example: "```python\nshapes = [Circle(2), Square(3)]\nfor s in shapes:\n    print(s.area())  # each computes its own\n```",
        steps: ["Define a common method name/interface.", "Implement it in each class.", "Write callers against the interface, never against concrete types.", "Delete the if/elif type checks."],
        analogy: "Press 'play' on any device — a record player, a phone, a radio — each does something different, but you never change how you press it.",
        contrast: "Polymorphism replaces `if isinstance(x, Circle): ... elif ...` chains. If you see those chains, polymorphism is missing.",
      },
      checks: [{ prompt: "What code smell does polymorphism usually eliminate?", answer: ["isinstance", "if", "type check", "switch", "elif", "chain"], hint: "Think about branching on type." }],
      prereqs: ["inheritance"],
    },
    {
      slug: "composition", label: "Composition over inheritance",
      summary: "Build behavior by combining objects ('has-a'); more flexible than deep inheritance trees.",
      explain: {
        plain: "Instead of inheriting behavior, hold an object that provides it. You can swap it at runtime and avoid fragile hierarchies.",
        example: "```python\nclass Logger: ...\nclass Service:\n    def __init__(self, logger: Logger):\n        self.logger = logger   # has-a\n```",
        steps: ["Identify a capability.", "Wrap it in its own small class.", "Inject it into the class that needs it.", "Swap implementations freely (tests, variants)."],
        analogy: "LEGO bricks vs. carving a statue: composition snaps parts together; inheritance carves from one block.",
        contrast: "Inheritance fixes the relationship at class-definition time; composition can change it per object.",
      },
      checks: [{ prompt: "Give an example where 'has-a' fits better than 'is-a'.", answer: ["has", "engine", "car", "logger", "wheel", "contains"], hint: "Think about parts of a thing." }],
      prereqs: ["inheritance", "encapsulation"],
    },
  ],
};

const recursion: DomainPack = {
  slug: "recursion",
  label: "Recursion",
  aliases: ["recursion", "recursive", "recursive functions"],
  summary: "Recursion solves a problem by solving smaller instances of itself, with a base case to stop.",
  concepts: [
    {
      slug: "base_case", label: "Base case",
      summary: "The smallest input that is answered directly, without recursing; without it recursion never ends.",
      explain: {
        plain: "Every recursive function needs a case it can answer immediately. That's the base case. Everything else shrinks the problem toward it.",
        example: "```python\ndef fact(n):\n    if n <= 1: return 1        # base case\n    return n * fact(n - 1)\n```",
        steps: ["Ask: what's the trivial input?", "Return its answer directly.", "Make sure every recursive call moves toward it."],
        analogy: "Russian nesting dolls: the smallest doll doesn't open. That's the base case.",
        contrast: "Missing base case → RecursionError / stack overflow. Wrong base case → off-by-one answers.",
      },
      checks: [{ prompt: "What happens if `fact` above had no `if n <= 1` line?", answer: ["infinite", "stack", "overflow", "recursionerror", "never", "crash"], hint: "When would it stop?" }],
    },
    {
      slug: "recursive_case", label: "Recursive case & trust",
      summary: "Express the answer for n in terms of a smaller subproblem, trusting the call to be correct (the recursive leap of faith).",
      explain: {
        plain: "Don't trace every call. Assume `fact(n-1)` already works, then ask: how do I get fact(n) from it? Multiply by n. That's the whole design move.",
        example: "```python\ndef total(xs):\n    if not xs: return 0                # base\n    return xs[0] + total(xs[1:])       # trust total() on the rest\n```",
        steps: ["Write the base case.", "Assume the function works for a smaller input.", "Combine that result with the current piece.", "Verify each call actually shrinks the input."],
        analogy: "Passing a bucket down a line: you only handle your bucket and trust the next person handles theirs.",
        contrast: "Beginners try to simulate the whole stack in their head; experts reason about one level and trust the rest.",
      },
      checks: [{ prompt: "Write (in words or code) a recursive function that sums a list of numbers.", answer: ["[0]", "rest", "1:", "sum", "+", "empty", "base"], hint: "Base case: empty list." }],
      prereqs: ["base_case"],
    },
    {
      slug: "call_stack", label: "The call stack",
      summary: "Each call gets its own frame with its own variables; frames unwind in reverse order when returning.",
      explain: {
        plain: "Each recursive call pauses the caller and starts fresh with its own local variables. When the deepest call returns, the paused calls resume in reverse order.",
        example: "fact(3) → 3 * fact(2) → 2 * fact(1) → 1. Then unwind: fact(2)=2, fact(3)=6.",
        steps: ["Call pushes a frame.", "Frame holds that call's locals.", "Return pops the frame.", "Too many frames → stack overflow."],
        analogy: "A stack of plates: each call adds a plate; returning removes the top one. You can only remove from the top.",
        contrast: "Loops reuse one set of variables; recursion gets a new set per call — that's why `n` can be 3, 2, 1 at once.",
      },
      checks: [{ prompt: "In `fact(3)`, how many frames exist at the deepest point?", answer: ["3", "three"], hint: "fact(3), fact(2), fact(1)." }],
      prereqs: ["recursive_case"],
    },
    {
      slug: "recursion_vs_iteration", label: "Recursion vs iteration",
      summary: "Any recursion can be rewritten as a loop (often with an explicit stack); recursion shines on tree-shaped data.",
      explain: {
        plain: "Loops are usually faster and safer for linear work. Recursion is clearer for nested structures: trees, nested lists, file systems, parsers.",
        example: "```python\ndef size(node):\n    if node is None: return 0\n    return 1 + size(node.left) + size(node.right)\n```",
        steps: ["Is the data shaped like a tree/nesting? → recursion is natural.", "Is it a flat sequence? → loop.", "Deep recursion (>1000 levels in Python)? → convert to loop with a stack."],
        analogy: "Recursion is a map that says 'explore each room, and inside each room, explore each closet'.",
        contrast: "Iteration: one frame, explicit state. Recursion: implicit state in the stack.",
      },
      checks: [{ prompt: "Name a data structure where recursion is clearly more natural than a loop.", answer: ["tree", "nested", "graph", "directory", "file system", "json", "linked"], hint: "Something that contains smaller copies of itself." }],
      prereqs: ["call_stack"],
    },
  ],
};

const rust: DomainPack = {
  slug: "rust_ownership",
  label: "Rust ownership",
  aliases: ["rust", "rust ownership", "borrow checker", "borrowing", "lifetimes", "ownership"],
  summary: "Rust's ownership system guarantees memory safety at compile time via single ownership, moves, borrowing rules and lifetimes.",
  concepts: [
    {
      slug: "ownership_moves", label: "Ownership & moves",
      summary: "Each value has exactly one owner; assigning a non-Copy value moves it, and the old binding becomes invalid.",
      explain: {
        plain: "Every value has one owner variable. When the owner goes out of scope, the value is dropped. Assigning `let b = a;` for heap data moves ownership to b; a can no longer be used.",
        example: "```rust\nlet s1 = String::from(\"hi\");\nlet s2 = s1;          // move\n// println!(\"{}\", s1); // error: value used after move\nlet n1 = 5; let n2 = n1; // i32 is Copy: both valid\n```",
        steps: ["Identify the owner.", "Assignment/pass-by-value of non-Copy types moves.", "After a move, the source is dead.", "Small stack-only types are Copy and are duplicated instead."],
        analogy: "A physical book: handing it to a friend means you no longer have it. A photocopy (Copy types) is different.",
        contrast: "In Python/Java, `b = a` shares a reference. In Rust it transfers ownership — there is never two owners of one heap value.",
      },
      checks: [{ prompt: "Why does `let s2 = s1; println!(\"{}\", s1);` fail to compile when s1 is a String?", answer: ["move", "moved", "ownership", "invalid", "no longer"], hint: "What happened to s1's ownership?" }],
    },
    {
      slug: "borrowing", label: "Borrowing & references",
      summary: "&T lends read access; &mut T lends exclusive write access; at any time either many & or one &mut.",
      explain: {
        plain: "Instead of moving, you can lend a reference. Shared references (&T) can coexist; a mutable reference (&mut T) must be the only one alive. This prevents data races and iterator invalidation at compile time.",
        example: "```rust\nfn len(s: &String) -> usize { s.len() }\nlet s = String::from(\"hi\");\nlet n = len(&s);   // s still owned here\nlet mut v = vec![1];\nlet r = &mut v; r.push(2);   // exclusive while r is used\n```",
        steps: ["Need to read? Pass `&value`.", "Need to modify? Pass `&mut value`, and make the binding `mut`.", "Rule: many readers XOR one writer.", "Borrow ends at last use of the reference (non-lexical lifetimes)."],
        analogy: "A library book: many people can read photocopies at once, but only one person can hold the editable master, and nobody else may read while they edit.",
        contrast: "Moving hands over the value; borrowing lends it and gives it back automatically.",
      },
      checks: [{ prompt: "Can you have a `&mut v` and a `&v` alive at the same time? Why?", answer: ["no", "exclusive", "one mutable", "data race", "aliasing"], hint: "Many readers or one writer." }],
      prereqs: ["ownership_moves"],
    },
    {
      slug: "lifetimes", label: "Lifetimes",
      summary: "Lifetimes describe how long references are valid so the compiler can prove no reference outlives its data.",
      explain: {
        plain: "A lifetime is the compiler's name for 'how long this reference may be used'. Usually inferred; you annotate ('a) when a function returns a reference and the compiler can't tell which input it comes from.",
        example: "```rust\nfn longest<'a>(a: &'a str, b: &'a str) -> &'a str {\n    if a.len() > b.len() { a } else { b }\n}\n```",
        steps: ["Reference returned from a function? Compiler needs to know its source.", "Add a lifetime parameter tying output to input(s).", "The returned reference lives no longer than the shortest input."],
        analogy: "A visitor badge that expires when the host leaves the building — you can't keep the badge past that.",
        contrast: "Lifetimes don't change how long data lives; they only describe relationships so the compiler can check them.",
      },
      checks: [{ prompt: "What does `'a` in `fn f<'a>(x: &'a str) -> &'a str` promise?", answer: ["outlive", "as long as", "same", "lives", "valid", "tied"], hint: "It's a relationship between input and output." }],
      prereqs: ["borrowing"],
    },
    {
      slug: "clone_vs_move", label: "Clone, Copy and when to use them",
      summary: "clone() makes a deep copy explicitly; Copy types duplicate implicitly; reaching for clone everywhere hides design problems.",
      explain: {
        plain: "When the borrow checker complains, cloning makes it compile but costs an allocation. Prefer borrowing; clone when you genuinely need two independent values.",
        example: "```rust\nlet a = String::from(\"x\");\nlet b = a.clone(); // both valid, two heap buffers\n```",
        steps: ["First try to borrow (&).", "If you need ownership in two places, consider restructuring.", "Clone as a deliberate choice, not a reflex."],
        analogy: "Photocopying a contract: fine occasionally, wasteful if you do it for every glance.",
        contrast: "Copy is implicit and cheap (ints, bools, &T); Clone is explicit and may be expensive (String, Vec).",
      },
      checks: [{ prompt: "Why is `.clone()` sometimes a code smell in Rust?", answer: ["allocation", "cost", "borrow", "expensive", "hides", "design"], hint: "What would a borrow have cost?" }],
      prereqs: ["borrowing"],
    },
  ],
};

const python: DomainPack = {
  slug: "python",
  label: "Python",
  aliases: ["python", "python basics", "py"],
  summary: "Python is a readable, dynamically typed language with rich built-in data structures and a huge ecosystem.",
  concepts: [
    {
      slug: "py_variables_types", label: "Variables & types",
      summary: "Names are bound to objects; objects have types, names don't. int, float, str, bool, None are the basics.",
      explain: {
        plain: "In Python a variable is a name pointing at an object. The object has a type; the name can be repointed to anything.",
        example: "```python\nx = 3        # int\nx = \"three\"  # now a str, fine\nprint(type(x))\n```",
        steps: ["Assign with `=`.", "Check with `type()`.", "Convert with `int()`, `str()`, `float()`."],
        analogy: "A name tag you can move from one thing to another; the tag doesn't change what the thing is.",
        contrast: "Unlike C/Java, the variable has no fixed type — but each object always does (Python is strongly typed).",
      },
      checks: [{ prompt: "What is `\"3\" + 3` in Python and why?", answer: ["error", "typeerror", "str", "int", "concatenate"], hint: "Mixing types." }],
    },
    {
      slug: "py_lists_dicts", label: "Lists & dictionaries",
      summary: "Lists are ordered mutable sequences; dicts map keys to values with O(1) lookup.",
      explain: {
        plain: "Use a list when order matters and you index by position. Use a dict when you look things up by a key.",
        example: "```python\nnums = [3, 1, 2]; nums.append(5); nums.sort()\nages = {\"ann\": 31}; ages[\"bob\"] = 40; ages.get(\"zed\", 0)\n```",
        steps: ["Ordered collection → list.", "Lookup by key → dict.", "Iterate: `for x in nums`, `for k, v in ages.items()`."],
        analogy: "A list is a numbered queue; a dict is a phone book.",
        contrast: "`nums[0]` is position; `ages['ann']` is a key. Dict keys must be hashable (no lists as keys).",
      },
      checks: [{ prompt: "You need to count how many times each word appears in a text. List or dict, and why?", answer: ["dict", "key", "lookup", "count"], hint: "You look up by word." }],
      prereqs: ["py_variables_types"],
    },
    {
      slug: "py_functions", label: "Functions & scope",
      summary: "def creates functions; arguments can be positional/keyword/default; local scope by default.",
      explain: {
        plain: "Functions package logic. Parameters get values by position or name. Variables assigned inside are local unless declared global.",
        example: "```python\ndef greet(name, punct=\"!\"):\n    return f\"Hello {name}{punct}\"\ngreet(\"Ada\"); greet(\"Ada\", punct=\"?\")\n```",
        steps: ["`def name(params):`", "Body indented; `return` a value.", "Default args after required ones.", "Avoid mutable defaults (`def f(x=[])`)."],
        analogy: "A function is a machine with labeled input slots; defaults are pre-filled slots.",
        contrast: "Mutable default argument is created once — shared across calls. Use `None` and create inside.",
      },
      checks: [{ prompt: "What's wrong with `def add(item, bucket=[]): bucket.append(item); return bucket`?", answer: ["mutable", "shared", "same list", "once", "default"], hint: "When is the default list created?" }],
      prereqs: ["py_variables_types"],
    },
    {
      slug: "py_comprehensions", label: "Comprehensions",
      summary: "Compact expressions to build lists/dicts/sets from iterables with optional filters.",
      explain: {
        plain: "A comprehension is a loop that builds a collection in one expression: `[expr for x in xs if cond]`.",
        example: "```python\nsquares = [x*x for x in range(5)]\nevens = {x for x in nums if x % 2 == 0}\nlengths = {w: len(w) for w in words}\n```",
        steps: ["Start with the loop.", "Move the produced value to the front.", "Add `if` at the end to filter."],
        analogy: "An assembly line: items go in, each is transformed, some are rejected.",
        contrast: "Comprehensions replace `result = []; for ...: result.append(...)`, not arbitrary loops with side effects.",
      },
      checks: [{ prompt: "Rewrite as a comprehension: `out=[]\\nfor n in nums:\\n  if n>0: out.append(n*2)`", answer: ["n*2", "n * 2", "for n in nums", "if n > 0", "if n>0"], hint: "[value for item in iterable if condition]" }],
      prereqs: ["py_lists_dicts", "py_functions"],
    },
  ],
};

const git: DomainPack = {
  slug: "git",
  label: "Git",
  aliases: ["git", "version control", "github", "branches", "commits"],
  summary: "Git is a distributed version control system that tracks snapshots of a project as a graph of commits.",
  concepts: [
    {
      slug: "git_commits", label: "Commits & the three areas",
      summary: "Working tree → staging area (add) → repository (commit); a commit is a snapshot with a parent.",
      explain: {
        plain: "You edit files (working tree), choose what to include (`git add` → staging area), then record a snapshot (`git commit`). Each commit points to its parent, forming history.",
        example: "```bash\ngit status\ngit add src/app.py\ngit commit -m \"Fix login bug\"\ngit log --oneline\n```",
        steps: ["Edit.", "`git add` what belongs in this change.", "`git commit -m` with a clear message.", "Inspect with `git log`."],
        analogy: "Staging is the photo frame: you arrange what will be in the picture before you press the shutter (commit).",
        contrast: "A commit is a full snapshot, not a diff — Git computes diffs on demand.",
      },
      checks: [{ prompt: "Why does Git have a staging area instead of committing all changes directly?", answer: ["choose", "select", "partial", "part of", "control", "group"], hint: "Think about committing only some of your edits." }],
    },
    {
      slug: "git_branches", label: "Branches & merging",
      summary: "A branch is a movable pointer to a commit; merging combines histories, possibly with conflicts.",
      explain: {
        plain: "A branch is just a name pointing at a commit. Committing moves the pointer. Merging brings another branch's commits into yours.",
        example: "```bash\ngit switch -c feature\n# ... commits ...\ngit switch main\ngit merge feature\n```",
        steps: ["Create branch for a piece of work.", "Commit on it.", "Switch back and merge.", "Resolve conflicts if both sides changed the same lines."],
        analogy: "A branch is a bookmark that moves forward as you add pages.",
        contrast: "Branches are cheap pointers, not copies of the project — unlike older VCSs.",
      },
      checks: [{ prompt: "What actually is a branch in Git's data model?", answer: ["pointer", "reference", "ref", "name", "commit"], hint: "It's tiny." }],
      prereqs: ["git_commits"],
    },
    {
      slug: "git_remotes", label: "Remotes, push & pull",
      summary: "Remotes are other copies of the repo; fetch downloads, pull = fetch+merge, push uploads your commits.",
      explain: {
        plain: "`origin` is a nickname for a remote repository. `fetch` gets its commits without touching your branches; `pull` also merges; `push` sends yours up.",
        example: "```bash\ngit fetch origin\ngit pull            # fetch + merge into current\ngit push origin main\n```",
        steps: ["`git fetch` to see what changed.", "Merge or rebase onto it.", "`git push` your commits.", "If rejected, pull first."],
        analogy: "Fetch = checking the mailbox; pull = reading and filing the letters; push = sending your own.",
        contrast: "`fetch` is always safe; `pull` modifies your branch.",
      },
      checks: [{ prompt: "What is the difference between `git fetch` and `git pull`?", answer: ["merge", "fetch only", "download", "doesn't change", "integrates"], hint: "One of them touches your branch." }],
      prereqs: ["git_branches"],
    },
  ],
};

const sql: DomainPack = {
  slug: "sql",
  label: "SQL",
  aliases: ["sql", "databases", "postgres", "postgresql", "queries", "joins"],
  summary: "SQL is the declarative language for querying and modifying relational databases.",
  concepts: [
    {
      slug: "sql_select", label: "SELECT, WHERE, ORDER BY",
      summary: "Choose columns from a table, filter rows, and sort results.",
      explain: {
        plain: "You describe what you want, not how. `SELECT` picks columns, `FROM` the table, `WHERE` filters rows, `ORDER BY` sorts.",
        example: "```sql\nSELECT name, age FROM users\nWHERE age >= 18\nORDER BY age DESC\nLIMIT 10;\n```",
        steps: ["FROM: which table.", "WHERE: which rows.", "SELECT: which columns.", "ORDER BY / LIMIT last."],
        analogy: "Ordering at a deli: 'give me the ham and cheese (columns) from the cold section (table), only the fresh ones (where), cheapest first (order by)'.",
        contrast: "Logical execution order is FROM → WHERE → SELECT → ORDER BY, not the order you write it.",
      },
      checks: [{ prompt: "Why can't you use a column alias defined in SELECT inside the WHERE clause?", answer: ["where", "before", "order", "evaluated", "first", "select runs after"], hint: "Think about logical execution order." }],
    },
    {
      slug: "sql_joins", label: "JOINs",
      summary: "Combine rows from tables on a matching condition; INNER keeps matches, LEFT keeps all left rows.",
      explain: {
        plain: "A join pairs rows from two tables where a condition holds. INNER JOIN drops rows without a match; LEFT JOIN keeps every left row and fills NULLs.",
        example: "```sql\nSELECT o.id, u.name\nFROM orders o\nLEFT JOIN users u ON u.id = o.user_id;\n```",
        steps: ["Identify the key linking the tables.", "Decide: must both sides match (INNER) or keep all of one side (LEFT)?", "Write `ON` with the key equality.", "Check row count against expectation."],
        analogy: "Matching socks from two drawers: INNER keeps only pairs; LEFT keeps every sock from the left drawer, paired or not.",
        contrast: "A missing `ON` condition gives a cross product — row count explodes.",
      },
      checks: [{ prompt: "You want every customer, including those with zero orders. Which join?", answer: ["left", "outer"], hint: "Keep all rows from one side." }],
      prereqs: ["sql_select"],
    },
    {
      slug: "sql_group_by", label: "GROUP BY & aggregates",
      summary: "Collapse rows into groups and compute COUNT/SUM/AVG per group; HAVING filters groups.",
      explain: {
        plain: "GROUP BY folds rows sharing the same value into one row; aggregates summarize each group. HAVING is WHERE for groups.",
        example: "```sql\nSELECT user_id, COUNT(*) AS n\nFROM orders\nGROUP BY user_id\nHAVING COUNT(*) > 5;\n```",
        steps: ["Pick grouping columns.", "Every selected column is either grouped or aggregated.", "Filter groups with HAVING."],
        analogy: "Sorting coins into piles by denomination, then counting each pile.",
        contrast: "WHERE filters rows before grouping; HAVING filters after.",
      },
      checks: [{ prompt: "What's the difference between WHERE and HAVING?", answer: ["group", "before", "after", "aggregate"], hint: "One runs before grouping." }],
      prereqs: ["sql_select"],
    },
  ],
};

export const SEED_PACKS: DomainPack[] = [bash, oop, recursion, rust, python, git, sql];
