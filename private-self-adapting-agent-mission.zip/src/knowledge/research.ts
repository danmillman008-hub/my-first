import { db } from "@/db";
import { domainCache, concepts, conceptEdges, type DomainPack, type ConceptSpec } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { SEED_PACKS } from "./seeds";
import { getLLM, parseJsonObject } from "@/llm";

export function slugify(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 60);
}

export function findSeedPack(query: string): DomainPack | null {
  const q = query.toLowerCase();
  let best: { pack: DomainPack; len: number } | null = null;
  for (const pack of SEED_PACKS) {
    for (const alias of pack.aliases ?? [pack.slug]) {
      const re = new RegExp(`(^|[^a-z])${alias.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^a-z]|$)`, "i");
      if (re.test(q) && (!best || alias.length > best.len)) best = { pack, len: alias.length };
    }
  }
  return best?.pack ?? null;
}

const WIKI_HEADERS = { "user-agent": "LearningAgent/1.0 (educational tutor; contact: none)", accept: "application/json" };

async function wikiJson<T>(url: string): Promise<T | null> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 8000);
    const res = await fetch(url, { headers: WIKI_HEADERS, signal: ctrl.signal });
    clearTimeout(t);
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

function stripHtml(s: string): string {
  return s.replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();
}

const STOP = new Set("the and for that with this from are was were which their have has been into also such more most than other some when where these those they them then there been being can may often used use using while both each between about over under after before during through within without because however example examples typically usually generally commonly called known form forms type types part parts process processes system systems".split(" "));

function keywordsOf(text: string, n = 5): string[] {
  const freq = new Map<string, number>();
  for (const w of text.toLowerCase().replace(/[^a-z0-9\- ]/g, " ").split(/\s+/)) {
    if (w.length < 5 || STOP.has(w) || /^\d+$/.test(w)) continue;
    freq.set(w, (freq.get(w) ?? 0) + 1);
  }
  return [...freq.entries()].sort((a, b) => b[1] - a[1] || b[0].length - a[0].length).slice(0, n).map((e) => e[0]);
}

const SKIP_SECTIONS = /^(see also|references|external links|notes|further reading|bibliography|sources|citations|gallery|footnotes|explanatory notes)$/i;

/**
 * Discover a domain from Wikipedia: the article's own sections become candidate
 * concepts (label + summary + explanation), with keyword checks derived from
 * the text so understanding can be verified even offline.
 */
export async function researchWikipedia(topic: string): Promise<DomainPack | null> {
  const search = await wikiJson<[string, string[], string[], string[]]>(
    `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(topic)}&limit=1&namespace=0&format=json`,
  );
  const title = search?.[1]?.[0];
  if (!title) return null;
  const data = await wikiJson<{ query: { pages: Record<string, { title: string; extract?: string }> } }>(
    `https://en.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&redirects=1&titles=${encodeURIComponent(title)}&format=json`,
  );
  let page = data ? Object.values(data.query.pages)[0] : null;
  if (!page?.extract) {
    // Rate-limited or empty: fall back to the (cheaper) intro-only extract
    const intro = await wikiJson<{ query: { pages: Record<string, { title: string; extract?: string }> } }>(
      `https://en.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&exintro=1&redirects=1&titles=${encodeURIComponent(title)}&format=json`,
    );
    page = intro ? Object.values(intro.query.pages)[0] : null;
  }
  const extract = page?.extract;
  if (!extract || extract.length < 200) return null;
  const rootSlug = slugify(page!.title);
  const [lead, ...rest] = extract.split(/\n(?===[^=])/);
  const leadText = stripHtml(lead).replace(/\s+/g, " ").trim();
  const sentences = (t: string, n: number) => t.split(/(?<=[.!?])\s+(?=[A-Z])/).slice(0, n).join(" ");
  const rootConcept: ConceptSpec = {
    slug: rootSlug,
    label: page!.title,
    summary: sentences(leadText, 2),
    explain: { plain: sentences(leadText, 5).slice(0, 900) },
    checks: [{ prompt: `In your own words, what is ${page!.title.toLowerCase()} and what is it for?`, answer: keywordsOf(leadText, 6), hint: "Think about what goes in, what comes out, and why it matters." }],
  };
  const sectionConcepts: ConceptSpec[] = [];
  for (const chunk of rest) {
    const m = chunk.match(/^==\s*([^=]+?)\s*==\n([\s\S]*)$/);
    if (!m) continue;
    const label = m[1].trim();
    if (SKIP_SECTIONS.test(label)) continue;
    // Body text: drop sub-headers, keep paragraphs
    const body = m[2].replace(/^===+[^=]+===+\s*$/gm, "").replace(/\s+/g, " ").trim();
    if (body.length < 200) continue;
    const slug = slugify(label);
    if (slug === rootSlug) continue;
    sectionConcepts.push({
      slug,
      label,
      summary: sentences(body, 2).slice(0, 300),
      explain: { plain: sentences(body, 5).slice(0, 900) },
      checks: [{ prompt: `Can you explain ${label.toLowerCase()} in the context of ${page!.title.toLowerCase()}, in a sentence or two?`, answer: keywordsOf(body, 6) }],
      related: [rootSlug],
      prereqs: [rootSlug],
    });
    if (sectionConcepts.length >= 8) break;
  }
  return {
    slug: slugify(topic),
    label: page!.title,
    summary: rootConcept.summary,
    aliases: [topic.toLowerCase(), page!.title.toLowerCase()],
    concepts: [rootConcept, ...sectionConcepts],
  };
}

async function researchWithLLM(topic: string): Promise<DomainPack | null> {
  const llm = getLLM();
  if (!llm) return null;
  const prompt = `You are building a compact concept map for tutoring the topic: "${topic}".
Return JSON: {"label": string, "summary": string, "concepts": [{"slug": snake_case, "label": string, "summary": one sentence,
"prereqs": [slugs from this list], "explain": {"plain": 2-3 sentences, "example": a short concrete example (code if applicable), "analogy": one sentence, "steps": [3-4 short steps]},
"checks": [{"prompt": a short question a tutor could ask to verify understanding, "answer": [3-6 keywords a correct answer would likely contain], "hint": string}]}]}
Include 5-8 concepts ordered from foundational to advanced. Only JSON.`;
  try {
    const raw = await llm.complete({ messages: [{ role: "user", content: prompt }], json: true, maxTokens: 2200, temperature: 0.3 });
    const parsed = parseJsonObject<{ label?: string; summary?: string; concepts?: ConceptSpec[] }>(raw);
    if (!parsed?.concepts?.length) return null;
    const known = new Set(parsed.concepts.map((c) => c.slug));
    return {
      slug: slugify(topic),
      label: parsed.label ?? topic,
      summary: parsed.summary ?? "",
      aliases: [topic.toLowerCase()],
      concepts: parsed.concepts.map((c) => ({
        ...c,
        slug: slugify(c.slug || c.label),
        prereqs: (c.prereqs ?? []).filter((p) => known.has(p)),
      })),
    };
  } catch {
    return null;
  }
}

/**
 * Resolve a topic to a domain pack, researching when needed.
 * Order: seed → shared cache → LLM → Wikipedia → learner-co-created minimal pack.
 */
export async function resolveDomain(topic: string): Promise<{ pack: DomainPack; source: string }> {
  const seed = findSeedPack(topic);
  if (seed) return { pack: seed, source: "seed" };
  const slug = slugify(topic);
  const cached = await db.select().from(domainCache).where(eq(domainCache.slug, slug)).limit(1);
  if (cached[0]) return { pack: cached[0].pack, source: cached[0].source };

  let pack: DomainPack | null = null;
  let source = "learner";
  const viaLLM = await researchWithLLM(topic);
  if (viaLLM) {
    pack = viaLLM;
    source = "llm";
  } else {
    const viaWiki = await researchWikipedia(topic);
    if (viaWiki) {
      pack = viaWiki;
      source = "wikipedia";
    }
  }
  if (!pack) {
    pack = {
      slug,
      label: topic,
      summary: `A topic introduced by the learner: ${topic}.`,
      aliases: [topic.toLowerCase()],
      concepts: [{ slug, label: topic, summary: `The learner wants to learn about ${topic}.` }],
    };
  }
  await db
    .insert(domainCache)
    .values({ slug, label: pack.label, source, pack })
    .onConflictDoNothing();
  return { pack, source };
}

/** Make sure a learner's graph contains the concepts/edges of a pack (idempotent). */
export async function seedGraphForLearner(learnerId: string, pack: DomainPack, origin: string): Promise<number> {
  const existing = await db
    .select({ slug: concepts.slug })
    .from(concepts)
    .where(and(eq(concepts.learnerId, learnerId), eq(concepts.domain, pack.slug)));
  const have = new Set(existing.map((e) => e.slug));
  let added = 0;
  for (const c of pack.concepts) {
    if (have.has(c.slug)) continue;
    await db.insert(concepts).values({
      learnerId,
      slug: c.slug,
      label: c.label,
      domain: pack.slug,
      summary: c.summary,
      status: "active",
      origin,
    });
    added++;
  }
  if (added > 0) {
    for (const c of pack.concepts) {
      for (const p of c.prereqs ?? []) {
        await db.insert(conceptEdges).values({ learnerId, fromSlug: p, toSlug: c.slug, relation: "prerequisite", weight: 0.7, evidenceCount: 0, origin }).onConflictDoNothing();
      }
      for (const r of c.related ?? []) {
        await db.insert(conceptEdges).values({ learnerId, fromSlug: r, toSlug: c.slug, relation: "related", weight: 0.4, evidenceCount: 0, origin }).onConflictDoNothing();
      }
    }
  }
  return added;
}

/** Get pack material (explain/checks) for a domain slug, from seeds or cache. */
export async function getPack(domainSlug: string): Promise<DomainPack | null> {
  const seed = SEED_PACKS.find((p) => p.slug === domainSlug);
  if (seed) return seed;
  const cached = await db.select().from(domainCache).where(eq(domainCache.slug, domainSlug)).limit(1);
  return cached[0]?.pack ?? null;
}

export function findConceptInPack(pack: DomainPack, text: string): ConceptSpec | null {
  const t = text.toLowerCase();
  // Words that name the domain itself must not select a concept ("recursion" ≠ "recursion vs iteration")
  const domainWords = new Set<string>();
  [pack.label, pack.slug].forEach((a) => a.toLowerCase().split(/[^a-z0-9+#]+/).forEach((w) => w && domainWords.add(w)));
  let best: { c: ConceptSpec; score: number } | null = null;
  for (const c of pack.concepts) {
    const terms = new Set<string>();
    c.label.toLowerCase().split(/[^a-z0-9+#]+/).forEach((w) => w.length > 2 && !domainWords.has(w) && terms.add(w));
    c.slug.split("_").forEach((w) => w.length > 2 && !domainWords.has(w) && terms.add(w));
    let score = 0;
    for (const term of terms) if (t.includes(term)) score += term.length > 4 ? 2 : 1;
    if (t.includes(c.label.toLowerCase())) score += 4;
    if (terms.size === 0) score = 0;
    if (score > 0 && (!best || score > best.score)) best = { c, score };
  }
  return best && best.score >= 2 ? best.c : null;
}

/** Short factual lookup for detours: cached, using the light REST summary endpoint. */
export async function quickLookup(subject: string): Promise<{ title: string; text: string } | null> {
  const slug = `q_${slugify(subject)}`;
  const cached = await db.select().from(domainCache).where(eq(domainCache.slug, slug)).limit(1);
  if (cached[0]) {
    const c = cached[0].pack.concepts[0];
    return c?.explain?.plain ? { title: c.label, text: c.explain.plain } : null;
  }
  const search = await wikiJson<[string, string[], string[], string[]]>(
    `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(subject)}&limit=1&namespace=0&format=json`,
  );
  const title = search?.[1]?.[0];
  if (!title) return null;
  const summary = await wikiJson<{ title: string; extract: string }>(
    `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title.replace(/ /g, "_"))}`,
  );
  if (!summary?.extract) return null;
  const text = stripHtml(summary.extract);
  await db
    .insert(domainCache)
    .values({ slug, label: summary.title, source: "wikipedia", pack: { slug, label: summary.title, summary: text.slice(0, 200), concepts: [{ slug: slugify(summary.title), label: summary.title, summary: text.slice(0, 200), explain: { plain: text } }] } })
    .onConflictDoNothing();
  return { title: summary.title, text };
}
