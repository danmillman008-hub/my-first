import {
  pgTable,
  text,
  serial,
  integer,
  real,
  boolean,
  timestamp,
  jsonb,
  index,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Learners & sessions                                                  */
/* ------------------------------------------------------------------ */

export const learners = pgTable("learners", {
  id: text("id").primaryKey(),
  name: text("name").notNull().default("Learner"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
  // Free-form durable notes the agent wants to keep about goals etc.
  goals: jsonb("goals").$type<GoalRecord[]>().notNull().default([]),
});

export type GoalRecord = {
  text: string;
  domain?: string;
  statedAt: string;
  status: "active" | "paused" | "done";
};

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }).notNull().defaultNow(),
    turnCount: integer("turn_count").notNull().default(0),
    summary: text("summary"),
    topics: jsonb("topics").$type<string[]>().notNull().default([]),
    state: jsonb("state").$type<SessionState>().notNull().default({ turnsSinceProbe: 99, probes: 0, explainedThisSession: [] }),
  },
  (t) => [index("sessions_learner_idx").on(t.learnerId, t.lastActiveAt)],
);

export type SessionState = {
  domain?: string;
  concept?: string;
  activity?: string;
  lastStrategy?: string;
  lastMove?: string;
  pending?: { concept: string; domain: string; prompt: string; answer: string[]; kind: string; hint?: string } | null;
  turnsSinceProbe: number;
  probes: number;
  explainedThisSession: string[];
  detourTopic?: string;
};

export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id").notNull(),
    role: text("role").notNull(), // 'user' | 'agent'
    content: text("content").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    // Agent trace for transparency & evaluation (strategy chosen, memory used…)
    meta: jsonb("meta").$type<AgentTrace | null>(),
  },
  (t) => [index("messages_session_idx").on(t.sessionId, t.id)],
);

export type AgentTrace = {
  move: string; // what the agent decided to do (answer, explain, probe, challenge, clarify, ...)
  strategy?: string; // explanation style used (concrete_example | concise | step_by_step | analogy | contrast)
  domain?: string;
  concept?: string;
  activity?: string;
  probe?: { kind: string; concept: string; reason: string } | null;
  memoryUsed: { beliefs: number[]; observations: number; concepts: string[] };
  reasons: string[];
  provider: string;
};

/* ------------------------------------------------------------------ */
/* Working memory: lightly interpreted observations                     */
/* ------------------------------------------------------------------ */

export const observations = pgTable(
  "observations",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id").notNull(),
    messageId: integer("message_id"),
    // What happened (behavioral): question | request | claim | code_submitted | attempt |
    // reaction | topic_switch | disagreement | preference_statement | goal | outcome | casual
    kind: text("kind").notNull(),
    content: text("content").notNull(), // plain description of what happened
    // Tentative meaning. Never durable by itself.
    interpretation: text("interpretation"),
    context: jsonb("context").$type<ObsContext>().notNull().default({}),
    // Structured payload used by consolidation (e.g. {signal:'wants_example'} or {correct:true,concept:'x'})
    payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
    strength: real("strength").notNull().default(0.5),
    consolidated: boolean("consolidated").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("obs_learner_idx").on(t.learnerId, t.createdAt),
    index("obs_session_idx").on(t.sessionId),
  ],
);

export type ObsContext = {
  domain?: string;
  concept?: string;
  activity?: string; // studying | coding | debugging | reviewing | exploring
  strategy?: string; // strategy the agent used just before this observation
};

/* ------------------------------------------------------------------ */
/* Long-term memory: beliefs (a prior, not a verdict)                   */
/* ------------------------------------------------------------------ */

export const beliefs = pgTable(
  "beliefs",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    // preference | strategy | pattern | goal | fact | knowledge_claim
    kind: text("kind").notNull(),
    // What the belief is about, e.g. 'explanation_style', 'pace', 'strategy:concrete_example'
    subject: text("subject").notNull(),
    // Contextual scope: '*' (global), 'domain:bash', 'activity:debugging', 'domain:bash/activity:coding'
    scope: text("scope").notNull().default("*"),
    value: text("value").notNull(), // e.g. 'concrete_examples' | 'concise' | 'works' | 'fails'
    statement: text("statement").notNull(), // human-readable
    confidence: real("confidence").notNull().default(0.3),
    supportCount: real("support_count").notNull().default(0),
    contradictionCount: real("contradiction_count").notNull().default(0),
    // hypothesis (weak) | active (consolidated) | dormant (stale) | retired (superseded/invalidated)
    status: text("status").notNull().default("hypothesis"),
    evidenceIds: jsonb("evidence_ids").$type<number[]>().notNull().default([]),
    sessionsSeen: jsonb("sessions_seen").$type<string[]>().notNull().default([]),
    history: jsonb("history").$type<BeliefRevision[]>().notNull().default([]),
    firstSeenAt: timestamp("first_seen_at", { withTimezone: true }).notNull().defaultNow(),
    lastConfirmedAt: timestamp("last_confirmed_at", { withTimezone: true }).notNull().defaultNow(),
    lastContradictedAt: timestamp("last_contradicted_at", { withTimezone: true }),
    invalidatedAt: timestamp("invalidated_at", { withTimezone: true }),
    supersededBy: integer("superseded_by"),
  },
  (t) => [index("beliefs_learner_idx").on(t.learnerId, t.status)],
);

export type BeliefRevision = {
  at: string;
  event: "created" | "confirmed" | "contradicted" | "promoted" | "demoted" | "narrowed" | "retired" | "reactivated";
  note?: string;
  confidence: number;
};

/* ------------------------------------------------------------------ */
/* Evolving concept graph (per learner)                                 */
/* ------------------------------------------------------------------ */

export const concepts = pgTable(
  "concepts",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    slug: text("slug").notNull(),
    label: text("label").notNull(),
    domain: text("domain").notNull(),
    summary: text("summary"),
    // emerging (mentioned, not yet structural) | active | dormant
    status: text("status").notNull().default("emerging"),
    origin: text("origin").notNull().default("conversation"), // seed | research | conversation
    // Recorded, but explicitly NOT a proxy for mastery/importance.
    touchCount: integer("touch_count").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastTouchedAt: timestamp("last_touched_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("concepts_learner_slug_idx").on(t.learnerId, t.slug)],
);

export const conceptEdges = pgTable(
  "concept_edges",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    fromSlug: text("from_slug").notNull(),
    toSlug: text("to_slug").notNull(),
    // prerequisite (from is needed for to) | related | part_of | contrasts | confused_with
    relation: text("relation").notNull(),
    weight: real("weight").notNull().default(0.5),
    evidenceCount: integer("evidence_count").notNull().default(0),
    origin: text("origin").notNull().default("research"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("edges_learner_idx").on(t.learnerId, t.fromSlug, t.toSlug)],
);

export const conceptStates = pgTable(
  "concept_states",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    slug: text("slug").notNull(),
    // Bayesian knowledge estimate driven by demonstrated evidence only
    pKnown: real("p_known").notNull().default(0.2),
    // What the learner has claimed about themselves (kept separate from demonstrated evidence)
    claimed: text("claimed"), // 'knows' | 'unsure' | 'does_not_know'
    claimedAt: timestamp("claimed_at", { withTimezone: true }),
    demonstratedCorrect: integer("demonstrated_correct").notNull().default(0),
    demonstratedIncorrect: integer("demonstrated_incorrect").notNull().default(0),
    evidence: jsonb("evidence").$type<KnowledgeEvidence[]>().notNull().default([]),
    lastEvidenceAt: timestamp("last_evidence_at", { withTimezone: true }),
    lastExplainedAt: timestamp("last_explained_at", { withTimezone: true }),
  },
  (t) => [index("states_learner_slug_idx").on(t.learnerId, t.slug)],
);

export type KnowledgeEvidence = {
  at: string;
  kind: "answer" | "code" | "explanation" | "application" | "self_report";
  correct: boolean;
  strategy?: string;
  observationId?: number;
};

/* ------------------------------------------------------------------ */
/* Domain research cache (shared across learners)                       */
/* ------------------------------------------------------------------ */

export const domainCache = pgTable("domain_cache", {
  slug: text("slug").primaryKey(),
  label: text("label").notNull(),
  source: text("source").notNull(), // seed | llm | wikipedia | learner
  pack: jsonb("pack").$type<DomainPack>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type ConceptSpec = {
  slug: string;
  label: string;
  summary: string;
  // Optional teaching material (offline engine uses these; LLM path generates on the fly)
  explain?: { plain?: string; example?: string; steps?: string[]; analogy?: string; contrast?: string };
  checks?: { prompt: string; answer: string[]; hint?: string }[]; // tiny probes / exercises
  prereqs?: string[];
  related?: string[];
};

export type DomainPack = {
  slug: string;
  label: string;
  summary: string;
  concepts: ConceptSpec[];
  aliases?: string[];
};

/* ------------------------------------------------------------------ */
/* Lab results                                                          */
/* ------------------------------------------------------------------ */

export const labRuns = pgTable("lab_runs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  config: jsonb("config").$type<Record<string, unknown>>().notNull().default({}),
  results: jsonb("results").$type<Record<string, unknown>>().notNull().default({}),
});
