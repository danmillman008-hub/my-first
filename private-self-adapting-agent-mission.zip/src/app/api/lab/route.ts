import { NextResponse } from "next/server";
import { db } from "@/db";
import { labRuns } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const runs = await db.select().from(labRuns).orderBy(desc(labRuns.id)).limit(10);
  return NextResponse.json({ runs });
}
