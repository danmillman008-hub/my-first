import { NextResponse } from "next/server";
import { runTurn } from "@/agent/run";
import { getLearnerId, learnerCookie } from "@/lib/identity";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { text?: string; sessionId?: string; simulatedNow?: string };
  const text = (body.text ?? "").trim();
  if (!text) return NextResponse.json({ error: "text required" }, { status: 400 });
  const { id, isNew } = await getLearnerId();
  try {
    const now = body.simulatedNow ? new Date(body.simulatedNow) : undefined;
    const result = await runTurn({ learnerId: id, text: text.slice(0, 8000), sessionId: body.sessionId, now });
    const res = NextResponse.json(result);
    if (isNew) res.cookies.set(learnerCookie(id));
    return res;
  } catch (e) {
    console.error("chat error", e);
    return NextResponse.json({ error: "The tutor hit an internal error. Please try again." }, { status: 500 });
  }
}
