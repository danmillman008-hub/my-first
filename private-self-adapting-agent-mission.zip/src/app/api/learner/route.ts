import { NextResponse } from "next/server";
import { db } from "@/db";
import { learners } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getLearnerId, learnerCookie } from "@/lib/identity";
import { ensureLearner } from "@/agent/run";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { name?: string; reset?: boolean };
  if (body.reset) {
    const id = `l_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
    const res = NextResponse.json({ id });
    res.cookies.set(learnerCookie(id));
    return res;
  }
  const { id, isNew } = await getLearnerId();
  await ensureLearner(id);
  if (body.name) await db.update(learners).set({ name: body.name.slice(0, 60) }).where(eq(learners.id, id));
  const res = NextResponse.json({ id, name: body.name });
  if (isNew) res.cookies.set(learnerCookie(id));
  return res;
}
