import { NextResponse } from "next/server";
import { db } from "@/db";
import { beliefs, concepts, conceptStates, conceptEdges, messages, observations, sessions, learners } from "@/db/schema";
import { and, desc, eq, ne } from "drizzle-orm";
import { getLearnerId, learnerCookie } from "@/lib/identity";
import { effectiveConfidence } from "@/memory";
import { getLLM } from "@/llm";

export const dynamic = "force-dynamic";

export async function GET() {
  const { id, isNew } = await getLearnerId();
  const now = new Date();
  const [learner] = await db.select().from(learners).where(eq(learners.id, id)).limit(1);
  const sess = await db.select().from(sessions).where(eq(sessions.learnerId, id)).orderBy(desc(sessions.lastActiveAt)).limit(20);
  const recentMsgs = await db.select().from(messages).where(eq(messages.learnerId, id)).orderBy(desc(messages.id)).limit(80);
  const bel = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, id), ne(beliefs.status, "retired"))).orderBy(desc(beliefs.confidence));
  const retired = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, id), eq(beliefs.status, "retired"))).orderBy(desc(beliefs.id)).limit(10);
  const cons = await db.select().from(concepts).where(eq(concepts.learnerId, id));
  const states = await db.select().from(conceptStates).where(eq(conceptStates.learnerId, id));
  const edges = await db.select().from(conceptEdges).where(eq(conceptEdges.learnerId, id));
  const obs = await db.select().from(observations).where(eq(observations.learnerId, id)).orderBy(desc(observations.id)).limit(25);
  const res = NextResponse.json({
    learner: learner ?? { id, name: "Learner", goals: [] },
    provider: getLLM()?.name ?? "offline engine",
    sessions: sess,
    messages: recentMsgs.reverse(),
    beliefs: bel.map((b) => ({ ...b, effective: effectiveConfidence(b, now) })),
    retiredBeliefs: retired,
    concepts: cons.map((c) => ({ ...c, state: states.find((s) => s.slug === c.slug) ?? null })),
    edges,
    observations: obs.reverse(),
  });
  if (isNew) res.cookies.set(learnerCookie(id));
  return res;
}
