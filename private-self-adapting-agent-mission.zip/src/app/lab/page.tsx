import { db } from "@/db";
import { labRuns } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Summary = Record<string, number | string | null | boolean[]>;

const METRICS: { key: string; label: string; hint: string }[] = [
  { key: "styleMatchEarly", label: "Style match (early ⅓)", hint: "fraction of explanations delivered in the learner's hidden preferred style" },
  { key: "styleMatchLate", label: "Style match (late ⅓)", hint: "same, after experience accumulated — adaptation shows as a rise" },
  { key: "landedRate", label: "Explanations landed", hint: "hidden-truth outcome: explanation understood" },
  { key: "lateLandedRate", label: "Landed (late ⅓)", hint: "" },
  { key: "conceptsMastered", label: "Concepts mastered / learner", hint: "hidden mastery ≥ 0.5" },
  { key: "probeRate", label: "Checks per turn", hint: "how often the tutor interrupts to verify — lower is less intrusive" },
  { key: "prefBeliefAccuracy", label: "Preference beliefs correct", hint: "agent's top domain-scoped preference vs hidden truth" },
  { key: "falseActivePrefBeliefs", label: "False active beliefs / learner", hint: "" },
  { key: "brier", label: "Knowledge calibration (Brier ↓)", hint: "agent p_known vs hidden mastery" },
  { key: "driftLag", label: "Drift lag (explanations)", hint: "explanations needed to re-adapt after preference drift" },
  { key: "activeBeliefsPerLearner", label: "Active beliefs / learner", hint: "long-term memory stays small and meaningful" },
  { key: "observationsPerLearner", label: "Observations / learner", hint: "working memory volume" },
];

export default async function LabPage() {
  const runs = await db.select().from(labRuns).orderBy(desc(labRuns.id)).limit(40);
  // Latest run per name
  const latest = new Map<string, (typeof runs)[number]>();
  for (const r of runs) if (!latest.has(r.name)) latest.set(r.name, r);
  const ordered = ["abl_none", "abl_no_ltm", "abl_stm_only", "abl_no_adapt", "abl_no_probe"].map((n) => latest.get(n)).filter(Boolean) as (typeof runs)[number][];
  const others = [...latest.values()].filter((r) => !ordered.includes(r));
  const cols = [...ordered, ...others].slice(0, 8);
  return (
    <main className="mx-auto max-w-6xl px-4 py-8">
      <a href="/" className="text-xs text-slate-500 underline">← back to tutor</a>
      <h1 className="mt-2 text-2xl font-semibold">Laboratory results</h1>
      <p className="mt-1 max-w-3xl text-sm text-slate-600">
        Synthetic learners with <em>hidden</em> traits (per-domain style preferences, learning rates, self-report bias, drift, noise, topic switching, long gaps) talk to the real agent over many sessions.
        Metrics compare the agent&apos;s behaviour and internal model against hidden truth it never sees. Ablations remove components to check they actually matter.
      </p>
      {cols.length === 0 ? (
        <p className="mt-6 text-sm text-slate-500">No runs yet. Run <code>npx tsx --env-file=.env src/lab/run.ts</code>.</p>
      ) : (
        <div className="mt-6 overflow-x-auto rounded-xl border border-slate-200 bg-white">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
                <th className="px-3 py-2">Metric</th>
                {cols.map((r) => (
                  <th key={r.id} className="px-3 py-2">
                    {r.name.replace(/^abl_/, "").replace(/_/g, " ")}
                    <div className="text-[10px] font-normal normal-case text-slate-400">{new Date(r.createdAt).toLocaleString()} · {(r.results.summary as Summary)?.turns as number} turns</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {METRICS.map((m) => (
                <tr key={m.key} className="border-t border-slate-100">
                  <td className="px-3 py-2">
                    <div className="font-medium text-slate-800">{m.label}</div>
                    {m.hint && <div className="text-[11px] text-slate-400">{m.hint}</div>}
                  </td>
                  {cols.map((r) => {
                    const v = (r.results.summary as Summary)?.[m.key];
                    return (
                      <td key={r.id} className="px-3 py-2 font-mono text-slate-700">
                        {typeof v === "number" ? v.toFixed(3) : v == null ? "—" : String(v)}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}
