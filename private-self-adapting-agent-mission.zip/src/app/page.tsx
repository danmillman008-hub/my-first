import Tutor from "@/components/Tutor";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-slate-50">
      <Tutor />
    </main>
  );
}
