import { db } from "@/db";
import { learners, sessions, messages, type AgentTrace, type SessionState, type ObsContext, type ConceptSpec, type DomainPack } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { perceive, type Perception } from "./perceive";
import { buildContext, consolidate, recordObservations, markExplained, touchConcept, reinforceEdge, applyDormancy, applyConceptDormancy, noteClaimBehaviorGap, type ContextPack, type Style } from "@/memory";
import { resolveDomain, seedGraphForLearner, getPack, findConceptInPack, findSeedPack, quickLookup, slugify } from "@/knowledge/research";
import { chooseStyle, nextConcept, probeDecision, pickCheck, weakPrerequisite, type Plan } from "./policy";
import { compose, renderExplanation, resumeHint } from "./compose";

function pick<T>(arr: T[], seed: number): T {
  return arr[Math.abs(seed) % arr.length];
}
import { getLLM } from "@/llm";

export type TurnResult = { reply: string; trace: AgentTrace; messageId: number; sessionId: string };

const DEFAULT_STATE: SessionState = { turnsSinceProbe: 99, probes: 0, explainedThisSession: [] };

export async function ensureLearner(learnerId: string, name?: string) {
  const rows = await db.select().from(learners).where(eq(learners.id, learnerId)).limit(1);
  if (!rows[0]) await db.insert(learners).values({ id: learnerId, name: name ?? "Learner" });
  return rows[0];
}

/** Sessions are continuous conversation; a new session starts after a long silence (>4h) or on explicit request. */
export async function getOrCreateSession(learnerId: string, now: Date, sessionId?: string): Promise<typeof sessions.$inferSelect> {
  if (sessionId) {
    const rows = await db.select().from(sessions).where(and(eq(sessions.id, sessionId), eq(sessions.learnerId, learnerId))).limit(1);
    if (rows[0]) return rows[0];
  }
  const latest = await db.select().from(sessions).where(eq(sessions.learnerId, learnerId)).orderBy(desc(sessions.lastActiveAt)).limit(1);
  if (latest[0] && now.getTime() - latest[0].lastActiveAt.getTime() < 4 * 3600_000) return latest[0];
  const id = `s_${now.getTime().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
  // Continuity: a new session inherits the thread (domain/concept/last approach) but not transient state.
  const prev = latest[0]?.state;
  const carried: SessionState = { ...DEFAULT_STATE, domain: prev?.domain, concept: prev?.concept, lastStrategy: prev?.lastStrategy };
  const [created] = await db.insert(sessions).values({ id, learnerId, startedAt: now, lastActiveAt: now, state: carried }).returning();
  return created;
}

function inferActivity(text: string, p: Perception): string {
  if (p.hasCode && /\b(?:error|fails?|not working|bug|broken|wrong|exception|traceback|stack ?trace|why does(?:n't| not))\b/i.test(text)) return "debugging";
  if (p.hasCode) return "coding";
  if (/\b(?:error|fails?|not working|bug|broken|crash|exception|traceback)\b/i.test(text)) return "debugging";
  return "studying";
}

/** Lightweight code review heuristics tied to concepts (offline). */
function reviewCode(code: string, domain?: string): { notes: string[]; concepts: string[] } {
  const notes: string[] = [];
  const cs: string[] = [];
  const bashy = domain === "bash" || /#!\/bin\/(?:ba)?sh|\becho\b|\bgrep\b|\$\{?[A-Za-z_]/.test(code);
  const pythonic = domain === "python" || /\bdef\b|\bprint\(|\bimport\b/.test(code);
  const rusty = domain === "rust_ownership" || /\bfn\b|\blet mut\b|String::from/.test(code);
  if (bashy) {
    if (/(?<!["'])\$[A-Za-z_][A-Za-z0-9_]*(?![^"]*")/.test(code) && !/"\$/.test(code)) {
      notes.push("You reference variables without quotes (e.g. `$var`). If a value ever contains spaces or globs it will split into several arguments — `\"$var\"` is the safe habit.");
      cs.push("quoting");
    }
    if (/for \w+ in \$\(ls/.test(code)) {
      notes.push("`for f in $(ls ...)` breaks on filenames with spaces; iterate a glob instead: `for f in *.txt`.");
      cs.push("loops_scripts");
    }
    if (/\b\w+ = /.test(code)) {
      notes.push("`x = 5` (with spaces) runs a command called `x`; assignments must be `x=5`.");
      cs.push("variables");
    }
    if (/\bif\s+\[\s+\$\w+\s*==/.test(code)) {
      notes.push("Inside `[ ]`, an unquoted empty variable makes the test malformed; prefer `[[ \"$x\" == ... ]]`.");
      cs.push("exit_status_conditionals");
    }
    if (!notes.length && /\|/.test(code)) notes.push("The pipeline reads cleanly — each stage does one job, which is exactly the Unix style.");
  }
  if (pythonic) {
    if (/def \w+\([^)]*=\s*(?:\[\]|\{\})/.test(code)) {
      notes.push("Mutable default argument: the list/dict is created once and shared across calls. Use `None` and create it inside.");
      cs.push("py_functions");
    }
    const fnName = code.match(/def (\w+)\(/)?.[1];
    if (fnName && new RegExp(`\\b${fnName}\\(`, "g").test(code.replace(`def ${fnName}(`, "")) && !/\bif\b/.test(code)) {
      notes.push(`\`${fnName}\` calls itself but I don't see a base case (an \`if\` that returns without recursing) — this will recurse forever.`);
      cs.push("base_case");
    }
    if (/for .+ in .+:\s*\n\s+\w+\.append\(/.test(code)) {
      notes.push("This loop-and-append pattern is a natural fit for a list comprehension.");
      cs.push("py_comprehensions");
    }
    if (/except:\s*\n/.test(code)) notes.push("A bare `except:` swallows everything, including Ctrl-C. Catch the specific exception you expect.");
  }
  if (rusty) {
    if (/let (\w+) = (\w+);[\s\S]*\b\2\b/.test(code) && /String::from|vec!|Vec</.test(code)) {
      notes.push("You use a value after moving it into another binding. Either borrow (`&`) or clone deliberately.");
      cs.push("ownership_moves");
    }
    if (/&mut \w+[\s\S]*&\w+/.test(code)) {
      notes.push("A mutable and a shared borrow of the same value overlap here — the borrow checker will refuse; end one borrow before starting the other.");
      cs.push("borrowing");
    }
    if (/\.clone\(\)[\s\S]*\.clone\(\)/.test(code)) {
      notes.push("Two clones in a short span — check whether a borrow would do; clones hide ownership design issues.");
      cs.push("clone_vs_move");
    }
  }
  if (!notes.length) {
    const lines = code.split("\n").length;
    notes.push(`${lines} lines, and nothing obviously wrong. If something misbehaves, tell me what you expected versus what happened.`);
  }
  return { notes, concepts: cs };
}

async function answerDetour(text: string): Promise<string | null> {
  const m = text.match(/(?:what|who) (?:is|are|was|were) (?:an? |the )?([^?.,]+)/i) ?? text.match(/(?:tell me about|explain) ([^?.,]+)/i);
  let subject = m?.[1]?.trim();
  if (!subject) subject = text.replace(/\b(?:who|what|when|where|why|how|which|is|are|was|were|did|does|do|the|a|an|of|invented|discovered|wrote|made|created|like|in|on|at)\b/gi, " ").replace(/[^a-z0-9 ]/gi, " ").replace(/\s+/g, " ").trim();
  if (!subject) return null;
  const hit = await quickLookup(subject);
  if (!hit) return null;
  return `${hit.title}: ${hit.text.split(/(?<=[.!?])\s+/).slice(0, 3).join(" ")}`;
}

/* ------------------------------------------------------------------ */

export async function runTurn(input: { learnerId: string; text: string; sessionId?: string; now?: Date; name?: string }): Promise<TurnResult> {
  const now = input.now ?? new Date();
  const text = input.text.trim();
  await ensureLearner(input.learnerId, input.name);
  const session = await getOrCreateSession(input.learnerId, now, input.sessionId);
  const state: SessionState = { ...DEFAULT_STATE, ...(session.state ?? {}) };
  const learnerId = input.learnerId;
  const sessionId = session.id;

  // Housekeeping at session start (cheap): dormancy is reversible influence management
  if (session.turnCount === 0) {
    await applyDormancy(learnerId, now);
    await applyConceptDormancy(learnerId, now);
  }

  const [userMsg] = await db.insert(messages).values({ learnerId, sessionId, role: "user", content: text, createdAt: now }).returning();

  const ctx: ObsContext = { domain: state.domain, concept: state.concept, activity: state.activity, strategy: state.lastStrategy };
  const p = await perceive(text, ctx, state.pending ?? null, state.lastMove);
  const activity = inferActivity(text, p);

  /* ---------------- domain / concept resolution ---------------- */
  let pack: DomainPack | null = state.domain ? await getPack(state.domain) : null;
  let concept: ConceptSpec | null = pack && state.concept ? pack.concepts.find((c) => c.slug === state.concept) ?? null : null;
  const reasons: string[] = [];
  let researched: string | null = null;
  let withinDomain = false;

  const wantsNewTopic = (p.intent === "learn_topic" || p.intent === "topic_switch") && p.topicMention;
  if (wantsNewTopic) {
    const seedHit = findSeedPack(p.topicMention!);
    // If the mention names a concept inside the current domain, stay in the domain
    const inCurrent = pack ? findConceptInPack(pack, p.topicMention!) : null;
    if (inCurrent && (!seedHit || seedHit.slug === pack?.slug)) {
      concept = inCurrent;
      withinDomain = true;
      reasons.push(`"${p.topicMention}" is a concept within ${pack!.label}`);
    } else {
      const r = await resolveDomain(p.topicMention!);
      pack = r.pack;
      researched = r.source;
      await seedGraphForLearner(learnerId, pack, r.source);
      concept = findConceptInPack(pack, p.topicMention!);
      reasons.push(`resolved topic "${p.topicMention}" → ${pack.label} (${r.source})`);
    }
  } else if (!pack && !p.detour) {
    const seedHit = findSeedPack(text);
    if (seedHit) {
      pack = seedHit;
      await seedGraphForLearner(learnerId, pack, "seed");
      concept = findConceptInPack(pack, text);
      reasons.push(`message mentions ${pack.label}`);
    }
  } else if (pack && !p.detour && ["question", "why_question", "request_example", "challenge_request", "claim_understanding", "claim_confusion", "disagree"].includes(p.intent)) {
    const hit = findConceptInPack(pack, text);
    if (hit) {
      concept = hit;
      reasons.push(`question is about ${hit.label}`);
    }
  }
  const domain = p.detour ? state.domain : pack?.slug ?? state.domain;

  // Behaviour as evidence: an unprompted explanation that matches a concept's check is a demonstration.
  let effectivePending = state.pending ?? null;
  if (!effectivePending && pack && !p.hasCode && !/\?\s*$/.test(text) && text.length > 40 && ["question", "casual", "claim_understanding", "next", "answer_attempt"].includes(p.intent)) {
    let best: { c: ConceptSpec; chk: NonNullable<ConceptSpec["checks"]>[number]; matched: string[] } | null = null;
    for (const c of pack.concepts) {
      for (const chk of c.checks ?? []) {
        const matched = chk.answer.filter((k) => text.toLowerCase().includes(k.toLowerCase()));
        if (matched.length >= 2 && (!best || matched.length > best.matched.length)) best = { c, chk, matched };
      }
    }
    if (best) {
      effectivePending = { concept: best.c.slug, domain: pack.slug, prompt: best.chk.prompt, answer: best.chk.answer, kind: "explanation" };
      p.intent = "answer_attempt";
      p.answerEval = { correct: true, partial: false, matched: best.matched };
      p.observations.push({ kind: "attempt", content: `Explained ${best.c.label} unprompted, correctly`, interpretation: "demonstrated understanding without being asked", payload: { concept: best.c.slug, domain: pack.slug, correct: true, kind: "explanation" }, strength: 0.8 });
      concept = best.c;
      reasons.push(`volunteered explanation matched ${best.c.slug} (${best.matched.join(", ")})`);
    }
  }
  const turnState: SessionState = { ...state, pending: effectivePending };
  const newCtx: ObsContext = { domain, concept: concept?.slug, activity, strategy: state.lastStrategy };

  /* ---------------- memory write + consolidation ---------------- */
  // Observations are recorded against the context in which they happened.
  const obsCtx: ObsContext = p.intent === "topic_switch" || p.intent === "learn_topic" ? { ...ctx, activity } : newCtx;
  const recorded = await recordObservations(learnerId, sessionId, userMsg.id, obsCtx, p.observations, now);
  await consolidate(learnerId, sessionId, now);
  const cp = await buildContext(learnerId, sessionId, newCtx, now);

  /* ---------------- decide ---------------- */
  const plan = await decide(p, cp, pack, concept, turnState, text, reasons, now, withinDomain);
  if (researched && researched !== "seed") plan.reasons.push(`researched new domain via ${researched}`);

  /* ---------------- respond ---------------- */
  const seed = userMsg.id;
  let feedback: Parameters<typeof compose>[0]["feedback"];
  let codeNotes: string[] | undefined;
  let detourAnswer: string | null | undefined;
  if (plan.move === "feedback" && effectivePending && p.answerEval) {
    const c = pack?.concepts.find((k) => k.slug === effectivePending!.concept) ?? null;
    const weak = !p.answerEval.correct && c && pack ? weakPrerequisite(c, cp, pack) : null;
    feedback = { correct: p.answerEval.correct, partial: p.answerEval.partial, concept: c, hint: effectivePending.hint, weakPrereq: weak };
    if (weak && c) {
      await reinforceEdge(learnerId, weak.slug, c.slug, "prerequisite", 0.1);
      plan.reasons.push(`failure on ${c.slug} with weak prerequisite ${weak.slug}: reinforced prerequisite edge`);
      const weakState = cp.states.get(weak.slug);
      const attemptObs = recorded.find((o) => o.kind === "attempt");
      if (weakState?.claimed === "knows" && attemptObs) {
        await noteClaimBehaviorGap(learnerId, sessionId, attemptObs.id, newCtx, now);
        plan.reasons.push(`claimed-known prerequisite ${weak.slug} appears weak: claim-vs-behaviour noted`);
      }
    }
  }
  if (plan.move === "reexplain" && plan.concept && pack) {
    const weak = weakPrerequisite(plan.concept, cp, pack);
    if (weak && (p.intent === "claim_confusion" || p.intent === "request_different")) {
      feedback = { correct: false, partial: false, concept: plan.concept, weakPrereq: weak };
      await reinforceEdge(learnerId, weak.slug, plan.concept.slug, "prerequisite", 0.05);
    }
  }
  if (plan.move === "code_review") {
    const r = reviewCode(p.codeBlock ?? text, domain);
    codeNotes = r.notes;
    for (const slug of r.concepts) {
      if (pack) {
        const spec = pack.concepts.find((c) => c.slug === slug);
        if (spec) await touchConcept(learnerId, slug, pack.slug, spec.label, now);
      }
      if (concept && slug !== concept.slug) await reinforceEdge(learnerId, slug, concept.slug, "related", 0.05);
    }
    if (r.concepts.length) plan.reasons.push(`code showed issues in: ${r.concepts.join(", ")}`);
  }
  if (plan.move === "detour") detourAnswer = await answerDetour(text);

  let reply: string | null = null;
  let provider = "offline";
  const llm = getLLM();
  if (llm) {
    const history = await db.select().from(messages).where(eq(messages.sessionId, sessionId)).orderBy(desc(messages.id)).limit(12);
    const out = await respondWithLLM(llm, { plan, cp, pack, perception: p, text, history: history.reverse(), feedback, codeNotes });
    if (out) {
      reply = out.reply;
      provider = llm.name;
      if (out.check) plan.check = out.check;
      else if (plan.move !== "probe" && plan.move !== "challenge") plan.check = null;
    }
  }
  if (!reply) reply = compose({ plan, perception: p, cp, pack, userText: text, seed, feedback, detourAnswer, codeNotes });

  /* ---------------- learn from what we did ---------------- */
  const explained = ["explain", "reexplain", "introduce_domain", "next_concept", "answer"].includes(plan.move) && plan.concept;
  if (explained && plan.concept && pack) {
    await markExplained(learnerId, plan.concept.slug, now);
    await touchConcept(learnerId, plan.concept.slug, pack.slug, plan.concept.label, now);
    if (!state.explainedThisSession.includes(plan.concept.slug)) state.explainedThisSession.push(plan.concept.slug);
  }
  const nextState: SessionState = {
    ...state,
    domain,
    concept: plan.concept?.slug ?? (p.detour ? state.concept : concept?.slug),
    activity,
    lastStrategy: explained ? plan.style : plan.move === "feedback" ? (p.answerEval?.correct ? undefined : plan.style) : state.lastStrategy,
    lastMove: plan.move,
    pending: plan.check ? { concept: plan.check.concept, domain: domain ?? "", prompt: plan.check.prompt, answer: plan.check.answer, kind: plan.check.kind === "challenge" ? "application" : "answer", hint: plan.check.hint } : null,
    turnsSinceProbe: plan.check ? 0 : state.turnsSinceProbe + 1,
    probes: state.probes + (plan.check ? 1 : 0),
  };
  const topics = domain && !session.topics.includes(domain) ? [...session.topics, domain] : session.topics;
  await db
    .update(sessions)
    .set({ state: nextState, lastActiveAt: now, turnCount: session.turnCount + 1, topics, summary: `Worked on ${topics.map((t) => t.replace(/_/g, " ")).join(", ") || "getting started"}; ${nextState.explainedThisSession.length} concepts covered, ${nextState.probes} checks.` })
    .where(eq(sessions.id, sessionId));
  await db.update(learners).set({ lastSeenAt: now }).where(eq(learners.id, learnerId));

  const trace: AgentTrace = {
    move: plan.move,
    strategy: explained ? plan.style : undefined,
    domain,
    concept: plan.concept?.slug,
    activity,
    probe: plan.check ? { kind: plan.check.kind, concept: plan.check.concept, reason: plan.reasons.find((r) => r.startsWith("check:")) ?? "" } : null,
    memoryUsed: { beliefs: plan.beliefIds, observations: recorded.length, concepts: cp.domainConcepts.slice(0, 12).map((c) => c.slug) },
    reasons: [...plan.reasons, `intent=${p.intent}`],
    provider,
  };
  const [agentMsg] = await db.insert(messages).values({ learnerId, sessionId, role: "agent", content: reply, createdAt: new Date(now.getTime() + 1), meta: trace }).returning();
  return { reply, trace, messageId: agentMsg.id, sessionId };
}

/* ------------------------------------------------------------------ */
/* Decision                                                              */
/* ------------------------------------------------------------------ */

async function decide(p: Perception, cp: ContextPack, pack: DomainPack | null, concept: ConceptSpec | null, state: SessionState, text: string, reasons: string[], now: Date, withinDomain = false): Promise<Plan> {
  const curious = cp.beliefs.some((b) => b.subject === "curiosity" && b.effective * b.relevance > 0.35);
  const base: Plan = { move: "answer", domain: pack?.slug, concept, style: "plain", includeWhy: curious || p.intent === "why_question", check: null, reasons, beliefIds: [], memoryNotes: [] };
  const withStyle = (plan: Plan, opts?: { reexplain?: boolean }) => {
    const s = chooseStyle(p, cp, state, opts);
    plan.style = s.style;
    plan.reasons.push(...s.reasons);
    plan.beliefIds.push(...s.beliefIds);
    return plan;
  };
  const curiousBelief = cp.beliefs.find((b) => b.subject === "curiosity" && b.effective * b.relevance > 0.35);
  if (curiousBelief) base.beliefIds.push(curiousBelief.id);

  // Returning after a long gap: acknowledge continuity once, at the first turn of a session.
  const firstTurn = state.turnsSinceProbe === 99 && state.explainedThisSession.length === 0 && !state.lastMove;
  if (firstTurn && cp.lastSession && cp.gapDays >= 1 && !["greeting", "resume"].includes(p.intent)) {
    const hint = resumeHint(cp);
    if (hint && (p.intent === "next" || p.intent === "casual")) base.memoryNotes.push(hint.split(" Carry on")[0].split(" It's been")[0]);
  }

  switch (p.intent) {
    case "greeting":
      return { ...base, move: "greet" };
    case "resume": {
      // "Let's continue" means continue: brief recap, then the next piece.
      const nxt = pack ? nextConcept(pack, cp, state) : null;
      if (nxt) {
        const hint = resumeHint(cp);
        const plan = withStyle({ ...base, move: "next_concept", concept: nxt, memoryNotes: hint ? [hint.split(" Carry on")[0].split(" It's been")[0]] : [] });
        return plan;
      }
      return { ...base, move: "resume", concept: null };
    }
    case "learn_topic":
    case "topic_switch": {
      if (!pack) return { ...base, move: "clarify" };
      const c = concept ?? nextConcept(pack, cp, state);
      const plan = withStyle({ ...base, move: withinDomain ? "explain" : "introduce_domain", concept: c });
      if (concept && cp.lastSession && cp.states.get(concept.slug)) plan.reasons.push("learner returns to a concept with history");
      return plan;
    }
    case "answer_attempt": {
      if (state.pending && p.answerEval) {
        const c = pack?.concepts.find((k) => k.slug === state.pending!.concept) ?? null;
        return withStyle({ ...base, move: "feedback", concept: c }, { reexplain: !p.answerEval.correct });
      }
      return withStyle({ ...base, move: concept ? "answer" : "clarify" });
    }
    case "submit_code":
      return { ...base, move: "code_review", style: "concrete_example" };
    case "disagree":
      return { ...base, move: "discuss_disagreement", includeWhy: true };
    case "challenge_request": {
      let c = concept ?? (pack ? nextConcept(pack, cp, state) : null);
      let check = c ? pickCheck(c, cp, state.pending?.prompt) : null;
      if (!check && state.pending && pack) {
        // Only one check exists for this concept and it is already on the table: pick the next concept's instead.
        c = nextConcept(pack, cp, state) ?? pack.concepts.find((k) => k.slug !== state.pending!.concept && k.checks?.length) ?? null;
        check = c ? pickCheck(c, cp) : null;
      }
      if (check) return { ...base, move: "challenge", concept: c, check: { ...check, kind: "challenge" }, reasons: [...reasons, "check: learner asked to practice"] };
      return { ...base, move: "clarify", memoryNotes: ["I don't have an exercise ready for this yet."] };
    }
    case "claim_confusion":
    case "request_different":
    case "request_detail":
    case "request_simpler":
    case "request_example":
    case "request_steps":
    case "request_analogy":
    case "request_concise": {
      if (!concept) {
        if (pack) return withStyle({ ...base, move: "answer" });
        return { ...base, move: "clarify" };
      }
      const reexplain = p.intent === "claim_confusion" || p.intent === "request_different" || p.intent === "request_simpler";
      return withStyle({ ...base, move: "reexplain", concept }, { reexplain });
    }
    case "claim_understanding": {
      // Claim of understanding: continue naturally; check only if the claim-vs-evidence gap matters for what's next.
      const pd = probeDecision(p, cp, state, concept);
      if (pd.probe && concept) {
        const check = pickCheck(concept, cp);
        if (check) return { ...base, move: "probe", concept, check, memoryNotes: [pick(["Good.", "Great.", "Nice."], text.length)], reasons: [...reasons, `check: ${pd.reason}`] };
      }
      const closing = /\b(?:thanks|thank you|bye|that'?s all|done for today)\b/i.test(text);
      const nxt = pack && !closing ? nextConcept(pack, cp, state) : null;
      if (nxt && state.lastMove && ["explain", "introduce_domain", "next_concept", "reexplain", "feedback", "probe"].includes(state.lastMove)) {
        const plan = withStyle({ ...base, move: "next_concept", concept: nxt, memoryNotes: [pick(["Good.", "Great.", "Nice."], text.length)] });
        plan.reasons.push(`no check: ${pd.reason}; continuing`);
        return plan;
      }
      return { ...base, move: "acknowledge", concept: nxt && nxt.slug !== concept?.slug ? nxt : null, reasons: [...reasons, `no check: ${pd.reason}`] };
    }
    case "next": {
      if (!pack) return { ...base, move: "clarify" };
      const pd = probeDecision(p, cp, state, concept);
      if (pd.probe && concept) {
        const check = pickCheck(concept, cp);
        if (check) return { ...base, move: "probe", concept, check, reasons: [...reasons, `check: ${pd.reason}`] };
      }
      const nxt = nextConcept(pack, cp, state);
      if (!nxt) return { ...base, move: "acknowledge", concept: null, memoryNotes: [`You've covered everything I have mapped for ${pack.label} — want to go deeper on one of them, or start something new?`] };
      const plan = withStyle({ ...base, move: "next_concept", concept: nxt });
      plan.reasons.push(`no check: ${pd.reason}`);
      // A light check may ride along with an explanation when the just-explained concept is unknown territory and the learner likes practice
      return plan;
    }
    case "preference_statement": {
      const style = (p.observations.find((o) => o.payload.signal === "stated_preference")?.payload.style as Style) ?? "plain";
      const label: Record<string, string> = { concise: "short and direct", concrete_example: "example-first", step_by_step: "step by step", analogy: "intuition-first", detailed: "thorough, with the why" };
      const plan: Plan = { ...base, move: "acknowledge", concept: null, memoryNotes: [`Noted — ${label[style] ?? style} from here${pack ? `, at least for ${pack.label}` : ""}. If that stops working I'll notice and adjust.`] };
      if (concept && state.lastMove && ["explain", "introduce_domain", "next_concept", "reexplain"].includes(state.lastMove)) {
        plan.move = "reexplain";
        plan.concept = concept;
        plan.style = style;
        plan.memoryNotes = [`Noted — ${label[style] ?? style} from here. Same idea, that way:`];
      }
      return plan;
    }
    case "goal_statement":
      return { ...base, move: pack && concept ? "explain" : "clarify", memoryNotes: ["Got it — I'll keep that goal in mind when choosing what to focus on."], style: "plain" };
    case "why_question":
    case "question": {
      if (p.detour) return { ...base, move: "detour", concept: null };
      if (!pack) {
        // Unknown territory with no explicit "teach me": try to research the subject of the question
        const subject = text.match(/(?:what|who) (?:is|are) (?:an? |the )?([^?.,]+)/i)?.[1]?.trim();
        if (subject && subject.split(" ").length <= 4) {
          const r = await resolveDomain(subject);
          if (r.pack.concepts.length > 1) {
            await seedGraphForLearner(cp.learner.id, r.pack, r.source);
            return withStyle({ ...base, move: "introduce_domain", domain: r.pack.slug, concept: r.pack.concepts[0], reasons: [...reasons, `researched "${subject}" via ${r.source}`] });
          }
        }
        return { ...base, move: "detour", concept: null };
      }
      const plan = withStyle({ ...base, move: "answer", concept: concept ?? null });
      if (p.intent === "why_question" && plan.style === "concise") plan.style = "plain";
      if (!concept) plan.reasons.push("question did not match a mapped concept; answering at domain level");
      return plan;
    }
    case "casual":
    default: {
      const nxt = pack ? nextConcept(pack, cp, state) : null;
      return { ...base, move: "acknowledge", concept: nxt };
    }
  }
}

/* ------------------------------------------------------------------ */
/* LLM response path                                                     */
/* ------------------------------------------------------------------ */

async function respondWithLLM(
  llm: NonNullable<ReturnType<typeof getLLM>>,
  x: { plan: Plan; cp: ContextPack; pack: DomainPack | null; perception: Perception; text: string; history: (typeof messages.$inferSelect)[]; feedback?: Parameters<typeof compose>[0]["feedback"]; codeNotes?: string[] },
): Promise<{ reply: string; check: Plan["check"] } | null> {
  const { plan, cp, pack } = x;
  const beliefLines = cp.beliefs
    .slice(0, 10)
    .map((b) => `- [${b.status}, conf ${b.effective.toFixed(2)}, scope ${b.scope}] ${b.statement}`)
    .join("\n");
  const stateLines = pack
    ? pack.concepts
        .map((c) => {
          const s = cp.states.get(c.slug);
          return `- ${c.slug}: p_known=${(s?.pKnown ?? 0.2).toFixed(2)} demonstrated ${s?.demonstratedCorrect ?? 0}✓/${s?.demonstratedIncorrect ?? 0}✗${s?.claimed ? ` (claims: ${s.claimed})` : ""}`;
        })
        .join("\n")
    : "(no domain yet)";
  const recent = cp.recentObservations
    .slice(-12)
    .map((o) => `- ${o.kind}: ${o.content}${o.interpretation ? ` (maybe: ${o.interpretation})` : ""}`)
    .join("\n");
  const material = plan.concept ? `Concept: ${plan.concept.label}\nSummary: ${plan.concept.summary}\n${plan.concept.explain ? JSON.stringify(plan.concept.explain).slice(0, 1800) : ""}` : "";
  const system = `You are one continuous, warm, sharp tutor in an ongoing relationship with this learner. Speak naturally; never mention modes, strategies, memory systems or confidence numbers. Never force the learner into a workflow.

WHAT YOU KNOW ABOUT THIS LEARNER (a prior, not a verdict — the present conversation outranks it):
Goals: ${cp.goals.map((g) => g.text).join("; ") || "none stated"}
${beliefLines || "- nothing durable yet"}

RECENT OBSERVATIONS (this and recent sessions):
${recent || "- none"}

KNOWLEDGE STATE in ${pack?.label ?? "no domain"} (evidence-based; a claim is not a demonstration):
${stateLines}
${cp.lastSession ? `Previous session (${Math.round(cp.gapDays)} days ago): ${cp.lastSession.summary}` : "This is the first session."}

RECOMMENDED MOVE (from your own deliberation; you may deviate if the conversation clearly calls for it):
move=${plan.move}; style=${plan.style}; include_why=${plan.includeWhy}; reasons=${plan.reasons.join(" | ")}
${plan.check ? `A light check is warranted: ask "${plan.check.prompt}" (a good answer mentions: ${plan.check.answer.join(", ")}).` : "Do NOT ask a test question this turn unless the learner asked to practice."}
${x.feedback ? `The learner's answer was ${x.feedback.correct ? "correct" : x.feedback.partial ? "partially correct" : "incorrect"}.${x.feedback.weakPrereq ? ` A likely missing prerequisite: ${x.feedback.weakPrereq.label}.` : ""}` : ""}
${x.codeNotes?.length ? `Code review findings: ${x.codeNotes.join(" | ")}` : ""}
${material ? `MATERIAL YOU MAY DRAW ON:\n${material}` : ""}

Rules: keep replies proportionate (short for short questions). If the learner disagrees, examine the claim honestly rather than defending. If they switch topic, follow them without complaint. If you do ask a check question, end your reply with a final line exactly like: [[check concept=<slug> answer=<kw1>,<kw2>,<kw3>]] (this line is stripped before display).`;
  try {
    const raw = await llm.complete({
      system,
      messages: [
        ...x.history.filter((m) => m.content !== x.text || m.role !== "user").slice(-10).map((m) => ({ role: (m.role === "user" ? "user" : "assistant") as "user" | "assistant", content: m.content })),
        { role: "user", content: x.text },
      ],
      maxTokens: 700,
    });
    if (!raw?.trim()) return null;
    const m = raw.match(/\[\[check concept=([a-z0-9_]+) answer=([^\]]+)\]\]/i);
    const reply = raw.replace(/\[\[check[^\]]*\]\]/gi, "").trim();
    let check: Plan["check"] = null;
    if (m) {
      const slug = m[1];
      const prompt = reply.split("\n").filter(Boolean).slice(-1)[0] ?? "";
      check = { kind: plan.check?.kind ?? "check", concept: slug, prompt, answer: m[2].split(",").map((s) => s.trim()).filter(Boolean) };
    }
    return { reply, check };
  } catch {
    return null;
  }
}

/* Re-export for other modules */
export { renderExplanation, slugify };
