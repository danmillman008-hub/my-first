import { getLLM, parseJsonObject } from "@/llm";
import type { ObsContext } from "@/db/schema";

export type Intent =
  | "learn_topic" // "I want to learn X"
  | "topic_switch" // "actually let's talk about Y"
  | "question" // asks something about current topic
  | "why_question" // "why does this work?"
  | "request_example"
  | "request_simpler"
  | "request_concise"
  | "request_steps"
  | "request_analogy"
  | "request_different"
  | "request_detail"
  | "claim_understanding" // "got it", "makes sense", "I already know this"
  | "claim_confusion" // "I don't get it", "still confused"
  | "disagree"
  | "submit_code"
  | "answer_attempt" // response to a pending check / challenge
  | "preference_statement" // "I prefer short answers"
  | "goal_statement"
  | "resume" // "where were we", "let's continue"
  | "next" // "what's next", "continue"
  | "challenge_request" // "give me an exercise"
  | "greeting"
  | "casual";

export type PerceivedObservation = {
  kind: string;
  content: string;
  interpretation?: string;
  payload: Record<string, unknown>;
  strength: number;
};

export type Perception = {
  intent: Intent;
  topicMention?: string;
  hasCode: boolean;
  codeBlock?: string;
  observations: PerceivedObservation[];
  /** When a check/probe was pending: how the learner's answer compared */
  answerEval?: { correct: boolean; partial: boolean; matched: string[] };
  /** Sentiment towards the previous agent move: positive/negative/neutral */
  reaction: "positive" | "negative" | "neutral";
  /** Off-topic question unrelated to current domain (agent should just answer it) */
  detour: boolean;
};

export type PendingCheck = { concept: string; domain: string; prompt: string; answer: string[]; kind: string } | null;

const RX = {
  learn: /\b(?:i(?:'d| would)? (?:like|want) to (?:learn|study|understand|get into|pick up)|teach me|help me (?:learn|understand|with)|can you teach|let'?s (?:learn|study|do|talk about|switch to|move (?:on )?to|go back to)|i'?m (?:learning|studying)|show me how (?:to|do)|explain(?: to me)?)\s+(.+?)(?:[.!?]|$)/i,
  switch: /\b(?:actually|instead|never ?mind|forget (?:that|it)|different topic|change (?:of )?topic|let'?s (?:talk about|switch to|move (?:on )?to|do|go back to)|back to|can we (?:talk about|do|switch to))\b/i,
  why: /\b(?:why|how come|what makes)\b.*\b(?:work|happen|fail|do that|behave)|^why\b/i,
  example: /\b(?:an?(?:other)? (?:concrete )?example|show me (?:an? )?(?:example|code)|for instance|in practice|real[- ]world|demo)\b/i,
  simpler: /\b(?:simpler|simplify|eli5|like i'?m (?:5|five|a beginner)|plain (?:english|words)|too (?:complex|complicated|advanced)|dumb it down|slower)\b/i,
  concise: /\b(?:shorter|too long|tl;?dr|just (?:the|give me the) (?:answer|command|code|gist)|be brief|concise|briefly|quick(?:ly)? answer|less detail|skip the (?:explanation|theory))\b/i,
  steps: /\b(?:step[- ]by[- ]step|walk me through|break (?:it|this) down|one step at a time|in order|what'?s the process)\b/i,
  analogy: /\b(?:analogy|metaphor|like what|compare (?:it|this) to|intuition|intuitively)\b/i,
  detail: /\b(?:go deeper|more detail|in depth|the full picture|tell me more|elaborate|expand on (?:that|this)|more thorough|dig deeper|what'?s (?:really )?going on under the hood)\b/i,
  different: /\b(?:another way|different(?:ly| way| explanation| approach)|rephrase|say (?:that|it) differently|didn'?t (?:help|land)|other way to (?:explain|put))\b/i,
  understand: /\b(?:got it|makes sense|i (?:see|understand|get it|get that|know (?:this|that|it)(?: already)?|already know)|that'?s clear|clear now|ok(?:ay)?,? (?:thanks|cool|great)|ah+,? (?:ok|right|i see)|understood|perfect|nice|thanks|thank you)\b/i,
  confused: /\b(?:i(?:'m| am)? (?:still )?(?:confused|lost|not sure|don'?t (?:get|understand|follow|see)|unclear)|huh\??|what\?+$|makes no sense|(?:doesn'?t|didn'?t|does not|did not) (?:make sense|click|land|help|compute)|not (?:following|clear|getting|clicking)|lost me|over my head|too fast)\b/i,
  disagree: /\b(?:that'?s (?:wrong|incorrect|not (?:right|true|correct))|i (?:disagree|don'?t think (?:that'?s|so|it'?s))|no,? (?:it|that) (?:isn'?t|doesn'?t|is not)|are you sure|i think you'?re (?:wrong|mistaken)|that'?s not (?:what|how))\b/i,
  prefShort: /\b(?:i (?:prefer|like|want)|give me|keep (?:it|things|answers))\s+(?:short|brief|concise|quick|direct|straight)\b|\bshort answers?\b|\bno fluff\b|\bstraight to the point\b/i,
  prefExamples: /\b(?:i (?:prefer|like|learn (?:best|better)|want)\b.*\b(?:examples?|by doing|hands[- ]on|code|seeing (?:it|code)))/i,
  prefSteps: /\bi (?:prefer|like|learn (?:best|better)|want)\b.*\b(?:step[- ]by[- ]step|steps|structured|systematic)/i,
  prefDetail: /\bi (?:prefer|like|want)\b.*\b(?:detail|deep|thorough|theory|background|the why)/i,
  prefAnalogy: /\bi (?:prefer|like|learn (?:best|better)|want)\b.*\b(?:analog|metaphor|intuition)/i,
  goal: /\b(?:my goal|i(?:'m| am) (?:preparing|trying to|aiming|working towards?)|i need (?:this|to) (?:for|by)|for (?:an? )?(?:interview|job|exam|project|work)|so (?:that )?i can)\b/i,
  resume: /\b(?:where (?:were|did) we|let'?s continue|continue where|pick up where|what were we|last time|remind me what)\b/i,
  next: /^(?:next|continue|go on|keep going|more|what'?s next|and then\??|ok(?:ay)?|sure|yes|yep|yeah|carry on)[.!?]*$/i,
  challenge: /\b(?:give me (?:an?|another|one more|some|a harder|an easier)? ?(?:exercise|challenge|problem|quiz|task|practice|question)|another (?:one|exercise|problem)|one more(?: exercise| problem)?|test me|quiz me|let me try|can i practice|something to practice|harder one|easier one)\b/i,
  greeting: /^(?:hi|hello|hey|yo|good (?:morning|evening|afternoon))\b[^a-z]*$/i,
  code: /```[\s\S]*?```|(?:^|\n)\s*(?:def |class |fn |let |const |var |for |while |if |#!\/|\$ |import |from \S+ import|SELECT |select |echo |grep |awk |sed |git |function )/,
};

export function extractTopic(text: string): string | undefined {
  const m = text.match(RX.learn);
  if (!m) return undefined;
  let topic = m[1].trim();
  topic = topic.replace(/^(?:about|the basics of|some|more about|how to use|how)\s+/i, "").replace(/\b(?:please|now|today|next|instead|again|once more|one more time|for me)\b/gi, "").replace(/\s+/g, " ").trim();
  topic = topic.replace(/[,;:].*$/, "").trim();
  if (topic.split(/\s+/).length > 6 || topic.length < 2) return undefined;
  return topic;
}

function gradeAnswer(text: string, check: PendingCheck): Perception["answerEval"] | undefined {
  if (!check) return undefined;
  const t = text.toLowerCase();
  const matched = check.answer.filter((k) => t.includes(k.toLowerCase()));
  const ratio = matched.length / Math.max(1, Math.min(check.answer.length, 3));
  const dontKnow = /\b(?:i don'?t know|no idea|not sure|skip|pass|dunno|tell me)\b/i.test(text);
  if (dontKnow) return { correct: false, partial: false, matched };
  return { correct: ratio >= 0.5 || matched.length >= 2, partial: matched.length === 1 && ratio < 0.5, matched };
}

/** Heuristic perception. Works offline and is the fallback for the LLM path. */
export function perceiveHeuristic(text: string, ctx: ObsContext, pending: PendingCheck, lastMove?: string): Perception {
  const obs: PerceivedObservation[] = [];
  const hasCode = RX.code.test(text);
  const codeBlock = hasCode ? (text.match(/```[\s\S]*?```/)?.[0] ?? text) : undefined;
  const topicMention = extractTopic(text);
  let intent: Intent = "question";
  let reaction: Perception["reaction"] = "neutral";
  const short = text.trim().length < 40;

  const isSwitch = RX.switch.test(text);
  const isGoal = RX.goal.test(text);

  if (RX.greeting.test(text)) intent = "greeting";
  else if (RX.resume.test(text)) intent = "resume";
  else if (
    pending &&
    !topicMention &&
    !isSwitch &&
    !RX.challenge.test(text) &&
    !/\b(?:already know|i know (?:this|that|it)|familiar with)\b/i.test(text) &&
    !RX.prefShort.test(text) && !RX.prefExamples.test(text) && !RX.prefSteps.test(text) && !RX.prefDetail.test(text) &&
    !RX.disagree.test(text) && !RX.different.test(text) && !RX.detail.test(text) && !RX.simpler.test(text) && !RX.steps.test(text) && !RX.analogy.test(text) &&
    !(RX.example.test(text) && /\?$/.test(text.trim()))
  ) {
    intent = "answer_attempt";
  } else if (topicMention && (isSwitch || (ctx.domain && !text.toLowerCase().includes(ctx.domain.replace(/_/g, " "))))) intent = ctx.domain ? "topic_switch" : "learn_topic";
  else if (topicMention) intent = "learn_topic";
  else if (hasCode) intent = "submit_code";
  else if (RX.challenge.test(text)) intent = "challenge_request";
  else if (RX.disagree.test(text)) intent = "disagree";
  else if (RX.prefShort.test(text) || RX.prefExamples.test(text) || RX.prefSteps.test(text) || RX.prefDetail.test(text) || RX.prefAnalogy.test(text)) intent = "preference_statement";
  else if (RX.different.test(text)) intent = "request_different";
  else if (RX.detail.test(text)) intent = "request_detail";
  else if (RX.simpler.test(text)) intent = "request_simpler";
  else if (RX.concise.test(text)) intent = "request_concise";
  else if (RX.steps.test(text)) intent = "request_steps";
  else if (RX.analogy.test(text)) intent = "request_analogy";
  else if (RX.example.test(text)) intent = "request_example";
  else if (RX.confused.test(text)) intent = "claim_confusion";
  else if (RX.next.test(text.trim())) intent = "next";
  else if (RX.understand.test(text) && short) intent = "claim_understanding";
  else if (RX.why.test(text)) intent = "why_question";
  else if (isGoal) intent = "goal_statement";
  else if (isSwitch && !topicMention) intent = "topic_switch";
  else if (/\?/.test(text) || /^(?:what|how|when|where|which|who|can|could|does|is|are|should)\b/i.test(text)) intent = "question";
  else if (short) intent = "casual";

  // --- observations: what happened (kind/content) + tentative interpretation ---
  const base = { strength: 0.5 };
  if (intent === "learn_topic" || intent === "topic_switch") {
    obs.push({ kind: "topic_switch", content: `Learner turned to: ${topicMention ?? "a different topic"}`, payload: { topic: topicMention }, strength: 0.6 });
  }
  if (isGoal) {
    obs.push({ kind: "goal", content: `Learner stated a goal: "${text.trim().slice(0, 160)}"`, payload: { text: text.trim().slice(0, 200) }, strength: 0.9 });
  }
  if (intent === "request_example") obs.push({ ...base, kind: "request", content: "Learner asked for a concrete example", interpretation: "examples may help here", payload: { signal: "wants_example", style: "concrete_example" } });
  if (intent === "request_simpler") obs.push({ ...base, kind: "request", content: "Learner asked for a simpler explanation", interpretation: "previous explanation too dense", payload: { signal: "wants_simpler", style: "plain" } });
  if (intent === "request_concise") obs.push({ ...base, kind: "request", content: "Learner asked for a shorter/direct answer", interpretation: "less detail wanted in this context", payload: { signal: "wants_concise", style: "concise" } });
  if (intent === "request_steps") obs.push({ ...base, kind: "request", content: "Learner asked to be walked through step by step", interpretation: "sequential structure may help", payload: { signal: "wants_steps", style: "step_by_step" } });
  if (intent === "request_detail") obs.push({ ...base, kind: "request", content: "Learner asked for more depth", interpretation: "fuller explanations may help", payload: { signal: "wants_detail", style: "detailed" } });
  if (intent === "request_analogy") obs.push({ ...base, kind: "request", content: "Learner asked for an analogy/intuition", interpretation: "intuition-first may help", payload: { signal: "wants_analogy", style: "analogy" } });
  if (intent === "request_different") obs.push({ ...base, kind: "reaction", content: "Learner asked for a different explanation", interpretation: `the ${ctx.strategy ?? "previous"} approach did not land`, payload: { signal: "explanation_failed", strategy: ctx.strategy } });
  if (intent === "claim_confusion") {
    reaction = "negative";
    obs.push({ ...base, kind: "reaction", content: "Learner expressed confusion", interpretation: `the ${ctx.strategy ?? "previous"} explanation may not have landed`, payload: { signal: "explanation_failed", strategy: ctx.strategy } });
  }
  if (intent === "claim_understanding") {
    reaction = "positive";
    const claimsPrior = /\b(?:already know|i know (?:this|that)|familiar)\b/i.test(text);
    obs.push({ ...base, kind: claimsPrior ? "claim" : "reaction", content: claimsPrior ? "Learner claims prior familiarity with this" : "Learner signalled understanding", interpretation: claimsPrior ? "self-report, not yet demonstrated" : `the ${ctx.strategy ?? "previous"} explanation seemed to land`, payload: { signal: claimsPrior ? "claims_known" : "explanation_landed", strategy: ctx.strategy }, strength: claimsPrior ? 0.4 : 0.5 });
  }
  if (intent === "disagree") {
    obs.push({ kind: "disagreement", content: `Learner disagreed: "${text.trim().slice(0, 140)}"`, interpretation: "learner is engaged and critical; verify rather than defend", payload: { signal: "disagreement" }, strength: 0.6 });
  }
  if (intent === "preference_statement") {
    const style = RX.prefShort.test(text) ? "concise" : RX.prefExamples.test(text) ? "concrete_example" : RX.prefSteps.test(text) ? "step_by_step" : RX.prefAnalogy.test(text) ? "analogy" : "detailed";
    obs.push({ kind: "preference_statement", content: `Learner said they prefer ${style.replace(/_/g, " ")}`, interpretation: "self-reported preference; honor now, confirm through outcomes", payload: { signal: "stated_preference", style }, strength: 0.7 });
  }
  if (intent === "submit_code") obs.push({ kind: "code_submitted", content: "Learner shared code", payload: { chars: text.length }, strength: 0.5 });
  if (intent === "challenge_request") obs.push({ kind: "request", content: "Learner asked to practice", interpretation: "wants active practice", payload: { signal: "wants_practice" }, strength: 0.6 });
  if (intent === "why_question") obs.push({ kind: "question", content: `Asked why: "${text.trim().slice(0, 120)}"`, interpretation: "curious about mechanism, not just recipe", payload: { signal: "asks_why" }, strength: 0.5 });
  else if (intent === "question") obs.push({ kind: "question", content: `Asked: "${text.trim().slice(0, 120)}"`, payload: {}, strength: 0.3 });

  const answerEval = intent === "answer_attempt" ? gradeAnswer(text, pending) : undefined;
  if (answerEval && pending) {
    obs.push({
      kind: "attempt",
      content: `Attempted check on ${pending.concept}: ${answerEval.correct ? "correct" : answerEval.partial ? "partially correct" : "incorrect"}`,
      payload: { concept: pending.concept, domain: pending.domain, correct: answerEval.correct, partial: answerEval.partial, kind: pending.kind },
      strength: 0.8,
    });
  }
  if (intent === "next" && lastMove === "explain") {
    reaction = "positive";
  }

  const detour = intent === "question" && !!ctx.domain && !topicMention && isUnrelatedToDomain(text, ctx.domain);
  return { intent, topicMention, hasCode, codeBlock, observations: obs, answerEval, reaction, detour };
}

function isUnrelatedToDomain(text: string, domain: string): boolean {
  // Cheap check: a question with no overlap with the domain's words and containing an obviously different subject.
  const t = text.toLowerCase();
  const dwords = domain.replace(/_/g, " ").split(" ");
  if (dwords.some((w) => t.includes(w))) return false;
  return /\b(?:weather|recipe|history of|capital of|population of|movie|music|sport|translate|joke|meaning of life|who (?:is|was|invented|wrote)|what year|when (?:did|was)|how old|how far|what is the \w+ of|define)\b/.test(t);
}

/** LLM-assisted perception: extracts intent + observations as JSON; heuristic fallback. */
export async function perceive(text: string, ctx: ObsContext, pending: PendingCheck, lastMove?: string): Promise<Perception> {
  const heuristic = perceiveHeuristic(text, ctx, pending, lastMove);
  const llm = getLLM();
  if (!llm) return heuristic;
  try {
    const raw = await llm.complete({
      json: true,
      temperature: 0,
      maxTokens: 500,
      system: `You observe a learner talking to a tutor. Record WHAT HAPPENED, with light interpretation only. Do not infer durable traits.`,
      messages: [
        {
          role: "user",
          content: `Current context: domain=${ctx.domain ?? "none"}, concept=${ctx.concept ?? "none"}, activity=${ctx.activity ?? "none"}, last tutor strategy=${ctx.strategy ?? "none"}.
${pending ? `A check is pending on concept "${pending.concept}": question "${pending.prompt}", correct answers involve: ${pending.answer.join(", ")}.` : "No check pending."}
Learner message: """${text.slice(0, 2000)}"""
Return JSON: {"intent": one of [learn_topic, topic_switch, question, why_question, request_example, request_simpler, request_concise, request_steps, request_analogy, request_different, request_detail, claim_understanding, claim_confusion, disagree, submit_code, answer_attempt, preference_statement, goal_statement, resume, next, challenge_request, greeting, casual],
"topicMention": string|null (the subject if they name a topic to learn/switch to),
"reaction": "positive"|"negative"|"neutral" (towards the tutor's last message),
"detour": boolean (an unrelated question outside the current domain),
"answerEval": {"correct": bool, "partial": bool} | null (only if a check is pending and they attempted it),
"statedPreferenceStyle": one of [concise, concrete_example, step_by_step, analogy, detailed] | null,
"observations": [{"kind": one of [question, request, claim, code_submitted, attempt, reaction, topic_switch, disagreement, preference_statement, goal, casual], "content": what happened in one sentence, "interpretation": tentative meaning or null}]}`,
        },
      ],
    });
    const parsed = parseJsonObject<{
      intent?: Intent;
      topicMention?: string | null;
      reaction?: Perception["reaction"];
      detour?: boolean;
      answerEval?: { correct: boolean; partial: boolean } | null;
      statedPreferenceStyle?: string | null;
      observations?: { kind: string; content: string; interpretation?: string | null }[];
    }>(raw);
    if (!parsed?.intent) return heuristic;
    const merged: Perception = {
      ...heuristic,
      intent: parsed.intent,
      topicMention: parsed.topicMention ?? heuristic.topicMention,
      reaction: parsed.reaction ?? heuristic.reaction,
      detour: parsed.detour ?? heuristic.detour,
      answerEval: parsed.answerEval ? { ...parsed.answerEval, matched: [] } : heuristic.answerEval,
    };
    // Rebuild structured observations from the (more reliable) heuristic payloads plus LLM's narrative ones.
    const rebuilt = perceiveHeuristicFromIntent(merged, text, ctx, pending, parsed.statedPreferenceStyle ?? undefined);
    const extra = (parsed.observations ?? [])
      .filter((o) => !rebuilt.some((r) => r.kind === o.kind))
      .map((o) => ({ kind: o.kind, content: o.content, interpretation: o.interpretation ?? undefined, payload: {}, strength: 0.3 }));
    merged.observations = [...rebuilt, ...extra];
    return merged;
  } catch {
    return heuristic;
  }
}

function perceiveHeuristicFromIntent(p: Perception, text: string, ctx: ObsContext, pending: PendingCheck, style?: string): PerceivedObservation[] {
  // Re-run the heuristic observation builder for the LLM-decided intent by
  // synthesising the same structured payloads (keeps consolidation consistent).
  const fake = perceiveHeuristic(text, ctx, pending);
  if (fake.intent === p.intent) return fake.observations;
  const obs: PerceivedObservation[] = [];
  const s = { strength: 0.5 };
  const map: Partial<Record<Intent, PerceivedObservation>> = {
    request_example: { ...s, kind: "request", content: "Learner asked for a concrete example", interpretation: "examples may help here", payload: { signal: "wants_example", style: "concrete_example" } },
    request_simpler: { ...s, kind: "request", content: "Learner asked for a simpler explanation", payload: { signal: "wants_simpler", style: "plain" } },
    request_concise: { ...s, kind: "request", content: "Learner asked for a shorter answer", payload: { signal: "wants_concise", style: "concise" } },
    request_steps: { ...s, kind: "request", content: "Learner asked for step-by-step", payload: { signal: "wants_steps", style: "step_by_step" } },
    request_analogy: { ...s, kind: "request", content: "Learner asked for an analogy", payload: { signal: "wants_analogy", style: "analogy" } },
    request_detail: { ...s, kind: "request", content: "Learner asked for more depth", payload: { signal: "wants_detail", style: "detailed" } },
    request_different: { ...s, kind: "reaction", content: "Learner asked for a different explanation", payload: { signal: "explanation_failed", strategy: ctx.strategy } },
    claim_confusion: { ...s, kind: "reaction", content: "Learner expressed confusion", payload: { signal: "explanation_failed", strategy: ctx.strategy } },
    claim_understanding: { ...s, kind: "reaction", content: "Learner signalled understanding", payload: { signal: "explanation_landed", strategy: ctx.strategy } },
    disagree: { kind: "disagreement", content: `Learner disagreed`, payload: { signal: "disagreement" }, strength: 0.6 },
    preference_statement: { kind: "preference_statement", content: `Learner said they prefer ${(style ?? "a different style").replace(/_/g, " ")}`, payload: { signal: "stated_preference", style: style ?? "detailed" }, strength: 0.7 },
    submit_code: { kind: "code_submitted", content: "Learner shared code", payload: {}, strength: 0.5 },
    challenge_request: { kind: "request", content: "Learner asked to practice", payload: { signal: "wants_practice" }, strength: 0.6 },
    why_question: { kind: "question", content: "Asked why", interpretation: "curious about mechanism", payload: { signal: "asks_why" }, strength: 0.5 },
    goal_statement: { kind: "goal", content: `Learner stated a goal: "${text.trim().slice(0, 160)}"`, payload: { text: text.trim().slice(0, 200) }, strength: 0.9 },
    learn_topic: { kind: "topic_switch", content: `Learner turned to: ${p.topicMention ?? "a topic"}`, payload: { topic: p.topicMention }, strength: 0.6 },
    topic_switch: { kind: "topic_switch", content: `Learner turned to: ${p.topicMention ?? "a different topic"}`, payload: { topic: p.topicMention }, strength: 0.6 },
  };
  const o = map[p.intent];
  if (o) obs.push(o);
  if (p.intent === "answer_attempt" && pending && p.answerEval) {
    obs.push({ kind: "attempt", content: `Attempted check on ${pending.concept}: ${p.answerEval.correct ? "correct" : p.answerEval.partial ? "partially correct" : "incorrect"}`, payload: { concept: pending.concept, domain: pending.domain, correct: p.answerEval.correct, partial: p.answerEval.partial, kind: pending.kind }, strength: 0.8 });
  }
  return obs;
}
