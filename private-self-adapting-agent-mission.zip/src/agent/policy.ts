import type { ConceptSpec, DomainPack, SessionState } from "@/db/schema";
import type { ContextPack, Style } from "@/memory";
import type { Perception } from "./perceive";
import { ablation } from "@/lab/ablation";

export type Move =
  | "greet"
  | "resume"
  | "introduce_domain"
  | "explain"
  | "reexplain"
  | "answer"
  | "detour"
  | "probe"
  | "challenge"
  | "feedback"
  | "acknowledge"
  | "discuss_disagreement"
  | "code_review"
  | "clarify"
  | "next_concept";

export type Plan = {
  move: Move;
  domain?: string;
  concept?: ConceptSpec | null;
  style: Style;
  includeWhy: boolean;
  check?: { kind: "check" | "challenge"; concept: string; prompt: string; answer: string[]; hint?: string } | null;
  reasons: string[];
  beliefIds: number[];
  /** short natural preface built from memory (resume, gap) */
  memoryNotes: string[];
};

const STYLE_ORDER: Style[] = ["concrete_example", "analogy", "step_by_step", "plain", "detailed", "concise"];

/** Which styles does the memory recommend/warn against in this context? */
export function styleScores(cp: ContextPack): { scores: Record<string, number>; used: number[] } {
  const scores: Record<string, number> = {};
  const used: number[] = [];
  // Specificity precedence: if we have real evidence about this domain, broader scopes are only a fallback.
  const prefs = cp.beliefs.filter((b) => b.kind === "preference" && b.subject === "explanation_style");
  const domainPrefs = prefs.filter((b) => b.scope.startsWith("domain:"));
  const hasDomainEvidence = domainPrefs.some((b) => b.supportCount >= 2 || b.status === "active");
  for (const b of prefs) {
    const specific = b.scope.startsWith("domain:");
    const fallbackPenalty = hasDomainEvidence && !specific ? 0.25 : 1;
    const w = b.effective * b.relevance * (b.status === "active" ? 1 : 0.6) * fallbackPenalty;
    scores[b.value] = (scores[b.value] ?? 0) + w;
    if (w > 0.2) used.push(b.id);
  }
  for (const b of cp.beliefs) {
    if (b.kind === "preference") continue;
    if (b.kind === "pattern" && b.subject === "curiosity" && b.value === "mechanism") {
      // Someone who keeps asking "why" tends to be better served by fuller explanations
      const w = b.effective * b.relevance * 0.5;
      scores["detailed"] = (scores["detailed"] ?? 0) + w;
      if (w > 0.15) used.push(b.id);
    }
    if (b.kind === "strategy") {
      const strategy = b.subject.replace("strategy:", "");
      const total = b.supportCount + b.contradictionCount;
      if (total < 1.5) continue;
      // Outcome evidence: a strategy that keeps failing here gets penalised even if it was requested
      const delta = b.value === "works" ? (b.confidence - 0.5) * 1.4 * b.relevance : -0.5 * b.relevance;
      scores[strategy] = (scores[strategy] ?? 0) + delta;
      if (Math.abs(delta) > 0.1) used.push(b.id);
    }
  }
  return { scores, used };
}

export function chooseStyle(p: Perception, cp: ContextPack, state: SessionState, opts: { reexplain?: boolean } = {}): { style: Style; reasons: string[]; beliefIds: number[] } {
  const reasons: string[] = [];
  if (ablation() === "no_adapt") return { style: "plain", reasons: ["ablation: no adaptation"], beliefIds: [] };
  // 1. The present outranks memory: an explicit request this turn wins.
  const direct: Partial<Record<Perception["intent"], Style>> = {
    request_example: "concrete_example",
    request_simpler: "plain",
    request_concise: "concise",
    request_steps: "step_by_step",
    request_analogy: "analogy",
    request_detail: "detailed",
  };
  const d = direct[p.intent];
  if (d) return { style: d, reasons: [`learner asked for ${d.replace(/_/g, " ")} just now`], beliefIds: [] };
  if (p.intent === "preference_statement") {
    const style = (p.observations.find((o) => o.payload.signal === "stated_preference")?.payload.style as Style) ?? "plain";
    return { style, reasons: [`learner just stated a preference for ${style.replace(/_/g, " ")}`], beliefIds: [] };
  }
  // 2. Recent working memory in this session (requests/preferences said minutes ago)
  const currentDomain = cp.domainConcepts[0]?.domain;
  const recent = [...cp.recentObservations].reverse().find((o) => (o.kind === "request" || o.kind === "preference_statement") && (!o.context.domain || !currentDomain || o.context.domain === currentDomain));
  const recentStyle = recent?.payload?.style as Style | undefined;
  // 3. Long-term beliefs, weighted by relevance and effective confidence
  const { scores, used } = styleScores(cp);
  const ranked = Object.entries(scores).filter(([s]) => STYLE_ORDER.includes(s as Style)).sort((a, b) => b[1] - a[1]);
  let style: Style | undefined;
  if (recentStyle && (scores[recentStyle] ?? 0) > -0.2 && !opts.reexplain) {
    style = recentStyle;
    reasons.push(`recently asked for ${recentStyle.replace(/_/g, " ")} this session`);
  } else if (ranked.length && ranked[0][1] > 0.25) {
    style = ranked[0][0] as Style;
    reasons.push(`memory suggests ${style.replace(/_/g, " ")} works for them here (score ${ranked[0][1].toFixed(2)})`);
  }
  if (opts.reexplain) {
    // Do not repeat the approach that just failed; pick the best-scoring alternative
    const failed = state.lastStrategy as Style | undefined;
    const candidates = STYLE_ORDER.filter((s) => s !== failed && s !== "concise").sort((a, b) => (scores[b] ?? 0) - (scores[a] ?? 0));
    if (p.intent === "request_simpler") style = "plain";
    else style = candidates[0];
    reasons.push(`switching approach after ${failed ?? "previous"} did not land`);
  }
  if (!style) {
    style = "plain";
    reasons.push("no strong signal yet; starting with a plain explanation plus a short example");
  }
  return { style, reasons, beliefIds: used };
}

/* ------------------------------------------------------------------ */
/* Concept selection                                                    */
/* ------------------------------------------------------------------ */

export function pKnownOf(cp: ContextPack, slug: string): number {
  return cp.states.get(slug)?.pKnown ?? 0.2;
}

export function isKnown(st: { pKnown: number; demonstratedCorrect: number } | undefined): boolean {
  return !!st && (st.pKnown >= 0.7 || (st.pKnown >= 0.58 && st.demonstratedCorrect > 0));
}

/**
 * Next concept: prefer new material whose prerequisites are in reasonable shape; fall back to
 * refreshers of previously explained but still-uncertain concepts. Never repeat within a session.
 */
export function nextConcept(pack: DomainPack, cp: ContextPack, state: SessionState): ConceptSpec | null {
  const eligible = (c: ConceptSpec) => {
    const st = cp.states.get(c.slug);
    if (isKnown(st)) return false;
    // Provisionally trust an unverified claim (it will be tested when something depends on it)
    if (st?.claimed === "knows" && st.demonstratedIncorrect === 0 && st.demonstratedCorrect === 0 && st.pKnown >= 0.4) return false;
    if (state.explainedThisSession.includes(c.slug)) return false;
    return true;
  };
  const prereqsOk = (c: ConceptSpec) => (c.prereqs ?? []).every((p) => pKnownOf(cp, p) >= 0.35 || state.explainedThisSession.includes(p));
  const fresh = pack.concepts.filter((c) => eligible(c) && !cp.states.get(c.slug)?.lastExplainedAt);
  const refreshers = pack.concepts.filter((c) => eligible(c) && cp.states.get(c.slug)?.lastExplainedAt);
  // A refresher whose demonstrated evidence is negative outranks new material (a real gap, not mere exposure)
  const gap = refreshers.find((c) => (cp.states.get(c.slug)?.demonstratedIncorrect ?? 0) > (cp.states.get(c.slug)?.demonstratedCorrect ?? 0));
  if (gap) return gap;
  return fresh.find(prereqsOk) ?? refreshers.find(prereqsOk) ?? fresh[0] ?? refreshers[0] ?? null;
}

/** A prerequisite of `concept` whose state is weak enough to explain the learner's trouble. */
export function weakPrerequisite(concept: ConceptSpec, cp: ContextPack, pack: DomainPack): ConceptSpec | null {
  for (const p of concept.prereqs ?? []) {
    const st = cp.states.get(p);
    if (!st || st.pKnown <= 0.45 || st.demonstratedIncorrect > st.demonstratedCorrect) {
      const spec = pack.concepts.find((c) => c.slug === p);
      if (spec) return spec;
    }
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Probing: resolve meaningful uncertainty with minimum disruption      */
/* ------------------------------------------------------------------ */

export function probeDecision(p: Perception, cp: ContextPack, state: SessionState, concept: ConceptSpec | null): { probe: boolean; reason: string } {
  if (ablation() === "no_probe") return { probe: false, reason: "ablation: probing disabled" };
  if (!concept?.checks?.length) return { probe: false, reason: "no check material" };
  const st = cp.states.get(concept.slug);
  const evidence = (st?.demonstratedCorrect ?? 0) + (st?.demonstratedIncorrect ?? 0);
  const pk = st?.pKnown ?? 0.2;
  const uncertainty = 1 - Math.abs(pk - 0.5) * 2; // 1 at 0.5, 0 at 0/1
  const claimGap = st?.claimed === "knows" && evidence === 0;
  const askedForBrevity = [...cp.recentObservations].slice(-6).some((o) => o.payload?.signal === "wants_concise");
  const wantsPractice = cp.beliefs.some((b) => b.subject === "practice" && b.effective > 0.5);
  // Hard constraints (disruption control)
  // A fresh claim of prior knowledge is an implicit invitation to verify: allow a slightly tighter budget.
  if (state.turnsSinceProbe < (claimGap && p.intent === "claim_understanding" ? 2 : 3)) return { probe: false, reason: "probed recently" };
  if (askedForBrevity) return { probe: false, reason: "learner asked for brevity" };
  if (["topic_switch", "learn_topic", "question", "why_question", "request_example", "request_simpler", "request_concise", "request_steps", "request_analogy", "request_different", "disagree", "claim_confusion", "greeting", "casual", "goal_statement", "preference_statement"].includes(p.intent))
    return { probe: false, reason: "learner is driving; answer instead" };
  // Value of information
  if (claimGap) return { probe: true, reason: "learner claims to know this but has never demonstrated it, and the next step builds on it" };
  if (evidence === 0 && uncertainty > 0.5 && state.explainedThisSession.includes(concept.slug) && (p.intent === "next" || p.intent === "claim_understanding"))
    return { probe: true, reason: "understanding of a just-explained concept is unknown and the next concept depends on it" };
  if (wantsPractice && evidence === 0 && p.intent === "next") return { probe: true, reason: "learner likes practice and this concept has not been tried" };
  return { probe: false, reason: "no meaningful uncertainty worth interrupting for" };
}

export function pickCheck(concept: ConceptSpec, cp: ContextPack, avoidPrompt?: string): NonNullable<Plan["check"]> | null {
  const all = concept.checks ?? [];
  const checks = all.filter((c) => c.prompt !== avoidPrompt);
  if (!checks.length) return null;
  const tried = cp.states.get(concept.slug)?.evidence.length ?? 0;
  const c = checks[tried % checks.length];
  return { kind: "check", concept: concept.slug, prompt: c.prompt, answer: c.answer, hint: c.hint };
}
