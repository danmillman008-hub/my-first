import type { ConceptSpec, DomainPack } from "@/db/schema";
import type { ContextPack, Style } from "@/memory";
import type { Plan } from "./policy";
import type { Perception } from "./perceive";

function pick<T>(arr: T[], seed: number): T {
  return arr[Math.abs(seed) % arr.length];
}

function firstLines(s: string | undefined, n: number): string | undefined {
  if (!s) return undefined;
  if (s.startsWith("```")) return s; // keep code blocks intact
  return s.split(/(?<=[.!?])\s+/).slice(0, n).join(" ");
}

/** Render a concept explanation in a given style. */
export function renderExplanation(c: ConceptSpec, style: Style, includeWhy: boolean): string {
  const e = c.explain ?? {};
  const parts: string[] = [];
  switch (style) {
    case "concise":
      parts.push(c.summary);
      if (e.example) parts.push(firstLines(e.example, 1)!);
      break;
    case "concrete_example":
      parts.push(firstLines(e.plain, 1) ?? c.summary);
      if (e.example) parts.push(e.example);
      else if (e.steps) parts.push(e.steps.map((s, i) => `${i + 1}. ${s}`).join("\n"));
      if (includeWhy && e.contrast) parts.push(`Why it matters: ${e.contrast}`);
      break;
    case "step_by_step":
      parts.push(firstLines(e.plain, 1) ?? c.summary);
      if (e.steps) parts.push(e.steps.map((s, i) => `${i + 1}. ${s}`).join("\n"));
      if (e.example) parts.push(`Putting it together:\n${e.example}`);
      break;
    case "analogy":
      if (e.analogy) parts.push(e.analogy);
      parts.push(e.plain ?? c.summary);
      if (includeWhy && e.contrast) parts.push(e.contrast);
      break;
    case "detailed":
      parts.push(e.plain ?? c.summary);
      if (e.example) parts.push(e.example);
      if (e.contrast) parts.push(`The subtle part: ${e.contrast}`);
      if (e.steps) parts.push(`In practice:\n${e.steps.map((s, i) => `${i + 1}. ${s}`).join("\n")}`);
      break;
    default: // plain
      parts.push(e.plain ?? c.summary);
      if (e.example) parts.push(firstLines(e.example, 2)!);
      if (includeWhy && e.contrast) parts.push(e.contrast);
  }
  return parts.filter(Boolean).join("\n\n");
}

/** "Why does this work?" — lead with mechanism rather than repeating the explanation. */
export function renderMechanism(c: ConceptSpec, style: Style): string {
  const e = c.explain ?? {};
  const parts: string[] = [];
  if (e.steps) parts.push(`Here's what actually happens, in order:\n${e.steps.map((s, i) => `${i + 1}. ${s}`).join("\n")}`);
  if (e.contrast) parts.push(e.contrast);
  if (style === "analogy" && e.analogy) parts.push(e.analogy);
  if (!parts.length) parts.push(e.plain ?? c.summary);
  if (style !== "concise" && e.example) parts.push(`You can see it in this case:\n${e.example}`);
  return parts.join("\n\n");
}

export function renderCheckQuestion(plan: Plan, seed: number, soft: boolean): string {
  const lead = soft
    ? pick(["Quick one before we move on — ", "Let me make sure this landed: ", "Before we build on it, a small check: ", "One quick question to see where you are: "], seed)
    : pick(["Try this: ", "Your turn: ", "Have a go at this one: "], seed);
  return `${lead}${plan.check!.prompt}`;
}

type Composer = {
  plan: Plan;
  perception: Perception;
  cp: ContextPack;
  pack: DomainPack | null;
  userText: string;
  seed: number;
  feedback?: { correct: boolean; partial: boolean; concept: ConceptSpec | null; hint?: string; weakPrereq?: ConceptSpec | null };
  detourAnswer?: string | null;
  codeNotes?: string[];
};

export function compose(x: Composer): string {
  const { plan, cp, seed } = x;
  const name = cp.learner?.name && cp.learner.name !== "Learner" ? cp.learner.name : null;
  const out: string[] = [];
  if (plan.memoryNotes.length) out.push(plan.memoryNotes.join(" "));

  switch (plan.move) {
    case "greet": {
      if (cp.sessionCount <= 1 && !cp.lastSession) {
        out.push(`Hi${name ? ` ${name}` : ""}. I'm your tutor — talk to me the way you'd talk to a person who knows the subject. Tell me what you'd like to learn, ask a question, or paste some code and I'll take it from there.`);
      } else {
        out.push(`Hey${name ? ` ${name}` : ""}, good to see you again. ${resumeHint(cp) ?? "What would you like to work on?"}`);
      }
      break;
    }
    case "resume": {
      out.push(resumeHint(cp) ?? "We haven't got a thread going yet — what would you like to dig into?");
      break;
    }
    case "introduce_domain": {
      const pack = x.pack!;
      const c = plan.concept;
      const known = pack.concepts.filter((k) => (cp.states.get(k.slug)?.pKnown ?? 0) >= 0.6).length;
      const touched = pack.concepts.filter((k) => cp.states.get(k.slug)?.lastExplainedAt).length;
      const intro = known > 0 ? `Back to ${pack.label} — you've already shown solid ground on ${known} of the ${pack.concepts.length} ideas we track here.` : touched > 0 ? `Back to ${pack.label}.` : `${pack.label}: ${pack.summary}`;
      out.push(intro);
      if (c) {
        const seen = !!cp.states.get(c.slug)?.lastExplainedAt;
        out.push(seen ? `${pick(["Let's pick up with", "Picking up with", "Back to"], seed)} **${c.label}**.` : `${pick(["A good place to start is", "Let's begin with", "The foundation here is"], seed)} **${c.label}**.`);
        out.push(renderExplanation(c, plan.style, plan.includeWhy));
        out.push(pick([
          "If you already know some of this, just say so and we'll skip ahead — or ask me anything about it.",
          "Ask whatever comes to mind, or say “next” when you're ready to move on.",
          "Tell me if this is too basic and we'll jump to where it gets interesting.",
        ], seed + 1));
      }
      break;
    }
    case "explain":
    case "next_concept": {
      const c = plan.concept!;
      const seenBefore = !!cp.states.get(c.slug)?.lastExplainedAt;
      if (plan.move === "next_concept" && seenBefore) out.push(pick([`Let's pick **${c.label}** back up — quick refresher, then we build on it.`, `We touched **${c.label}** before; here it is again, condensed.`], seed));
      else if (plan.move === "next_concept") out.push(pick([`Next up: **${c.label}**.`, `Building on that, let's look at **${c.label}**.`, `Now **${c.label}** — this is where the previous piece pays off.`], seed));
      else out.push(`**${c.label}**`);
      out.push(renderExplanation(c, plan.style, plan.includeWhy));
      if (plan.check) out.push(renderCheckQuestion(plan, seed, true));
      else if (plan.style !== "concise") out.push(pick(["Want an example, a different angle, or shall we keep going?", "Say “next” when ready, or ask me to show it differently.", "Questions? Or I can give you something small to try."], seed + 2));
      break;
    }
    case "reexplain": {
      const c = plan.concept!;
      const lead: Record<string, string> = {
        concrete_example: "Let me make it concrete instead.",
        analogy: "Let me try it from a different angle.",
        step_by_step: "Let's slow down and go one step at a time.",
        plain: "Let me strip it back to the essentials.",
        detailed: "Let me give you the fuller picture, including the why.",
        concise: "Short version:",
      };
      out.push(lead[plan.style] ?? "Another way to see it:");
      out.push(renderExplanation(c, plan.style, plan.includeWhy));
      if (x.feedback?.weakPrereq) {
        out.push(`One thing I suspect is getting in the way: **${x.feedback.weakPrereq.label}**. ${x.feedback.weakPrereq.summary} If that piece feels shaky, say so and we'll shore it up first.`);
      }
      out.push(pick(["Does that land better?", "Closer?", "Tell me which part is still fuzzy and I'll zoom in there."], seed));
      break;
    }
    case "answer": {
      const c = plan.concept;
      if (c && x.perception.intent === "why_question") {
        out.push(renderMechanism(c, plan.style));
      } else if (c) {
        out.push(renderExplanation(c, plan.style, plan.includeWhy));
      } else if (x.pack) {
        out.push(`${x.pack.summary}`);
        out.push(`Which part are you after? We can cover ${x.pack.concepts.slice(0, 4).map((k) => k.label.toLowerCase()).join(", ")}, or something else entirely.`);
      } else {
        out.push("Good question. Tell me a bit more about what you're trying to do and I'll tailor the answer — or name a topic and we'll dig in.");
      }
      break;
    }
    case "detour": {
      out.push(x.detourAnswer ?? "I'll be honest — I don't have solid material on that offline, so I'd rather not guess.");
      if (x.pack && plan.domain) out.push(pick([`Whenever you like, we can pick ${x.pack.label} back up.`, `No rush — ${x.pack.label} will be right where we left it.`, `Happy to keep wandering, or return to ${x.pack.label} when you're ready.`], seed));
      break;
    }
    case "probe": {
      out.push(renderCheckQuestion(plan, seed, true));
      break;
    }
    case "challenge": {
      out.push(renderCheckQuestion(plan, seed, false));
      if (plan.check?.hint) out.push("(Ask for a hint if you get stuck.)");
      break;
    }
    case "feedback": {
      const f = x.feedback!;
      const c = f.concept;
      if (f.correct) {
        out.push(x.perception.observations.some((o) => o.interpretation?.includes("without being asked")) ? pick(["Exactly right — and you got there on your own.", "That's a solid explanation; nothing to correct."], seed) : pick(["Yes — exactly.", "Right.", "That's it.", "Spot on."], seed));
        if (c?.explain?.contrast && plan.includeWhy) out.push(c.explain.contrast);
        out.push(pick(["Ready for the next piece, or want to push on this one a bit more?", "Shall we keep going?", "Want something a little harder on this, or move on?"], seed + 1));
      } else if (f.partial) {
        out.push(pick(["You're partly there.", "Close — you've got half of it.", "Good start; one piece is missing."], seed));
        if (f.hint) out.push(`Hint: ${f.hint}`);
        if (c) out.push(firstLines(c.explain?.plain, 2) ?? c.summary);
        out.push("Want to have another go, or should I just lay it out?");
      } else {
        out.push(pick(["Not quite — and that's useful, it tells me exactly what to explain.", "No worries, this one trips a lot of people.", "Not this time, but the gap is small."], seed));
        if (c) out.push(renderExplanation(c, plan.style, true));
        if (f.weakPrereq) out.push(`I think the real snag might be **${f.weakPrereq.label}** — ${f.weakPrereq.summary} Want to look at that first?`);
        else out.push("Want to try a similar one, or move on and come back later?");
      }
      break;
    }
    case "acknowledge": {
      if (!plan.memoryNotes.length) out.push(pick(["Good.", "Great.", "Nice."], seed));
      const nxt = plan.concept;
      if (nxt) out.push(`When you're ready, the natural next step is **${nxt.label}** — or ask me anything else.`);
      else out.push("What would you like to do next?");
      break;
    }
    case "discuss_disagreement": {
      const c = plan.concept;
      out.push(pick(["Fair challenge — let's check it rather than take my word for it.", "You might be right; let's look at it properly.", "Good, push back. Let's test it."], seed));
      if (c?.explain?.contrast) out.push(c.explain.contrast);
      if (c?.explain?.example) out.push(`Here's the concrete case I'd test against:\n${c.explain.example}`);
      out.push("If you have a counter-example in mind, show me — if it holds, I'll happily revise.");
      break;
    }
    case "code_review": {
      const notes = x.codeNotes ?? [];
      out.push(pick(["Thanks for sharing the code. Here's what I notice:", "Let's read through it together:", "Looking at your code:"], seed));
      if (notes.length) out.push(notes.map((n) => `- ${n}`).join("\n"));
      else out.push("- Nothing jumps out as wrong. Tell me what it's supposed to do, or what's not behaving, and we'll dig in.");
      break;
    }
    case "clarify": {
      out.push(pick([
        `I can help with that. Do you want the fundamentals from the start, or is there a specific thing you're trying to do with it?`,
        `Happy to. Are you starting from scratch or do you already use it and want to go deeper?`,
      ], seed));
      break;
    }
  }
  return out.filter(Boolean).join("\n\n");
}

export function resumeHint(cp: ContextPack): string | null {
  const s = cp.lastSession;
  if (!s) return null;
  const topics = s.topics.length ? s.topics.map((t) => t.replace(/_/g, " ")).join(", ") : null;
  const gap = cp.gapDays;
  const when = gap < 1 ? "earlier" : gap < 2 ? "yesterday" : gap < 14 ? `${Math.round(gap)} days ago` : gap < 60 ? `${Math.round(gap / 7)} weeks ago` : "a while back";
  const goal = cp.goals.find((g) => g.status === "active");
  const parts: string[] = [];
  if (topics) parts.push(`Last time (${when}) we were on ${topics}.`);
  if (goal) parts.push(`You mentioned your goal: “${goal.text.replace(/^Learner stated a goal: /, "").replace(/^"|"$/g, "")}”.`);
  if (gap > 21 && topics) parts.push("It's been a bit — I won't assume everything stuck. Want to carry on, or start somewhere fresh?");
  else if (topics) parts.push("Carry on from there, or take a different direction — your call.");
  return parts.length ? parts.join(" ") : null;
}
