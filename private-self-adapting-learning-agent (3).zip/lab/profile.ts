import "dotenv/config";
import { pool } from "@/db";
const orig = pool.query.bind(pool);
const stats: Record<string, { n: number; ms: number }> = {};
// @ts-expect-error monkey patch for profiling
pool.query = async (...args: unknown[]) => {
  const t = Date.now();
  // @ts-expect-error passthrough
  const r = await orig(...args);
  const key = String(typeof args[0] === "string" ? args[0] : (args[0] as { text: string }).text).replace(/\s+/g, " ").slice(0, 70);
  stats[key] = stats[key] ?? { n: 0, ms: 0 };
  stats[key].n++;
  stats[key].ms += Date.now() - t;
  return r;
};
process.on("exit", () => {
  console.log(Object.entries(stats).sort((a, b) => b[1].ms - a[1].ms).slice(0, 12).map(([k, v]) => `${v.ms}ms ${v.n}x ${k}`).join("\n"));
});
import("./run");
