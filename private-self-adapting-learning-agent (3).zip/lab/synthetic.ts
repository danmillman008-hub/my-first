// Synthetic learners with HIDDEN ground truth. The agent never sees these parameters;
// it only sees the natural-language messages the learner produces.
import type { Rng } from "@/lib/agent/context";

export const STRATS = ["example_first", "concept_first", "socratic", "exercise", "analogy", "walkthrough", "direct"] as const;
export type Strat = (typeof STRATS)[number];
export type Affinity = Record<Strat, number>;

export type Profile = {
  name: string;
  seed: number;
  subjects: string[]; // subject slugs in play (first = primary)
  affinity: Record<string, Affinity>; // per subject: P(understood | strategy)
  learningRate: number; // hidden mastery growth per understood turn
  noise: number; // P(flip the expressed signal)
  drift?: { atSession: number; affinity: Record<string, Affinity> };
  switchSubjectAtSession?: number; // abandon primary subject for the second one
  topicSwitchProb: number; // within-session subject hopping
  claims: "over" | "under" | "none";
  disagreeProb: number;
  chaosProb: number; // unrelated / garbage messages
  requestProbs: Partial<Record<"simpler" | "deeper" | "example" | "move_on" | "exercise", number>>;
  sessions: number;
  turnsPerSession: number;
  gapDays: number;
  codeProb: number;
};

const aff = (o: Partial<Affinity>): Affinity => ({ example_first: 0.5, concept_first: 0.5, socratic: 0.5, exercise: 0.5, analogy: 0.5, walkthrough: 0.5, direct: 0.5, ...o });
const EXAMPLE_LOVER = aff({ example_first: 0.88, exercise: 0.7, walkthrough: 0.62, analogy: 0.55, socratic: 0.4, concept_first: 0.3, direct: 0.28 });
const THEORY_LOVER = aff({ concept_first: 0.88, direct: 0.75, walkthrough: 0.55, socratic: 0.5, analogy: 0.35, example_first: 0.32, exercise: 0.3 });
const HANDS_ON = aff({ exercise: 0.9, example_first: 0.7, walkthrough: 0.6, socratic: 0.45, analogy: 0.4, concept_first: 0.3, direct: 0.3 });
const FLAT = aff({});

const base = (name: string, seed: number, o: Partial<Profile>): Profile => ({
  name,
  seed,
  subjects: ["bash"],
  affinity: { bash: EXAMPLE_LOVER },
  learningRate: 0.08,
  noise: 0.08,
  topicSwitchProb: 0.03,
  claims: "none",
  disagreeProb: 0.03,
  chaosProb: 0.03,
  requestProbs: { example: 0.03, move_on: 0.03 },
  sessions: 12,
  turnsPerSession: 12,
  gapDays: 2,
  codeProb: 0.04,
  ...o,
});

export const COHORT: Profile[] = [
  base("beginner-example-lover", 11, {}),
  base("expert-theory-direct", 12, { affinity: { bash: THEORY_LOVER }, learningRate: 0.15, claims: "over", requestProbs: { move_on: 0.12, deeper: 0.08 } }),
  base("fast-improver", 13, { affinity: { bash: HANDS_ON }, learningRate: 0.2 }),
  base("slow-improver", 14, { learningRate: 0.03 }),
  base("inconsistent", 15, { noise: 0.35 }),
  base("curious-switcher", 16, { subjects: ["bash", "linear-algebra"], affinity: { bash: EXAMPLE_LOVER, "linear-algebra": EXAMPLE_LOVER }, topicSwitchProb: 0.3, chaosProb: 0.08 }),
  base("focused", 17, { topicSwitchProb: 0, chaosProb: 0, affinity: { bash: HANDS_ON } }),
  base("interest-changer", 18, { subjects: ["bash", "python"], affinity: { bash: EXAMPLE_LOVER, python: EXAMPLE_LOVER }, switchSubjectAtSession: 6 }),
  base("overestimator", 19, { claims: "over", affinity: { bash: aff({ example_first: 0.6, walkthrough: 0.55, exercise: 0.5, concept_first: 0.35, direct: 0.3, socratic: 0.35, analogy: 0.4 }) }, learningRate: 0.04, requestProbs: { move_on: 0.15 } }),
  base("underestimator", 20, { claims: "under", affinity: { bash: aff({ example_first: 0.85, concept_first: 0.8, direct: 0.8, walkthrough: 0.8, exercise: 0.8, socratic: 0.7, analogy: 0.7 }) }, learningRate: 0.15 }),
  base("contradictor", 21, { disagreeProb: 0.2 }),
  base("pure-noise", 22, { noise: 0.5, affinity: { bash: FLAT } }),
  base("context-dependent", 23, { subjects: ["bash", "linear-algebra"], affinity: { bash: EXAMPLE_LOVER, "linear-algebra": THEORY_LOVER }, topicSwitchProb: 0.25 }),
  base("drifter", 24, { drift: { atSession: 7, affinity: { bash: THEORY_LOVER } }, sessions: 14 }),
  base("returner-long-gaps", 25, { gapDays: 30, sessions: 8 }),
  base("chaos-monkey", 26, { chaosProb: 0.35, disagreeProb: 0.1, noise: 0.2, topicSwitchProb: 0.15, subjects: ["bash", "linear-algebra"], affinity: { bash: EXAMPLE_LOVER, "linear-algebra": EXAMPLE_LOVER } }),
  base("simplifier", 27, { requestProbs: { simpler: 0.15, example: 0.05 }, affinity: { bash: aff({ analogy: 0.85, example_first: 0.8, concept_first: 0.25, direct: 0.2, socratic: 0.4, exercise: 0.5, walkthrough: 0.6 }) } }),
  base("deep-diver", 28, { requestProbs: { deeper: 0.15 }, affinity: { bash: THEORY_LOVER }, learningRate: 0.12 }),
  base("hands-on-bilingual", 29, { subjects: ["python", "bash"], affinity: { python: HANDS_ON, bash: HANDS_ON }, topicSwitchProb: 0.2, codeProb: 0.15 }),
  base("beginner-slow-noisy", 30, { learningRate: 0.03, noise: 0.25, requestProbs: { simpler: 0.08, example: 0.06 } }),
];

const UNDERSTOOD = [
  "oh I see, got it",
  "ok that makes sense now",
  "ah right, I get it",
  "yes, that clicked, thanks",
  "got it. that helps",
  "ok I understand",
  "makes sense",
  "yep, I see now",
];
const CONFUSED = [
  "hmm I don't get it",
  "I'm lost, sorry",
  "I still don't understand this",
  "wait, that doesn't make sense to me",
  "not sure I follow",
  "I don't really see why",
  "confused. can you explain that again?",
  "huh? I don't get what you mean",
];
const CHAOS = [
  "what's the capital of Mongolia?",
  "asdf qwer zxcv",
  "brb, lunch",
  "do you like jazz",
  "unrelated but how do I boil an egg",
  "lol",
  "",
  "🙃🙃🙃",
  "SELECT * FROM users;",
];
const DISAGREE = ["that's wrong, actually it works the other way", "I disagree, I think you mean the opposite", "are you sure? that's not what the docs say", "no, actually that's not right"];
const CODE = [
  "```bash\nfor f in *.txt; do\n  echo $f\ndone\n```\nwhy does this print nothing?",
  "```bash\nif [ $x == 1 ]\nthen echo one\nfi\n```\nthis gives an error",
  "```python\ndef f(x):\n    return x*2\nprint(f(3))\n```\nis this idiomatic?",
  "```python\nfor i in range(10)\n    print(i)\n```\nsyntax error?",
];
const REQ = {
  simpler: ["can you make that simpler?", "too complicated, plain english please", "eli5?"],
  deeper: ["can you go deeper on that?", "what's happening under the hood?", "more detail please"],
  example: ["can you show me an example?", "give me a concrete example", "what does that look like in practice?"],
  move_on: ["ok let's move on", "next topic please", "I know this already, what's next?"],
  exercise: ["give me an exercise", "let me try something", "quiz me on this"],
};

export type SimState = { mastery: Record<string, number>; session: number; subject: string; lastStrategy?: string; lastConcepts: string[]; lastAction?: string; introduced: Set<string> };

export function pick<T>(rng: Rng, arr: readonly T[]): T {
  return arr[Math.floor(rng() * arr.length)];
}

export function currentAffinity(p: Profile, st: SimState): Affinity {
  const table = p.drift && st.session >= p.drift.atSession ? { ...p.affinity, ...p.drift.affinity } : p.affinity;
  return table[st.subject] ?? table[p.subjects[0]] ?? FLAT;
}

/** Ground-truth reaction to the tutor's last turn; returns true if the learner genuinely understood. */
export function react(p: Profile, st: SimState, rng: Rng): boolean | null {
  if (!st.lastStrategy || !["explain", "answer", "review_code"].includes(st.lastAction ?? "explain")) return null;
  const a = currentAffinity(p, st)[st.lastStrategy as Strat] ?? 0.5;
  const c = st.lastConcepts[0];
  const m = c ? st.mastery[c] ?? 0 : 0;
  const pU = Math.min(0.97, a + 0.15 * m);
  const understood = rng() < pU;
  if (understood && c) st.mastery[c] = Math.min(1, m + p.learningRate);
  return understood;
}

/** Produce the learner's next message (natural language) given hidden state. */
export function nextMessage(p: Profile, st: SimState, rng: Rng, turn: number, subjectNames: Record<string, string>, concepts: Record<string, string[]>): { text: string; understood: boolean | null } {
  const sess = st.session;
  if (turn === 0) {
    const s = st.subject;
    if (!st.introduced.has(s)) {
      st.introduced.add(s);
      return { text: `I want to learn ${subjectNames[s] ?? s}`, understood: null };
    }
    return { text: pick(rng, [`back to ${subjectNames[s] ?? s} today`, `let's continue with ${subjectNames[s] ?? s}`, `ok, more ${subjectNames[s] ?? s}`]), understood: null };
  }
  if (rng() < p.chaosProb) return { text: pick(rng, CHAOS) || "...", understood: null };
  if (p.subjects.length > 1 && rng() < p.topicSwitchProb) {
    const other = pick(rng, p.subjects.filter((x) => x !== st.subject));
    st.subject = other;
    if (!st.introduced.has(other)) {
      st.introduced.add(other);
      return { text: `actually, I also want to learn ${subjectNames[other] ?? other}`, understood: null };
    }
    const c = pick(rng, concepts[other] ?? [other]);
    return { text: pick(rng, [`random question about ${subjectNames[other]}: how does ${c} work?`, `switching gears — in ${subjectNames[other]}, what is ${c}?`]), understood: null };
  }
  if (rng() < p.disagreeProb) return { text: pick(rng, DISAGREE), understood: null };
  if (rng() < p.codeProb) return { text: pick(rng, CODE), understood: null };
  for (const [k, pr] of Object.entries(p.requestProbs)) if (rng() < (pr ?? 0)) return { text: pick(rng, REQ[k as keyof typeof REQ]), understood: null };
  if (p.claims !== "none" && rng() < 0.12) {
    const c = pick(rng, concepts[st.subject] ?? []);
    if (c) return { text: p.claims === "over" ? `I already know ${c}, that's easy` : `I've never really understood ${c}`, understood: null };
  }
  const truth = react(p, st, rng);
  if (truth === null) return { text: pick(rng, ["ok", "go on", "and then?", "tell me more"]), understood: null };
  const expressed = rng() < p.noise ? !truth : truth;
  void sess;
  return { text: pick(rng, expressed ? UNDERSTOOD : CONFUSED), understood: truth };
}
