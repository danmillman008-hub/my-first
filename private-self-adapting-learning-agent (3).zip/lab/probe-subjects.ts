import "dotenv/config";
import { ensureSubject } from "@/lib/subjects/research";
import { db } from "@/db";
import { subjects, nodes, edges } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";
(async () => {
  await db.delete(subjects).where(eq(subjects.slug, "bash"));
  await db.delete(edges).where(eq(edges.learnerId, "__shared__"));
  await db.delete(nodes).where(eq(nodes.learnerId, "__shared__"));
  for (const n of ["Rust programming", "the guitar"]) {
    const t = Date.now();
    const r = await ensureSubject(n);
    console.log(n, "=>", r.subject.name, r.subject.origin, r.subject.concepts.length, "concepts", Date.now() - t, "ms");
    console.log("   ", r.subject.concepts.slice(0, 12).map((c) => c.label).join(" | "));
  }
  process.exit(0);
})();
