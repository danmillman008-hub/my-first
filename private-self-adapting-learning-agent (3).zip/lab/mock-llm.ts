import "dotenv/config";
import { createServer } from "http";

// A fake OpenAI-compatible endpoint. It echoes back what the system prompt contained (so we can verify the
// learner model actually reaches the model) and returns a reply with a structured evidence block.
let lastSystem = "";
let calls = 0;
const server = createServer((req, res) => {
  let body = "";
  req.on("data", (c) => (body += c));
  req.on("end", () => {
    calls++;
    const j = JSON.parse(body) as { messages: { role: string; content: string }[] };
    lastSystem = j.messages.find((m) => m.role === "system")?.content ?? "";
    const user = j.messages[j.messages.length - 1].content;
    let content: string;
    if (/curriculum researcher/i.test(lastSystem)) {
      content = JSON.stringify({ name: "Mock Subject", summary: "A mocked subject.", concepts: [{ slug: "alpha", label: "Alpha", level: 1 }, { slug: "beta", label: "Beta", level: 2, prerequisites: ["alpha"] }], sources: [] });
    } else if (/```bash/.test(user)) {
      content =
        "Your loop is fine, but `[ $x == 1 ]` breaks when `x` is empty — quote it: `[ \"$x\" == 1 ]`. That's word splitting, not a logic error.\n\n```evidence\n{\"strategy\":\"walkthrough\",\"action\":\"review_code\",\"concepts\":[\"quoting\"],\"newConcepts\":[{\"slug\":\"word-splitting\",\"label\":\"Word splitting\",\"description\":\"How unquoted expansions are split into words\",\"relatedTo\":[\"quoting\"]}],\"observations\":[{\"kind\":\"mistake\",\"content\":\"left $x unquoted in a test, causing a syntax error when empty\",\"concept\":\"quoting\",\"polarity\":-1,\"mistakeType\":\"syntax\",\"confusedWith\":\"word-splitting\",\"salience\":0.7}],\"insight\":{\"key\":\"understands-logic-slips-on-syntax\",\"content\":\"grasps the control-flow logic but slips on shell quoting details\",\"polarity\":1}}\n```";
    } else {
      content = `Sure — here's the idea. (mock reply to: ${user.slice(0, 40)})\n\n\`\`\`evidence\n{"strategy":"example_first","action":"explain","concepts":["pipelines"],"observations":[{"kind":"understanding","content":"followed the pipeline example","concept":"pipelines","polarity":1,"salience":0.4}],"insight":null}\n\`\`\``;
    }
    res.setHeader("content-type", "application/json");
    res.end(JSON.stringify({ choices: [{ message: { role: "assistant", content } }] }));
  });
});

async function main() {
  await new Promise<void>((r) => server.listen(48111, r));
  process.env.OPENAI_API_KEY = "mock";
  process.env.OPENAI_BASE_URL = "http://127.0.0.1:48111/v1";
  process.env.LLM_MODEL = "mock-model";
  const { handleTurn } = await import("@/lib/agent/agent");
  const { db } = await import("@/db");
  const { learners, sessions, subjects, edges, observations, beliefs } = await import("@/db/schema");
  const { newId } = await import("@/lib/memory/store");
  const { eq, and } = await import("drizzle-orm");
  const { ensureSubject } = await import("@/lib/subjects/research");

  const L = newId("l");
  await db.insert(learners).values({ id: L, name: "adv:mock-llm" });
  const S = newId("s");
  await db.insert(sessions).values({ id: S, learnerId: L });
  await ensureSubject("bash");
  const checks: [string, boolean, string][] = [];

  const r1 = await handleTurn(L, S, "I want to learn Bash");
  checks.push(["provider used", r1.meta.provider === "openai-compatible:mock-model", r1.meta.provider ?? ""]);
  checks.push(["evidence block stripped from reply", !/```evidence/.test(r1.reply) && r1.reply.startsWith("Sure"), r1.reply.slice(0, 60)]);
  checks.push(["strategy/concepts taken from model evidence", r1.meta.strategy === "example_first" && (r1.meta.concepts ?? []).includes("pipelines"), JSON.stringify(r1.meta.concepts)]);
  checks.push(["learner model rendered into system prompt", /LEARNER MODEL/.test(lastSystem) && /SUBJECT MAP/.test(lastSystem), ""]);

  const r2 = await handleTurn(L, S, "ok got it");
  checks.push(["prior strategy outcome attributed", (await db.select().from(beliefs).where(and(eq(beliefs.learnerId, L), eq(beliefs.key, "strategy:bash:example_first")))).length === 1, ""]);
  checks.push(["working memory shows up in later prompts", /Recent evidence/.test(lastSystem) && /followed the pipeline example/.test(lastSystem), ""]);
  void r2;

  const r3 = await handleTurn(L, S, "```bash\nif [ $x == 1 ]\nthen echo one\nfi\n```\nthis gives an error");
  const subj = (await db.select().from(subjects).where(eq(subjects.slug, "bash")))[0];
  checks.push(["subject map expanded with a concept discovered in conversation", subj.concepts.some((c) => c.slug === "word-splitting"), ""]);
  const obs = await db.select().from(observations).where(eq(observations.learnerId, L));
  checks.push(["LLM observation stored with mistake type", obs.some((o) => o.kind === "mistake" && o.source === "llm" && o.data.mistakeType === "syntax"), ""]);
  checks.push(["insight stored as observation (must earn belief status)", obs.some((o) => o.kind === "insight" && (o.data.key as string) === "understands-logic-slips-on-syntax"), ""]);
  const es = await db.select().from(edges).where(eq(edges.learnerId, L));
  checks.push(["confused_with edge created", es.some((e) => e.relation === "confused_with"), ""]);
  checks.push(["misconception belief created", (await db.select().from(beliefs).where(and(eq(beliefs.learnerId, L), eq(beliefs.kind, "misconception")))).length === 1, ""]);
  checks.push(["review_code action recorded", r3.meta.action === "review_code", r3.meta.action ?? ""]);

  // provider failure -> graceful fallback
  server.close();
  const r4 = await handleTurn(L, S, "and what about pipes?");
  checks.push(["provider outage degrades gracefully", /problem reaching the model provider/.test(r4.reply) && r4.reply.length > 80, r4.reply.slice(0, 80)]);

  let pass = 0;
  for (const [n, ok, d] of checks) {
    console.log(`${ok ? "PASS" : "FAIL"}  ${n}${d ? `  — ${d}` : ""}`);
    if (ok) pass++;
  }
  console.log(`\n${pass}/${checks.length} mock-LLM checks passed (${calls} model calls)`);
  process.exit(pass === checks.length ? 0 : 1);
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
});
