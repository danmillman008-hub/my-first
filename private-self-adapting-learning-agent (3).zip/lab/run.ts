import "dotenv/config";
import { db } from "@/db";
import { beliefs, consolidations, edges, evalRuns, learners, messages, nodes, observations, sessions } from "@/db/schema";
import { handleTurn, seededRng, type AgentOptions } from "@/lib/agent/agent";
import { newId, effectiveWeight, retention } from "@/lib/memory/store";
import { ensureSubject } from "@/lib/subjects/research";
import { inArray, like, sql } from "drizzle-orm";
import { mkdirSync, readFileSync, writeFileSync } from "fs";
import { COHORT, STRATS, currentAffinity, nextMessage, type Profile, type SimState } from "./synthetic";

type Cond = { name: string; opts: AgentOptions };
const CONDITIONS: Cond[] = [
  { name: "full", opts: {} },
  { name: "no_longterm", opts: { useLongTerm: false } },
  { name: "no_adapt", opts: { adaptive: false } },
];

type TurnLog = { learner: string; cond: string; session: number; turn: number; subject: string; strategy?: string; action?: string; understood: boolean | null; bestStrategy: string; regret: number; text: string; reply: string; ms: number };

const onlyCond = process.env.LAB_CONDITIONS?.split(",");
const onlyLearners = process.env.LAB_LEARNERS?.split(",");
const scale = Number(process.env.LAB_SCALE ?? 1);
const seeds = Number(process.env.LAB_SEEDS ?? 1);

async function wipeSim(conds: Cond[]) {
  const all = await db.select({ id: learners.id, name: learners.name }).from(learners).where(like(learners.name, "sim:%"));
  const ids = all.filter((l) => conds.some((c) => l.name.startsWith(`sim:${c.name}:`))).map((r) => r.id);
  if (!ids.length) return;
  for (const t of [messages, sessions, observations, beliefs, consolidations, nodes, edges]) await db.delete(t).where(inArray(t.learnerId, ids));
  await db.delete(learners).where(inArray(learners.id, ids));
}

async function runLearner(p: Profile, cond: Cond, subjectNames: Record<string, string>, conceptLists: Record<string, string[]>, seedIdx = 0): Promise<{ log: TurnLog[]; learnerId: string }> {
  const rng = seededRng(p.seed * 1000 + cond.name.length + seedIdx * 7919);
  const learnerId = newId("l");
  await db.insert(learners).values({ id: learnerId, name: `sim:${cond.name}:${p.name}${seedIdx ? `#${seedIdx}` : ""}`, createdAt: new Date("2025-01-01T09:00:00Z"), meta: { profile: p.name, condition: cond.name, seed: seedIdx } });
  const st: SimState = { mastery: {}, session: 0, subject: p.subjects[0], lastConcepts: [], introduced: new Set() };
  const log: TurnLog[] = [];
  let clock = new Date("2025-01-01T09:00:00Z").getTime();
  const sessionsN = Math.max(2, Math.round(p.sessions * scale));
  for (let s = 0; s < sessionsN; s++) {
    st.session = s + 1;
    if (p.switchSubjectAtSession && st.session >= p.switchSubjectAtSession) st.subject = p.subjects[1];
    const sessionId = newId("s");
    await db.insert(sessions).values({ id: sessionId, learnerId, title: `session ${s + 1}`, startedAt: new Date(clock), lastActiveAt: new Date(clock) });
    st.lastStrategy = undefined;
    st.lastConcepts = [];
    for (let t = 0; t < p.turnsPerSession; t++) {
      const { text, understood } = nextMessage(p, st, rng, t, subjectNames, conceptLists);
      const affNow = currentAffinity(p, st);
      const best = (Object.entries(affNow) as [string, number][]).sort((a, b) => b[1] - a[1])[0][0];
      const t0 = Date.now();
      const r = await handleTurn(learnerId, sessionId, text || "...", { ...cond.opts, now: new Date(clock), rng, forceOffline: true, skipNetwork: true });
      const regret = affNow[best as keyof typeof affNow] - (affNow[(r.meta.strategy ?? "direct") as keyof typeof affNow] ?? 0.5);
      log.push({ learner: p.name, cond: cond.name, session: s + 1, turn: t, subject: st.subject, strategy: r.meta.strategy, action: r.meta.action, understood, bestStrategy: best, regret, text, reply: r.reply, ms: Date.now() - t0 });
      st.lastStrategy = r.meta.strategy;
      st.lastConcepts = r.meta.concepts ?? [];
      st.lastAction = r.meta.action;
      clock += 90_000;
    }
    clock += p.gapDays * 864e5;
  }
  return { log, learnerId };
}

const topStrategy = (log: TurnLog[]) => {
  const c: Record<string, number> = {};
  for (const l of log) if (l.strategy && ["explain", "answer"].includes(l.action ?? "")) c[l.strategy] = (c[l.strategy] ?? 0) + 1;
  return Object.entries(c).sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;
};
const mean = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : NaN);
const r3 = (x: number) => (Number.isFinite(x) ? Math.round(x * 1000) / 1000 : null);
function pearson(a: number[], b: number[]) {
  const ma = mean(a);
  const mb = mean(b);
  const num = a.reduce((s, x, i) => s + (x - ma) * (b[i] - mb), 0);
  const den = Math.sqrt(a.reduce((s, x) => s + (x - ma) ** 2, 0) * b.reduce((s, x) => s + (x - mb) ** 2, 0));
  return den ? num / den : NaN;
}

function compRate(log: TurnLog[], from: number, to: number) {
  const xs = log.filter((l) => l.session >= from && l.session <= to && l.understood !== null).map((l) => (l.understood ? 1 : 0));
  return mean(xs);
}
function regretRate(log: TurnLog[], from: number, to: number, subject?: string) {
  return mean(log.filter((l) => l.session >= from && l.session <= to && ["explain", "answer"].includes(l.action ?? "") && (!subject || l.subject === subject)).map((l) => l.regret));
}
function matchRate(log: TurnLog[], from: number, to: number, subject?: string) {
  const xs = log.filter((l) => l.session >= from && l.session <= to && l.understood !== null && (!subject || l.subject === subject)).map((l) => (l.strategy === l.bestStrategy ? 1 : 0));
  return mean(xs);
}

async function learnerMetrics(p: Profile, learnerId: string, log: TurnLog[], cond: string, finalClock: Date) {
  const bs = await db.select().from(beliefs).where(sql`${beliefs.learnerId} = ${learnerId}`);
  const ns = await db.select().from(nodes).where(sql`${nodes.learnerId} = ${learnerId}`);
  const es = await db.select().from(edges).where(sql`${edges.learnerId} = ${learnerId}`);
  const S = Math.max(...log.map((l) => l.session));
  const early = compRate(log, 1, 3);
  const late = compRate(log, Math.max(1, S - 2), S);
  const truth = currentAffinity(p, { mastery: {}, session: 1, subject: p.subjects[0], lastConcepts: [], introduced: new Set() });
  const vals = Object.values(truth);
  const oracle = Math.max(...vals);
  const random = mean(vals);
  // belief accuracy for strategy effects (primary subject)
  const pairs = STRATS.map((s) => {
    const b = bs.find((x) => x.key === `strategy:${p.subjects[0]}:${s}`);
    return b ? [truth[s], b.confidence] : null;
  }).filter(Boolean) as [number, number][];
  const stratCorr = pairs.length >= 3 ? pearson(pairs.map((x) => x[0]), pairs.map((x) => x[1])) : NaN;
  const active = bs.filter((b) => b.status === "active");
  const tend = active.filter((b) => b.kind === "tendency" || b.kind === "preference");
  const probes = log.filter((l) => l.action === "probe").length;
  const asks = log.filter((l) => l.action === "ask" || l.action === "probe").length;
  const m: Record<string, unknown> = {
    learner: p.name,
    cond,
    turns: log.length,
    msPerTurn: r3(mean(log.map((l) => l.ms))),
    comprehension: { early: r3(early), late: r3(late), all: r3(compRate(log, 1, S)), oracle: r3(oracle), random: r3(random) },
    strategyMatch: { early: r3(matchRate(log, 1, 3)), late: r3(matchRate(log, Math.max(1, S - 2), S)) },
    regret: { early: r3(regretRate(log, 1, 3)), late: r3(regretRate(log, Math.max(1, S - 2), S)) },
    beliefs: { total: bs.length, active: active.length, dormant: bs.filter((b) => b.status === "dormant").length, activeTendenciesOrPrefs: tend.length, maxTendencyConfidence: r3(Math.max(0, ...tend.map((b) => b.confidence))), strategyBeliefCorrelation: r3(stratCorr) },
    graph: { nodes: ns.length, activeNodes: ns.filter((n) => n.active).length, edges: es.length, activeEdges: es.filter((e) => e.active).length, relations: Object.fromEntries([...new Set(es.map((e) => e.relation))].map((r) => [r, es.filter((e) => e.relation === r).length])) },
    naturalness: { probesPerSession: r3(probes / S), askOrProbeFraction: r3(asks / log.length) },
  };
  if (p.drift) {
    const d = p.drift.atSession;
    m.drift = { matchBefore: r3(matchRate(log, 1, d - 1)), matchRightAfter: r3(matchRate(log, d, d + 1)), matchLater: r3(matchRate(log, d + 3, S)), regretBefore: r3(regretRate(log, 1, d - 1)), regretRightAfter: r3(regretRate(log, d, d + 1)), regretLater: r3(regretRate(log, d + 3, S)), compBefore: r3(compRate(log, 1, d - 1)), compRightAfter: r3(compRate(log, d, d + 1)), compLater: r3(compRate(log, d + 3, S)) };
  }
  if (p.subjects.length > 1 && !p.switchSubjectAtSession) {
    m.perSubject = Object.fromEntries(p.subjects.map((s) => [s, { match: r3(matchRate(log, 1, S, s)), regretLate: r3(regretRate(log, Math.max(1, S - 3), S, s)), topStrategyLate: topStrategy(log.filter((l) => l.subject === s && l.session > S - 4)), comp: r3(mean(log.filter((l) => l.subject === s && l.understood !== null).map((l) => (l.understood ? 1 : 0)))), contextSpecificBeliefs: bs.filter((b) => b.kind === "strategy_effect" && b.subject === s && b.status === "active").length }]));
  }
  if (p.claims !== "none") {
    const k = p.claims === "over" ? "overestimates" : "underestimates";
    const b = bs.find((x) => x.key.includes(`self-assessment-${k}`));
    const wrong = bs.find((x) => x.key.includes(`self-assessment-${k === "overestimates" ? "underestimates" : "overestimates"}`));
    m.calibration = { expected: k, detected: !!b, status: b?.status ?? null, confidence: r3(b?.confidence ?? NaN), support: b?.support ?? 0, oppositeActive: wrong?.status === "active" };
  }
  if (p.gapDays >= 20) {
    const mastery = bs.filter((b) => b.kind === "mastery");
    m.longGaps = { masteryBeliefs: mastery.length, avgRetentionNow: r3(mean(mastery.map((b) => retention(b, finalClock)))), avgEffectiveWeight: r3(mean(mastery.map((b) => effectiveWeight(b, finalClock)))), reactivated: bs.filter((b) => (b.data as { reactivatedAt?: string }).reactivatedAt).length, inactiveNodes: ns.filter((n) => !n.active).length };
  }
  if (p.switchSubjectAtSession) {
    const goals = bs.filter((b) => b.kind === "goal");
    m.interestChange = { goals: goals.map((g) => ({ key: g.key, status: g.status, weight: r3(effectiveWeight(g, finalClock)) })), lateSubjectMatch: r3(matchRate(log, p.switchSubjectAtSession + 2, S, p.subjects[1])) };
  }
  // preference beliefs should reflect explicit requests
  const prefs = active.filter((b) => b.kind === "preference").map((b) => `${b.key}@${b.confidence.toFixed(2)}`);
  if (prefs.length) m.activePreferences = prefs;
  return m;
}

async function main() {
  const t0 = Date.now();
  const conds = CONDITIONS.filter((c) => !onlyCond || onlyCond.includes(c.name));
  await wipeSim(conds);
  const subjectSlugs = [...new Set(COHORT.flatMap((p) => p.subjects))];
  const subjectNames: Record<string, string> = {};
  const conceptLists: Record<string, string[]> = {};
  for (const s of subjectSlugs) {
    const { subject } = await ensureSubject(s.replace(/-/g, " "));
    subjectNames[s] = subject.name.replace(/\s*\(.*\)\s*$/, "");
    conceptLists[s] = subject.concepts.slice(0, 10).map((c) => c.label.toLowerCase());
  }
  console.log("subjects:", Object.entries(subjectNames).map(([k, v]) => `${k}=${v}(${conceptLists[k].length})`).join(", "));

  // merge with previous results for conditions not run this time (incremental lab runs)
  let previous: Record<string, unknown>[] = [];
  try {
    previous = ((JSON.parse(readFileSync("lab/out/summary.json", "utf8")) as { learners: Record<string, unknown>[] }).learners ?? []).filter((r) => !conds.some((c) => c.name === r.cond));
  } catch {
    /* no previous summary */
  }
  const results: Record<string, unknown>[] = [...previous];
  const transcripts: Record<string, TurnLog[]> = {};
  const cohort = COHORT.filter((p) => !onlyLearners || onlyLearners.includes(p.name));
  let totalTurns = 0;
  for (const cond of conds) {
    for (const p of cohort) for (let seedIdx = 0; seedIdx < seeds; seedIdx++) {
      const { log, learnerId } = await runLearner(p, cond, subjectNames, conceptLists, seedIdx);
      totalTurns += log.length;
      const finalClock = new Date(new Date("2025-01-01T09:00:00Z").getTime() + log.length * 90_000 + Math.round(p.sessions * scale) * p.gapDays * 864e5);
      const m = await learnerMetrics(p, learnerId, log, cond.name, finalClock);
      results.push(m);
      if (cond.name === "full" && seedIdx === 0) transcripts[p.name] = log;
      m.seed = seedIdx;
      const c = m.comprehension as { early: number; late: number; oracle: number; random: number };
      const sm = m.strategyMatch as { early: number; late: number };
      console.log(`${cond.name.padEnd(12)} ${p.name.padEnd(24)} turns=${log.length} comp early→late ${c.early}→${c.late} (rand ${c.random}, oracle ${c.oracle}) match ${sm.early}→${sm.late} ms/turn=${m.msPerTurn}`);
    }
  }

  // Aggregate per condition
  const agg: Record<string, unknown> = {};
  for (const cond of CONDITIONS.filter((c) => results.some((r) => r.cond === c.name))) {
    const rs = results.filter((r) => r.cond === cond.name);
    const c = (k: "early" | "late" | "all" | "oracle" | "random") => mean(rs.map((r) => (r.comprehension as Record<string, number>)[k]).filter((x) => x !== null));
    const sm = (k: "early" | "late") => mean(rs.map((r) => (r.strategyMatch as Record<string, number>)[k]).filter((x) => x !== null));
    agg[cond.name] = {
      learners: rs.length,
      comprehensionEarly: r3(c("early")),
      comprehensionLate: r3(c("late")),
      comprehensionAll: r3(c("all")),
      randomBaseline: r3(c("random")),
      oracle: r3(c("oracle")),
      regretVsOracleLate: r3(c("oracle") - c("late")),
      strategyMatchEarly: r3(sm("early")),
      strategyMatchLate: r3(sm("late")),
      regretEarly: r3(mean(rs.map((r) => (r.regret as { early: number }).early).filter((x) => x !== null))),
      regretLate: r3(mean(rs.map((r) => (r.regret as { late: number }).late).filter((x) => x !== null))),
      probesPerSession: r3(mean(rs.map((r) => (r.naturalness as { probesPerSession: number }).probesPerSession))),
      msPerTurn: r3(mean(rs.map((r) => r.msPerTurn as number))),
    };
  }
  const summary = { totalTurns, seconds: Math.round((Date.now() - t0) / 1000), conditions: agg, learners: results };
  console.log("\n=== AGGREGATE ===");
  console.table(agg);
  mkdirSync("lab/out/transcripts", { recursive: true });
  writeFileSync("lab/out/summary.json", JSON.stringify(summary, null, 2));
  for (const [name, log] of Object.entries(transcripts)) {
    writeFileSync(
      `lab/out/transcripts/${name}.md`,
      log.map((l) => `${l.turn === 0 ? `\n## session ${l.session}\n` : ""}**learner:** ${l.text}\n**tutor** [${l.strategy}/${l.action}/${l.subject}${l.understood === null ? "" : l.understood ? " · truth:understood" : " · truth:confused"}]: ${l.reply.replace(/\n+/g, " ")}\n`).join("\n")
    );
  }
  await db.insert(evalRuns).values({ id: newId("ev"), name: `lab run: ${cohort.length} learners × ${Object.keys(agg).join("/")} · ${results.length} learner-runs`, summary: { totalTurns, seconds: summary.seconds, conditions: agg, perLearner: results.map((r) => ({ learner: r.learner, cond: r.cond, comprehension: r.comprehension, strategyMatch: r.strategyMatch, regret: r.regret, beliefs: r.beliefs, drift: r.drift, perSubject: r.perSubject, calibration: r.calibration, longGaps: r.longGaps, interestChange: r.interestChange, naturalness: r.naturalness })) } });
  console.log(`\n${totalTurns} turns in ${summary.seconds}s. Transcripts in lab/out/transcripts/.`);
  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
