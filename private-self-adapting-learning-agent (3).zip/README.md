# Private Self-Adapting Learning Agent

One tutor, one continuous relationship. The learner talks naturally — "I want to learn Bash", pastes code, asks *why*, disagrees,
changes subject, comes back a week later — and the agent adapts around the conversation using a persistent, evidence-based
model of the learner that it builds from what the learner actually **does**, not only what they say.

```
interaction → perception (signals) → observations (working memory)
           → fast evidence updates (mastery, what-works)      ─┐
           → consolidation (patterns, preferences, tendencies) ─┴→ beliefs (long-term, prior-not-verdict)
           → learner graph (concepts, struggles, navigation)     → context for the next decision
```

## Running

- `npm run build && npm start` (or the platform preview). Schema: `npx drizzle-kit push`.
- Set `OPENAI_API_KEY` (optionally `OPENAI_BASE_URL`, `LLM_MODEL`) for full tutoring with any OpenAI-compatible provider
  (OpenAI, OpenRouter, Groq, Ollama, …). Without a key the app runs in **offline mode**: the whole learner-model machinery is
  live (perception, memory, consolidation, graph, adaptive strategy choice, domain discovery via Wikipedia), but prose
  explanations are outlines rather than generated text.
- MCP (Streamable HTTP, JSON): `POST /api/mcp` — tools `list_learners`, `get_learner_profile`, `search_memory`, `get_graph`,
  `record_observation`, `get_subject`, `consolidate`. External assistants read the accumulated model instead of rebuilding it,
  and can contribute evidence that must earn long-term status like any other observation.

## Architecture

| Layer | Where | What |
| --- | --- | --- |
| Perception | `src/lib/agent/perceive.ts` | Cheap, deterministic signals from natural language: confusion / comprehension, requests (simpler, deeper, example, exercise, move on…), disagreement, self-claims, goals, pasted code. Flags evidence; never classifies the person. |
| Working memory | `observations` table, `src/lib/memory/store.ts` | Rich, lightly interpreted, never deleted. Retrieval = recency + salience + relevance (Generative-Agents style, without embeddings). Consolidation marks, not removes. |
| Long-term memory | `beliefs` table | Recency-weighted Beta posteriors per belief (`mastery`, `strategy_effect`, `preference`, `tendency`, `misconception`, `goal`). Old evidence is discounted as new evidence arrives and with time (60-day half-life), so **the past is a prior, not a verdict**. Status `active/dormant` is earned from *effective* (time-decayed) evidence; dormant beliefs keep full history and reactivate. Mastery has forgetting (stability grows with evidence). |
| Consolidation | `src/lib/memory/consolidate.ts` | Triggered by a salience budget or after long gaps ("sleep"). Requests → context-tagged preferences with base-rate correction; mistakes → tendencies; LLM insights must repeat before becoming beliefs; claims are re-checked against later behaviour (calibration); topic switching described without assuming a cause; status pass; graph decay. Idempotent. |
| Graph | `nodes`, `edges` | Shared subject maps (researched) + per-learner overlay: `part_of`, `prerequisite_of`, `related_to`, `struggles_in`, `confused_with`, `leads_to`. Weights reinforce/decay; inactive edges keep history. Touch count is shown but **never** interpreted as mastery or importance. |
| Domain discovery | `src/lib/subjects/research.ts` | Unknown subject → Wikipedia grounding (search-based disambiguation using the learner's own phrasing: "rust programming" ≠ iron oxide) + LLM concept map when available; section hierarchy fallback otherwise. Maps expand as new concepts appear in conversation. |
| Context & policy | `src/lib/agent/context.ts` | Renders the model with explicit epistemic markers (weak/moderate/strong evidence). Strategy choice: UCB with ε over per-context posteriors, falling back to general evidence when context evidence is thin; flags context-specific divergence. Probes only when uncertainty matters for the next step, rate-limited. |
| Agent loop | `src/lib/agent/agent.ts` | perceive → situate (subject/concepts, switches, research) → attribute outcome of the previous approach → record evidence → build context → act (LLM with a hidden structured evidence block, or the offline tutor) → learn from the model's evidence → consolidate when due. |
| Provider | `src/lib/llm/provider.ts` | OpenAI-compatible abstraction. The learner model never lives inside model context. |

### Design decisions grounded in research / prior art
- Memory stream + recency/importance/relevance retrieval + reflection: Park et al., *Generative Agents* (2023). Importance here is a
  cheap heuristic salience rather than an LLM rating per write (cost, drift across model versions).
- Consolidation levers (importance, merge, decay, eviction): we use *dormancy with preserved history* instead of eviction
  (cf. Zep/Graphiti temporal validity), because historical evidence must remain recoverable.
- Mastery: evidence-weighted posterior with recency discounting and forgetting whose stability grows with successful practice
  (BKT/spacing-inspired, deliberately simple and inspectable).
- Strategy adaptation as a contextual bandit: Thompson sampling and UCB were both implemented and compared empirically (below);
  UCB+ε won decisively because recency-capped counts keep Thompson posteriors permanently wide.
- Mem0 / Letta / Zep were considered and rejected for this deployment: they need external services or an LLM call per write,
  and none offers offline operation on plain Postgres. Their patterns were adopted instead of their code.

## Evidence (the lab)

`lab/` is an experimental harness that drives the real agent and database with synthetic learners whose ground truth is hidden
(per-subject strategy affinities, learning rate, noise, preference drift, over/under-estimation, topic switching, long gaps, chaos).

- `npx tsx lab/run.ts` — 20 archetypes × 12–14 sessions × 12 turns, three conditions (`full`, `no_longterm`, `no_adapt`),
  `LAB_SEEDS=n` for replication. Metrics vs hidden truth: comprehension, regret vs oracle, strategy match, belief accuracy,
  drift recovery, context specificity, calibration detection, long-gap retention/dormancy/reactivation, probe rate, graph shape.
  Transcripts are written to `lab/out/transcripts/` for qualitative review; summaries go to the **Lab** tab in the UI.
- `npx tsx lab/adversarial.ts` — 25 mechanism-level attempts to break guarantees: memory dictatorship, dormancy/reactivation
  with history, false certainty under 50/50 noise, contradictory requests, context specificity, frequency≠importance,
  claims-vs-behaviour calibration, consolidation idempotence, probe rate limits, hostile input, return-after-gap continuity.
- `npx tsx lab/mock-llm.ts` — exercises the provider path with a fake OpenAI-compatible server: prompt assembly, evidence-block
  parsing, subject expansion, LLM observations, misconception edges, graceful outage fallback.

### Headline results (2 seeds × 20 archetypes × 3 conditions = 120 learner-runs, 17,136 turns in 244 s; Lab tab in the UI)

| condition | late comprehension | regret vs oracle | notes |
| --- | --- | --- | --- |
| full | **0.75** (early 0.60) | 0.12 | random baseline 0.54, oracle 0.85 |
| no long-term memory | 0.58 | 0.31 | ≈ random |
| fixed strategy (no adaptation) | 0.48 | 0.40 | great for theory-lovers (0.92–0.96), poor for everyone else |

- Drifter (preference flips at session 7): regret 0.20–0.28 → 0.37 right after the flip → 0.09–0.17 later; the old belief yields.
- Context-dependent learner: converged on `example_first` in bash and `direct` in linear algebra (both near-optimal), with
  context-specific beliefs flagged.
- Pure-noise learner: 0 active tendencies/preferences; strategy confidence stays ≈0.5 with "weak/moderate evidence" labels.
- Probes: 0.08 per session on average — the tutor is not a questionnaire.

### What the lab changed (version-to-version)
1. Advancing was gated on mastery thresholds → the tutor looped on the first concept after "got it" (found in transcripts). Fixed: advancing respects the present.
2. Thompson sampling under-exploited (late strategy match 0.3–0.4) → replaced by UCB+ε (0.86–0.96 on stable learners) after a head-to-head run.
3. Preferences activated from two requests → thresholds raised and a base-rate correction added (sessions without the request count against it).
4. Calibration (claims vs behaviour) only worked when behavioural evidence preceded the claim → claims are now re-examined at later consolidations.
5. Subject resolution hit disambiguation pages ("bash", "rust") → search-based resolution using the learner's full phrase.
6. Beliefs could be `active` with near-zero present-day weight → context now gates on effective weight (stale-memory guard).
7. "let's continue with Bash" was perceived as a request to move on → 80%-confidence spurious preferences for most learners. Fixed; re-run shows preferences only for learners who actually request them (simplifier → *simpler* 0.79, deep-diver → *deeper* 0.82, others none).

### Known limits
- Without a model key, explanations are outlines; mistake-type and misconception evidence primarily come from the model's
  structured observations (or from external tools via MCP).
- The synthetic learners' reaction model is simple by design (strategy affinity + hidden mastery + noise); it measures adaptation
  machinery, not pedagogy quality. Qualitative review of real transcripts remains necessary.
