import { eq } from "drizzle-orm";
import { db } from "@/db";
import { subjects, type SubjectConcept } from "@/db/schema";
import { getProvider, extractJson } from "@/lib/llm/provider";
import { slugify } from "@/lib/agent/perceive";
import { reinforceEdge, touchNode, SHARED } from "@/lib/memory/store";

export type Subject = typeof subjects.$inferSelect;

const ALIASES: Record<string, string> = {
  shell: "bash",
  "bash scripting": "bash",
  "shell scripting": "bash",
  "the shell": "bash",
  "command line": "bash",
  linux: "bash",
  js: "javascript",
  ts: "typescript",
  py: "python",
  "linear algebra": "linear-algebra",
  postgres: "sql",
  postgresql: "sql",
  databases: "sql",
};

export function normalizeSubjectName(raw: string) {
  const cleaned = raw
    .toLowerCase()
    .replace(/\b(?:programming|language|basics|fundamentals|scripting)\b/g, (m) => (m === "scripting" && /bash|shell/.test(raw.toLowerCase()) ? "" : m))
    .replace(/\s+/g, " ")
    .trim();
  const alias = ALIASES[cleaned] ?? ALIASES[cleaned.replace(/ (?:programming|language|basics|fundamentals)$/, "")];
  const slug = slugify(alias ?? cleaned.replace(/ (?:programming|language|basics|fundamentals)$/, ""));
  return { slug, name: alias ? alias.replace(/-/g, " ") : cleaned.replace(/ (?:programming|language|basics|fundamentals)$/, "") };
}

export async function listSubjects(): Promise<Subject[]> {
  return db.select().from(subjects);
}

export async function getSubject(slug: string): Promise<Subject | null> {
  const [s] = await db.select().from(subjects).where(eq(subjects.slug, slug)).limit(1);
  return s ?? null;
}

async function fetchJson(url: string, ms = 8000): Promise<unknown | null> {
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), ms);
  try {
    const r = await fetch(url, { signal: c.signal, headers: { "user-agent": "self-adapting-learning-agent/1.0 (research)" } });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

type WikiSummary = { title?: string; extract?: string; content_urls?: { desktop?: { page?: string } }; type?: string };

/** Ground the subject in a real source (Wikipedia REST), used with or without an LLM. */
type Section = { label: string; parent: string | null };

async function wikipediaGrounding(name: string, rawPhrase?: string): Promise<{ title: string; extract: string; url: string; sections: Section[] } | null> {
  const summaryFor = async (t: string) => (await fetchJson(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(t.replace(/\s+/g, "_"))}?redirect=true`)) as WikiSummary | null;
  // The learner's full phrase ("rust programming") carries disambiguating context; search with it first.
  const query = rawPhrase && rawPhrase.toLowerCase() !== name.toLowerCase() ? rawPhrase : name;
  let summary = query === name ? await summaryFor(name) : null;
  if (!summary?.extract || summary.type === "disambiguation") {
    // Resolve through search: skip disambiguation pages, prefer titles that start with the name.
    const search = (await fetchJson(`https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&srlimit=6&format=json&origin=*`)) as { query?: { search?: { title: string }[] } } | null;
    const titles = (search?.query?.search ?? []).map((s) => s.title);
    const ordered = [...titles.filter((t) => t.toLowerCase().startsWith(name.toLowerCase())), ...titles.filter((t) => !t.toLowerCase().startsWith(name.toLowerCase()))];
    summary = null;
    for (const t of ordered.slice(0, 4)) {
      const s = await summaryFor(t);
      if (s?.extract && s.type !== "disambiguation") {
        summary = s;
        break;
      }
    }
    if (!summary) return null;
  }
  const sec = (await fetchJson(
    `https://en.wikipedia.org/w/api.php?action=parse&page=${encodeURIComponent(summary.title ?? name)}&prop=sections&format=json&origin=*&redirects=1`
  )) as { parse?: { sections?: { line: string; toclevel: number; number: string }[] } } | null;
  const skip =
    /^(see also|references|external links|notes|further reading|history|bibliography|citations|sources|footnotes|gallery|documentation|bug reporting|timeline|table of features|deprecated syntax|security and vulnerabilities|explanatory notes|general and cited sources|usage and applications|extensions and generalizations|online resources|online books|introductory textbooks|advanced textbooks|study guides and outlines|further resources|user manual|man page|posix specification|definitions|other modes|interactive-only features|observability|criticism|reception|legacy|etymology|in popular culture|awards|controversies)$/i;
  const raw = sec?.parse?.sections ?? [];
  const skippedTop = new Set(raw.filter((s) => s.toclevel === 1 && skip.test(s.line.replace(/<[^>]+>/g, "").trim())).map((s) => s.number.split(".")[0]));
  const clean = (l: string) => l.replace(/<[^>]+>/g, "").trim();
  const ok = (l: string) => l.length > 2 && l.length < 50 && !skip.test(l);
  const tops = raw.filter((s) => s.toclevel === 1 && !skippedTop.has(s.number.split(".")[0]) && ok(clean(s.line)));
  const sections: Section[] = tops.map((s) => ({ label: clean(s.line), parent: null }));
  for (const t of tops) {
    if (sections.length >= 24) break;
    const kids = raw.filter((s) => s.toclevel === 2 && s.number.startsWith(`${t.number}.`) && ok(clean(s.line))).slice(0, 4);
    for (const k of kids) if (sections.length < 24 && !sections.some((x) => x.label === clean(k.line))) sections.push({ label: clean(k.line), parent: clean(t.line) });
  }
  return { title: summary.title ?? name, extract: summary.extract ?? "", url: summary.content_urls?.desktop?.page ?? `https://en.wikipedia.org/wiki/${encodeURIComponent(summary.title ?? name)}`, sections };
}

type Outline = { name?: string; summary?: string; concepts?: SubjectConcept[]; sources?: { title: string; url?: string }[] };

async function llmOutline(name: string, grounding: string | null): Promise<Outline | null> {
  const p = getProvider();
  if (!p) return null;
  const text = await p.complete(
    [
      {
        role: "system",
        content:
          "You are a curriculum researcher. Produce a compact, accurate concept map for teaching a subject to a self-directed learner. Return JSON only: {\"name\":string,\"summary\":string,\"concepts\":[{\"slug\":kebab,\"label\":string,\"description\":string,\"prerequisites\":[slugs],\"level\":1-5}],\"sources\":[{\"title\":string,\"url\":string}]}. 10-22 concepts ordered from foundational to advanced; prerequisites reference earlier slugs only; sources must be real official docs/reference pages you are confident exist.",
      },
      { role: "user", content: `Subject: ${name}\n${grounding ? `Reference summary:\n${grounding.slice(0, 1500)}` : ""}` },
    ],
    { temperature: 0.2, json: true, maxTokens: 2500 }
  );
  return extractJson<Outline>(text);
}

/** Ensure a subject exists; research it if it does not. Returns the subject row. */
export async function ensureSubject(rawName: string, opts: { now?: Date; skipNetwork?: boolean } = {}): Promise<{ subject: Subject; researched: boolean }> {
  const { slug, name } = normalizeSubjectName(rawName);
  if (!slug) throw new Error("empty subject");
  const existing = await getSubject(slug);
  if (existing) return { subject: existing, researched: false };

  const now = opts.now ?? new Date();
  const grounding = opts.skipNetwork ? null : await wikipediaGrounding(name, rawName);
  let outline = opts.skipNetwork ? null : await llmOutline(name, grounding?.extract ?? null).catch(() => null);
  let origin = "llm";
  if (!outline?.concepts?.length) {
    origin = grounding ? "web" : "heuristic";
    const secs = grounding?.sections ?? [];
    const tops = secs.filter((x) => !x.parent);
    const concepts: SubjectConcept[] = secs.map((x) => {
      const ti = tops.findIndex((t) => t.label === (x.parent ?? x.label));
      return {
        slug: slugify(x.label),
        label: x.label,
        level: Math.min(5, 1 + Math.floor(Math.max(0, ti) / 3) + (x.parent ? 1 : 0)),
        prerequisites: x.parent ? [slugify(x.parent)] : ti > 0 ? [slugify(tops[ti - 1].label)] : [],
      };
    });
    outline = {
      name: grounding?.title ?? name,
      summary: grounding?.extract ?? `${name} (discovered from conversation; structure will emerge as we go)`,
      concepts: concepts.length ? concepts : [{ slug: `${slug}-basics`, label: `${name} basics`, level: 1, prerequisites: [] }],
      sources: grounding ? [{ title: `Wikipedia: ${grounding.title}`, url: grounding.url }] : [],
    };
  } else if (grounding) {
    outline.sources = [{ title: `Wikipedia: ${grounding.title}`, url: grounding.url }, ...(outline.sources ?? [])];
  }

  const concepts = dedupeConcepts(outline.concepts ?? []);
  const row = {
    slug,
    name: (outline.name ?? name).slice(0, 80),
    summary: outline.summary?.slice(0, 2000) ?? null,
    concepts,
    sources: (outline.sources ?? []).slice(0, 12),
    origin,
    createdAt: now,
    updatedAt: now,
  };
  await db.insert(subjects).values(row).onConflictDoNothing();
  await writeSubjectGraph(slug, row.name, concepts, now);
  const [saved] = await db.select().from(subjects).where(eq(subjects.slug, slug)).limit(1);
  return { subject: saved, researched: true };
}

function dedupeConcepts(list: SubjectConcept[]): SubjectConcept[] {
  const seen = new Set<string>();
  const out: SubjectConcept[] = [];
  for (const c of list) {
    const s = slugify(c.slug || c.label || "");
    if (!s || seen.has(s)) continue;
    seen.add(s);
    out.push({ slug: s, label: (c.label || s).slice(0, 60), description: c.description?.slice(0, 300), prerequisites: (c.prerequisites ?? []).map(slugify).filter((p) => p !== s), level: c.level ?? 1 });
  }
  return out.slice(0, 30);
}

async function writeSubjectGraph(slug: string, name: string, concepts: SubjectConcept[], now: Date) {
  const subjId = await touchNode(SHARED, "subject", slug, name, { subject: slug, now });
  const ids = new Map<string, string>();
  for (const c of concepts) ids.set(c.slug, await touchNode(SHARED, "concept", c.slug, c.label, { subject: slug, description: c.description, now }));
  for (const c of concepts) {
    await reinforceEdge(SHARED, ids.get(c.slug)!, subjId, "part_of", { delta: 0.5, now });
    for (const p of c.prerequisites ?? []) if (ids.has(p)) await reinforceEdge(SHARED, ids.get(p)!, ids.get(c.slug)!, "prerequisite_of", { delta: 0.5, now });
  }
}

/** Add a concept discovered during conversation to the shared subject model (graph expands through use). */
export async function expandSubject(slug: string, concept: { slug: string; label: string; description?: string; relatedTo?: string[] }, now = new Date()) {
  const s = await getSubject(slug);
  if (!s) return;
  const cslug = slugify(concept.slug || concept.label);
  if (!cslug) return;
  if (!s.concepts.some((c) => c.slug === cslug)) {
    const concepts = [...s.concepts, { slug: cslug, label: concept.label.slice(0, 60), description: concept.description?.slice(0, 300), prerequisites: [], level: 3 }];
    await db.update(subjects).set({ concepts, updatedAt: now }).where(eq(subjects.slug, slug));
  }
  const subjId = await touchNode(SHARED, "subject", slug, s.name, { subject: slug, now, boost: 0.05 });
  const cid = await touchNode(SHARED, "concept", cslug, concept.label, { subject: slug, description: concept.description, now });
  await reinforceEdge(SHARED, cid, subjId, "part_of", { delta: 0.2, now });
  for (const r of concept.relatedTo ?? []) {
    const rs = slugify(r);
    if (rs && rs !== cslug && s.concepts.some((c) => c.slug === rs)) {
      const rid = await touchNode(SHARED, "concept", rs, s.concepts.find((c) => c.slug === rs)!.label, { subject: slug, now, boost: 0.02 });
      await reinforceEdge(SHARED, cid, rid, "related_to", { delta: 0.1, now });
    }
  }
}

/** Detect which known subject a message refers to (explicit mention wins; else null). */
export function detectSubjectMention(text: string, known: Subject[]): Subject | null {
  const lower = ` ${text.toLowerCase()} `;
  let best: { s: Subject; len: number } | null = null;
  for (const s of known) {
    const names = [s.name.toLowerCase(), s.slug.replace(/-/g, " "), ...Object.entries(ALIASES).filter(([, v]) => v === s.slug).map(([k]) => k)];
    for (const n of names) {
      if (n.length < 2) continue;
      const re = new RegExp(`[^a-z0-9]${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}[^a-z0-9]`, "i");
      if (re.test(lower) && (!best || n.length > best.len)) best = { s, len: n.length };
    }
  }
  return best?.s ?? null;
}
