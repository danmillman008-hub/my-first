import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { messages, sessions, type MessageMeta, type ObservationKind } from "@/db/schema";
import { getProvider, extractJson, type ChatMessage } from "@/lib/llm/provider";
import { applyBeliefEvidence, newId, recordObservation, reinforceEdge, touchNode } from "@/lib/memory/store";
import { consolidate, shouldConsolidate, STRATEGY_LABELS } from "@/lib/memory/consolidate";
import { detectSubjectMention, ensureSubject, expandSubject, listSubjects, type Subject } from "@/lib/subjects/research";
import { matchConcepts, perceive, slugify, type Signals } from "./perceive";
import { buildLearnerContext, renderContext, type LearnerContext, type Rng } from "./context";
import { offlineReply } from "./offline";

export type AgentOptions = {
  now?: Date;
  rng?: Rng;
  useLongTerm?: boolean;
  useWorkingMemory?: boolean;
  adaptive?: boolean;
  allowProbes?: boolean;
  forceOffline?: boolean;
  skipNetwork?: boolean;
};

export type TurnResult = {
  reply: string;
  meta: MessageMeta;
  signals: Signals;
  context: LearnerContext;
  consolidated: boolean;
  researchedSubject?: string;
  userMessageId: string;
  assistantMessageId: string;
};

type EvidenceBlock = {
  strategy?: string;
  action?: string;
  concepts?: string[];
  newConcepts?: { slug?: string; label: string; description?: string; relatedTo?: string[] }[];
  observations?: { kind: string; content: string; concept?: string; polarity?: number; mistakeType?: string; salience?: number; confusedWith?: string }[];
  insight?: { key: string; content: string; polarity?: number; kind?: string } | null;
};

export function seededRng(seed: number): Rng {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Concepts that are natural to work on next: not yet solid, prerequisites at least partially evidenced. */
export function frontierConcepts(subject: Subject | null, mastery: LearnerContext["mastery"], limit = 3): string[] {
  if (!subject) return [];
  const p = new Map(mastery.map((m) => [m.concept, m]));
  const solid = (slug: string) => (p.get(slug)?.p ?? 0) >= 0.6 && (p.get(slug)?.weight ?? 0) >= 0.8;
  const touchedOk = (slug: string) => (p.get(slug)?.p ?? 0) >= 0.5 && (p.get(slug)?.weight ?? 0) >= 0.4;
  return subject.concepts
    .filter((c) => !solid(c.slug) && (c.prerequisites ?? []).every((pr) => solid(pr) || touchedOk(pr) || !subject.concepts.some((x) => x.slug === pr)))
    .sort((a, b) => (a.level ?? 1) - (b.level ?? 1))
    .slice(0, limit)
    .map((c) => c.slug);
}

/** The concept to move to when the learner wants to advance: never gate on mastery thresholds (respect the present). */
export function nextConcept(subject: Subject | null, focus: string | null, mastery: LearnerContext["mastery"]): string | null {
  if (!subject || !subject.concepts.length) return null;
  const p = new Map(mastery.map((m) => [m.concept, m]));
  const solid = (slug: string) => (p.get(slug)?.p ?? 0) >= 0.6 && (p.get(slug)?.weight ?? 0) >= 0.8;
  const order = [...subject.concepts].sort((a, b) => (a.level ?? 1) - (b.level ?? 1));
  const i = focus ? order.findIndex((c) => c.slug === focus) : -1;
  const after = [...order.slice(i + 1), ...order.slice(0, Math.max(0, i))];
  return (after.find((c) => c.slug !== focus && !solid(c.slug)) ?? after[0] ?? null)?.slug ?? null;
}

const SYSTEM_PROMPT = `You are a private tutor who is also a good conversational partner. One learner, one continuous relationship.

How to behave:
- Follow the learner. They may learn, ask unrelated questions, paste code, debug, digress, disagree, or change subject. Go with them. Never force a curriculum, a quiz, or a "mode".
- Decide freely what is most useful right now: answer directly, explain, give an example, ask ONE natural question, suggest a tiny exercise, review their code, point out a missing prerequisite, or simply continue the conversation.
- The LEARNER MODEL below is accumulated evidence from past interactions. Treat it as a prior, not a verdict. The present message always wins. Never announce the model ("I notice you prefer…") unless it is genuinely helpful; just act on it.
- If the learner disagrees or corrects you, take it seriously — they may be right. Say so if they are.
- Do not interrogate. At most one question per turn, and only when the answer changes what you would do next. Do not ask questions just to "assess".
- Be honest about uncertainty. Do not present weak inferences as facts.
- Match length to need: short for quick questions, longer for explanations. Use code blocks for code.

After your reply, append a fenced block tagged \`evidence\` containing JSON (the learner never sees it):
{"strategy": one of ${Object.keys(STRATEGY_LABELS).join("|")},
 "action": "answer|explain|ask|probe|exercise|review_code|redirect|continue|research",
 "concepts": ["slugs of the concepts this turn was really about (from the subject map when possible)"],
 "newConcepts": [{"slug":"kebab","label":"...","description":"...","relatedTo":["existing-slug"]}]  (only concepts genuinely missing from the subject map),
 "observations": [{"kind":"success|mistake|understanding|confusion|claim|remark|disagreement","content":"specific, behavioural, one sentence","concept":"slug","polarity":-1..1,"mistakeType":"syntax|conceptual|careless","confusedWith":"slug","salience":0..1}]  (only what you actually observed in THIS learner message, 0-4 items),
 "insight": {"key":"kebab-key","content":"a higher-level pattern worth remembering only if it repeats","polarity":1} or null}`;

async function lastAssistant(sessionId: string) {
  const [m] = await db
    .select()
    .from(messages)
    .where(and(eq(messages.sessionId, sessionId), eq(messages.role, "assistant")))
    .orderBy(desc(messages.createdAt))
    .limit(1);
  return m ?? null;
}

async function previousSessionGapHours(learnerId: string, sessionId: string, now: Date) {
  const rows = await db.select().from(sessions).where(eq(sessions.learnerId, learnerId)).orderBy(desc(sessions.lastActiveAt)).limit(5);
  const prev = rows.find((s) => s.id !== sessionId);
  return prev ? (now.getTime() - prev.lastActiveAt.getTime()) / 36e5 : null;
}

export async function handleTurn(learnerId: string, sessionId: string, userText: string, opts: AgentOptions = {}): Promise<TurnResult> {
  const now = opts.now ?? new Date();
  const rng = opts.rng ?? Math.random;
  const text = userText.trim();

  // --- session bookkeeping & "sleep" consolidation after a long gap ---
  const [priorTurns] = await db.select({ id: messages.id }).from(messages).where(eq(messages.sessionId, sessionId)).limit(1);
  const firstTurn = !priorTurns;
  if (firstTurn) {
    const gap = await previousSessionGapHours(learnerId, sessionId, now);
    if (gap !== null && gap > 20) {
      await consolidate(learnerId, now).catch(() => null);
      await recordObservation({ learnerId, sessionId, kind: "remark", content: `returned after ${Math.round(gap / 24)} day(s)`, salience: 0.15, data: { gapHours: gap }, createdAt: now });
    }
  }

  const userMessageId = newId("m");
  await db.insert(messages).values({ id: userMessageId, sessionId, learnerId, role: "user", content: text, meta: {}, createdAt: now });
  await db.update(sessions).set({ lastActiveAt: now }).where(eq(sessions.id, sessionId));

  const signals = perceive(text);
  const prev = await lastAssistant(sessionId);
  const known = await listSubjects();

  // --- situate: subject & concepts ---
  let subject: Subject | null = prev?.meta.subject ? known.find((s) => s.slug === prev.meta.subject) ?? null : null;
  if (!subject) {
    // fall back to the learner's most recent subject across sessions (continuity across days)
    const [lastAny] = await db
      .select({ meta: messages.meta })
      .from(messages)
      .where(and(eq(messages.learnerId, learnerId), eq(messages.role, "assistant")))
      .orderBy(desc(messages.createdAt))
      .limit(1);
    if (lastAny?.meta.subject) subject = known.find((s) => s.slug === lastAny.meta.subject) ?? null;
  }
  let researchedSubject: string | undefined;
  const mentioned = detectSubjectMention(text, known);
  if (signals.goal) {
    const goalName = signals.goal.replace(/\b(?:the|a|an)\b/g, "").trim();
    try {
      const r = await ensureSubject(goalName, { now, skipNetwork: opts.skipNetwork });
      if (r.researched) researchedSubject = r.subject.name;
      if (!subject || subject.slug !== r.subject.slug) {
        if (subject) await recordObservation({ learnerId, sessionId, messageId: userMessageId, kind: "topic_switch", content: `switched from ${subject.name} to ${r.subject.name}`, subject: r.subject.slug, salience: 0.3, createdAt: now });
        subject = r.subject;
      }
      await recordObservation({ learnerId, sessionId, messageId: userMessageId, kind: "goal", content: `wants to learn ${r.subject.name}`, subject: r.subject.slug, salience: 0.7, polarity: 1, createdAt: now });
      await applyBeliefEvidence({ learnerId, kind: "goal", key: `goal:${r.subject.slug}`, statement: `wants to learn ${r.subject.name}`, subject: r.subject.slug, positive: true, weight: 1, sessionId, now, recencyFactor: 1 });
    } catch {
      /* unparseable goal; continue */
    }
  } else if (mentioned && (!subject || mentioned.slug !== subject.slug)) {
    if (subject) await recordObservation({ learnerId, sessionId, messageId: userMessageId, kind: "topic_switch", content: `moved from ${subject.name} to ${mentioned.name}`, subject: mentioned.slug, salience: 0.3, createdAt: now });
    subject = mentioned;
  } else if (!subject && signals.codeLanguage) {
    subject = known.find((s) => s.slug === signals.codeLanguage) ?? null;
  }

  let concepts = subject ? matchConcepts(text, subject.concepts) : [];
  const continuing = !signals.goal && !mentioned && prev?.meta.subject === subject?.slug;
  if (!concepts.length && continuing && prev?.meta.concepts?.length) concepts = prev.meta.concepts.slice(0, 2);
  const subjSlug = subject?.slug ?? null;

  // --- attribute outcome of the previous strategy (learning from what the learner does) ---
  const prevStrategy = prev?.meta.strategy;
  const prevConcepts = prev?.meta.concepts ?? [];
  const outcome = signals.understanding > 0 && signals.confusion < 0.5 ? "understood" : signals.confusion > 0 || signals.request === "simpler" ? "confused" : null;
  if (prevStrategy && outcome && continuing) {
    const positive = outcome === "understood";
    const oid = await recordObservation({
      learnerId,
      sessionId,
      messageId: userMessageId,
      kind: "strategy_outcome",
      content: `${STRATEGY_LABELS[prevStrategy] ?? prevStrategy} → ${outcome}${prevConcepts.length ? ` (${prevConcepts.join(", ")})` : ""}`,
      subject: subjSlug,
      concepts: prevConcepts,
      data: { strategy: prevStrategy, outcome },
      polarity: positive ? 1 : -1,
      salience: 0.45,
      createdAt: now,
    });
    if (opts.useLongTerm !== false) {
      for (const scope of [subjSlug ?? "general", "general"]) {
        if (scope === "general" && subjSlug === null) continue;
        await applyBeliefEvidence({
          learnerId,
          kind: "strategy_effect",
          key: `strategy:${scope}:${prevStrategy}`,
          statement: `${STRATEGY_LABELS[prevStrategy] ?? prevStrategy} tends to ${positive ? "land" : "miss"}${scope !== "general" ? ` in ${scope}` : ""}`,
          subject: scope === "general" ? null : scope,
          positive,
          weight: 1,
          evidenceId: oid,
          sessionId,
          now,
          recencyFactor: 0.96,
        });
      }
      for (const c of prevConcepts) await masteryEvidence(learnerId, subjSlug, c, positive, positive ? 0.6 : 0.5, oid, sessionId, now, subject);
    }
    if (subject && prevConcepts.length && !positive) {
      const sid = await touchNode(learnerId, "subject", subject.slug, subject.name, { subject: subject.slug, now, boost: 0.05 });
      for (const c of prevConcepts) {
        const cid = await touchNode(learnerId, "concept", c, labelFor(subject, c), { subject: subject.slug, now, boost: 0.1 });
        await reinforceEdge(learnerId, cid, sid, "struggles_in", { delta: 0.2, now, note: `confused after ${prevStrategy}` });
      }
    }
  }

  // --- heuristic observations ---
  const obsIds: string[] = [];
  const add = async (kind: ObservationKind, content: string, extra: { data?: Record<string, unknown>; polarity?: number; salience?: number; concepts?: string[] } = {}) => {
    const id = await recordObservation({ learnerId, sessionId, messageId: userMessageId, kind, content, subject: subjSlug, concepts: extra.concepts ?? concepts, data: extra.data, polarity: extra.polarity, salience: extra.salience, createdAt: now });
    obsIds.push(id);
    return id;
  };
  if (signals.confusion >= 0.5 && !outcome) await add("confusion", `expressed confusion: "${text.slice(0, 120)}"`, { polarity: -1, salience: 0.5 });
  if (signals.request) await add("request", `asked for: ${signals.request}`, { data: { request: signals.request }, salience: signals.request === "move_on" || signals.request === "explain_why" ? 0.3 : 0.4 });
  if (signals.disagreement) await add("disagreement", `pushed back on the tutor: "${text.slice(0, 120)}"`, { salience: 0.6 });
  if (signals.frustration > 0) await add("remark", `signs of frustration: "${text.slice(0, 100)}"`, { salience: 0.5, polarity: -0.5 });
  if (signals.hasCode) await add("remark", `shared ${signals.codeLanguage ?? ""} code (${text.split("\n").length} lines)`, { data: { hasCode: true, language: signals.codeLanguage }, salience: 0.35 });
  for (const [claim, positive] of [
    [signals.claimsKnowledge, true],
    [signals.claimsIgnorance, false],
  ] as const) {
    if (!claim) continue;
    const cs = subject ? matchConcepts(claim, subject.concepts) : [];
    const id = await add("claim", `${positive ? "says they know" : "says they have not used"} ${claim}`, { polarity: positive ? 1 : -1, salience: 0.45, concepts: cs, data: { claim, positive } });
    if (opts.useLongTerm !== false) for (const c of cs) await masteryEvidence(learnerId, subjSlug, c, positive, 0.35, id, sessionId, now, subject, "self-report");
  }

  // --- learner graph: concepts touched, co-occurrence, navigation ---
  if (subject && opts.useLongTerm !== false) {
    const sid = await touchNode(learnerId, "subject", subject.slug, subject.name, { subject: subject.slug, now, boost: 0.1 });
    const ids: string[] = [];
    for (const c of concepts) {
      const cid = await touchNode(learnerId, "concept", c, labelFor(subject, c), { subject: subject.slug, now });
      ids.push(cid);
      await reinforceEdge(learnerId, cid, sid, "part_of", { delta: 0.1, now });
    }
    for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) await reinforceEdge(learnerId, ids[i], ids[j], "related_to", { delta: 0.1, now, note: "co-mentioned" });
    if (prevConcepts.length && concepts.length && prevConcepts[0] !== concepts[0] && prev?.meta.subject === subject.slug) {
      const from = await touchNode(learnerId, "concept", prevConcepts[0], labelFor(subject, prevConcepts[0]), { subject: subject.slug, now, boost: 0 });
      await reinforceEdge(learnerId, from, ids[0], "leads_to", { delta: 0.1, now });
    }
  }

  // --- context & decision ---
  const context = await buildLearnerContext(learnerId, subject, concepts, {
    sessionId,
    now,
    request: signals.request,
    rng,
    useLongTerm: opts.useLongTerm,
    useWorkingMemory: opts.useWorkingMemory,
    adaptive: opts.adaptive,
    allowProbes: opts.allowProbes,
  });
  const frontier = frontierConcepts(subject, context.mastery);

  const provider = opts.forceOffline ? null : getProvider();
  let reply = "";
  let meta: MessageMeta = { strategy: context.recommended.strategy, action: "explain", concepts, subject: subjSlug ?? undefined, provider: provider?.name ?? "offline", researched: !!researchedSubject };
  let evidence: EvidenceBlock | null = null;

  if (provider) {
    const history = await db.select().from(messages).where(eq(messages.sessionId, sessionId)).orderBy(desc(messages.createdAt)).limit(14);
    const convo: ChatMessage[] = history
      .reverse()
      .filter((m) => m.id !== userMessageId)
      .map((m) => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.content }));
    const subjectBlock = subject
      ? `SUBJECT MAP (${subject.name}${researchedSubject ? ", just researched" : ""}): ${subject.concepts.map((c) => `${c.slug}${c.prerequisites?.length ? `←[${c.prerequisites.join(",")}]` : ""}`).join(", ")}${frontier.length ? `\nNatural next steps given evidence: ${frontier.join(", ")}` : ""}`
      : "No subject in focus yet.";
    const sys = `${SYSTEM_PROMPT}\n\n${renderContext(context, now)}\n\n${subjectBlock}${firstTurn && context.totalEvidence > 0 ? "\n(New session; the learner is returning. Pick up naturally, no recap unless useful.)" : ""}`;
    try {
      const raw = await provider.complete([{ role: "system", content: sys }, ...convo, { role: "user", content: text }], { temperature: 0.6, maxTokens: 1400 });
      const m = raw.match(/```evidence\s*([\s\S]*?)```\s*$/i);
      reply = (m ? raw.slice(0, m.index) : raw).trim();
      evidence = m ? extractJson<EvidenceBlock>(m[1]) : extractJson<EvidenceBlock>(raw.slice(raw.lastIndexOf("{\"strategy\"")));
      if (!reply) reply = raw.replace(/```evidence[\s\S]*$/i, "").trim();
    } catch (e) {
      reply = `I hit a problem reaching the model provider (${(e as Error).message.slice(0, 120)}). ` + offlineReply({ signals, context, subject, frontier, next: nextConcept(subject, concepts[0] ?? null, context.mastery), firstTurn, researchedSubject, text }).reply;
    }
  } else {
    const off = offlineReply({ signals, context, subject, frontier, next: nextConcept(subject, concepts[0] ?? null, context.mastery), firstTurn, researchedSubject, text });
    reply = off.reply;
    meta = { ...meta, strategy: off.strategy, action: off.action, concepts: off.concepts.length ? off.concepts : concepts };
  }

  // --- learn from the model's structured evidence ---
  if (evidence) {
    if (evidence.strategy && STRATEGY_LABELS[evidence.strategy]) meta.strategy = evidence.strategy;
    if (evidence.action) meta.action = evidence.action;
    if (Array.isArray(evidence.concepts) && evidence.concepts.length) meta.concepts = evidence.concepts.map(slugify).filter(Boolean).slice(0, 5);
    if (subject && Array.isArray(evidence.newConcepts)) {
      for (const nc of evidence.newConcepts.slice(0, 4)) if (nc?.label) await expandSubject(subject.slug, { slug: nc.slug ?? slugify(nc.label), label: nc.label, description: nc.description, relatedTo: nc.relatedTo }, now);
    }
    for (const o of (evidence.observations ?? []).slice(0, 4)) {
      if (!o?.kind || !o.content) continue;
      const kind = (["success", "mistake", "understanding", "confusion", "claim", "remark", "disagreement"].includes(o.kind) ? o.kind : "remark") as ObservationKind;
      const c = o.concept ? slugify(o.concept) : undefined;
      const id = await recordObservation({
        learnerId,
        sessionId,
        messageId: userMessageId,
        kind,
        content: o.content,
        subject: subjSlug,
        concepts: c ? [c] : meta.concepts ?? [],
        data: { mistakeType: o.mistakeType, confusedWith: o.confusedWith, hasCode: signals.hasCode },
        polarity: o.polarity ?? (kind === "success" || kind === "understanding" ? 1 : kind === "mistake" || kind === "confusion" ? -1 : 0),
        salience: Math.min(1, Math.max(0.2, o.salience ?? 0.5)),
        source: "llm",
        createdAt: now,
      });
      obsIds.push(id);
      if (opts.useLongTerm !== false && c && (kind === "success" || kind === "mistake" || kind === "understanding" || kind === "confusion")) {
        const positive = kind === "success" || kind === "understanding";
        await masteryEvidence(learnerId, subjSlug, c, positive, kind === "success" || kind === "mistake" ? 1 : 0.6, id, sessionId, now, subject);
      }
      if (subject && c && o.confusedWith && opts.useLongTerm !== false) {
        const a = await touchNode(learnerId, "concept", c, labelFor(subject, c), { subject: subject.slug, now });
        const b = await touchNode(learnerId, "concept", slugify(o.confusedWith), labelFor(subject, slugify(o.confusedWith)), { subject: subject.slug, now });
        await reinforceEdge(learnerId, a, b, "confused_with", { delta: 0.25, now, note: o.content.slice(0, 80) });
        await applyBeliefEvidence({ learnerId, kind: "misconception", key: `misconception:${subject.slug}:${c}~${slugify(o.confusedWith)}`, statement: `tends to confuse ${labelFor(subject, c)} with ${labelFor(subject, slugify(o.confusedWith))}`, subject: subject.slug, concept: c, positive: true, weight: 1, evidenceId: id, sessionId, now });
      }
    }
    if (evidence.insight?.key && evidence.insight.content) {
      obsIds.push(await recordObservation({ learnerId, sessionId, messageId: userMessageId, kind: "insight", content: evidence.insight.content, subject: subjSlug, concepts: meta.concepts ?? [], data: { key: slugify(evidence.insight.key), beliefKind: evidence.insight.kind === "preference" ? "preference" : "tendency" }, polarity: evidence.insight.polarity ?? 1, salience: 0.5, source: "llm", createdAt: now }));
    }
  }

  meta.evidenceIds = obsIds;
  meta.signals = { confusion: signals.confusion, understanding: signals.understanding, request: signals.request, disagreement: signals.disagreement, hasCode: signals.hasCode, outcome };
  const assistantMessageId = newId("m");
  await db.insert(messages).values({ id: assistantMessageId, sessionId, learnerId, role: "assistant", content: reply, meta, createdAt: new Date(now.getTime() + 1) });
  if (firstTurn) await db.update(sessions).set({ title: (signals.goal ? `Learning ${subject?.name ?? signals.goal}` : text.slice(0, 48)) || "Conversation" }).where(eq(sessions.id, sessionId));

  let consolidated = false;
  if (opts.useLongTerm !== false && (await shouldConsolidate(learnerId, now))) {
    await consolidate(learnerId, now);
    consolidated = true;
  }
  return { reply, meta, signals, context, consolidated, researchedSubject, userMessageId, assistantMessageId };
}

function labelFor(subject: Subject, slug: string) {
  return subject.concepts.find((c) => c.slug === slug)?.label ?? slug.replace(/-/g, " ");
}

async function masteryEvidence(learnerId: string, subjSlug: string | null, concept: string, positive: boolean, weight: number, evidenceId: string, sessionId: string, now: Date, subject: Subject | null, note?: string) {
  await applyBeliefEvidence({
    learnerId,
    kind: "mastery",
    key: `mastery:${subjSlug ?? "general"}:${concept}`,
    statement: `understands ${subject ? labelFor(subject, concept) : concept}${subjSlug ? ` (${subjSlug})` : ""}`,
    subject: subjSlug,
    concept,
    positive,
    weight,
    evidenceId,
    sessionId,
    now,
    recencyFactor: 0.85,
    note,
  });
}
