// Heuristic perception: turns a raw learner message into lightly interpreted signals.
// Deliberately conservative: it flags evidence, it does not classify the learner.

export type RequestType = "simpler" | "deeper" | "example" | "exercise" | "move_on" | "slow_down" | "explain_why" | "demonstrate";

export type Signals = {
  confusion: number; // 0..1
  understanding: number; // 0..1
  frustration: number;
  hasCode: boolean;
  codeLanguage?: string;
  request?: RequestType;
  disagreement: boolean;
  claimsKnowledge?: string; // "I already know pipes"
  claimsIgnorance?: string; // "I've never used loops"
  goal?: string; // "I want to learn Bash" -> "bash"
  isQuestion: boolean;
  isWhy: boolean;
  tokens: string[];
  length: number;
};

const CONFUSION = [
  /\bi (?:don'?t|do not|still don'?t|really don'?t) (?:get|understand|follow|see)\b/i,
  /\b(?:confus(?:ed|ing)|lost|no idea|makes no sense|doesn'?t make sense|what does that mean|huh\??)\b/i,
  /\bnot (?:sure|clear) (?:i|what|how|why)\b/i,
  /\bwhy (?:doesn'?t|does not|isn'?t|won'?t) (?:this|it|that) work\b/i,
  /\b(?:error|exception|fails?|failing|broken|doesn'?t work|not working|stuck)\b/i,
  /\bcan you (?:explain|clarify) (?:that|this|again)\b/i,
];
const UNDERSTANDING = [
  /\b(?:oh+|ah+|aha),? (?:i (?:get|see|understand)|got it|that makes sense|right|ok(?:ay)? (?:i see|got it))\b/i,
  /\b(?:got it|i get it|i see(?: now)?|makes sense|that (?:helps|helped|clicked|worked)|it works now|works now|thanks?,? that)\b/i,
  /\b(?:i understand|understood|clear now|perfect,? thanks|that's clear|now i get)\b/i,
  /\b(?:it worked|that worked|solved|fixed it|works!)\b/i,
];
const FRUSTRATION = [/\b(?:ugh|argh|frustrat|annoying|hate this|giving up|so hard|too hard|this is stupid)\b/i, /!{2,}/];
const DISAGREE = [
  /\b(?:that'?s (?:not|wrong|incorrect)|you'?re wrong|i disagree|no,? (?:that'?s|it'?s|actually)|actually,? (?:it|that|no)|isn'?t that (?:wrong|backwards)|are you sure)\b/i,
  /\b(?:i think you (?:mean|meant)|that'?s not what|but (?:earlier|before) you said|contradict)\b/i,
];
const REQUESTS: [RegExp, RequestType][] = [
  [/\b(?:simpler|simplify|eli5|like i'?m (?:5|five)|plain (?:english|words)|dumb it down|less (?:technical|jargon)|too (?:complicated|complex|abstract|much))\b/i, "simpler"],
  [/\b(?:go deeper|more (?:detail|depth|details)|in depth|under the hood|deep dive|deeper|more (?:technical|rigorous|advanced)|the internals)\b/i, "deeper"],
  [/\b(?:(?:show|give)(?: me)? (?:an? |some )?(?:concrete |real |quick |small )?examples?|for example\?|example please|can i see (?:an? )?example|what does (?:that|this) look like)\b/i, "example"],
  [/\b(?:(?:give|let) me (?:an? )?(?:exercise|challenge|problem|practice|something to try)|let me try|quiz me|test me|practice)\b/i, "exercise"],
  [/\b(?:move on|next (?:topic|thing|one)|let'?s (?:skip|move on)|skip (?:this|that)|i know this already|can we (?:go|move) (?:on|forward)|what'?s next)\b/i, "move_on"],
  [/\b(?:slow down|too fast|one (?:step|thing) at a time|step by step|back up|wait,? (?:first|what))\b/i, "slow_down"],
  [/\b(?:why (?:does|do|is|did|would|should)|why not|what'?s the reason|how come|but why)\b/i, "explain_why"],
  [/\b(?:show me how|demonstrate|walk me through|can you run|walkthrough|do it live)\b/i, "demonstrate"],
];
const CLAIM_KNOW = /\bi (?:already |also )?(?:know|understand|am (?:familiar|comfortable) with|have used|use|am (?:good|great|fine) (?:at|with)|get)\s+(?!how\b|why\b|what\b|that\b|it\b|this\b)([a-z0-9][\w\s\-+#.]{1,40}?)(?:[.,!?;]|\s+(?:already|well|pretty|quite|a lot|fine|now)\b|$)/i;
const CLAIM_IGNORANT = /\bi(?:'ve| have)? (?:never|don'?t|do not|haven'?t|hardly)(?: really)? (?:used|use|learned|learnt|know|understood|understand|touched|seen|tried)\s+(?:about |what |how |much )?([a-z0-9][\w\s\-+#.]{1,40}?)(?:[.,!?;]| before| yet| at all|$)/i;
const GOAL = /\b(?:i(?:'d| would)? (?:want|like|need|wanna|plan|am trying|'m trying) to (?:learn|understand|study|get (?:better|good) at|master|pick up|start (?:with|learning))|teach me|help me (?:learn|understand|with)|let'?s learn|i'?m learning|i want to get into|can you teach me)\s+(?:about |some |the basics of |more about )?(?:the |a |an )?([a-z0-9][\w\s\-+#./()]{1,50}?)(?:[.,!?;:]|\s+(?:please|properly|from scratch|better|today|now|quickly|instead|too|as well|also|first|next|again|then|if|so|because|but)\b|$)/i;

const CODE_FENCE = /```(\w+)?\n?([\s\S]*?)```/g;
const CODE_HINTS: [RegExp, string][] = [
  [/#!\/bin\/(?:ba)?sh|\becho\s+\$|\bgrep\b|\bawk\b|\bsed\b|\bchmod\b|\|\s*\w+|\bfor \w+ in\b.*;\s*do\b|\bfi\b|\bdone\b/, "bash"],
  [/\bdef \w+\(|\bimport \w+|\bprint\(|\bself\.|\belif\b|:\s*$/m, "python"],
  [/\bconst \w+\s*=|\bfunction\b|=>|\bconsole\.log|\blet \w+|\bawait\b/, "javascript"],
  [/\bSELECT\b[\s\S]*\bFROM\b|\bINSERT INTO\b|\bCREATE TABLE\b|\bJOIN\b/i, "sql"],
  [/\bgit (?:commit|push|pull|rebase|merge|checkout|branch|status|log)\b/, "git"],
  [/#include\s*<|\bint main\(|std::/, "c++"],
];

const STOP = new Set(
  "the a an and or but of to in on at for with from by as is are was were be been being it this that these those i you we they he she my your our their me them what which who how why when where do does did can could would should will just really very so if then than too also not no yes about into over under up down out more most some any all there here have has had get got make made like want need know think say said tell".split(
    " "
  )
);

export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/[^a-z0-9+#.\-\s]/g, " ")
    .split(/\s+/)
    .map((t) => t.replace(/^[.\-]+|[.\-]+$/g, ""))
    .filter((t) => t.length > 1 && !STOP.has(t));
}

export function slugify(s: string): string {
  return s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9+#]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

function score(patterns: RegExp[], text: string): number {
  let hits = 0;
  for (const p of patterns) if (p.test(text)) hits++;
  return Math.min(1, hits * 0.5);
}

export function perceive(text: string): Signals {
  const t = text.trim();
  let hasCode = false;
  let codeLanguage: string | undefined;
  const fences = [...t.matchAll(CODE_FENCE)];
  if (fences.length) {
    hasCode = true;
    codeLanguage = fences[0][1]?.toLowerCase();
  }
  const codeBody = fences.length ? fences.map((f) => f[2]).join("\n") : t;
  if (!codeLanguage) {
    for (const [re, lang] of CODE_HINTS) {
      if (re.test(codeBody)) {
        codeLanguage = lang;
        // inline code (no fence) counts as code only if several lines or explicit shell/lang markers
        if (!hasCode && (codeBody.split("\n").length >= 2 || /^\s*[$>]\s/m.test(codeBody) || /#!\/bin/.test(codeBody))) hasCode = true;
        break;
      }
    }
  }

  const prose = t.replace(CODE_FENCE, " ");
  const isQuestion = /\?\s*$/.test(prose) || /^(?:what|why|how|when|where|which|who|can|could|does|do|is|are|should)\b/i.test(prose);
  let request: RequestType | undefined;
  for (const [re, kind] of REQUESTS) {
    if (re.test(prose)) {
      request = kind;
      break;
    }
  }
  const understanding = score(UNDERSTANDING, prose);
  let confusion = score(CONFUSION, prose);
  // "why does this work?" is curiosity, not confusion
  if (request === "explain_why" && !/don'?t|not/i.test(prose)) confusion = Math.max(0, confusion - 0.5);
  if (understanding > 0 && confusion > 0) confusion *= 0.5; // "got it, but why does X fail?" -> mostly understanding

  const claimK = prose.match(CLAIM_KNOW)?.[1]?.trim();
  const claimI = prose.match(CLAIM_IGNORANT)?.[1]?.trim();
  const goal = prose.match(GOAL)?.[1]?.trim();

  return {
    confusion,
    understanding,
    frustration: score(FRUSTRATION, prose),
    hasCode,
    codeLanguage,
    request,
    disagreement: DISAGREE.some((p) => p.test(prose)),
    claimsKnowledge: claimK && claimK.length > 1 ? claimK : undefined,
    claimsIgnorance: claimI && claimI.length > 1 ? claimI : undefined,
    goal: goal && goal.length > 1 ? goal : undefined,
    isQuestion,
    isWhy: /\bwhy\b/i.test(prose),
    tokens: tokenize(prose),
    length: t.length,
  };
}

/** Match known concept labels/slugs in text. Returns slugs in order of appearance strength. */
export function matchConcepts(text: string, concepts: { slug: string; label: string; aliases?: string[] }[]): string[] {
  const lower = text.toLowerCase();
  const hits: { slug: string; pos: number; len: number }[] = [];
  for (const c of concepts) {
    const names = [c.label, c.slug.replace(/-/g, " "), ...(c.aliases ?? [])].map((n) => n.toLowerCase()).filter((n) => n.length > 1);
    for (const n of names) {
      const re = new RegExp(`(^|[^a-z0-9])${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(s|es|ing|ed)?(?=$|[^a-z0-9])`, "i");
      const m = re.exec(lower);
      if (m) {
        hits.push({ slug: c.slug, pos: m.index, len: n.length });
        break;
      }
    }
  }
  hits.sort((a, b) => b.len - a.len || a.pos - b.pos);
  return [...new Set(hits.map((h) => h.slug))].slice(0, 6);
}
