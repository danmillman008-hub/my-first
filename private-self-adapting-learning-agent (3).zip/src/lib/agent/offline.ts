import type { LearnerContext } from "./context";
import type { Signals } from "./perceive";
import type { Subject } from "@/lib/subjects/research";
import { STRATEGY_LABELS } from "@/lib/memory/consolidate";

type Input = {
  signals: Signals;
  context: LearnerContext;
  subject: Subject | null;
  frontier: string[];
  next: string | null;
  firstTurn: boolean;
  researchedSubject?: string;
  text: string;
};

export type OfflineOut = { reply: string; strategy: string; action: string; concepts: string[] };

function label(subject: Subject | null, slug: string) {
  return subject?.concepts.find((c) => c.slug === slug)?.label ?? slug.replace(/-/g, " ");
}
function desc(subject: Subject | null, slug: string) {
  return subject?.concepts.find((c) => c.slug === slug)?.description ?? `a core part of ${subject?.name ?? "this subject"} (details will fill in as we work through it)`;
}

function explain(strategy: string, subject: Subject | null, slug: string): string {
  const L = label(subject, slug);
  const D = desc(subject, slug);
  switch (strategy) {
    case "example_first":
      return `Let's start concrete. Picture a typical situation where **${L}** shows up in ${subject?.name ?? "practice"} — a small, real case rather than the definition. Once that case is clear, the general idea is simply: ${D}. Does that concrete case match how you imagined it?`;
    case "concept_first":
      return `**${L}** — the idea first: ${D}. With that in place, an example will make more sense; say the word and I'll give one.`;
    case "socratic":
      return `Before I explain **${L}**: what do you *expect* to happen in the simplest case where it's used? Take a guess — a wrong guess tells us exactly where to start.`;
    case "exercise":
      return `Try a tiny exercise on **${L}**: build the smallest possible example that uses it, run it, and tell me what happened — including any error text. Failing attempts are just as useful.`;
    case "analogy":
      return `Think of **${L}** like an everyday process you already know — same shape, different material. In plain words: ${D}. If the analogy breaks down anywhere for you, tell me where.`;
    case "walkthrough":
      return `Let's go through **${L}** step by step: (1) what it's for, (2) the smallest example, (3) what changes when you vary one thing. Starting with (1): ${D}. Stop me the moment it stops making sense.`;
    default:
      return `**${L}**, short version: ${D}.`;
  }
}

export function offlineReply(i: Input): OfflineOut {
  const { signals, context, subject, frontier } = i;
  const focus = context.concepts[0] ?? frontier[0] ?? null;
  const strategy = context.recommended.strategy;
  const note = i.firstTurn ? "\n\n_(No model provider is configured, so I'm working from the researched subject map and your history rather than generating full prose explanations.)_" : "";
  const label_ = (s: string) => label(subject, s);

  if (!subject) {
    return { reply: `Happy to help. What would you like to dig into — a subject you want to learn, a question, or something you're working on (paste it in)?${note}`, strategy: "direct", action: "ask", concepts: [] };
  }

  if (signals.goal) {
    const solid = context.mastery.filter((m) => m.p >= 0.65 && m.weight >= 0.8).map((m) => m.label);
    const shaky = context.mastery.filter((m) => m.p < 0.45 && m.weight >= 0.8).map((m) => m.label);
    const back = solid.length || shaky.length;
    const map = subject.concepts.slice(0, 6).map((c) => c.label).join(", ");
    const reply = back
      ? `Welcome back to ${subject.name}. From what we did before: ${solid.length ? `${solid.slice(0, 4).join(", ")} looked solid` : "nothing is settled yet"}${shaky.length ? `; ${shaky.slice(0, 3).join(", ")} was still shaky` : ""}. A natural place to pick up would be **${frontier[0] ? label_(frontier[0]) : map}** — or tell me what you actually need right now.${note}`
      : `Let's do it. ${i.researchedSubject ? `I looked into ${subject.name}: ` : ""}${subject.summary ? subject.summary.split(/(?<=\.)\s/)[0] : ""} The territory covers roughly ${subject.concepts.length} ideas — the early ones are ${map}. Do you want to start at the beginning with **${frontier[0] ? label_(frontier[0]) : map}**, or is there something specific you're trying to do?${note}`;
    return { reply, strategy: "direct", action: "ask", concepts: frontier.slice(0, 1) };
  }

  if (signals.disagreement) {
    return {
      reply: `You may well be right — I'd rather check than defend it. Walk me through what you'd expect instead and why; if your version holds up, I'll go with it${focus ? ` and we'll note that for ${label_(focus)}` : ""}.`,
      strategy: "socratic",
      action: "ask",
      concepts: focus ? [focus] : [],
    };
  }

  if (signals.hasCode) {
    return {
      reply: `I can see your ${signals.codeLanguage ?? ""} code. Without a model provider I can't execute or fully review it, so let's reason together: what did you expect it to do, and what actually happened (exact error text helps)?${focus ? ` I'll relate it back to ${label_(focus)}.` : ""}`,
      strategy: "walkthrough",
      action: "review_code",
      concepts: focus ? [focus] : [],
    };
  }

  if (context.probe.suggested && context.probe.concept) {
    return {
      reply: `Sure, we can move ahead. One quick thing first so I don't skip something you'll need: in a sentence, how would you describe **${label_(context.probe.concept)}**? Then straight on to ${i.next ? label_(i.next) : "the next part"}.`,
      strategy: "socratic",
      action: "probe",
      concepts: [context.probe.concept],
    };
  }

  if (signals.request === "move_on" || (signals.understanding > 0 && signals.confusion < 0.5)) {
    const next = i.next ?? frontier.find((f) => f !== focus) ?? frontier[0];
    if (!next) return { reply: `Nice — that covers the map I have for ${subject.name}. Want to go deeper on anything, try a bigger exercise, or switch subjects?`, strategy: "direct", action: "ask", concepts: [] };
    const lead = signals.understanding > 0 ? "Good, that landed. " : "Sure. ";
    return { reply: `${lead}Next up: ${explain(strategy, subject, next)}`, strategy, action: "explain", concepts: [next] };
  }

  if (!focus) {
    return { reply: `Tell me what you're after in ${subject.name} — a specific thing you're stuck on, or shall I suggest where to start?`, strategy: "direct", action: "ask", concepts: [] };
  }

  const gapNote = context.weakPrereqs.length && context.weakPrereqs[0].concept !== focus ? ` (One thing I'm keeping an eye on: ${context.weakPrereqs[0].label} looked shaky earlier and ${label_(focus)} leans on it — shout if that's where it's snagging.)` : "";
  if (signals.confusion >= 0.5) {
    return {
      reply: `Okay — let's come at **${label_(focus)}** differently, ${STRATEGY_LABELS[strategy]} this time. ${explain(strategy, subject, focus)}${gapNote}`,
      strategy,
      action: "explain",
      concepts: [focus],
    };
  }
  return { reply: `${explain(strategy, subject, focus)}${gapNote}${note}`, strategy, action: signals.isQuestion ? "answer" : "explain", concepts: [focus] };
}
