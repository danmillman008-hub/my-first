import { desc, eq, and } from "drizzle-orm";
import { db } from "@/db";
import { messages, type SubjectConcept } from "@/db/schema";
import { effectiveWeight, getBeliefs, getWorkingMemory, retention, type Belief, type Obs } from "@/lib/memory/store";
import { STRATEGY_LABELS } from "@/lib/memory/consolidate";
import type { RequestType } from "./perceive";
import type { Subject } from "@/lib/subjects/research";

export const STRATEGIES = Object.keys(STRATEGY_LABELS);

export type MasteryView = { concept: string; label: string; p: number; weight: number; retention: number; status: string };
export type StrategyEstimate = { strategy: string; mean: number; weight: number; source: "subject" | "general" | "prior"; contextSpecific: boolean };

export type LearnerContext = {
  learnerId: string;
  subject: Subject | null;
  concepts: string[];
  mastery: MasteryView[];
  weakPrereqs: { concept: string; label: string; neededFor: string[] }[];
  strategies: StrategyEstimate[];
  recommended: { strategy: string; reason: string; exploring: boolean; overriddenByRequest: boolean };
  preferences: Belief[];
  tendencies: Belief[];
  goals: Belief[];
  misconceptions: Belief[];
  working: Obs[];
  probe: { suggested: boolean; concept?: string; reason?: string };
  turnsSinceProbe: number;
  totalEvidence: number;
};

export type Rng = () => number;

function betaSample(a: number, b: number, rng: Rng) {
  // Simple gamma-based Beta sampler (Marsaglia-Tsang) adequate for a,b >= 1
  const g = (k: number) => {
    const d = k - 1 / 3;
    const c = 1 / Math.sqrt(9 * d);
    for (;;) {
      let x: number, v: number;
      do {
        const u1 = rng() || 1e-9;
        const u2 = rng();
        x = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
        v = 1 + c * x;
      } while (v <= 0);
      v = v * v * v;
      const u = rng();
      if (u < 1 - 0.0331 * x ** 4 || Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
    }
  };
  const x = g(a);
  const y = g(b);
  return x / (x + y);
}

export function estimateStrategies(strategyBeliefs: Belief[], subjectSlug: string | null, now: Date): StrategyEstimate[] {
  return STRATEGIES.map((s) => {
    const subj = subjectSlug ? strategyBeliefs.find((b) => b.key === `strategy:${subjectSlug}:${s}`) : undefined;
    const gen = strategyBeliefs.find((b) => b.key === `strategy:general:${s}`);
    const sw = subj ? effectiveWeight(subj, now) : 0;
    const gw = gen ? effectiveWeight(gen, now) : 0;
    const contextSpecific = !!(subj && gen && sw >= 1.5 && gw >= 1.5 && Math.abs(subj.confidence - gen.confidence) > 0.25);
    if (subj && sw >= 1.5) return { strategy: s, mean: subj.confidence, weight: sw, source: "subject", contextSpecific };
    if (gen && gw >= 1) {
      // blend subject partial evidence with general
      const mean = subj ? (subj.confidence * sw + gen.confidence * gw) / (sw + gw) : gen.confidence;
      return { strategy: s, mean, weight: sw + gw, source: "general", contextSpecific };
    }
    return { strategy: s, mean: subj ? subj.confidence : 0.5, weight: sw, source: "prior", contextSpecific: false };
  });
}

const REQUEST_STRATEGY: Partial<Record<RequestType, string>> = {
  example: "example_first",
  exercise: "exercise",
  simpler: "analogy",
  deeper: "concept_first",
  explain_why: "concept_first",
  demonstrate: "walkthrough",
  slow_down: "walkthrough",
};

export type Policy = "ucb" | "thompson";
export const DEFAULT_POLICY: Policy = (process.env.STRATEGY_POLICY as Policy) || "ucb";

export function chooseStrategy(estimates: StrategyEstimate[], request: RequestType | undefined, rng: Rng, opts: { adaptive?: boolean; policy?: Policy } = {}) {
  const req = request ? REQUEST_STRATEGY[request] : undefined;
  if (req) return { strategy: req, reason: `learner asked for it (${request})`, exploring: false, overriddenByRequest: true };
  if (opts.adaptive === false) {
    return { strategy: "concept_first", reason: "adaptation disabled (baseline)", exploring: false, overriddenByRequest: false };
  }
  const policy = opts.policy ?? DEFAULT_POLICY;
  let chosen: StrategyEstimate;
  if (policy === "thompson") {
    // Thompson sampling over Beta posteriors; weight informs pseudo-counts.
    let best: { s: StrategyEstimate; sample: number } | null = null;
    for (const e of estimates) {
      const sample = betaSample(1 + e.mean * e.weight, 1 + (1 - e.mean) * e.weight, rng);
      if (!best || sample > best.sample) best = { s: e, sample };
    }
    chosen = best!.s;
  } else {
    // UCB-style: exploit the posterior mean, with an uncertainty bonus for under-tried approaches
    // and a small epsilon so a changed learner is noticed. Evidence recency already discounts the past.
    const total = estimates.reduce((s, e) => s + e.weight, 0);
    const eps = Math.max(0.06, 0.4 / (1 + total / 6));
    if (rng() < eps) chosen = estimates[Math.floor(rng() * estimates.length)];
    else {
      const scored = estimates.map((e) => ({ e, score: e.mean + 0.35 * Math.sqrt(Math.log(total + 2) / (e.weight + 1)) + rng() * 0.02 }));
      scored.sort((a, b) => b.score - a.score);
      chosen = scored[0].e;
    }
  }
  const greedy = [...estimates].sort((a, b) => b.mean * Math.min(1, b.weight / 2) - a.mean * Math.min(1, a.weight / 2))[0];
  const exploring = chosen.strategy !== greedy.strategy || chosen.weight < 1.5;
  const reason =
    chosen.weight < 1
      ? "little evidence yet; trying an approach"
      : `${chosen.source === "subject" ? "in this subject" : "generally"} this has worked ${(chosen.mean * 100).toFixed(0)}% of the time (${chosen.weight.toFixed(1)} evidence)`;
  return { strategy: chosen.strategy, reason, exploring, overriddenByRequest: false };
}

export type ContextOptions = {
  sessionId?: string | null;
  now?: Date;
  request?: RequestType;
  rng?: Rng;
  // ablation switches (used by the lab)
  useLongTerm?: boolean;
  useWorkingMemory?: boolean;
  adaptive?: boolean;
  allowProbes?: boolean;
};

export async function buildLearnerContext(learnerId: string, subject: Subject | null, concepts: string[], opts: ContextOptions = {}): Promise<LearnerContext> {
  const now = opts.now ?? new Date();
  const rng = opts.rng ?? Math.random;
  const useLT = opts.useLongTerm !== false;
  const all = useLT ? await getBeliefs(learnerId) : [];
  // Stale-memory guard: status is updated lazily at consolidation, so also require present-day evidence weight.
  const active = all.filter((b) => b.status === "active" && effectiveWeight(b, now) >= 0.5);
  const subjSlug = subject?.slug ?? null;

  const masteryBeliefs = all.filter((b) => b.kind === "mastery" && (subjSlug ? b.subject === subjSlug : true));
  const subjectConcepts: SubjectConcept[] = subject?.concepts ?? [];
  const labelOf = (slug: string) => subjectConcepts.find((c) => c.slug === slug)?.label ?? slug.replace(/-/g, " ");
  const mastery: MasteryView[] = masteryBeliefs
    .map((b) => ({ concept: b.concept ?? "", label: labelOf(b.concept ?? ""), p: b.confidence * (0.5 + 0.5 * retention(b, now)), weight: effectiveWeight(b, now), retention: retention(b, now), status: b.status }))
    .filter((m) => m.concept);
  const mp = new Map(mastery.map((m) => [m.concept, m]));

  const weakPrereqs: LearnerContext["weakPrereqs"] = [];
  for (const c of subjectConcepts) {
    for (const p of c.prerequisites ?? []) {
      const m = mp.get(p);
      if (m && m.weight >= 1 && m.p < 0.45 && (concepts.includes(c.slug) || concepts.length === 0)) {
        const w = weakPrereqs.find((x) => x.concept === p);
        if (w) w.neededFor.push(c.label);
        else weakPrereqs.push({ concept: p, label: labelOf(p), neededFor: [c.label] });
      }
    }
  }

  const strategies = estimateStrategies(active.filter((b) => b.kind === "strategy_effect"), subjSlug, now);
  const recommended = chooseStrategy(strategies, opts.request, rng, { adaptive: opts.adaptive });

  const inCtx = (b: Belief) => b.subject === null || b.subject === subjSlug;
  const preferences = active.filter((b) => b.kind === "preference" && inCtx(b));
  const tendencies = active.filter((b) => b.kind === "tendency" && inCtx(b));
  const goals = active.filter((b) => b.kind === "goal");
  const misconceptions = active.filter((b) => b.kind === "misconception" && inCtx(b));

  const working = opts.useWorkingMemory === false ? [] : await getWorkingMemory(learnerId, { now, sessionId: opts.sessionId, concepts, subject: subjSlug, limit: 16 });

  // Probe cooldown: count assistant turns since last probe in this session
  let turnsSinceProbe = 99;
  if (opts.sessionId) {
    const recent = await db
      .select({ meta: messages.meta })
      .from(messages)
      .where(and(eq(messages.sessionId, opts.sessionId), eq(messages.role, "assistant")))
      .orderBy(desc(messages.createdAt))
      .limit(8);
    const idx = recent.findIndex((m) => m.meta.action === "probe");
    turnsSinceProbe = idx === -1 ? 99 : idx;
  }

  // Active information gathering only when uncertainty matters for the next decision
  let probe: LearnerContext["probe"] = { suggested: false };
  if (opts.allowProbes !== false && turnsSinceProbe >= 4) {
    const target = concepts.find((c) => {
      const m = mp.get(c);
      const isPrereqOfSomething = subjectConcepts.some((sc) => (sc.prerequisites ?? []).includes(c));
      return isPrereqOfSomething && (!m || m.weight < 1) && (opts.request === "move_on" || opts.request === "deeper");
    });
    if (target) probe = { suggested: true, concept: target, reason: `learner wants to move ahead but there is little evidence about "${labelOf(target)}", a prerequisite for later material` };
  }

  return {
    learnerId,
    subject,
    concepts,
    mastery,
    weakPrereqs,
    strategies,
    recommended,
    preferences,
    tendencies,
    goals,
    misconceptions,
    working,
    probe,
    turnsSinceProbe,
    totalEvidence: all.reduce((s, b) => s + b.support + b.contradictions, 0),
  };
}

function conf(b: Belief, now: Date) {
  const w = effectiveWeight(b, now);
  const strength = w < 1.5 ? "weak" : w < 4 ? "moderate" : "strong";
  return `${(b.confidence * 100).toFixed(0)}% · ${strength} evidence (${b.support}+/${b.contradictions}−, ${b.sessionsSeen} session${b.sessionsSeen === 1 ? "" : "s"})`;
}

/** Render the learner model for the model prompt with explicit epistemic status. */
export function renderContext(ctx: LearnerContext, now = new Date()): string {
  const lines: string[] = [];
  lines.push("LEARNER MODEL (a prior, not a verdict — what the learner says and does *now* takes priority):");
  if (ctx.goals.length) lines.push(`Goals: ${ctx.goals.map((g) => g.statement).join("; ")}`);
  if (ctx.subject) lines.push(`Current subject: ${ctx.subject.name}${ctx.concepts.length ? ` · concepts in play: ${ctx.concepts.join(", ")}` : ""}`);
  const known = ctx.mastery.filter((m) => m.weight >= 0.8);
  if (known.length) {
    const fmt = (m: MasteryView) => `${m.label} ${(m.p * 100).toFixed(0)}%${m.retention < 0.5 ? " (not practised recently)" : ""}`;
    const strong = known.filter((m) => m.p >= 0.65).map(fmt);
    const shaky = known.filter((m) => m.p < 0.45).map(fmt);
    const mid = known.filter((m) => m.p >= 0.45 && m.p < 0.65).map(fmt);
    if (strong.length) lines.push(`Appears solid: ${strong.join(", ")}`);
    if (mid.length) lines.push(`Partial: ${mid.join(", ")}`);
    if (shaky.length) lines.push(`Shaky: ${shaky.join(", ")}`);
  } else lines.push("Mastery: no behavioural evidence yet in this subject.");
  if (ctx.weakPrereqs.length) lines.push(`Possible missing prerequisites: ${ctx.weakPrereqs.map((w) => `${w.label} (needed for ${w.neededFor.join(", ")})`).join("; ")}`);
  if (ctx.misconceptions.length) lines.push(`Possible misconceptions: ${ctx.misconceptions.map((b) => `${b.statement} [${conf(b, now)}]`).join("; ")}`);
  if (ctx.preferences.length) lines.push(`Observed preferences: ${ctx.preferences.map((b) => `${b.statement} [${conf(b, now)}]`).join("; ")}`);
  if (ctx.tendencies.length) lines.push(`Observed tendencies: ${ctx.tendencies.map((b) => `${b.statement} [${conf(b, now)}]`).join("; ")}`);
  const informative = ctx.strategies.filter((s) => s.weight >= 1);
  if (informative.length)
    lines.push(
      `Teaching approaches tried: ${informative
        .sort((a, b) => b.mean - a.mean)
        .map((s) => `${STRATEGY_LABELS[s.strategy]} → ${(s.mean * 100).toFixed(0)}% landed (${s.source}${s.contextSpecific ? ", context-specific" : ""})`)
        .join("; ")}`
    );
  lines.push(
    `Suggested approach for this turn: ${STRATEGY_LABELS[ctx.recommended.strategy]} — ${ctx.recommended.reason}${ctx.recommended.exploring ? " (exploratory; low confidence)" : ""}. Use judgment: if the message clearly calls for something else, do that.`
  );
  if (ctx.probe.suggested) lines.push(`Worth a light check (not a quiz): ${ctx.probe.reason}. One natural question or tiny task, only if it fits the flow.`);
  else if (ctx.turnsSinceProbe < 4) lines.push("Do not probe or quiz this turn; recent check already happened.");
  if (ctx.working.length) {
    lines.push("Recent evidence (working memory):");
    for (const o of ctx.working.slice(-10)) {
      const age = Math.round((now.getTime() - o.createdAt.getTime()) / 36e5);
      lines.push(`- [${o.kind}${o.subject ? `/${o.subject}` : ""} ${age < 1 ? "just now" : age < 48 ? `${age}h ago` : `${Math.round(age / 24)}d ago`}] ${o.content.slice(0, 160)}`);
    }
  }
  return lines.join("\n");
}
