// Provider abstraction. The learner model never depends on a vendor: the model is
// the flexible intelligence; the persistent memory belongs to the product.

export type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

export interface LLMProvider {
  name: string;
  complete(messages: ChatMessage[], opts?: { temperature?: number; maxTokens?: number; json?: boolean }): Promise<string>;
}

class OpenAICompatibleProvider implements LLMProvider {
  name: string;
  constructor(
    private apiKey: string,
    private baseUrl: string,
    private model: string
  ) {
    this.name = `openai-compatible:${model}`;
  }

  async complete(messages: ChatMessage[], opts: { temperature?: number; maxTokens?: number; json?: boolean } = {}) {
    const body: Record<string, unknown> = {
      model: this.model,
      messages,
      temperature: opts.temperature ?? 0.6,
      max_tokens: opts.maxTokens ?? 1200,
    };
    if (opts.json) body.response_format = { type: "json_object" };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 60_000);
    try {
      const res = await fetch(`${this.baseUrl.replace(/\/$/, "")}/chat/completions`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${this.apiKey}` },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(`LLM provider error ${res.status}: ${text.slice(0, 300)}`);
      }
      const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      return json.choices?.[0]?.message?.content ?? "";
    } finally {
      clearTimeout(timer);
    }
  }
}

let cached: LLMProvider | null | undefined;

/** Returns a provider when one is configured, otherwise null (offline mode). */
export function getProvider(): LLMProvider | null {
  if (cached !== undefined) return cached;
  if (process.env.LLM_DISABLED === "1") return (cached = null);
  const key = process.env.OPENAI_API_KEY || process.env.LLM_API_KEY;
  if (!key) return (cached = null);
  const baseUrl = process.env.OPENAI_BASE_URL || process.env.LLM_BASE_URL || "https://api.openai.com/v1";
  const model = process.env.LLM_MODEL || process.env.OPENAI_MODEL || "gpt-4o-mini";
  cached = new OpenAICompatibleProvider(key, baseUrl, model);
  return cached;
}

export function providerStatus() {
  const p = getProvider();
  return { available: !!p, name: p?.name ?? "offline (no OPENAI_API_KEY configured)" };
}

/** Extract the first JSON object from a model response (tolerates code fences and prose). */
export function extractJson<T = unknown>(text: string): T | null {
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidates = [fence?.[1], text];
  for (const c of candidates) {
    if (!c) continue;
    const start = c.indexOf("{");
    const end = c.lastIndexOf("}");
    if (start === -1 || end <= start) continue;
    try {
      return JSON.parse(c.slice(start, end + 1)) as T;
    } catch {
      /* try next */
    }
  }
  return null;
}
