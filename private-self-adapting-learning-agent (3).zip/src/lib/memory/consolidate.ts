import { and, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { consolidations, observations } from "@/db/schema";
import {
  applyBeliefEvidence,
  decayGraph,
  effectiveWeight,
  getBeliefs,
  getUnconsolidated,
  markConsolidated,
  newId,
  setBeliefStatus,
  type Belief,
  type Obs,
} from "./store";

export const STRATEGY_LABELS: Record<string, string> = {
  example_first: "concrete example first, then the idea",
  concept_first: "the idea/definition first, then an example",
  socratic: "guided questions",
  exercise: "a small hands-on exercise",
  analogy: "an analogy",
  walkthrough: "a step-by-step walkthrough",
  direct: "a direct, compact answer",
};

export const REQUEST_PREFERENCE: Record<string, string> = {
  simpler: "tends to ask for simpler, less technical explanations",
  deeper: "tends to ask for more depth / internals",
  example: "tends to ask for concrete examples",
  exercise: "tends to ask for hands-on practice",
  move_on: "tends to want to move on quickly",
  slow_down: "tends to want a slower, step-by-step pace",
  explain_why: "tends to ask *why* things work (mechanism-oriented)",
  demonstrate: "tends to ask for demonstrations",
};

function ctx(subject: string | null | undefined) {
  return subject ?? "general";
}

/** Decide if consolidation should run now (salience budget, like reflection triggers). */
export async function shouldConsolidate(learnerId: string, now = new Date()) {
  const pending = await getUnconsolidated(learnerId);
  if (!pending.length) return false;
  const salience = pending.reduce((s, o) => s + o.salience, 0);
  const oldest = pending[0].createdAt.getTime();
  return salience >= 4 || pending.length >= 14 || now.getTime() - oldest > 6 * 36e5;
}

export async function consolidate(learnerId: string, now = new Date()) {
  const pending = await getUnconsolidated(learnerId);
  const notes: string[] = [];
  let created = 0;
  let updated = 0;

  const before = new Set((await getBeliefs(learnerId)).map((b) => b.id));
  const track = (b: Belief) => {
    if (before.has(b.id)) updated++;
    else {
      created++;
      before.add(b.id);
    }
  };

  // 1. Requests -> preference candidates (context tagged; global only if seen across contexts)
  const requests = pending.filter((o) => o.kind === "request" && typeof o.data.request === "string");
  for (const o of requests) {
    const r = o.data.request as string;
    const label = REQUEST_PREFERENCE[r];
    if (!label) continue;
    const b = await applyBeliefEvidence({
      learnerId,
      kind: "preference",
      key: `pref:${ctx(o.subject)}:${r}`,
      statement: `${label}${o.subject ? ` (in ${o.subject})` : ""}`,
      subject: o.subject,
      positive: true,
      weight: 0.6,
      evidenceId: o.id,
      sessionId: o.sessionId,
      now,
      recencyFactor: 0.95,
    });
    track(b);
    // Opposite requests contradict each other (simpler vs deeper, move_on vs slow_down)
    const opposite: Record<string, string> = { simpler: "deeper", deeper: "simpler", move_on: "slow_down", slow_down: "move_on" };
    if (opposite[r]) {
      const oppKey = `pref:${ctx(o.subject)}:${opposite[r]}`;
      const existing = (await getBeliefs(learnerId, { kinds: ["preference"] })).find((b) => b.key === oppKey);
      if (existing) {
        track(
          await applyBeliefEvidence({
            learnerId,
            kind: "preference",
            key: oppKey,
            statement: existing.statement,
            subject: existing.subject,
            positive: false,
            weight: 0.6,
            evidenceId: o.id,
            sessionId: o.sessionId,
            now,
            recencyFactor: 0.95,
            note: `contradicted by request for ${r}`,
          })
        );
      }
    }
  }

  // 1b. Base rates: a session with plenty of interaction but no such request is weak evidence against a request-based
  //     preference (frequency of a request matters relative to opportunity, not raw count).
  const turnsBySession = new Map<string, number>();
  for (const o of pending) if (o.sessionId) turnsBySession.set(o.sessionId, (turnsBySession.get(o.sessionId) ?? 0) + 1);
  const requestPrefs = (await getBeliefs(learnerId, { kinds: ["preference"] })).filter((b) => b.key.startsWith("pref:"));
  for (const b of requestPrefs) {
    const r = b.key.split(":")[2];
    for (const [sid, n] of turnsBySession) {
      if (n < 6) continue;
      const sawRequest = requests.some((o) => o.sessionId === sid && o.data.request === r && (ctx(o.subject) === b.key.split(":")[1]));
      if (sawRequest) continue;
      track(
        await applyBeliefEvidence({ learnerId, kind: "preference", key: b.key, statement: b.statement, subject: b.subject, positive: false, weight: 0.25, sessionId: sid, now, recencyFactor: 0.95, note: "session without this request" })
      );
    }
  }

  // 2. Mistakes -> tendency candidates by mistake type; clean successes weakly contradict
  const mistakes = pending.filter((o) => o.kind === "mistake" && typeof o.data.mistakeType === "string");
  for (const o of mistakes) {
    const mt = o.data.mistakeType as string;
    track(
      await applyBeliefEvidence({
        learnerId,
        kind: "tendency",
        key: `tendency:${ctx(o.subject)}:${mt}-mistakes`,
        statement: `recurring ${mt} mistakes${o.subject ? ` in ${o.subject}` : ""}${mt === "syntax" ? " (often despite conceptual understanding)" : ""}`,
        subject: o.subject,
        positive: true,
        weight: 0.7,
        evidenceId: o.id,
        sessionId: o.sessionId,
        now,
      })
    );
  }
  const cleanSuccess = pending.filter((o) => o.kind === "success" && o.data.hasCode === true);
  for (const o of cleanSuccess) {
    const existing = (await getBeliefs(learnerId, { kinds: ["tendency"] })).filter((b) => b.key === `tendency:${ctx(o.subject)}:syntax-mistakes`);
    for (const b of existing) {
      track(
        await applyBeliefEvidence({
          learnerId,
          kind: "tendency",
          key: b.key,
          statement: b.statement,
          subject: b.subject,
          positive: false,
          weight: 0.3,
          evidenceId: o.id,
          sessionId: o.sessionId,
          now,
          note: "clean code submission",
        })
      );
    }
  }

  // 3. Agent insights (reflections) must earn belief status through repetition
  const insights = pending.filter((o) => o.kind === "insight" && typeof o.data.key === "string");
  for (const o of insights) {
    track(
      await applyBeliefEvidence({
        learnerId,
        kind: (o.data.beliefKind as Belief["kind"]) ?? "tendency",
        key: `insight:${ctx(o.subject)}:${o.data.key as string}`,
        statement: o.content,
        subject: o.subject,
        positive: o.polarity >= 0,
        weight: 0.5,
        evidenceId: o.id,
        sessionId: o.sessionId,
        now,
        recencyFactor: 0.9,
      })
    );
  }

  // 4. Self-assessment calibration: claims vs observed behaviour on the same concept.
  //    Claims are re-examined at later consolidations (up to 45 days) because behavioural evidence usually arrives *after* the claim.
  const recentClaims = (
    await db
      .select()
      .from(observations)
      .where(and(eq(observations.learnerId, learnerId), eq(observations.kind, "claim"), gte(observations.createdAt, new Date(now.getTime() - 45 * 864e5))))
  ).filter((o) => o.concepts.length && o.data.calibrationChecked !== true);
  const claims = recentClaims;
  const markChecked = async (o: Obs) => db.update(observations).set({ data: { ...o.data, calibrationChecked: true } }).where(eq(observations.id, o.id));
  if (claims.length) {
    const mastery = await getBeliefs(learnerId, { kinds: ["mastery"] });
    for (const c of claims) {
      const claimsKnows = c.polarity > 0;
      for (const concept of c.concepts) {
        const m = mastery.find((b) => b.concept === concept && (c.subject ? b.subject === c.subject : true));
        const claimWeight = (m?.evidenceIds ?? []).includes(c.id) ? 0.35 : 0;
        if (!m || effectiveWeight(m, now) - claimWeight < 1.2) continue; // not enough *behavioural* evidence yet; re-check next time
        await markChecked(c);
        const overestimates = claimsKnows && m.confidence < 0.4;
        const underestimates = !claimsKnows && m.confidence > 0.65;
        const calibrated = (claimsKnows && m.confidence >= 0.6) || (!claimsKnows && m.confidence <= 0.4);
        if (overestimates || underestimates || calibrated) {
          const key = overestimates ? "overestimates" : underestimates ? "underestimates" : null;
          if (key) {
            track(
              await applyBeliefEvidence({
                learnerId,
                kind: "tendency",
                key: `tendency:${ctx(c.subject)}:self-assessment-${key}`,
                statement: `self-assessment tends to ${key === "overestimates" ? "over" : "under"}state actual performance${c.subject ? ` in ${c.subject}` : ""}`,
                subject: c.subject,
                positive: true,
                weight: 0.7,
                evidenceId: c.id,
                sessionId: c.sessionId,
                now,
                note: `claim about ${concept} vs mastery ${m.confidence.toFixed(2)}`,
              })
            );
          } else {
            for (const k of ["overestimates", "underestimates"]) {
              const b = (await getBeliefs(learnerId, { kinds: ["tendency"] })).find((x) => x.key === `tendency:${ctx(c.subject)}:self-assessment-${k}`);
              if (b)
                track(
                  await applyBeliefEvidence({
                    learnerId,
                    kind: "tendency",
                    key: b.key,
                    statement: b.statement,
                    subject: b.subject,
                    positive: false,
                    weight: 0.4,
                    evidenceId: c.id,
                    sessionId: c.sessionId,
                    now,
                    note: `calibrated claim about ${concept}`,
                  })
                );
            }
          }
        }
      }
    }
  }

  // 5. Topic switching pattern (descriptive, cause deliberately left open)
  const switchesBySession = new Map<string, number>();
  for (const o of pending) if (o.kind === "topic_switch" && o.sessionId) switchesBySession.set(o.sessionId, (switchesBySession.get(o.sessionId) ?? 0) + 1);
  for (const [sid, n] of switchesBySession) {
    if (n >= 3) {
      track(
        await applyBeliefEvidence({
          learnerId,
          kind: "tendency",
          key: "tendency:general:broad-exploration",
          statement: "often moves between several topics within one session (cause unknown: curiosity, restlessness, or real-world needs)",
          positive: true,
          weight: 0.5,
          sessionId: sid,
          now,
        })
      );
    }
  }

  await markConsolidated(
    pending.map((o) => o.id),
    now
  );

  // 6. Status pass: beliefs earn/lose active status from *effective* (time-decayed) evidence.
  let dormant = 0;
  const all = await getBeliefs(learnerId);
  for (const b of all) {
    const w = effectiveWeight(b, now);
    let want: Belief["status"] = b.status;
    if (b.kind === "preference" || b.kind === "tendency") {
      const enough = w >= 1.7 && b.sessionsSeen >= 2 && b.confidence >= 0.62;
      want = enough ? "active" : "dormant";
    } else if (b.kind === "strategy_effect") {
      want = w >= 0.8 ? "active" : "dormant";
    } else if (b.kind === "mastery") {
      want = w >= 0.4 ? "active" : "dormant";
    } else if (b.kind === "goal") {
      want = w >= 0.3 ? "active" : "dormant";
    } else if (b.kind === "misconception") {
      want = w >= 0.8 && b.confidence >= 0.55 ? "active" : "dormant";
    }
    if (want !== b.status) {
      if (want === "dormant") dormant++;
      await setBeliefStatus(b.id, want, want === "dormant" ? "insufficient or faded evidence" : "evidence threshold reached", now);
      notes.push(`${b.key}: ${b.status} -> ${want}`);
    }
  }

  const graphDeactivated = await decayGraph(learnerId, now);
  if (graphDeactivated) notes.push(`graph: ${graphDeactivated} nodes/edges went inactive`);

  await db.insert(consolidations).values({
    id: newId("c"),
    learnerId,
    observationsProcessed: pending.length,
    beliefsCreated: created,
    beliefsUpdated: updated,
    beliefsDormant: dormant,
    notes: notes.slice(0, 50),
    createdAt: now,
  });
  return { processed: pending.length, created, updated, dormant, notes };
}

export type ConsolidationRow = typeof consolidations.$inferSelect;
