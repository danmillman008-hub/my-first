import { and, desc, eq, inArray, isNull, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  beliefs,
  edges,
  nodes,
  observations,
  type BeliefKind,
  type BeliefStatus,
  type EdgeRelation,
  type NodeKind,
  type ObservationKind,
} from "@/db/schema";
import { randomUUID } from "crypto";

export const SHARED = "__shared__";

export function newId(prefix: string) {
  return `${prefix}_${randomUUID().replace(/-/g, "").slice(0, 20)}`;
}

// ---------------- Observations (short-term / working memory) ----------------

export type NewObservation = {
  learnerId: string;
  sessionId?: string | null;
  messageId?: string | null;
  kind: ObservationKind;
  content: string;
  subject?: string | null;
  concepts?: string[];
  data?: Record<string, unknown>;
  polarity?: number;
  salience?: number;
  source?: string;
  createdAt?: Date;
};

export async function recordObservation(o: NewObservation) {
  const id = newId("obs");
  await db.insert(observations).values({
    id,
    learnerId: o.learnerId,
    sessionId: o.sessionId ?? null,
    messageId: o.messageId ?? null,
    kind: o.kind,
    content: o.content.slice(0, 2000),
    subject: o.subject ?? null,
    concepts: o.concepts ?? [],
    data: o.data ?? {},
    polarity: o.polarity ?? 0,
    salience: Math.max(0, Math.min(1, o.salience ?? 0.3)),
    source: o.source ?? "heuristic",
    createdAt: o.createdAt ?? new Date(),
  });
  return id;
}

export type Obs = typeof observations.$inferSelect;

/**
 * Working memory retrieval (Generative-Agents style): recency + salience + relevance.
 * Relevance is concept/subject overlap (no embeddings needed; deterministic and cheap).
 */
export async function getWorkingMemory(
  learnerId: string,
  opts: { now?: Date; sessionId?: string | null; concepts?: string[]; subject?: string | null; limit?: number; poolSize?: number } = {}
): Promise<Obs[]> {
  const now = opts.now ?? new Date();
  const pool = await db
    .select()
    .from(observations)
    .where(eq(observations.learnerId, learnerId))
    .orderBy(desc(observations.createdAt))
    .limit(opts.poolSize ?? 120);
  const want = new Set((opts.concepts ?? []).map((c) => c.toLowerCase()));
  const scored = pool.map((o) => {
    const ageH = Math.max(0, (now.getTime() - o.createdAt.getTime()) / 36e5);
    const recency = Math.exp(-ageH / 48); // ~2 day time constant
    const sameSession = opts.sessionId && o.sessionId === opts.sessionId ? 0.25 : 0;
    const overlap = o.concepts.filter((c) => want.has(c.toLowerCase())).length;
    const subj = opts.subject && o.subject === opts.subject ? 0.2 : 0;
    const relevance = Math.min(1, overlap * 0.4) + subj;
    const unconsolidated = o.consolidatedAt ? 0 : 0.15;
    return { o, score: recency + o.salience + relevance + sameSession + unconsolidated };
  });
  scored.sort((a, b) => b.score - a.score);
  return scored
    .slice(0, opts.limit ?? 18)
    .map((s) => s.o)
    .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
}

export async function getUnconsolidated(learnerId: string) {
  return db
    .select()
    .from(observations)
    .where(and(eq(observations.learnerId, learnerId), isNull(observations.consolidatedAt)))
    .orderBy(observations.createdAt);
}

export async function markConsolidated(ids: string[], at: Date) {
  if (!ids.length) return;
  await db.update(observations).set({ consolidatedAt: at }).where(inArray(observations.id, ids));
}

// ---------------- Graph ----------------

export async function touchNode(
  scope: string,
  kind: NodeKind,
  slug: string,
  label: string,
  extra: { subject?: string | null; description?: string | null; now?: Date; boost?: number } = {}
) {
  const now = extra.now ?? new Date();
  const boost = extra.boost ?? 0.2;
  const id = `n_${scope === SHARED ? "s" : scope.slice(-8)}_${kind}_${slug}`.slice(0, 120);
  await db
    .insert(nodes)
    .values({
      id,
      learnerId: scope,
      kind,
      slug,
      label,
      subject: extra.subject ?? null,
      description: extra.description ?? null,
      activation: 0.5,
      touchCount: 1,
      active: true,
      createdAt: now,
      lastTouchedAt: now,
    })
    .onConflictDoUpdate({
      target: [nodes.learnerId, nodes.kind, nodes.slug],
      set: {
        activation: sql`least(1.0, ${nodes.activation} * exp(-greatest(0, extract(epoch from (${now.toISOString()}::timestamptz - ${nodes.lastTouchedAt})) / 86400.0) / 30.0) + ${boost})`,
        touchCount: sql`${nodes.touchCount} + 1`,
        active: true,
        lastTouchedAt: now,
        description: sql`coalesce(${extra.description ?? null}, ${nodes.description})`,
        subject: sql`coalesce(${extra.subject ?? null}, ${nodes.subject})`,
      },
    });
  return id;
}

export async function reinforceEdge(
  scope: string,
  fromId: string,
  toId: string,
  relation: EdgeRelation,
  opts: { delta?: number; note?: string; now?: Date } = {}
) {
  if (fromId === toId) return;
  const now = opts.now ?? new Date();
  const delta = opts.delta ?? 0.15;
  const existing = await db
    .select()
    .from(edges)
    .where(and(eq(edges.learnerId, scope), eq(edges.fromId, fromId), eq(edges.toId, toId), eq(edges.relation, relation)))
    .limit(1);
  if (!existing.length) {
    const w = Math.max(0.05, Math.min(1, 0.3 + delta));
    await db.insert(edges).values({
      id: newId("e"),
      learnerId: scope,
      fromId,
      toId,
      relation,
      weight: w,
      evidenceCount: 1,
      active: true,
      history: [{ at: now.toISOString(), weight: w, delta, note: opts.note }],
      createdAt: now,
      lastReinforcedAt: now,
    });
    return;
  }
  const e = existing[0];
  const ageDays = Math.max(0, (now.getTime() - e.lastReinforcedAt.getTime()) / 864e5);
  const decayed = e.weight * Math.exp(-ageDays / 45);
  const w = Math.max(0, Math.min(1, decayed + delta * (delta > 0 ? 1 - decayed : 1)));
  const history = [...e.history, { at: now.toISOString(), weight: w, delta, note: opts.note }].slice(-40);
  await db
    .update(edges)
    .set({ weight: w, evidenceCount: e.evidenceCount + 1, lastReinforcedAt: now, active: w >= 0.08, history })
    .where(eq(edges.id, e.id));
}

/** Time-based decay for a learner's graph; inactive (not deleted) below thresholds. */
export async function decayGraph(learnerId: string, now = new Date()) {
  const ns = await db.select().from(nodes).where(eq(nodes.learnerId, learnerId));
  let deactivated = 0;
  for (const n of ns) {
    const ageDays = Math.max(0, (now.getTime() - n.lastTouchedAt.getTime()) / 864e5);
    const activation = n.activation * Math.exp(-ageDays / 30);
    const active = activation >= 0.05;
    if (Math.abs(activation - n.activation) > 1e-4 || active !== n.active) {
      if (n.active && !active) deactivated++;
      await db.update(nodes).set({ activation, active }).where(eq(nodes.id, n.id));
    }
  }
  const es = await db.select().from(edges).where(eq(edges.learnerId, learnerId));
  for (const e of es) {
    const ageDays = Math.max(0, (now.getTime() - e.lastReinforcedAt.getTime()) / 864e5);
    const weight = e.weight * Math.exp(-ageDays / 45);
    const active = weight >= 0.08;
    if (Math.abs(weight - e.weight) > 1e-4 || active !== e.active) {
      if (e.active && !active) deactivated++;
      await db.update(edges).set({ weight, active }).where(eq(edges.id, e.id));
    }
  }
  return deactivated;
}

export async function getGraph(learnerId: string, opts: { includeShared?: boolean; includeInactive?: boolean } = {}) {
  const scopes = opts.includeShared === false ? [learnerId] : [learnerId, SHARED];
  const ns = await db.select().from(nodes).where(inArray(nodes.learnerId, scopes));
  const es = await db.select().from(edges).where(inArray(edges.learnerId, scopes));
  const nodeIds = new Set(ns.map((n) => n.id));
  return {
    nodes: opts.includeInactive ? ns : ns.filter((n) => n.active || n.learnerId === SHARED),
    edges: es.filter((e) => nodeIds.has(e.fromId) && nodeIds.has(e.toId) && (opts.includeInactive || e.active)),
  };
}

export async function getSharedSubjectGraph(subject: string) {
  const ns = await db.select().from(nodes).where(and(eq(nodes.learnerId, SHARED), eq(nodes.subject, subject)));
  const ids = ns.map((n) => n.id);
  const es = ids.length
    ? await db.select().from(edges).where(and(eq(edges.learnerId, SHARED), or(inArray(edges.fromId, ids), inArray(edges.toId, ids))))
    : [];
  return { nodes: ns, edges: es };
}

// ---------------- Beliefs (long-term memory) ----------------

export type Belief = typeof beliefs.$inferSelect;

/**
 * Evidence-weighted Beta posterior with recency weighting.
 * alpha = weighted support, beta = weighted contradiction. Older evidence is discounted
 * each time new evidence arrives (recencyFactor), so the past is a prior, not a verdict.
 */
export function posteriorMean(alpha: number, beta: number) {
  return (alpha + 1) / (alpha + beta + 2);
}

export function evidenceWeight(alpha: number, beta: number) {
  return alpha + beta;
}

export type BeliefEvidence = {
  learnerId: string;
  kind: BeliefKind;
  key: string;
  statement: string; // may be regenerated by caller
  subject?: string | null;
  concept?: string | null;
  positive: boolean; // supports (true) or contradicts (false) the statement
  weight?: number; // evidence weight 0..1 (default 1)
  evidenceId?: string;
  sessionId?: string | null;
  now?: Date;
  recencyFactor?: number; // discount applied to old alpha/beta per new evidence (default 0.9)
  data?: Record<string, unknown>;
  note?: string;
};

export async function applyBeliefEvidence(ev: BeliefEvidence): Promise<Belief> {
  const now = ev.now ?? new Date();
  const w = ev.weight ?? 1;
  const rf = ev.recencyFactor ?? 0.9;
  const existing = await db
    .select()
    .from(beliefs)
    .where(and(eq(beliefs.learnerId, ev.learnerId), eq(beliefs.key, ev.key)))
    .limit(1);

  if (!existing.length) {
    const alpha = ev.positive ? w : 0;
    const beta = ev.positive ? 0 : w;
    const row = {
      id: newId("b"),
      learnerId: ev.learnerId,
      kind: ev.kind,
      key: ev.key,
      statement: ev.statement,
      subject: ev.subject ?? null,
      concept: ev.concept ?? null,
      confidence: posteriorMean(alpha, beta),
      support: ev.positive ? 1 : 0,
      contradictions: ev.positive ? 0 : 1,
      sessionsSeen: 1,
      status: "active" as BeliefStatus,
      evidenceIds: ev.evidenceId ? [ev.evidenceId] : [],
      history: [
        {
          at: now.toISOString(),
          confidence: posteriorMean(alpha, beta),
          support: ev.positive ? 1 : 0,
          contradictions: ev.positive ? 0 : 1,
          status: "active" as BeliefStatus,
          note: ev.note ?? "created",
        },
      ],
      data: { alpha, beta, lastSessionId: ev.sessionId ?? null, ...(ev.data ?? {}) },
      createdAt: now,
      updatedAt: now,
      lastEvidenceAt: now,
    };
    await db.insert(beliefs).values(row);
    return row as Belief;
  }

  const b = existing[0];
  const d = b.data as { alpha?: number; beta?: number; lastSessionId?: string | null };
  // Time-based forgetting of evidence weight: half-life 60 days.
  const ageDays = Math.max(0, (now.getTime() - b.lastEvidenceAt.getTime()) / 864e5);
  const timeDecay = Math.pow(0.5, ageDays / 60);
  let alpha = (d.alpha ?? 0) * timeDecay * rf;
  let beta = (d.beta ?? 0) * timeDecay * rf;
  if (ev.positive) alpha += w;
  else beta += w;
  const confidence = posteriorMean(alpha, beta);
  const newSession = ev.sessionId && ev.sessionId !== d.lastSessionId;
  const status: BeliefStatus = "active";
  const history = [
    ...b.history,
    { at: now.toISOString(), confidence, support: b.support + (ev.positive ? 1 : 0), contradictions: b.contradictions + (ev.positive ? 0 : 1), status, note: ev.note },
  ].slice(-60);
  const updated = {
    statement: ev.statement,
    subject: ev.subject ?? b.subject,
    concept: ev.concept ?? b.concept,
    confidence,
    support: b.support + (ev.positive ? 1 : 0),
    contradictions: b.contradictions + (ev.positive ? 0 : 1),
    sessionsSeen: b.sessionsSeen + (newSession ? 1 : 0),
    status,
    evidenceIds: ev.evidenceId ? [...b.evidenceIds, ev.evidenceId].slice(-100) : b.evidenceIds,
    history,
    data: { ...b.data, ...(ev.data ?? {}), alpha, beta, lastSessionId: ev.sessionId ?? d.lastSessionId ?? null, reactivatedAt: b.status !== "active" ? now.toISOString() : (b.data as Record<string, unknown>).reactivatedAt },
    updatedAt: now,
    lastEvidenceAt: now,
  };
  await db.update(beliefs).set(updated).where(eq(beliefs.id, b.id));
  return { ...b, ...updated } as Belief;
}

export async function getBeliefs(learnerId: string, opts: { kinds?: BeliefKind[]; statuses?: BeliefStatus[]; subject?: string | null } = {}) {
  const conds = [eq(beliefs.learnerId, learnerId)];
  if (opts.kinds?.length) conds.push(inArray(beliefs.kind, opts.kinds));
  if (opts.statuses?.length) conds.push(inArray(beliefs.status, opts.statuses));
  const rows = await db.select().from(beliefs).where(and(...conds)).orderBy(desc(beliefs.updatedAt));
  if (opts.subject === undefined) return rows;
  return rows.filter((b) => b.subject === opts.subject || b.subject === null);
}

/** Effective evidence weight after time decay: how much the belief should be trusted *now*. */
export function effectiveWeight(b: Belief, now = new Date()) {
  const d = b.data as { alpha?: number; beta?: number };
  const ageDays = Math.max(0, (now.getTime() - b.lastEvidenceAt.getTime()) / 864e5);
  return ((d.alpha ?? 0) + (d.beta ?? 0)) * Math.pow(0.5, ageDays / 60);
}

/** Mastery with forgetting: stability grows with evidence; retention decays without practice. */
export function retention(b: Belief, now = new Date()) {
  const d = b.data as { alpha?: number; beta?: number };
  const stability = 3 + 6 * Math.min(6, (d.alpha ?? 0)); // days; more successful evidence -> slower forgetting
  const ageDays = Math.max(0, (now.getTime() - b.lastEvidenceAt.getTime()) / 864e5);
  return Math.exp(-ageDays / stability);
}

export async function setBeliefStatus(id: string, status: BeliefStatus, note: string, now = new Date()) {
  const [b] = await db.select().from(beliefs).where(eq(beliefs.id, id)).limit(1);
  if (!b) return;
  await db
    .update(beliefs)
    .set({
      status,
      updatedAt: now,
      history: [...b.history, { at: now.toISOString(), confidence: b.confidence, support: b.support, contradictions: b.contradictions, status, note }].slice(-60),
    })
    .where(eq(beliefs.id, id));
}
