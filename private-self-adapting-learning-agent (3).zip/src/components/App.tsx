"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { GraphView } from "./GraphView";

type Learner = { id: string; name: string };
type Session = { id: string; title: string; lastActiveAt: string };
type Msg = { id: string; role: string; content: string; meta: { strategy?: string; action?: string; subject?: string; concepts?: string[]; researched?: boolean; provider?: string }; createdAt: string };
type Belief = { id: string; kind: string; key: string; statement: string; subject: string | null; confidence: number; support: number; contradictions: number; sessionsSeen: number; status: string; effectiveWeight: number; retention: number | null; lastEvidenceAt: string; history: { at: string; confidence: number; status: string; note?: string }[] };
type Obs = { id: string; kind: string; content: string; subject: string | null; concepts: string[]; salience: number; polarity: number; source: string; createdAt: string; consolidatedAt: string | null };
type Model = {
  beliefs: Belief[];
  observations: Obs[];
  consolidations: { id: string; observationsProcessed: number; beliefsCreated: number; beliefsUpdated: number; beliefsDormant: number; notes: string[]; createdAt: string }[];
  graph: { nodes: Parameters<typeof GraphView>[0]["nodes"]; edges: Parameters<typeof GraphView>[0]["edges"] };
  subjects: { slug: string; name: string; origin: string; concepts: { slug: string; label: string }[]; sources: { title: string; url?: string }[] }[];
};
type EvalRun = { id: string; name: string; summary: Record<string, unknown>; createdAt: string };

const STRAT: Record<string, string> = { example_first: "example → idea", concept_first: "idea → example", socratic: "guided questions", exercise: "exercise", analogy: "analogy", walkthrough: "walkthrough", direct: "direct" };

async function j<T>(url: string, init?: RequestInit): Promise<T> {
  const r = await fetch(url, { ...init, headers: { "content-type": "application/json", ...(init?.headers ?? {}) } });
  if (!r.ok) throw new Error((await r.json().catch(() => ({ error: r.statusText }))).error ?? r.statusText);
  return r.json();
}

export function App() {
  const [learners, setLearners] = useState<Learner[]>([]);
  const [learner, setLearner] = useState<Learner | null>(null);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [session, setSession] = useState<Session | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [model, setModel] = useState<Model | null>(null);
  const [tab, setTab] = useState<"long" | "short" | "graph" | "subjects" | "lab">("long");
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<{ provider: { available: boolean; name: string } } | null>(null);
  const [evals, setEvals] = useState<EvalRun[]>([]);
  const [toast, setToast] = useState<string | null>(null);
  const bottom = useRef<HTMLDivElement>(null);

  const loadModel = useCallback(async (id: string) => setModel(await j<Model>(`/api/learners/${id}/model`)), []);

  useEffect(() => {
    j<{ provider: { available: boolean; name: string } }>("/api/status").then(setStatus).catch(() => null);
    j<Learner[]>("/api/learners").then((ls) => {
      setLearners(ls);
      if (ls[0]) setLearner(ls[0]);
    });
    j<EvalRun[]>("/api/eval").then(setEvals).catch(() => null);
  }, []);

  useEffect(() => {
    if (!learner) return;
    setSession(null);
    setMsgs([]);
    j<Session[]>(`/api/learners/${learner.id}/sessions`).then((ss) => {
      setSessions(ss);
      if (ss[0]) setSession(ss[0]);
    });
    loadModel(learner.id);
  }, [learner, loadModel]);

  useEffect(() => {
    if (!session) return;
    j<Msg[]>(`/api/sessions/${session.id}/messages`).then(setMsgs);
  }, [session]);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, busy]);

  const newLearner = async () => {
    const name = prompt("Learner name?", "Alex") ?? "";
    if (!name.trim()) return;
    const l = await j<Learner>("/api/learners", { method: "POST", body: JSON.stringify({ name }) });
    setLearners((x) => [l, ...x]);
    setLearner(l);
  };
  const newSession = async () => {
    if (!learner) return;
    const s = await j<Session>(`/api/learners/${learner.id}/sessions`, { method: "POST" });
    setSessions((x) => [s, ...x]);
    setSession(s);
    setMsgs([]);
  };

  const send = async () => {
    if (!learner || !input.trim() || busy) return;
    let s = session;
    if (!s) {
      s = await j<Session>(`/api/learners/${learner.id}/sessions`, { method: "POST" });
      setSessions((x) => [s!, ...x]);
      setSession(s);
    }
    const text = input;
    setInput("");
    setBusy(true);
    setMsgs((m) => [...m, { id: `tmp_${Date.now()}`, role: "user", content: text, meta: {}, createdAt: new Date().toISOString() }]);
    try {
      const r = await j<{ reply: string; meta: Msg["meta"]; consolidated: boolean; researchedSubject: string | null }>("/api/chat", { method: "POST", body: JSON.stringify({ learnerId: learner.id, sessionId: s.id, text }) });
      setMsgs((m) => [...m, { id: `a_${Date.now()}`, role: "assistant", content: r.reply, meta: r.meta, createdAt: new Date().toISOString() }]);
      if (r.researchedSubject) setToast(`Researched a new subject: ${r.researchedSubject}`);
      else if (r.consolidated) setToast("Memory consolidated");
      j<Session[]>(`/api/learners/${learner.id}/sessions`).then(setSessions);
      loadModel(learner.id);
    } catch (e) {
      setMsgs((m) => [...m, { id: `err_${Date.now()}`, role: "assistant", content: `Something went wrong: ${(e as Error).message}`, meta: {}, createdAt: new Date().toISOString() }]);
    } finally {
      setBusy(false);
      setTimeout(() => setToast(null), 4000);
    }
  };

  const consolidateNow = async () => {
    if (!learner) return;
    const r = await j<{ processed: number; created: number; updated: number; dormant: number }>(`/api/learners/${learner.id}/consolidate`, { method: "POST" });
    setToast(`Consolidated ${r.processed} observations · ${r.created} new beliefs · ${r.updated} updated · ${r.dormant} dormant`);
    loadModel(learner.id);
    setTimeout(() => setToast(null), 5000);
  };

  const byKind = (k: string) => (model?.beliefs ?? []).filter((b) => b.kind === k).sort((a, b) => Number(b.status === "active") - Number(a.status === "active") || b.effectiveWeight - a.effectiveWeight);

  return (
    <div className="h-screen flex flex-col bg-slate-100 text-slate-900">
      <header className="flex items-center justify-between px-4 py-2 bg-white border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-600 to-violet-600" />
          <div>
            <div className="font-semibold leading-tight">Private Self-Adapting Learning Agent</div>
            <div className="text-[11px] text-slate-500">one tutor · persistent, evidence-based memory · open-ended conversation</div>
          </div>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <span className={`px-2 py-1 rounded-full ${status?.provider.available ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}`} title="Set OPENAI_API_KEY (and optionally OPENAI_BASE_URL, LLM_MODEL) to enable a model provider">
            {status ? (status.provider.available ? `model: ${status.provider.name}` : "offline mode — set OPENAI_API_KEY for full tutoring") : "…"}
          </span>
          <a className="text-slate-500 hover:text-slate-800" href="/api/mcp" target="_blank">MCP</a>
        </div>
      </header>
      {toast && <div className="absolute top-14 left-1/2 -translate-x-1/2 z-10 bg-slate-900 text-white text-xs px-3 py-1.5 rounded-full shadow">{toast}</div>}
      <div className="flex-1 grid grid-cols-[220px_1fr_460px] min-h-0">
        <aside className="bg-white border-r border-slate-200 p-3 overflow-y-auto text-sm">
          <div className="flex items-center justify-between mb-2"><span className="font-medium text-slate-700">Learners</span><button onClick={newLearner} className="text-blue-600 hover:underline text-xs">+ new</button></div>
          <ul className="space-y-1 mb-4">
            {learners.map((l) => (
              <li key={l.id}><button onClick={() => setLearner(l)} className={`w-full text-left px-2 py-1 rounded ${learner?.id === l.id ? "bg-blue-50 text-blue-800" : "hover:bg-slate-50"}`}>{l.name}</button></li>
            ))}
            {!learners.length && <li className="text-xs text-slate-500">Create a learner to begin.</li>}
          </ul>
          {learner && (
            <>
              <div className="flex items-center justify-between mb-2"><span className="font-medium text-slate-700">Conversations</span><button onClick={newSession} className="text-blue-600 hover:underline text-xs">+ new</button></div>
              <ul className="space-y-1">
                {sessions.map((s) => (
                  <li key={s.id}><button onClick={() => setSession(s)} className={`w-full text-left px-2 py-1 rounded text-xs ${session?.id === s.id ? "bg-blue-50 text-blue-800" : "hover:bg-slate-50"}`}><div className="truncate">{s.title}</div><div className="text-[10px] text-slate-400">{new Date(s.lastActiveAt).toLocaleString()}</div></button></li>
                ))}
              </ul>
            </>
          )}
        </aside>

        <main className="flex flex-col min-h-0">
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {!learner && <div className="text-slate-500 text-sm">Create a learner on the left, then just talk: “I want to learn Bash”, paste code, ask why something works, change topic — the agent adapts around you.</div>}
            {learner && !msgs.length && !busy && (
              <div className="text-slate-500 text-sm max-w-xl">
                <p className="mb-2">Talk naturally. Some things you can try:</p>
                <ul className="list-disc ml-5 space-y-1 text-xs">
                  <li>“I want to learn Bash” — the agent researches the subject if it doesn’t know it yet</li>
                  <li>Paste code and ask “why does this work?”</li>
                  <li>“Simpler please”, “go deeper”, “give me an exercise”, “let’s move on”</li>
                  <li>Disagree with it. Change subject. Come back tomorrow.</li>
                </ul>
              </div>
            )}
            {msgs.map((m) => (
              <div key={m.id} className={`max-w-[80%] ${m.role === "user" ? "ml-auto" : ""}`}>
                <div className={`rounded-2xl px-4 py-2.5 text-sm whitespace-pre-wrap leading-relaxed ${m.role === "user" ? "bg-blue-600 text-white" : "bg-white border border-slate-200"}`}>{m.content}</div>
                {m.role === "assistant" && (m.meta.strategy || m.meta.researched) && (
                  <div className="flex flex-wrap gap-1 mt-1 text-[10px] text-slate-500">
                    {m.meta.strategy && <span className="px-1.5 py-0.5 bg-slate-200 rounded">{STRAT[m.meta.strategy] ?? m.meta.strategy}</span>}
                    {m.meta.action && <span className="px-1.5 py-0.5 bg-slate-200 rounded">{m.meta.action}</span>}
                    {m.meta.subject && <span className="px-1.5 py-0.5 bg-slate-200 rounded">{m.meta.subject}{m.meta.concepts?.length ? ` · ${m.meta.concepts.join(", ")}` : ""}</span>}
                    {m.meta.researched && <span className="px-1.5 py-0.5 bg-violet-100 text-violet-800 rounded">researched subject</span>}
                  </div>
                )}
              </div>
            ))}
            {busy && <div className="text-xs text-slate-400">thinking…</div>}
            <div ref={bottom} />
          </div>
          <div className="p-3 bg-white border-t border-slate-200">
            <div className="flex gap-2">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    send();
                  }
                }}
                rows={2}
                placeholder={learner ? "Say anything… (Enter to send, Shift+Enter for newline)" : "Create a learner first"}
                disabled={!learner || busy}
                className="flex-1 resize-none rounded-xl border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button onClick={send} disabled={!learner || busy || !input.trim()} className="px-4 rounded-xl bg-blue-600 text-white text-sm font-medium disabled:opacity-40">Send</button>
            </div>
          </div>
        </main>

        <aside className="bg-white border-l border-slate-200 flex flex-col min-h-0">
          <div className="flex items-center gap-1 px-3 pt-2 border-b border-slate-200 text-xs">
            {(["long", "short", "graph", "subjects", "lab"] as const).map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`px-2.5 py-1.5 rounded-t ${tab === t ? "bg-slate-100 font-medium" : "text-slate-500 hover:text-slate-800"}`}>
                {{ long: "Long-term", short: "Working memory", graph: "Graph", subjects: "Subjects", lab: "Lab" }[t]}
              </button>
            ))}
            <div className="ml-auto pb-1"><button onClick={consolidateNow} disabled={!learner} className="text-[11px] text-blue-600 hover:underline disabled:opacity-40">consolidate now</button></div>
          </div>
          <div className="flex-1 overflow-y-auto p-3 text-sm">
            {!model && <div className="text-slate-400 text-xs">No learner selected.</div>}
            {model && tab === "long" && (
              <div className="space-y-4">
                <p className="text-[11px] text-slate-500">Consolidated beliefs with evidence. A belief is a prior, not a verdict: confidence is a recency-weighted posterior; “weight” is time-decayed evidence; dormant beliefs keep their history and can reactivate.</p>
                {[
                  ["goal", "Goals"],
                  ["mastery", "Mastery (with forgetting)"],
                  ["strategy_effect", "What works (teaching approaches)"],
                  ["preference", "Preferences"],
                  ["tendency", "Tendencies"],
                  ["misconception", "Misconceptions"],
                ].map(([k, title]) => {
                  const list = byKind(k);
                  if (!list.length) return null;
                  return (
                    <section key={k}>
                      <h3 className="font-medium text-slate-700 mb-1">{title}</h3>
                      <ul className="space-y-1.5">
                        {list.slice(0, 40).map((b) => (
                          <li key={b.id} className={`rounded-lg border px-2.5 py-1.5 ${b.status === "active" ? "border-slate-200" : "border-dashed border-slate-200 opacity-60"}`}>
                            <div className="flex items-start justify-between gap-2">
                              <span className="text-xs">{b.statement}</span>
                              <span className={`text-[10px] px-1.5 rounded-full shrink-0 ${b.status === "active" ? "bg-emerald-100 text-emerald-800" : "bg-slate-100 text-slate-500"}`}>{b.status}</span>
                            </div>
                            <div className="mt-1 h-1.5 bg-slate-100 rounded overflow-hidden"><div className={`h-full ${b.confidence >= 0.6 ? "bg-emerald-500" : b.confidence >= 0.4 ? "bg-amber-400" : "bg-rose-400"}`} style={{ width: `${Math.round(b.confidence * 100)}%` }} /></div>
                            <div className="text-[10px] text-slate-500 mt-0.5">
                              {Math.round(b.confidence * 100)}% · weight {b.effectiveWeight.toFixed(1)} ({b.effectiveWeight < 1.5 ? "weak" : b.effectiveWeight < 4 ? "moderate" : "strong"}) · {b.support}+ / {b.contradictions}− · {b.sessionsSeen} session{b.sessionsSeen === 1 ? "" : "s"}
                              {b.subject ? ` · ${b.subject}` : " · general"}
                              {b.retention !== null && b.retention < 0.6 ? ` · retention ${Math.round(b.retention * 100)}%` : ""}
                            </div>
                          </li>
                        ))}
                      </ul>
                    </section>
                  );
                })}
                {!model.beliefs.length && <div className="text-xs text-slate-400">Nothing durable yet. Beliefs form from repeated evidence.</div>}
                {model.consolidations.length > 0 && (
                  <section>
                    <h3 className="font-medium text-slate-700 mb-1">Consolidation log</h3>
                    <ul className="text-[11px] text-slate-500 space-y-1">
                      {model.consolidations.slice(0, 5).map((c) => (
                        <li key={c.id}>{new Date(c.createdAt).toLocaleString()} · {c.observationsProcessed} obs → +{c.beliefsCreated} / ~{c.beliefsUpdated} / {c.beliefsDormant} dormant{c.notes.length ? ` · ${c.notes.slice(0, 2).join("; ")}` : ""}</li>
                      ))}
                    </ul>
                  </section>
                )}
              </div>
            )}
            {model && tab === "short" && (
              <div>
                <p className="text-[11px] text-slate-500 mb-2">Recent, lightly interpreted evidence. Nothing is deleted; consolidation marks what has been folded into long-term beliefs.</p>
                <ul className="space-y-1">
                  {model.observations.map((o) => (
                    <li key={o.id} className="text-xs border-b border-slate-100 pb-1">
                      <span className={`inline-block px-1.5 rounded text-[10px] mr-1 ${o.polarity > 0 ? "bg-emerald-100 text-emerald-800" : o.polarity < 0 ? "bg-rose-100 text-rose-800" : "bg-slate-100 text-slate-600"}`}>{o.kind}</span>
                      {o.content}
                      <div className="text-[10px] text-slate-400">{new Date(o.createdAt).toLocaleString()} · salience {o.salience.toFixed(2)} · {o.source}{o.subject ? ` · ${o.subject}` : ""}{o.concepts.length ? ` · ${o.concepts.join(", ")}` : ""}{o.consolidatedAt ? " · consolidated" : " · pending"}</div>
                    </li>
                  ))}
                  {!model.observations.length && <li className="text-xs text-slate-400">No observations yet.</li>}
                </ul>
              </div>
            )}
            {model && tab === "graph" && learner && <GraphView nodes={model.graph.nodes} edges={model.graph.edges} learnerId={learner.id} />}
            {model && tab === "subjects" && (
              <div className="space-y-3">
                {model.subjects.map((s) => (
                  <div key={s.slug} className="border border-slate-200 rounded-lg p-2">
                    <div className="font-medium">{s.name} <span className="text-[10px] text-slate-400">({s.origin})</span></div>
                    <div className="text-[11px] text-slate-600 mt-1 flex flex-wrap gap-1">{s.concepts.map((c) => <span key={c.slug} className="px-1.5 bg-slate-100 rounded">{c.label}</span>)}</div>
                    {s.sources.length > 0 && <div className="text-[10px] text-slate-400 mt-1">Sources: {s.sources.map((x) => (x.url ? <a key={x.title} className="underline mr-1" href={x.url} target="_blank">{x.title}</a> : <span key={x.title} className="mr-1">{x.title}</span>))}</div>}
                  </div>
                ))}
                {!model.subjects.length && <div className="text-xs text-slate-400">No subjects touched yet. Say “I want to learn …”.</div>}
              </div>
            )}
            {tab === "lab" && (
              <div className="space-y-3">
                <p className="text-[11px] text-slate-500">Results of the empirical lab (synthetic learners, long-horizon and adversarial scenarios, ablations). Regenerate with <code>npx tsx lab/run.ts</code> and <code>npx tsx lab/adversarial.ts</code>.</p>
                {evals.map((e) => (
                  <details key={e.id} className="border border-slate-200 rounded-lg p-2" open={evals[0]?.id === e.id}>
                    <summary className="text-xs font-medium cursor-pointer">{e.name} <span className="text-slate-400 font-normal">· {new Date(e.createdAt).toLocaleString()}</span></summary>
                    <pre className="text-[10px] mt-2 whitespace-pre-wrap text-slate-700">{JSON.stringify(e.summary, null, 2)}</pre>
                  </details>
                ))}
                {!evals.length && <div className="text-xs text-slate-400">No lab runs recorded yet.</div>}
              </div>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
