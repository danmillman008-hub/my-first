"use client";
import { useMemo } from "react";

type N = { id: string; learnerId: string; kind: string; label: string; subject: string | null; activation: number; touchCount: number; active: boolean };
type E = { id: string; fromId: string; toId: string; relation: string; weight: number; evidenceCount: number; active: boolean };

const COLORS: Record<string, string> = {
  prerequisite_of: "#94a3b8",
  part_of: "#cbd5e1",
  related_to: "#60a5fa",
  confused_with: "#f87171",
  helped_by: "#34d399",
  struggles_in: "#fb923c",
  leads_to: "#a78bfa",
};

export function GraphView({ nodes, edges, learnerId }: { nodes: N[]; edges: E[]; learnerId: string }) {
  const W = 640;
  const H = 460;
  const layout = useMemo(() => {
    // Merge learner-scoped and shared nodes with the same slug/kind so learner evidence overlays the subject map
    const key = (n: N) => `${n.kind}:${n.label.toLowerCase()}:${n.subject ?? ""}`;
    const merged = new Map<string, N & { mine: boolean; ids: string[] }>();
    for (const n of nodes) {
      const k = key(n);
      const m = merged.get(k);
      if (m) {
        m.ids.push(n.id);
        if (n.learnerId === learnerId) {
          m.mine = true;
          m.activation = n.activation;
          m.touchCount = n.touchCount;
          m.active = n.active;
        }
      } else merged.set(k, { ...n, mine: n.learnerId === learnerId, ids: [n.id] });
    }
    const list = [...merged.values()].slice(0, 90);
    const idToKey = new Map<string, string>();
    for (const m of list) for (const id of m.ids) idToKey.set(id, key(m));
    const idx = new Map(list.map((n, i) => [key(n), i]));
    const es = edges
      .map((e) => ({ ...e, a: idx.get(idToKey.get(e.fromId) ?? ""), b: idx.get(idToKey.get(e.toId) ?? "") }))
      .filter((e) => e.a !== undefined && e.b !== undefined && e.a !== e.b) as (E & { a: number; b: number })[];
    let seed = 7;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    const pos = list.map(() => ({ x: W / 2 + (rnd() - 0.5) * W * 0.8, y: H / 2 + (rnd() - 0.5) * H * 0.8, vx: 0, vy: 0 }));
    for (let it = 0; it < 220; it++) {
      const t = 1 - it / 220;
      for (let i = 0; i < pos.length; i++) {
        for (let j = i + 1; j < pos.length; j++) {
          const dx = pos[i].x - pos[j].x;
          const dy = pos[i].y - pos[j].y;
          const d2 = dx * dx + dy * dy + 0.01;
          const f = (2600 / d2) * t;
          pos[i].vx += dx * f * 0.01;
          pos[i].vy += dy * f * 0.01;
          pos[j].vx -= dx * f * 0.01;
          pos[j].vy -= dy * f * 0.01;
        }
      }
      for (const e of es) {
        const dx = pos[e.b].x - pos[e.a].x;
        const dy = pos[e.b].y - pos[e.a].y;
        const d = Math.sqrt(dx * dx + dy * dy) + 0.01;
        const k = (d - 90) * 0.02 * (0.3 + e.weight) * t;
        pos[e.a].vx += (dx / d) * k;
        pos[e.a].vy += (dy / d) * k;
        pos[e.b].vx -= (dx / d) * k;
        pos[e.b].vy -= (dy / d) * k;
      }
      for (const p of pos) {
        p.vx += (W / 2 - p.x) * 0.002;
        p.vy += (H / 2 - p.y) * 0.002;
        p.x = Math.max(20, Math.min(W - 20, p.x + p.vx));
        p.y = Math.max(14, Math.min(H - 14, p.y + p.vy));
        p.vx *= 0.6;
        p.vy *= 0.6;
      }
    }
    return { list, es, pos };
  }, [nodes, edges, learnerId]);

  if (!layout.list.length) return <div className="text-sm text-slate-500 p-4">No graph yet — the graph grows from conversation.</div>;
  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto bg-white rounded-lg border border-slate-200">
        {layout.es.map((e) => (
          <line
            key={e.id}
            x1={layout.pos[e.a].x}
            y1={layout.pos[e.a].y}
            x2={layout.pos[e.b].x}
            y2={layout.pos[e.b].y}
            stroke={COLORS[e.relation] ?? "#cbd5e1"}
            strokeWidth={0.6 + e.weight * 3}
            strokeOpacity={e.active ? 0.85 : 0.25}
            strokeDasharray={e.active ? undefined : "4 3"}
          >
            <title>
              {e.relation} · w={e.weight.toFixed(2)} · {e.evidenceCount} evidence
            </title>
          </line>
        ))}
        {layout.list.map((n, i) => {
          const r = n.kind === "subject" ? 11 : 5 + Math.min(8, Math.sqrt(n.touchCount) * 1.6);
          const fill = n.kind === "subject" ? "#0f172a" : n.mine ? (n.active ? "#2563eb" : "#93c5fd") : "#e2e8f0";
          return (
            <g key={key2(n)}>
              <circle cx={layout.pos[i].x} cy={layout.pos[i].y} r={r} fill={fill} fillOpacity={n.mine ? 0.35 + 0.65 * n.activation : 1} stroke={n.mine ? "#1e40af" : "#94a3b8"} strokeWidth={0.8}>
                <title>
                  {n.label} ({n.kind}) · touched {n.touchCount}× · activation {n.activation.toFixed(2)} {n.mine ? "" : "· subject map"}
                </title>
              </circle>
              <text x={layout.pos[i].x + r + 2} y={layout.pos[i].y + 3} fontSize={9} fill="#334155">
                {n.label.length > 22 ? n.label.slice(0, 21) + "…" : n.label}
              </text>
            </g>
          );
        })}
      </svg>
      <div className="flex flex-wrap gap-3 mt-2 text-[11px] text-slate-600">
        <span><span className="inline-block w-3 h-3 rounded-full bg-blue-600 align-middle mr-1" />touched by learner (size = touches, opacity = activation)</span>
        <span><span className="inline-block w-3 h-3 rounded-full bg-slate-200 align-middle mr-1" />subject map</span>
        {Object.entries(COLORS).map(([k, c]) => (
          <span key={k}><span className="inline-block w-4 h-0.5 align-middle mr-1" style={{ background: c }} />{k}</span>
        ))}
      </div>
    </div>
  );
}

function key2(n: { kind: string; label: string; subject: string | null }) {
  return `${n.kind}:${n.label}:${n.subject ?? ""}`;
}
