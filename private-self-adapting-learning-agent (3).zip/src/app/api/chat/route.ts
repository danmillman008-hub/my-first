import { handleTurn } from "@/lib/agent/agent";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { learnerId?: string; sessionId?: string; text?: string };
  if (!body.learnerId || !body.sessionId || !body.text?.trim()) return Response.json({ error: "learnerId, sessionId and text are required" }, { status: 400 });
  try {
    const r = await handleTurn(body.learnerId, body.sessionId, body.text);
    return Response.json({
      reply: r.reply,
      meta: r.meta,
      consolidated: r.consolidated,
      researchedSubject: r.researchedSubject ?? null,
      signals: { confusion: r.signals.confusion, understanding: r.signals.understanding, request: r.signals.request ?? null, disagreement: r.signals.disagreement, hasCode: r.signals.hasCode, goal: r.signals.goal ?? null },
      recommended: r.context.recommended,
      probe: r.context.probe,
      assistantMessageId: r.assistantMessageId,
    });
  } catch (e) {
    console.error(e);
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}
