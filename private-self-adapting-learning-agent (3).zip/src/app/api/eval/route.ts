import { db } from "@/db";
import { evalRuns } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(evalRuns).orderBy(desc(evalRuns.createdAt)).limit(20);
  return Response.json(rows);
}
