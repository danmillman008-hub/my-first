import { db } from "@/db";
import { learners } from "@/db/schema";
import { newId } from "@/lib/memory/store";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(learners).orderBy(desc(learners.createdAt));
  return Response.json(rows);
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { name?: string };
  const name = (body.name ?? "").trim() || "Learner";
  const row = { id: newId("l"), name, createdAt: new Date(), meta: {} };
  await db.insert(learners).values(row);
  return Response.json(row, { status: 201 });
}
