import { consolidate } from "@/lib/memory/consolidate";

export const dynamic = "force-dynamic";

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const r = await consolidate(id);
  return Response.json(r);
}
