import { db } from "@/db";
import { consolidations, observations, subjects } from "@/db/schema";
import { effectiveWeight, getBeliefs, getGraph, retention } from "@/lib/memory/store";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const now = new Date();
  const [beliefs, obs, cons, graph, subj] = await Promise.all([
    getBeliefs(id),
    db.select().from(observations).where(eq(observations.learnerId, id)).orderBy(desc(observations.createdAt)).limit(60),
    db.select().from(consolidations).where(eq(consolidations.learnerId, id)).orderBy(desc(consolidations.createdAt)).limit(10),
    getGraph(id, { includeInactive: true }),
    db.select().from(subjects),
  ]);
  const touchedSubjects = new Set(graph.nodes.filter((n) => n.learnerId === id).map((n) => n.subject).filter(Boolean));
  return Response.json({
    beliefs: beliefs.map((b) => ({ ...b, effectiveWeight: effectiveWeight(b, now), retention: b.kind === "mastery" ? retention(b, now) : null })),
    observations: obs,
    consolidations: cons,
    graph: {
      nodes: graph.nodes.filter((n) => n.learnerId === id || touchedSubjects.has(n.subject)),
      edges: graph.edges,
    },
    subjects: subj.filter((s) => touchedSubjects.has(s.slug)),
  });
}
