import { db } from "@/db";
import { sessions } from "@/db/schema";
import { newId } from "@/lib/memory/store";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rows = await db.select().from(sessions).where(eq(sessions.learnerId, id)).orderBy(desc(sessions.lastActiveAt));
  return Response.json(rows);
}

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const row = { id: newId("s"), learnerId: id, title: "New conversation", startedAt: new Date(), lastActiveAt: new Date() };
  await db.insert(sessions).values(row);
  return Response.json(row, { status: 201 });
}
