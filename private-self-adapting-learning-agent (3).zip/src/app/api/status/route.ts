import { providerStatus } from "@/lib/llm/provider";
import { db } from "@/db";
import { subjects } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const subj = await db.select({ slug: subjects.slug, name: subjects.name, origin: subjects.origin }).from(subjects);
  return Response.json({ provider: providerStatus(), subjects: subj });
}
