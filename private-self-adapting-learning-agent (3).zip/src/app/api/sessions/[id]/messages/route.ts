import { db } from "@/db";
import { messages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rows = await db.select().from(messages).where(eq(messages.sessionId, id)).orderBy(asc(messages.createdAt));
  return Response.json(rows);
}
