import { db } from "@/db";
import { learners, observations, type ObservationKind } from "@/db/schema";
import { buildLearnerContext, renderContext } from "@/lib/agent/context";
import { tokenize } from "@/lib/agent/perceive";
import { consolidate } from "@/lib/memory/consolidate";
import { effectiveWeight, getBeliefs, getGraph, recordObservation } from "@/lib/memory/store";
import { ensureSubject, getSubject, listSubjects, normalizeSubjectName } from "@/lib/subjects/research";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

// Minimal Model Context Protocol server (Streamable HTTP transport, JSON responses).
// The MCP layer exposes the learner model; it is not the intelligence.

const PROTOCOL_VERSION = "2025-03-26";

const TOOLS = [
  { name: "list_learners", description: "List learners known to the learning agent.", inputSchema: { type: "object", properties: {} } },
  {
    name: "get_learner_profile",
    description: "Get the consolidated learner model (mastery, preferences, tendencies, strategy effectiveness) with epistemic status, optionally scoped to a subject. Treat it as a prior, not a verdict.",
    inputSchema: { type: "object", properties: { learnerId: { type: "string" }, subject: { type: "string", description: "subject slug, e.g. 'bash'" } }, required: ["learnerId"] },
  },
  {
    name: "search_memory",
    description: "Search the learner's short-term evidence stream (observations) by keywords.",
    inputSchema: { type: "object", properties: { learnerId: { type: "string" }, query: { type: "string" }, limit: { type: "number" } }, required: ["learnerId", "query"] },
  },
  {
    name: "get_graph",
    description: "Get the learner's evolving knowledge/interaction graph (nodes, weighted edges, activation), including the shared subject graph.",
    inputSchema: { type: "object", properties: { learnerId: { type: "string" }, subject: { type: "string" }, includeInactive: { type: "boolean" } }, required: ["learnerId"] },
  },
  {
    name: "record_observation",
    description: "Contribute evidence about the learner from an external tool (e.g. an IDE assistant saw them fix a bug). Goes into short-term memory and must earn long-term status through consolidation.",
    inputSchema: {
      type: "object",
      properties: {
        learnerId: { type: "string" },
        kind: { type: "string", enum: ["success", "mistake", "understanding", "confusion", "claim", "remark", "goal"] },
        content: { type: "string" },
        subject: { type: "string" },
        concepts: { type: "array", items: { type: "string" } },
        polarity: { type: "number" },
        salience: { type: "number" },
      },
      required: ["learnerId", "kind", "content"],
    },
  },
  { name: "get_subject", description: "Get (or research, if unknown) the concept map for a subject.", inputSchema: { type: "object", properties: { subject: { type: "string" } }, required: ["subject"] } },
  { name: "consolidate", description: "Run memory consolidation for a learner now.", inputSchema: { type: "object", properties: { learnerId: { type: "string" } }, required: ["learnerId"] } },
];

type Rpc = { jsonrpc: "2.0"; id?: string | number | null; method: string; params?: Record<string, unknown> };

async function callTool(name: string, args: Record<string, unknown>) {
  switch (name) {
    case "list_learners":
      return db.select().from(learners).orderBy(desc(learners.createdAt));
    case "get_learner_profile": {
      const learnerId = String(args.learnerId);
      const subj = args.subject ? await getSubject(normalizeSubjectName(String(args.subject)).slug) : null;
      const ctx = await buildLearnerContext(learnerId, subj, [], { allowProbes: false });
      const now = new Date();
      const beliefs = (await getBeliefs(learnerId)).map((b) => ({ key: b.key, kind: b.kind, statement: b.statement, subject: b.subject, confidence: b.confidence, support: b.support, contradictions: b.contradictions, sessionsSeen: b.sessionsSeen, status: b.status, effectiveWeight: effectiveWeight(b, now), lastEvidenceAt: b.lastEvidenceAt }));
      return { rendered: renderContext(ctx, now), beliefs, mastery: ctx.mastery, strategies: ctx.strategies };
    }
    case "search_memory": {
      const q = new Set(tokenize(String(args.query)));
      const rows = await db.select().from(observations).where(eq(observations.learnerId, String(args.learnerId))).orderBy(desc(observations.createdAt)).limit(400);
      return rows
        .map((o) => ({ o, score: tokenize(`${o.content} ${o.subject ?? ""} ${o.concepts.join(" ")}`).filter((t) => q.has(t)).length }))
        .filter((x) => x.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, Number(args.limit ?? 20))
        .map((x) => x.o);
    }
    case "get_graph": {
      const g = await getGraph(String(args.learnerId), { includeInactive: !!args.includeInactive });
      if (args.subject) {
        const s = normalizeSubjectName(String(args.subject)).slug;
        const ids = new Set(g.nodes.filter((n) => n.subject === s).map((n) => n.id));
        return { nodes: g.nodes.filter((n) => ids.has(n.id)), edges: g.edges.filter((e) => ids.has(e.fromId) && ids.has(e.toId)) };
      }
      return g;
    }
    case "record_observation": {
      const id = await recordObservation({
        learnerId: String(args.learnerId),
        kind: String(args.kind) as ObservationKind,
        content: String(args.content),
        subject: args.subject ? normalizeSubjectName(String(args.subject)).slug : null,
        concepts: Array.isArray(args.concepts) ? args.concepts.map(String) : [],
        polarity: typeof args.polarity === "number" ? args.polarity : 0,
        salience: typeof args.salience === "number" ? args.salience : 0.4,
        source: "mcp",
      });
      return { id };
    }
    case "get_subject":
      return (await ensureSubject(String(args.subject))).subject;
    case "consolidate":
      return consolidate(String(args.learnerId));
    default:
      throw new Error(`unknown tool ${name}`);
  }
}

function result(id: Rpc["id"], res: unknown) {
  return { jsonrpc: "2.0", id: id ?? null, result: res };
}
function error(id: Rpc["id"], code: number, message: string) {
  return { jsonrpc: "2.0", id: id ?? null, error: { code, message } };
}

async function handle(msg: Rpc) {
  switch (msg.method) {
    case "initialize":
      return result(msg.id, { protocolVersion: PROTOCOL_VERSION, capabilities: { tools: {} }, serverInfo: { name: "self-adapting-learning-agent", version: "1.0.0" } });
    case "ping":
      return result(msg.id, {});
    case "tools/list":
      return result(msg.id, { tools: TOOLS });
    case "tools/call": {
      const p = (msg.params ?? {}) as { name?: string; arguments?: Record<string, unknown> };
      try {
        const out = await callTool(String(p.name), p.arguments ?? {});
        return result(msg.id, { content: [{ type: "text", text: JSON.stringify(out, null, 2) }], isError: false });
      } catch (e) {
        return result(msg.id, { content: [{ type: "text", text: (e as Error).message }], isError: true });
      }
    }
    default:
      if (msg.method.startsWith("notifications/")) return null;
      return error(msg.id, -32601, `method not found: ${msg.method}`);
  }
}

export async function POST(req: Request) {
  let body: Rpc | Rpc[];
  try {
    body = (await req.json()) as Rpc | Rpc[];
  } catch {
    return Response.json(error(null, -32700, "parse error"), { status: 400 });
  }
  const msgs = Array.isArray(body) ? body : [body];
  const responses = (await Promise.all(msgs.map(handle))).filter((r) => r !== null);
  if (!responses.length) return new Response(null, { status: 202 });
  return Response.json(Array.isArray(body) ? responses : responses[0]);
}

export async function GET() {
  return Response.json({ name: "self-adapting-learning-agent", protocolVersion: PROTOCOL_VERSION, transport: "streamable-http (JSON responses)", tools: TOOLS.map((t) => t.name), subjects: (await listSubjects()).map((s) => s.slug) });
}
