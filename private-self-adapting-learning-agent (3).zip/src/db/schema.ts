import {
  pgTable,
  text,
  timestamp,
  integer,
  real,
  boolean,
  jsonb,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

// ---------- Learners & conversation ----------

export const learners = pgTable("learners", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
});

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    title: text("title").notNull().default("New conversation"),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sessions_learner_idx").on(t.learnerId)]
);

export type MessageMeta = {
  strategy?: string; // teaching strategy used by the assistant for this turn
  action?: string; // high-level action the agent chose (answer, ask, exercise, research, ...)
  concepts?: string[];
  subject?: string;
  signals?: Record<string, unknown>;
  provider?: string;
  evidenceIds?: string[];
  researched?: boolean;
};

export const messages = pgTable(
  "messages",
  {
    id: text("id").primaryKey(),
    sessionId: text("session_id").notNull(),
    learnerId: text("learner_id").notNull(),
    role: text("role").notNull(), // user | assistant | system
    content: text("content").notNull(),
    meta: jsonb("meta").$type<MessageMeta>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("messages_session_idx").on(t.sessionId), index("messages_learner_idx").on(t.learnerId)]
);

// ---------- Short-term / working memory: observations ----------
// Rich, lightly interpreted evidence. Never deleted; consolidation marks them.

export type ObservationKind =
  | "confusion" // learner signalled not understanding
  | "understanding" // learner signalled comprehension / success
  | "mistake" // an error observed in learner work
  | "success" // a correct answer / working solution
  | "claim" // learner claims about self ("I already know X")
  | "request" // learner asked for a style change (simpler/deeper/example/move on)
  | "topic_switch"
  | "disagreement" // learner disagrees with / corrects tutor
  | "strategy_outcome" // tutor used strategy S, learner reaction R
  | "remark" // casual remark, contextual info
  | "insight" // higher-level reflection proposed by the agent (must earn belief status)
  | "goal";

export const observations = pgTable(
  "observations",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id"),
    messageId: text("message_id"),
    kind: text("kind").$type<ObservationKind>().notNull(),
    content: text("content").notNull(), // natural language description of the evidence
    subject: text("subject"), // context (e.g. "bash", "linear algebra")
    concepts: jsonb("concepts").$type<string[]>().notNull().default([]),
    // structured payload, e.g. { strategy: "example_first", outcome: "understood", polarity: 1 }
    data: jsonb("data").$type<Record<string, unknown>>().notNull().default({}),
    polarity: real("polarity").notNull().default(0), // -1..1 direction of evidence where applicable
    salience: real("salience").notNull().default(0.3), // heuristic importance 0..1 (cheap, not LLM rated)
    source: text("source").notNull().default("heuristic"), // heuristic | llm | mcp | user
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    consolidatedAt: timestamp("consolidated_at", { withTimezone: true }),
  },
  (t) => [
    index("obs_learner_idx").on(t.learnerId),
    index("obs_learner_created_idx").on(t.learnerId, t.createdAt),
    index("obs_unconsolidated_idx").on(t.learnerId, t.consolidatedAt),
  ]
);

// ---------- Graph: nodes & edges (emergent structure) ----------

export type NodeKind = "subject" | "concept" | "strategy" | "goal" | "theme";

export const nodes = pgTable(
  "nodes",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull().default("__shared__"), // "__shared__" => subject knowledge shared across learners
    kind: text("kind").$type<NodeKind>().notNull(),
    slug: text("slug").notNull(),
    label: text("label").notNull(),
    subject: text("subject"),
    description: text("description"),
    activation: real("activation").notNull().default(0.5), // decays; reactivates when touched
    touchCount: integer("touch_count").notNull().default(0),
    active: boolean("active").notNull().default(true),
    meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastTouchedAt: timestamp("last_touched_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("nodes_scope_slug_idx").on(t.learnerId, t.kind, t.slug), index("nodes_learner_idx").on(t.learnerId)]
);

export type EdgeRelation =
  | "prerequisite_of" // a is prerequisite of b (subject knowledge)
  | "part_of" // concept part of subject
  | "related_to" // co-occurrence in learner interaction
  | "confused_with" // learner tends to confuse a with b
  | "helped_by" // concept a understood after strategy/concept b
  | "struggles_in" // learner struggles with concept in a context
  | "leads_to"; // learner tends to move from a to b (navigation pattern)

export type EdgeHistoryEntry = { at: string; weight: number; delta: number; note?: string };

export const edges = pgTable(
  "edges",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull().default("__shared__"), // "__shared__" => shared
    fromId: text("from_id").notNull(),
    toId: text("to_id").notNull(),
    relation: text("relation").$type<EdgeRelation>().notNull(),
    weight: real("weight").notNull().default(0.5),
    evidenceCount: integer("evidence_count").notNull().default(1),
    active: boolean("active").notNull().default(true),
    history: jsonb("history").$type<EdgeHistoryEntry[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastReinforcedAt: timestamp("last_reinforced_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("edges_unique_idx").on(t.learnerId, t.fromId, t.toId, t.relation),
    index("edges_from_idx").on(t.fromId),
    index("edges_to_idx").on(t.toId),
  ]
);

// ---------- Long-term memory: beliefs (consolidated, evidence-backed priors) ----------

export type BeliefKind =
  | "mastery" // p(learner knows concept)
  | "strategy_effect" // strategy S works in context C
  | "preference" // stable stated/observed preference
  | "tendency" // recurring behavioural pattern (e.g. "syntax slips despite conceptual understanding")
  | "goal"
  | "misconception";

export type BeliefStatus = "active" | "dormant" | "retracted";
export type BeliefHistoryEntry = {
  at: string;
  confidence: number;
  support: number;
  contradictions: number;
  status: BeliefStatus;
  note?: string;
};

export const beliefs = pgTable(
  "beliefs",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    kind: text("kind").$type<BeliefKind>().notNull(),
    key: text("key").notNull(), // stable key e.g. "mastery:bash:pipes" or "strategy:programming:example_first"
    statement: text("statement").notNull(), // human readable
    subject: text("subject"), // context in which this belief holds (null => global)
    concept: text("concept"),
    confidence: real("confidence").notNull().default(0.5), // 0..1 strength of belief
    support: integer("support").notNull().default(0),
    contradictions: integer("contradictions").notNull().default(0),
    sessionsSeen: integer("sessions_seen").notNull().default(0),
    status: text("status").$type<BeliefStatus>().notNull().default("active"),
    evidenceIds: jsonb("evidence_ids").$type<string[]>().notNull().default([]),
    history: jsonb("history").$type<BeliefHistoryEntry[]>().notNull().default([]),
    data: jsonb("data").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    lastEvidenceAt: timestamp("last_evidence_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("beliefs_learner_key_idx").on(t.learnerId, t.key), index("beliefs_learner_idx").on(t.learnerId)]
);

// ---------- Subject knowledge (researched / discovered domain models) ----------

export type SubjectConcept = { slug: string; label: string; description?: string; prerequisites?: string[]; level?: number };

export const subjects = pgTable("subjects", {
  slug: text("slug").primaryKey(),
  name: text("name").notNull(),
  summary: text("summary"),
  concepts: jsonb("concepts").$type<SubjectConcept[]>().notNull().default([]),
  sources: jsonb("sources").$type<{ title: string; url?: string }[]>().notNull().default([]),
  origin: text("origin").notNull().default("llm"), // llm | web | heuristic | user
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// ---------- Consolidation log ----------

export const consolidations = pgTable("consolidations", {
  id: text("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  observationsProcessed: integer("observations_processed").notNull().default(0),
  beliefsCreated: integer("beliefs_created").notNull().default(0),
  beliefsUpdated: integer("beliefs_updated").notNull().default(0),
  beliefsDormant: integer("beliefs_dormant").notNull().default(0),
  notes: jsonb("notes").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ---------- Evaluation runs (lab results, visible in the UI) ----------

export const evalRuns = pgTable("eval_runs", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  summary: jsonb("summary").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
