"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Markdown } from "./Markdown";
import { ConceptGraph, masteryColor, type GraphConcept } from "./ConceptGraph";

type Turn = { id: number; role: string; kind: string; conceptId: number | null; content: Record<string, unknown>; createdAt: string };
type Snapshot = {
  goal: { id: number; rawText: string; subject: string; status: string; interpretation: { level: string; focus: string[]; notes: string } | null };
  domain: { title: string; origin: string; description: string; researchLog: Array<{ at: string; step: string; source: string; detail: string }> } | null;
  concepts: Array<GraphConcept & { slug: string; summary: string; difficulty: number; directEvidence: number; inferredEvidence: number; provenance: { source: string; ref?: string; reason?: string }; sources: string[]; exerciseCount: number }>;
  session: { id: number; phase: string; currentConceptId: number | null; strategy: string | null } | null;
  affect: { frustration: number; confusion: number; engagement: number; fatigue: number; confidence: number; label: string } | null;
  decisions: Array<{ id: number; kind: string; rationale: string; outcome: Record<string, unknown> | null; createdAt: string }>;
  evidence: Array<{ id: number; kind: string; correct: boolean | null; conceptId: number | null; pBefore: number | null; pAfter: number | null; createdAt: string; strategy: string | null }>;
  strategies: Array<{ scope: string; strategy: string; label: string; mean: number; pulls: number; successes: number }>;
  traits: Array<{ key: string; value: unknown; confidence: number; evidenceCount: number; rationale: string }>;
};

const FEEDBACK: Array<{ value: string; label: string; title: string }> = [
  { value: "got_it", label: "👍 Got it", title: "That explanation worked" },
  { value: "confused", label: "😕 Confused", title: "Explain it differently" },
  { value: "too_easy", label: "⏩ Too easy", title: "Skip ahead" },
  { value: "too_slow", label: "🏃 Faster", title: "Shorter explanations" },
  { value: "frustrated", label: "😫 Frustrated", title: "Step back" },
  { value: "tired", label: "😴 Tired", title: "Suggest a break" },
];

export function GoalWorkspace({ goalId }: { goalId: number }) {
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [answer, setAnswer] = useState("");
  const [tab, setTab] = useState<"graph" | "mastery" | "agent" | "model" | "research">("graph");
  const [selected, setSelected] = useState<number | null>(null);
  const issuedAt = useRef<number>(Date.now());
  const bottom = useRef<HTMLDivElement>(null);
  const started = useRef(false);

  const act = useCallback(
    async (action: Record<string, unknown>) => {
      setBusy(true);
      setError(null);
      try {
        const res = await fetch(`/api/goals/${goalId}/turn`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(action) });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "request failed");
        setTurns((t) => [...t, ...(data.turns as Turn[])]);
        setSnap(data.snapshot as Snapshot);
        if ((data.turns as Turn[]).some((t) => t.kind === "exercise")) issuedAt.current = Date.now();
        setAnswer("");
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e));
      } finally {
        setBusy(false);
      }
    },
    [goalId],
  );

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    (async () => {
      const [s, t] = await Promise.all([fetch(`/api/goals/${goalId}`).then((r) => r.json()), fetch(`/api/goals/${goalId}/turns`).then((r) => r.json())]);
      setSnap(s);
      setTurns(t.turns ?? []);
      const ended = Boolean((s as Snapshot & { session: { endedAt?: string | null } | null }).session?.endedAt);
      if (ended || !(t.turns ?? []).length || !(t.turns as Turn[]).some((x) => x.kind === "exercise" && x.role === "agent")) {
        if (ended) setTurns([]);
        await act({ type: "start" });
      } else issuedAt.current = Date.now();
    })();
  }, [goalId, act]);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth" });
  }, [turns.length, busy]);

  const pendingExercise = [...turns].reverse().find((t) => t.kind === "exercise" && t.role === "agent");
  const answeredIds = new Set(turns.filter((t) => t.kind === "feedback" || (t.role === "learner" && t.kind === "answer")).map((t) => t.content.exerciseId as string));
  const lastAnswered = [...turns].reverse().find((t) => t.kind === "feedback");
  const exerciseOpen = pendingExercise && (!lastAnswered || lastAnswered.id < pendingExercise.id);

  const submitAnswer = (value: string) => {
    if (!value.trim()) return;
    act({ type: "answer", answer: value, latencyMs: Date.now() - issuedAt.current });
  };

  const current = snap?.concepts.find((c) => c.id === (selected ?? snap?.session?.currentConceptId));
  const relevant = snap?.concepts.filter((c) => c.relevant) ?? [];
  const mastered = relevant.filter((c) => c.mastered).length;

  return (
    <div className="grid min-h-screen grid-cols-1 gap-0 bg-slate-50 lg:grid-cols-[minmax(0,1fr)_440px]">
      {/* Conversation */}
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-10 border-b border-slate-200 bg-white/90 px-6 py-3 backdrop-blur">
          <div className="flex items-center justify-between gap-4">
            <div className="min-w-0">
              <Link href="/" className="text-xs text-slate-500 hover:text-slate-800">← Goals</Link>
              <h1 className="truncate text-lg font-semibold text-slate-900">{snap?.domain?.title ?? snap?.goal.subject ?? "…"}</h1>
              <p className="truncate text-xs text-slate-500">“{snap?.goal.rawText}” · {snap?.goal.status}{snap?.session ? ` · phase: ${snap.session.phase}` : ""}</p>
            </div>
            <div className="flex shrink-0 items-center gap-3 text-xs">
              <div className="text-right">
                <div className="font-medium text-slate-800">{mastered}/{relevant.length} mastered</div>
                <div className="h-1.5 w-32 overflow-hidden rounded bg-slate-200"><div className="h-full bg-emerald-500" style={{ width: `${relevant.length ? (mastered / relevant.length) * 100 : 0}%` }} /></div>
              </div>
              {snap?.affect && <span className="rounded-full border border-slate-200 bg-white px-2 py-1 text-slate-600" title={`frustration ${(snap.affect.frustration * 100).toFixed(0)}% · confusion ${(snap.affect.confusion * 100).toFixed(0)}% · engagement ${(snap.affect.engagement * 100).toFixed(0)}% · fatigue ${(snap.affect.fatigue * 100).toFixed(0)}%`}>{snap.affect.label}</span>}
            </div>
          </div>
        </header>

        <div className="flex-1 space-y-3 px-4 py-4 sm:px-6">
          {turns.map((t) => (
            <TurnView key={t.id} turn={t} answered={answeredIds.has(t.content.exerciseId as string) || (t.kind === "exercise" && !(exerciseOpen && pendingExercise?.id === t.id))} onAnswer={submitAnswer} onAction={act} busy={busy} answer={answer} setAnswer={setAnswer} isOpen={Boolean(exerciseOpen && pendingExercise?.id === t.id)} />
          ))}
          {busy && <div className="flex items-center gap-2 text-sm text-slate-500"><span className="inline-block h-2 w-2 animate-pulse rounded-full bg-indigo-500" /> agent is thinking…</div>}
          {error && <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</div>}
          <div ref={bottom} />
        </div>

        <div className="sticky bottom-0 border-t border-slate-200 bg-white px-4 py-3 sm:px-6">
          <div className="mb-2 flex flex-wrap gap-1.5">
            {FEEDBACK.map((f) => (
              <button key={f.value} title={f.title} disabled={busy} onClick={() => act({ type: "feedback", value: f.value })} className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs text-slate-700 hover:bg-slate-100 disabled:opacity-50">{f.label}</button>
            ))}
            {exerciseOpen && <button disabled={busy} onClick={() => act({ type: "hint" })} className="rounded-full border border-amber-200 bg-amber-50 px-2.5 py-1 text-xs text-amber-800 hover:bg-amber-100 disabled:opacity-50">💡 Hint</button>}
            <button disabled={busy} onClick={() => act({ type: "next" })} className="rounded-full border border-indigo-200 bg-indigo-50 px-2.5 py-1 text-xs text-indigo-800 hover:bg-indigo-100 disabled:opacity-50">Next →</button>
          </div>
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (!text.trim()) return;
              act({ type: "message", text });
              setText("");
            }}
          >
            <input value={text} onChange={(e) => setText(e.target.value)} placeholder='Ask anything ("what is word splitting?"), or say "I already know variables"…' className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
            <button disabled={busy || !text.trim()} className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-40">Send</button>
          </form>
        </div>
      </div>

      {/* Inspector */}
      <aside className="border-l border-slate-200 bg-white lg:sticky lg:top-0 lg:h-screen lg:overflow-y-auto">
        <div className="flex border-b border-slate-200 text-xs">
          {(["graph", "mastery", "agent", "model", "research"] as const).map((k) => (
            <button key={k} onClick={() => setTab(k)} className={`flex-1 px-2 py-2.5 capitalize ${tab === k ? "border-b-2 border-indigo-500 font-medium text-indigo-700" : "text-slate-500 hover:text-slate-800"}`}>{k === "agent" ? "Agent log" : k === "model" ? "Learner" : k}</button>
          ))}
        </div>
        <div className="p-4 text-sm">
          {!snap && <p className="text-slate-500">Loading…</p>}
          {snap && tab === "graph" && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500">Prerequisites flow left → right. Bar = mastery estimate (faded = uncertain). Dashed = discovered after a gap was detected. Click a node.</p>
              <ConceptGraph concepts={snap.concepts} currentId={snap.session?.currentConceptId ?? null} onSelect={setSelected} />
              {current && (
                <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                  <div className="flex items-center justify-between"><h3 className="font-semibold text-slate-900">{current.title}</h3><span className="text-xs text-slate-500">{current.role}</span></div>
                  <p className="mt-1 text-xs text-slate-600">{current.summary}</p>
                  <MasteryBar c={current} />
                  <p className="mt-2 text-[11px] text-slate-500">Source: {current.provenance.source}{current.provenance.reason ? ` — ${current.provenance.reason}` : ""}{current.sources[0] ? ` · ${current.sources[0]}` : ""} · {current.exerciseCount} exercises · difficulty {(current.difficulty * 100).toFixed(0)}</p>
                </div>
              )}
            </div>
          )}
          {snap && tab === "mastery" && (
            <div className="space-y-2">
              {snap.concepts.filter((c) => c.relevant).map((c) => (
                <div key={c.id} className="rounded-lg border border-slate-200 p-2.5">
                  <div className="flex items-center justify-between text-sm"><span className={`font-medium ${c.id === snap.session?.currentConceptId ? "text-indigo-700" : "text-slate-800"}`}>{c.title}</span>{c.mastered && <span className="text-xs text-emerald-600">mastered</span>}</div>
                  <MasteryBar c={c} />
                </div>
              ))}
            </div>
          )}
          {snap && tab === "agent" && (
            <div className="space-y-2">
              <p className="text-xs text-slate-500">Every planning decision, with rationale. Verified adaptations show their outcome.</p>
              {snap.decisions.map((d) => (
                <div key={d.id} className="rounded-lg border border-slate-200 p-2.5">
                  <div className="flex items-center justify-between text-[11px] text-slate-500"><span className="rounded bg-slate-100 px-1.5 py-0.5 font-mono">{d.kind}</span><span>{new Date(d.createdAt).toLocaleTimeString()}</span></div>
                  <p className="mt-1 text-xs text-slate-700">{d.rationale}</p>
                  {d.outcome && <p className={`mt-1 text-[11px] font-medium ${d.outcome.worked ? "text-emerald-700" : "text-rose-700"}`}>outcome: {d.outcome.worked ? "worked" : "did not work"}</p>}
                </div>
              ))}
            </div>
          )}
          {snap && tab === "model" && (
            <div className="space-y-4">
              {snap.affect && (
                <section>
                  <h3 className="mb-1 font-semibold text-slate-900">Affect <span className="text-xs font-normal text-slate-500">({snap.affect.label})</span></h3>
                  {(["frustration", "confusion", "engagement", "fatigue", "confidence"] as const).map((k) => (
                    <div key={k} className="flex items-center gap-2 text-xs"><span className="w-20 text-slate-600">{k}</span><div className="h-1.5 flex-1 rounded bg-slate-200"><div className="h-full rounded bg-indigo-500" style={{ width: `${snap.affect![k] * 100}%` }} /></div><span className="w-8 text-right text-slate-500">{(snap.affect![k] * 100).toFixed(0)}</span></div>
                  ))}
                </section>
              )}
              <section>
                <h3 className="mb-1 font-semibold text-slate-900">Strategy effectiveness</h3>
                <p className="mb-1 text-[11px] text-slate-500">Posterior success rate per explanation style (Thompson sampling). Learned from your follow-up answers and feedback.</p>
                {snap.strategies.filter((s) => s.scope === "global").sort((a, b) => b.mean - a.mean).map((s) => (
                  <div key={s.strategy} className="flex items-center gap-2 text-xs"><span className="w-28 text-slate-600">{s.label}</span><div className="h-1.5 flex-1 rounded bg-slate-200"><div className="h-full rounded" style={{ width: `${s.mean * 100}%`, background: masteryColor(s.mean) }} /></div><span className="w-16 text-right text-slate-500">{(s.mean * 100).toFixed(0)}% · n={s.pulls}</span></div>
                ))}
              </section>
              <section>
                <h3 className="mb-1 font-semibold text-slate-900">Traits</h3>
                {snap.traits.length === 0 && <p className="text-xs text-slate-500">Nothing inferred yet — traits appear as evidence accumulates.</p>}
                {snap.traits.map((t) => (
                  <div key={t.key} className="mb-1.5 rounded border border-slate-200 p-2 text-xs"><div className="flex justify-between"><span className="font-mono text-slate-800">{t.key}</span><span className="text-slate-500">conf {(t.confidence * 100).toFixed(0)}% · n={t.evidenceCount}</span></div><div className="text-slate-700">{typeof t.value === "object" ? JSON.stringify(t.value) : String(t.value)}</div><div className="text-[11px] text-slate-500">{t.rationale}</div></div>
                ))}
              </section>
              <section>
                <h3 className="mb-1 font-semibold text-slate-900">Recent evidence</h3>
                {snap.evidence.slice(0, 15).map((e) => (
                  <div key={e.id} className="flex items-center justify-between border-b border-slate-100 py-1 text-[11px]"><span className="text-slate-700">{e.kind} · {snap.concepts.find((c) => c.id === e.conceptId)?.title ?? "—"}</span><span className={e.correct === null ? "text-slate-400" : e.correct ? "text-emerald-600" : "text-rose-600"}>{e.pBefore != null && e.pAfter != null ? `${(e.pBefore * 100).toFixed(0)}→${(e.pAfter * 100).toFixed(0)}%` : ""}</span></div>
                ))}
              </section>
              <Link href="/learner" className="block text-xs text-indigo-700 hover:underline">Open full learner model →</Link>
            </div>
          )}
          {snap && tab === "research" && (
            <div className="space-y-2">
              <p className="text-xs text-slate-500">How the agent built this domain model (origin: <b>{snap.domain?.origin}</b>). {snap.goal.interpretation?.notes}</p>
              {(snap.domain?.researchLog ?? []).map((r, i) => (
                <div key={i} className="rounded-lg border border-slate-200 p-2 text-xs"><div className="flex justify-between text-[11px] text-slate-500"><span className="font-mono">{r.step} · {r.source}</span><span>{new Date(r.at).toLocaleTimeString()}</span></div><p className="text-slate-700">{r.detail}</p></div>
              ))}
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}

function MasteryBar({ c }: { c: GraphConcept & { directEvidence: number; inferredEvidence: number } }) {
  return (
    <div className="mt-1.5">
      <div className="h-2 w-full overflow-hidden rounded bg-slate-200"><div className="h-full rounded" style={{ width: `${c.pKnown * 100}%`, background: masteryColor(c.pKnown), opacity: 1 - c.uncertainty * 0.6 }} /></div>
      <div className="mt-0.5 flex justify-between text-[11px] text-slate-500"><span>{(c.pKnown * 100).toFixed(0)}% known · ±{(c.uncertainty * 100).toFixed(0)} uncertainty</span><span>{c.basis} · {c.directEvidence} direct / {c.inferredEvidence} inferred</span></div>
    </div>
  );
}

function TurnView({ turn, answered, onAnswer, onAction, busy, answer, setAnswer, isOpen }: { turn: Turn; answered: boolean; onAnswer: (v: string) => void; onAction: (a: Record<string, unknown>) => void; busy: boolean; answer: string; setAnswer: (v: string) => void; isOpen: boolean }) {
  const c = turn.content;
  if (turn.role === "learner") {
    const label = turn.kind === "answer" ? String(c.answer) : turn.kind === "feedback" ? `feedback: ${String(c.value).replace("_", " ")}` : turn.kind === "hint" ? "asked for a hint" : String(c.text);
    return <div className="flex justify-end"><div className="max-w-[80%] rounded-2xl rounded-br-sm bg-indigo-600 px-4 py-2 text-sm text-white">{label}</div></div>;
  }
  if (turn.role === "system") {
    return <div className="flex items-start gap-2 pl-1 text-xs text-slate-500"><span className="mt-0.5 rounded bg-slate-200 px-1 font-mono text-[10px] text-slate-600">{String(c.kind ?? "agent")}</span><span className="italic">{String(c.text)}</span></div>;
  }
  if (turn.kind === "lesson") {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <div className="mb-2 flex flex-wrap items-center gap-2"><span className="text-xs font-semibold uppercase tracking-wide text-indigo-600">Lesson</span><h3 className="text-base font-semibold text-slate-900">{String(c.title)}</h3><span className="rounded-full bg-indigo-50 px-2 py-0.5 text-[11px] text-indigo-700">{String(c.strategyLabel)}</span></div>
        <Markdown text={String(c.text)} />
        {Array.isArray(c.keyPoints) && (c.keyPoints as string[]).length > 0 && (
          <div className="mt-3 rounded-lg bg-slate-50 p-3 text-sm"><div className="mb-1 text-xs font-semibold text-slate-500">Key points</div><ul className="list-disc space-y-0.5 pl-5 text-slate-700">{(c.keyPoints as string[]).map((k, i) => <li key={i}><Markdown text={k} className="inline text-sm" /></li>)}</ul></div>
        )}
        <div className="mt-3 flex gap-1.5 text-xs">
          <button disabled={busy} onClick={() => onAction({ type: "feedback", value: "helpful" })} className="rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-emerald-800 disabled:opacity-50">This helped</button>
          <button disabled={busy} onClick={() => onAction({ type: "feedback", value: "not_helpful" })} className="rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-slate-700 disabled:opacity-50">Explain differently</button>
        </div>
      </div>
    );
  }
  if (turn.kind === "exercise") {
    const options = c.options as string[] | null;
    return (
      <div className={`rounded-2xl border p-4 shadow-sm ${isOpen ? "border-indigo-300 bg-indigo-50/40" : "border-slate-200 bg-white"}`}>
        <div className="mb-2 flex flex-wrap items-center gap-2"><span className="text-xs font-semibold uppercase tracking-wide text-amber-600">{String(c.purpose)}</span><span className="text-sm font-medium text-slate-800">{String(c.conceptTitle)}</span>{c.note ? <span className="text-xs text-slate-500">· {String(c.note)}</span> : null}</div>
        <Markdown text={String(c.prompt)} />
        {c.code ? <pre className="my-2 overflow-x-auto rounded-lg bg-slate-900 p-3 text-[13px] text-slate-100"><code>{String(c.code)}</code></pre> : null}
        {isOpen && !answered && (
          options ? (
            <div className="mt-3 grid gap-2">{options.map((o, i) => <button key={i} disabled={busy} onClick={() => onAnswer(String(i))} className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-left text-sm hover:border-indigo-400 hover:bg-indigo-50 disabled:opacity-50"><span className="mr-2 font-mono text-xs text-slate-400">{String.fromCharCode(65 + i)}</span><span className="whitespace-pre-wrap font-mono text-[13px]">{o}</span></button>)}</div>
          ) : (
            <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); onAnswer(answer); }}>
              <input autoFocus value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder="Your answer…" className="flex-1 rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm outline-none focus:border-indigo-400" />
              <button disabled={busy || !answer.trim()} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-40">Check</button>
            </form>
          )
        )}
      </div>
    );
  }
  if (turn.kind === "feedback") {
    const ok = Boolean(c.correct);
    return (
      <div className={`rounded-2xl border p-4 ${ok ? "border-emerald-200 bg-emerald-50" : "border-rose-200 bg-rose-50"}`}>
        <div className={`mb-1 text-xs font-semibold uppercase tracking-wide ${ok ? "text-emerald-700" : "text-rose-700"}`}>{ok ? "Correct" : "Not quite"}</div>
        <Markdown text={String(c.text)} />
        {typeof c.pBefore === "number" && typeof c.pAfter === "number" && (
          <div className="mt-2 flex items-center gap-2 text-[11px] text-slate-600"><span>belief</span><div className="relative h-1.5 w-40 rounded bg-slate-200"><div className="absolute h-full rounded bg-slate-400" style={{ width: `${(c.pBefore as number) * 100}%` }} /><div className="absolute h-full rounded" style={{ width: `${(c.pAfter as number) * 100}%`, background: masteryColor(c.pAfter as number), opacity: 0.85 }} /></div><span>{((c.pBefore as number) * 100).toFixed(0)}% → {((c.pAfter as number) * 100).toFixed(0)}%</span></div>
        )}
      </div>
    );
  }
  const actions = (c.actions as string[] | undefined) ?? [];
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <Markdown text={String(c.text)} />
      {actions.includes("skip_diagnostic") && (
        <div className="mt-3 flex flex-wrap gap-2 text-xs">
          <button disabled={busy} onClick={() => onAction({ type: "skip_diagnostic", level: "beginner" })} className="rounded-full border border-slate-300 bg-white px-3 py-1.5 text-slate-700 hover:bg-slate-50 disabled:opacity-50">I&apos;m a complete beginner — skip</button>
          <button disabled={busy} onClick={() => onAction({ type: "skip_diagnostic", level: "knows_basics" })} className="rounded-full border border-slate-300 bg-white px-3 py-1.5 text-slate-700 hover:bg-slate-50 disabled:opacity-50">I know the basics — skip</button>
        </div>
      )}
      {actions.includes("take_break") && <button disabled={busy} onClick={() => onAction({ type: "take_break" })} className="mt-3 rounded-full border border-slate-300 bg-white px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 disabled:opacity-50">Take a break (save & pause)</button>}
    </div>
  );
}
