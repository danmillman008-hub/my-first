"use client";
import { useMemo } from "react";

export type GraphConcept = { id: number; title: string; role: string; pKnown: number; uncertainty: number; mastered: boolean; relevant: boolean; target: boolean; prereqIds: number[]; basis: string };

export function masteryColor(p: number) {
  // red -> amber -> green
  const h = Math.round(p * 120);
  return `hsl(${h} 70% 45%)`;
}

export function ConceptGraph({ concepts, currentId, onSelect }: { concepts: GraphConcept[]; currentId: number | null; onSelect?: (id: number) => void }) {
  const layout = useMemo(() => {
    const byId = new Map(concepts.map((c) => [c.id, c]));
    const depth = new Map<number, number>();
    const visiting = new Set<number>();
    const d = (id: number): number => {
      if (depth.has(id)) return depth.get(id)!;
      if (visiting.has(id)) return 0;
      visiting.add(id);
      const c = byId.get(id);
      const val = c && c.prereqIds.length ? 1 + Math.max(...c.prereqIds.filter((p) => byId.has(p)).map(d), -1) : 0;
      depth.set(id, Math.max(0, val));
      visiting.delete(id);
      return depth.get(id)!;
    };
    concepts.forEach((c) => d(c.id));
    const layers = new Map<number, number[]>();
    for (const c of concepts) {
      const l = depth.get(c.id) ?? 0;
      if (!layers.has(l)) layers.set(l, []);
      layers.get(l)!.push(c.id);
    }
    const colW = 190;
    const rowH = 58;
    const pos = new Map<number, { x: number; y: number }>();
    let maxRows = 1;
    for (const [l, ids] of layers) {
      maxRows = Math.max(maxRows, ids.length);
      ids.forEach((id, i) => pos.set(id, { x: 20 + l * colW, y: 20 + i * rowH }));
    }
    const width = 20 + layers.size * colW + 20;
    const height = 20 + maxRows * rowH + 10;
    return { pos, width, height };
  }, [concepts]);

  return (
    <div className="overflow-x-auto">
      <svg width={layout.width} height={layout.height} className="block">
        <defs>
          <marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">
            <path d="M0,0 L8,4 L0,8 z" fill="#94a3b8" />
          </marker>
        </defs>
        {concepts.flatMap((c) =>
          c.prereqIds
            .filter((p) => layout.pos.has(p))
            .map((p) => {
              const a = layout.pos.get(p)!;
              const b = layout.pos.get(c.id)!;
              return <line key={`${p}-${c.id}`} x1={a.x + 150} y1={a.y + 18} x2={b.x} y2={b.y + 18} stroke="#cbd5e1" strokeWidth={1.5} markerEnd="url(#arrow)" />;
            }),
        )}
        {concepts.map((c) => {
          const p = layout.pos.get(c.id)!;
          const isCurrent = c.id === currentId;
          return (
            <g key={c.id} transform={`translate(${p.x},${p.y})`} className="cursor-pointer" onClick={() => onSelect?.(c.id)}>
              <rect width={150} height={36} rx={8} fill="white" stroke={isCurrent ? "#4f46e5" : c.role === "discovered" ? "#f59e0b" : "#e2e8f0"} strokeWidth={isCurrent ? 2.5 : 1.5} strokeDasharray={c.role === "discovered" ? "4 3" : undefined} opacity={c.relevant ? 1 : 0.5} />
              <rect x={4} y={28} width={142 * c.pKnown} height={4} rx={2} fill={masteryColor(c.pKnown)} opacity={1 - c.uncertainty * 0.6} />
              <text x={8} y={18} fontSize={11} fill="#0f172a" fontWeight={c.target ? 600 : 400}>
                {c.title.length > 24 ? c.title.slice(0, 23) + "…" : c.title}
              </text>
              {c.mastered && <text x={138} y={17} fontSize={11} fill="#16a34a">✓</text>}
            </g>
          );
        })}
      </svg>
    </div>
  );
}
