"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

const EXAMPLES = ["I want to learn Bash", "Teach me Object-Oriented Programming", "I want to learn SQL, I'm a complete beginner", "I want to understand recursion", "Teach me about Git, especially branching and merging"];

export function GoalForm() {
  const router = useRouter();
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const submit = async (value: string) => {
    if (!value.trim() || busy) return;
    setBusy(true);
    setError(null);
    setStatus("Interpreting your goal…");
    const timer = setTimeout(() => setStatus("Investigating the subject and building a concept graph… (new subjects take a little longer)"), 1500);
    try {
      const res = await fetch("/api/goals", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ text: value }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "failed");
      setStatus(`Built ${data.build.conceptCount} concepts (${data.build.origin}). Opening…`);
      router.push(`/goals/${data.goal.id}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      setBusy(false);
      setStatus(null);
    } finally {
      clearTimeout(timer);
    }
  };

  return (
    <div>
      <form className="flex flex-col gap-2 sm:flex-row" onSubmit={(e) => { e.preventDefault(); submit(text); }}>
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="I want to learn…" className="flex-1 rounded-xl border border-slate-300 bg-white px-4 py-3 text-base outline-none focus:border-indigo-400" disabled={busy} />
        <button disabled={busy || !text.trim()} className="rounded-xl bg-indigo-600 px-5 py-3 font-medium text-white disabled:opacity-40">{busy ? "Working…" : "Start learning"}</button>
      </form>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {EXAMPLES.map((ex) => <button key={ex} disabled={busy} onClick={() => { setText(ex); submit(ex); }} className="rounded-full border border-slate-200 bg-white px-2.5 py-1 text-xs text-slate-600 hover:border-indigo-300 hover:text-indigo-700 disabled:opacity-50">{ex}</button>)}
      </div>
      {status && <p className="mt-3 flex items-center gap-2 text-sm text-slate-600"><span className="inline-block h-2 w-2 animate-pulse rounded-full bg-indigo-500" />{status}</p>}
      {error && <p className="mt-3 text-sm text-rose-700">{error}</p>}
    </div>
  );
}
