"use client";
import { Fragment, type ReactNode } from "react";

/** Minimal markdown renderer: fenced code, inline code, bold, italics, lists, paragraphs. */
function inline(text: string, key: number): ReactNode {
  const parts: ReactNode[] = [];
  const re = /(`[^`]+`|\*\*[^*]+\*\*|_[^_]+_)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    const tok = m[0];
    if (tok.startsWith("`")) parts.push(<code key={`${key}-${i++}`} className="rounded bg-slate-100 px-1 py-0.5 font-mono text-[0.9em] text-rose-700">{tok.slice(1, -1)}</code>);
    else if (tok.startsWith("**")) parts.push(<strong key={`${key}-${i++}`} className="font-semibold text-slate-900">{tok.slice(2, -2)}</strong>);
    else parts.push(<em key={`${key}-${i++}`} className="text-slate-600">{tok.slice(1, -1)}</em>);
    last = m.index + tok.length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return <Fragment key={key}>{parts}</Fragment>;
}

export function Markdown({ text, className = "" }: { text: string; className?: string }) {
  const blocks: ReactNode[] = [];
  const lines = text.split("\n");
  let i = 0;
  let k = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (line.startsWith("```")) {
      const buf: string[] = [];
      i++;
      while (i < lines.length && !lines[i].startsWith("```")) buf.push(lines[i++]);
      i++;
      blocks.push(<pre key={k++} className="my-2 overflow-x-auto rounded-lg bg-slate-900 p-3 text-[13px] leading-relaxed text-slate-100"><code>{buf.join("\n")}</code></pre>);
      continue;
    }
    if (/^\s*[-*] /.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*[-*] /.test(lines[i])) items.push(lines[i++].replace(/^\s*[-*] /, ""));
      blocks.push(<ul key={k++} className="my-2 list-disc space-y-1 pl-5">{items.map((it, j) => <li key={j}>{inline(it, j)}</li>)}</ul>);
      continue;
    }
    if (/^\s*\d+\. /.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*\d+\. /.test(lines[i])) items.push(lines[i++].replace(/^\s*\d+\. /, ""));
      blocks.push(<ol key={k++} className="my-2 list-decimal space-y-1 pl-5">{items.map((it, j) => <li key={j}>{inline(it, j)}</li>)}</ol>);
      continue;
    }
    if (line.trim() === "") {
      i++;
      continue;
    }
    const buf: string[] = [];
    while (i < lines.length && lines[i].trim() !== "" && !lines[i].startsWith("```") && !/^\s*[-*] /.test(lines[i]) && !/^\s*\d+\. /.test(lines[i])) buf.push(lines[i++]);
    blocks.push(<p key={k++} className="my-1.5 whitespace-pre-wrap">{inline(buf.join("\n"), k)}</p>);
  }
  return <div className={`text-[15px] leading-relaxed text-slate-800 ${className}`}>{blocks}</div>;
}
