/**
 * Read-side of the persistent learner model: inspectable snapshots for the UI
 * and for external assistants via MCP.
 */
import { and, desc, eq, inArray } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import { affectStates, agentDecisions, concepts, domains, evidenceEvents, goals, learners, masteryBeliefs, prerequisites, sessions, strategyStats, turns, learnerTraits } from "@/db/schema";
import { describeAffect, latestAffect } from "./affect";
import { ensureBeliefs, isMastered, uncertainty } from "./mastery";
import { loadGraph } from "./tutor";
import { STRATEGY_LABELS } from "./strategy";
import type { StrategyId } from "@/db/schema";

const COOKIE = "pal_learner";

export async function ensureLearner(publicId?: string | null) {
  if (publicId) {
    const [row] = await db.select().from(learners).where(eq(learners.publicId, publicId)).limit(1);
    if (row) return row;
  }
  const [created] = await db.insert(learners).values({ publicId: publicId ?? crypto.randomUUID() }).returning();
  return created;
}

/** Learner identity from cookie (created on first use). */
export async function currentLearner() {
  const jar = await cookies();
  const pid = jar.get(COOKIE)?.value ?? null;
  const learner = await ensureLearner(pid);
  if (pid !== learner.publicId) {
    try {
      jar.set(COOKIE, learner.publicId, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
    } catch {
      /* read-only cookies in server components; the API routes will set it */
    }
  }
  return learner;
}

export async function getGoalSnapshot(goalId: number) {
  const [goal] = await db.select().from(goals).where(eq(goals.id, goalId)).limit(1);
  if (!goal) return null;
  const domain = goal.domainId ? (await db.select().from(domains).where(eq(domains.id, goal.domainId)).limit(1))[0] : null;
  if (!domain) return { goal, domain: null, concepts: [], edges: [], session: null, affect: null, decisions: [], evidence: [], strategies: [], traits: [] };
  const graph = await loadGraph(goal);
  const allIds = [...graph.conceptMap.keys()];
  const beliefs = await ensureBeliefs(goal.learnerId, allIds);
  const relevant = new Set(graph.order);
  const conceptsOut = allIds
    .map((id) => {
      const c = graph.conceptMap.get(id)!;
      const b = beliefs.get(id)!;
      return {
        id,
        slug: c.slug,
        title: c.title,
        summary: c.summary,
        role: c.role,
        difficulty: c.difficulty,
        tags: c.tags,
        provenance: c.provenance,
        sources: c.material.sources ?? [],
        exerciseCount: c.material.exercises?.length ?? 0,
        pKnown: b.pKnown,
        uncertainty: uncertainty(b.alpha, b.beta),
        basis: b.basis,
        directEvidence: b.directEvidence,
        inferredEvidence: b.inferredEvidence,
        mastered: isMastered(b),
        relevant: relevant.has(id),
        order: graph.order.indexOf(id),
        target: goal.targetConceptIds.includes(id),
        prereqIds: (graph.prereqOf.get(id) ?? []).map((p) => p.id),
      };
    })
    .sort((a, b) => (a.order === -1 ? 999 : a.order) - (b.order === -1 ? 999 : b.order));
  const [session] = await db.select().from(sessions).where(eq(sessions.goalId, goalId)).orderBy(desc(sessions.startedAt)).limit(1);
  const affect = await latestAffect(goal.learnerId);
  const decisions = await db.select().from(agentDecisions).where(eq(agentDecisions.goalId, goalId)).orderBy(desc(agentDecisions.createdAt)).limit(40);
  const evidence = await db.select().from(evidenceEvents).where(eq(evidenceEvents.goalId, goalId)).orderBy(desc(evidenceEvents.createdAt)).limit(40);
  const strategies = await db.select().from(strategyStats).where(and(eq(strategyStats.learnerId, goal.learnerId), inArray(strategyStats.scope, ["global", `domain:${domain.slug}`])));
  const traits = await db.select().from(learnerTraits).where(eq(learnerTraits.learnerId, goal.learnerId));
  return {
    goal,
    domain: { id: domain.id, slug: domain.slug, title: domain.title, description: domain.description, origin: domain.origin, researchLog: domain.researchLog },
    concepts: conceptsOut,
    edges: graph.edges.map((e) => ({ conceptId: e.conceptId, prerequisiteId: e.prerequisiteId, strength: e.strength, provenance: e.provenance })),
    session: session ?? null,
    affect: { ...affect, label: describeAffect(affect) },
    decisions,
    evidence,
    strategies: strategies.map((s) => ({ scope: s.scope, strategy: s.strategy, label: STRATEGY_LABELS[s.strategy as StrategyId] ?? s.strategy, mean: s.alpha / (s.alpha + s.beta), pulls: s.pulls, successes: s.successes, alpha: s.alpha, beta: s.beta })),
    traits,
  };
}

export async function getSessionTurns(goalId: number) {
  const [session] = await db.select().from(sessions).where(eq(sessions.goalId, goalId)).orderBy(desc(sessions.startedAt)).limit(1);
  if (!session) return [];
  return db.select().from(turns).where(eq(turns.sessionId, session.id)).orderBy(turns.createdAt, turns.id);
}

export async function getLearnerModel(learnerId: number) {
  const [learner] = await db.select().from(learners).where(eq(learners.id, learnerId)).limit(1);
  const goalRows = await db.select().from(goals).where(eq(goals.learnerId, learnerId)).orderBy(desc(goals.createdAt));
  const beliefs = await db.select().from(masteryBeliefs).where(eq(masteryBeliefs.learnerId, learnerId));
  const conceptRows = beliefs.length ? await db.select({ id: concepts.id, title: concepts.title, slug: concepts.slug, domainId: concepts.domainId, role: concepts.role }).from(concepts).where(inArray(concepts.id, beliefs.map((b) => b.conceptId))) : [];
  const domainRows = await db.select({ id: domains.id, title: domains.title, slug: domains.slug, origin: domains.origin }).from(domains);
  const cmap = new Map(conceptRows.map((c) => [c.id, c]));
  const dmap = new Map(domainRows.map((d) => [d.id, d]));
  const traits = await db.select().from(learnerTraits).where(eq(learnerTraits.learnerId, learnerId));
  const strategies = await db.select().from(strategyStats).where(eq(strategyStats.learnerId, learnerId));
  const affectTimeline = await db.select().from(affectStates).where(eq(affectStates.learnerId, learnerId)).orderBy(desc(affectStates.createdAt)).limit(60);
  const evidence = await db.select().from(evidenceEvents).where(eq(evidenceEvents.learnerId, learnerId)).orderBy(desc(evidenceEvents.createdAt)).limit(80);
  const decisions = await db.select().from(agentDecisions).where(eq(agentDecisions.learnerId, learnerId)).orderBy(desc(agentDecisions.createdAt)).limit(80);
  const affect = await latestAffect(learnerId);
  return {
    learner,
    goals: goalRows.map((g) => ({ ...g, domain: g.domainId ? dmap.get(g.domainId) ?? null : null })),
    mastery: beliefs
      .map((b) => ({
        conceptId: b.conceptId,
        title: cmap.get(b.conceptId)?.title ?? "?",
        slug: cmap.get(b.conceptId)?.slug ?? "?",
        domain: dmap.get(cmap.get(b.conceptId)?.domainId ?? -1)?.title ?? "?",
        pKnown: b.pKnown,
        uncertainty: uncertainty(b.alpha, b.beta),
        basis: b.basis,
        directEvidence: b.directEvidence,
        inferredEvidence: b.inferredEvidence,
        mastered: isMastered(b),
        lastEvidenceAt: b.lastEvidenceAt,
      }))
      .sort((a, b) => b.pKnown - a.pKnown),
    traits,
    strategies: strategies.map((s) => ({ scope: s.scope, strategy: s.strategy, label: STRATEGY_LABELS[s.strategy as StrategyId] ?? s.strategy, mean: s.alpha / (s.alpha + s.beta), pulls: s.pulls, successes: s.successes })),
    affect: { ...affect, label: describeAffect(affect) },
    affectTimeline: affectTimeline.reverse(),
    evidence: evidence.map((e) => ({ ...e, conceptTitle: e.conceptId ? cmap.get(e.conceptId)?.title ?? null : null })),
    decisions,
  };
}

export async function getConceptGraph(domainSlug: string) {
  const [domain] = await db.select().from(domains).where(eq(domains.slug, domainSlug)).limit(1);
  if (!domain) return null;
  const cs = await db.select().from(concepts).where(eq(concepts.domainId, domain.id));
  const es = cs.length ? await db.select().from(prerequisites).where(inArray(prerequisites.conceptId, cs.map((c) => c.id))) : [];
  return {
    domain: { id: domain.id, slug: domain.slug, title: domain.title, description: domain.description, origin: domain.origin, researchLog: domain.researchLog },
    concepts: cs.map((c) => ({ id: c.id, slug: c.slug, title: c.title, summary: c.summary, role: c.role, difficulty: c.difficulty, tags: c.tags, provenance: c.provenance, exerciseCount: c.material.exercises?.length ?? 0 })),
    edges: es.map((e) => ({ conceptId: e.conceptId, prerequisiteId: e.prerequisiteId, strength: e.strength, provenance: e.provenance })),
  };
}
