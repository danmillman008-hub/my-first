/**
 * Domain research: turns a subject string into a candidate concept structure by
 * investigating Wikipedia (search -> canonical article -> section structure ->
 * lead-paragraph links as prerequisite candidates -> per-concept summaries).
 *
 * Every step is logged so the research trail is inspectable.
 */
import type { Exercise, ResearchLogEntry, StrategyId } from "@/db/schema";

const UA = "PrivateAdaptiveLearningAgent/1.0 (personal adaptive tutoring research agent; https://github.com/private-learning-agent) node-fetch";
const API = "https://en.wikipedia.org/w/api.php";

export class ResearchUnavailableError extends Error {
  retryAfterSec: number;
  constructor(msg: string, retryAfterSec = 30) {
    super(msg);
    this.name = "ResearchUnavailableError";
    this.retryAfterSec = retryAfterSec;
  }
}

/** Fetch from the MediaWiki API with bounded retry on rate limiting. */
async function wiki<T>(params: Record<string, string>): Promise<T> {
  const url = `${API}?${new URLSearchParams({ format: "json", formatversion: "2", origin: "*", ...params })}`;
  let lastRetry = 30;
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await fetch(url, { headers: { "User-Agent": UA, "Api-User-Agent": UA }, signal: AbortSignal.timeout(15_000) });
    if (res.status === 429 || res.status === 503) {
      lastRetry = Math.min(25, Number(res.headers.get("retry-after") ?? 5) || 5);
      if (attempt < 2) {
        await new Promise((r) => setTimeout(r, Math.min(lastRetry, 8) * 1000));
        continue;
      }
      throw new ResearchUnavailableError(`The research source (Wikipedia) is rate-limiting requests right now. Please try again in about ${lastRetry} seconds.`, lastRetry);
    }
    if (!res.ok) throw new Error(`wikipedia ${res.status}`);
    const ct = res.headers.get("content-type") ?? "";
    if (!ct.includes("json")) throw new ResearchUnavailableError("The research source returned an unexpected response; please retry shortly.", 15);
    return (await res.json()) as T;
  }
  throw new ResearchUnavailableError("Research source unavailable.", lastRetry);
}

/** Learning goals are about disciplines, skills, techniques and bodies of knowledge — not films, songs or minerals. */
const LEARNABLE = /\b(programming|language|software|computing|computer|mathematic|science|scientific|theory|method|technique|discipline|field|study|framework|library|tool|skill|philosoph|histor|branch of|system|engineering|analysis|design|model|concept|practice|paradigm|process|technology|art|craft|cuisine|cooking|music|sport|game theory|statistics|economics|biology|chemistry|physics|law|medicine)\b/i;
const NOT_LEARNABLE_TITLE = /\((film|album|song|band|video game|novel|tv series|series|character|comics|magazine|ep|singer|rapper|actor|footballer|company|brand|horse|ship|river|town|village|city)\)/i;

export function rankHits(hits: Array<{ title: string; snippet: string }>, subject: string, focus: string[] = []) {
  const subj = subject.toLowerCase().trim();
  const tokens = subj.split(/\W+/).filter((t) => t.length > 2);
  const scored = hits.map((h, i) => {
    const title = h.title.toLowerCase();
    const snippet = h.snippet.replace(/<[^>]+>/g, "").toLowerCase();
    let score = 0;
    const bare = title.replace(/\s*\(.*\)$/, "");
    const bareTokens = bare.split(/\W+/).filter(Boolean);
    if (title === subj || bare === subj) score += 3;
    else if (bareTokens.length && bareTokens.every((t) => tokens.includes(t))) score += 4; // "pasta" for "cook pasta": the general article
    else if (tokens.some((t) => title.includes(t))) score += 2;
    score -= Math.max(0, bareTokens.length - 2) * 0.15; // prefer general articles over long specific titles
    if (LEARNABLE.test(h.title) || LEARNABLE.test(snippet)) score += 2;
    for (const f of focus) if (f && snippet.includes(f.toLowerCase())) score += 2;
    if (/may refer to|disambiguation/.test(snippet) || /\(disambiguation\)/i.test(h.title)) score -= 4;
    if (NOT_LEARNABLE_TITLE.test(h.title)) score -= 3;
    if (/^list of /i.test(h.title)) score -= 3;
    score -= i * 0.15; // mild preference for search rank
    return { hit: h, score };
  });
  return scored.sort((a, b) => b.score - a.score);
}

export type ResearchedConcept = {
  slug: string;
  title: string;
  summary: string;
  text: string;
  role: "core" | "prerequisite";
  order: number;
  sourceRef: string;
  mentions: string[]; // titles of other candidates mentioned in text
};

export type ResearchResult = {
  subject: string;
  canonicalTitle: string | null;
  description: string;
  concepts: ResearchedConcept[];
  prerequisitePairs: Array<{ concept: string; prerequisite: string; reason: string }>;
  log: ResearchLogEntry[];
};

export function slugify(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

const BOILERPLATE_SECTIONS = new Set([
  "history",
  "see also",
  "references",
  "external links",
  "notes",
  "bibliography",
  "further reading",
  "sources",
  "citations",
  "footnotes",
  "criticism",
  "reception",
  "legacy",
  "etymology",
  "in popular culture",
  "awards",
  "release history",
  "version history",
  "versions",
  "notable people",
  "gallery",
  "timeline",
  "works cited",
  "explanatory notes",
  "general and cited references",
  "adoption",
  "distribution",
  "ports",
  "availability",
  "naming",
  "name",
  "discovery",
  "refinements",
  "development",
  "origins",
  "early history",
  "modern era",
  "controversies",
  "trivia",
  "in fiction",
  "media",
  "usage",
  "popularity",
]);
const isBoilerplate = (s: { heading: string; parent: string }) => BOILERPLATE_SECTIONS.has(s.heading.toLowerCase()) || (s.parent && BOILERPLATE_SECTIONS.has(s.parent.toLowerCase()));

function log(entries: ResearchLogEntry[], step: string, source: string, detail: string, data?: Record<string, unknown>) {
  entries.push({ at: new Date().toISOString(), step, source, detail, data });
}

export async function searchWikipedia(query: string, limit = 5): Promise<Array<{ title: string; snippet: string; pageid: number }>> {
  const data = await wiki<{ query?: { search?: Array<{ title: string; snippet: string; pageid: number }> } }>({
    action: "query",
    list: "search",
    srsearch: query,
    srlimit: String(limit),
  });
  return data.query?.search ?? [];
}

export async function fetchExtract(title: string): Promise<{ title: string; text: string } | null> {
  const data = await wiki<{ query?: { pages?: Array<{ title: string; extract?: string; missing?: boolean }> } }>({
    action: "query",
    prop: "extracts",
    explaintext: "1",
    redirects: "1",
    titles: title,
  });
  const page = data.query?.pages?.[0];
  if (!page || page.missing || !page.extract) return null;
  return { title: page.title, text: page.extract };
}

export async function fetchSummary(title: string): Promise<{ title: string; summary: string } | null> {
  const data = await wiki<{ query?: { pages?: Array<{ title: string; extract?: string; missing?: boolean }> } }>({
    action: "query",
    prop: "extracts",
    exintro: "1",
    explaintext: "1",
    redirects: "1",
    titles: title,
  });
  const page = data.query?.pages?.[0];
  if (!page || page.missing || !page.extract) return null;
  return { title: page.title, summary: page.extract.trim() };
}

async function fetchLeadLinks(title: string): Promise<string[]> {
  const data = await wiki<{ parse?: { links?: Array<{ title: string; ns: number; exists?: boolean }> } }>({
    action: "parse",
    page: title,
    prop: "links",
    section: "0",
    redirects: "1",
  });
  return (data.parse?.links ?? [])
    .filter((l) => l.ns === 0 && l.exists !== false)
    .map((l) => l.title)
    .filter((t) => !/^\d{4}/.test(t) && !/\(disambiguation\)/.test(t));
}

/** Split a plaintext Wikipedia extract into (heading, text) sections. */
export function splitSections(text: string): Array<{ level: number; heading: string; text: string; parent: string }> {
  const lines = text.split("\n");
  const sections: Array<{ level: number; heading: string; text: string; parent: string }> = [];
  let current = { level: 1, heading: "Introduction", text: "", parent: "" };
  let lastTop = "";
  for (const line of lines) {
    const m = line.match(/^(={2,4})\s*(.+?)\s*\1\s*$/);
    if (m) {
      sections.push(current);
      const level = m[1].length;
      if (level === 2) lastTop = m[2].trim();
      current = { level, heading: m[2].trim(), text: "", parent: level === 2 ? "" : lastTop };
    } else {
      current.text += line + "\n";
    }
  }
  sections.push(current);
  return sections.map((s) => ({ ...s, text: s.text.trim() }));
}

export function firstSentences(text: string, n = 2): string {
  const clean = text.replace(/\s+/g, " ").trim();
  const parts = clean.match(/[^.!?]+[.!?]+(\s|$)/g) ?? [clean];
  return parts.slice(0, n).join(" ").trim();
}

/**
 * Investigate a subject. Returns a structured research result with a log.
 */
export async function researchSubject(subject: string, focus: string[] = []): Promise<ResearchResult> {
  const entries: ResearchLogEntry[] = [];
  const result: ResearchResult = { subject, canonicalTitle: null, description: "", concepts: [], prerequisitePairs: [], log: entries };

  const query = [subject, ...focus].join(" ");
  log(entries, "search", "wikipedia", `Searching for the canonical article for "${query}"`);
  const hits = await searchWikipedia(query, 8); // throws ResearchUnavailableError on rate limit
  if (!hits.length) {
    log(entries, "search", "wikipedia", "No results found");
    return result;
  }
  const ranked = rankHits(hits, subject, focus);
  log(entries, "search", "wikipedia", `Candidates ranked for learnability: ${ranked.map((r) => `${r.hit.title} (${r.score.toFixed(1)})`).join(" | ")}`, { hits: hits.map((h) => h.title) });

  let article: { title: string; text: string } | null = null;
  for (const r of ranked.slice(0, 3)) {
    const a = await fetchExtract(r.hit.title);
    if (!a) continue;
    if (/may refer to:|may also refer to/i.test(a.text.slice(0, 400))) {
      log(entries, "disambiguate", "wikipedia", `"${a.title}" is a disambiguation page; trying the next candidate`);
      continue;
    }
    article = a;
    break;
  }
  if (!article) {
    log(entries, "fetch", "wikipedia", `Could not fetch a usable article for "${subject}"`);
    return result;
  }
  result.canonicalTitle = article.title;
  const sections = splitSections(article.text);
  result.description = firstSentences(sections[0]?.text ?? "", 2);
  log(entries, "fetch", "wikipedia", `Fetched "${article.title}" (${article.text.length} chars, ${sections.length} sections)`, {
    ref: `https://en.wikipedia.org/wiki/${encodeURIComponent(article.title.replace(/ /g, "_"))}`,
  });

  // Candidate core concepts = substantive sections of the article.
  const core = sections
    .slice(1)
    .filter((s) => s.level <= 3 && !isBoilerplate(s) && s.text.length >= 250)
    .slice(0, 10);
  log(entries, "structure", "wikipedia", `Selected ${core.length} substantive sections as concept candidates: ${core.map((s) => s.heading).join(", ")}`);

  let order = 0;
  const seen = new Set<string>();
  for (const s of core) {
    const slug = slugify(s.heading);
    if (!slug || seen.has(slug)) continue;
    seen.add(slug);
    result.concepts.push({
      slug,
      title: s.heading,
      summary: firstSentences(s.text, 3),
      text: s.text,
      role: "core",
      order: order++,
      sourceRef: `${article.title}#${s.heading}`,
      mentions: [],
    });
  }

  // Prerequisite candidates = linked topics in the lead paragraph (what the
  // subject is defined in terms of).
  try {
    const leadText = firstSentences(sections[0]?.text ?? "", 3).toLowerCase();
    const leadLinks = (await fetchLeadLinks(article.title)).filter((t) => {
      const lt = t.toLowerCase().replace(/\s*\(.*\)$/, "");
      if (lt.length < 3 || /[a-z][A-Z]/.test(t) || /^\d/.test(t)) return false;
      if (/\((book|novel|film|album|song|magazine|journal|company|tv series|band)\)/i.test(t)) return false;
      const re = new RegExp(`(^|[^a-z])${lt.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^a-z]|$)`, "i");
      return re.test(leadText);
    });
    log(entries, "prerequisites", "wikipedia", `Terms the lead definition depends on: ${leadLinks.join(", ") || "(none found)"}`);
    const chosen = leadLinks.filter((t) => t.toLowerCase() !== article.title.toLowerCase()).slice(0, 4);
    for (const t of chosen) {
      const sum = await fetchSummary(t).catch(() => null);
      if (!sum || sum.summary.length < 80) continue;
      // Skip biographies and organisations — they are context, not prerequisites.
      if (/\b(born|died|née|is an? (american|british|english|french|german|italian|canadian|australian|indian|japanese|chinese|russian|spanish)\b.*\b(chef|author|writer|businessman|businesswoman|politician|actor|actress|singer|scientist|mathematician|physicist|engineer|entrepreneur|television|host|journalist|artist|musician))\b/i.test(firstSentences(sum.summary, 1))) {
        log(entries, "prerequisites", "wikipedia", `Skipping "${sum.title}" (biography/organisation, not a concept)`);
        continue;
      }
      const slug = slugify(sum.title);
      if (seen.has(slug)) continue;
      seen.add(slug);
      result.concepts.push({
        slug,
        title: sum.title,
        summary: firstSentences(sum.summary, 3),
        text: sum.summary,
        role: "prerequisite",
        order: -1,
        sourceRef: sum.title,
        mentions: [],
      });
      log(entries, "prerequisites", "wikipedia", `Added prerequisite candidate "${sum.title}"`);
    }
  } catch (e) {
    log(entries, "prerequisites", "wikipedia", `Lead link fetch failed: ${e instanceof Error ? e.message : e}`);
  }

  // Infer prerequisite edges: (a) prerequisite-role concepts feed the first core
  // concepts; (b) if concept B's text mentions concept A's title and A comes
  // earlier, A -> B; (c) sequential fallback for adjacent sections.
  const cores = result.concepts.filter((c) => c.role === "core");
  const prereqs = result.concepts.filter((c) => c.role === "prerequisite");
  for (const p of prereqs) {
    for (const c of cores.slice(0, 2)) {
      result.prerequisitePairs.push({ concept: c.slug, prerequisite: p.slug, reason: "definitional dependency from lead paragraph" });
    }
  }
  for (let i = 0; i < cores.length; i++) {
    const b = cores[i];
    const lower = b.text.toLowerCase();
    let found = false;
    for (let j = 0; j < i; j++) {
      const a = cores[j];
      if (a.title.length >= 4 && lower.includes(a.title.toLowerCase())) {
        b.mentions.push(a.title);
        result.prerequisitePairs.push({ concept: b.slug, prerequisite: a.slug, reason: `"${b.title}" text references "${a.title}"` });
        found = true;
      }
    }
    if (!found && i > 0) {
      result.prerequisitePairs.push({ concept: b.slug, prerequisite: cores[i - 1].slug, reason: "sequential article structure" });
    }
  }
  log(entries, "graph", "inference", `Inferred ${result.prerequisitePairs.length} prerequisite edges from text references and structure`);
  return result;
}

/** Research a single concept (used for gap discovery / learner questions). */
export async function researchConcept(term: string, context: string): Promise<{ title: string; summary: string; text: string; ref: string; log: ResearchLogEntry[] } | null> {
  const entries: ResearchLogEntry[] = [];
  log(entries, "search", "wikipedia", `Investigating "${term}" in the context of ${context}`);
  const hits = await searchWikipedia(`${term} ${context}`, 3).catch(() => []);
  const pick = hits[0] ?? (await searchWikipedia(term, 1).catch(() => []))[0];
  if (!pick) {
    log(entries, "search", "wikipedia", "Nothing found");
    return null;
  }
  const art = await fetchExtract(pick.title);
  if (!art) return null;
  const sections = splitSections(art.text);
  log(entries, "fetch", "wikipedia", `Using article "${art.title}"`);
  return {
    title: art.title,
    summary: firstSentences(sections[0].text, 3),
    text: sections.slice(0, 3).map((s) => s.text).join("\n\n").slice(0, 4000),
    ref: `https://en.wikipedia.org/wiki/${encodeURIComponent(art.title.replace(/ /g, "_"))}`,
    log: entries,
  };
}

// ---------------------------------------------------------------------------
// Content synthesis from researched text (no-LLM path)
// ---------------------------------------------------------------------------

const STOP = new Set(
  "the a an and or but of to in on at for with by from as is are was were be been being this that these those it its into than then which who whom whose what when where why how not no also can may might will would should could such more most other some any each all both either neither very often used use using uses called known commonly typically usually example examples including include includes".split(" "),
);

export function keyTerms(text: string, limit = 12): string[] {
  const counts = new Map<string, number>();
  for (const raw of text.toLowerCase().match(/[a-z][a-z0-9_+#-]{3,}/g) ?? []) {
    if (STOP.has(raw)) continue;
    counts.set(raw, (counts.get(raw) ?? 0) + 1);
  }
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([t]) => t);
}

function sentences(text: string): string[] {
  return (text.replace(/\s+/g, " ").match(/[^.!?]+[.!?]+(?=\s|$)/g) ?? []).map((s) => s.trim()).filter((s) => s.length >= 50 && s.length <= 220 && !/\b(citation|ISBN|http)/i.test(s));
}

function shuffle<T>(arr: T[], seed: number): T[] {
  const a = [...arr];
  let s = seed;
  for (let i = a.length - 1; i > 0; i--) {
    s = (s * 9301 + 49297) % 233280;
    const j = Math.floor((s / 233280) * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/**
 * Build exercises for a concept from its researched text plus sibling concepts
 * (used as distractors). Produces definition-matching, cloze and true/false items.
 */
export function synthesizeExercises(
  concept: { slug: string; title: string; summary: string; text: string },
  siblings: Array<{ slug: string; title: string; summary: string }>,
): Exercise[] {
  const out: Exercise[] = [];
  const others = siblings.filter((s) => s.slug !== concept.slug);
  const mask = (s: string) => s.replace(new RegExp(concept.title.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi"), "____");

  // 1) Definition matching (recognition)
  if (others.length >= 2 && concept.summary.length > 40) {
    const distractors = shuffle(others, concept.slug.length).slice(0, 3).map((o) => o.title);
    const options = shuffle([concept.title, ...distractors], concept.slug.length + 7);
    out.push({
      id: `${concept.slug}-def`,
      type: "mcq",
      prompt: `Which concept is being described?\n\n"${mask(firstSentences(concept.summary, 1))}"`,
      options,
      answer: String(options.indexOf(concept.title)),
      explanation: `This describes ${concept.title}: ${firstSentences(concept.summary, 1)}`,
      difficulty: 0.3,
    });
  }

  // 2) Cloze items on key terms (recall)
  const terms = keyTerms(concept.text, 15).filter((t) => t.length >= 5 && !concept.title.toLowerCase().includes(t));
  const sents = sentences(concept.text);
  let clozeCount = 0;
  for (const term of terms) {
    if (clozeCount >= 2) break;
    const s = sents.find((x) => new RegExp(`\\b${term}\\b`, "i").test(x));
    if (!s) continue;
    const distractors = terms.filter((t) => t !== term).slice(0, 6);
    if (distractors.length < 3) continue;
    const options = shuffle([term, ...shuffle(distractors, term.length).slice(0, 3)], term.length * 3);
    out.push({
      id: `${concept.slug}-cloze-${clozeCount}`,
      type: "mcq",
      prompt: `Fill in the blank (about ${concept.title}):\n\n"${s.replace(new RegExp(`\\b${term}\\b`, "i"), "______")}"`,
      options,
      answer: String(options.indexOf(term)),
      explanation: s,
      difficulty: 0.55,
    });
    clozeCount++;
  }

  // 3) True/false by swapping the concept name with a sibling's
  if (others.length && sents.length >= 2) {
    const s = sents.find((x) => x.toLowerCase().includes(concept.title.toLowerCase())) ?? sents[1];
    const swapped = others[0];
    const makeFalse = s.toLowerCase().includes(concept.title.toLowerCase());
    const stmt = makeFalse ? s.replace(new RegExp(concept.title.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"), swapped.title) : s;
    out.push({
      id: `${concept.slug}-tf`,
      type: "truefalse",
      prompt: `True or false?\n\n"${stmt}"`,
      options: ["True", "False"],
      answer: makeFalse ? "1" : "0",
      explanation: makeFalse ? `False — the original statement is about ${concept.title}, not ${swapped.title}: "${s}"` : `True: "${s}"`,
      difficulty: 0.45,
    });
  }
  return out;
}

/** Generate explanations in each teaching strategy from researched text. */
export function synthesizeExplanations(concept: { title: string; summary: string; text: string }, subject: string): Partial<Record<StrategyId, string>> {
  const sents = sentences(concept.text);
  const points = keyTerms(concept.text, 6);
  const body = concept.text.slice(0, 900).trim();
  const example = sents.find((s) => /\b(for example|e\.g\.|for instance|such as)\b/i.test(s));
  return {
    formal_definition: `**${concept.title}** — ${concept.summary}\n\n${body}`,
    concrete_example: `Let's look at **${concept.title}** through a concrete case.\n\n${example ?? sents[0] ?? concept.summary}\n\nIn practice, when working with ${subject}, you meet this whenever ${points.slice(0, 3).join(", ")} come up. Try to spot those terms in the next exercise.`,
    analogy: `Think of **${concept.title}** as one piece of the ${subject} toolbox. ${concept.summary}\n\nIf ${subject} were a workshop, ${concept.title} would be the tool you reach for when you need to deal with ${points.slice(0, 2).join(" and ")}.`,
    step_by_step: `**${concept.title}**, one idea at a time:\n\n${(sents.length ? sents.slice(0, 5) : [concept.summary]).map((s, i) => `${i + 1}. ${s}`).join("\n")}`,
    socratic: `Before I explain **${concept.title}**, consider these questions:\n\n- What problem in ${subject} do you think ${concept.title} solves?\n- Where have you seen the words ${points.slice(0, 3).map((p) => `"${p}"`).join(", ")} before?\n\nHere's the core idea to check your thinking against: ${concept.summary}`,
  };
}
