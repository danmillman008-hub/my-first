/**
 * Intelligence provider abstraction.
 *
 * When ANTHROPIC_API_KEY or OPENAI_API_KEY is configured the agent uses an LLM
 * for open-ended reasoning (goal interpretation, curriculum synthesis, free-text
 * grading, explanation generation). Without a key, every caller has a built-in
 * deterministic fallback (web research + heuristics), so the adaptive
 * machinery — mastery tracking, strategy learning, affect, gap detection,
 * graph extension — works in both modes.
 */

export type LLMProvider = "anthropic" | "openai" | "none";

export function llmProvider(): LLMProvider {
  if (process.env.ANTHROPIC_API_KEY) return "anthropic";
  if (process.env.OPENAI_API_KEY) return "openai";
  return "none";
}

export function hasLLM(): boolean {
  return llmProvider() !== "none";
}

export type LLMResult<T> = { ok: true; value: T; provider: LLMProvider } | { ok: false; error: string };

async function callAnthropic(system: string, user: string, maxTokens: number): Promise<string> {
  const model = process.env.ANTHROPIC_MODEL || "claude-sonnet-4-20250514";
  const res = await fetch(`${(process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com").replace(/\/$/, "")}/v1/messages`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY!,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model,
      max_tokens: maxTokens,
      system,
      messages: [{ role: "user", content: user }],
    }),
    signal: AbortSignal.timeout(90_000),
  });
  if (!res.ok) throw new Error(`anthropic ${res.status}: ${(await res.text()).slice(0, 300)}`);
  const json = (await res.json()) as { content: Array<{ type: string; text?: string }> };
  return json.content.map((c) => c.text ?? "").join("");
}

async function callOpenAI(system: string, user: string, maxTokens: number): Promise<string> {
  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";
  const res = await fetch(`${(process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${process.env.OPENAI_API_KEY!}`,
    },
    body: JSON.stringify({
      model,
      max_tokens: maxTokens,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
      response_format: { type: "json_object" },
    }),
    signal: AbortSignal.timeout(90_000),
  });
  if (!res.ok) throw new Error(`openai ${res.status}: ${(await res.text()).slice(0, 300)}`);
  const json = (await res.json()) as { choices: Array<{ message: { content: string } }> };
  return json.choices[0]?.message?.content ?? "";
}

function extractJson(text: string): unknown {
  const trimmed = text.trim();
  const fence = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/);
  const candidate = fence ? fence[1] : trimmed;
  try {
    return JSON.parse(candidate);
  } catch {
    const start = candidate.search(/[[{]/);
    const end = Math.max(candidate.lastIndexOf("}"), candidate.lastIndexOf("]"));
    if (start >= 0 && end > start) return JSON.parse(candidate.slice(start, end + 1));
    throw new Error("no JSON found in model output");
  }
}

/**
 * Ask the LLM for a JSON object. `validate` should throw or return null when
 * the shape is wrong; the caller then falls back to its deterministic path.
 */
export async function llmJson<T>(
  system: string,
  user: string,
  validate: (raw: unknown) => T | null,
  opts: { maxTokens?: number } = {},
): Promise<LLMResult<T>> {
  const provider = llmProvider();
  if (provider === "none") return { ok: false, error: "no LLM provider configured" };
  const maxTokens = opts.maxTokens ?? 4000;
  const sys = `${system}\n\nRespond with a single JSON value and nothing else.`;
  try {
    const text = provider === "anthropic" ? await callAnthropic(sys, user, maxTokens) : await callOpenAI(sys, user, maxTokens);
    const raw = extractJson(text);
    const value = validate(raw);
    if (value === null) return { ok: false, error: "LLM output failed validation" };
    return { ok: true, value, provider };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}
