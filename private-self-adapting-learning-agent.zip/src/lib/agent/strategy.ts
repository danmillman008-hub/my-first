/**
 * Teaching-strategy selection as a per-learner Bernoulli bandit solved with
 * Thompson sampling. Each strategy has a Beta(alpha, beta) posterior on
 * "this explanation style leads to a correct follow-up / positive feedback".
 *
 * Scope layering: a domain-specific posterior is preferred once it has enough
 * pulls; otherwise the learner's global posterior is used, so what we learn
 * about a learner in Bash informs how we start teaching them OOP.
 */
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { learnerTraits, strategyStats, type StrategyId } from "@/db/schema";

export const STRATEGIES: StrategyId[] = ["concrete_example", "analogy", "formal_definition", "step_by_step", "socratic"];

export const STRATEGY_LABELS: Record<StrategyId, string> = {
  concrete_example: "Concrete example",
  analogy: "Analogy",
  formal_definition: "Formal definition",
  step_by_step: "Step by step",
  socratic: "Socratic questions",
};

export type StrategyRow = typeof strategyStats.$inferSelect;

// --- Beta sampling (Marsaglia & Tsang gamma) ---
function randn(): number {
  let u = 0,
    v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}
function gamma(shape: number): number {
  if (shape < 1) return gamma(shape + 1) * Math.pow(Math.random(), 1 / shape);
  const d = shape - 1 / 3;
  const c = 1 / Math.sqrt(9 * d);
  for (;;) {
    let x: number, v: number;
    do {
      x = randn();
      v = 1 + c * x;
    } while (v <= 0);
    v = v * v * v;
    const u = Math.random();
    if (u < 1 - 0.0331 * x ** 4) return d * v;
    if (Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
  }
}
export function sampleBeta(alpha: number, beta: number): number {
  const a = gamma(alpha);
  const b = gamma(beta);
  return a / (a + b);
}

export async function getStrategyStats(learnerId: number, scope: string): Promise<Map<StrategyId, StrategyRow>> {
  const rows = await db.select().from(strategyStats).where(and(eq(strategyStats.learnerId, learnerId), eq(strategyStats.scope, scope)));
  const map = new Map(rows.map((r) => [r.strategy as StrategyId, r]));
  const missing = STRATEGIES.filter((s) => !map.has(s));
  if (missing.length) {
    const inserted = await db
      .insert(strategyStats)
      .values(missing.map((strategy) => ({ learnerId, scope, strategy })))
      .onConflictDoNothing()
      .returning();
    for (const r of inserted) map.set(r.strategy as StrategyId, r);
  }
  return map;
}

export type StrategyChoice = {
  strategy: StrategyId;
  samples: Record<string, number>;
  means: Record<string, number>;
  scopeUsed: string;
  exploration: boolean;
};

/**
 * Choose a strategy. `exclude` lets the tutor avoid strategies that just failed
 * on this concept; `available` restricts to strategies the material supports.
 */
export async function chooseStrategy(
  learnerId: number,
  domainScope: string,
  opts: { exclude?: StrategyId[]; available?: StrategyId[] } = {},
): Promise<StrategyChoice> {
  const [domainStats, globalStats] = await Promise.all([getStrategyStats(learnerId, domainScope), getStrategyStats(learnerId, "global")]);
  const domainPulls = [...domainStats.values()].reduce((n, r) => n + r.pulls, 0);
  const useDomain = domainPulls >= 4;
  const stats = useDomain ? domainStats : globalStats;
  const candidates = STRATEGIES.filter((s) => !(opts.exclude ?? []).includes(s) && (!opts.available || opts.available.includes(s)));
  const pool = candidates.length ? candidates : STRATEGIES;
  const samples: Record<string, number> = {};
  const means: Record<string, number> = {};
  let best: StrategyId = pool[0];
  let bestSample = -1;
  // With solid evidence, sharpen the posterior samples so we exploit more and
  // explore less (still non-zero exploration, so a changed learner is noticed).
  const totalPulls = [...stats.values()].reduce((n, r) => n + r.pulls, 0) + (useDomain ? 0 : domainPulls);
  const sharpen = totalPulls >= 8 ? 2 : 1;
  for (const s of pool) {
    const r = stats.get(s)!;
    // blend with the other scope's posterior as a prior
    const other = (useDomain ? globalStats : domainStats).get(s)!;
    const a = (r.alpha + (other.alpha - 1) * 0.5) * sharpen;
    const b = (r.beta + (other.beta - 1) * 0.5) * sharpen;
    samples[s] = sampleBeta(a, b);
    means[s] = a / (a + b);
    if (samples[s] > bestSample) {
      bestSample = samples[s];
      best = s;
    }
  }
  const greedy = Object.entries(means).sort((x, y) => y[1] - x[1])[0]?.[0];
  return { strategy: best, samples, means, scopeUsed: useDomain ? domainScope : "global", exploration: greedy !== best };
}

/** Reward a strategy in both scopes. weight lets explicit feedback count more/less than an exercise outcome. */
export async function rewardStrategy(learnerId: number, domainScope: string, strategy: StrategyId, success: boolean, weight = 1) {
  for (const scope of [domainScope, "global"]) {
    const stats = await getStrategyStats(learnerId, scope);
    const r = stats.get(strategy)!;
    await db
      .update(strategyStats)
      .set({
        alpha: r.alpha + (success ? weight : 0),
        beta: r.beta + (success ? 0 : weight),
        pulls: r.pulls + 1,
        successes: r.successes + (success ? 1 : 0),
        updatedAt: new Date(),
      })
      .where(eq(strategyStats.id, r.id));
  }
  await refreshStyleTrait(learnerId);
}

/** Derive an inspectable "preferred explanation style" trait from the bandit posteriors. */
async function refreshStyleTrait(learnerId: number) {
  const stats = await getStrategyStats(learnerId, "global");
  const ranked = [...stats.values()]
    .map((r) => ({ strategy: r.strategy, mean: r.alpha / (r.alpha + r.beta), pulls: r.pulls }))
    .sort((a, b) => b.mean - a.mean);
  const totalPulls = ranked.reduce((n, r) => n + r.pulls, 0);
  if (totalPulls < 3) return;
  const top = ranked[0];
  const bottom = ranked[ranked.length - 1];
  const confidence = Math.min(0.95, 0.3 + totalPulls * 0.05 + (top.mean - bottom.mean));
  await upsertTrait(
    learnerId,
    "explanation_style",
    { preferred: top.strategy, avoid: bottom.mean < 0.4 ? bottom.strategy : null, ranking: ranked },
    confidence,
    totalPulls,
    `${STRATEGY_LABELS[top.strategy as StrategyId]} has the best success rate (${(top.mean * 100).toFixed(0)}%) across ${totalPulls} explanations` +
      (bottom.mean < 0.4 ? `; ${STRATEGY_LABELS[bottom.strategy as StrategyId]} is underperforming (${(bottom.mean * 100).toFixed(0)}%)` : ""),
  );
}

export async function upsertTrait(learnerId: number, key: string, value: unknown, confidence: number, evidenceCount: number, rationale: string) {
  await db
    .insert(learnerTraits)
    .values({ learnerId, key, value, confidence, evidenceCount, rationale, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: [learnerTraits.learnerId, learnerTraits.key],
      set: { value, confidence, evidenceCount, rationale, updatedAt: new Date() },
    });
}

export async function getTraits(learnerId: number) {
  return db.select().from(learnerTraits).where(eq(learnerTraits.learnerId, learnerId));
}
