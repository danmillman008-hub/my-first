import type { Exercise, StrategyId } from "@/db/schema";

export type PackConcept = {
  slug: string;
  title: string;
  summary: string;
  difficulty: number;
  role: "core" | "prerequisite";
  tags: string[];
  prereqs: string[];
  explanations: Partial<Record<StrategyId, string>>;
  keyPoints: string[];
  exercises: Exercise[];
};

/** A concept the agent knows about but does not schedule until evidence shows it is needed. */
export type LatentConcept = Omit<PackConcept, "role" | "prereqs"> & {
  /** concepts (slugs) this latent concept is a prerequisite for once discovered */
  supports: string[];
};

export type KnowledgePack = {
  slug: string;
  title: string;
  description: string;
  aliases: string[];
  concepts: PackConcept[];
  latent: LatentConcept[];
};
