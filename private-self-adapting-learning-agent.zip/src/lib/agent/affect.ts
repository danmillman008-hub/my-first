/**
 * Affect estimation from behavioural and explicit signals.
 *
 * Signals: correctness streaks, response latency relative to the learner's
 * own baseline, hint requests, explicit feedback buttons, and lexical cues in
 * free-text messages. Estimates are exponentially smoothed so a single event
 * nudges rather than flips the state, and every update stores the signals that
 * caused it.
 */
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { affectStates } from "@/db/schema";

export type Affect = {
  frustration: number;
  confusion: number;
  engagement: number;
  fatigue: number;
  confidence: number;
};

export const NEUTRAL_AFFECT: Affect = { frustration: 0, confusion: 0, engagement: 0.6, fatigue: 0, confidence: 0.5 };

export type AffectSignal =
  | { type: "answer"; correct: boolean; latencyMs: number | null; baselineMs: number | null; wrongStreak: number; rightStreak: number; hintUsed: boolean }
  | { type: "feedback"; value: "confused" | "got_it" | "too_easy" | "too_hard" | "too_slow" | "too_fast" | "tired" | "frustrated" | "helpful" | "not_helpful" }
  | { type: "text"; text: string }
  | { type: "session"; exercisesSinceBreak: number; minutesActive: number }
  | { type: "hint" };

const LEX: Array<{ re: RegExp; effect: Partial<Affect>; label: string }> = [
  { re: /\b(confus|don'?t (get|understand)|lost|no idea|what does .* mean|huh|unclear|makes no sense)\b/i, effect: { confusion: 0.35 }, label: "text:confusion" },
  { re: /\b(frustrat|annoy|ugh|argh|stupid|hate|give up|this sucks|wtf|pointless)\b/i, effect: { frustration: 0.4, engagement: -0.15 }, label: "text:frustration" },
  { re: /\b(tired|exhausted|sleepy|break|enough for today|long day)\b/i, effect: { fatigue: 0.4 }, label: "text:fatigue" },
  { re: /\b(boring|bored|too easy|already know|trivial|obvious|skip)\b/i, effect: { engagement: -0.2, confidence: 0.15 }, label: "text:boredom" },
  { re: /\b(cool|interesting|nice|got it|makes sense|i see|awesome|love this|thanks)\b/i, effect: { engagement: 0.15, confusion: -0.15, frustration: -0.15 }, label: "text:positive" },
  { re: /\b(too fast|slow down|too much|too long|overwhelm)\b/i, effect: { confusion: 0.2, fatigue: 0.1 }, label: "text:pace-too-fast" },
];

function clamp(x: number) {
  return Math.max(0, Math.min(1, x));
}

export function applySignal(prev: Affect, signal: AffectSignal): { next: Affect; labels: string[] } {
  const d: Affect = { frustration: 0, confusion: 0, engagement: 0, fatigue: 0, confidence: 0 };
  const labels: string[] = [];
  switch (signal.type) {
    case "answer": {
      if (signal.correct) {
        d.confidence += 0.12;
        d.frustration -= 0.15;
        d.confusion -= 0.12;
        d.engagement += 0.05;
        if (signal.rightStreak >= 4) {
          d.engagement -= 0.08; // possible boredom
          labels.push("long-correct-streak");
        }
      } else {
        d.confidence -= 0.1;
        d.confusion += 0.15;
        d.frustration += 0.08 + 0.1 * Math.max(0, signal.wrongStreak - 1);
        if (signal.wrongStreak >= 2) labels.push(`wrong-streak:${signal.wrongStreak}`);
      }
      if (signal.hintUsed) {
        d.confusion += 0.08;
        labels.push("hint-used");
      }
      if (signal.latencyMs != null && signal.baselineMs != null && signal.baselineMs > 0) {
        const ratio = signal.latencyMs / signal.baselineMs;
        if (ratio > 2.2) {
          d.confusion += 0.12;
          d.fatigue += 0.05;
          labels.push("slow-response");
        } else if (ratio < 0.35 && !signal.correct) {
          d.engagement -= 0.15;
          d.frustration += 0.1;
          labels.push("fast-wrong-answer");
        }
      }
      break;
    }
    case "feedback": {
      labels.push(`feedback:${signal.value}`);
      const map: Record<string, Partial<Affect>> = {
        confused: { confusion: 0.4 },
        got_it: { confusion: -0.3, confidence: 0.15, engagement: 0.1 },
        too_easy: { engagement: -0.2, confidence: 0.2 },
        too_hard: { confusion: 0.3, frustration: 0.2, confidence: -0.15 },
        too_slow: { engagement: -0.15 },
        too_fast: { confusion: 0.2 },
        tired: { fatigue: 0.5 },
        frustrated: { frustration: 0.5, engagement: -0.1 },
        helpful: { engagement: 0.1, confusion: -0.2 },
        not_helpful: { confusion: 0.2, frustration: 0.1 },
      };
      Object.assign(d, mergeDelta(d, map[signal.value] ?? {}));
      break;
    }
    case "text": {
      for (const l of LEX) {
        if (l.re.test(signal.text)) {
          Object.assign(d, mergeDelta(d, l.effect));
          labels.push(l.label);
        }
      }
      break;
    }
    case "session": {
      // Fatigue grows with sustained time-on-task, not with a raw item count.
      if (signal.minutesActive >= 25) {
        d.fatigue += 0.05 + Math.min(0.1, (signal.minutesActive - 25) / 200);
        labels.push("long-session");
      } else if (signal.exercisesSinceBreak >= 25) {
        d.fatigue += 0.03;
        labels.push("many-items");
      }
      break;
    }
    case "hint": {
      d.confusion += 0.1;
      labels.push("hint-request");
      break;
    }
  }
  // Exponential smoothing toward the delta target; mild regression toward neutral
  const k = 0.7;
  const next: Affect = {
    frustration: clamp(prev.frustration + k * d.frustration - 0.02),
    confusion: clamp(prev.confusion + k * d.confusion - 0.02),
    engagement: clamp(prev.engagement + k * d.engagement + 0.01 * (0.6 - prev.engagement)),
    fatigue: clamp(prev.fatigue + k * d.fatigue - 0.01),
    confidence: clamp(prev.confidence + k * d.confidence),
  };
  return { next, labels };
}

function mergeDelta(d: Affect, e: Partial<Affect>): Affect {
  return {
    frustration: d.frustration + (e.frustration ?? 0),
    confusion: d.confusion + (e.confusion ?? 0),
    engagement: d.engagement + (e.engagement ?? 0),
    fatigue: d.fatigue + (e.fatigue ?? 0),
    confidence: d.confidence + (e.confidence ?? 0),
  };
}

export async function latestAffect(learnerId: number): Promise<Affect> {
  const [row] = await db.select().from(affectStates).where(eq(affectStates.learnerId, learnerId)).orderBy(desc(affectStates.createdAt)).limit(1);
  if (!row) return { ...NEUTRAL_AFFECT };
  // affect fades with time between sessions
  const hours = (Date.now() - row.createdAt.getTime()) / 3_600_000;
  const fade = Math.exp(-hours / 6);
  return {
    frustration: row.frustration * fade,
    confusion: row.confusion * fade,
    engagement: 0.6 + (row.engagement - 0.6) * fade,
    fatigue: row.fatigue * Math.exp(-hours / 2),
    confidence: 0.5 + (row.confidence - 0.5) * fade,
  };
}

export async function updateAffect(learnerId: number, goalId: number | null, sessionId: number | null, signals: AffectSignal[]): Promise<{ affect: Affect; labels: string[] }> {
  let affect = await latestAffect(learnerId);
  const labels: string[] = [];
  for (const s of signals) {
    const r = applySignal(affect, s);
    affect = r.next;
    labels.push(...r.labels);
  }
  await db.insert(affectStates).values({ learnerId, goalId, sessionId, ...affect, signals: labels });
  return { affect, labels };
}

/** Human-readable dominant state, used for UI and for MCP consumers. */
export function describeAffect(a: Affect): string {
  if (a.fatigue > 0.6) return "fatigued";
  if (a.frustration > 0.55) return "frustrated";
  if (a.confusion > 0.55) return "confused";
  if (a.engagement < 0.35) return "disengaged";
  if (a.confidence > 0.75 && a.engagement > 0.5) return "confident";
  return "engaged";
}
