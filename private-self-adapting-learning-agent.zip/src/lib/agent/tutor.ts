/**
 * The tutoring agent loop.
 *
 * Every learner action flows through `tutorTurn`, which: grades / interprets
 * the action, records evidence (append-only), updates beliefs (mastery,
 * affect, strategy posteriors, traits), verifies whether earlier adaptations
 * worked, detects prerequisite gaps, extends the graph when needed, re-plans,
 * and emits the next agent turns. Every non-trivial choice is logged as an
 * inspectable decision with a rationale.
 */
import { and, asc, desc, eq, inArray, isNull } from "drizzle-orm";
import { db } from "@/db";
import { agentDecisions, concepts, domains, goals, prerequisites, sessions, turns, type Exercise, type SessionState, type StrategyId } from "@/db/schema";
import { describeAffect, updateAffect, type Affect, type AffectSignal } from "./affect";
import { discoverConcept } from "./domain";
import { hasLLM, llmJson } from "./intelligence";
import { ensureBeliefs, isMastered, MASTERY_THRESHOLD, READY_THRESHOLD, recordEvidence, recordSelfReport, retentionFactor, type BeliefRow } from "./mastery";
import { chooseStrategy, getTraits, rewardStrategy, STRATEGIES, STRATEGY_LABELS, upsertTrait } from "./strategy";

export type FeedbackValue = "confused" | "got_it" | "too_easy" | "too_hard" | "too_slow" | "too_fast" | "tired" | "frustrated" | "helpful" | "not_helpful";

export type LearnerAction =
  | { type: "start" }
  | { type: "next" }
  | { type: "answer"; answer: string; latencyMs?: number }
  | { type: "feedback"; value: FeedbackValue }
  | { type: "message"; text: string }
  | { type: "hint" }
  | { type: "skip_diagnostic"; level: "beginner" | "knows_basics" }
  | { type: "take_break" };

type ConceptRow = typeof concepts.$inferSelect;
type SessionRow = typeof sessions.$inferSelect;
type GoalRow = typeof goals.$inferSelect;
type TurnRow = typeof turns.$inferSelect;

export type TurnResult = { turns: TurnRow[]; session: SessionRow; affect: Affect; affectLabel: string };

type Ctx = {
  goal: GoalRow;
  session: SessionRow;
  state: SessionState;
  conceptMap: Map<number, ConceptRow>;
  order: number[]; // topological order of relevant concept ids
  prereqOf: Map<number, Array<{ id: number; strength: number }>>;
  beliefs: Map<number, BeliefRow>;
  domainSlug: string;
  out: TurnRow[];
  affect: Affect;
  affectLabels: string[];
  traits: Map<string, { value: unknown; confidence: number }>;
};

// ---------------------------------------------------------------------------
// Graph helpers
// ---------------------------------------------------------------------------

export async function loadGraph(goal: GoalRow) {
  const all = await db.select().from(concepts).where(eq(concepts.domainId, goal.domainId!));
  const edges = await db
    .select()
    .from(prerequisites)
    .where(inArray(prerequisites.conceptId, all.map((c) => c.id)));
  const prereqOf = new Map<number, Array<{ id: number; strength: number }>>();
  for (const e of edges) {
    if (!prereqOf.has(e.conceptId)) prereqOf.set(e.conceptId, []);
    prereqOf.get(e.conceptId)!.push({ id: e.prerequisiteId, strength: e.strength });
  }
  // relevant = targets + transitive prerequisites (+ discovered concepts linked into that closure)
  const relevant = new Set<number>();
  const stack = [...goal.targetConceptIds];
  while (stack.length) {
    const id = stack.pop()!;
    if (relevant.has(id)) continue;
    relevant.add(id);
    for (const p of prereqOf.get(id) ?? []) stack.push(p.id);
  }
  // Kahn topological sort restricted to relevant, tie-break by difficulty
  const indeg = new Map<number, number>();
  for (const id of relevant) indeg.set(id, (prereqOf.get(id) ?? []).filter((p) => relevant.has(p.id)).length);
  const conceptMap = new Map(all.map((c) => [c.id, c]));
  const order: number[] = [];
  const ready = [...relevant].filter((id) => indeg.get(id) === 0);
  const visited = new Set<number>();
  while (ready.length) {
    ready.sort((a, b) => (conceptMap.get(a)!.difficulty - conceptMap.get(b)!.difficulty) || a - b);
    const id = ready.shift()!;
    if (visited.has(id)) continue;
    visited.add(id);
    order.push(id);
    for (const [c, ps] of prereqOf) {
      if (!relevant.has(c) || visited.has(c)) continue;
      if (ps.some((p) => p.id === id)) {
        indeg.set(c, (indeg.get(c) ?? 1) - 1);
        if (indeg.get(c) === 0) ready.push(c);
      }
    }
  }
  for (const id of relevant) if (!visited.has(id)) order.push(id); // cycles: append
  return { conceptMap, order, prereqOf, edges };
}

// ---------------------------------------------------------------------------
// Session bootstrap
// ---------------------------------------------------------------------------

async function getOrCreateSession(goal: GoalRow): Promise<SessionRow> {
  const [open] = await db.select().from(sessions).where(and(eq(sessions.goalId, goal.id), isNull(sessions.endedAt))).orderBy(desc(sessions.startedAt)).limit(1);
  if (open) return open;
  // Inherit what matters from the previous session: diagnostic completion and the concept in focus.
  const [prev] = await db.select().from(sessions).where(eq(sessions.goalId, goal.id)).orderBy(desc(sessions.startedAt)).limit(1);
  const diagnosticDone = Boolean(prev?.state?.diagnosticDone) || (goal.status !== "diagnosing" && goal.status !== "investigating");
  const phase = goal.status === "completed" ? "complete" : diagnosticDone ? "teach" : "diagnose";
  const [created] = await db
    .insert(sessions)
    .values({ learnerId: goal.learnerId, goalId: goal.id, phase, currentConceptId: prev?.currentConceptId ?? null, state: diagnosticDone ? { diagnosticDone: true, resumedFromSession: prev?.id } : {} })
    .returning();
  return created;
}

async function emit(ctx: Ctx, role: "agent" | "system", kind: string, content: Record<string, unknown>, conceptId: number | null = null) {
  const [row] = await db.insert(turns).values({ sessionId: ctx.session.id, learnerId: ctx.goal.learnerId, role, kind, conceptId, content }).returning();
  ctx.out.push(row);
  return row;
}

async function recordLearnerTurn(ctx: Ctx, kind: string, content: Record<string, unknown>, conceptId: number | null = null) {
  await db.insert(turns).values({ sessionId: ctx.session.id, learnerId: ctx.goal.learnerId, role: "learner", kind, conceptId, content });
}

async function decide(ctx: Ctx, kind: string, rationale: string, inputs: Record<string, unknown> = {}, outputs: Record<string, unknown> = {}) {
  const [row] = await db.insert(agentDecisions).values({ learnerId: ctx.goal.learnerId, goalId: ctx.goal.id, sessionId: ctx.session.id, kind, rationale, inputs, outputs }).returning({ id: agentDecisions.id });
  await emit(ctx, "system", "note", { text: rationale, kind, decisionId: row.id });
  return row.id;
}

async function saveState(ctx: Ctx, patch: Partial<SessionRow> = {}) {
  const [s] = await db
    .update(sessions)
    .set({ state: ctx.state, lastActivityAt: new Date(), ...patch })
    .where(eq(sessions.id, ctx.session.id))
    .returning();
  ctx.session = s;
}

function trait<T>(ctx: Ctx, key: string, fallback: T): T {
  const t = ctx.traits.get(key);
  return (t?.value as T) ?? fallback;
}

// ---------------------------------------------------------------------------
// Planning
// ---------------------------------------------------------------------------

function pickNextConcept(ctx: Ctx): number | null {
  const unmastered = ctx.order.filter((id) => !isMastered(ctx.beliefs.get(id)!));
  if (!unmastered.length) return null;
  for (const id of unmastered) {
    const prereqs = (ctx.prereqOf.get(id) ?? []).filter((p) => ctx.beliefs.has(p.id));
    const ready = prereqs.every((p) => ctx.beliefs.get(p.id)!.pKnown >= READY_THRESHOLD * p.strength || isMastered(ctx.beliefs.get(p.id)!));
    if (ready) return id;
  }
  return unmastered[0];
}

function pickReviewConcept(ctx: Ctx): number | null {
  const since = ctx.state.exercisesSinceBreak ?? 0;
  if (since % 6 !== 5) return null;
  const candidates = ctx.order
    .filter((id) => isMastered(ctx.beliefs.get(id)!) && id !== ctx.session.currentConceptId)
    .map((id) => ({ id, retention: retentionFactor(ctx.beliefs.get(id)!.lastEvidenceAt), minutes: (Date.now() - (ctx.beliefs.get(id)!.lastEvidenceAt?.getTime() ?? Date.now())) / 60_000 }))
    .filter((c) => c.retention < 0.98 || c.minutes >= 5)
    .sort((a, b) => a.retention - b.retention);
  return candidates[0]?.id ?? null;
}

function pickExercise(ctx: Ctx, concept: ConceptRow, purpose: "diagnostic" | "practice" | "review", opts: { easier?: boolean } = {}): Exercise | null {
  const list = concept.material.exercises ?? [];
  if (!list.length) return null;
  const attempted = new Set(Object.keys(ctx.state.conceptAttempts ?? {}).filter((k) => k.startsWith(`${concept.id}:`)).map((k) => k.split(":")[1]));
  const p = ctx.beliefs.get(concept.id)?.pKnown ?? 0.3;
  const target = purpose === "diagnostic" ? 0.45 : opts.easier ? Math.max(0.1, p - 0.25) : Math.min(0.9, p + 0.15);
  const scored = list
    .map((e) => ({ e, score: Math.abs(e.difficulty - target) + (attempted.has(e.id) ? 0.6 : 0) }))
    .sort((a, b) => a.score - b.score);
  return scored[0].e;
}

function normalize(s: string): string {
  return s
    .trim()
    .toLowerCase()
    .replace(/^["'`]+|["'`]+$/g, "")
    .replace(/\s+/g, " ")
    .replace(/[.]+$/g, "")
    .trim();
}

async function grade(exercise: Exercise, answer: string): Promise<{ correct: boolean; chosenKey: string; expected: string; viaLLM?: boolean }> {
  const a = answer.trim();
  if (exercise.type === "mcq" || exercise.type === "truefalse") {
    const opts = exercise.options ?? [];
    let idx = /^\d+$/.test(a) ? Number(a) : opts.findIndex((o) => normalize(o) === normalize(a));
    if (idx < 0 && /^[a-d]$/i.test(a)) idx = a.toLowerCase().charCodeAt(0) - 97;
    const expectedIdx = Number(exercise.answer);
    return { correct: idx === expectedIdx, chosenKey: String(idx), expected: opts[expectedIdx] ?? exercise.answer };
  }
  const n = normalize(a);
  const accepted = [exercise.answer, ...(exercise.accept ?? [])].map(normalize);
  if (accepted.includes(n)) return { correct: true, chosenKey: n, expected: exercise.answer };
  // tolerate trailing/leading whitespace differences inside code-like output
  if (accepted.some((x) => x.replace(/\s/g, "") === n.replace(/\s/g, "") && n.length > 0)) return { correct: true, chosenKey: n, expected: exercise.answer };
  if (hasLLM() && n.length > 0) {
    const res = await llmJson<{ correct: boolean }>(
      "You grade short answers for a tutoring system. Judge semantic equivalence strictly; formatting differences are fine, wrong meaning is not.",
      `Question: ${exercise.prompt}\n${exercise.code ? `Code:\n${exercise.code}\n` : ""}Expected: ${exercise.answer}\nAlso acceptable: ${(exercise.accept ?? []).join(" | ")}\nLearner answer: ${a}\n\nReturn {"correct": true|false}`,
      (r) => (typeof (r as { correct?: unknown }).correct === "boolean" ? (r as { correct: boolean }) : null),
      { maxTokens: 50 },
    );
    if (res.ok) return { correct: res.value.correct, chosenKey: n, expected: exercise.answer, viaLLM: true };
  }
  return { correct: false, chosenKey: n, expected: exercise.answer };
}

function misconceptionFor(exercise: Exercise, chosenKey: string): string | null {
  if (!exercise.misconceptions) return null;
  for (const [k, v] of Object.entries(exercise.misconceptions)) if (normalize(k) === normalize(chosenKey)) return v;
  return null;
}

// ---------------------------------------------------------------------------
// Content rendering
// ---------------------------------------------------------------------------

function renderLesson(ctx: Ctx, concept: ConceptRow, strategy: StrategyId): { text: string; strategy: StrategyId } {
  const ex = concept.material.explanations ?? {};
  let chosen = strategy;
  if (!ex[chosen]) chosen = (STRATEGIES.find((s) => ex[s]) ?? strategy) as StrategyId;
  let text = ex[chosen] ?? concept.summary;
  const verbosity = trait<string>(ctx, "verbosity", "detailed");
  if (verbosity === "concise" && text.length > 700) {
    const cut = text.slice(0, 700);
    text = cut.slice(0, Math.max(cut.lastIndexOf("\n"), cut.lastIndexOf(". ") + 1)) + "\n\n_(shortened — you've told me you prefer brevity; ask for more if you want it)_";
  }
  return { text, strategy: chosen };
}

async function teachConcept(ctx: Ctx, conceptId: number, reason: string, opts: { exclude?: StrategyId[]; switching?: boolean } = {}) {
  const concept = ctx.conceptMap.get(conceptId)!;
  const available = STRATEGIES.filter((s) => concept.material.explanations?.[s]);
  const used = (ctx.state.strategyHistory ?? []).filter((h) => h.conceptId === conceptId).map((h) => h.strategy as StrategyId);
  const exclude = [...(opts.exclude ?? []), ...used];
  const choice = await chooseStrategy(ctx.goal.learnerId, `domain:${ctx.domainSlug}`, { exclude, available: available.length ? available : undefined });
  const lesson = renderLesson(ctx, concept, choice.strategy);
  const belief = ctx.beliefs.get(conceptId)!;
  const decisionId = await decide(
    ctx,
    opts.switching ? "strategy_switch" : "select_strategy",
    opts.switching
      ? `Re-explaining "${concept.title}" with ${STRATEGY_LABELS[lesson.strategy]} (${choice.exploration ? "exploring" : "best-known"} for this learner; scope ${choice.scopeUsed}; est. success ${(choice.means[lesson.strategy] * 100).toFixed(0)}%). ${reason}`
      : `Teaching "${concept.title}" using ${STRATEGY_LABELS[lesson.strategy]} (${choice.exploration ? "exploring" : "best-known"} for this learner; scope ${choice.scopeUsed}; est. success ${(choice.means[lesson.strategy] * 100).toFixed(0)}%). ${reason}`,
    { conceptId, means: choice.means, exclude, pKnown: belief.pKnown },
    { strategy: lesson.strategy },
  );
  ctx.state.strategyHistory = [...(ctx.state.strategyHistory ?? []), { conceptId, strategy: lesson.strategy, at: new Date().toISOString(), decisionId }].slice(-40);
  ctx.state.lastLessonAt = new Date().toISOString();
  await emit(ctx, "agent", "lesson", { conceptId, title: concept.title, strategy: lesson.strategy, strategyLabel: STRATEGY_LABELS[lesson.strategy], text: lesson.text, keyPoints: concept.material.keyPoints ?? [], summary: concept.summary, sources: concept.material.sources ?? [], pKnown: belief.pKnown }, conceptId);
  ctx.session.currentConceptId = conceptId;
  ctx.session.strategy = lesson.strategy;
  await saveState(ctx, { currentConceptId: conceptId, strategy: lesson.strategy, phase: "teach" });
}

async function issueExercise(ctx: Ctx, conceptId: number, purpose: "diagnostic" | "practice" | "review", opts: { easier?: boolean; note?: string } = {}) {
  const concept = ctx.conceptMap.get(conceptId)!;
  const exercise = pickExercise(ctx, concept, purpose, opts);
  if (!exercise) {
    // No exercises available: treat a lesson as weak evidence and move on.
    await emit(ctx, "agent", "message", { text: `I don't have practice items for **${concept.title}** yet. Tell me in the chat what you understood, or say "next" and I'll continue.` }, conceptId);
    return null;
  }
  ctx.state.pendingExercise = { conceptId, exerciseId: exercise.id, issuedAt: new Date().toISOString(), strategy: ctx.session.strategy ?? undefined, purpose };
  await emit(ctx, "agent", "exercise", { conceptId, conceptTitle: concept.title, exerciseId: exercise.id, type: exercise.type, prompt: exercise.prompt, code: exercise.code ?? null, options: exercise.options ?? null, purpose, difficulty: exercise.difficulty, note: opts.note ?? null, hasHint: Boolean(exercise.hint || exercise.explanation) }, conceptId);
  await saveState(ctx);
  return exercise;
}

// ---------------------------------------------------------------------------
// Diagnostic phase (adaptive bisection over the topological order)
// ---------------------------------------------------------------------------

async function runDiagnosticStep(ctx: Ctx) {
  const st = ctx.state;
  if (st.diagnosticDone) return startTeaching(ctx, "Diagnostic complete.");
  if (st.diagLo === undefined) {
    st.diagLo = 0;
    st.diagHi = ctx.order.length - 1;
    st.diagProbes = 0;
    const interp = ctx.goal.interpretation;
    if (interp?.level === "beginner") {
      // Self-reported beginner: skip probing the foundations; still verify one early concept.
      st.diagHi = Math.min(st.diagHi, 1);
    }
    await emit(ctx, "agent", "message", {
      text: `Let's start with a quick check of what you already know about **${ctx.goal.subject}** so I can skip what you've got and focus on what you need. A few short questions — it's fine to guess or say you don't know. You can also skip this if you're brand new to the subject.`,
      actions: ["skip_diagnostic"],
    });
  }
  const maxProbes = Math.min(5, ctx.order.length);
  if (st.diagLo > st.diagHi! || st.diagProbes! >= maxProbes) {
    st.diagnosticDone = true;
    const known = ctx.order.filter((id) => ctx.beliefs.get(id)!.pKnown >= READY_THRESHOLD).length;
    await decide(ctx, "diagnose", `Diagnostic finished after ${st.diagProbes} probes: ${known} of ${ctx.order.length} relevant concepts look known (≥${READY_THRESHOLD * 100}%). Starting instruction at the first concept whose prerequisites are in place.`, {}, { known, total: ctx.order.length });
    await saveState(ctx);
    return startTeaching(ctx, "Based on the diagnostic, here is where we begin.");
  }
  const mid = Math.floor((st.diagLo + st.diagHi!) / 2);
  const conceptId = ctx.order[mid];
  st.diagIndex = mid;
  st.diagProbes!++;
  await saveState(ctx, { phase: "diagnose", currentConceptId: conceptId });
  const issued = await issueExercise(ctx, conceptId, "diagnostic", { note: `Diagnostic ${st.diagProbes}/${maxProbes}: ${ctx.conceptMap.get(conceptId)!.title}` });
  if (!issued) {
    st.diagHi = mid - 1;
    await saveState(ctx);
    return runDiagnosticStep(ctx);
  }
}

async function startTeaching(ctx: Ctx, intro: string) {
  ctx.state.diagnosticDone = true;
  const next = pickNextConcept(ctx);
  if (next === null) return completeGoal(ctx);
  const concept = ctx.conceptMap.get(next)!;
  const pre = (ctx.prereqOf.get(next) ?? []).map((p) => ctx.conceptMap.get(p.id)?.title).filter(Boolean);
  await decide(ctx, "select_concept", `${intro} Next concept: "${concept.title}" (mastery estimate ${(ctx.beliefs.get(next)!.pKnown * 100).toFixed(0)}%${pre.length ? `; prerequisites ${pre.join(", ")} judged ready` : ""}).`, {}, { conceptId: next });
  await db.update(goals).set({ status: "teaching", updatedAt: new Date() }).where(eq(goals.id, ctx.goal.id));
  await teachConcept(ctx, next, "");
  await issueExercise(ctx, next, "practice");
}

async function completeGoal(ctx: Ctx) {
  await db.update(goals).set({ status: "completed", updatedAt: new Date() }).where(eq(goals.id, ctx.goal.id));
  await saveState(ctx, { phase: "complete" });
  await emit(ctx, "agent", "message", { text: `You've demonstrated mastery of every target concept for **${ctx.goal.subject}**. 🎉 I'll keep your learner model, so if you come back for review or a related subject I'll start from what you already know. You can still ask me anything about this subject here.` });
}

// ---------------------------------------------------------------------------
// Answer handling
// ---------------------------------------------------------------------------

async function handleAnswer(ctx: Ctx, answer: string, latencyMs?: number) {
  const pending = ctx.state.pendingExercise;
  if (!pending) {
    await emit(ctx, "agent", "message", { text: "There's no open question right now — say **next** and I'll continue." });
    return;
  }
  const concept = ctx.conceptMap.get(pending.conceptId)!;
  const exercise = (concept.material.exercises ?? []).find((e) => e.id === pending.exerciseId)!;
  const result = await grade(exercise, answer);
  await recordLearnerTurn(ctx, "answer", { answer, exerciseId: exercise.id, latencyMs: latencyMs ?? null }, concept.id);
  const attemptsKey = `${concept.id}:${exercise.id}`;
  ctx.state.conceptAttempts = { ...(ctx.state.conceptAttempts ?? {}), [attemptsKey]: ((ctx.state.conceptAttempts ?? {})[attemptsKey] ?? 0) + 1 };
  ctx.state.exercisesSinceBreak = (ctx.state.exercisesSinceBreak ?? 0) + 1;
  ctx.state.pendingExercise = undefined;
  const hintUsed = Boolean(ctx.state.hintUsed);
  ctx.state.hintUsed = false;

  // --- evidence & belief update ---
  const ev = await recordEvidence({
    learnerId: ctx.goal.learnerId,
    goalId: ctx.goal.id,
    sessionId: ctx.session.id,
    conceptId: concept.id,
    correct: result.correct,
    exerciseType: exercise.type,
    purpose: pending.purpose as "diagnostic" | "practice" | "review",
    strategy: pending.strategy ?? null,
    payload: { exerciseId: exercise.id, answer, expected: result.expected, latencyMs: latencyMs ?? null, hintUsed, viaLLM: result.viaLLM ?? false },
  });
  ctx.beliefs = await ensureBeliefs(ctx.goal.learnerId, ctx.order);
  const recent = [...(ctx.state.recentOutcomes ?? []), { conceptId: concept.id, correct: result.correct, strategy: pending.strategy, at: new Date().toISOString() }].slice(-30);
  ctx.state.recentOutcomes = recent;
  const onConcept = recent.filter((r) => r.conceptId === concept.id);
  let wrongStreak = 0;
  for (let i = onConcept.length - 1; i >= 0 && !onConcept[i].correct; i--) wrongStreak++;
  let rightStreak = 0;
  for (let i = recent.length - 1; i >= 0 && recent[i].correct; i--) rightStreak++;

  // --- latency baseline trait ---
  const baseline = trait<number | null>(ctx, "response_baseline_ms", null);
  if (latencyMs && latencyMs > 500 && latencyMs < 600_000) {
    const nextBaseline = baseline ? baseline * 0.8 + latencyMs * 0.2 : latencyMs;
    await upsertTrait(ctx.goal.learnerId, "response_baseline_ms", Math.round(nextBaseline), 0.5, (ctx.traits.get("response_baseline_ms") ? 1 : 0) + 1, "Smoothed typical answer latency; used to detect hesitation or rushing.");
  }

  // --- affect ---
  const affectRes = await updateAffect(ctx.goal.learnerId, ctx.goal.id, ctx.session.id, [
    { type: "answer", correct: result.correct, latencyMs: latencyMs ?? null, baselineMs: baseline, wrongStreak, rightStreak, hintUsed },
    { type: "session", exercisesSinceBreak: ctx.state.exercisesSinceBreak, minutesActive: (Date.now() - ctx.session.startedAt.getTime()) / 60_000 },
  ]);
  ctx.affect = affectRes.affect;
  ctx.affectLabels = affectRes.labels;

  // --- strategy reward (first practice item after a lesson evaluates that lesson's strategy) ---
  const lastLesson = [...(ctx.state.strategyHistory ?? [])].reverse().find((h) => h.conceptId === concept.id);
  const isFirstAfterLesson = pending.purpose === "practice" && lastLesson && onConcept.filter((o) => o.at > lastLesson.at).length === 1;
  if (isFirstAfterLesson && pending.strategy) {
    await rewardStrategy(ctx.goal.learnerId, `domain:${ctx.domainSlug}`, pending.strategy as StrategyId, result.correct);
    // verify an earlier strategy switch
    const sw = await db.select().from(agentDecisions).where(and(eq(agentDecisions.id, lastLesson!.decisionId ?? -1), eq(agentDecisions.kind, "strategy_switch"))).limit(1);
    if (sw[0] && !sw[0].outcome) {
      await db.update(agentDecisions).set({ outcome: { worked: result.correct, verifiedAt: new Date().toISOString(), pAfter: ev.after } }).where(eq(agentDecisions.id, sw[0].id));
      await decide(ctx, "verify_adaptation", result.correct ? `Adaptation check: switching to ${STRATEGY_LABELS[pending.strategy as StrategyId]} for "${concept.title}" worked — the follow-up was correct. Raising this strategy's weight for you.` : `Adaptation check: switching to ${STRATEGY_LABELS[pending.strategy as StrategyId]} for "${concept.title}" did not work — follow-up still incorrect. Lowering its weight and trying a different angle.`, { decisionId: sw[0].id }, { worked: result.correct });
    }
  }

  // --- feedback turn ---
  const misconception = result.correct ? null : misconceptionFor(exercise, result.chosenKey);
  const propagatedText = ev.propagated.length
    ? ` Because this ${result.correct ? "builds on" : "depends on"} ${ev.propagated.map((p) => ctx.conceptMap.get(p.conceptId)?.title ?? "a prerequisite").join(", ")}, I've nudged ${ev.propagated.length > 1 ? "those estimates" : "that estimate"} ${ev.propagated[0].direction} too.`
    : "";
  await emit(
    ctx,
    "agent",
    "feedback",
    {
      correct: result.correct,
      expected: result.expected,
      explanation: exercise.explanation,
      misconception: misconception && !misconception.startsWith("concept:") ? misconception : null,
      conceptTitle: concept.title,
      pBefore: ev.before,
      pAfter: ev.after,
      propagated: ev.propagated,
      text: result.correct
        ? `${rightStreak >= 3 ? "Another one right. " : "Correct. "}${exercise.explanation} My estimate that you know **${concept.title}** moved from ${(ev.before * 100).toFixed(0)}% to ${(ev.after * 100).toFixed(0)}%.${propagatedText}`
        : `Not quite — the answer is **${result.expected}**. ${exercise.explanation}${misconception && !misconception.startsWith("concept:") ? ` (Common trap: ${misconception}.)` : ""} Estimate for **${concept.title}**: ${(ev.before * 100).toFixed(0)}% → ${(ev.after * 100).toFixed(0)}%.${propagatedText}`,
    },
    concept.id,
  );

  // --- diagnostic phase bookkeeping ---
  if (pending.purpose === "diagnostic" && !ctx.state.diagnosticDone) {
    const st = ctx.state;
    if (result.correct) st.diagLo = (st.diagIndex ?? 0) + 1;
    else st.diagHi = (st.diagIndex ?? 0) - 1;
    await saveState(ctx);
    return runDiagnosticStep(ctx);
  }

  // --- affect-driven policy ---
  if (ctx.affect.fatigue > 0.65 && !ctx.state.breakSuggested) {
    ctx.state.breakSuggested = true;
    await decide(ctx, "affect_response", `Fatigue signals are high (${(ctx.affect.fatigue * 100).toFixed(0)}%: ${ctx.affectLabels.join(", ") || "long session"}). Suggesting a break; everything is saved.`, { affect: ctx.affect }, {});
    await emit(ctx, "agent", "message", { text: `You've been at this for a while. A short break now will help retention more than one more exercise — your progress is saved and I'll pick up exactly here. Or say **next** to keep going.`, actions: ["take_break"] });
  }

  // --- next step ---
  const belief = ctx.beliefs.get(concept.id)!;
  if (pending.purpose === "review") {
    if (!result.correct) {
      await decide(ctx, "select_concept", `Review of "${concept.title}" failed — mastery estimate dropped to ${(belief.pKnown * 100).toFixed(0)}%. Re-teaching it briefly before continuing.`, {}, { conceptId: concept.id });
      await teachConcept(ctx, concept.id, "Refreshing after a missed review item.", { switching: true });
      return issueExercise(ctx, concept.id, "practice");
    }
    return continueTeaching(ctx, "Review passed.");
  }

  if (result.correct) {
    if (isMastered(belief)) {
      await emit(ctx, "agent", "message", { text: `That's enough evidence for me to mark **${concept.title}** as mastered (${(belief.pKnown * 100).toFixed(0)}%). Moving on.` }, concept.id);
      return continueTeaching(ctx, `"${concept.title}" mastered.`);
    }
    if (ctx.affect.engagement < 0.4 && rightStreak >= 3) {
      await decide(ctx, "affect_response", `Correct streak of ${rightStreak} with low engagement — this looks too easy. Skipping ahead with a harder diagnostic item instead of more practice here.`, { affect: ctx.affect }, {});
      const nextId = ctx.order.find((id, i) => i > ctx.order.indexOf(concept.id) && !isMastered(ctx.beliefs.get(id)!));
      if (nextId) {
        await saveState(ctx, { currentConceptId: nextId });
        return issueExercise(ctx, nextId, "diagnostic", { note: `Stretch check: ${ctx.conceptMap.get(nextId)!.title}` });
      }
    }
    return issueExercise(ctx, concept.id, "practice");
  }

  // Incorrect answer paths --------------------------------------------------
  const gapSlug = misconception?.startsWith("concept:") ? misconception.slice(8) : null;
  if (gapSlug) {
    const target = [...ctx.conceptMap.values()].find((c) => c.slug === gapSlug);
    if (target && ctx.beliefs.get(target.id) && ctx.beliefs.get(target.id)!.pKnown >= READY_THRESHOLD && ctx.beliefs.get(target.id)!.directEvidence >= 2) {
      // prerequisite already demonstrated: treat as ordinary error
    } else if (target) {
      await decide(ctx, "prereq_probe", `Your answer pattern points at a gap in "${target.title}" (a prerequisite of "${concept.title}"; current estimate ${((ctx.beliefs.get(target.id)?.pKnown ?? 0.3) * 100).toFixed(0)}%). Checking that directly before continuing.`, { misconception, conceptId: concept.id }, { probeConceptId: target.id });
      if (!ctx.beliefs.has(target.id)) ctx.beliefs = await ensureBeliefs(ctx.goal.learnerId, [...ctx.order, target.id]);
      if (!ctx.order.includes(target.id)) ctx.order.unshift(target.id);
      await saveState(ctx, { currentConceptId: target.id });
      return issueExercise(ctx, target.id, "diagnostic", { note: `Prerequisite check: ${target.title}` });
    } else {
      await emit(ctx, "system", "note", { text: `Detected a likely missing prerequisite ("${gapSlug.replace(/-/g, " ")}") that is not in the current concept graph. Investigating and extending the graph…`, kind: "extend_graph" });
      const disc = await discoverConcept(ctx.goal.domainId!, gapSlug, concept.id, `Learner's wrong answer on "${exercise.id}" (${concept.title}) indicates this missing prerequisite`).catch(async (e) => {
        await emit(ctx, "system", "note", { text: `Could not extend the graph right now (${e instanceof Error ? e.message : e}). Continuing with the current material; I'll retry if the pattern repeats.`, kind: "extend_graph" });
        return null;
      });
      if (disc) {
        const graph = await loadGraph(ctx.goal);
        ctx.conceptMap = graph.conceptMap;
        ctx.prereqOf = graph.prereqOf;
        ctx.order = graph.order;
        ctx.beliefs = await ensureBeliefs(ctx.goal.learnerId, ctx.order);
        await decide(ctx, "extend_graph", `Extended the concept graph with "${disc.title}" (source: ${disc.source}) as a prerequisite of "${concept.title}", because your error pattern matched a misconception rooted there. Teaching it now, then returning to "${concept.title}".`, { misconception }, { conceptId: disc.conceptId, source: disc.source });
        await teachConcept(ctx, disc.conceptId, "Filling the discovered gap.");
        return issueExercise(ctx, disc.conceptId, "practice");
      }
    }
  }

  if (wrongStreak >= 4) {
    const weakest = (ctx.prereqOf.get(concept.id) ?? [])
      .map((p) => ({ p, b: ctx.beliefs.get(p.id) }))
      .filter((x) => x.b && x.b.directEvidence < 3)
      .sort((a, b) => a.b!.pKnown - b.b!.pKnown)[0];
    if (weakest) {
      const pc = ctx.conceptMap.get(weakest.p.id)!;
      await decide(ctx, "prereq_probe", `${wrongStreak} consecutive misses on "${concept.title}" despite re-explanation. The most likely cause is a shaky prerequisite — probing "${pc.title}" (estimate ${(weakest.b!.pKnown * 100).toFixed(0)}%, ${weakest.b!.directEvidence} direct observations).`, { wrongStreak }, { probeConceptId: pc.id });
      await saveState(ctx, { currentConceptId: pc.id });
      return issueExercise(ctx, pc.id, "diagnostic", { note: `Prerequisite check: ${pc.title}` });
    }
  }

  if (wrongStreak >= 2 || ctx.affect.confusion > 0.6) {
    const usedHere = (ctx.state.strategyHistory ?? []).filter((h) => h.conceptId === concept.id).map((h) => h.strategy as StrategyId);
    const available = STRATEGIES.filter((s) => concept.material.explanations?.[s]);
    if (available.length && available.every((s) => usedHere.includes(s)) && wrongStreak >= 3) {
      // Every explanation style has been tried on this concept. Stop cycling: drop to the easiest item,
      // surface the key points, and be honest about it.
      const easiest = [...(concept.material.exercises ?? [])].sort((a, b) => a.difficulty - b.difficulty)[0];
      await decide(ctx, "strategy_exhausted", `I've now explained "${concept.title}" in every style I have (${available.map((s) => STRATEGY_LABELS[s]).join(", ")}) and it still isn't landing. Rather than repeat myself, I'm going to the simplest possible item and the key points, and I'll treat your next answers as a signal about whether something more basic is missing.`, { usedHere, wrongStreak }, { easiestExercise: easiest?.id ?? null });
      await emit(ctx, "agent", "message", { text: `Let's strip this down to the essentials for **${concept.title}**:\n\n${(concept.material.keyPoints ?? [concept.summary]).map((k) => `- ${k}`).join("\n")}\n\nTry this simpler one — and if a word in it is unfamiliar, ask me "what is …?" and I'll explain or look it up.` }, concept.id);
      return issueExercise(ctx, concept.id, "practice", { easier: true });
    }
    const reason = ctx.affect.frustration > 0.55 ? `Frustration is building (${(ctx.affect.frustration * 100).toFixed(0)}%), so I'm changing the explanation style rather than repeating the same one, and following up with an easier item.` : `${wrongStreak} misses in a row on this concept after a ${STRATEGY_LABELS[(usedHere.at(-1) ?? "concrete_example") as StrategyId]} explanation — that style isn't landing for this topic.`;
    await teachConcept(ctx, concept.id, reason, { switching: true, exclude: usedHere });
    return issueExercise(ctx, concept.id, "practice", { easier: ctx.affect.frustration > 0.55 });
  }

  return issueExercise(ctx, concept.id, "practice", { easier: wrongStreak >= 1 });
}

async function continueTeaching(ctx: Ctx, intro: string) {
  const review = pickReviewConcept(ctx);
  if (review !== null) {
    await decide(ctx, "select_concept", `${intro} Interleaving a review of "${ctx.conceptMap.get(review)!.title}" to protect retention before moving on.`, {}, { conceptId: review });
    await saveState(ctx, { currentConceptId: review });
    return issueExercise(ctx, review, "review", { note: `Quick review: ${ctx.conceptMap.get(review)!.title}` });
  }
  const next = pickNextConcept(ctx);
  if (next === null) return completeGoal(ctx);
  const concept = ctx.conceptMap.get(next)!;
  const notReady = (ctx.prereqOf.get(next) ?? []).filter((p) => ctx.beliefs.has(p.id) && ctx.beliefs.get(p.id)!.pKnown < READY_THRESHOLD * p.strength);
  await decide(ctx, "select_concept", `${intro} Next: "${concept.title}" (estimate ${(ctx.beliefs.get(next)!.pKnown * 100).toFixed(0)}%).${notReady.length ? ` Note: prerequisite ${notReady.map((p) => ctx.conceptMap.get(p.id)?.title).join(", ")} is below the readiness bar, but nothing easier remains, so I'll watch for gaps closely.` : ""}`, {}, { conceptId: next });
  await teachConcept(ctx, next, "");
  await issueExercise(ctx, next, "practice");
}

// ---------------------------------------------------------------------------
// Feedback / messages / hints
// ---------------------------------------------------------------------------

async function handleFeedback(ctx: Ctx, value: FeedbackValue) {
  await recordLearnerTurn(ctx, "feedback", { value }, ctx.session.currentConceptId);
  const affectRes = await updateAffect(ctx.goal.learnerId, ctx.goal.id, ctx.session.id, [{ type: "feedback", value }]);
  ctx.affect = affectRes.affect;
  const conceptId = ctx.session.currentConceptId;
  const concept = conceptId ? ctx.conceptMap.get(conceptId) : null;
  const strategy = ctx.session.strategy as StrategyId | null;
  const scope = `domain:${ctx.domainSlug}`;
  const usedHere = conceptId ? (ctx.state.strategyHistory ?? []).filter((h) => h.conceptId === conceptId).map((h) => h.strategy as StrategyId) : [];

  switch (value) {
    case "confused":
    case "not_helpful":
    case "too_hard": {
      if (strategy) await rewardStrategy(ctx.goal.learnerId, scope, strategy, false, 0.7);
      if (concept) {
        await teachConcept(ctx, concept.id, `You said the ${strategy ? STRATEGY_LABELS[strategy] : "previous"} explanation ${value === "too_hard" ? "was too hard" : "didn't help"}, so I'm trying a different angle instead of repeating it.`, { switching: true, exclude: usedHere });
        if (!ctx.state.pendingExercise) await issueExercise(ctx, concept.id, "practice", { easier: true });
      }
      break;
    }
    case "got_it":
    case "helpful": {
      if (strategy) await rewardStrategy(ctx.goal.learnerId, scope, strategy, true, 0.7);
      await emit(ctx, "agent", "message", { text: `Noted — ${strategy ? STRATEGY_LABELS[strategy].toLowerCase() + " explanations" : "that"} seem to work for you; I'll lean on that style more.${ctx.state.pendingExercise ? " Try the question when you're ready." : ""}` });
      if (!ctx.state.pendingExercise && concept) await issueExercise(ctx, concept.id, "practice");
      break;
    }
    case "too_easy": {
      const n = (ctx.traits.get("pace_feedback") ? ((ctx.traits.get("pace_feedback")!.value as { fast?: number }).fast ?? 0) : 0) + 1;
      await upsertTrait(ctx.goal.learnerId, "pace_feedback", { fast: n }, Math.min(0.9, 0.4 + n * 0.15), n, "Learner has asked for a faster pace / found material too easy.");
      await upsertTrait(ctx.goal.learnerId, "verbosity", "concise", Math.min(0.9, 0.4 + n * 0.15), n, "Learner finds material too easy; shortening explanations.");
      if (concept) {
        await decide(ctx, "affect_response", `You flagged "${concept.title}" as too easy. Instead of more practice I'll test it directly with the hardest item I have; pass it and we skip ahead.`, {}, { conceptId: concept.id });
        const hard = [...(concept.material.exercises ?? [])].sort((a, b) => b.difficulty - a.difficulty)[0];
        if (hard) {
          ctx.state.pendingExercise = { conceptId: concept.id, exerciseId: hard.id, issuedAt: new Date().toISOString(), strategy: strategy ?? undefined, purpose: "diagnostic" };
          await emit(ctx, "agent", "exercise", { conceptId: concept.id, conceptTitle: concept.title, exerciseId: hard.id, type: hard.type, prompt: hard.prompt, code: hard.code ?? null, options: hard.options ?? null, purpose: "diagnostic", difficulty: hard.difficulty, note: "Skip-ahead check", hasHint: true }, concept.id);
          await saveState(ctx);
        }
      }
      break;
    }
    case "too_slow":
    case "too_fast": {
      const key = value === "too_slow" ? "concise" : "detailed";
      const prev = ctx.traits.get("verbosity");
      const count = (prev ? 1 : 0) + 1;
      await upsertTrait(ctx.goal.learnerId, "verbosity", key, Math.min(0.9, 0.5 + count * 0.1), count, value === "too_slow" ? "Learner asked for a faster pace; explanations will be shortened." : "Learner asked for a slower pace; explanations will stay detailed and items will step up more gradually.");
      await emit(ctx, "agent", "message", { text: value === "too_slow" ? "Got it — I'll keep explanations shorter and move faster. Tell me if I overshoot." : "Understood — I'll slow down, keep explanations fuller, and raise difficulty more gradually." });
      break;
    }
    case "tired":
    case "frustrated": {
      await decide(ctx, "affect_response", value === "tired" ? "You said you're tired. Ending the push here is the right call — I'll shorten the remaining items and you can stop any time." : `You're frustrated. I'm stepping back: a different explanation style on "${concept?.title ?? "this topic"}" and an easier item so you can get a win before we go on.`, { affect: ctx.affect }, {});
      if (value === "frustrated" && concept) {
        if (strategy) await rewardStrategy(ctx.goal.learnerId, scope, strategy, false, 0.5);
        await teachConcept(ctx, concept.id, "Resetting after frustration.", { switching: true, exclude: usedHere });
        await issueExercise(ctx, concept.id, "practice", { easier: true });
      } else {
        await emit(ctx, "agent", "message", { text: "Take a break whenever you like — everything is saved. Say **next** when you're ready.", actions: ["take_break"] });
      }
      break;
    }
  }
  await saveState(ctx);
}

async function handleMessage(ctx: Ctx, text: string) {
  await recordLearnerTurn(ctx, "message", { text }, ctx.session.currentConceptId);
  const affectRes = await updateAffect(ctx.goal.learnerId, ctx.goal.id, ctx.session.id, [{ type: "text", text }]);
  ctx.affect = affectRes.affect;
  const t = text.trim();
  const lower = t.toLowerCase();

  // "I already know X"
  const knowMatch = lower.match(/\b(?:i (?:already )?know|i'?m (?:familiar|comfortable) with|i understand|skip)\s+(.+)$/);
  if (knowMatch) {
    const term = knowMatch[1].replace(/[.!?]$/, "").trim();
    const c = findConcept(ctx, term);
    if (c) {
      await recordSelfReport(ctx.goal.learnerId, ctx.goal.id, c.id, true, text);
      ctx.beliefs = await ensureBeliefs(ctx.goal.learnerId, ctx.order);
      await decide(ctx, "self_report", `You report already knowing "${c.title}". I've raised my estimate (now ${(ctx.beliefs.get(c.id)!.pKnown * 100).toFixed(0)}%) but recorded it as self-reported rather than demonstrated — one quick item will confirm it when we get there.`, { text }, { conceptId: c.id });
      return;
    }
  }

  // Questions about a term: "what is X", "explain X", "X?"
  const q = lower.match(/^(?:what(?:'s| is| are| does)|explain|tell me about|how do(?:es)? (?:i|you)?\s*(?:use)?|can you explain|why)\s+(.+?)\??$/) ?? (t.endsWith("?") && t.length < 80 ? [t, t.replace(/\?$/, "")] : null);
  if (q) {
    const term = q[1].replace(/^(a|an|the)\s+/, "").replace(/\s+(mean|work|works|do)$/, "").trim();
    const c = findConcept(ctx, term);
    if (c) {
      const exp = c.material.explanations ?? {};
      const style = (trait<{ preferred?: string }>(ctx, "explanation_style", {}).preferred as StrategyId | undefined) ?? "concrete_example";
      const body = exp[style] ?? exp.concrete_example ?? exp.formal_definition ?? c.summary;
      await emit(ctx, "agent", "message", { text: `**${c.title}** — ${c.summary}\n\n${body}${ctx.state.pendingExercise ? "\n\nThe open question is still waiting when you're ready." : ""}` }, c.id);
      return;
    }
    if (hasLLM()) {
      const res = await llmJson<{ answer: string }>(
        `You are a patient tutor for ${ctx.goal.subject}. Answer the learner's question in under 150 words, with one concrete example if helpful.`,
        `Question: ${t}\nCurrent topic: ${ctx.session.currentConceptId ? ctx.conceptMap.get(ctx.session.currentConceptId)?.title : "none"}\nReturn {"answer": "..."}`,
        (r) => (typeof (r as { answer?: unknown }).answer === "string" ? (r as { answer: string }) : null),
        { maxTokens: 600 },
      );
      if (res.ok) {
        await emit(ctx, "agent", "message", { text: res.value.answer });
        return;
      }
    }
    await emit(ctx, "system", "note", { text: `"${term}" isn't in the concept graph yet — investigating it so I can answer and remember it.`, kind: "extend_graph" });
    const disc = await discoverConcept(ctx.goal.domainId!, term, null, `Learner asked about "${term}"`).catch(async (e) => {
      await emit(ctx, "agent", "message", { text: `I tried to look that up but the research source is unavailable right now (${e instanceof Error ? e.message : e}). Ask again in a moment.` });
      return undefined;
    });
    if (disc === undefined) return;
    if (disc) {
      const [row] = await db.select().from(concepts).where(eq(concepts.id, disc.conceptId)).limit(1);
      const graph = await loadGraph(ctx.goal);
      ctx.conceptMap = graph.conceptMap;
      await decide(ctx, "extend_graph", `Researched "${disc.title}" (${disc.source}) in response to your question and added it to the graph as a discovered concept.`, { term }, { conceptId: disc.conceptId });
      await emit(ctx, "agent", "message", { text: `Here's what I found on **${row.title}**:\n\n${row.summary}\n\n${row.material.explanations?.formal_definition?.slice(0, 900) ?? ""}${row.material.sources?.length ? `\n\n_Source: ${row.material.sources[0]}_` : ""}` }, row.id);
    } else {
      await emit(ctx, "agent", "message", { text: `I couldn't find reliable material on "${term}" right now. Could you rephrase, or tell me what you were trying to do?` });
    }
    return;
  }

  if (/^(next|continue|go on|ok|okay|ready|yes|let'?s go)[.!]?$/.test(lower)) return handleNext(ctx);

  // Otherwise: acknowledge, using affect to respond
  const label = describeAffect(ctx.affect);
  if (label === "frustrated" || label === "confused") {
    if (ctx.session.currentConceptId) {
      const c = ctx.conceptMap.get(ctx.session.currentConceptId)!;
      const usedHere = (ctx.state.strategyHistory ?? []).filter((h) => h.conceptId === c.id).map((h) => h.strategy as StrategyId);
      await decide(ctx, "affect_response", `Your message reads as ${label} (${affectRes.labels.join(", ")}). Re-explaining "${c.title}" a different way and easing the next item.`, { text }, {});
      await teachConcept(ctx, c.id, "Responding to your message.", { switching: true, exclude: usedHere });
      if (!ctx.state.pendingExercise) await issueExercise(ctx, c.id, "practice", { easier: true });
      return;
    }
  }
  if (label === "fatigued") {
    await emit(ctx, "agent", "message", { text: "Sounds like a good moment to pause. Everything is saved; come back any time and we'll continue exactly here.", actions: ["take_break"] });
    return;
  }
  await emit(ctx, "agent", "message", { text: ctx.state.pendingExercise ? "Noted. The open question is above whenever you're ready — or ask me anything about the topic." : "Noted. Say **next** to continue, or ask me a question about the subject." });
}

function findConcept(ctx: Ctx, term: string): ConceptRow | null {
  const n = term.toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
  if (!n) return null;
  let best: { c: ConceptRow; score: number } | null = null;
  for (const c of ctx.conceptMap.values()) {
    const title = c.title.toLowerCase();
    const slugWords = c.slug.replace(/-/g, " ");
    let score = 0;
    if (title === n || slugWords === n) score = 3;
    else if (title.includes(n) || n.includes(title) || slugWords.includes(n)) score = 2;
    else {
      const words = n.split(" ").filter((w) => w.length > 3);
      const hit = words.filter((w) => title.includes(w) || slugWords.includes(w)).length;
      if (hit && hit >= Math.ceil(words.length / 2)) score = 1;
    }
    if (score && (!best || score > best.score)) best = { c, score };
  }
  return best?.c ?? null;
}

async function handleHint(ctx: Ctx) {
  const pending = ctx.state.pendingExercise;
  if (!pending) return emit(ctx, "agent", "message", { text: "No open question to hint at." });
  const concept = ctx.conceptMap.get(pending.conceptId)!;
  const exercise = (concept.material.exercises ?? []).find((e) => e.id === pending.exerciseId)!;
  ctx.state.hintUsed = true;
  await recordLearnerTurn(ctx, "hint", { exerciseId: exercise.id }, concept.id);
  await updateAffect(ctx.goal.learnerId, ctx.goal.id, ctx.session.id, [{ type: "hint" }]);
  const hint = exercise.hint ?? (concept.material.keyPoints?.[0] ? `Remember: ${concept.material.keyPoints[0]}` : concept.summary);
  await emit(ctx, "agent", "message", { text: `Hint: ${hint}` }, concept.id);
  await saveState(ctx);
}

async function handleSkipDiagnostic(ctx: Ctx, level: "beginner" | "knows_basics") {
  await recordLearnerTurn(ctx, "message", { text: level === "beginner" ? "I'm a complete beginner" : "I know the basics" });
  for (const id of ctx.order) {
    const c = ctx.conceptMap.get(id)!;
    if (level === "beginner") await recordSelfReport(ctx.goal.learnerId, ctx.goal.id, id, false, "self-reported beginner");
    else if (c.role === "prerequisite") await recordSelfReport(ctx.goal.learnerId, ctx.goal.id, id, true, "self-reported: knows the basics");
  }
  ctx.beliefs = await ensureBeliefs(ctx.goal.learnerId, ctx.order);
  ctx.state.diagnosticDone = true;
  ctx.state.pendingExercise = undefined;
  await decide(ctx, "diagnose", level === "beginner" ? "You told me you're new to this, so I'm skipping the diagnostic, setting low priors everywhere, and starting from the foundations. Your answers will correct me quickly if you know more than you think." : "You told me you know the basics. I've raised estimates for foundational concepts (as self-reported, not demonstrated) and will verify with a quick item before relying on them.", { level }, {});
  await saveState(ctx);
  return startTeaching(ctx, "Let's begin.");
}

async function handleNext(ctx: Ctx) {
  if (ctx.session.phase === "complete") return emit(ctx, "agent", "message", { text: "This goal is complete — ask me anything about it, or start a new goal." });
  if (!ctx.state.diagnosticDone) return runDiagnosticStep(ctx);
  if (ctx.state.pendingExercise) {
    const c = ctx.conceptMap.get(ctx.state.pendingExercise.conceptId)!;
    return emit(ctx, "agent", "message", { text: `There's an open question on **${c.title}** above — answer it (guessing is fine) so I can update my model, or ask for a hint.` });
  }
  if (ctx.session.currentConceptId && !isMastered(ctx.beliefs.get(ctx.session.currentConceptId) ?? { pKnown: 1, directEvidence: 9 })) return issueExercise(ctx, ctx.session.currentConceptId, "practice");
  return continueTeaching(ctx, "Continuing.");
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

export async function tutorTurn(goalId: number, action: LearnerAction): Promise<TurnResult> {
  const [goal] = await db.select().from(goals).where(eq(goals.id, goalId)).limit(1);
  if (!goal) throw new Error("goal not found");
  if (!goal.domainId) throw new Error("goal has no domain yet");
  const [domain] = await db.select().from(domains).where(eq(domains.id, goal.domainId)).limit(1);
  const session = await getOrCreateSession(goal);
  const graph = await loadGraph(goal);
  const beliefs = await ensureBeliefs(goal.learnerId, graph.order);
  const traitRows = await getTraits(goal.learnerId);
  const { latestAffect } = await import("./affect");
  const ctx: Ctx = {
    goal,
    session,
    state: { ...(session.state ?? {}) },
    conceptMap: graph.conceptMap,
    order: graph.order,
    prereqOf: graph.prereqOf,
    beliefs,
    domainSlug: domain.slug,
    out: [],
    affect: await latestAffect(goal.learnerId),
    affectLabels: [],
    traits: new Map(traitRows.map((t) => [t.key, { value: t.value, confidence: t.confidence }])),
  };

  switch (action.type) {
    case "start": {
      const existing = await db.select({ id: turns.id }).from(turns).where(eq(turns.sessionId, session.id)).limit(1);
      if (!existing.length) {
        if (session.phase === "complete") await emit(ctx, "agent", "message", { text: `Welcome back. This goal is complete; ask me anything or start a new one.` });
        else if (ctx.state.diagnosticDone) {
          const mastered = ctx.order.filter((id) => isMastered(ctx.beliefs.get(id)!)).length;
          await emit(ctx, "agent", "message", { text: `Welcome back — ${mastered} of ${ctx.order.length} concepts mastered so far. Picking up where we left off.` });
          await continueTeaching(ctx, "Resuming from your last session.");
        } else await runDiagnosticStep(ctx);
      } else if (!ctx.state.pendingExercise && session.phase !== "complete") {
        await emit(ctx, "agent", "message", { text: `Welcome back — picking up where we left off.` });
        await handleNext(ctx);
      }
      break;
    }
    case "next":
      await handleNext(ctx);
      break;
    case "answer":
      await handleAnswer(ctx, action.answer, action.latencyMs);
      break;
    case "feedback":
      await handleFeedback(ctx, action.value);
      break;
    case "message":
      await handleMessage(ctx, action.text);
      break;
    case "hint":
      await handleHint(ctx);
      break;
    case "skip_diagnostic":
      await handleSkipDiagnostic(ctx, action.level);
      break;
    case "take_break": {
      await recordLearnerTurn(ctx, "message", { text: "taking a break" });
      await db.update(sessions).set({ endedAt: new Date(), state: ctx.state }).where(eq(sessions.id, session.id));
      await emit(ctx, "agent", "message", { text: "Session saved. See you soon." });
      break;
    }
  }
  await saveState(ctx);
  return { turns: ctx.out, session: ctx.session, affect: ctx.affect, affectLabel: describeAffect(ctx.affect) };
}

export { MASTERY_THRESHOLD, READY_THRESHOLD, asc };
