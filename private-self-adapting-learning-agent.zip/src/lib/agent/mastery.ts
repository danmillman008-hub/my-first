/**
 * Mastery beliefs: Bayesian Knowledge Tracing (Corbett & Anderson, 1995) for the
 * point estimate, plus Beta pseudo-counts so we can report *uncertainty* and
 * distinguish "demonstrated" from "inferred" from "prior" knowledge.
 *
 * Prerequisite inference: success on a concept is weak evidence for its
 * prerequisites (you rarely apply a concept without its foundations); failure
 * on a concept is weak evidence *against* poorly-evidenced prerequisites, and
 * repeated failure triggers an explicit probe.
 */
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { concepts, evidenceEvents, masteryBeliefs, prerequisites } from "@/db/schema";

export const MASTERY_THRESHOLD = 0.85;
export const READY_THRESHOLD = 0.6; // prerequisite level needed before teaching a concept

export type BeliefRow = typeof masteryBeliefs.$inferSelect;

export function priorForDifficulty(difficulty: number): number {
  return Math.max(0.05, Math.min(0.5, 0.4 - 0.3 * difficulty));
}

export function bktUpdate(pKnown: number, correct: boolean, opts: { guess: number; slip: number; transit: number }): number {
  const { guess, slip, transit } = opts;
  const pCorrectGivenKnown = 1 - slip;
  const pCorrectGivenUnknown = guess;
  const posterior = correct
    ? (pKnown * pCorrectGivenKnown) / (pKnown * pCorrectGivenKnown + (1 - pKnown) * pCorrectGivenUnknown)
    : (pKnown * slip) / (pKnown * slip + (1 - pKnown) * (1 - guess));
  // learning opportunity: the learner may have learned from feedback
  return posterior + (1 - posterior) * transit;
}

export function bktParams(exerciseType: string, purpose: "diagnostic" | "practice" | "review"): { guess: number; slip: number; transit: number } {
  const guess = exerciseType === "mcq" ? 0.25 : exerciseType === "truefalse" ? 0.5 : 0.08;
  const slip = 0.1;
  const transit = purpose === "practice" ? 0.12 : purpose === "review" ? 0.05 : 0.0;
  return { guess, slip, transit };
}

/** Uncertainty in [0,1]: 1 = nothing known, 0 = very sure. Based on Beta std-dev scaled. */
export function uncertainty(alpha: number, beta: number): number {
  const n = alpha + beta;
  const variance = (alpha * beta) / (n * n * (n + 1));
  // Beta(1,1) has sd 0.289; normalise so the prior is ~1.0
  return Math.min(1, Math.sqrt(variance) / 0.2887);
}

export function isMastered(b: { pKnown: number; directEvidence: number }): boolean {
  return b.pKnown >= MASTERY_THRESHOLD && b.directEvidence >= 2;
}

export async function ensureBeliefs(learnerId: number, conceptIds: number[]): Promise<Map<number, BeliefRow>> {
  if (!conceptIds.length) return new Map();
  const existing = await db
    .select()
    .from(masteryBeliefs)
    .where(and(eq(masteryBeliefs.learnerId, learnerId), inArray(masteryBeliefs.conceptId, conceptIds)));
  const map = new Map(existing.map((b) => [b.conceptId, b]));
  const missing = conceptIds.filter((id) => !map.has(id));
  if (missing.length) {
    const rows = await db.select({ id: concepts.id, difficulty: concepts.difficulty }).from(concepts).where(inArray(concepts.id, missing));
    const inserted = await db
      .insert(masteryBeliefs)
      .values(rows.map((r) => ({ learnerId, conceptId: r.id, pKnown: priorForDifficulty(r.difficulty), alpha: 1, beta: 1, basis: "prior" })))
      .onConflictDoNothing()
      .returning();
    for (const b of inserted) map.set(b.conceptId, b);
  }
  return map;
}

export type EvidenceInput = {
  learnerId: number;
  goalId: number | null;
  sessionId: number | null;
  conceptId: number;
  correct: boolean;
  exerciseType: string;
  purpose: "diagnostic" | "practice" | "review";
  strategy?: string | null;
  payload?: Record<string, unknown>;
};

export type EvidenceOutcome = {
  before: number;
  after: number;
  belief: BeliefRow;
  propagated: Array<{ conceptId: number; before: number; after: number; direction: "up" | "down" }>;
};

/** Record direct evidence, update the belief, and propagate to prerequisites. */
export async function recordEvidence(input: EvidenceInput): Promise<EvidenceOutcome> {
  const beliefs = await ensureBeliefs(input.learnerId, [input.conceptId]);
  const belief = beliefs.get(input.conceptId)!;
  const before = belief.pKnown;
  const params = bktParams(input.exerciseType, input.purpose);
  const after = bktUpdate(before, input.correct, params);
  const now = new Date();
  const [updated] = await db
    .update(masteryBeliefs)
    .set({
      pKnown: after,
      alpha: belief.alpha + (input.correct ? 1 : 0),
      beta: belief.beta + (input.correct ? 0 : 1),
      directEvidence: belief.directEvidence + 1,
      basis: "demonstrated",
      lastEvidenceAt: now,
      updatedAt: now,
    })
    .where(eq(masteryBeliefs.id, belief.id))
    .returning();
  await db.insert(evidenceEvents).values({
    learnerId: input.learnerId,
    goalId: input.goalId,
    sessionId: input.sessionId,
    conceptId: input.conceptId,
    kind: input.purpose === "diagnostic" ? "diagnostic" : "exercise",
    correct: input.correct,
    strategy: input.strategy ?? null,
    payload: input.payload ?? {},
    pBefore: before,
    pAfter: after,
  });

  // --- Propagation to prerequisites ---
  const propagated: EvidenceOutcome["propagated"] = [];
  const prereqRows = await db
    .select({ prerequisiteId: prerequisites.prerequisiteId, strength: prerequisites.strength })
    .from(prerequisites)
    .where(eq(prerequisites.conceptId, input.conceptId));
  if (prereqRows.length) {
    const prereqBeliefs = await ensureBeliefs(
      input.learnerId,
      prereqRows.map((p) => p.prerequisiteId),
    );
    for (const p of prereqRows) {
      const pb = prereqBeliefs.get(p.prerequisiteId);
      if (!pb) continue;
      // Do not override strong direct evidence with inference.
      if (pb.directEvidence >= 3) continue;
      let next = pb.pKnown;
      if (input.correct && after > 0.5) {
        next = pb.pKnown + (1 - pb.pKnown) * 0.2 * p.strength;
      } else if (!input.correct && pb.directEvidence === 0) {
        next = pb.pKnown - pb.pKnown * 0.08 * p.strength;
      } else {
        continue;
      }
      await db
        .update(masteryBeliefs)
        .set({
          pKnown: next,
          inferredEvidence: pb.inferredEvidence + 1,
          basis: pb.directEvidence > 0 ? pb.basis : "inferred",
          updatedAt: now,
        })
        .where(eq(masteryBeliefs.id, pb.id));
      await db.insert(evidenceEvents).values({
        learnerId: input.learnerId,
        goalId: input.goalId,
        sessionId: input.sessionId,
        conceptId: p.prerequisiteId,
        kind: "inference",
        correct: input.correct,
        payload: { from: input.conceptId, reason: input.correct ? "success on dependent concept" : "failure on dependent concept" },
        pBefore: pb.pKnown,
        pAfter: next,
      });
      propagated.push({ conceptId: p.prerequisiteId, before: pb.pKnown, after: next, direction: next > pb.pKnown ? "up" : "down" });
    }
  }

  return { before, after, belief: updated, propagated };
}

/** Self-report evidence ("I already know X" / "I'm a complete beginner"). Weaker than demonstrated. */
export async function recordSelfReport(learnerId: number, goalId: number | null, conceptId: number, knows: boolean, note: string) {
  const beliefs = await ensureBeliefs(learnerId, [conceptId]);
  const b = beliefs.get(conceptId)!;
  const after = knows ? Math.max(b.pKnown, 0.65) : Math.min(b.pKnown, 0.15);
  await db
    .update(masteryBeliefs)
    .set({ pKnown: after, inferredEvidence: b.inferredEvidence + 1, basis: b.directEvidence > 0 ? b.basis : "inferred", updatedAt: new Date() })
    .where(eq(masteryBeliefs.id, b.id));
  await db.insert(evidenceEvents).values({ learnerId, goalId, conceptId, kind: "self_report", correct: knows, payload: { note }, pBefore: b.pKnown, pAfter: after });
  return { before: b.pKnown, after };
}

/** Time-based decay for review scheduling: how much we should discount an old mastery estimate. */
export function retentionFactor(lastEvidenceAt: Date | null, now = new Date()): number {
  if (!lastEvidenceAt) return 1;
  const days = (now.getTime() - lastEvidenceAt.getTime()) / 86_400_000;
  return Math.exp(-days / 14); // half-life ≈ 10 days
}
