/**
 * Goal understanding + domain model construction.
 *
 * Pipeline: interpret goal -> resolve domain (existing / curated expertise /
 * LLM synthesis grounded in research / pure research) -> persist concepts &
 * prerequisite edges with provenance -> pick target concepts for the goal.
 *
 * Also provides `discoverConcept`, which extends an existing graph when a gap is
 * detected (latent knowledge -> LLM -> web research, in that order).
 */
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { agentDecisions, concepts, domains, goals, prerequisites, type ConceptMaterial, type Exercise, type GoalInterpretation, type Provenance, type ResearchLogEntry, type StrategyId } from "@/db/schema";
import { hasLLM, llmJson } from "./intelligence";
import { researchConcept, researchSubject, ResearchUnavailableError, slugify, synthesizeExercises, synthesizeExplanations, type ResearchResult } from "./research";
import { bashPack } from "./packs/bash";
import { oopPack } from "./packs/oop";
import type { KnowledgePack, LatentConcept } from "./packs/types";
import { STRATEGIES } from "./strategy";

export const PACKS: KnowledgePack[] = [bashPack, oopPack];

// ---------------------------------------------------------------------------
// Goal interpretation
// ---------------------------------------------------------------------------

const LEVEL_PATTERNS: Array<[RegExp, GoalInterpretation["level"]]> = [
  [/\b(complete|total|absolute)?\s*(beginner|newbie|from scratch|never (used|done|written)|no experience|know nothing)\b/i, "beginner"],
  [/\b(intermediate|some experience|familiar with|already know (the )?basics|used it before|refresh)\b/i, "intermediate"],
  [/\b(advanced|expert|deep dive|master|in depth|internals)\b/i, "advanced"],
];

export function interpretGoalHeuristically(raw: string): GoalInterpretation {
  const text = raw.trim();
  let subject = text
    .replace(/^(i('| a)?m|i)\s+(want|would like|need|wanna|'d like)\s+to\s+(learn|understand|study|master|get better at|pick up)\s+/i, "")
    .replace(/^(teach|show|help)\s+me\s+(about\s+|to\s+)?(learn\s+)?/i, "")
    .replace(/^(learn|understand|study|master)\s+/i, "")
    .replace(/^(about|the basics of|basics of|fundamentals of|how to (use|write|do|program in|get started with|work with|start)|how to)\s+/i, "")
    .replace(/[.!?]+$/g, "")
    .trim();
  const focus: string[] = [];
  const focusMatch = subject.match(/\b(?:especially|focus(?:ing)? on|particularly|mainly|specifically)\s+(.+)$/i);
  if (focusMatch) {
    focus.push(...focusMatch[1].split(/,|\band\b/).map((s) => s.trim()).filter(Boolean));
    subject = subject.slice(0, focusMatch.index).trim();
  }
  const levelClause = subject.match(/\b(?:as a|i'?m a|i am a|from|,)\s*(complete beginner|beginner|intermediate|advanced|expert|scratch).*$/i);
  if (levelClause) subject = subject.slice(0, levelClause.index).trim().replace(/,$/, "");
  // trailing self-description: "..., I already know the basics" / "but I've never used a terminal"
  const selfClause = subject.match(/(?:[,;]|\s+(?:but|because|since|although|though|and))\s+(?:i|i'm|i've|i am|i have|my|we)\b.*$/i);
  if (selfClause) subject = subject.slice(0, selfClause.index).trim();
  subject = subject.replace(/\s+(please|now|today|quickly|fast)$/i, "").replace(/[,;:]+$/, "").trim();
  subject = subject.replace(/\s+/g, " ").replace(/^["']|["']$/g, "");
  let level: GoalInterpretation["level"] = "unknown";
  for (const [re, lvl] of LEVEL_PATTERNS) if (re.test(text)) level = lvl;
  return { subject: subject || text, level, focus, notes: "heuristic interpretation", confidence: subject && subject !== text ? 0.75 : 0.5 };
}

export async function interpretGoal(raw: string): Promise<GoalInterpretation> {
  const heuristic = interpretGoalHeuristically(raw);
  if (!hasLLM()) return heuristic;
  const res = await llmJson<GoalInterpretation>(
    "You interpret a learner's natural-language learning objective for an adaptive tutoring system.",
    `Learning request: """${raw}"""\n\nReturn JSON: {"subject": short canonical subject name, "level": "beginner"|"intermediate"|"advanced"|"unknown", "focus": [specific sub-topics they asked for], "notes": one sentence about what they seem to want, "confidence": 0..1}`,
    (r) => {
      const o = r as Partial<GoalInterpretation>;
      if (!o || typeof o.subject !== "string") return null;
      return { subject: o.subject, level: (o.level as GoalInterpretation["level"]) ?? "unknown", focus: Array.isArray(o.focus) ? o.focus.map(String) : [], notes: String(o.notes ?? ""), confidence: Number(o.confidence ?? 0.7) };
    },
    { maxTokens: 400 },
  );
  return res.ok ? res.value : heuristic;
}

// ---------------------------------------------------------------------------
// Domain resolution
// ---------------------------------------------------------------------------

export function matchPack(subject: string): KnowledgePack | null {
  const s = subject.toLowerCase().replace(/[^a-z0-9 +#-]/g, " ").replace(/\s+/g, " ").trim();
  for (const pack of PACKS) {
    for (const alias of pack.aliases) {
      const a = alias.toLowerCase();
      if (s === a || new RegExp(`(^|\\s)${a.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}($|\\s)`).test(s)) return pack;
    }
  }
  return null;
}

type DomainBuild = { domainId: number; created: boolean; log: ResearchLogEntry[]; conceptCount: number; origin: string };

export class NoMaterialError extends Error {
  constructor(msg: string) {
    super(msg);
    this.name = "NoMaterialError";
  }
}
export { ResearchUnavailableError };

async function logDecision(learnerId: number | null, goalId: number | null, kind: string, rationale: string, inputs: Record<string, unknown> = {}, outputs: Record<string, unknown> = {}) {
  const [row] = await db.insert(agentDecisions).values({ learnerId, goalId, kind, rationale, inputs, outputs }).returning({ id: agentDecisions.id });
  return row.id;
}

/** Resolve or build the domain model for an interpreted goal. */
export async function buildDomain(interp: GoalInterpretation, ctx: { learnerId: number; goalId: number }): Promise<DomainBuild> {
  const pack = matchPack(interp.subject);
  const slug = pack ? pack.slug : slugify(interp.subject);

  const existing = await db.select().from(domains).where(eq(domains.slug, slug)).limit(1);
  if (existing[0]) {
    const count = await db.select({ id: concepts.id }).from(concepts).where(eq(concepts.domainId, existing[0].id));
    if (count.length >= 3) {
      await logDecision(ctx.learnerId, ctx.goalId, "build_graph", `Reusing existing domain model "${existing[0].title}" (${count.length} concepts, origin: ${existing[0].origin}). No new research required.`, { subject: interp.subject }, { domainId: existing[0].id });
      return { domainId: existing[0].id, created: false, log: existing[0].researchLog, conceptCount: count.length, origin: existing[0].origin };
    }
    await db.delete(domains).where(eq(domains.id, existing[0].id));
  }

  if (pack) {
    const build = await persistPack(pack);
    await logDecision(ctx.learnerId, ctx.goalId, "build_graph", `Subject "${interp.subject}" matches curated expertise "${pack.title}". Built graph with ${build.conceptCount} concepts; ${pack.latent.length} latent concepts held in reserve for gap discovery.`, { subject: interp.subject }, { domainId: build.domainId });
    return build;
  }

  // Unknown subject: investigate.
  const research = await researchSubject(interp.subject, interp.focus);
  let build: DomainBuild | null = null;
  if (hasLLM()) build = await synthesizeWithLLM(interp, research, slug);
  if (!build && research.concepts.length === 0) {
    await logDecision(ctx.learnerId, ctx.goalId, "research", `Investigated "${interp.subject}" but found no usable reference material (${research.log.map((l) => l.detail).slice(-2).join("; ")}). Not creating a curriculum from nothing.`, { subject: interp.subject }, {});
    throw new NoMaterialError(`I couldn't find reference material for "${interp.subject}". Try naming the subject more specifically (e.g. "Python programming", "cooking Italian pasta").`);
  }
  if (!build) build = await persistResearch(interp, research, slug);
  await logDecision(
    ctx.learnerId,
    ctx.goalId,
    "research",
    build.origin === "llm"
      ? `No prior expertise for "${interp.subject}". Researched the subject (${research.log.length} research steps) and synthesized a curriculum with the LLM grounded in those findings.`
      : `No prior expertise for "${interp.subject}". Investigated Wikipedia ("${research.canonicalTitle ?? "no article"}"), extracted ${research.concepts.length} concept candidates and ${research.prerequisitePairs.length} dependency edges, and generated diagnostic items from the researched text.`,
    { subject: interp.subject },
    { domainId: build.domainId, conceptCount: build.conceptCount },
  );
  return build;
}

async function persistPack(pack: KnowledgePack): Promise<DomainBuild> {
  const log: ResearchLogEntry[] = [
    { at: new Date().toISOString(), step: "resolve", source: "curated", detail: `Matched curated expertise "${pack.title}" (${pack.concepts.length} concepts, ${pack.latent.length} latent)` },
  ];
  const [domain] = await db.insert(domains).values({ slug: pack.slug, title: pack.title, description: pack.description, origin: "curated", researchLog: log }).returning();
  const idBySlug = new Map<string, number>();
  for (const c of pack.concepts) {
    const material: ConceptMaterial = { explanations: c.explanations, exercises: c.exercises, keyPoints: c.keyPoints, sources: ["curated"] };
    const [row] = await db
      .insert(concepts)
      .values({ domainId: domain.id, slug: c.slug, title: c.title, summary: c.summary, difficulty: c.difficulty, role: c.role, tags: c.tags, material, provenance: { source: "curated", at: new Date().toISOString() } })
      .returning({ id: concepts.id });
    idBySlug.set(c.slug, row.id);
  }
  for (const c of pack.concepts) {
    for (const p of c.prereqs) {
      const pid = idBySlug.get(p);
      if (pid) await db.insert(prerequisites).values({ conceptId: idBySlug.get(c.slug)!, prerequisiteId: pid, strength: 0.85, provenance: { source: "curated" } }).onConflictDoNothing();
    }
  }
  return { domainId: domain.id, created: true, log, conceptCount: pack.concepts.length, origin: "curated" };
}

async function persistResearch(interp: GoalInterpretation, research: ResearchResult, slug: string): Promise<DomainBuild> {
  const log = [...research.log];
  const title = research.canonicalTitle ?? interp.subject;
  const [domain] = await db
    .insert(domains)
    .values({ slug, title, description: research.description || `Learning ${interp.subject}`, origin: "research", researchLog: log })
    .returning();

  if (research.concepts.length === 0) {
    // Absolute fallback so the learner is never stuck: a single overview concept.
    log.push({ at: new Date().toISOString(), step: "fallback", source: "agent", detail: "Research produced no structure; creating an overview concept and flagging the domain for extension." });
    await db.insert(concepts).values({
      domainId: domain.id,
      slug: "overview",
      title: `${interp.subject}: overview`,
      summary: `An introduction to ${interp.subject}.`,
      difficulty: 0.3,
      role: "core",
      tags: ["fallback"],
      material: { explanations: { formal_definition: `We could not find reference material for "${interp.subject}" automatically. Ask a question in the chat and the agent will investigate specific terms.` }, exercises: [] },
      provenance: { source: "agent", reason: "research-fallback" },
    });
    await db.update(domains).set({ researchLog: log }).where(eq(domains.id, domain.id));
    return { domainId: domain.id, created: true, log, conceptCount: 1, origin: "research" };
  }

  const idBySlug = new Map<string, number>();
  const cores = research.concepts.filter((c) => c.role === "core");
  for (const c of research.concepts) {
    const siblings = research.concepts.filter((x) => x.role === c.role);
    const exercises = synthesizeExercises(c, siblings.length >= 3 ? siblings : research.concepts);
    const explanations = synthesizeExplanations(c, interp.subject);
    const difficulty = c.role === "prerequisite" ? 0.2 : Math.min(0.9, 0.3 + (0.5 * (c.order + 1)) / Math.max(1, cores.length));
    const [row] = await db
      .insert(concepts)
      .values({
        domainId: domain.id,
        slug: c.slug,
        title: c.title,
        summary: c.summary,
        difficulty,
        role: c.role,
        tags: ["researched"],
        material: { explanations, exercises, keyPoints: [], sources: [c.sourceRef] },
        provenance: { source: "wikipedia", ref: c.sourceRef, at: new Date().toISOString() },
      })
      .onConflictDoNothing()
      .returning({ id: concepts.id });
    if (row) idBySlug.set(c.slug, row.id);
  }
  for (const p of research.prerequisitePairs) {
    const a = idBySlug.get(p.concept);
    const b = idBySlug.get(p.prerequisite);
    if (a && b && a !== b) await db.insert(prerequisites).values({ conceptId: a, prerequisiteId: b, strength: p.reason.includes("sequential") ? 0.5 : 0.75, provenance: { source: "inference", reason: p.reason } }).onConflictDoNothing();
  }
  await db.update(domains).set({ researchLog: log }).where(eq(domains.id, domain.id));
  return { domainId: domain.id, created: true, log, conceptCount: idBySlug.size, origin: "research" };
}

type LLMCurriculum = {
  title: string;
  description: string;
  concepts: Array<{
    slug: string;
    title: string;
    summary: string;
    difficulty: number;
    role: "core" | "prerequisite";
    prereqs: string[];
    keyPoints: string[];
    explanations: Partial<Record<StrategyId, string>>;
    exercises: Exercise[];
  }>;
};

function validateCurriculum(raw: unknown): LLMCurriculum | null {
  const o = raw as LLMCurriculum;
  if (!o || !Array.isArray(o.concepts) || o.concepts.length < 3) return null;
  const out: LLMCurriculum = { title: String(o.title ?? ""), description: String(o.description ?? ""), concepts: [] };
  for (const c of o.concepts) {
    if (!c || typeof c.title !== "string") continue;
    const slug = slugify(c.slug || c.title);
    const exercises: Exercise[] = Array.isArray(c.exercises)
      ? c.exercises
          .filter((e) => e && typeof e.prompt === "string" && typeof e.answer === "string")
          .map((e, i) => ({
            id: `${slug}-${i}`,
            type: (["mcq", "short", "predict", "truefalse"] as const).includes(e.type) ? e.type : "short",
            prompt: e.prompt,
            code: e.code,
            options: Array.isArray(e.options) ? e.options.map(String) : undefined,
            answer: String(e.answer),
            accept: Array.isArray(e.accept) ? e.accept.map(String) : undefined,
            explanation: String(e.explanation ?? ""),
            difficulty: Number.isFinite(e.difficulty) ? Number(e.difficulty) : 0.5,
            misconceptions: e.misconceptions && typeof e.misconceptions === "object" ? e.misconceptions : undefined,
            hint: e.hint,
          }))
      : [];
    out.concepts.push({
      slug,
      title: c.title,
      summary: String(c.summary ?? ""),
      difficulty: Number.isFinite(c.difficulty) ? Math.max(0, Math.min(1, Number(c.difficulty))) : 0.5,
      role: c.role === "prerequisite" ? "prerequisite" : "core",
      prereqs: Array.isArray(c.prereqs) ? c.prereqs.map((p) => slugify(String(p))) : [],
      keyPoints: Array.isArray(c.keyPoints) ? c.keyPoints.map(String) : [],
      explanations: c.explanations && typeof c.explanations === "object" ? c.explanations : {},
      exercises,
    });
  }
  return out.concepts.length >= 3 ? out : null;
}

async function synthesizeWithLLM(interp: GoalInterpretation, research: ResearchResult, slug: string): Promise<DomainBuild | null> {
  const grounding = research.concepts.map((c) => `- ${c.title} (${c.role}): ${c.summary.slice(0, 200)}`).join("\n");
  const res = await llmJson<LLMCurriculum>(
    `You are an expert curriculum designer for an adaptive tutoring system. Design a prerequisite-structured concept graph for the subject, with teaching material in five explanation styles (${STRATEGIES.join(", ")}) and 3 diagnostic exercises per concept. Exercises: type "mcq" (options + answer = index as string), "short" (answer text + accept list), "predict" (code + expected output), "truefalse" (options ["True","False"]). Include misconceptions mapping wrong options to a short label or "concept:<slug>" when the wrong answer indicates a missing prerequisite. Include 1-3 prerequisite-role concepts the learner may lack. 8-12 concepts total.`,
    `Subject: ${interp.subject}\nLevel: ${interp.level}\nFocus: ${interp.focus.join(", ") || "general"}\n\nResearch grounding (Wikipedia):\n${grounding || "(none)"}\n\nReturn JSON: {"title","description","concepts":[{"slug","title","summary","difficulty":0..1,"role":"core"|"prerequisite","prereqs":[slugs],"keyPoints":[...],"explanations":{"concrete_example":"...","analogy":"...","formal_definition":"...","step_by_step":"...","socratic":"..."},"exercises":[...]}]}`,
    validateCurriculum,
    { maxTokens: 16000 },
  );
  if (!res.ok) {
    research.log.push({ at: new Date().toISOString(), step: "synthesis", source: "llm", detail: `LLM synthesis failed (${res.error}); falling back to research-only graph.` });
    return null;
  }
  const cur = res.value;
  const log = [...research.log, { at: new Date().toISOString(), step: "synthesis", source: `llm:${res.provider}`, detail: `Synthesized ${cur.concepts.length} concepts with material and exercises, grounded in ${research.concepts.length} researched topics.` }];
  const [domain] = await db.insert(domains).values({ slug, title: cur.title || research.canonicalTitle || interp.subject, description: cur.description || research.description, origin: "llm", researchLog: log }).returning();
  const idBySlug = new Map<string, number>();
  for (const c of cur.concepts) {
    const [row] = await db
      .insert(concepts)
      .values({ domainId: domain.id, slug: c.slug, title: c.title, summary: c.summary, difficulty: c.difficulty, role: c.role, tags: ["llm"], material: { explanations: c.explanations, exercises: c.exercises, keyPoints: c.keyPoints, sources: research.canonicalTitle ? [research.canonicalTitle] : [] }, provenance: { source: "llm", ref: res.provider, at: new Date().toISOString() } })
      .onConflictDoNothing()
      .returning({ id: concepts.id });
    if (row) idBySlug.set(c.slug, row.id);
  }
  for (const c of cur.concepts) for (const p of c.prereqs) {
    const a = idBySlug.get(c.slug), b = idBySlug.get(p);
    if (a && b && a !== b) await db.insert(prerequisites).values({ conceptId: a, prerequisiteId: b, strength: 0.8, provenance: { source: "llm" } }).onConflictDoNothing();
  }
  return { domainId: domain.id, created: true, log, conceptCount: idBySlug.size, origin: "llm" };
}

// ---------------------------------------------------------------------------
// Target selection
// ---------------------------------------------------------------------------

export async function selectTargets(domainId: number, interp: GoalInterpretation): Promise<number[]> {
  const rows = await db.select({ id: concepts.id, title: concepts.title, role: concepts.role, tags: concepts.tags }).from(concepts).where(eq(concepts.domainId, domainId));
  let targets = rows.filter((r) => r.role === "core");
  if (interp.focus.length) {
    const focused = targets.filter((t) => interp.focus.some((f) => t.title.toLowerCase().includes(f.toLowerCase())));
    if (focused.length) targets = focused;
  }
  return targets.map((t) => t.id);
}

// ---------------------------------------------------------------------------
// Graph extension (gap discovery)
// ---------------------------------------------------------------------------

export type Discovery = { conceptId: number; title: string; source: string; created: boolean; log: ResearchLogEntry[] };

/**
 * Ensure a concept exists in the domain for `term` and link it as a
 * prerequisite of `supportsConceptId`. Order: latent curated knowledge ->
 * LLM -> web research.
 */
export async function discoverConcept(domainId: number, term: string, supportsConceptId: number | null, reason: string): Promise<Discovery | null> {
  const [domain] = await db.select().from(domains).where(eq(domains.id, domainId)).limit(1);
  if (!domain) return null;
  const slug = slugify(term.replace(/^concept:/, ""));
  const existing = await db.select().from(concepts).where(and(eq(concepts.domainId, domainId), eq(concepts.slug, slug))).limit(1);
  const provenance: Provenance = { source: "gap-detection", reason, at: new Date().toISOString() };
  if (existing[0]) {
    if (supportsConceptId) await db.insert(prerequisites).values({ conceptId: supportsConceptId, prerequisiteId: existing[0].id, strength: 0.7, provenance }).onConflictDoNothing();
    return { conceptId: existing[0].id, title: existing[0].title, source: "existing", created: false, log: [] };
  }

  const log: ResearchLogEntry[] = [];
  let created: { id: number; title: string } | null = null;
  let source = "";

  // 1) latent curated knowledge
  const pack = PACKS.find((p) => p.slug === domain.slug);
  const latent: LatentConcept | undefined = pack?.latent.find((l) => l.slug === slug);
  if (latent) {
    const [row] = await db
      .insert(concepts)
      .values({ domainId, slug: latent.slug, title: latent.title, summary: latent.summary, difficulty: latent.difficulty, role: "discovered", tags: latent.tags, material: { explanations: latent.explanations, exercises: latent.exercises, keyPoints: latent.keyPoints, sources: ["curated:latent"] }, provenance: { ...provenance, source: "curated-latent" } })
      .returning({ id: concepts.id, title: concepts.title });
    created = row;
    source = "curated-latent";
    log.push({ at: new Date().toISOString(), step: "extend", source: "curated", detail: `Activated latent concept "${latent.title}" from the agent's ${pack!.title} expertise` });
    // link to every concept it supports that exists
    const supported = await db.select({ id: concepts.id, slug: concepts.slug }).from(concepts).where(and(eq(concepts.domainId, domainId), inArray(concepts.slug, latent.supports)));
    for (const s of supported) await db.insert(prerequisites).values({ conceptId: s.id, prerequisiteId: row.id, strength: 0.7, provenance }).onConflictDoNothing();
  }

  // 2) LLM
  if (!created && hasLLM()) {
    const res = await llmJson<LLMCurriculum["concepts"][number]>(
      `You add one missing prerequisite concept to an adaptive tutoring curriculum. Provide explanations in styles ${STRATEGIES.join(", ")} and 3 exercises (mcq/short/predict/truefalse; mcq answer is option index as string).`,
      `Domain: ${domain.title}\nMissing concept: ${term}\nWhy it is needed: ${reason}\n\nReturn JSON: {"slug","title","summary","difficulty":0..1,"role":"prerequisite","prereqs":[],"keyPoints":[],"explanations":{...},"exercises":[...]}`,
      (raw) => {
        const v = validateCurriculum({ concepts: [raw, raw, raw] });
        return v ? v.concepts[0] : null;
      },
      { maxTokens: 4000 },
    );
    if (res.ok) {
      const c = res.value;
      const [row] = await db
        .insert(concepts)
        .values({ domainId, slug, title: c.title, summary: c.summary, difficulty: c.difficulty, role: "discovered", tags: ["llm", "discovered"], material: { explanations: c.explanations, exercises: c.exercises, keyPoints: c.keyPoints }, provenance: { ...provenance, source: "llm" } })
        .onConflictDoNothing()
        .returning({ id: concepts.id, title: concepts.title });
      if (row) {
        created = row;
        source = "llm";
        log.push({ at: new Date().toISOString(), step: "extend", source: `llm:${res.provider}`, detail: `Generated concept "${c.title}"` });
      }
    }
  }

  // 3) web research
  if (!created) {
    const r = await researchConcept(term.replace(/^concept:/, "").replace(/-/g, " "), domain.title);
    if (r) {
      log.push(...r.log);
      const siblings = await db.select({ slug: concepts.slug, title: concepts.title, summary: concepts.summary }).from(concepts).where(eq(concepts.domainId, domainId));
      const exercises = synthesizeExercises({ slug, title: r.title, summary: r.summary, text: r.text }, siblings);
      const explanations = synthesizeExplanations({ title: r.title, summary: r.summary, text: r.text }, domain.title);
      const [row] = await db
        .insert(concepts)
        .values({ domainId, slug, title: r.title, summary: r.summary, difficulty: 0.4, role: "discovered", tags: ["researched", "discovered"], material: { explanations, exercises, sources: [r.ref] }, provenance: { ...provenance, source: "wikipedia", ref: r.ref } })
        .onConflictDoNothing()
        .returning({ id: concepts.id, title: concepts.title });
      if (row) {
        created = row;
        source = "wikipedia";
      }
    }
  }

  if (!created) return null;
  if (supportsConceptId) await db.insert(prerequisites).values({ conceptId: supportsConceptId, prerequisiteId: created.id, strength: 0.7, provenance }).onConflictDoNothing();
  await db.update(domains).set({ researchLog: [...domain.researchLog, ...log], updatedAt: new Date() }).where(eq(domains.id, domainId));
  return { conceptId: created.id, title: created.title, source, created: true, log };
}

/** Create a goal end-to-end: interpret, build domain, pick targets. */
export async function createGoal(learnerId: number, rawText: string) {
  const interp = await interpretGoal(rawText);
  const [goal] = await db.insert(goals).values({ learnerId, rawText, subject: interp.subject, status: "investigating", interpretation: interp }).returning();
  await logDecision(learnerId, goal.id, "interpret_goal", `Interpreted "${rawText}" as subject "${interp.subject}" (level: ${interp.level}${interp.focus.length ? `, focus: ${interp.focus.join(", ")}` : ""}).`, { rawText }, { ...interp });
  try {
    const build = await buildDomain(interp, { learnerId, goalId: goal.id });
    const targets = await selectTargets(build.domainId, interp);
    const [updated] = await db.update(goals).set({ domainId: build.domainId, targetConceptIds: targets, status: "diagnosing", updatedAt: new Date() }).where(eq(goals.id, goal.id)).returning();
    return { goal: updated, build, interp };
  } catch (err) {
    // Keep the decision trail (learner-scoped) but do not leave a half-built goal behind.
    await logDecision(learnerId, null, "error", `Domain construction for "${rawText}" failed: ${err instanceof Error ? err.message : String(err)}`);
    await db.delete(goals).where(eq(goals.id, goal.id));
    throw err;
  }
}
