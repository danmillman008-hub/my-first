import {
  pgTable,
  serial,
  text,
  integer,
  real,
  boolean,
  timestamp,
  jsonb,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/**
 * Persistent learner model + domain knowledge model.
 *
 * Design principle: BELIEFS are mutable and carry uncertainty; EVIDENCE is
 * append-only and carries provenance. The agent may change its mind, but the
 * record of what the learner actually did never disappears.
 */

// ---------- Learners ----------
export const learners = pgTable("learners", {
  id: serial("id").primaryKey(),
  publicId: text("public_id").notNull().unique(),
  name: text("name").notNull().default("Learner"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ---------- Domains (subjects) & concept graph ----------
export const domains = pgTable("domains", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  // how the domain model was obtained: 'curated' | 'research' | 'llm' | 'hybrid'
  origin: text("origin").notNull().default("research"),
  researchLog: jsonb("research_log").$type<ResearchLogEntry[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const concepts = pgTable(
  "concepts",
  {
    id: serial("id").primaryKey(),
    domainId: integer("domain_id")
      .notNull()
      .references(() => domains.id, { onDelete: "cascade" }),
    slug: text("slug").notNull(),
    title: text("title").notNull(),
    summary: text("summary").notNull().default(""),
    difficulty: real("difficulty").notNull().default(0.5), // 0..1
    // 'core' | 'prerequisite' | 'discovered' — discovered = added after a gap was detected
    role: text("role").notNull().default("core"),
    tags: jsonb("tags").$type<string[]>().notNull().default([]),
    // teaching material keyed by strategy id, plus exercises
    material: jsonb("material").$type<ConceptMaterial>().notNull().default({}),
    provenance: jsonb("provenance").$type<Provenance>().notNull().default({ source: "unknown" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("concepts_domain_slug_idx").on(t.domainId, t.slug)],
);

export const prerequisites = pgTable(
  "prerequisites",
  {
    id: serial("id").primaryKey(),
    conceptId: integer("concept_id")
      .notNull()
      .references(() => concepts.id, { onDelete: "cascade" }),
    prerequisiteId: integer("prerequisite_id")
      .notNull()
      .references(() => concepts.id, { onDelete: "cascade" }),
    strength: real("strength").notNull().default(0.8), // 0..1 how hard the dependency is
    provenance: jsonb("provenance").$type<Provenance>().notNull().default({ source: "unknown" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("prereq_pair_idx").on(t.conceptId, t.prerequisiteId)],
);

// ---------- Goals ----------
export const goals = pgTable("goals", {
  id: serial("id").primaryKey(),
  learnerId: integer("learner_id")
    .notNull()
    .references(() => learners.id, { onDelete: "cascade" }),
  domainId: integer("domain_id").references(() => domains.id, { onDelete: "set null" }),
  rawText: text("raw_text").notNull(),
  subject: text("subject").notNull(),
  // 'investigating' | 'diagnosing' | 'teaching' | 'completed' | 'failed'
  status: text("status").notNull().default("investigating"),
  interpretation: jsonb("interpretation").$type<GoalInterpretation>(),
  targetConceptIds: jsonb("target_concept_ids").$type<number[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// ---------- Beliefs about mastery (mutable, uncertain) ----------
export const masteryBeliefs = pgTable(
  "mastery_beliefs",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    conceptId: integer("concept_id")
      .notNull()
      .references(() => concepts.id, { onDelete: "cascade" }),
    pKnown: real("p_known").notNull().default(0.2), // BKT posterior
    // Beta pseudo-counts summarising direct evidence -> uncertainty = variance of Beta
    alpha: real("alpha").notNull().default(1),
    beta: real("beta").notNull().default(1),
    directEvidence: integer("direct_evidence").notNull().default(0),
    inferredEvidence: integer("inferred_evidence").notNull().default(0),
    // 'prior' | 'inferred' | 'demonstrated' — what the belief rests on
    basis: text("basis").notNull().default("prior"),
    lastEvidenceAt: timestamp("last_evidence_at", { withTimezone: true }),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("mastery_learner_concept_idx").on(t.learnerId, t.conceptId)],
);

// ---------- Evidence (append-only) ----------
export const evidenceEvents = pgTable(
  "evidence_events",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    goalId: integer("goal_id").references(() => goals.id, { onDelete: "set null" }),
    conceptId: integer("concept_id").references(() => concepts.id, { onDelete: "cascade" }),
    sessionId: integer("session_id"),
    // 'exercise' | 'diagnostic' | 'self_report' | 'feedback' | 'inference' | 'affect' | 'external'
    kind: text("kind").notNull(),
    correct: boolean("correct"),
    strategy: text("strategy"),
    payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
    pBefore: real("p_before"),
    pAfter: real("p_after"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("evidence_learner_idx").on(t.learnerId, t.createdAt)],
);

// ---------- Strategy effectiveness (per learner, Thompson sampling) ----------
export const strategyStats = pgTable(
  "strategy_stats",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    // scope: 'global' or 'domain:<slug>'
    scope: text("scope").notNull().default("global"),
    strategy: text("strategy").notNull(),
    alpha: real("alpha").notNull().default(1),
    beta: real("beta").notNull().default(1),
    pulls: integer("pulls").notNull().default(0),
    successes: integer("successes").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("strategy_learner_scope_idx").on(t.learnerId, t.scope, t.strategy)],
);

// ---------- Learner traits (pacing, verbosity, etc.) ----------
export const learnerTraits = pgTable(
  "learner_traits",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    key: text("key").notNull(),
    value: jsonb("value").$type<unknown>().notNull(),
    confidence: real("confidence").notNull().default(0.3),
    evidenceCount: integer("evidence_count").notNull().default(0),
    rationale: text("rationale").notNull().default(""),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("trait_learner_key_idx").on(t.learnerId, t.key)],
);

// ---------- Affect timeline ----------
export const affectStates = pgTable(
  "affect_states",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    goalId: integer("goal_id").references(() => goals.id, { onDelete: "set null" }),
    sessionId: integer("session_id"),
    frustration: real("frustration").notNull().default(0),
    confusion: real("confusion").notNull().default(0),
    engagement: real("engagement").notNull().default(0.6),
    fatigue: real("fatigue").notNull().default(0),
    confidence: real("confidence").notNull().default(0.5),
    signals: jsonb("signals").$type<string[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("affect_learner_idx").on(t.learnerId, t.createdAt)],
);

// ---------- Sessions & turns ----------
export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  learnerId: integer("learner_id")
    .notNull()
    .references(() => learners.id, { onDelete: "cascade" }),
  goalId: integer("goal_id")
    .notNull()
    .references(() => goals.id, { onDelete: "cascade" }),
  currentConceptId: integer("current_concept_id").references(() => concepts.id, { onDelete: "set null" }),
  // 'diagnose' | 'teach' | 'practice' | 'review' | 'complete'
  phase: text("phase").notNull().default("diagnose"),
  strategy: text("strategy"),
  state: jsonb("state").$type<SessionState>().notNull().default({}),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  lastActivityAt: timestamp("last_activity_at", { withTimezone: true }).notNull().defaultNow(),
  endedAt: timestamp("ended_at", { withTimezone: true }),
});

export const turns = pgTable(
  "turns",
  {
    id: serial("id").primaryKey(),
    sessionId: integer("session_id")
      .notNull()
      .references(() => sessions.id, { onDelete: "cascade" }),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    role: text("role").notNull(), // 'agent' | 'learner' | 'system'
    kind: text("kind").notNull(), // 'lesson' | 'exercise' | 'answer' | 'feedback' | 'message' | 'note'
    conceptId: integer("concept_id").references(() => concepts.id, { onDelete: "set null" }),
    content: jsonb("content").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("turns_session_idx").on(t.sessionId, t.createdAt)],
);

// ---------- Agent decisions (inspectable reasoning trail) ----------
export const agentDecisions = pgTable(
  "agent_decisions",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id").references(() => learners.id, { onDelete: "cascade" }),
    goalId: integer("goal_id").references(() => goals.id, { onDelete: "cascade" }),
    sessionId: integer("session_id"),
    // 'interpret_goal' | 'research' | 'build_graph' | 'extend_graph' | 'select_concept' |
    // 'select_strategy' | 'strategy_switch' | 'prereq_probe' | 'affect_response' | 'verify_adaptation' | ...
    kind: text("kind").notNull(),
    rationale: text("rationale").notNull(),
    inputs: jsonb("inputs").$type<Record<string, unknown>>().notNull().default({}),
    outputs: jsonb("outputs").$type<Record<string, unknown>>().notNull().default({}),
    // outcome verification: filled in later when the agent checks whether the decision worked
    outcome: jsonb("outcome").$type<Record<string, unknown> | null>(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("decisions_learner_idx").on(t.learnerId, t.createdAt)],
);

// ---------- Shared JSON types ----------
export type ResearchLogEntry = {
  at: string;
  step: string;
  source: string;
  detail: string;
  data?: Record<string, unknown>;
};

export type Provenance = {
  source: string; // 'curated' | 'wikipedia' | 'llm' | 'gap-detection' | 'learner-request' | 'mcp'
  ref?: string;
  reason?: string;
  at?: string;
};

export type StrategyId =
  | "concrete_example"
  | "analogy"
  | "formal_definition"
  | "step_by_step"
  | "socratic";

export type Exercise = {
  id: string;
  type: "mcq" | "short" | "predict" | "truefalse";
  prompt: string;
  code?: string;
  options?: string[];
  answer: string; // canonical answer (option index for mcq as string, text otherwise)
  accept?: string[]; // alternative accepted answers (normalized)
  explanation: string;
  difficulty: number; // 0..1
  misconceptions?: Record<string, string>; // option/answer -> misconception label or related concept slug
  hint?: string;
};

export type ConceptMaterial = {
  explanations?: Partial<Record<StrategyId, string>>;
  exercises?: Exercise[];
  keyPoints?: string[];
  sources?: string[];
};

export type GoalInterpretation = {
  subject: string;
  level: "beginner" | "intermediate" | "advanced" | "unknown";
  focus: string[];
  notes: string;
  confidence: number;
};

export type SessionState = {
  diagnosticQueue?: number[];
  diagnosticDone?: boolean;
  pendingExercise?: { conceptId: number; exerciseId: string; issuedAt: string; strategy?: string; purpose: string };
  recentOutcomes?: Array<{ conceptId: number; correct: boolean; strategy?: string; at: string }>;
  conceptAttempts?: Record<string, number>;
  lastLessonAt?: string;
  strategyHistory?: Array<{ conceptId: number; strategy: string; at: string; decisionId?: number }>;
  exercisesSinceBreak?: number;
  diagLo?: number;
  diagHi?: number;
  diagProbes?: number;
  diagIndex?: number;
  hintUsed?: boolean;
  breakSuggested?: boolean;
  resumedFromSession?: number;
};
