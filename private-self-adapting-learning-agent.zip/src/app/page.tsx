import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { domains, goals } from "@/db/schema";
import { currentLearner } from "@/lib/agent/learner-model";
import { hasLLM, llmProvider } from "@/lib/agent/intelligence";
import { GoalForm } from "@/components/GoalForm";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const learner = await currentLearner();
  const rows = await db
    .select({ goal: goals, domainTitle: domains.title, domainOrigin: domains.origin })
    .from(goals)
    .leftJoin(domains, eq(goals.domainId, domains.id))
    .where(eq(goals.learnerId, learner.id))
    .orderBy(desc(goals.createdAt));

  return (
    <main className="mx-auto max-w-3xl px-6 py-14">
      <p className="text-xs font-semibold uppercase tracking-[0.14em] text-indigo-600">Private self-adapting learning agent</p>
      <h1 className="mt-3 text-4xl font-semibold leading-tight text-slate-950">What do you want to learn?</h1>
      <p className="mt-3 text-slate-600">Say it in plain language. The agent works out the subject, investigates it if it hasn&apos;t taught it before, builds a prerequisite graph, checks what you already know, and then teaches — adapting its strategy to how <em>you</em> respond, and remembering everything it learns about you.</p>
      <div className="mt-8"><GoalForm /></div>

      <section className="mt-12">
        <div className="flex items-center justify-between"><h2 className="text-lg font-semibold text-slate-900">Your goals</h2><Link href="/learner" className="text-sm text-indigo-700 hover:underline">Inspect learner model →</Link></div>
        {rows.length === 0 ? (
          <p className="mt-3 text-sm text-slate-500">No goals yet.</p>
        ) : (
          <ul className="mt-3 divide-y divide-slate-200 rounded-2xl border border-slate-200 bg-white">
            {rows.map(({ goal, domainTitle, domainOrigin }) => (
              <li key={goal.id}>
                <Link href={`/goals/${goal.id}`} className="flex items-center justify-between gap-4 px-4 py-3 hover:bg-slate-50">
                  <div className="min-w-0"><div className="truncate font-medium text-slate-900">{domainTitle ?? goal.subject}</div><div className="truncate text-xs text-slate-500">“{goal.rawText}”</div></div>
                  <div className="shrink-0 text-right text-xs text-slate-500"><div className="rounded-full bg-slate-100 px-2 py-0.5 capitalize">{goal.status}</div>{domainOrigin && <div className="mt-1">{domainOrigin === "curated" ? "curated expertise" : domainOrigin === "llm" ? "LLM + research" : "researched"}</div>}</div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      <footer className="mt-14 border-t border-slate-200 pt-5 text-xs text-slate-500">
        <p>Intelligence: {hasLLM() ? `LLM (${llmProvider()}) + built-in reasoner + live research` : "built-in reasoner + live research (set ANTHROPIC_API_KEY or OPENAI_API_KEY to enable LLM synthesis for richer open-domain material)"}.</p>
        <p className="mt-1">MCP endpoint for external assistants: <code className="rounded bg-slate-100 px-1">POST /api/mcp</code> (Streamable HTTP). Learner id: <code className="rounded bg-slate-100 px-1">{learner.publicId}</code></p>
      </footer>
    </main>
  );
}
