import Link from "next/link";
import { currentLearner, getLearnerModel } from "@/lib/agent/learner-model";

export const dynamic = "force-dynamic";

function pct(x: number) {
  return `${(x * 100).toFixed(0)}%`;
}

export default async function LearnerPage() {
  const learner = await currentLearner();
  const m = await getLearnerModel(learner.id);
  return (
    <main className="mx-auto max-w-5xl px-6 py-10">
      <Link href="/" className="text-xs text-slate-500 hover:text-slate-800">← Home</Link>
      <h1 className="mt-2 text-3xl font-semibold text-slate-950">Your learner model</h1>
      <p className="mt-1 text-sm text-slate-600">Everything the agent believes about you, with the evidence behind it. Beliefs change; evidence is never deleted. Learner id <code className="rounded bg-slate-100 px-1">{learner.publicId}</code></p>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <section className="rounded-2xl border border-slate-200 bg-white p-5">
          <h2 className="font-semibold text-slate-900">Current affect <span className="text-xs font-normal text-slate-500">({m.affect.label})</span></h2>
          {(["frustration", "confusion", "engagement", "fatigue", "confidence"] as const).map((k) => (
            <div key={k} className="mt-2 flex items-center gap-2 text-xs"><span className="w-20 text-slate-600">{k}</span><div className="h-2 flex-1 rounded bg-slate-200"><div className="h-full rounded bg-indigo-500" style={{ width: pct(m.affect[k]) }} /></div><span className="w-8 text-right">{pct(m.affect[k])}</span></div>
          ))}
          <p className="mt-3 text-[11px] text-slate-500">{m.affectTimeline.length} affect observations recorded.</p>
        </section>
        <section className="rounded-2xl border border-slate-200 bg-white p-5">
          <h2 className="font-semibold text-slate-900">Explanation strategies that work for you</h2>
          {m.strategies.filter((s) => s.scope === "global").sort((a, b) => b.mean - a.mean).map((s) => (
            <div key={s.strategy} className="mt-2 flex items-center gap-2 text-xs"><span className="w-32 text-slate-600">{s.label}</span><div className="h-2 flex-1 rounded bg-slate-200"><div className="h-full rounded bg-emerald-500" style={{ width: pct(s.mean) }} /></div><span className="w-20 text-right text-slate-500">{pct(s.mean)} · n={s.pulls}</span></div>
          ))}
          {m.strategies.filter((s) => s.scope !== "global" && s.pulls > 0).length > 0 && <p className="mt-3 text-[11px] text-slate-500">Domain-specific posteriors: {[...new Set(m.strategies.filter((s) => s.scope !== "global" && s.pulls > 0).map((s) => s.scope.replace("domain:", "")))].join(", ")}</p>}
        </section>
      </div>

      <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-5">
        <h2 className="font-semibold text-slate-900">Traits</h2>
        {m.traits.length === 0 ? <p className="mt-2 text-sm text-slate-500">No traits inferred yet.</p> : (
          <table className="mt-2 w-full text-left text-xs"><thead><tr className="text-slate-500"><th className="py-1">Trait</th><th>Value</th><th>Confidence</th><th>Why</th></tr></thead><tbody>
            {m.traits.map((t) => <tr key={t.key} className="border-t border-slate-100"><td className="py-1.5 font-mono">{t.key}</td><td>{typeof t.value === "object" ? JSON.stringify(t.value) : String(t.value)}</td><td>{pct(t.confidence)} (n={t.evidenceCount})</td><td className="text-slate-600">{t.rationale}</td></tr>)}
          </tbody></table>
        )}
      </section>

      <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-5">
        <h2 className="font-semibold text-slate-900">Mastery beliefs across all subjects</h2>
        {m.mastery.length === 0 ? <p className="mt-2 text-sm text-slate-500">No concepts yet.</p> : (
          <table className="mt-2 w-full text-left text-xs"><thead><tr className="text-slate-500"><th className="py-1">Concept</th><th>Domain</th><th>P(known)</th><th>Uncertainty</th><th>Basis</th><th>Evidence</th></tr></thead><tbody>
            {m.mastery.map((b) => <tr key={b.conceptId} className="border-t border-slate-100"><td className="py-1.5">{b.title}{b.mastered && <span className="ml-1 text-emerald-600">✓</span>}</td><td className="text-slate-500">{b.domain}</td><td>{pct(b.pKnown)}</td><td>±{pct(b.uncertainty)}</td><td>{b.basis}</td><td>{b.directEvidence} direct / {b.inferredEvidence} inferred</td></tr>)}
          </tbody></table>
        )}
      </section>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <section className="rounded-2xl border border-slate-200 bg-white p-5">
          <h2 className="font-semibold text-slate-900">Evidence log (append-only)</h2>
          <div className="mt-2 max-h-96 overflow-y-auto text-xs">
            {m.evidence.map((e) => <div key={e.id} className="flex justify-between border-t border-slate-100 py-1"><span>{e.kind} · {e.conceptTitle ?? "—"}{e.strategy ? ` · ${e.strategy}` : ""}</span><span className={e.correct == null ? "text-slate-400" : e.correct ? "text-emerald-600" : "text-rose-600"}>{e.pBefore != null && e.pAfter != null ? `${pct(e.pBefore)}→${pct(e.pAfter)}` : ""}</span></div>)}
          </div>
        </section>
        <section className="rounded-2xl border border-slate-200 bg-white p-5">
          <h2 className="font-semibold text-slate-900">Agent decisions</h2>
          <div className="mt-2 max-h-96 space-y-2 overflow-y-auto text-xs">
            {m.decisions.map((d) => <div key={d.id} className="rounded border border-slate-200 p-2"><div className="flex justify-between text-[11px] text-slate-500"><span className="font-mono">{d.kind}</span><span>{new Date(d.createdAt).toLocaleString()}</span></div><p className="text-slate-700">{d.rationale}</p>{d.outcome && <p className={`font-medium ${d.outcome.worked ? "text-emerald-700" : "text-rose-700"}`}>outcome: {d.outcome.worked ? "worked" : "did not work"}</p>}</div>)}
          </div>
        </section>
      </div>
    </main>
  );
}
