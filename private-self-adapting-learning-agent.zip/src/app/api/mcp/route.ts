/**
 * MCP (Model Context Protocol) endpoint — Streamable HTTP transport, stateless.
 *
 * External assistants can read the persistent learner model, get the concept
 * graph, ask for recommendations, drive tutoring turns, record evidence, and
 * extend the graph without rebuilding any of the adaptive machinery.
 */
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { WebStandardStreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js";
import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { concepts, domains, evidenceEvents, goals, masteryBeliefs } from "@/db/schema";
import { createGoal, discoverConcept } from "@/lib/agent/domain";
import { ensureLearner, getConceptGraph, getGoalSnapshot, getLearnerModel, getSessionTurns } from "@/lib/agent/learner-model";
import { chooseStrategy, STRATEGY_LABELS } from "@/lib/agent/strategy";
import { ensureBeliefs, isMastered, READY_THRESHOLD, recordEvidence } from "@/lib/agent/mastery";
import { loadGraph, tutorTurn, type LearnerAction } from "@/lib/agent/tutor";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

function text(data: unknown) {
  return { content: [{ type: "text" as const, text: JSON.stringify(data, null, 2) }] };
}

async function learnerByPublicId(publicId: string) {
  const l = await ensureLearner(publicId);
  return l;
}

function buildServer() {
  const server = new McpServer({ name: "private-adaptive-learning-agent", version: "1.0.0" });

  server.registerTool(
    "create_learner",
    { title: "Create learner", description: "Create a new persistent learner profile. Returns the learner_id to use with other tools.", inputSchema: { name: z.string().optional() } },
    async ({ name }) => {
      const l = await ensureLearner(null);
      if (name) await db.execute(`update learners set name = '${name.replace(/'/g, "''")}' where id = ${l.id}`);
      return text({ learner_id: l.publicId, name: name ?? l.name });
    },
  );

  server.registerTool(
    "get_learner_state",
    { title: "Get learner state", description: "Full persistent learner model: goals, mastery beliefs with uncertainty and evidence basis, traits (explanation-style preference, pacing), strategy effectiveness, affect, recent evidence and agent decisions.", inputSchema: { learner_id: z.string() } },
    async ({ learner_id }) => {
      const l = await learnerByPublicId(learner_id);
      const m = await getLearnerModel(l.id);
      return text({ learner_id: l.publicId, ...m, affectTimeline: m.affectTimeline.slice(-10), evidence: m.evidence.slice(0, 30), decisions: m.decisions.slice(0, 30) });
    },
  );

  server.registerTool(
    "list_goals",
    { title: "List goals", description: "List a learner's learning goals with status.", inputSchema: { learner_id: z.string() } },
    async ({ learner_id }) => {
      const l = await learnerByPublicId(learner_id);
      const rows = await db.select().from(goals).where(eq(goals.learnerId, l.id)).orderBy(desc(goals.createdAt));
      return text(rows.map((g) => ({ goal_id: g.id, text: g.rawText, subject: g.subject, status: g.status, interpretation: g.interpretation, createdAt: g.createdAt })));
    },
  );

  server.registerTool(
    "create_goal",
    { title: "Create learning goal", description: "Express a learning objective in natural language (e.g. 'I want to learn Bash'). The agent interprets it, researches the domain if needed, builds the concept graph and prepares a diagnostic.", inputSchema: { learner_id: z.string(), text: z.string().min(3).max(400) } },
    async ({ learner_id, text: t }) => {
      const l = await learnerByPublicId(learner_id);
      const { goal, build, interp } = await createGoal(l.id, t);
      return text({ goal_id: goal.id, status: goal.status, interpretation: interp, domain: { id: build.domainId, origin: build.origin, conceptCount: build.conceptCount, reused: !build.created } });
    },
  );

  server.registerTool(
    "get_concept_graph",
    { title: "Get concept graph", description: "Concept graph (nodes + prerequisite edges with provenance) for a domain slug or a goal id.", inputSchema: { domain_slug: z.string().optional(), goal_id: z.number().optional() } },
    async ({ domain_slug, goal_id }) => {
      let slug = domain_slug;
      if (!slug && goal_id) {
        const [g] = await db.select({ domainId: goals.domainId }).from(goals).where(eq(goals.id, goal_id)).limit(1);
        if (g?.domainId) slug = (await db.select({ slug: domains.slug }).from(domains).where(eq(domains.id, g.domainId)).limit(1))[0]?.slug;
      }
      if (!slug) return text({ error: "domain not found" });
      return text(await getConceptGraph(slug));
    },
  );

  server.registerTool(
    "get_mastery",
    { title: "Get mastery", description: "Mastery beliefs for a goal: probability known, uncertainty, whether it rests on demonstrated/inferred/prior evidence, and readiness.", inputSchema: { goal_id: z.number() } },
    async ({ goal_id }) => {
      const snap = await getGoalSnapshot(goal_id);
      if (!snap) return text({ error: "goal not found" });
      return text({ goal_id, status: snap.goal.status, concepts: snap.concepts.map((c) => ({ concept_id: c.id, slug: c.slug, title: c.title, role: c.role, pKnown: c.pKnown, uncertainty: c.uncertainty, basis: c.basis, directEvidence: c.directEvidence, inferredEvidence: c.inferredEvidence, mastered: c.mastered, target: c.target, prereqIds: c.prereqIds })) });
    },
  );

  server.registerTool(
    "get_recommendation",
    { title: "Get recommendation", description: "What the agent would do next for this goal: the recommended concept, why, the explanation strategy it would use given the learner's history, and the current affect reading.", inputSchema: { goal_id: z.number() } },
    async ({ goal_id }) => {
      const [goal] = await db.select().from(goals).where(eq(goals.id, goal_id)).limit(1);
      if (!goal?.domainId) return text({ error: "goal not ready" });
      const [domain] = await db.select().from(domains).where(eq(domains.id, goal.domainId)).limit(1);
      const graph = await loadGraph(goal);
      const beliefs = await ensureBeliefs(goal.learnerId, graph.order);
      const unmastered = graph.order.filter((id) => !isMastered(beliefs.get(id)!));
      const next = unmastered.find((id) => (graph.prereqOf.get(id) ?? []).every((p) => !beliefs.has(p.id) || beliefs.get(p.id)!.pKnown >= READY_THRESHOLD * p.strength)) ?? unmastered[0] ?? null;
      const choice = await chooseStrategy(goal.learnerId, `domain:${domain.slug}`);
      const snap = await getGoalSnapshot(goal_id);
      return text({
        goal_id,
        status: goal.status,
        next_concept: next ? { concept_id: next, title: graph.conceptMap.get(next)!.title, pKnown: beliefs.get(next)!.pKnown, prerequisites: (graph.prereqOf.get(next) ?? []).map((p) => ({ title: graph.conceptMap.get(p.id)?.title, pKnown: beliefs.get(p.id)?.pKnown })) } : null,
        rationale: next ? `First unmastered concept in prerequisite order whose prerequisites are at or above the readiness threshold (${READY_THRESHOLD}).` : "All target concepts mastered.",
        recommended_strategy: { strategy: choice.strategy, label: STRATEGY_LABELS[choice.strategy], expected_success: choice.means, scope: choice.scopeUsed },
        affect: snap?.affect ?? null,
        remaining: unmastered.length,
        total: graph.order.length,
      });
    },
  );

  server.registerTool(
    "tutoring_turn",
    {
      title: "Tutoring turn",
      description: "Drive the adaptive tutor. Actions: start, next, answer {answer, latencyMs?}, feedback {value: confused|got_it|too_easy|too_hard|too_slow|too_fast|tired|frustrated|helpful|not_helpful}, message {text}, hint, skip_diagnostic {level: beginner|knows_basics}, take_break. Returns the agent's new turns (lessons, exercises, feedback, notes).",
      inputSchema: { goal_id: z.number(), action: z.object({ type: z.string(), answer: z.string().optional(), latencyMs: z.number().optional(), value: z.string().optional(), text: z.string().optional(), level: z.string().optional() }) },
    },
    async ({ goal_id, action }) => {
      const result = await tutorTurn(goal_id, action as unknown as LearnerAction);
      return text({ turns: result.turns.map((t) => ({ id: t.id, role: t.role, kind: t.kind, conceptId: t.conceptId, content: t.content })), session: { id: result.session.id, phase: result.session.phase, currentConceptId: result.session.currentConceptId, strategy: result.session.strategy }, affect: { ...result.affect, label: result.affectLabel } });
    },
  );

  server.registerTool(
    "get_interaction_history",
    { title: "Get interaction history", description: "Turn-by-turn history of the current session for a goal.", inputSchema: { goal_id: z.number(), limit: z.number().optional() } },
    async ({ goal_id, limit }) => {
      const rows = await getSessionTurns(goal_id);
      return text(rows.slice(-(limit ?? 50)).map((t) => ({ id: t.id, role: t.role, kind: t.kind, conceptId: t.conceptId, content: t.content, createdAt: t.createdAt })));
    },
  );

  server.registerTool(
    "record_evidence",
    { title: "Record evidence", description: "Record external evidence about a learner's mastery of a concept (e.g. observed in another tool). Updates beliefs with provenance 'external'.", inputSchema: { learner_id: z.string(), concept_id: z.number(), correct: z.boolean(), note: z.string().optional(), goal_id: z.number().optional() } },
    async ({ learner_id, concept_id, correct, note, goal_id }) => {
      const l = await learnerByPublicId(learner_id);
      const out = await recordEvidence({ learnerId: l.id, goalId: goal_id ?? null, sessionId: null, conceptId: concept_id, correct, exerciseType: "short", purpose: "practice", payload: { source: "mcp", note: note ?? null } });
      await db.update(evidenceEvents).set({ kind: "external" }).where(and(eq(evidenceEvents.learnerId, l.id), eq(evidenceEvents.conceptId, concept_id), eq(evidenceEvents.pAfter, out.after)));
      return text({ concept_id, pBefore: out.before, pAfter: out.after, propagated: out.propagated });
    },
  );

  server.registerTool(
    "extend_graph",
    { title: "Extend concept graph", description: "Add a concept to a goal's domain (the agent will use latent knowledge, an LLM if configured, or web research), optionally as a prerequisite of an existing concept.", inputSchema: { goal_id: z.number(), term: z.string(), supports_concept_id: z.number().optional(), reason: z.string().optional() } },
    async ({ goal_id, term, supports_concept_id, reason }) => {
      const [g] = await db.select().from(goals).where(eq(goals.id, goal_id)).limit(1);
      if (!g?.domainId) return text({ error: "goal not ready" });
      const d = await discoverConcept(g.domainId, term, supports_concept_id ?? null, reason ?? "requested via MCP");
      if (!d) return text({ error: `could not find material for "${term}"` });
      const [c] = await db.select().from(concepts).where(eq(concepts.id, d.conceptId)).limit(1);
      await ensureBeliefs(g.learnerId, [d.conceptId]);
      const [b] = await db.select().from(masteryBeliefs).where(and(eq(masteryBeliefs.learnerId, g.learnerId), eq(masteryBeliefs.conceptId, d.conceptId))).limit(1);
      return text({ concept_id: d.conceptId, title: d.title, source: d.source, created: d.created, summary: c.summary, pKnown: b?.pKnown ?? null, log: d.log });
    },
  );

  server.registerResource("learner-model-schema", "pal://schema/learner-model", { title: "Learner model schema", description: "How the persistent learner model is structured.", mimeType: "text/markdown" }, async (uri) => ({
    contents: [
      {
        uri: uri.href,
        mimeType: "text/markdown",
        text: `# Learner model\n\n- **mastery_beliefs**: per concept, pKnown (BKT posterior), Beta(alpha,beta) pseudo-counts → uncertainty, basis ∈ {prior, inferred, demonstrated}, direct/inferred evidence counts.\n- **evidence_events**: append-only; kind ∈ {exercise, diagnostic, self_report, inference, external}; pBefore/pAfter.\n- **strategy_stats**: Thompson-sampling posteriors per strategy (${Object.values(STRATEGY_LABELS).join(", ")}), scoped global and per domain.\n- **learner_traits**: explanation_style, verbosity, pace_feedback, response_baseline_ms — each with confidence, evidence count and rationale.\n- **affect_states**: frustration, confusion, engagement, fatigue, confidence timeline with the signals that produced each update.\n- **agent_decisions**: every planning decision with rationale, inputs, outputs and (where applicable) verified outcome.\n`,
      },
    ],
  }));

  return server;
}

async function handle(req: Request) {
  const server = buildServer();
  const transport = new WebStandardStreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
  await server.connect(transport);
  try {
    return await transport.handleRequest(req);
  } finally {
    // stateless: tear down after the response is produced
    setTimeout(() => {
      void transport.close();
      void server.close();
    }, 0);
  }
}

export async function POST(req: Request) {
  return handle(req);
}
export async function GET(req: Request) {
  return handle(req);
}
export async function DELETE(req: Request) {
  return handle(req);
}
