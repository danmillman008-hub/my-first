import { NextResponse } from "next/server";
import { currentLearner, getLearnerModel } from "@/lib/agent/learner-model";

export const dynamic = "force-dynamic";

export async function GET() {
  const learner = await currentLearner();
  return NextResponse.json(await getLearnerModel(learner.id));
}
