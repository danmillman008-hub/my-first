import { NextResponse } from "next/server";
import { getSessionTurns } from "@/lib/agent/learner-model";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  return NextResponse.json({ turns: await getSessionTurns(Number(id)) });
}
