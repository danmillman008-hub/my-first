import { NextResponse } from "next/server";
import { getGoalSnapshot } from "@/lib/agent/learner-model";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const snapshot = await getGoalSnapshot(Number(id));
  if (!snapshot) return NextResponse.json({ error: "not found" }, { status: 404 });
  return NextResponse.json(snapshot);
}
