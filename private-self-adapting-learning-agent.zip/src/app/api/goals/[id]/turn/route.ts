import { NextResponse } from "next/server";
import { getGoalSnapshot } from "@/lib/agent/learner-model";
import { tutorTurn, type LearnerAction } from "@/lib/agent/tutor";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const VALID = new Set(["start", "next", "answer", "feedback", "message", "hint", "skip_diagnostic", "take_break"]);

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const action = (await req.json().catch(() => null)) as LearnerAction | null;
  if (!action || !VALID.has(action.type)) return NextResponse.json({ error: "invalid action" }, { status: 400 });
  if (action.type === "answer" && typeof action.answer !== "string") return NextResponse.json({ error: "answer required" }, { status: 400 });
  if (action.type === "message" && (typeof action.text !== "string" || !action.text.trim())) return NextResponse.json({ error: "text required" }, { status: 400 });
  try {
    const result = await tutorTurn(Number(id), action);
    const snapshot = await getGoalSnapshot(Number(id));
    return NextResponse.json({ ...result, snapshot });
  } catch (err) {
    console.error("turn failed", err);
    return NextResponse.json({ error: err instanceof Error ? err.message : "turn failed" }, { status: 500 });
  }
}
