import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { domains, goals } from "@/db/schema";
import { createGoal, NoMaterialError, ResearchUnavailableError } from "@/lib/agent/domain";
import { currentLearner } from "@/lib/agent/learner-model";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function GET() {
  const learner = await currentLearner();
  const rows = await db
    .select({ goal: goals, domainTitle: domains.title, domainOrigin: domains.origin })
    .from(goals)
    .leftJoin(domains, eq(goals.domainId, domains.id))
    .where(eq(goals.learnerId, learner.id))
    .orderBy(desc(goals.createdAt));
  return NextResponse.json({ learner: { publicId: learner.publicId, name: learner.name }, goals: rows });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { text?: string };
  const text = (body.text ?? "").trim();
  if (text.length < 3) return NextResponse.json({ error: "Tell me what you want to learn." }, { status: 400 });
  if (text.length > 400) return NextResponse.json({ error: "Please keep the goal under 400 characters." }, { status: 400 });
  const learner = await currentLearner();
  try {
    const { goal, build, interp } = await createGoal(learner.id, text);
    const res = NextResponse.json({ goal, build: { conceptCount: build.conceptCount, origin: build.origin, created: build.created }, interpretation: interp });
    res.cookies.set("pal_learner", learner.publicId, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
    return res;
  } catch (err) {
    if (err instanceof NoMaterialError) return NextResponse.json({ error: err.message }, { status: 422 });
    if (err instanceof ResearchUnavailableError) return NextResponse.json({ error: err.message, retryAfter: err.retryAfterSec }, { status: 503 });
    console.error("goal creation failed", err);
    return NextResponse.json({ error: err instanceof Error ? err.message : "failed to create goal" }, { status: 500 });
  }
}
