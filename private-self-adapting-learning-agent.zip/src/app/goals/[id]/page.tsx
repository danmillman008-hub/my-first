import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { goals } from "@/db/schema";
import { GoalWorkspace } from "@/components/GoalWorkspace";

export const dynamic = "force-dynamic";

export default async function GoalPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const goalId = Number(id);
  if (!Number.isFinite(goalId)) notFound();
  const [goal] = await db.select({ id: goals.id, status: goals.status, subject: goals.subject }).from(goals).where(eq(goals.id, goalId)).limit(1);
  if (!goal) notFound();
  if (goal.status === "failed" || goal.status === "investigating") {
    return <main className="mx-auto max-w-xl px-6 py-20 text-center"><h1 className="text-xl font-semibold">{goal.status === "failed" ? "The agent could not build this goal" : "Still investigating…"}</h1><p className="mt-2 text-sm text-slate-600">Subject: {goal.subject}. Try rephrasing the goal from the home page.</p></main>;
  }
  return <GoalWorkspace goalId={goalId} />;
}
