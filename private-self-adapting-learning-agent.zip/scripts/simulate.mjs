// Simulation harness: drives the real API with simulated learners and checks adaptive behaviour.
import pg from "pg";
const BASE = process.env.BASE || "http://localhost:3100";
const pool = new pg.Pool({ connectionString: "postgresql://postgres:postgres@127.0.0.1:5432/app_db" });

async function api(path, opts = {}, jar) {
  const res = await fetch(BASE + path, { ...opts, headers: { "content-type": "application/json", ...(jar?.cookie ? { cookie: jar.cookie } : {}), ...(opts.headers ?? {}) } });
  const sc = res.headers.get("set-cookie");
  if (sc && jar) jar.cookie = sc.split(";")[0];
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`${path} -> ${res.status} ${JSON.stringify(data).slice(0, 300)}`);
  return data;
}

async function exerciseAnswer(conceptId, exerciseId) {
  const { rows } = await pool.query("select material from concepts where id=$1", [conceptId]);
  const ex = (rows[0]?.material?.exercises ?? []).find((e) => e.id === exerciseId);
  return ex;
}

function wrongAnswer(ex, preferMisconception) {
  if (ex.options) {
    if (preferMisconception && ex.misconceptions) {
      const k = Object.keys(ex.misconceptions).find((k) => ex.misconceptions[k].startsWith("concept:"));
      if (k !== undefined && /^\d+$/.test(k)) return k;
    }
    const idx = (Number(ex.answer) + 1) % ex.options.length;
    return String(idx);
  }
  if (preferMisconception && ex.misconceptions) {
    const k = Object.keys(ex.misconceptions).find((k) => ex.misconceptions[k].startsWith("concept:"));
    if (k) return k;
  }
  return "definitely wrong";
}

/** run a simulated learner on a goal. policy(turnCtx) -> {answer} | {feedback} | {message} */
async function runLearner(name, goalText, policy, { maxSteps = 60, jar = {}, log = false } = {}) {
  const t0 = Date.now();
  const created = await api("/api/goals", { method: "POST", body: JSON.stringify({ text: goalText }) }, jar);
  const goalId = created.goal.id;
  console.log(`\n=== ${name}: "${goalText}" -> goal ${goalId} (${created.build.origin}, ${created.build.conceptCount} concepts, ${Date.now() - t0}ms) interp=${JSON.stringify(created.interpretation)}`);
  let out = await api(`/api/goals/${goalId}/turn`, { method: "POST", body: JSON.stringify({ type: "start" }) }, jar);
  const history = [];
  let steps = 0;
  const state = { lastStrategy: null, lastLessonConcept: null };
  let pending = null;
  while (steps++ < maxSteps) {
    const turns = out.turns;
    for (const t of turns) {
      history.push(t);
      if (t.kind === "exercise") pending = t;
      if (t.kind === "feedback") pending = null;
      if (t.kind === "lesson") { state.lastStrategy = t.content.strategy; state.lastLessonConcept = t.conceptId; }
      if (log) console.log(`  [${t.role}/${t.kind}] ${(t.content.title ?? t.content.text ?? t.content.prompt ?? "").toString().slice(0, 110).replace(/\n/g, " ")}`);
    }
    if (out.session.phase === "complete") break;
    const ex = pending;
    let action;
    if (ex) {
      const full = await exerciseAnswer(ex.conceptId, ex.content.exerciseId);
      action = policy({ exercise: full, turn: ex, state, step: steps });
      if (action.answer !== undefined) action = { type: "answer", answer: action.answer, latencyMs: action.latencyMs ?? 8000 };
    } else {
      action = policy({ exercise: null, turn: null, state, step: steps });
    }
    if (action.feedback) action = { type: "feedback", value: action.feedback };
    if (action.message) action = { type: "message", text: action.message };
    if (!action.type) action = { type: "next" };
    if (log) console.log(`  -> learner: ${JSON.stringify(action).slice(0, 100)}`);
    out = await api(`/api/goals/${goalId}/turn`, { method: "POST", body: JSON.stringify(action) }, jar);
  }
  const snap = await api(`/api/goals/${goalId}`, {}, jar);
  snap.decisions = (await pool.query("select id, kind, rationale, outcome from agent_decisions where goal_id=$1 order by id", [goalId])).rows;
  const kinds = {};
  for (const d of snap.decisions) kinds[d.kind] = (kinds[d.kind] ?? 0) + 1;
  console.log(`  steps=${steps} phase=${out.session.phase} status=${snap.goal.status} mastered=${snap.concepts.filter((c) => c.relevant && c.mastered).length}/${snap.concepts.filter((c) => c.relevant).length} affect=${snap.affect.label} decisions=${JSON.stringify(kinds)}`);
  return { goalId, snap, history, jar };
}

const results = {};
function check(name, cond, detail = "") { results[name] = cond; console.log(`  ${cond ? "PASS" : "FAIL"} ${name} ${detail}`); }

// ---------- Scenario A: expert learner on Bash ----------
{
  const r = await runLearner("A expert", "I want to learn Bash", ({ exercise }) => (exercise ? { answer: exercise.type === "mcq" || exercise.type === "truefalse" ? exercise.answer : exercise.answer, latencyMs: 3000 } : { type: "next" }), { maxSteps: 80 });
  check("A: goal completed", r.snap.goal.status === "completed");
  const inferred = r.snap.evidence.filter((e) => e.kind === "inference").length;
  check("A: prerequisite inference propagated", inferred > 0, `(${inferred} inference events)`);
  const diagnostics = Number((await pool.query("select count(*) from evidence_events where goal_id=$1 and kind='diagnostic'", [r.goalId])).rows[0].count);
  check("A: diagnostic probes used", diagnostics >= 2 && diagnostics <= 6, `(${diagnostics})`);
  check("A: fewer steps than 4x concepts", r.history.filter((t) => t.kind === "exercise").length < r.snap.concepts.filter((c) => c.relevant).length * 4);
}

// ---------- Scenario C: prerequisite gap (word splitting) ----------
{
  const r = await runLearner("C gap learner", "I want to learn Bash, I already know the basics", ({ exercise, state }) => {
    if (!exercise) return { type: "next" };
    const hasGap = exercise.misconceptions && Object.values(exercise.misconceptions).some((v) => v === "concept:word-splitting");
    if (hasGap && !state.gapFixed) return { answer: wrongAnswer(exercise, true) };
    if (exercise.id.startsWith("ws-")) { state.wsSeen = (state.wsSeen ?? 0) + 1; if (state.wsSeen >= 2) state.gapFixed = true; }
    return { answer: exercise.answer };
  }, { maxSteps: 90 });
  const ext = r.snap.decisions.filter((d) => d.kind === "extend_graph");
  const ws = r.snap.concepts.find((c) => c.slug === "word-splitting");
  check("C: graph extended with discovered concept", ext.length > 0 && Boolean(ws), ws ? `(word-splitting added, role=${ws.role}, source=${ws.provenance.source})` : "(missing)");
  check("C: discovered concept linked as prerequisite of quoting", Boolean(ws) && r.snap.concepts.find((c) => c.slug === "quoting")?.prereqIds.includes(ws?.id));
  check("C: discovered concept was taught", r.history.some((t) => t.kind === "lesson" && t.conceptId === ws?.id));
  check("C: goal still completed after gap", r.snap.goal.status === "completed");
}

// ---------- Scenario B: learner who only learns from concrete examples ----------
let jarB = {};
{
  const r = await runLearner("B example-dependent", "teach me bash scripting", ({ exercise, state }) => {
    if (!exercise) return { type: "next" };
    const good = state.lastStrategy === "concrete_example";
    const p = good ? 0.95 : 0.25;
    return Math.random() < p ? { answer: exercise.answer } : { answer: wrongAnswer(exercise, false) };
  }, { maxSteps: 120, jar: jarB });
  jarB = r.jar;
  const g = r.snap.strategies.filter((s) => s.scope === "global").sort((a, b) => b.mean - a.mean);
  console.log("  strategies:", g.map((s) => `${s.strategy}=${s.mean.toFixed(2)}(n=${s.pulls})`).join(" "));
  check("B: concrete_example ranked top", g[0].strategy === "concrete_example", `(top=${g[0].strategy})`);
  const switches = r.snap.decisions.filter((d) => d.kind === "strategy_switch").length;
  const verified = r.snap.decisions.filter((d) => d.kind === "verify_adaptation").length;
  check("B: strategy switches happened and were verified", switches > 0 && verified > 0, `(switches=${switches}, verified=${verified})`);
  const trait = r.snap.traits.find((t) => t.key === "explanation_style");
  check("B: explanation_style trait inferred", Boolean(trait) && trait.value.preferred === "concrete_example", trait ? JSON.stringify(trait.value.preferred) : "(none)");
  // persistence across subjects: start OOP with same learner; the first lesson should favour concrete_example
  const r2 = await runLearner("B2 same learner, new subject", "I want to learn object-oriented programming", ({ exercise }) => (exercise ? { answer: exercise.answer } : { type: "next" }), { maxSteps: 6, jar: jarB });
  const firstLesson = r2.history.find((t) => t.kind === "lesson");
  // Thompson sampling is stochastic; check the majority over repeated recommendations for the new domain
  const picks = [];
  for (let i = 0; i < 7; i++) {
    const res = await fetch(BASE + "/api/mcp", { method: "POST", headers: { "content-type": "application/json", accept: "application/json, text/event-stream" }, body: JSON.stringify({ jsonrpc: "2.0", id: i, method: "tools/call", params: { name: "get_recommendation", arguments: { goal_id: r2.goalId } } }) });
    const j = await res.json();
    picks.push(JSON.parse(j.result.content[0].text).recommended_strategy.strategy);
  }
  const majority = picks.filter((p) => p === "concrete_example").length;
  check("B2: cross-domain strategy transfer (learned preference dominates in new subject)", majority >= 4, `(first lesson=${firstLesson?.content.strategy}; ${majority}/7 recommendations = concrete_example)`);
  const learnerModel = await api("/api/learner", {}, jarB);
  check("B2: learner model persists both goals", learnerModel.goals.length === 2 && learnerModel.mastery.length > 10, `(goals=${learnerModel.goals.length}, beliefs=${learnerModel.mastery.length})`);
}

// ---------- Scenario D: frustrated, confused learner ----------
{
  let n = 0;
  const r = await runLearner("D frustrated", "I want to learn OOP", ({ exercise, step }) => {
    n++;
    if (step === 2) return { type: "skip_diagnostic", level: "beginner" };
    if (n % 5 === 0) return { message: "ugh I don't get this at all, this is so frustrating" };
    if (n % 7 === 0) return { feedback: "confused" };
    if (!exercise) return { type: "next" };
    return n < 14 ? { answer: wrongAnswer(exercise, false), latencyMs: 40000 } : { answer: exercise.answer, latencyMs: 6000 };
  }, { maxSteps: 40 });
  const affectResp = r.snap.decisions.filter((d) => d.kind === "affect_response").length;
  check("D: affect-driven responses", affectResp > 0, `(${affectResp})`);
  check("D: diagnostic skipped -> beginner priors", r.snap.decisions.some((d) => d.kind === "diagnose" && /new to this/.test(d.rationale)));
  const probes = r.snap.decisions.filter((d) => d.kind === "prereq_probe").length;
  const switches = r.snap.decisions.filter((d) => d.kind === "strategy_switch").length;
  check("D: strategy switching under failure", switches >= 2, `(switches=${switches}, prereq probes=${probes})`);
  const lm = await api("/api/learner", {}, r.jar);
  check("D: affect timeline persisted", lm.affectTimeline.length > 5 && lm.affectTimeline.some((a) => a.frustration > 0.3), `(${lm.affectTimeline.length} rows, max frustration ${Math.max(...lm.affectTimeline.map((a) => a.frustration)).toFixed(2)})`);
}

// ---------- Scenario E: open domain via research ----------
{
  const r = await runLearner("E open domain", "I want to learn about photosynthesis", ({ exercise }) => (exercise ? { answer: exercise.answer } : { type: "next" }), { maxSteps: 10 });
  check("E: researched domain built with concepts", r.snap.domain.origin === "research" && r.snap.concepts.length >= 4, `(${r.snap.concepts.length} concepts: ${r.snap.concepts.slice(0, 6).map((c) => c.title).join(", ")})`);
  check("E: research log recorded", r.snap.domain.researchLog.length >= 3);
  check("E: exercises synthesized", r.snap.concepts.some((c) => c.exerciseCount > 0), `(${r.snap.concepts.reduce((n, c) => n + c.exerciseCount, 0)} exercises)`);
  check("E: prerequisite edges inferred", r.snap.edges.length > 0, `(${r.snap.edges.length} edges)`);
  check("E: lessons delivered", r.history.some((t) => t.kind === "lesson"));
  // ask a question about an unknown term -> graph extension via research
  const q = await api(`/api/goals/${r.goalId}/turn`, { method: "POST", body: JSON.stringify({ type: "message", text: "what is chlorophyll?" }) }, r.jar);
  const added = q.snapshot.concepts.find((c) => /chlorophyll/i.test(c.title));
  check("E: question about unknown term researched & added to graph", Boolean(added), added ? `(${added.title}, ${added.provenance.source})` : JSON.stringify(q.turns.map((t) => t.content.text?.slice(0, 80))));
}

// ---------- Scenario F: MCP ----------
{
  const mcp = async (body) => {
    const res = await fetch(BASE + "/api/mcp", { method: "POST", headers: { "content-type": "application/json", accept: "application/json, text/event-stream" }, body: JSON.stringify(body) });
    const txt = await res.text();
    try { return JSON.parse(txt); } catch { return { raw: txt.slice(0, 300), status: res.status }; }
  };
  const init = await mcp({ jsonrpc: "2.0", id: 1, method: "initialize", params: { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "sim", version: "1" } } });
  check("F: MCP initialize", init.result?.serverInfo?.name === "private-adaptive-learning-agent", JSON.stringify(init).slice(0, 120));
  const tools = await mcp({ jsonrpc: "2.0", id: 2, method: "tools/list", params: {} });
  const names = (tools.result?.tools ?? []).map((t) => t.name);
  check("F: MCP tools listed", names.includes("get_learner_state") && names.includes("tutoring_turn") && names.includes("extend_graph"), names.join(","));
  const cl = await mcp({ jsonrpc: "2.0", id: 3, method: "tools/call", params: { name: "create_learner", arguments: { name: "MCP Bot" } } });
  const learnerId = JSON.parse(cl.result.content[0].text).learner_id;
  const cg = await mcp({ jsonrpc: "2.0", id: 4, method: "tools/call", params: { name: "create_goal", arguments: { learner_id: learnerId, text: "I want to learn Bash" } } });
  const goalId = JSON.parse(cg.result.content[0].text).goal_id;
  const rec = await mcp({ jsonrpc: "2.0", id: 5, method: "tools/call", params: { name: "get_recommendation", arguments: { goal_id: goalId } } });
  const recj = JSON.parse(rec.result.content[0].text);
  check("F: MCP recommendation", Boolean(recj.next_concept?.title) && Boolean(recj.recommended_strategy?.strategy), `(${recj.next_concept?.title} via ${recj.recommended_strategy?.strategy})`);
  const tt = await mcp({ jsonrpc: "2.0", id: 6, method: "tools/call", params: { name: "tutoring_turn", arguments: { goal_id: goalId, action: { type: "start" } } } });
  const ttj = JSON.parse(tt.result.content[0].text);
  check("F: MCP tutoring turn", ttj.turns.some((t) => t.kind === "exercise"));
  const st = await mcp({ jsonrpc: "2.0", id: 7, method: "tools/call", params: { name: "get_learner_state", arguments: { learner_id: learnerId } } });
  const stj = JSON.parse(st.result.content[0].text);
  check("F: MCP learner state", stj.goals.length === 1 && stj.mastery.length > 0);
  const cid = stj.mastery[0].conceptId;
  const ev = await mcp({ jsonrpc: "2.0", id: 8, method: "tools/call", params: { name: "record_evidence", arguments: { learner_id: learnerId, concept_id: cid, correct: true, note: "observed in IDE" } } });
  const evj = JSON.parse(ev.result.content[0].text);
  check("F: MCP record_evidence updates belief", evj.pAfter > evj.pBefore, `(${evj.pBefore?.toFixed(2)} -> ${evj.pAfter?.toFixed(2)})`);
  const ext = await mcp({ jsonrpc: "2.0", id: 9, method: "tools/call", params: { name: "extend_graph", arguments: { goal_id: goalId, term: "command substitution", reason: "test" } } });
  const extj = JSON.parse(ext.result.content[0].text);
  check("F: MCP extend_graph", Boolean(extj.concept_id), `(${extj.title} via ${extj.source})`);
}

console.log("\n==== SUMMARY ====");
const failed = Object.entries(results).filter(([, v]) => !v);
console.log(`${Object.keys(results).length - failed.length}/${Object.keys(results).length} checks passed`);
for (const [k] of failed) console.log("FAILED:", k);
await pool.end();
process.exit(failed.length ? 1 : 0);
