# Graph Tutor — private, graph-native adaptive tutor

A single-window chat tutor whose behaviour emerges from a **Graphify** knowledge
graph plus a thin adaptive overlay. It learns from real interaction: explanation
depth and style drift with your history, concepts strengthen with use and fade
without it, dormant branches come back when you return to them, and a
lightweight affect model shapes tone and pacing.

## What is reused (audit result)

| Need | Reused from | How |
|---|---|---|
| Graph substrate, persistence format | **graphify** `export.py::to_json` | The graph is stored verbatim as a `graph.json` node-link document (`nodes`, `links`, `relation`, `confidence`, `confidence_score`, `community`, `norm_label`). No second graph model. |
| Extraction schema + validation | **graphify** `validate.py`, `llm.py` prompt shape | Chat turns are extracted into the same `{nodes, edges}` schema; `validateExtraction` is a 1:1 port. |
| Learning overlay with decay | **graphify** `reflect.py` (`.graphify_learning.json`) | Personalization lives in graphify's own sidecar (`status/score/uses/last/provenance`, half-life decay) extended with `mastery`, `branch`, `depth`, `style`. graphify's `serve.py` already reads this file and annotates query output with `learning=<status>`. |
| Query / explain / path / MCP over the graph | **graphify** CLI + `graphify-mcp` | Both documents are mirrored to `./graphify-out/`, so `graphify query`, `graphify explain`, `graphify path` and `graphify-mcp` (stdio or Streamable HTTP) work unchanged. |
| Pedagogy | **auto-tutor** `learning-engine` skill | Socratic method, Bloom's taxonomy + dynamic downgrade, background adaptation, anti-hallucination rule, learning-history structure → `interactions` table. |

Added (thin layers only): `src/tutor/{signals,overlay,policy,prompts,engine,summary}.ts`,
`src/graphify/{types,graph,store}.ts`, `src/mcp/server.ts`, 4 API routes, one page.

## Run

```bash
cp .env.example .env   # or edit .env: DATABASE_URL, GEMINI_API_KEY, GEMINI_MODEL
npm install
npx drizzle-kit push   # creates `graphs` + `interactions`
npm run dev            # http://localhost:3000
```

`GEMINI_API_KEY` is read server-side only. Without it the app runs in
"graph-only" mode (state still adapts; replies are a deterministic policy summary).

## Use the graph with upstream Graphify tools

```bash
uv tool install "graphifyy[mcp]"
graphify explain "Derivative" --graph graphify-out/graph.json
graphify path "Limit" "Chain Rule"
graphify-mcp --graph graphify-out/graph.json                # stdio
graphify-mcp --graph graphify-out/graph.json --http --port 8765   # Streamable HTTP
```

## MCP (built-in adapter)

Endpoint: `POST|GET|DELETE /api/mcp` — MCP **Streamable HTTP** (single endpoint,
stateless, JSON responses, SSE on GET) via `@modelcontextprotocol/sdk`.

```json
{ "mcpServers": { "graph-tutor": { "url": "http://localhost:3000/api/mcp" } } }
```

Tools: `get_state`, `get_node`, `recommend_next`, `record_interaction`,
`reactivate_branch`, `set_learner_background`, `run_decay`.
Resources: `graphify://graph`, `graphify://learning`, `tutor://state`, `tutor://history`.
Prompt: `explain_with_policy(concept)`.

## Other endpoints

- `POST /api/chat {message}` → one adaptive turn; `GET /api/chat` → history
- `GET /api/state` → learner model / affect / branches / current policy
- `POST /api/reset` → wipe (debug)

## How adaptation works (one turn)

1. **Decay pass** – every sidecar entry's activation = `score · 0.5^(age/half_life)`; below threshold ⇒ `branch: dormant`.
2. **Signals** – regex/structural indicators: confusion, frustration, curiosity, fatigue, confidence, depth requests, style cues, corrections, follow-up streaks, message length.
3. **Focus** – graph nodes mentioned in the message (fallback: previous focus on short follow-ups).
4. **Policy** – depth (learner EMA ⊕ per-concept memory ⊕ affect), style (weights reinforced by prior outcome), Bloom level from focus mastery, Socratic ratio, tone, pacing, and **next paths** from a 2-hop walk scored by edge confidence × weight, mastery gap, prerequisite direction, prior success and dormancy (reactivation bonus).
5. **LLM** – Gemini gets the policy + graph neighbourhood, returns `{reply, extraction, focus}`; the extraction is validated and merged into `graph.json`.
6. **Overlay update** – credit/blame the previous focus by this turn's outcome, strengthen touched nodes, propagate depth/style to 1-hop neighbours, reactivate dormant nodes that were touched; persist to Postgres and mirror to `graphify-out/`.
