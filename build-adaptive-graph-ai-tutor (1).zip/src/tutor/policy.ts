import { adjacency, nodeById } from "@/graphify/graph";
import type { GraphifyGraph, LearningOverlay, OverlayEntry, Style } from "@/graphify/types";
import { STYLES, activation, topStyle } from "./overlay";
import type { TurnSignals } from "./signals";

/** Bloom's taxonomy levels (auto-tutor references/bloom-taxonomy.md). */
export const BLOOM = ["remember", "understand", "apply", "analyze", "evaluate", "create"] as const;
export type BloomLevel = (typeof BLOOM)[number];

export type PathMode = "introduce" | "deepen" | "revisit_prerequisite" | "reactivate" | "connect";

export interface NextPath {
  id: string;
  label: string;
  mode: PathMode;
  score: number;
  reason: string;
}

export interface ResponsePolicy {
  depth: number; // 1..5
  style: Style;
  style_mix: Record<Style, number>;
  bloom: BloomLevel;
  socratic_ratio: number; // 0..1 – ask vs. tell
  length: "short" | "medium" | "long";
  pacing: "slow" | "steady" | "fast";
  tone: "reassuring" | "neutral" | "energetic" | "concise";
  focus: string[];
  focus_mastery: number;
  next_paths: NextPath[];
  dormant_nearby: string[];
  rationale: string[];
}

const PREREQ_RELATIONS = new Set(["prerequisite_of", "requires", "builds_on", "depends_on"]);
const PART_RELATIONS = new Set(["part_of", "contains", "has_component", "subconcept_of"]);

function isPrereqEdge(rel: string) {
  return PREREQ_RELATIONS.has(rel);
}

export function derivePolicy(
  G: GraphifyGraph,
  overlay: LearningOverlay,
  focus: string[],
  now = new Date(),
  signals?: TurnSignals,
): ResponsePolicy {
  const L0 = overlay.learner;
  const rationale: string[] = [];
  // Blend the current turn's signals in (same EMA weight applyTurn uses) so an
  // explicit "simpler please" or a burst of confusion changes THIS reply, not
  // just the next one. The persisted learner model is untouched here.
  const L = signals
    ? {
        ...L0,
        depth: clamp(L0.depth + signals.depth_request * 0.9, 1, 5),
        affect: Object.fromEntries(
          Object.entries(L0.affect).map(([k, v]) => [k, v * 0.65 + signals.affect[k as keyof typeof signals.affect] * 0.35]),
        ) as typeof L0.affect,
        style: { ...L0.style },
        follow_up_streak: signals.follow_up ? L0.follow_up_streak + 1 : 0,
      }
    : L0;
  if (signals) {
    for (const [k, v] of Object.entries(signals.style_cues) as [Style, number][]) L.style[k] += 0.6 * v;
    if (signals.depth_request !== 0) rationale.push(`explicit depth request ${signals.depth_request > 0 ? "deeper" : "simpler"}`);
  }
  const hl = L.half_life_days;

  /* ---- depth: blend learner-level preference with per-concept memory ---- */
  const focusEntries = focus.map((id) => overlay.nodes[id]).filter(Boolean) as OverlayEntry[];
  const conceptDepth = focusEntries.length
    ? focusEntries.reduce((a, e) => a + e.depth, 0) / focusEntries.length
    : L.depth;
  let depth = 0.5 * L.depth + 0.5 * conceptDepth;
  const focusMastery = focusEntries.length
    ? focusEntries.reduce((a, e) => a + e.mastery, 0) / focusEntries.length
    : 0.2;

  // affect modulation
  if (L.affect.confusion > 0.55) {
    depth -= 0.8;
    rationale.push("confusion high → simplify");
  }
  if (L.affect.fatigue > 0.5) {
    depth -= 0.5;
    rationale.push("fatigue → shorter, lighter");
  }
  if (L.affect.curiosity > 0.55 && L.affect.confusion < 0.35) {
    depth += 0.5;
    rationale.push("curiosity → go deeper");
  }
  depth = Math.round(clamp(depth, 1, 5) * 2) / 2;

  /* ---- style: learner mix blended with what worked on these concepts --- */
  const mix = { ...L.style };
  for (const e of focusEntries) for (const k of STYLES) mix[k] = 0.6 * mix[k] + 0.4 * e.style[k];
  if (L.affect.confusion > 0.5) {
    mix.analogy += 0.4;
    mix.example += 0.3;
    mix.formal -= 0.3;
  }
  if (L.affect.confidence > 0.55 && focusMastery > 0.5) mix.socratic += 0.3;
  if (L.affect.frustration > 0.5) mix.socratic -= 0.5; // don't quiz a frustrated learner
  const style = topStyle(mix);

  /* ---- Bloom level follows mastery of the focus ------------------------ */
  const bloomIdx = clampInt(Math.floor(focusMastery * 6), 0, 5);
  const bloom = BLOOM[bloomIdx];

  /* ---- socratic ratio (auto-tutor's Socratic method, tempered by affect) */
  let socratic = 0.25 + focusMastery * 0.4 + L.affect.confidence * 0.2;
  socratic -= L.affect.confusion * 0.3 + L.affect.frustration * 0.4 + L.affect.fatigue * 0.3;
  socratic = clamp(socratic, 0.05, 0.85);

  /* ---- length / pacing / tone ------------------------------------------ */
  const length: ResponsePolicy["length"] =
    L.affect.fatigue > 0.5 || depth <= 1.5 ? "short" : depth >= 4 ? "long" : "medium";
  const pacing: ResponsePolicy["pacing"] =
    L.affect.confusion > 0.5 || L.follow_up_streak >= 2 ? "slow" : L.affect.curiosity > 0.5 && focusMastery > 0.5 ? "fast" : "steady";
  const tone: ResponsePolicy["tone"] =
    L.affect.frustration > 0.45 || L.affect.confusion > 0.6
      ? "reassuring"
      : L.affect.fatigue > 0.5
        ? "concise"
        : L.affect.curiosity > 0.55
          ? "energetic"
          : "neutral";

  /* ---- next explanation paths ----------------------------------------- */
  const { next_paths, dormant_nearby } = recommendPaths(G, overlay, focus, focusMastery, now, hl);

  if (focusEntries.length) rationale.push(`focus mastery ${focusMastery.toFixed(2)} → bloom:${bloom}`);
  rationale.push(`style ${style} (learner mix top=${topStyle(L.style)})`);

  return {
    depth,
    style,
    style_mix: mix,
    bloom,
    socratic_ratio: Number(socratic.toFixed(2)),
    length,
    pacing,
    tone,
    focus,
    focus_mastery: Number(focusMastery.toFixed(2)),
    next_paths,
    dormant_nearby,
    rationale,
  };
}

/**
 * Graph walk from the focus: score 1–2 hop candidates by edge confidence ×
 * weight, mastery gap, prerequisite direction, and prior success; dormant
 * neighbours get a reactivation bonus when they are structurally close.
 */
export function recommendPaths(
  G: GraphifyGraph,
  overlay: LearningOverlay,
  focus: string[],
  focusMastery: number,
  now = new Date(),
  halfLife = 30,
  limit = 3,
): { next_paths: NextPath[]; dormant_nearby: string[] } {
  const adj = adjacency(G);
  const focusSet = new Set(focus);
  const candidates = new Map<string, NextPath>();
  const dormantNearby = new Set<string>();

  const consider = (id: string, base: number, mode: PathMode, reason: string) => {
    const e = overlay.nodes[id];
    const mastery = e?.mastery ?? 0;
    const act = e ? activation(e, now, halfLife) : 0;
    let score = base * (1 - mastery * 0.8);
    if (e?.branch === "dormant") {
      dormantNearby.add(id);
      score += 0.35;
      mode = "reactivate";
      reason = `dormant branch related to current focus (last seen ${e.last.slice(0, 10)})`;
    }
    // prior success on this node favours returning to it; heavy confusion
    // there argues for a prerequisite detour instead
    if (e) score += (e.successes - e.confusions) * 0.05 + Math.min(act, 3) * 0.05;
    const prev = candidates.get(id);
    if (!prev || prev.score < score) {
      candidates.set(id, { id, label: nodeById(G, id)?.label ?? id, mode, score: Number(score.toFixed(3)), reason });
    }
  };

  // Seeds without a focus: strongest active nodes, then anything new.
  if (!focus.length) {
    const ranked = Object.entries(overlay.nodes)
      .filter(([, e]) => e.branch === "active")
      .sort((a, b) => activation(b[1], now, halfLife) - activation(a[1], now, halfLife))
      .slice(0, 3);
    for (const [id] of ranked) consider(id, 0.6, "deepen", "most active recent branch");
  }

  for (const f of focus) {
    for (const nb of adj.get(f) ?? []) {
      if (focusSet.has(nb.id)) continue;
      const w = (nb.link.confidence_score ?? 0.75) * Math.min(nb.link.weight ?? 1, 3) / 1.5;
      const rel = nb.link.relation;
      if (isPrereqEdge(rel)) {
        // edge source is prerequisite of target
        const nbIsPrereq = !nb.outgoing;
        if (nbIsPrereq && focusMastery < 0.45) {
          consider(nb.id, w + 0.4, "revisit_prerequisite", `prerequisite of ${nodeById(G, f)?.label ?? f}; focus mastery is low`);
        } else if (!nbIsPrereq && focusMastery >= 0.45) {
          consider(nb.id, w + 0.3, "introduce", `builds on ${nodeById(G, f)?.label ?? f}, which is understood`);
        } else {
          consider(nb.id, w * 0.5, nbIsPrereq ? "revisit_prerequisite" : "introduce", `linked by ${rel}`);
        }
      } else if (PART_RELATIONS.has(rel)) {
        consider(nb.id, w + 0.15, focusMastery >= 0.45 ? "deepen" : "introduce", `sub-concept of ${nodeById(G, f)?.label ?? f}`);
      } else {
        consider(nb.id, w, "connect", `related via ${rel}`);
      }
      // 2-hop: look one step further for cross-branch connections
      for (const nb2 of adj.get(nb.id) ?? []) {
        if (focusSet.has(nb2.id) || nb2.id === nb.id) continue;
        consider(nb2.id, w * 0.35, "connect", `2 hops from focus via ${nodeById(G, nb.id)?.label ?? nb.id}`);
      }
    }
    // if the learner keeps struggling on the focus itself, deepening it with a
    // different style is a valid path
    const fe = overlay.nodes[f];
    if (fe && fe.mastery < 0.5) consider(f, 0.5, "deepen", "focus itself is not yet mastered – re-explain differently");
  }

  const next_paths = [...candidates.values()].sort((a, b) => b.score - a.score).slice(0, limit);
  return { next_paths, dormant_nearby: [...dormantNearby].slice(0, 5) };
}

function clamp(x: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, x));
}
function clampInt(x: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, Math.trunc(x)));
}
