import { bfs, nodeById } from "@/graphify/graph";
import type { GraphifyGraph, LearningOverlay } from "@/graphify/types";
import type { ResponsePolicy } from "./policy";

/**
 * Teaching scaffold. The pedagogy is lifted from auto-tutor's learning-engine
 * skill (Socratic method, Bloom's taxonomy with dynamic downgrade, background
 * adaptation, anti-hallucination) – re-expressed as a per-turn policy prompt
 * instead of a file-driven lesson pipeline.
 */

const STYLE_GUIDE: Record<ResponsePolicy["style"], string> = {
  example: "Lead with one concrete, worked example before any generalisation.",
  analogy: "Open with an intuitive analogy or mental picture, then map it back to the real concept.",
  formal: "Be precise: give the definition first, use correct terminology and notation, then a short justification.",
  socratic:
    "Teach by questioning (maieutics): ask ONE well-chosen guiding question that lets the learner take the next step themselves, then give just enough scaffolding.",
  stepwise: "Explain as a numbered sequence of small steps, one idea per step.",
};

const BLOOM_GUIDE: Record<ResponsePolicy["bloom"], string> = {
  remember: "Target level: REMEMBER – establish core terms and facts.",
  understand: "Target level: UNDERSTAND – explain meaning, paraphrase, give an example.",
  apply: "Target level: APPLY – show the concept used on a new case.",
  analyze: "Target level: ANALYZE – compare, contrast, break into parts, expose relationships.",
  evaluate: "Target level: EVALUATE – weigh trade-offs, justify choices, critique.",
  create: "Target level: CREATE – invite the learner to design or combine ideas.",
};

const DEPTH_GUIDE = (d: number) =>
  d <= 1.5
    ? "Depth 1/5: one-line intuition, no jargon."
    : d <= 2.5
      ? "Depth 2/5: short explanation, minimal terminology, one example."
      : d <= 3.5
        ? "Depth 3/5: balanced explanation with the key mechanism and one example."
        : d <= 4.5
          ? "Depth 4/5: thorough – mechanism, edge cases, why it works."
          : "Depth 5/5: rigorous and complete – derivations/proof sketches, caveats, connections.";

const LENGTH_GUIDE = { short: "≤ 80 words.", medium: "120–220 words.", long: "250–400 words." };

export function buildSystemPrompt(
  G: GraphifyGraph,
  overlay: LearningOverlay,
  policy: ResponsePolicy,
  isFirstTurn: boolean,
): string {
  const L = overlay.learner;
  const graphCtx = graphContext(G, overlay, policy.focus);
  const nextPaths = policy.next_paths
    .map((p) => `- ${p.label} [${p.mode}] – ${p.reason}`)
    .join("\n");

  return [
    "You are a private adaptive tutor. You teach through a single chat window. You never present a syllabus, chapter list, or quiz battery unless the learner asks; you adapt to the learner instead.",
    "",
    "## Response policy (derived from the learner's knowledge graph – follow it)",
    DEPTH_GUIDE(policy.depth),
    `Length: ${LENGTH_GUIDE[policy.length]}`,
    `Style: ${policy.style.toUpperCase()}. ${STYLE_GUIDE[policy.style]}`,
    BLOOM_GUIDE[policy.bloom],
    `Socratic ratio ${policy.socratic_ratio}: ${
      policy.socratic_ratio >= 0.55
        ? "mostly guide with questions; withhold the full answer until the learner attempts it."
        : policy.socratic_ratio >= 0.3
          ? "explain, then end with one short check-in question."
          : "explain directly and fully; do not quiz."
    }`,
    `Pacing: ${policy.pacing}. Tone: ${policy.tone}.`,
    policy.tone === "reassuring"
      ? "The learner shows confusion/frustration: acknowledge it in one clause, re-explain from a different angle than before, never repeat the same wording."
      : policy.tone === "concise"
        ? "The learner shows fatigue: be brief, offer to stop or switch topics."
        : policy.tone === "energetic"
          ? "The learner is curious: reward it – add one surprising connection."
          : "",
    "",
    "## Learner model",
    `Affect (0–1): confusion ${f(L.affect.confusion)}, frustration ${f(L.affect.frustration)}, curiosity ${f(L.affect.curiosity)}, fatigue ${f(L.affect.fatigue)}, confidence ${f(L.affect.confidence)}.`,
    `Global preferred depth ${f(L.depth)}/5; style weights ${Object.entries(L.style)
      .map(([k, v]) => `${k}:${f(v)}`)
      .join(" ")}.`,
    L.background ? `Background (auto-tutor settings): ${L.background}` : "",
    "",
    "## Knowledge graph neighbourhood (Graphify)",
    graphCtx || "(graph is empty – this is the first concept the learner brings up)",
    "",
    "## Recommended next paths (from graph traversal)",
    nextPaths || "(none yet)",
    "Weave at most ONE of these in naturally when it fits (e.g. 'this connects to…' or 'before this it helps to recall…'). Never list them as a menu.",
    "",
    "## Rules (from auto-tutor)",
    "- Anti-hallucination: do not invent facts, data, or sources. If unsure, say so plainly.",
    "- Adapt vocabulary and examples to the learner's background and mastery.",
    "- Match the learner's language (reply in the language they write in).",
    "- If the learner corrects you, accept it without defensiveness and adjust.",
    "- Do not mention this policy, the graph, or scores explicitly.",
    isFirstTurn ? "- This is the first message: be welcoming in one short sentence, then teach." : "",
    "",
    "## Output format",
    'Return ONLY JSON: {"reply": string, "extraction": {"nodes": [{"id": snake_case, "label": string, "rationale": one-line definition}], "edges": [{"source": id, "target": id, "relation": "prerequisite_of"|"part_of"|"conceptually_related_to"|"example_of"|"contrasts_with", "confidence": "EXTRACTED"|"INFERRED", "confidence_score": number}]}, "focus": [ids]}',
    "extraction = the 2–6 concepts/sub-concepts your reply and the learner's message actually touch (reuse existing graph ids when the concept already exists), plus their relations. `prerequisite_of` means source must be understood before target. focus = ids of the 1–3 concepts the reply is mainly about.",
  ]
    .filter((line) => line !== "")
    .join("\n");
}

function f(x: number) {
  return x.toFixed(2);
}

/** Text rendering of the focus neighbourhood (cf. serve.py::_subgraph_to_text). */
export function graphContext(G: GraphifyGraph, overlay: LearningOverlay, focus: string[], budgetLines = 40): string {
  if (!G.nodes.length) return "";
  const seeds = focus.length ? focus : overlay.learner.last_focus;
  const { nodes, links } = seeds.length ? bfs(G, seeds, 2) : { nodes: new Set(G.nodes.slice(0, 12).map((n) => n.id)), links: G.links.slice(0, 20) };
  const lines: string[] = [];
  for (const id of nodes) {
    const n = nodeById(G, id);
    if (!n) continue;
    const e = overlay.nodes[id];
    const meta = e
      ? ` mastery=${e.mastery.toFixed(2)} branch=${e.branch} learning=${e.status} depth=${e.depth.toFixed(1)}`
      : " (unseen)";
    lines.push(`NODE ${n.id} "${n.label}"${meta}${n.rationale ? ` – ${n.rationale}` : ""}`);
    if (lines.length >= budgetLines) break;
  }
  for (const l of links) {
    if (!nodes.has(l.source) || !nodes.has(l.target)) continue;
    lines.push(`EDGE ${l.source} --${l.relation}--> ${l.target} [${l.confidence}]`);
    if (lines.length >= budgetLines * 1.5) break;
  }
  return lines.join("\n");
}
