import type { GraphState } from "@/graphify/store";
import { activation, topStyle } from "./overlay";
import { derivePolicy, type ResponsePolicy } from "./policy";

export interface StateSummary {
  nodes: number;
  edges: number;
  active: number;
  dormant: number;
  turns: number;
  learner: {
    depth: number;
    style: string;
    style_mix: Record<string, number>;
    affect: Record<string, number>;
  };
  strongest: Array<{ id: string; label: string; mastery: number; activation: number; status: string; branch: string }>;
  dormant_branches: Array<{ id: string; label: string; last: string; mastery: number }>;
  policy: ResponsePolicy;
}

export function summarize(state: GraphState, now = new Date()): StateSummary {
  const { graph, overlay } = state;
  const L = overlay.learner;
  const entries = Object.entries(overlay.nodes);
  const hl = L.half_life_days;
  const strongest = entries
    .filter(([, e]) => e.branch === "active")
    .sort((a, b) => activation(b[1], now, hl) - activation(a[1], now, hl))
    .slice(0, 6)
    .map(([id, e]) => ({
      id,
      label: e.label,
      mastery: Number(e.mastery.toFixed(2)),
      activation: Number(activation(e, now, hl).toFixed(2)),
      status: e.status,
      branch: e.branch,
    }));
  const dormant = entries
    .filter(([, e]) => e.branch === "dormant")
    .sort((a, b) => Date.parse(b[1].last) - Date.parse(a[1].last))
    .slice(0, 6)
    .map(([id, e]) => ({ id, label: e.label, last: e.last, mastery: Number(e.mastery.toFixed(2)) }));

  return {
    nodes: graph.nodes.length,
    edges: graph.links.length,
    active: entries.filter(([, e]) => e.branch === "active").length,
    dormant: entries.filter(([, e]) => e.branch === "dormant").length,
    turns: L.turns,
    learner: {
      depth: Number(L.depth.toFixed(2)),
      style: topStyle(L.style),
      style_mix: Object.fromEntries(Object.entries(L.style).map(([k, v]) => [k, Number(v.toFixed(2))])),
      affect: Object.fromEntries(Object.entries(L.affect).map(([k, v]) => [k, Number(v.toFixed(2))])),
    },
    strongest,
    dormant_branches: dormant,
    policy: derivePolicy(graph, overlay, L.last_focus, now),
  };
}
