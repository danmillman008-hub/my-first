import {
  coerceExtraction,
  findMentionedNodes,
  mergeExtraction,
  validateExtraction,
} from "@/graphify/graph";
import {
  appendInteraction,
  loadState,
  recentHistory,
  saveState,
  type GraphState,
} from "@/graphify/store";
import type { Style } from "@/graphify/types";
import { generateJson, llmConfigured, type ChatTurn } from "./llm";
import { applyDecay, applyTurn } from "./overlay";
import { derivePolicy, type ResponsePolicy } from "./policy";
import { buildSystemPrompt } from "./prompts";
import { analyzeTurn, type TurnSignals } from "./signals";

interface LlmTurnPayload {
  reply?: string;
  extraction?: unknown;
  focus?: unknown;
}

export interface TurnResult {
  reply: string;
  policy: ResponsePolicy;
  signals: TurnSignals;
  touched: string[];
  added: string[];
  reactivated: string[];
  newlyDormant: string[];
  llm: boolean;
}

/**
 * One chat turn. Everything adaptive happens here, in order:
 *  1. decay pass over the sidecar (branches may go dormant)
 *  2. signals from the user message
 *  3. focus = graph nodes mentioned (fallback: previous focus on follow-ups)
 *  4. policy from graph + overlay state
 *  5. LLM reply + graphify-schema extraction, merged into graph.json
 *  6. overlay update (strengthen/propagate/reactivate), persist
 */
export async function runTurn(userText: string, slug = "default"): Promise<TurnResult> {
  const state = await loadState(slug);
  const { graph: G, overlay } = state;
  const now = new Date();

  const newlyDormant = applyDecay(overlay, now);

  const prevFocus = overlay.learner.last_focus;
  let focus = findMentionedNodes(G, userText);
  const signals = analyzeTurn(userText, {
    prevFocus,
    focus,
    followUpStreak: overlay.learner.follow_up_streak,
    avgLen: overlay.learner.avg_msg_len,
  });
  // Short follow-ups ("why?", "simpler please") inherit the previous focus.
  if (!focus.length && prevFocus.length && (signals.length < 80 || signals.correction)) {
    focus = prevFocus;
    signals.follow_up = true;
  }

  const policy = derivePolicy(G, overlay, focus, now, signals);

  const history = await recentHistory(slug, 10);
  const turnNo = (history.at(-1)?.turn ?? 0) + 1;
  const chat: ChatTurn[] = history.map((h) => ({
    role: h.role === "user" ? "user" : "model",
    text: h.content,
  }));
  chat.push({ role: "user", text: userText });

  const system = buildSystemPrompt(G, overlay, policy, history.length === 0);
  const payload = llmConfigured() ? await generateJson<LlmTurnPayload>(system, chat) : null;

  let reply: string;
  let touched: string[] = [...focus];
  let added: string[] = [];
  if (payload?.reply) {
    reply = payload.reply;
    const ex = coerceExtraction(payload.extraction, "chat");
    const errors = validateExtraction(ex);
    if (!errors.length && ex.nodes.length) {
      const merged = mergeExtraction(G, ex);
      added = merged.added;
      touched = [...new Set([...touched, ...merged.touched])];
    }
    if (Array.isArray(payload.focus)) {
      const llmFocus = payload.focus
        .map((x) => String(x))
        .filter((id) => G.nodes.some((n) => n.id === id));
      if (llmFocus.length) {
        // LLM-reported focus becomes the anchor for the next turn's credit
        // assignment; keep matched nodes too.
        touched = [...new Set([...llmFocus, ...touched])];
      }
    }
  } else {
    reply = fallbackReply(policy, signals, state);
  }

  const { reactivated } = applyTurn(G, overlay, {
    touched,
    prevFocus,
    signals,
    userText,
    chosenStyle: policy.style as Style,
    chosenDepth: policy.depth,
    now,
  });

  // Rebuild next paths against the updated graph so the panel shows what the
  // tutor will lean towards *next*.
  const post = derivePolicy(G, overlay, overlay.learner.last_focus, now);
  policy.next_paths = post.next_paths;
  policy.dormant_nearby = post.dormant_nearby;

  await saveState(state);
  await appendInteraction({ slug, role: "user", content: userText, turn: turnNo, signals, concepts: focus });
  await appendInteraction({ slug, role: "tutor", content: reply, turn: turnNo, policy, concepts: touched });

  return { reply, policy, signals, touched, added, reactivated, newlyDormant, llm: Boolean(payload?.reply) };
}

/** Deterministic fallback when no LLM key is configured or the call fails. */
function fallbackReply(policy: ResponsePolicy, signals: TurnSignals, state: GraphState): string {
  const focusLabels = policy.focus.map((id) => state.graph.nodes.find((n) => n.id === id)?.label ?? id);
  const next = policy.next_paths[0];
  const parts: string[] = [];
  if (!llmConfigured()) parts.push("(No GEMINI_API_KEY configured – running in graph-only mode.)");
  else parts.push("(The language model was unavailable for this turn; the graph state was still updated.)");
  if (focusLabels.length) parts.push(`Focus: ${focusLabels.join(", ")}.`);
  parts.push(
    `Current policy → depth ${policy.depth}/5, style ${policy.style}, Bloom level ${policy.bloom}, tone ${policy.tone}.`,
  );
  if (signals.affect.confusion > 0.5) parts.push("I can tell this is not landing yet – I will simplify next time.");
  if (next) parts.push(`Suggested next path: ${next.label} (${next.mode}).`);
  return parts.join(" ");
}
