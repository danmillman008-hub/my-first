import { adjacency, nodeById } from "@/graphify/graph";
import type {
  Affect,
  GraphifyGraph,
  LearnerModel,
  LearningOverlay,
  LearningStatus,
  OverlayEntry,
  Style,
  StyleWeights,
} from "@/graphify/types";
import type { TurnSignals } from "./signals";

/* Scoring defaults mirror graphify/reflect.py */
const DEFAULT_HALF_LIFE_DAYS = 30;
const MIN_CORROBORATION = 2; // distinct useful results needed to "prefer"
const PROVENANCE_CAP = 5;
/** activation below this (after decay) parks a branch as dormant */
const DORMANT_THRESHOLD = 0.35;
const REACTIVATION_BOOST = 1.25;
const PROPAGATION = 0.3; // preference propagation factor to 1-hop neighbours

export const STYLES: Style[] = ["example", "analogy", "formal", "socratic", "stepwise"];

export function uniformStyle(): StyleWeights {
  return { example: 1, analogy: 1, formal: 1, socratic: 1, stepwise: 1 };
}

export function emptyLearner(): LearnerModel {
  return {
    depth: 3,
    style: uniformStyle(),
    affect: { confusion: 0, frustration: 0, curiosity: 0.2, fatigue: 0, confidence: 0.3 },
    turns: 0,
    avg_msg_len: 0,
    follow_up_streak: 0,
    last_focus: [],
    last_style: null,
    last_depth: null,
    half_life_days: DEFAULT_HALF_LIFE_DAYS,
    background: "",
  };
}

export function emptyOverlay(): LearningOverlay {
  return {
    version: 1,
    generated_at: new Date().toISOString(),
    nodes: {},
    learner: emptyLearner(),
  };
}

/** graphify/reflect.py::_decay – weight halves every half_life_days. */
export function decay(dateStr: string, now: Date, halfLifeDays: number): number {
  const dt = Date.parse(dateStr);
  if (Number.isNaN(dt) || halfLifeDays <= 0) return 1;
  const ageDays = Math.max(0, (now.getTime() - dt) / 86_400_000);
  return Math.pow(0.5, ageDays / halfLifeDays);
}

export function activation(e: OverlayEntry, now: Date, halfLife: number): number {
  return e.score * decay(e.last, now, halfLife);
}

function statusFor(e: OverlayEntry): LearningStatus {
  // upstream semantics: contested when negatives rival positives; preferred
  // needs corroboration; otherwise tentative.
  if (e.confusions > 0 && e.confusions >= e.successes * 0.75) return "contested";
  if (e.successes >= MIN_CORROBORATION && e.mastery >= 0.5) return "preferred";
  return "tentative";
}

function newEntry(G: GraphifyGraph, id: string, learner: LearnerModel, now: string): OverlayEntry {
  const n = nodeById(G, id);
  return {
    status: "tentative",
    score: 0,
    uses: 0,
    last: now,
    label: n?.label ?? id,
    source_file: n?.source_file ?? "chat",
    code_fingerprint: "",
    provenance: [],
    branch: "active",
    mastery: 0.2,
    successes: 0,
    confusions: 0,
    depth: learner.depth,
    style: { ...learner.style },
    reactivations: 0,
  };
}

function ema(prev: number, x: number, alpha: number): number {
  return prev * (1 - alpha) + x * alpha;
}

function normalizeStyle(s: StyleWeights): StyleWeights {
  const total = STYLES.reduce((a, k) => a + Math.max(0.05, s[k] ?? 0), 0) || 1;
  const out = { ...s };
  for (const k of STYLES) out[k] = (Math.max(0.05, s[k] ?? 0) / total) * STYLES.length;
  return out;
}

export function topStyle(s: StyleWeights): Style {
  return STYLES.reduce((best, k) => (s[k] > s[best] ? k : best), STYLES[0]);
}

/**
 * Pass 1 – time decay. Recomputes branch state for every node from decayed
 * activation. Returns ids that just went dormant.
 */
export function applyDecay(overlay: LearningOverlay, now = new Date()): string[] {
  const hl = overlay.learner.half_life_days || DEFAULT_HALF_LIFE_DAYS;
  const newlyDormant: string[] = [];
  for (const [id, e] of Object.entries(overlay.nodes)) {
    const act = activation(e, now, hl);
    if (e.branch === "active" && act < DORMANT_THRESHOLD && e.uses > 0) {
      e.branch = "dormant";
      newlyDormant.push(id);
    }
  }
  return newlyDormant;
}

/**
 * Pass 2 – strengthen concepts touched this turn, propagate preferences to
 * neighbours, reactivate dormant branches that came back into use, and fold
 * the turn's signals into the learner model.
 */
export function applyTurn(
  G: GraphifyGraph,
  overlay: LearningOverlay,
  input: {
    touched: string[];
    prevFocus: string[];
    signals: TurnSignals;
    userText: string;
    chosenStyle: Style | null;
    chosenDepth: number | null;
    now?: Date;
  },
): { reactivated: string[] } {
  const now = input.now ?? new Date();
  const nowIso = now.toISOString();
  const L = overlay.learner;
  const s = input.signals;
  const reactivated: string[] = [];

  /* ---- learner-level updates -------------------------------------- */
  L.turns += 1;
  L.avg_msg_len = L.turns === 1 ? s.length : ema(L.avg_msg_len, s.length, 0.2);
  L.follow_up_streak = s.follow_up ? L.follow_up_streak + 1 : 0;
  for (const k of Object.keys(L.affect) as (keyof Affect)[]) {
    L.affect[k] = ema(L.affect[k], s.affect[k], 0.35);
  }
  // Depth: explicit requests dominate; repeated confusion nudges simpler
  // (auto-tutor's "dynamic downgrade"); sustained confidence + curiosity
  // nudges deeper.
  let depthDelta = s.depth_request * 0.6;
  if (L.affect.confusion > 0.5 && L.follow_up_streak >= 2) depthDelta -= 0.35;
  if (L.affect.confidence > 0.5 && L.affect.curiosity > 0.4) depthDelta += 0.2;
  if (L.affect.fatigue > 0.5) depthDelta -= 0.25;
  L.depth = clamp(L.depth + depthDelta, 1, 5);

  // Style: explicit cues + reinforcement of whatever style the previous
  // tutor turn used, scaled by this turn's outcome (path selection by prior
  // success).
  for (const [k, v] of Object.entries(s.style_cues) as [Style, number][]) {
    L.style[k] += 0.6 * v;
  }
  if (L.last_style) {
    L.style[L.last_style] += (s.outcome - 0.5) * 0.8;
  }
  L.style = normalizeStyle(L.style);

  /* ---- previous focus: credit / blame the last explanation -------- */
  // The user's reaction tells us how well the *previous* explanation of
  // prevFocus landed. Apply outcome to those nodes.
  for (const id of input.prevFocus) {
    const e = overlay.nodes[id];
    if (!e) continue;
    e.mastery = clamp(ema(e.mastery, s.outcome, 0.3), 0, 1);
    if (s.outcome >= 0.7) e.successes += 1;
    if (s.outcome <= 0.35) e.confusions += 1;
    if (L.last_style) e.style[L.last_style] += (s.outcome - 0.5) * 0.6;
    if (L.last_depth != null) {
      // Depth that worked is remembered per concept.
      e.depth = clamp(ema(e.depth, s.outcome >= 0.6 ? L.last_depth : L.depth, 0.3), 1, 5);
    }
    e.style = normalizeStyle(e.style);
    pushProvenance(e, input.userText, nowIso, s.outcome >= 0.5 ? "useful" : "not_useful");
    e.status = statusFor(e);
  }

  /* ---- touched nodes: strengthen + reactivate ----------------------- */
  const hl = L.half_life_days || DEFAULT_HALF_LIFE_DAYS;
  const usefulness = 0.6 + s.outcome * 0.6 + s.affect.curiosity * 0.3; // 0.6..1.5
  for (const id of input.touched) {
    let e = overlay.nodes[id];
    if (!e) {
      e = newEntry(G, id, L, nowIso);
      overlay.nodes[id] = e;
    }
    // collapse decayed score to "now" before adding, so `last` stays a
    // faithful anchor for the next decay.
    e.score = activation(e, now, hl) + usefulness;
    e.last = nowIso;
    e.uses += 1;
    if (e.branch === "dormant") {
      e.branch = "active";
      e.score += REACTIVATION_BOOST;
      e.reactivations += 1;
      reactivated.push(id);
    }
    // depth/style preference drifts toward the learner's current preference
    e.depth = clamp(ema(e.depth, L.depth, 0.25), 1, 5);
    for (const k of STYLES) e.style[k] = ema(e.style[k], L.style[k], 0.25);
    e.style = normalizeStyle(e.style);
    e.status = statusFor(e);
  }

  /* ---- preference propagation to 1-hop neighbours ------------------- */
  const adj = adjacency(G);
  const touchedSet = new Set(input.touched);
  for (const id of input.touched) {
    const src = overlay.nodes[id];
    if (!src) continue;
    for (const nb of adj.get(id) ?? []) {
      if (touchedSet.has(nb.id)) continue;
      const w = PROPAGATION * (nb.link.confidence_score ?? 0.75);
      let e = overlay.nodes[nb.id];
      if (!e) {
        e = newEntry(G, nb.id, L, nowIso);
        overlay.nodes[nb.id] = e;
      }
      e.depth = clamp(ema(e.depth, src.depth, w), 1, 5);
      for (const k of STYLES) e.style[k] = ema(e.style[k], src.style[k], w);
      e.style = normalizeStyle(e.style);
      // a little spill-over activation keeps closely related branches warm
      e.score = activation(e, now, hl) + 0.15 * w * 3;
      e.last = nowIso;
    }
  }

  L.last_focus = input.touched.slice(0, 5);
  L.last_style = input.chosenStyle;
  L.last_depth = input.chosenDepth;
  return { reactivated };
}

function pushProvenance(e: OverlayEntry, question: string, date: string, outcome: "useful" | "not_useful") {
  e.provenance.unshift({ question: question.slice(0, 160), date, outcome });
  if (e.provenance.length > PROVENANCE_CAP) e.provenance.length = PROVENANCE_CAP;
}

function clamp(x: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, x));
}

/** Manually re-open a dormant branch (used by the MCP mutation tool). */
export function reactivate(overlay: LearningOverlay, id: string, now = new Date()): boolean {
  const e = overlay.nodes[id];
  if (!e) return false;
  const hl = overlay.learner.half_life_days || DEFAULT_HALF_LIFE_DAYS;
  e.score = activation(e, now, hl) + REACTIVATION_BOOST;
  e.last = now.toISOString();
  e.branch = "active";
  e.reactivations += 1;
  return true;
}
