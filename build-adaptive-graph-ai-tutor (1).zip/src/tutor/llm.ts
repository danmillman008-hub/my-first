/**
 * Minimal Gemini REST client (no SDK). The key is only ever read server-side.
 */
const FALLBACK_MODELS = ["gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-3-flash-preview"];
const MODELS = [
  ...new Set([process.env.GEMINI_MODEL ?? FALLBACK_MODELS[0], ...FALLBACK_MODELS]),
];
const endpoint = (model: string) =>
  `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
/** statuses worth retrying on the next model (retired model, quota, overload) */
const RETRYABLE = new Set([404, 429, 503]);

export interface ChatTurn {
  role: "user" | "model";
  text: string;
}

export function llmConfigured(): boolean {
  return Boolean(process.env.GEMINI_API_KEY);
}

export async function generateJson<T>(
  system: string,
  history: ChatTurn[],
  opts: { temperature?: number; maxOutputTokens?: number } = {},
): Promise<T | null> {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return null;
  const body = {
    systemInstruction: { parts: [{ text: system }] },
    contents: history.map((h) => ({ role: h.role, parts: [{ text: h.text }] })),
    generationConfig: {
      temperature: opts.temperature ?? 0.6,
      maxOutputTokens: opts.maxOutputTokens ?? 8192,
      responseMimeType: "application/json",
    },
  };
  for (const model of MODELS) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 45_000);
    try {
      const res = await fetch(endpoint(model), {
        method: "POST",
        headers: { "content-type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify(body),
        signal: ctrl.signal,
      });
      if (!res.ok) {
        console.error("[gemini]", model, res.status, (await res.text()).slice(0, 200));
        if (RETRYABLE.has(res.status)) continue;
        return null;
      }
      const data = (await res.json()) as {
        candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
      };
      const text = data.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
      const parsed = parseJson<T>(text);
      if (parsed === null) {
        console.error("[gemini] unparseable response from", model, JSON.stringify(data).slice(0, 300));
      }
      return parsed;
    } catch (err) {
      console.error("[gemini] request failed", model, err);
      continue;
    } finally {
      clearTimeout(timer);
    }
  }
  return null;
}

function parseJson<T>(text: string): T | null {
  const cleaned = text.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  try {
    return JSON.parse(cleaned) as T;
  } catch {
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(cleaned.slice(start, end + 1)) as T;
      } catch {
        return null;
      }
    }
    return null;
  }
}
