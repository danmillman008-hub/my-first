import type { AffectKey, Style } from "@/graphify/types";

/**
 * Lightweight interaction-signal layer. Not emotion recognition — a set of
 * cheap, explainable indicators that feed the overlay update and the policy.
 */
export interface TurnSignals {
  length: number;
  /** -1 (wants simpler / shorter) .. +1 (wants deeper / more) */
  depth_request: number;
  /** explicit or implicit style cues */
  style_cues: Partial<Record<Style, number>>;
  /** normalized 0..1 indicators */
  affect: Record<AffectKey, number>;
  /** user is correcting the tutor ("no, I meant…") */
  correction: boolean;
  /** user reports comprehension ("got it", "makes sense") */
  understood: boolean;
  /** user is asking a question at all */
  question: boolean;
  /** same focus as previous turn (repeated follow-up) */
  follow_up: boolean;
  /** derived scalar: how useful the previous explanation seems to have been */
  outcome: number; // 0..1
}

const RX = {
  confusion:
    /\b(confus|don'?t (get|understand|follow)|not (sure|clear)|lost|huh|what do you mean|unclear|no idea|wait,? what|i'?m stuck|makes no sense)\b|\?\?+/i,
  frustration:
    /\b(ugh|still (don'?t|not)|again|frustrat|annoy|this is (hard|impossible)|wrong|useless|come on|seriously)\b/i,
  curiosity:
    /\b(interesting|cool|fascinating|curious|what about|what if|why does|how come|tell me more|wow|neat|love this)\b|!\s*$/i,
  fatigue:
    /\b(tired|bored|boring|whatever|enough|too long|tl;?dr|skip|move on|later|meh|ok+|k|fine|sure)\b/i,
  confidence:
    /\b(got it|makes sense|i see|understood|clear now|that helps|thanks|thank you|right,? so|so basically|in other words|ah+|oh+ (i see|right|ok))\b/i,
  deeper:
    /\b(more detail|in depth|deeper|elaborate|why exactly|rigorous|prove|derivation|formally|under the hood|precisely|expand on|go further)\b/i,
  simpler:
    /\b(simpl(er|y|ify)|eli5|like i'?m (5|five)|plain (english|words)|shorter|briefly|in short|summar(y|ize)|too (much|complicated|complex)|slow down|basics?)\b/i,
  correction:
    /^(no|nope|not (that|quite|really)|actually|i meant|that'?s not|wrong)\b|\b(i meant|not what i asked|you misunderstood)\b/i,
  example: /\b(example|for instance|show me|concrete|real[- ]world|use case|demo)\b/i,
  analogy: /\b(analogy|like a|compare|metaphor|intuiti|picture|imagine)\b/i,
  formal: /\b(formal|definition|define|theorem|proof|rigorous|precise|notation|equation|mathematically)\b/i,
  stepwise: /\b(step[- ]by[- ]step|walk me through|steps?|procedure|how do i|checklist|one at a time)\b/i,
  socratic: /\b(let me try|i think|my guess|is it because|could it be|i'?d say)\b/i,
};

function clamp01(x: number): number {
  return Math.max(0, Math.min(1, x));
}

export function analyzeTurn(
  text: string,
  ctx: { prevFocus: string[]; focus: string[]; followUpStreak: number; avgLen: number },
): TurnSignals {
  const t = text.trim();
  const len = t.length;
  const words = t.split(/\s+/).filter(Boolean).length;

  const hit = (k: keyof typeof RX) => (RX[k].test(t) ? 1 : 0);

  const correction = Boolean(hit("correction"));
  const understood = Boolean(hit("confidence")) && !correction;
  const question = /\?/.test(t) || /^(what|why|how|when|where|which|can|could|does|is|are|explain)\b/i.test(t);
  const follow_up =
    ctx.focus.length > 0 && ctx.prevFocus.length > 0 && ctx.focus.some((f) => ctx.prevFocus.includes(f));

  // Very short replies in a streak are a boredom/fatigue tell; very long
  // messages signal engagement and tolerance for depth.
  const shortStreak = words <= 3 && ctx.followUpStreak >= 2 ? 0.4 : 0;
  const lenRatio = ctx.avgLen > 0 ? len / ctx.avgLen : 1;

  const affect: Record<AffectKey, number> = {
    confusion: clamp01(hit("confusion") * 0.8 + (follow_up && question ? 0.25 : 0) + (correction ? 0.2 : 0)),
    frustration: clamp01(hit("frustration") * 0.7 + (correction ? 0.3 : 0) + (ctx.followUpStreak >= 3 ? 0.2 : 0)),
    curiosity: clamp01(hit("curiosity") * 0.7 + (question && lenRatio > 1.3 ? 0.25 : 0)),
    fatigue: clamp01(hit("fatigue") * (words <= 6 ? 0.7 : 0.3) + shortStreak),
    confidence: clamp01((understood ? 0.8 : 0) + hit("socratic") * 0.3),
  };

  const depth_request = clamp1(
    hit("deeper") * 0.8 - hit("simpler") * 0.8 + (lenRatio > 1.6 ? 0.15 : lenRatio < 0.5 ? -0.15 : 0),
  );

  const style_cues: Partial<Record<Style, number>> = {};
  for (const s of ["example", "analogy", "formal", "stepwise", "socratic"] as Style[]) {
    if (RX[s].test(t)) style_cues[s] = 1;
  }

  // Outcome of the *previous* tutor turn as seen through this user turn.
  const outcome = clamp01(
    0.55 +
      (understood ? 0.35 : 0) +
      affect.curiosity * 0.15 -
      affect.confusion * 0.45 -
      (correction ? 0.3 : 0) -
      affect.frustration * 0.2,
  );

  return {
    length: len,
    depth_request,
    style_cues,
    affect,
    correction,
    understood,
    question,
    follow_up,
    outcome,
  };
}

function clamp1(x: number): number {
  return Math.max(-1, Math.min(1, x));
}
