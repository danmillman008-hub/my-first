import { and, asc, desc, eq } from "drizzle-orm";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { db } from "@/db";
import { graphs, interactions } from "@/db/schema";
import { emptyGraph } from "./graph";
import { emptyOverlay } from "@/tutor/overlay";
import type { GraphifyGraph, LearningOverlay } from "./types";

/** Same defaults as graphify/paths.py + reflect.py. */
export const GRAPHIFY_OUT = process.env.GRAPHIFY_OUT ?? "graphify-out";
export const LEARNING_SIDECAR_NAME = ".graphify_learning.json";
export const DEFAULT_SLUG = "default";

export interface GraphState {
  slug: string;
  graph: GraphifyGraph;
  overlay: LearningOverlay;
}

export async function loadState(slug = DEFAULT_SLUG): Promise<GraphState> {
  const row = await db.select().from(graphs).where(eq(graphs.slug, slug)).limit(1);
  if (row.length) {
    return {
      slug,
      graph: row[0].graph as GraphifyGraph,
      overlay: row[0].overlay as LearningOverlay,
    };
  }
  const state: GraphState = { slug, graph: emptyGraph(), overlay: emptyOverlay() };
  await db
    .insert(graphs)
    .values({ slug, graph: state.graph, overlay: state.overlay })
    .onConflictDoNothing();
  return state;
}

export async function saveState(state: GraphState): Promise<void> {
  state.overlay.generated_at = new Date().toISOString();
  await db
    .insert(graphs)
    .values({ slug: state.slug, graph: state.graph, overlay: state.overlay })
    .onConflictDoUpdate({
      target: graphs.slug,
      set: { graph: state.graph, overlay: state.overlay, updatedAt: new Date() },
    });
  await mirrorToDisk(state).catch(() => undefined); // best-effort
}

/**
 * Write `graphify-out/graph.json` + `.graphify_learning.json` exactly where
 * the upstream tools look for them, with graphify's canonical key ordering
 * (export.py: identity keys first, rest sorted; sorted, indented JSON).
 */
export async function mirrorToDisk(state: GraphState): Promise<void> {
  const dir = path.join(process.cwd(), GRAPHIFY_OUT);
  await mkdir(dir, { recursive: true });
  const canonical = (item: Record<string, unknown>, lead: string[]) => {
    const out: Record<string, unknown> = {};
    for (const k of lead) if (k in item) out[k] = item[k];
    for (const k of Object.keys(item).sort()) if (!(k in out)) out[k] = item[k];
    return out;
  };
  const doc = {
    ...state.graph,
    nodes: state.graph.nodes.map((n) => canonical(n, ["id", "label"])),
    links: state.graph.links.map((l) => canonical(l, ["source", "target", "relation"])),
  };
  await writeFile(path.join(dir, "graph.json"), JSON.stringify(doc, null, 2) + "\n");
  await writeFile(
    path.join(dir, LEARNING_SIDECAR_NAME),
    JSON.stringify(state.overlay, null, 2) + "\n",
  );
}

/* ------------------------------------------------------------------------ */
/* Interaction history                                                      */
/* ------------------------------------------------------------------------ */

export interface HistoryMessage {
  id: number;
  role: "user" | "tutor";
  content: string;
  signals: unknown;
  policy: unknown;
  concepts: string[] | null;
  turn: number;
  createdAt: Date;
}

export async function recentHistory(slug: string, limit = 12): Promise<HistoryMessage[]> {
  const rows = await db
    .select()
    .from(interactions)
    .where(eq(interactions.graphSlug, slug))
    .orderBy(desc(interactions.createdAt), desc(interactions.id))
    .limit(limit);
  return rows.reverse().map((r) => ({
    id: r.id,
    role: r.role as "user" | "tutor",
    content: r.content,
    signals: r.signals,
    policy: r.policy,
    concepts: r.concepts ?? null,
    turn: r.turn,
    createdAt: r.createdAt,
  }));
}

export async function fullHistory(slug: string): Promise<HistoryMessage[]> {
  const rows = await db
    .select()
    .from(interactions)
    .where(eq(interactions.graphSlug, slug))
    .orderBy(asc(interactions.createdAt), asc(interactions.id));
  return rows.map((r) => ({
    id: r.id,
    role: r.role as "user" | "tutor",
    content: r.content,
    signals: r.signals,
    policy: r.policy,
    concepts: r.concepts ?? null,
    turn: r.turn,
    createdAt: r.createdAt,
  }));
}

export async function appendInteraction(input: {
  slug: string;
  role: "user" | "tutor";
  content: string;
  turn: number;
  signals?: unknown;
  policy?: unknown;
  concepts?: string[];
}): Promise<void> {
  await db.insert(interactions).values({
    graphSlug: input.slug,
    role: input.role,
    content: input.content,
    turn: input.turn,
    signals: input.signals ?? null,
    policy: input.policy ?? null,
    concepts: input.concepts ?? null,
  });
}

export async function resetState(slug = DEFAULT_SLUG): Promise<void> {
  await db.delete(interactions).where(and(eq(interactions.graphSlug, slug)));
  await db.delete(graphs).where(eq(graphs.slug, slug));
}
