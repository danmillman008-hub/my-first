import type {
  Confidence,
  Extraction,
  FileType,
  GraphifyGraph,
  GraphifyLink,
  GraphifyNode,
} from "./types";

/* ------------------------------------------------------------------------ */
/* Constants ported 1:1 from graphify/validate.py                            */
/* ------------------------------------------------------------------------ */
const VALID_FILE_TYPES = new Set<FileType>([
  "code",
  "document",
  "paper",
  "image",
  "rationale",
  "concept",
]);
const VALID_CONFIDENCES = new Set<Confidence>([
  "EXTRACTED",
  "INFERRED",
  "AMBIGUOUS",
]);
/** graphify/export.py::_CONFIDENCE_SCORE_DEFAULTS */
const CONFIDENCE_SCORE_DEFAULTS: Record<Confidence, number> = {
  EXTRACTED: 1.0,
  INFERRED: 0.75,
  AMBIGUOUS: 0.5,
};

export function emptyGraph(): GraphifyGraph {
  return {
    directed: false,
    multigraph: false,
    graph: { hyperedges: [] },
    nodes: [],
    links: [],
  };
}

/** graphify/export.py::_strip_diacritics(...).lower() */
export function normLabel(label: string): string {
  return label
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

/** Stable snake_case id (graphify ids are stems + entity names). */
export function toNodeId(label: string): string {
  return normLabel(label)
    .replace(/[^a-z0-9\u4e00-\u9fff]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 80);
}

/**
 * Port of graphify/validate.py::validate_extraction. Returns error strings;
 * empty list means valid.
 */
export function validateExtraction(data: unknown): string[] {
  if (!data || typeof data !== "object") return ["Extraction must be a JSON object"];
  const d = data as Record<string, unknown>;
  const errors: string[] = [];
  const nodeIds = new Set<string>();

  if (!("nodes" in d)) errors.push("Missing required key 'nodes'");
  else if (!Array.isArray(d.nodes)) errors.push("'nodes' must be a list");
  else {
    d.nodes.forEach((node, i) => {
      if (!node || typeof node !== "object") {
        errors.push(`Node ${i} must be an object`);
        return;
      }
      const n = node as Record<string, unknown>;
      for (const f of ["id", "label", "file_type", "source_file"]) {
        if (!(f in n)) errors.push(`Node ${i} missing required field '${f}'`);
      }
      if (typeof n.id === "string") nodeIds.add(n.id);
      else errors.push(`Node ${i} id must be a string`);
      if ("file_type" in n && !VALID_FILE_TYPES.has(n.file_type as FileType))
        errors.push(`Node ${i} has invalid file_type ${String(n.file_type)}`);
    });
  }

  if (!("edges" in d)) errors.push("Missing required key 'edges'");
  else if (!Array.isArray(d.edges)) errors.push("'edges' must be a list");
  else {
    d.edges.forEach((edge, i) => {
      if (!edge || typeof edge !== "object") {
        errors.push(`Edge ${i} must be an object`);
        return;
      }
      const e = edge as Record<string, unknown>;
      for (const f of ["source", "target", "relation", "confidence", "source_file"]) {
        if (!(f in e)) errors.push(`Edge ${i} missing required field '${f}'`);
      }
      if ("confidence" in e && !VALID_CONFIDENCES.has(e.confidence as Confidence))
        errors.push(`Edge ${i} has invalid confidence ${String(e.confidence)}`);
      if (typeof e.source === "string" && !nodeIds.has(e.source))
        errors.push(`Edge ${i} references unknown source '${e.source}'`);
      if (typeof e.target === "string" && !nodeIds.has(e.target))
        errors.push(`Edge ${i} references unknown target '${e.target}'`);
    });
  }
  return errors;
}

/**
 * Coerce a loosely-shaped LLM payload into a valid Extraction: fixes ids,
 * drops junk, resolves labels->ids for edges. Mirrors the defensive cleanup
 * graphify does in llm.py before validate_extraction.
 */
export function coerceExtraction(raw: unknown, sourceFile: string): Extraction {
  const out: Extraction = { nodes: [], edges: [] };
  if (!raw || typeof raw !== "object") return out;
  const r = raw as { nodes?: unknown; edges?: unknown };
  const byKey = new Map<string, string>(); // norm label / raw id -> id

  if (Array.isArray(r.nodes)) {
    for (const n of r.nodes) {
      if (!n || typeof n !== "object") continue;
      const o = n as Record<string, unknown>;
      const label = String(o.label ?? o.id ?? "").trim();
      if (!label) continue;
      const id = toNodeId(label);
      if (!id || byKey.has(id)) continue;
      byKey.set(id, id);
      byKey.set(normLabel(label), id);
      if (typeof o.id === "string") byKey.set(o.id, id);
      out.nodes.push({
        id,
        label: label.slice(0, 120),
        file_type: "concept",
        source_file: sourceFile,
        source_location: null,
        rationale: typeof o.rationale === "string" ? o.rationale.slice(0, 300) : null,
      });
    }
  }
  if (Array.isArray(r.edges)) {
    const seen = new Set<string>();
    for (const e of r.edges) {
      if (!e || typeof e !== "object") continue;
      const o = e as Record<string, unknown>;
      const s = byKey.get(String(o.source ?? "")) ?? byKey.get(normLabel(String(o.source ?? "")));
      const t = byKey.get(String(o.target ?? "")) ?? byKey.get(normLabel(String(o.target ?? "")));
      if (!s || !t || s === t) continue;
      const relation = String(o.relation ?? "conceptually_related_to")
        .toLowerCase()
        .replace(/[^a-z_]/g, "_");
      const key = `${s}|${t}|${relation}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const confidence = VALID_CONFIDENCES.has(o.confidence as Confidence)
        ? (o.confidence as Confidence)
        : "INFERRED";
      out.edges.push({
        source: s,
        target: t,
        relation,
        confidence,
        confidence_score:
          typeof o.confidence_score === "number"
            ? Math.max(0, Math.min(1, o.confidence_score))
            : CONFIDENCE_SCORE_DEFAULTS[confidence],
        source_file: sourceFile,
        weight: 1.0,
      });
    }
  }
  return out;
}

/**
 * Merge a validated extraction into an existing graph.json document.
 * Dedup by node id / norm_label (graphify's exact-dedup path); repeated edges
 * raise `weight` instead of duplicating (multigraph=false upstream).
 * Returns ids of nodes touched by this merge.
 */
export function mergeExtraction(
  G: GraphifyGraph,
  ex: Extraction,
): { touched: string[]; added: string[] } {
  const byId = new Map(G.nodes.map((n) => [n.id, n]));
  const byNorm = new Map(G.nodes.map((n) => [n.norm_label ?? normLabel(n.label), n.id]));
  const touched = new Set<string>();
  const added: string[] = [];
  const idMap = new Map<string, string>();

  for (const n of ex.nodes) {
    const norm = normLabel(n.label);
    const existing = byId.get(n.id) ?? (byNorm.has(norm) ? byId.get(byNorm.get(norm)!) : undefined);
    if (existing) {
      idMap.set(n.id, existing.id);
      if (!existing.rationale && n.rationale) existing.rationale = n.rationale;
      touched.add(existing.id);
      continue;
    }
    const node: GraphifyNode = {
      id: n.id,
      label: n.label,
      file_type: n.file_type,
      source_file: n.source_file,
      source_location: n.source_location ?? null,
      rationale: n.rationale ?? null,
      community: null,
      norm_label: norm,
    };
    G.nodes.push(node);
    byId.set(node.id, node);
    byNorm.set(norm, node.id);
    idMap.set(n.id, node.id);
    touched.add(node.id);
    added.push(node.id);
  }

  const edgeKey = (s: string, t: string, r: string) =>
    G.directed || s < t ? `${s}|${t}|${r}` : `${t}|${s}|${r}`;
  const edgeIndex = new Map(G.links.map((l) => [edgeKey(l.source, l.target, l.relation), l]));

  for (const e of ex.edges) {
    const s = idMap.get(e.source) ?? e.source;
    const t = idMap.get(e.target) ?? e.target;
    if (!byId.has(s) || !byId.has(t) || s === t) continue;
    const key = edgeKey(s, t, e.relation);
    const existing = edgeIndex.get(key);
    if (existing) {
      existing.weight = (existing.weight ?? 1) + 0.5;
      if (existing.confidence !== "EXTRACTED" && e.confidence === "EXTRACTED") {
        existing.confidence = "EXTRACTED";
        existing.confidence_score = 1.0;
      }
      continue;
    }
    const link: GraphifyLink = {
      source: s,
      target: t,
      relation: e.relation,
      confidence: e.confidence,
      confidence_score: e.confidence_score ?? CONFIDENCE_SCORE_DEFAULTS[e.confidence],
      source_file: e.source_file,
      source_location: null,
      weight: e.weight ?? 1.0,
    };
    G.links.push(link);
    edgeIndex.set(key, link);
  }

  assignCommunities(G);
  return { touched: [...touched], added };
}

/**
 * Cheap community labelling (connected components) so `community` is always
 * populated like graphify's export expects. Upstream uses Leiden; running
 * `graphify` on the mirrored graph.json will replace these with real ones.
 */
export function assignCommunities(G: GraphifyGraph): void {
  const adj = adjacency(G);
  const seen = new Map<string, number>();
  let cid = 0;
  for (const n of G.nodes) {
    if (seen.has(n.id)) continue;
    const stack = [n.id];
    seen.set(n.id, cid);
    while (stack.length) {
      const cur = stack.pop()!;
      for (const nb of adj.get(cur) ?? []) {
        if (!seen.has(nb.id)) {
          seen.set(nb.id, cid);
          stack.push(nb.id);
        }
      }
    }
    cid++;
  }
  for (const n of G.nodes) n.community = seen.get(n.id) ?? null;
}

/* ------------------------------------------------------------------------ */
/* Minimal traversal helpers (adjacency + BFS). The full query engine stays  */
/* in graphify/serve.py; the tutor only needs local neighbourhoods.          */
/* ------------------------------------------------------------------------ */

export interface Neighbor {
  id: string;
  link: GraphifyLink;
  /** true when `link.source` is the node we came from */
  outgoing: boolean;
}

export function adjacency(G: GraphifyGraph): Map<string, Neighbor[]> {
  const adj = new Map<string, Neighbor[]>();
  for (const n of G.nodes) adj.set(n.id, []);
  for (const l of G.links) {
    adj.get(l.source)?.push({ id: l.target, link: l, outgoing: true });
    adj.get(l.target)?.push({ id: l.source, link: l, outgoing: false });
  }
  return adj;
}

export function nodeById(G: GraphifyGraph, id: string): GraphifyNode | undefined {
  return G.nodes.find((n) => n.id === id);
}

/** Find nodes whose label appears in the text (token/substring match). */
export function findMentionedNodes(G: GraphifyGraph, text: string, limit = 5): string[] {
  const t = normLabel(text);
  if (!t) return [];
  const hits: Array<{ id: string; len: number }> = [];
  for (const n of G.nodes) {
    const nl = n.norm_label ?? normLabel(n.label);
    if (nl.length >= 3 && t.includes(nl)) hits.push({ id: n.id, len: nl.length });
  }
  hits.sort((a, b) => b.len - a.len);
  return hits.slice(0, limit).map((h) => h.id);
}

/** BFS neighbourhood up to `depth` hops (graphify/serve.py::_bfs shape). */
export function bfs(
  G: GraphifyGraph,
  start: string[],
  depth: number,
): { nodes: Set<string>; links: GraphifyLink[] } {
  const adj = adjacency(G);
  const visited = new Set<string>(start.filter((s) => adj.has(s)));
  const links: GraphifyLink[] = [];
  let frontier = [...visited];
  for (let d = 0; d < depth && frontier.length; d++) {
    const next: string[] = [];
    for (const id of frontier) {
      for (const nb of adj.get(id) ?? []) {
        links.push(nb.link);
        if (!visited.has(nb.id)) {
          visited.add(nb.id);
          next.push(nb.id);
        }
      }
    }
    frontier = next;
  }
  const uniq = new Map(links.map((l) => [`${l.source}|${l.target}|${l.relation}`, l]));
  return { nodes: visited, links: [...uniq.values()] };
}
