/**
 * Type mirrors of the Graphify on-disk formats. These are NOT a new graph
 * model — they describe exactly what `graphify/export.py::to_json` writes and
 * what `graphify/reflect.py` writes to `.graphify_learning.json`.
 */

export type Confidence = "EXTRACTED" | "INFERRED" | "AMBIGUOUS";
export type FileType =
  | "code"
  | "document"
  | "paper"
  | "image"
  | "rationale"
  | "concept";

/** One entry of graph.json `nodes` (networkx node-link node). */
export interface GraphifyNode {
  id: string;
  label: string;
  file_type: FileType;
  source_file: string;
  source_location?: string | null;
  community?: number | null;
  community_name?: string;
  norm_label?: string;
  rationale?: string | null;
  [k: string]: unknown;
}

/** One entry of graph.json `links` (networkx node-link edge). */
export interface GraphifyLink {
  source: string;
  target: string;
  relation: string;
  confidence: Confidence;
  confidence_score: number;
  source_file: string;
  source_location?: string | null;
  weight?: number;
  [k: string]: unknown;
}

/** The full graph.json document. */
export interface GraphifyGraph {
  directed: boolean;
  multigraph: boolean;
  graph: {
    hyperedges?: unknown[];
    community_labels?: Record<string, string>;
    [k: string]: unknown;
  };
  nodes: GraphifyNode[];
  links: GraphifyLink[];
}

/** The extraction schema every graphify extractor returns (validate.py). */
export interface Extraction {
  nodes: Array<{
    id: string;
    label: string;
    file_type: FileType;
    source_file: string;
    source_location?: string | null;
    rationale?: string | null;
  }>;
  edges: Array<{
    source: string;
    target: string;
    relation: string;
    confidence: Confidence;
    confidence_score?: number;
    source_file: string;
    weight?: number;
  }>;
}

/* ------------------------------------------------------------------------ */
/* Learning sidecar (`.graphify_learning.json`, graphify/reflect.py)         */
/* ------------------------------------------------------------------------ */

/** Upstream vocabulary: preferred > tentative > contested. */
export type LearningStatus = "preferred" | "tentative" | "contested";
export type BranchState = "active" | "dormant";

export type Style = "example" | "analogy" | "formal" | "socratic" | "stepwise";
export type StyleWeights = Record<Style, number>;

export interface Provenance {
  question: string;
  date: string;
  outcome: "useful" | "not_useful";
}

/**
 * Per-node sidecar entry. The first block is byte-compatible with what
 * graphify's `build_learning_overlay` emits (serve.py annotates query output
 * with `learning=<status>`); the second block is the tutor extension.
 */
export interface OverlayEntry {
  // --- upstream fields -------------------------------------------------
  status: LearningStatus;
  score: number;
  uses: number;
  last: string;
  label: string;
  source_file: string;
  code_fingerprint: string;
  provenance: Provenance[];
  verdict?: "even" | "positive" | "negative";
  neg?: number;
  // --- tutor extension -------------------------------------------------
  branch: BranchState;
  mastery: number; // 0..1 EMA of comprehension outcomes
  successes: number;
  confusions: number;
  depth: number; // 1..5 preferred explanation depth for this concept
  style: StyleWeights;
  reactivations: number;
}

export type AffectKey =
  | "confusion"
  | "frustration"
  | "curiosity"
  | "fatigue"
  | "confidence";
export type Affect = Record<AffectKey, number>;

/** Graph-level learner model (tutor extension, ignored by upstream loader). */
export interface LearnerModel {
  depth: number; // 1..5 global preferred depth (EMA)
  style: StyleWeights;
  affect: Affect;
  turns: number;
  avg_msg_len: number;
  follow_up_streak: number;
  last_focus: string[];
  last_style: Style | null;
  last_depth: number | null;
  half_life_days: number;
  background: string; // auto-tutor settings/background.md analogue
}

export interface LearningOverlay {
  version: 1;
  generated_at: string;
  nodes: Record<string, OverlayEntry>;
  learner: LearnerModel;
}
