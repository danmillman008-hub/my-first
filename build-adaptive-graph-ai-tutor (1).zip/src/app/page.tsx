"use client";

import { useCallback, useEffect, useRef, useState } from "react";

interface Msg {
  id: number | string;
  role: "user" | "tutor";
  content: string;
}

interface Summary {
  nodes: number;
  edges: number;
  active: number;
  dormant: number;
  turns: number;
  learner: { depth: number; style: string; affect: Record<string, number> };
  strongest: Array<{ id: string; label: string; mastery: number; branch: string; status: string }>;
  dormant_branches: Array<{ id: string; label: string; last: string }>;
  policy: {
    depth: number;
    style: string;
    bloom: string;
    tone: string;
    socratic_ratio: number;
    next_paths: Array<{ id: string; label: string; mode: string; reason: string }>;
  };
}

export default function Home() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [showPanel, setShowPanel] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);

  const refreshState = useCallback(async () => {
    try {
      const r = await fetch("/api/state", { cache: "no-store" });
      if (r.ok) setSummary(await r.json());
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    fetch("/api/chat", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : { messages: [] }))
      .then((d) => setMessages(d.messages ?? []))
      .catch(() => undefined);
    void refreshState();
  }, [refreshState]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, busy]);

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    setBusy(true);
    setMessages((m) => [...m, { id: `u-${Date.now()}`, role: "user", content: text }]);
    try {
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ message: text }),
      });
      const d = await r.json();
      setMessages((m) => [
        ...m,
        { id: `t-${Date.now()}`, role: "tutor", content: r.ok ? d.reply : `Error: ${d.error ?? r.status}` },
      ]);
      void refreshState();
    } catch {
      setMessages((m) => [...m, { id: `e-${Date.now()}`, role: "tutor", content: "Network error." }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex h-dvh max-w-5xl gap-4 p-4">
      {/* Conversation */}
      <section className="flex min-w-0 flex-1 flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <header className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
          <div>
            <h1 className="text-sm font-semibold tracking-tight">Graph Tutor</h1>
            <p className="text-xs text-slate-500">Ask anything. The tutor adapts as you talk.</p>
          </div>
          <button
            onClick={() => setShowPanel((s) => !s)}
            className="rounded-md px-2 py-1 text-xs text-slate-500 hover:bg-slate-100"
          >
            {showPanel ? "Hide state" : "Show state"}
          </button>
        </header>

        <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
          {messages.length === 0 && (
            <p className="mt-16 text-center text-sm text-slate-400">
              Start with whatever you want to understand — e.g. &ldquo;What is a derivative?&rdquo; or
              &ldquo;Explain attention in transformers.&rdquo;
            </p>
          )}
          {messages.map((m) => (
            <div key={m.id} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div
                className={
                  m.role === "user"
                    ? "max-w-[80%] whitespace-pre-wrap rounded-2xl rounded-br-sm bg-slate-900 px-4 py-2 text-sm text-white"
                    : "max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-bl-sm bg-slate-100 px-4 py-2 text-sm text-slate-800"
                }
              >
                {m.content}
              </div>
            </div>
          ))}
          {busy && (
            <div className="flex justify-start">
              <div className="rounded-2xl rounded-bl-sm bg-slate-100 px-4 py-2 text-sm text-slate-400">thinking…</div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void send();
          }}
          className="flex gap-2 border-t border-slate-100 p-3"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message…"
            className="flex-1 rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-slate-400"
            disabled={busy}
            autoFocus
          />
          <button
            type="submit"
            disabled={busy || !input.trim()}
            className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-40"
          >
            Send
          </button>
        </form>
      </section>

      {/* Optional small state summary */}
      {showPanel && (
        <aside className="hidden w-72 shrink-0 flex-col gap-3 overflow-y-auto rounded-2xl border border-slate-200 bg-white p-4 text-xs shadow-sm md:flex">
          <h2 className="text-sm font-semibold">Graph state</h2>
          {!summary ? (
            <p className="text-slate-400">loading…</p>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-2">
                <Stat label="concepts" value={summary.nodes} />
                <Stat label="edges" value={summary.edges} />
                <Stat label="active" value={summary.active} />
                <Stat label="dormant" value={summary.dormant} />
              </div>

              <Block title="Policy now">
                <Row k="depth" v={`${summary.policy.depth}/5`} />
                <Row k="style" v={summary.policy.style} />
                <Row k="bloom" v={summary.policy.bloom} />
                <Row k="tone" v={summary.policy.tone} />
                <Row k="socratic" v={summary.policy.socratic_ratio.toFixed(2)} />
              </Block>

              <Block title="Affect">
                {Object.entries(summary.learner.affect).map(([k, v]) => (
                  <div key={k} className="flex items-center gap-2">
                    <span className="w-20 text-slate-500">{k}</span>
                    <div className="h-1.5 flex-1 rounded bg-slate-100">
                      <div className="h-1.5 rounded bg-slate-700" style={{ width: `${Math.round(v * 100)}%` }} />
                    </div>
                  </div>
                ))}
              </Block>

              {summary.strongest.length > 0 && (
                <Block title="Active branches">
                  {summary.strongest.map((n) => (
                    <div key={n.id} className="flex justify-between gap-2">
                      <span className="truncate">{n.label}</span>
                      <span className="text-slate-400">m {n.mastery.toFixed(2)}</span>
                    </div>
                  ))}
                </Block>
              )}

              {summary.dormant_branches.length > 0 && (
                <Block title="Dormant">
                  {summary.dormant_branches.map((n) => (
                    <div key={n.id} className="truncate text-slate-400">
                      {n.label}
                    </div>
                  ))}
                </Block>
              )}

              {summary.policy.next_paths.length > 0 && (
                <Block title="Next paths">
                  {summary.policy.next_paths.map((p) => (
                    <div key={p.id} className="truncate">
                      <span className="text-slate-400">{p.mode.replace("_", " ")}</span> · {p.label}
                    </div>
                  ))}
                </Block>
              )}
              <p className="mt-auto text-[10px] text-slate-400">
                MCP: <code>/api/mcp</code> · graph mirrored to <code>graphify-out/</code>
              </p>
            </>
          )}
        </aside>
      )}
    </main>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg bg-slate-50 px-2 py-1.5">
      <div className="text-base font-semibold">{value}</div>
      <div className="text-slate-500">{label}</div>
    </div>
  );
}

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">{title}</div>
      {children}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-slate-500">{k}</span>
      <span className="font-medium">{v}</span>
    </div>
  );
}
