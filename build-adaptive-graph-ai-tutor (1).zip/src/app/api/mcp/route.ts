import { WebStandardStreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js";
import { createTutorMcpServer } from "@/mcp/server";

/**
 * MCP Streamable HTTP transport (spec 2025-03-26+): ONE endpoint handling
 * POST (client→server JSON-RPC), GET (server→client SSE stream) and DELETE
 * (session teardown). Implemented with the official SDK transport – not a
 * hand-rolled JSON endpoint. Runs stateless: every request gets a fresh
 * server+transport pair, which is what a serverless Next.js route needs.
 */
export const dynamic = "force-dynamic";

async function handle(req: Request): Promise<Response> {
  const server = createTutorMcpServer();
  const transport = new WebStandardStreamableHTTPServerTransport({
    sessionIdGenerator: undefined, // stateless
    enableJsonResponse: true, // plain JSON responses for POST (SSE still served for GET)
  });
  await server.connect(transport);
  try {
    return await transport.handleRequest(req);
  } finally {
    // Close lazily so an in-flight SSE stream is not cut before it flushes.
    setTimeout(() => {
      void server.close();
    }, 0);
  }
}

export const GET = handle;
export const POST = handle;
export const DELETE = handle;
