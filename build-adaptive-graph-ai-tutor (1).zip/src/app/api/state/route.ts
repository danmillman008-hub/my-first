import { NextResponse } from "next/server";
import { loadState } from "@/graphify/store";
import { summarize } from "@/tutor/summary";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json(summarize(await loadState()));
}
