import { NextResponse } from "next/server";
import { runTurn } from "@/tutor/engine";
import { fullHistory, DEFAULT_SLUG } from "@/graphify/store";

export const dynamic = "force-dynamic";

export async function GET() {
  const history = await fullHistory(DEFAULT_SLUG);
  return NextResponse.json({ messages: history.map((h) => ({ id: h.id, role: h.role, content: h.content })) });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as { message?: string } | null;
  const message = body?.message?.trim();
  if (!message) return NextResponse.json({ error: "message is required" }, { status: 400 });
  if (message.length > 4000) return NextResponse.json({ error: "message too long" }, { status: 413 });
  try {
    const result = await runTurn(message, DEFAULT_SLUG);
    return NextResponse.json(result);
  } catch (err) {
    console.error("[chat]", err);
    return NextResponse.json({ error: "turn failed" }, { status: 500 });
  }
}
