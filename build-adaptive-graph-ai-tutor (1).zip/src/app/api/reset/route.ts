import { NextResponse } from "next/server";
import { resetState, DEFAULT_SLUG } from "@/graphify/store";

export const dynamic = "force-dynamic";

/** Debug-only: wipe the learner graph + history. */
export async function POST() {
  await resetState(DEFAULT_SLUG);
  return NextResponse.json({ ok: true });
}
