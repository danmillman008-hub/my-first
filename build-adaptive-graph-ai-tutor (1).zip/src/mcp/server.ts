import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { bfs, nodeById } from "@/graphify/graph";
import { fullHistory, loadState, saveState, DEFAULT_SLUG } from "@/graphify/store";
import { runTurn } from "@/tutor/engine";
import { applyDecay, reactivate } from "@/tutor/overlay";
import { derivePolicy, recommendPaths } from "@/tutor/policy";
import { summarize } from "@/tutor/summary";

/**
 * Thin MCP adapter. No logic lives here – every tool delegates to the
 * graphify store / tutor modules. Read access is exposed as resources,
 * mutations as a few narrowly-scoped tools.
 *
 * Read tools that need the full graphify query engine (`query_graph`,
 * `shortest_path`, `god_nodes`, …) are intentionally NOT re-implemented:
 * point `graphify-mcp` at ./graphify-out/graph.json for those.
 */
export function createTutorMcpServer(): McpServer {
  const server = new McpServer(
    { name: "graph-tutor", version: "0.1.0" },
    { instructions: "Adaptive tutor state built on a Graphify knowledge graph. Use resources for read access, tools for safe mutations." },
  );

  const text = (data: unknown) => ({
    content: [{ type: "text" as const, text: typeof data === "string" ? data : JSON.stringify(data, null, 2) }],
  });

  /* ---------------------------- resources ------------------------------ */
  server.registerResource(
    "graph",
    "graphify://graph",
    { title: "Knowledge graph (graph.json)", description: "Verbatim Graphify graph.json document", mimeType: "application/json" },
    async (uri) => ({ contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify((await loadState()).graph) }] }),
  );
  server.registerResource(
    "learning-overlay",
    "graphify://learning",
    { title: "Learning sidecar (.graphify_learning.json)", description: "Per-concept mastery, branch state, preferences and learner model", mimeType: "application/json" },
    async (uri) => ({ contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify((await loadState()).overlay) }] }),
  );
  server.registerResource(
    "tutor-state",
    "tutor://state",
    { title: "Tutor state summary", description: "Learner model, affect, active/dormant branches and current response policy", mimeType: "application/json" },
    async (uri) => ({ contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify(summarize(await loadState()), null, 2) }] }),
  );
  server.registerResource(
    "history",
    "tutor://history",
    { title: "Interaction history", description: "Chronological chat turns with signals and applied policy", mimeType: "application/json" },
    async (uri) => ({ contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify(await fullHistory(DEFAULT_SLUG)) }] }),
  );

  /* ------------------------------- tools ------------------------------- */
  server.registerTool(
    "get_state",
    { title: "Get tutor state", description: "Learner model, affect, strongest/dormant branches, current policy.", inputSchema: {} },
    async () => text(summarize(await loadState())),
  );

  server.registerTool(
    "get_node",
    {
      title: "Get concept",
      description: "A concept node with its learning-overlay entry and 1-hop neighbourhood.",
      inputSchema: { id: z.string().describe("node id (snake_case)") },
    },
    async ({ id }) => {
      const { graph, overlay } = await loadState();
      const node = nodeById(graph, id);
      if (!node) return { isError: true, ...text(`unknown node: ${id}`) };
      const nb = bfs(graph, [id], 1);
      return text({
        node,
        learning: overlay.nodes[id] ?? null,
        neighbors: [...nb.nodes].filter((n) => n !== id).map((n) => nodeById(graph, n)),
        edges: nb.links,
      });
    },
  );

  server.registerTool(
    "recommend_next",
    {
      title: "Recommend next explanation path",
      description: "Graph-derived next topics / modes for the given focus (defaults to the learner's last focus).",
      inputSchema: { focus: z.array(z.string()).optional() },
    },
    async ({ focus }) => {
      const { graph, overlay } = await loadState();
      const f = focus?.length ? focus : overlay.learner.last_focus;
      const policy = derivePolicy(graph, overlay, f);
      return text({ focus: f, policy, paths: recommendPaths(graph, overlay, f, policy.focus_mastery).next_paths });
    },
  );

  server.registerTool(
    "record_interaction",
    {
      title: "Record a learner message",
      description: "Run one full tutor turn (signals → policy → reply → graph update). Returns the reply and applied policy.",
      inputSchema: { message: z.string().min(1) },
    },
    async ({ message }) => {
      const r = await runTurn(message);
      return text({ reply: r.reply, policy: r.policy, signals: r.signals, touched: r.touched, added: r.added, reactivated: r.reactivated });
    },
  );

  server.registerTool(
    "reactivate_branch",
    { title: "Reactivate dormant branch", description: "Bring a dormant concept branch back to active.", inputSchema: { id: z.string() } },
    async ({ id }) => {
      const state = await loadState();
      const ok = reactivate(state.overlay, id);
      if (!ok) return { isError: true, ...text(`unknown node: ${id}`) };
      await saveState(state);
      return text({ id, branch: state.overlay.nodes[id].branch, score: state.overlay.nodes[id].score });
    },
  );

  server.registerTool(
    "set_learner_background",
    {
      title: "Set learner background",
      description: "auto-tutor style background note (grade, subjects, goals) used to adapt vocabulary and depth.",
      inputSchema: { background: z.string().max(2000) },
    },
    async ({ background }) => {
      const state = await loadState();
      state.overlay.learner.background = background;
      await saveState(state);
      return text({ ok: true });
    },
  );

  server.registerTool(
    "run_decay",
    { title: "Run decay pass", description: "Apply time decay now; returns branches that became dormant.", inputSchema: {} },
    async () => {
      const state = await loadState();
      const dormant = applyDecay(state.overlay);
      await saveState(state);
      return text({ newly_dormant: dormant });
    },
  );

  /* ------------------------------ prompts ------------------------------ */
  server.registerPrompt(
    "explain_with_policy",
    {
      title: "Explain a concept under the current policy",
      description: "Prompt scaffold that applies the learner's current depth/style/affect policy to a concept.",
      argsSchema: { concept: z.string() },
    },
    async ({ concept }) => {
      const { graph, overlay } = await loadState();
      const ids = graph.nodes.filter((n) => n.label.toLowerCase() === concept.toLowerCase()).map((n) => n.id);
      const p = derivePolicy(graph, overlay, ids);
      return {
        messages: [
          {
            role: "user" as const,
            content: {
              type: "text" as const,
              text: `Explain "${concept}" at depth ${p.depth}/5 in a ${p.style} style, Bloom level ${p.bloom}, tone ${p.tone}, ${p.length} length. Socratic ratio ${p.socratic_ratio}.`,
            },
          },
        ],
      };
    },
  );

  return server;
}
