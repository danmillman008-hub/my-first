import {
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/**
 * Persistence for the Graphify substrate.
 *
 * `graph`   – the verbatim Graphify `graph.json` document (networkx node-link
 *             format). This IS the knowledge graph; nothing is duplicated into
 *             relational node/edge tables.
 * `overlay` – the verbatim Graphify learning sidecar (`.graphify_learning.json`,
 *             see graphify/reflect.py) extended with tutor personalization
 *             fields. Kept separate from graph.json exactly like upstream.
 *
 * Both documents are also mirrored to `graphify-out/` on disk so the upstream
 * Python CLI / `graphify-mcp` can read them unchanged.
 */
export const graphs = pgTable("graphs", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  graph: jsonb("graph").notNull(),
  overlay: jsonb("overlay").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

/**
 * Interaction history (the auto-tutor `learning-history/` idea, one row per
 * chat turn instead of one markdown file per lesson).
 */
export const interactions = pgTable(
  "interactions",
  {
    id: serial("id").primaryKey(),
    graphSlug: text("graph_slug").notNull(),
    role: text("role").notNull(), // "user" | "tutor"
    content: text("content").notNull(),
    signals: jsonb("signals"),
    policy: jsonb("policy"),
    concepts: jsonb("concepts").$type<string[]>(),
    turn: integer("turn").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("interactions_graph_idx").on(t.graphSlug, t.createdAt)],
);
