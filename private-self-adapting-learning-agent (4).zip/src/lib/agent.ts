import { db } from "@/db";
import { and, desc, eq, isNull, sql } from "drizzle-orm";
import { agentTraces, learners, messages, sessions } from "@/db/schema";
import type { LLMProvider, TurnOutput } from "@/lib/types";
import { createProvider } from "@/lib/llm/openai";
import { buildTurnContext, type MemoryMode } from "@/lib/memory/retrieval";
import { consolidateTurn, sweepDormancy, type ConsolidationReport } from "@/lib/memory/consolidate";
import { ensureDomainGrounding, researchTopic } from "@/lib/research";

const uid = (p: string) => `${p}_${crypto.randomUUID()}`;

export interface TurnResult {
  reply: string;
  sessionId: string;
  isNewSession: boolean;
  assistantMessageId: string;
  meta: Record<string, unknown>;
  output: TurnOutput;
  report: ConsolidationReport;
}

export async function ensureLearner(learnerId: string, name?: string) {
  const [l] = await db.select().from(learners).where(eq(learners.id, learnerId)).limit(1);
  if (!l) await db.insert(learners).values({ id: learnerId, name: name ?? "Learner" });
}

/**
 * One conversational turn. Everything the learner never has to think about
 * happens here: session continuity, memory retrieval, strategy choice,
 * research, model call, persistence, consolidation, tracing.
 */
export async function runTurn(opts: {
  learnerId: string;
  userMessage: string;
  now?: Date;
  provider?: LLMProvider;
  mode?: MemoryMode;
  rnd?: () => number;
  enableResearch?: boolean;
}): Promise<TurnResult> {
  const now = opts.now ?? new Date();
  const provider = opts.provider ?? createProvider();
  const mode = opts.mode ?? "full";
  await ensureLearner(opts.learnerId);

  const ctx = await buildTurnContext({ learnerId: opts.learnerId, userMessage: opts.userMessage, now, mode, rnd: opts.rnd });

  if (ctx.isNewSession) {
    // Close out the previous session (summary) and let stale beliefs go dormant.
    await summarizeUnsummarizedSessions(opts.learnerId, provider, ctx.sessionId);
    if (mode === "full" || mode === "no_adaptation") await sweepDormancy(opts.learnerId, now);
    await db.insert(sessions).values({ id: ctx.sessionId, learnerId: opts.learnerId, startedAt: now, lastActiveAt: now, turnCount: 0 });
  }

  if (opts.enableResearch !== false && ctx.currentDomainGuess) {
    const did = await ensureDomainGrounding(ctx.currentDomainGuess);
    if (did) {
      const fresh = await buildTurnContext({ learnerId: opts.learnerId, userMessage: opts.userMessage, now, mode, rnd: opts.rnd });
      ctx.researchNotes = fresh.researchNotes;
      await db.insert(agentTraces).values({ id: uid("t"), learnerId: opts.learnerId, sessionId: ctx.sessionId, kind: "research", payload: { domain: ctx.currentDomainGuess, reason: "unfamiliar domain, grounded before answering" }, createdAt: now });
    }
  }

  const lastAssistantRow = await db
    .select({ id: messages.id, meta: messages.meta })
    .from(messages)
    .where(and(eq(messages.learnerId, opts.learnerId), eq(messages.role, "assistant")))
    .orderBy(desc(messages.createdAt))
    .limit(1);
  const lastAssistant = lastAssistantRow[0] ?? null;

  const output = await provider.turn({ userMessage: opts.userMessage, context: ctx });

  const userMessageId = uid("m");
  const assistantMessageId = uid("m");
  const meta: Record<string, unknown> = {
    strategy: output.strategy,
    depth: output.depth,
    domain: output.domain,
    concepts: output.concepts,
    recommendedStrategy: ctx.recommendedStrategy,
    strategyReason: ctx.strategyReason,
    strategyOverrideReason: output.strategyOverrideReason,
    probe: output.probe,
    provider: provider.name,
    mode,
    beliefsInContext: ctx.beliefs.filter((b) => b.status === "active" || b.status === "contested").map((b) => b.id),
  };
  await db.insert(messages).values([
    { id: userMessageId, learnerId: opts.learnerId, sessionId: ctx.sessionId, role: "user", content: opts.userMessage, meta: {}, createdAt: now },
    { id: assistantMessageId, learnerId: opts.learnerId, sessionId: ctx.sessionId, role: "assistant", content: output.reply, meta, createdAt: new Date(now.getTime() + 1) },
  ]);
  await db.update(sessions).set({ lastActiveAt: now, turnCount: sql`${sessions.turnCount} + 1` }).where(eq(sessions.id, ctx.sessionId));

  const report = await consolidateTurn({ learnerId: opts.learnerId, sessionId: ctx.sessionId, userMessageId, assistantMessageId, lastAssistantMessage: lastAssistant, output, now, mode });

  if (output.probe) await db.insert(agentTraces).values({ id: uid("t"), learnerId: opts.learnerId, sessionId: ctx.sessionId, messageId: assistantMessageId, kind: "probe", payload: { ...output.probe }, createdAt: now });
  if (output.researchRequest && opts.enableResearch !== false) {
    const note = await researchTopic(output.researchRequest.topic, output.domain);
    await db.insert(agentTraces).values({ id: uid("t"), learnerId: opts.learnerId, sessionId: ctx.sessionId, messageId: assistantMessageId, kind: "research", payload: { ...output.researchRequest, found: !!note }, createdAt: now });
  }
  await db.insert(agentTraces).values({
    id: uid("t"),
    learnerId: opts.learnerId,
    sessionId: ctx.sessionId,
    messageId: assistantMessageId,
    kind: "turn",
    payload: { strategy: output.strategy, depth: output.depth, domain: output.domain, recommended: ctx.recommendedStrategy, reason: ctx.strategyReason, override: output.strategyOverrideReason, prevTurnOutcome: output.prevTurnOutcome, report: { ...report } },
    createdAt: now,
  });

  return { reply: output.reply, sessionId: ctx.sessionId, isNewSession: ctx.isNewSession, assistantMessageId, meta, output, report };
}

async function summarizeUnsummarizedSessions(learnerId: string, provider: LLMProvider, excludeSessionId: string) {
  const rows = await db.select().from(sessions).where(and(eq(sessions.learnerId, learnerId), isNull(sessions.summary))).orderBy(desc(sessions.lastActiveAt)).limit(3);
  for (const s of rows) {
    if (s.id === excludeSessionId) continue;
    const msgs = await db.select({ role: messages.role, content: messages.content }).from(messages).where(eq(messages.sessionId, s.id)).orderBy(messages.createdAt).limit(60);
    if (!msgs.length) continue;
    let summary: string;
    try {
      summary = await provider.summarizeSession(msgs);
    } catch {
      summary = `Discussed: ${msgs.filter((m) => m.role === "user").slice(0, 3).map((m) => m.content.slice(0, 60)).join(" · ")}`;
    }
    await db.update(sessions).set({ summary }).where(eq(sessions.id, s.id));
  }
}

/** Learner-initiated correction from the memory panel ("that's not true about me"). */
export async function challengeBelief(opts: { learnerId: string; beliefId: string; note: string; replacement?: string | null; now?: Date }) {
  const now = opts.now ?? new Date();
  const [last] = await db.select().from(sessions).where(eq(sessions.learnerId, opts.learnerId)).orderBy(desc(sessions.lastActiveAt)).limit(1);
  let sessionId = last?.id;
  if (!sessionId) {
    sessionId = uid("s");
    await db.insert(sessions).values({ id: sessionId, learnerId: opts.learnerId, startedAt: now, lastActiveAt: now, turnCount: 0 });
  }
  const userMessageId = uid("m");
  const report = await consolidateTurn({
    learnerId: opts.learnerId,
    sessionId,
    userMessageId,
    assistantMessageId: "",
    lastAssistantMessage: null,
    now,
    mode: "full",
    output: {
      reply: "",
      strategy: "direct_explanation",
      depth: "standard",
      domain: null,
      concepts: [],
      observations: [{ kind: "correction", content: `Corrected the tutor's memory: ${opts.note}`, concepts: [], domain: null, signals: {}, salience: 1 }],
      prevTurnOutcome: null,
      beliefFeedback: [],
      learnerCorrection: { beliefId: opts.beliefId, statement: opts.note, replacement: opts.replacement ?? null },
      probe: null,
      researchRequest: null,
      strategyOverrideReason: null,
    },
  });
  return report;
}
