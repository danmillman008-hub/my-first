import { db } from "@/db";
import { and, desc, eq, gte, inArray, isNull, ne, sql } from "drizzle-orm";
import { beliefs, conceptStates, messages, observations, researchNotes, sessions, strategyOutcomes, agentTraces } from "@/db/schema";
import type { BeliefView, ConceptStateView, Strategy, TurnContext, Depth } from "@/lib/types";
import { selectStrategy, strategyStats } from "./strategy";
import { guessDomain, detectOutcome, extractConcepts } from "@/lib/llm/heuristics";

export const SESSION_GAP_MINUTES = 45;

export type MemoryMode = "full" | "no_long_term" | "no_adaptation" | "short_term_only";

const HALF_LIFE_DAYS: Record<string, number> = {
  goal: 120,
  preference: 90,
  tendency: 90,
  knowledge: 60,
  context: 365,
  strategy_fit: 60,
};

const STATUS_WEIGHT: Record<string, number> = {
  active: 1,
  contested: 0.6,
  candidate: 0.25,
  dormant: 0.3,
  retired: 0,
};

/** Influence = how much this belief should shape the current turn. */
export function beliefInfluence(b: BeliefView, now: Date, domain: string | null): number {
  const days = Math.max(0, (now.getTime() - b.lastConfirmedAt.getTime()) / 86400000);
  const hl = HALF_LIFE_DAYS[b.kind] ?? 90;
  const recency = Math.max(0.4, Math.exp((-Math.LN2 * days) / hl));
  const scope = !b.domain ? 0.85 : b.domain === domain ? 1 : 0.35;
  return b.confidence * (STATUS_WEIGHT[b.status] ?? 0) * (0.4 + 0.6 * recency) * scope;
}

export function toBeliefView(r: typeof beliefs.$inferSelect): BeliefView {
  return {
    id: r.id,
    kind: r.kind,
    key: r.key,
    statement: r.statement,
    domain: r.domain,
    concepts: r.concepts,
    source: r.source,
    status: r.status,
    confidence: r.confidence,
    supportCount: r.supportCount,
    contradictionCount: r.contradictionCount,
    distinctSessions: r.distinctSessions,
    lastConfirmedAt: r.lastConfirmedAt,
    validFrom: r.validFrom,
    invalidAt: r.invalidAt,
    invalidReason: r.invalidReason,
  };
}

export async function loadBeliefsForContext(learnerId: string, now: Date, domain: string | null, mode: MemoryMode): Promise<BeliefView[]> {
  if (mode === "no_long_term" || mode === "short_term_only") return [];
  const rows = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, learnerId), ne(beliefs.status, "retired")));
  const views = rows.map((r) => ({ ...toBeliefView(r), influence: beliefInfluence(toBeliefView(r), now, domain) }));
  return views
    .filter((b) => (b.influence ?? 0) >= 0.06)
    .sort((a, b) => (b.influence ?? 0) - (a.influence ?? 0))
    .slice(0, 24);
}

export async function buildTurnContext(opts: {
  learnerId: string;
  userMessage: string;
  now: Date;
  mode?: MemoryMode;
  rnd?: () => number;
}): Promise<TurnContext & { sessionId: string; isNewSession: boolean }> {
  const { learnerId, userMessage, now } = opts;
  const mode = opts.mode ?? "full";

  // --- Session: continuous relationship, grouped only by time gaps ---
  const [last] = await db.select().from(sessions).where(eq(sessions.learnerId, learnerId)).orderBy(desc(sessions.lastActiveAt)).limit(1);
  const gapMinutes = last ? (now.getTime() - last.lastActiveAt.getTime()) / 60000 : null;
  const isNewSession = !last || (gapMinutes ?? Infinity) > SESSION_GAP_MINUTES;
  const sessionId = isNewSession ? `s_${crypto.randomUUID()}` : last.id;

  const recentRows = await db
    .select()
    .from(messages)
    .where(and(eq(messages.learnerId, learnerId), isNewSession ? sql`true` : eq(messages.sessionId, sessionId)))
    .orderBy(desc(messages.createdAt))
    .limit(isNewSession ? 6 : 24);
  // recentRows is newest-first here; resolve the latest assistant turn BEFORE reordering.
  const lastAssistant = recentRows.find((m) => m.role === "assistant");
  const lastAssistantMeta = lastAssistant?.meta ?? null;
  const recentMessages = [...recentRows].reverse().map((m) => ({ role: m.role, content: m.content, meta: m.meta, createdAt: m.createdAt }));

  const prevDomain = (lastAssistantMeta?.domain as string | undefined) ?? null;
  const currentDomainGuess = guessDomain(userMessage, prevDomain);

  const summariesRows = mode === "short_term_only"
    ? []
    : await db.select().from(sessions).where(and(eq(sessions.learnerId, learnerId), ne(sessions.id, sessionId))).orderBy(desc(sessions.lastActiveAt)).limit(5);
  const previousSessionSummaries = summariesRows.filter((s) => s.summary).map((s) => ({ summary: s.summary!, endedAt: s.lastActiveAt }));

  const beliefViews = await loadBeliefsForContext(learnerId, now, currentDomainGuess, mode);

  // --- Concept states relevant to this domain / recently touched ---
  const csRows = mode === "short_term_only"
    ? []
    : await db.select().from(conceptStates).where(eq(conceptStates.learnerId, learnerId)).orderBy(desc(conceptStates.lastSeenAt)).limit(60);
  const conceptViews: ConceptStateView[] = csRows
    .filter((c) => !currentDomainGuess || c.domain === currentDomainGuess || (now.getTime() - c.lastSeenAt.getTime()) < 3 * 86400000)
    .slice(0, 12)
    .map((c) => ({ concept: c.concept, domain: c.domain, pKnown: c.pKnown, attempts: c.attempts, successes: c.successes, mistakes: c.mistakes, selfReport: c.selfReport, exposures: c.exposures, lastSeenAt: c.lastSeenAt }));

  // --- Recent observations: this session's plus salient earlier ones in scope ---
  const obsRows = await db
    .select()
    .from(observations)
    .where(and(eq(observations.learnerId, learnerId), gte(observations.createdAt, new Date(now.getTime() - 30 * 86400000))))
    .orderBy(desc(observations.createdAt))
    .limit(80);
  const recentObservations = obsRows
    .map((o) => ({ o, score: o.salience * (o.sessionId === sessionId ? 1.5 : 1) * (!o.domain || o.domain === currentDomainGuess ? 1 : 0.5) * Math.exp(-(now.getTime() - o.createdAt.getTime()) / (14 * 86400000)) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 12)
    .map(({ o }) => ({ kind: o.kind, content: o.content, domain: o.domain, createdAt: o.createdAt }));

  // --- Strategy evidence & recommendation ---
  const outcomeRows = mode === "no_adaptation" || mode === "short_term_only"
    ? []
    : await db.select().from(strategyOutcomes).where(eq(strategyOutcomes.learnerId, learnerId)).orderBy(desc(strategyOutcomes.createdAt)).limit(400);
  const outcomes = outcomeRows.map((o) => ({ strategy: o.strategy, domain: o.domain, outcome: o.outcome, createdAt: o.createdAt }));
  // The learner's reaction to the LAST reply is inside the message we are about to
  // answer. Parse it now (cheaply) so the strategy choice can respond immediately
  // instead of one turn late.
  const provisional = detectOutcome(userMessage, !!lastAssistant);
  const lastStrategy = (lastAssistantMeta?.strategy as Strategy | undefined) ?? null;
  const lastOutcomeScore = provisional && !["unknown", "neutral"].includes(provisional.label) ? provisional.score : null;
  if (lastStrategy && lastOutcomeScore != null && mode !== "no_adaptation" && mode !== "short_term_only") {
    outcomes.unshift({ strategy: lastStrategy, domain: (lastAssistantMeta?.domain as string | null) ?? currentDomainGuess, outcome: lastOutcomeScore, createdAt: now });
  }
  const stats = strategyStats(outcomes, now).filter((s) => s.domain === currentDomainGuess || s.domain === null);
  const sel = selectStrategy({
    outcomes,
    domain: currentDomainGuess,
    beliefs: beliefViews,
    currentStrategy: lastStrategy,
    lastOutcomeScore,
    now,
    rnd: opts.rnd,
    mode: mode === "no_adaptation" ? "no_adaptation" : "full",
  });

  // --- Probe policy: rare, only when uncertainty matters ---
  const sessionTurns = last && !isNewSession ? last.turnCount : 0;
  const [lastProbe] = await db
    .select({ createdAt: agentTraces.createdAt })
    .from(agentTraces)
    .where(and(eq(agentTraces.learnerId, learnerId), eq(agentTraces.kind, "probe")))
    .orderBy(desc(agentTraces.createdAt))
    .limit(1);
  const turnsSinceProbe = lastProbe ? await countTurnsSince(learnerId, lastProbe.createdAt) : Infinity;
  let probeSuggestion: TurnContext["probeSuggestion"] = null;
  const mentioned = new Set(extractConcepts(userMessage, currentDomainGuess));
  for (const c of conceptViews) {
    if (c.domain !== currentDomainGuess || !mentioned.has(c.concept)) continue;
    const claimWithoutEvidence = c.selfReport != null && Math.abs(c.selfReport) >= 0.5 && c.attempts === 0 && c.exposures >= 2;
    const uncertain = c.attempts >= 2 && c.pKnown > 0.35 && c.pKnown < 0.65;
    if (claimWithoutEvidence) { probeSuggestion = { concept: c.concept, reason: "they said they know it but I have never seen them use it" }; break; }
    if (uncertain && !probeSuggestion) probeSuggestion = { concept: c.concept, reason: "mixed results so far; unclear whether it has clicked" };
  }
  const probeAllowed = mode !== "short_term_only" && sessionTurns >= 2 && turnsSinceProbe >= 8 && probeSuggestion !== null;

  // --- Research notes for the domain ---
  const notes = currentDomainGuess
    ? await db.select().from(researchNotes).where(eq(researchNotes.domain, currentDomainGuess)).orderBy(desc(researchNotes.createdAt)).limit(2)
    : [];

  return {
    learnerId,
    sessionId,
    now,
    isNewSession,
    gapMinutes,
    recentMessages,
    previousSessionSummaries,
    beliefs: beliefViews,
    conceptStates: conceptViews,
    recentObservations,
    strategyStats: stats,
    recommendedStrategy: sel.strategy,
    recommendedDepth: sel.depth as Depth,
    strategyReason: sel.reason,
    probeAllowed,
    probeSuggestion,
    lastAssistantMeta,
    researchNotes: notes.map((n) => ({ topic: n.topic, content: n.content, sources: n.sources })),
    currentDomainGuess,
  };
}

async function countTurnsSince(learnerId: string, since: Date): Promise<number> {
  const [r] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(messages)
    .where(and(eq(messages.learnerId, learnerId), eq(messages.role, "user"), gte(messages.createdAt, since)));
  return r?.n ?? 0;
}

export async function loadLearnerMemory(learnerId: string, now = new Date()) {
  const [allBeliefs, states, recentObs, outcomes, sess] = await Promise.all([
    db.select().from(beliefs).where(eq(beliefs.learnerId, learnerId)).orderBy(desc(beliefs.updatedAt)),
    db.select().from(conceptStates).where(eq(conceptStates.learnerId, learnerId)).orderBy(desc(conceptStates.lastSeenAt)).limit(100),
    db.select().from(observations).where(eq(observations.learnerId, learnerId)).orderBy(desc(observations.createdAt)).limit(60),
    db.select().from(strategyOutcomes).where(eq(strategyOutcomes.learnerId, learnerId)).orderBy(desc(strategyOutcomes.createdAt)).limit(400),
    db.select().from(sessions).where(eq(sessions.learnerId, learnerId)).orderBy(desc(sessions.lastActiveAt)).limit(20),
  ]);
  const beliefViews = allBeliefs.map((r) => ({ ...toBeliefView(r), influence: beliefInfluence(toBeliefView(r), now, null), createdAt: r.createdAt, supersededBy: r.supersededBy }));
  return {
    beliefs: beliefViews,
    conceptStates: states,
    observations: recentObs,
    strategyStats: strategyStats(outcomes.map((o) => ({ strategy: o.strategy, domain: o.domain, outcome: o.outcome, createdAt: o.createdAt })), now),
    sessions: sess,
  };
}

export async function loadBeliefEvidence(beliefId: string) {
  const { beliefEvidence } = await import("@/db/schema");
  const ev = await db.select().from(beliefEvidence).where(eq(beliefEvidence.beliefId, beliefId)).orderBy(desc(beliefEvidence.createdAt)).limit(40);
  if (!ev.length) return [];
  const obs = await db.select().from(observations).where(inArray(observations.id, ev.map((e) => e.observationId)));
  const byId = new Map(obs.map((o) => [o.id, o]));
  return ev.map((e) => ({ polarity: e.polarity, weight: e.weight, createdAt: e.createdAt, observation: byId.get(e.observationId) ?? null }));
}

export { isNull };
