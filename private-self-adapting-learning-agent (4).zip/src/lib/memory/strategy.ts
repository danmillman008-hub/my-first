import { STRATEGIES, type Strategy, type Depth, type BeliefView, type StrategyStat } from "@/lib/types";

// ---------------------------------------------------------------------------
// Strategy selection = contextual Thompson sampling over Beta posteriors.
//   prior(domain, s)  <- global posterior for s (shrunk) + preference beliefs
//   posterior(domain, s) <- prior + outcomes observed in that domain
// Hysteresis: keep the current strategy unless another one is clearly better,
// which prevents the "repetitive strategy switching" failure mode.
// ---------------------------------------------------------------------------

export interface OutcomeRow {
  strategy: string;
  domain: string | null;
  outcome: number; // -1..1
  createdAt: Date;
}

// Deterministic PRNG so simulations are reproducible.
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function sampleBeta(a: number, b: number, rnd: () => number): number {
  // Approximate Beta sample via ratio of Gamma samples (Marsaglia-Tsang).
  const g = (k: number): number => {
    if (k < 1) return g(k + 1) * Math.pow(rnd(), 1 / k);
    const d = k - 1 / 3;
    const c = 1 / Math.sqrt(9 * d);
    for (;;) {
      let x: number, v: number;
      do {
        // Box-Muller
        const u1 = Math.max(rnd(), 1e-12);
        const u2 = rnd();
        x = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
        v = 1 + c * x;
      } while (v <= 0);
      v = v * v * v;
      const u = rnd();
      if (u < 1 - 0.0331 * x * x * x * x) return d * v;
      if (Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
    }
  };
  const x = g(a);
  const y = g(b);
  return x / (x + y);
}

function recencyWeight(createdAt: Date, now: Date): number {
  // Outcomes from months ago count less than last week's, but never vanish
  // (floor 0.35) — the learner may have changed, but old evidence is still evidence.
  const days = Math.max(0, (now.getTime() - createdAt.getTime()) / 86400000);
  return 0.35 + 0.65 * Math.exp(-days / 45);
}

// Non-stationary learners: besides wall-clock decay, discount each outcome by how
// many MORE RECENT outcomes exist in the same scope (discounted Thompson sampling).
// Effective memory ≈ 1/(1-GAMMA) ≈ 12 outcomes, so a real change in what works is
// picked up within a handful of turns instead of being buried under old successes.
const GAMMA = 0.92;
const MAX_PSEUDO = 30; // cap on a+b so the posterior never becomes unexplorably certain

function orderWeights(outcomes: OutcomeRow[]): Map<OutcomeRow, { local: number; global: number }> {
  const sorted = [...outcomes].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  const seenByDomain = new Map<string, number>();
  let seenGlobal = 0;
  const out = new Map<OutcomeRow, { local: number; global: number }>();
  for (const o of sorted) {
    const dk = o.domain ?? "*";
    const kLocal = seenByDomain.get(dk) ?? 0;
    out.set(o, { local: Math.pow(GAMMA, kLocal), global: Math.pow(GAMMA, seenGlobal) });
    seenByDomain.set(dk, kLocal + 1);
    seenGlobal++;
  }
  return out;
}

export function strategyStats(outcomes: OutcomeRow[], now: Date): StrategyStat[] {
  const acc = new Map<string, { n: number; sum: number; w: number; strategy: Strategy; domain: string | null }>();
  const ow = orderWeights(outcomes);
  for (const o of outcomes) {
    if (!(STRATEGIES as readonly string[]).includes(o.strategy)) continue;
    for (const d of [o.domain, null]) {
      const k = `${o.strategy}|${d ?? "*"}`;
      const w = recencyWeight(o.createdAt, now) * (d ? ow.get(o)!.local : ow.get(o)!.global);
      const cur = acc.get(k) ?? { n: 0, sum: 0, w: 0, strategy: o.strategy as Strategy, domain: d };
      cur.n += 1;
      cur.sum += o.outcome * w;
      cur.w += w;
      acc.set(k, cur);
    }
  }
  return [...acc.values()].map((v) => ({ strategy: v.strategy, domain: v.domain, n: v.n, mean: v.w ? v.sum / v.w : 0 })).sort((a, b) => b.n - a.n);
}

export interface SelectionInput {
  outcomes: OutcomeRow[];
  domain: string | null;
  beliefs: BeliefView[];
  currentStrategy: Strategy | null;
  lastOutcomeScore: number | null;
  now: Date;
  rnd?: () => number;
  /** 'full' = normal; 'no_adaptation' = ablation that ignores outcome history */
  mode?: "full" | "no_adaptation";
}

export interface SelectionResult {
  strategy: Strategy;
  depth: Depth;
  reason: string;
  posterior: Record<Strategy, { a: number; b: number; mean: number; n: number }>;
}

export function selectStrategy(input: SelectionInput): SelectionResult {
  const rnd = input.rnd ?? Math.random;
  const now = input.now;
  const posterior = {} as SelectionResult["posterior"];

  // 1. Global evidence (all domains) — used as a shrunk prior for the domain.
  const global = new Map<Strategy, { a: number; b: number }>();
  const local = new Map<Strategy, { a: number; b: number; n: number }>();
  for (const s of STRATEGIES) {
    global.set(s, { a: 1, b: 1 });
    local.set(s, { a: 0, b: 0, n: 0 });
  }
  if (input.mode !== "no_adaptation") {
    const ow = orderWeights(input.outcomes);
    for (const o of input.outcomes) {
      if (!(STRATEGIES as readonly string[]).includes(o.strategy)) continue;
      const s = o.strategy as Strategy;
      const tw = recencyWeight(o.createdAt, now);
      const p = (o.outcome + 1) / 2; // map [-1,1] -> [0,1]
      const g = global.get(s)!;
      const gw = tw * ow.get(o)!.global;
      g.a += p * gw;
      g.b += (1 - p) * gw;
      if (o.domain && o.domain === input.domain) {
        const l = local.get(s)!;
        const lw = tw * ow.get(o)!.local;
        l.a += p * lw;
        l.b += (1 - p) * lw;
        l.n += 1;
      }
    }
  }

  // 2. Preference beliefs shift the prior (stated/observed preferences are evidence too).
  const prefBoost = new Map<Strategy, number>();
  for (const b of input.beliefs) {
    if (b.kind !== "preference" && b.kind !== "strategy_fit") continue;
    if (b.status !== "active" && b.status !== "contested") continue;
    const inScope = !b.domain || b.domain === input.domain;
    // Observed strategy fit is context-specific evidence: it never leaks across
    // domains (the shrunk global prior already carries cross-domain information).
    // Stated preferences travel, but weakly.
    if (b.kind === "strategy_fit" && !inScope) continue;
    for (const s of STRATEGIES) {
      if (b.statement.toLowerCase().includes(s.replace(/_/g, " ")) || b.concepts.includes(s)) {
        const neg = /(?:does not|doesn't|dislikes|not helpful|avoid|hates|has not worked)/i.test(b.statement);
        const strength = (b.influence ?? b.confidence) * (inScope ? 1 : 0.4) * (b.status === "contested" ? 0.5 : 1);
        prefBoost.set(s, (prefBoost.get(s) ?? 0) + (neg ? -strength : strength));
      }
    }
  }

  // 3. Build per-strategy posteriors: local evidence + shrunk global prior + preference.
  let best: Strategy = input.currentStrategy ?? "direct_explanation";
  let bestSample = -Infinity;
  const samples: Record<string, number> = {};
  for (const s of STRATEGIES) {
    const g = global.get(s)!;
    const l = local.get(s)!;
    const gN = g.a + g.b - 2;
    const shrink = gN > 0 ? Math.min(1, 4 / gN) : 1; // cap global influence to ~4 pseudo-observations
    const pa = 1 + (g.a - 1) * shrink + l.a;
    const pb = 1 + (g.b - 1) * shrink + l.b;
    const boost = prefBoost.get(s) ?? 0;
    let a = Math.max(0.5, pa + Math.max(0, boost) * 3);
    let b = Math.max(0.5, pb + Math.max(0, -boost) * 3);
    const total = a + b;
    if (total > MAX_PSEUDO) { a *= MAX_PSEUDO / total; b *= MAX_PSEUDO / total; }
    const mean = a / (a + b);
    posterior[s] = { a, b, mean, n: l.n };
    const sample = input.mode === "no_adaptation" ? rnd() : sampleBeta(a, b, rnd);
    samples[s] = sample;
    if (sample > bestSample) {
      bestSample = sample;
      best = s;
    }
  }

  // 4. Hysteresis on the SAMPLES (not the means) so Thompson exploration survives:
  //    keep what just worked unless another arm's sample clearly beats it; after a
  //    clear failure, always try something different.
  let reason = `Thompson sample favoured ${best}`;
  const cur = input.currentStrategy;
  if (cur && input.mode !== "no_adaptation") {
    const lastGood = (input.lastOutcomeScore ?? 0) >= 0.3;
    const lastBad = (input.lastOutcomeScore ?? 0) <= -0.3;
    const curEstablished = posterior[cur].n >= 4 && posterior[cur].mean >= 0.62;
    if (lastBad && !curEstablished) {
      // Try something different after a failure — unless this arm has a solid
      // track record here, in which case one bad turn is not evidence against it.
      if (best === cur) {
        const alt = (Object.keys(samples) as Strategy[]).filter((k) => k !== cur).sort((x, y) => samples[y] - samples[x])[0];
        best = alt;
      }
      reason = `switched from ${cur} (last outcome poor) to ${best}`;
    } else if (lastBad && best !== cur) {
      reason = `switched from ${cur} (last outcome poor) to ${best}`;
    } else if (lastBad) {
      reason = `kept ${cur} despite a poor turn: strong track record here`;
    } else if (cur !== best && lastGood && posterior[best].mean - posterior[cur].mean < 0.12) {
      // Win-stay: a strategy that just worked is kept unless another is clearly
      // better on the evidence (not merely on a lucky sample). This is what keeps
      // the tutor from oscillating between approaches turn after turn.
      best = cur;
      reason = `kept ${cur}: it just worked and nothing is clearly better`;
    } else if (cur !== best && !lastGood && posterior[best].mean - posterior[cur].mean < 0.05 && samples[cur] >= bestSample - 0.15) {
      best = cur;
      reason = `kept ${cur}: alternatives not meaningfully better`;
    }
  }
  const n = posterior[best].n;
  if (n === 0 && input.mode !== "no_adaptation") reason += ` (no ${input.domain ?? "domain"} evidence yet; using overall prior)`;

  // Depth: from preference beliefs, defaults to standard.
  let depth: Depth = "standard";
  for (const b of input.beliefs) {
    if (b.kind !== "preference" || (b.status !== "active" && b.status !== "contested")) continue;
    if (b.domain && b.domain !== input.domain) continue;
    if (/brief|short|concise|less detail/i.test(b.statement)) depth = "brief";
    if (/depth|detail|thorough|deeper/i.test(b.statement)) depth = "deep";
  }

  return { strategy: best, depth, reason, posterior };
}
