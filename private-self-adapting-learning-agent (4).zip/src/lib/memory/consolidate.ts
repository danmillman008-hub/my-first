import { db } from "@/db";
import { and, eq, ne, sql, desc, inArray, isNull } from "drizzle-orm";
import { beliefs, beliefEvidence, conceptStates, graphEdges, graphNodes, observations, strategyOutcomes, agentTraces } from "@/db/schema";
import type { BeliefKind, BeliefStatus, ExtractedObservation, TurnOutput, Strategy } from "@/lib/types";
import { STRATEGIES } from "@/lib/types";
import { slug, guessDomain } from "@/lib/llm/heuristics";
import { strategyStats } from "./strategy";
import type { MemoryMode } from "./retrieval";

const uid = (p: string) => `${p}_${crypto.randomUUID()}`;

// BKT parameters (conservative: slow learn rate, moderate guess/slip).
const BKT = { learn: 0.12, slip: 0.12, guess: 0.2 };

const OPPOSITES: Record<string, string> = {
  "pref:brief": "pref:deep",
  "pref:deep": "pref:brief",
  "pref:socratic": "pref:direct_explanation",
  "pref:direct_explanation": "pref:socratic",
};

const PREF_STATEMENT: Record<string, string> = {
  "pref:brief": "Prefers brief, concise explanations",
  "pref:deep": "Wants depth and detail rather than summaries",
  "pref:worked_example": "Prefers a concrete worked example over abstract explanation",
  "pref:analogy": "Finds analogies / real-world comparisons helpful",
  "pref:hands_on_task": "Likes to practice with a hands on task",
  "pref:step_by_step": "Prefers being walked through step by step",
  "pref:direct_explanation": "Prefers direct explanation; dislikes being quizzed",
  "pref:socratic": "Responds well to socratic questioning",
};

export interface ConsolidationInput {
  learnerId: string;
  sessionId: string;
  userMessageId: string;
  assistantMessageId: string;
  lastAssistantMessage: { id: string; meta: Record<string, unknown> } | null;
  output: TurnOutput;
  now: Date;
  mode?: MemoryMode;
}

export interface ConsolidationReport {
  observationsAdded: number;
  beliefsCreated: string[];
  beliefsSupported: string[];
  beliefsContradicted: string[];
  beliefsRetired: string[];
  outcomeRecorded: { strategy: string; outcome: number } | null;
  conceptsUpdated: string[];
}

export async function consolidateTurn(input: ConsolidationInput): Promise<ConsolidationReport> {
  const { learnerId, sessionId, output, now } = input;
  const mode = input.mode ?? "full";
  const report: ConsolidationReport = { observationsAdded: 0, beliefsCreated: [], beliefsSupported: [], beliefsContradicted: [], beliefsRetired: [], outcomeRecorded: null, conceptsUpdated: [] };

  // 1. Persist observations (short-term evidence). Dedupe only near-identical
  //    evidence inside the same session so one repeated sentence doesn't count twice.
  const stored: { id: string; obs: ExtractedObservation }[] = [];
  for (const obs of output.observations) {
    const dedupeKey = ["statement", "request", "context", "self_report", "topic_switch"].includes(obs.kind)
      ? `${obs.kind}|${(obs.signals.key as string | undefined) ?? slug(obs.content)}|${obs.domain ?? ""}`
      : null;
    if (dedupeKey) {
      const [dup] = await db
        .select({ id: observations.id })
        .from(observations)
        .where(and(eq(observations.learnerId, learnerId), eq(observations.sessionId, sessionId), eq(observations.dedupeKey, dedupeKey)))
        .limit(1);
      if (dup) continue;
    }
    const id = uid("o");
    await db.insert(observations).values({ id, learnerId, sessionId, messageId: input.userMessageId, kind: obs.kind, content: obs.content, concepts: obs.concepts, domain: obs.domain, signals: obs.signals, salience: obs.salience, dedupeKey, createdAt: now });
    stored.push({ id, obs });
    report.observationsAdded++;
  }

  // 2. Strategy outcome for the previous assistant turn (what actually worked).
  const prevStrategy = input.lastAssistantMessage?.meta?.strategy as string | undefined;
  if (mode !== "short_term_only" && output.prevTurnOutcome && prevStrategy && !["unknown", "neutral"].includes(output.prevTurnOutcome.label) && (STRATEGIES as readonly string[]).includes(prevStrategy)) {
    const prevDomain = (input.lastAssistantMessage?.meta?.domain as string | null | undefined) ?? output.domain;
    const reaction = stored.find((s) => s.obs.kind === "reaction");
    // Task success/failure is confounded by prior mastery of the concept, so it
    // counts at half weight for "did the explanation land"; the full signal goes
    // to concept states. Direct reactions (understood/confused) count fully.
    const isTask = output.prevTurnOutcome.label === "succeeded" || output.prevTurnOutcome.label === "failed";
    const attributed = isTask ? output.prevTurnOutcome.score * 0.5 : output.prevTurnOutcome.score;
    await db.insert(strategyOutcomes).values({
      id: uid("so"),
      learnerId,
      strategy: prevStrategy,
      domain: prevDomain ?? null,
      concepts: (input.lastAssistantMessage?.meta?.concepts as string[] | undefined) ?? [],
      outcome: attributed,
      outcomeLabel: output.prevTurnOutcome.label,
      assistantMessageId: input.lastAssistantMessage?.id ?? null,
      observationId: reaction?.id ?? null,
      createdAt: now,
    });
    report.outcomeRecorded = { strategy: prevStrategy, outcome: attributed };
  }

  if (mode === "short_term_only") return report;

  // 3. Concept states (behaviour-grounded knowledge tracing).
  const touched = new Set<string>();
  const conceptDomain = output.domain;
  for (const c of output.concepts) {
    await touchConcept(learnerId, c, conceptDomain, now, { exposure: true });
    touched.add(c);
  }
  for (const { obs } of stored) {
    const cs = obs.concepts.length ? obs.concepts : output.concepts;
    if (obs.kind === "success" || obs.kind === "mistake") {
      for (const c of cs) { await touchConcept(learnerId, c, obs.domain ?? conceptDomain, now, { correct: obs.kind === "success" }); touched.add(c); }
    }
    if (obs.kind === "self_report" && typeof obs.signals.level === "number") {
      for (const c of cs) { await touchConcept(learnerId, c, obs.domain ?? conceptDomain, now, { selfReport: obs.signals.level as number }); touched.add(c); }
    }
  }
  report.conceptsUpdated = [...touched];

  if (mode === "no_long_term") return report;

  // 4. Learner correction FIRST: retire without destroying evidence; optional replacement.
  const retiredKeys = new Set<string>();
  if (output.learnerCorrection) {
    const corrObs = stored.find((s) => s.obs.kind === "correction")?.id ?? (await ensureNoteObservation(learnerId, sessionId, input.userMessageId, `Correction: ${output.learnerCorrection.statement}`, now, "correction"));
    if (output.learnerCorrection.beliefId) {
      const [target] = await db.select().from(beliefs).where(eq(beliefs.id, output.learnerCorrection.beliefId)).limit(1);
      if (target && target.status !== "retired") {
        let replacementId: string | null = null;
        if (output.learnerCorrection.replacement) {
          replacementId = uid("b");
          await db.insert(beliefs).values({ id: replacementId, learnerId, kind: target.kind, key: target.key, statement: output.learnerCorrection.replacement, domain: target.domain, concepts: target.concepts, source: "stated", status: "active", confidence: 0.9, supportCount: 1, contradictionCount: 0, distinctSessions: 1, validFrom: now, lastConfirmedAt: now, createdAt: now, updatedAt: now });
          await db.insert(beliefEvidence).values({ id: uid("be"), beliefId: replacementId, observationId: corrObs, polarity: "supports", weight: 2, createdAt: now });
          report.beliefsCreated.push(replacementId);
        }
        await retire(report, target, corrObs, now, `learner correction: ${output.learnerCorrection.statement.slice(0, 140)}`, replacementId);
        if (target.key) retiredKeys.add(target.key);
        // Retire the general variant of the same key too (a general claim cannot
        // survive the learner rejecting it). Other domain-scoped variants keep their
        // own evidence: correcting "in OOP" says nothing about Bash.
        if (target.key) {
          const sib = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, learnerId), eq(beliefs.key, target.key), ne(beliefs.id, target.id), ne(beliefs.status, "retired")));
          for (const s of sib) if (!s.domain || !target.domain) await retire(report, s, corrObs, now, `learner correction (shared key ${target.key})`, replacementId);
        }
      }
    }
    await db.insert(agentTraces).values({ id: uid("t"), learnerId, sessionId, messageId: input.userMessageId, kind: "correction", payload: { ...output.learnerCorrection }, createdAt: now });
  }

  // 4b. Beliefs (long-term). Evidence must earn durability.
  for (const { id: obsId, obs } of stored) {
    const key = obs.signals.key as string | undefined;
    if (key && retiredKeys.has(key)) continue; // just retired by the learner this very turn
    if (obs.kind === "statement" && key?.startsWith("goal:")) {
      const goalText = (obs.signals.goal as string | undefined) ?? obs.content.replace(/^wants to learn:\s*/i, "");
      const goalDomain = guessDomain(goalText, obs.domain);
      await upsertBelief(report, { learnerId, sessionId, obsId, kind: "goal", key, domain: goalDomain, concepts: obs.concepts, statement: `Wants to learn ${goalText}`, source: "stated", now });
      await upsertNode(learnerId, "goal", key, goalText, now);
      if (goalDomain) { await upsertNode(learnerId, "domain", `domain:${goalDomain}`, goalDomain, now); await reinforceEdge(learnerId, key, `domain:${goalDomain}`, "involves", now, 1); }
    } else if (obs.kind === "request" && key?.startsWith("pref:")) {
      const statement = PREF_STATEMENT[key] ?? obs.content;
      const opp = OPPOSITES[key];
      if (opp) await contradictByKey(report, { learnerId, obsId, key: opp, domain: obs.domain, now });
      await upsertBelief(report, { learnerId, sessionId, obsId, kind: "preference", key, domain: obs.domain, concepts: [key.slice(5)], statement, source: "inferred", now });
      await maybeGeneralize(report, { learnerId, key, statement, now });
    } else if (obs.kind === "context" && key) {
      await upsertBelief(report, { learnerId, sessionId, obsId, kind: "context", key, domain: null, concepts: [], statement: obs.content.replace(/^context:\s*/i, ""), source: "stated", now });
    } else if (obs.kind === "reaction" && typeof obs.signals.strategy === "string" && obs.signals.outcome === "confused") {
      // Repeated confusion with a strategy in a domain is evidence too (handled via outcomes → strategy_fit below).
    }
  }

  // 4b. Self-report vs behaviour discrepancy → tendency evidence (context-scoped).
  if (conceptDomain) {
    const rows = await db.select().from(conceptStates).where(and(eq(conceptStates.learnerId, learnerId), eq(conceptStates.domain, conceptDomain)));
    for (const c of rows) {
      if (c.attempts < 3 || c.selfReport == null) continue;
      const behaviour = 2 * c.pKnown - 1;
      const gap = c.selfReport - behaviour;
      if (!touched.has(c.concept)) continue;
      const evObs = stored.find((s) => s.obs.kind === "mistake" || s.obs.kind === "success" || s.obs.kind === "self_report");
      if (!evObs) continue;
      if (gap > 0.9) {
        await upsertBelief(report, { learnerId, sessionId, obsId: evObs.id, kind: "tendency", key: `tendency:overclaims`, domain: conceptDomain, concepts: [c.concept], statement: `Says ${conceptDomain} concepts are understood, but attempts on ${c.concept} keep failing — check by doing, not by asking`, source: "observed", now });
      } else if (gap < -0.9) {
        await upsertBelief(report, { learnerId, sessionId, obsId: evObs.id, kind: "tendency", key: `tendency:underclaims`, domain: conceptDomain, concepts: [c.concept], statement: `Says they are bad at ${conceptDomain}, yet succeeds on ${c.concept} tasks — likely under-confident; encourage and raise difficulty`, source: "observed", now });
      } else if (Math.abs(gap) < 0.5) {
        // Self-report and behaviour agree now: that is evidence AGAINST a standing
        // over/under-claiming tendency, so it can be contested and eventually retired.
        for (const key of ["tendency:overclaims", "tendency:underclaims"]) {
          const rows2 = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, learnerId), eq(beliefs.key, key), eq(beliefs.domain, conceptDomain), ne(beliefs.status, "retired")));
          for (const b of rows2) await contradict(report, b, evObs.id, now, `self-report and behaviour now agree on ${c.concept}`);
        }
      }
    }
  }

  // 4c. LLM belief feedback (supports/contradicts existing beliefs).
  for (const f of output.beliefFeedback) {
    const [b] = await db.select().from(beliefs).where(eq(beliefs.id, f.beliefId)).limit(1);
    if (!b || b.status === "retired") continue;
    const evObs = stored[0]?.id ?? (await ensureNoteObservation(learnerId, sessionId, input.userMessageId, `Model judged this turn ${f.polarity} belief: ${f.note}`, now));
    if (f.polarity === "supports") await support(report, b, evObs, sessionId, now);
    else await contradict(report, b, evObs, now, `contradicted by behaviour: ${f.note}`);
  }

  // 5. Strategy-fit beliefs derived from accumulated outcomes (context-scoped).
  if (mode !== "no_adaptation" && conceptDomain) await deriveStrategyFit(report, learnerId, sessionId, conceptDomain, now);

  // 6. Graph evolution.
  if (conceptDomain) {
    await upsertNode(learnerId, "domain", `domain:${conceptDomain}`, conceptDomain, now);
    const keys = output.concepts.map((c) => `concept:${conceptDomain}/${slug(c)}`);
    for (let i = 0; i < output.concepts.length; i++) {
      await upsertNode(learnerId, "concept", keys[i], output.concepts[i], now, { domain: conceptDomain });
      await reinforceEdge(learnerId, keys[i], `domain:${conceptDomain}`, "belongs_to", now, 0.5);
      for (let j = i + 1; j < keys.length; j++) await reinforceEdge(learnerId, keys[i], keys[j], "co_occurs", now, 0.25);
    }
    // Active goals in this domain → goal involves concept.
    const goals = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, learnerId), eq(beliefs.kind, "goal"), eq(beliefs.status, "active"), eq(beliefs.domain, conceptDomain)));
    for (const g of goals) if (g.key) for (const k of keys) await reinforceEdge(learnerId, g.key, k, "involves", now, 0.3);
    // learner struggles_with / has_grasped edges from behaviour, bi-temporal.
    for (const c of touched) {
      const [cs] = await db.select().from(conceptStates).where(and(eq(conceptStates.learnerId, learnerId), eq(conceptStates.concept, c), eq(conceptStates.domain, conceptDomain))).limit(1);
      if (!cs) continue;
      const k = `concept:${conceptDomain}/${slug(c)}`;
      if (cs.attempts >= 3 && cs.pKnown < 0.35) { await reinforceEdge(learnerId, "learner:self", k, "struggles_with", now, 0.5); await invalidateEdge(learnerId, "learner:self", k, "has_grasped", now); }
      if (cs.attempts >= 2 && cs.pKnown >= 0.75) { await reinforceEdge(learnerId, "learner:self", k, "has_grasped", now, 0.5); await invalidateEdge(learnerId, "learner:self", k, "struggles_with", now); }
    }
  }

  return report;
}

// ---------------------------------------------------------------------------
// Concept tracing
// ---------------------------------------------------------------------------
async function touchConcept(learnerId: string, concept: string, domain: string | null, now: Date, ev: { exposure?: boolean; correct?: boolean; selfReport?: number }) {
  const c = concept.toLowerCase().trim();
  if (!c) return;
  const [row] = await db.select().from(conceptStates).where(and(eq(conceptStates.learnerId, learnerId), eq(conceptStates.concept, c), domain ? eq(conceptStates.domain, domain) : isNull(conceptStates.domain))).limit(1);
  let p = row?.pKnown ?? 0.2;
  const patch: Partial<typeof conceptStates.$inferInsert> = { lastSeenAt: now };
  if (ev.exposure) patch.exposures = (row?.exposures ?? 0) + 1;
  if (ev.correct != null) {
    const { slip, guess, learn } = BKT;
    const post = ev.correct ? (p * (1 - slip)) / (p * (1 - slip) + (1 - p) * guess) : (p * slip) / (p * slip + (1 - p) * (1 - guess));
    p = post + (1 - post) * learn;
    patch.pKnown = Math.min(0.99, Math.max(0.01, p));
    patch.attempts = (row?.attempts ?? 0) + 1;
    if (ev.correct) { patch.successes = (row?.successes ?? 0) + 1; patch.lastSuccessAt = now; }
    else { patch.mistakes = (row?.mistakes ?? 0) + 1; patch.lastMistakeAt = now; }
  }
  if (ev.selfReport != null) patch.selfReport = ev.selfReport;
  if (row) await db.update(conceptStates).set(patch).where(eq(conceptStates.id, row.id));
  else await db.insert(conceptStates).values({ id: uid("cs"), learnerId, concept: c, domain, pKnown: patch.pKnown ?? 0.2, attempts: patch.attempts ?? 0, successes: patch.successes ?? 0, mistakes: patch.mistakes ?? 0, selfReport: patch.selfReport ?? null, exposures: patch.exposures ?? 0, firstSeenAt: now, lastSeenAt: now, lastSuccessAt: patch.lastSuccessAt ?? null, lastMistakeAt: patch.lastMistakeAt ?? null });
}

// ---------------------------------------------------------------------------
// Belief lifecycle
// ---------------------------------------------------------------------------
function confidenceFor(source: string, support: number, contradiction: number): number {
  const a0 = source === "stated" ? 4 : 1;
  return Math.min(0.97, (support + a0) / (support + contradiction + a0 + 1));
}

function statusFor(source: string, support: number, contradiction: number, distinctSessions: number, prev: BeliefStatus): BeliefStatus {
  if (contradiction > 0 && contradiction >= support) return "retired";
  if (contradiction > 0 && contradiction / Math.max(1, support) >= 0.34) return "contested";
  if (source === "stated") return "active";
  if (support >= 2 && (distinctSessions >= 2 || support >= 3)) return "active";
  return prev === "active" || prev === "contested" ? "active" : "candidate";
}

async function upsertBelief(report: ConsolidationReport, p: { learnerId: string; sessionId: string; obsId: string; kind: BeliefKind; key: string; domain: string | null; concepts: string[]; statement: string; source: string; now: Date }) {
  const existing = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, p.learnerId), eq(beliefs.key, p.key), p.domain ? eq(beliefs.domain, p.domain) : isNull(beliefs.domain), ne(beliefs.status, "retired"))).limit(1);
  if (existing[0]) return support(report, existing[0], p.obsId, p.sessionId, p.now);
  const id = uid("b");
  const status: BeliefStatus = p.source === "stated" ? "active" : "candidate";
  await db.insert(beliefs).values({ id, learnerId: p.learnerId, kind: p.kind, key: p.key, statement: p.statement, domain: p.domain, concepts: p.concepts, source: p.source, status, confidence: confidenceFor(p.source, 1, 0), supportCount: 1, contradictionCount: 0, distinctSessions: 1, validFrom: p.now, lastConfirmedAt: p.now, createdAt: p.now, updatedAt: p.now });
  await db.insert(beliefEvidence).values({ id: uid("be"), beliefId: id, observationId: p.obsId, polarity: "supports", weight: 1, createdAt: p.now });
  report.beliefsCreated.push(id);
}

async function distinctSessionCount(beliefId: string): Promise<number> {
  const [r] = await db
    .select({ n: sql<number>`count(distinct ${observations.sessionId})::int` })
    .from(beliefEvidence)
    .innerJoin(observations, eq(observations.id, beliefEvidence.observationId))
    .where(and(eq(beliefEvidence.beliefId, beliefId), eq(beliefEvidence.polarity, "supports")));
  return r?.n ?? 1;
}

async function support(report: ConsolidationReport, b: typeof beliefs.$inferSelect, obsId: string, sessionId: string, now: Date) {
  await db.insert(beliefEvidence).values({ id: uid("be"), beliefId: b.id, observationId: obsId, polarity: "supports", weight: 1, createdAt: now });
  const supportCount = b.supportCount + 1;
  const distinct = await distinctSessionCount(b.id);
  // Fresh support after contradictions slowly re-earns trust; contradictions decay by one per two supports.
  const contradictionCount = supportCount % 2 === 0 ? Math.max(0, b.contradictionCount - 1) : b.contradictionCount;
  const status = statusFor(b.source, supportCount, contradictionCount, distinct, b.status === "dormant" ? "active" : b.status);
  await db.update(beliefs).set({ supportCount, contradictionCount, distinctSessions: distinct, confidence: confidenceFor(b.source, supportCount, contradictionCount), status, lastConfirmedAt: now, updatedAt: now, invalidAt: null, invalidReason: null }).where(eq(beliefs.id, b.id));
  report.beliefsSupported.push(b.id);
}

async function contradict(report: ConsolidationReport, b: typeof beliefs.$inferSelect, obsId: string, now: Date, reason: string) {
  await db.insert(beliefEvidence).values({ id: uid("be"), beliefId: b.id, observationId: obsId, polarity: "contradicts", weight: 1, createdAt: now });
  const contradictionCount = b.contradictionCount + 1;
  const status = statusFor(b.source, b.supportCount, contradictionCount, b.distinctSessions, b.status);
  await db.update(beliefs).set({ contradictionCount, confidence: confidenceFor(b.source, b.supportCount, contradictionCount), status, updatedAt: now, ...(status === "retired" ? { invalidAt: now, invalidReason: reason } : {}) }).where(eq(beliefs.id, b.id));
  (status === "retired" ? report.beliefsRetired : report.beliefsContradicted).push(b.id);
}

async function retire(report: ConsolidationReport, b: typeof beliefs.$inferSelect, obsId: string, now: Date, reason: string, supersededBy: string | null) {
  await db.insert(beliefEvidence).values({ id: uid("be"), beliefId: b.id, observationId: obsId, polarity: "contradicts", weight: 3, createdAt: now });
  await db.update(beliefs).set({ status: "retired", invalidAt: now, invalidReason: reason, supersededBy, contradictionCount: b.contradictionCount + 1, confidence: Math.min(b.confidence, 0.1), updatedAt: now }).where(eq(beliefs.id, b.id));
  report.beliefsRetired.push(b.id);
}

async function contradictByKey(report: ConsolidationReport, p: { learnerId: string; obsId: string; key: string; domain: string | null; now: Date }) {
  const rows = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, p.learnerId), eq(beliefs.key, p.key), ne(beliefs.status, "retired")));
  for (const b of rows) {
    // Same scope or general scope contradicts; a different specific domain does not.
    if (b.domain && p.domain && b.domain !== p.domain) continue;
    await contradict(report, b, p.obsId, p.now, `learner asked for the opposite (${p.key})`);
  }
}

/** If the same preference is active in ≥2 domains, add/upgrade a general belief. */
async function maybeGeneralize(report: ConsolidationReport, p: { learnerId: string; key: string; statement: string; now: Date }) {
  const rows = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, p.learnerId), eq(beliefs.key, p.key), ne(beliefs.status, "retired")));
  const activeDomains = new Set(rows.filter((r) => r.domain && (r.status === "active" || r.status === "contested")).map((r) => r.domain));
  const general = rows.find((r) => !r.domain);
  if (activeDomains.size >= 2 && !general) {
    const id = uid("b");
    const total = rows.reduce((s, r) => s + r.supportCount, 0);
    await db.insert(beliefs).values({ id, learnerId: p.learnerId, kind: "preference", key: p.key, statement: `${p.statement} (seen across ${[...activeDomains].join(", ")})`, domain: null, concepts: [p.key.slice(5)], source: "inferred", status: "active", confidence: confidenceFor("inferred", total, 0), supportCount: total, contradictionCount: 0, distinctSessions: activeDomains.size, validFrom: p.now, lastConfirmedAt: p.now, createdAt: p.now, updatedAt: p.now });
    // Link evidence from the scoped beliefs so provenance is preserved.
    const ev = await db.select().from(beliefEvidence).where(inArray(beliefEvidence.beliefId, rows.map((r) => r.id)));
    for (const e of ev) await db.insert(beliefEvidence).values({ id: uid("be"), beliefId: id, observationId: e.observationId, polarity: e.polarity, weight: e.weight, createdAt: p.now });
    report.beliefsCreated.push(id);
  }
}

async function ensureNoteObservation(learnerId: string, sessionId: string, messageId: string, content: string, now: Date, kind: "reaction" | "correction" = "reaction"): Promise<string> {
  const id = uid("o");
  await db.insert(observations).values({ id, learnerId, sessionId, messageId, kind, content, concepts: [], domain: null, signals: {}, salience: 0.6, dedupeKey: null, createdAt: now });
  return id;
}

async function deriveStrategyFit(report: ConsolidationReport, learnerId: string, sessionId: string, domain: string, now: Date) {
  const rows = await db.select().from(strategyOutcomes).where(and(eq(strategyOutcomes.learnerId, learnerId), eq(strategyOutcomes.domain, domain))).orderBy(desc(strategyOutcomes.createdAt)).limit(200);
  if (rows.length < 4) return;
  const stats = strategyStats(rows.map((r) => ({ strategy: r.strategy, domain: r.domain, outcome: r.outcome, createdAt: r.createdAt })), now).filter((s) => s.domain === domain);
  const sorted = [...stats].sort((a, b) => b.mean - a.mean);
  const existing = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, learnerId), eq(beliefs.kind, "strategy_fit"), eq(beliefs.domain, domain), ne(beliefs.status, "retired")));
  // A learner correction outranks old aggregate evidence: after "that's not true",
  // a fit belief may only re-emerge from outcomes observed AFTER the correction.
  const corrected = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, learnerId), eq(beliefs.kind, "strategy_fit"), eq(beliefs.domain, domain), eq(beliefs.status, "retired")));
  const correctedAt = new Map<string, Date>();
  for (const c of corrected) if (c.key && c.invalidAt && c.invalidReason?.startsWith("learner correction")) correctedAt.set(c.key, new Date(Math.max(c.invalidAt.getTime(), correctedAt.get(c.key)?.getTime() ?? 0)));
  for (const s0 of stats) {
    const fitKey = `fit:${s0.strategy}`;
    const unfitKey = `unfit:${s0.strategy}`;
    const since = correctedAt.get(fitKey) ?? correctedAt.get(unfitKey);
    let s = s0;
    if (since) {
      const fresh = rows.filter((r) => r.strategy === s0.strategy && r.createdAt > since);
      const st = strategyStats(fresh.map((r) => ({ strategy: r.strategy, domain: r.domain, outcome: r.outcome, createdAt: r.createdAt })), now).find((x) => x.domain === domain);
      s = st ?? { ...s0, n: 0, mean: 0 };
    }
    const fit = existing.find((b) => b.key === fitKey);
    const unfit = existing.find((b) => b.key === unfitKey);
    const best = sorted[0];
    const second = sorted[1];
    const latest = rows.find((r) => r.strategy === s.strategy);
    const evObs = latest?.observationId ?? (await ensureNoteObservation(learnerId, sessionId, "", `Aggregate: ${s.strategy} mean outcome ${s.mean.toFixed(2)} over ${s.n} turns in ${domain}`, now));
    if (s.n >= 4 && s.mean >= 0.4 && best.strategy === s.strategy && (!second || best.mean - second.mean >= 0.2)) {
      if (!fit) {
        const id = uid("b");
        await db.insert(beliefs).values({ id, learnerId, kind: "strategy_fit", key: fitKey, statement: `${label(s.strategy)} works well for this learner in ${domain} (mean outcome ${s.mean.toFixed(2)} over ${s.n} turns)`, domain, concepts: [s.strategy], source: "observed", status: "active", confidence: Math.min(0.9, 0.5 + s.n * 0.05), supportCount: s.n, contradictionCount: 0, distinctSessions: 1, validFrom: now, lastConfirmedAt: now, createdAt: now, updatedAt: now });
        await db.insert(beliefEvidence).values({ id: uid("be"), beliefId: id, observationId: evObs, polarity: "supports", weight: 1, createdAt: now });
        report.beliefsCreated.push(id);
      } else if (fit.supportCount !== s.n) {
        await db.update(beliefs).set({ statement: `${label(s.strategy)} works well for this learner in ${domain} (mean outcome ${s.mean.toFixed(2)} over ${s.n} turns)`, supportCount: s.n, confidence: Math.min(0.9, 0.5 + s.n * 0.05), status: "active", lastConfirmedAt: now, updatedAt: now }).where(eq(beliefs.id, fit.id));
      }
    } else if (fit) {
      if (s.mean < -0.1) { await retire(report, fit, evObs, now, `outcomes changed: ${s.strategy} now averages ${s.mean.toFixed(2)}`, null); }
      else if (s.mean < 0.2 && fit.status === "active") { await db.update(beliefs).set({ status: "contested", updatedAt: now }).where(eq(beliefs.id, fit.id)); report.beliefsContradicted.push(fit.id); }
    }
    // Change detector: a run of recent failures contests a standing "works well"
    // belief immediately, even if the long-run mean is still positive.
    if (fit && fit.status === "active") {
      const recent = rows.filter((r) => r.strategy === s.strategy).slice(0, 3);
      if (recent.length === 3 && recent.every((r) => r.outcome <= -0.3)) {
        await db.update(beliefs).set({ status: "contested", contradictionCount: fit.contradictionCount + 1, updatedAt: now }).where(eq(beliefs.id, fit.id));
        await db.insert(beliefEvidence).values({ id: uid("be"), beliefId: fit.id, observationId: evObs, polarity: "contradicts", weight: 1, createdAt: now });
        report.beliefsContradicted.push(fit.id);
      }
    }
    if (s.n >= 6 && s.mean <= -0.3) {
      if (!unfit) {
        const id = uid("b");
        await db.insert(beliefs).values({ id, learnerId, kind: "strategy_fit", key: unfitKey, statement: `${label(s.strategy)} has not worked well in ${domain} (mean outcome ${s.mean.toFixed(2)} over ${s.n} turns) — avoid leading with it`, domain, concepts: [s.strategy], source: "observed", status: "active", confidence: Math.min(0.85, 0.5 + s.n * 0.05), supportCount: s.n, contradictionCount: 0, distinctSessions: 1, validFrom: now, lastConfirmedAt: now, createdAt: now, updatedAt: now });
        await db.insert(beliefEvidence).values({ id: uid("be"), beliefId: id, observationId: evObs, polarity: "supports", weight: 1, createdAt: now });
        report.beliefsCreated.push(id);
      }
    } else if (unfit && s.mean > 0.1) {
      await retire(report, unfit, evObs, now, `outcomes changed: ${s.strategy} now averages ${s.mean.toFixed(2)}`, null);
    }
    await upsertNode(learnerId, "strategy", `strategy:${s.strategy}`, label(s.strategy), now);
    if (s.mean > 0.1) await reinforceEdge(learnerId, `strategy:${s.strategy}`, `domain:${domain}`, "works_for", now, 0, s.mean);
    else await invalidateEdge(learnerId, `strategy:${s.strategy}`, `domain:${domain}`, "works_for", now);
  }
}

function label(s: string) {
  return s.replace(/_/g, " ").replace(/^\w/, (c) => c.toUpperCase());
}

/** Dormancy sweep: long-unconfirmed inferred beliefs lose active influence without losing history. */
export async function sweepDormancy(learnerId: string, now: Date) {
  const rows = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, learnerId), inArray(beliefs.status, ["active", "contested"])));
  const limits: Record<string, number> = { preference: 150, tendency: 150, strategy_fit: 120, knowledge: 120, goal: 200, context: 100000 };
  let changed = 0;
  for (const b of rows) {
    const days = (now.getTime() - b.lastConfirmedAt.getTime()) / 86400000;
    if (days > (limits[b.kind] ?? 150)) {
      await db.update(beliefs).set({ status: "dormant", updatedAt: now }).where(eq(beliefs.id, b.id));
      changed++;
    }
  }
  return changed;
}

// ---------------------------------------------------------------------------
// Graph helpers (bi-temporal edges: invalidated, never deleted)
// ---------------------------------------------------------------------------
export async function upsertNode(learnerId: string, type: string, key: string, labelText: string, now: Date, attrs: Record<string, unknown> = {}) {
  const [n] = await db.select({ id: graphNodes.id }).from(graphNodes).where(and(eq(graphNodes.learnerId, learnerId), eq(graphNodes.key, key))).limit(1);
  if (n) await db.update(graphNodes).set({ updatedAt: now, active: true }).where(eq(graphNodes.id, n.id));
  else await db.insert(graphNodes).values({ id: uid("n"), learnerId, type, key, label: labelText, attrs, active: true, createdAt: now, updatedAt: now });
}

export async function reinforceEdge(learnerId: string, fromKey: string, toKey: string, relation: string, now: Date, delta: number, setWeight?: number) {
  if (fromKey === toKey) return;
  const [e] = await db.select().from(graphEdges).where(and(eq(graphEdges.learnerId, learnerId), eq(graphEdges.fromKey, fromKey), eq(graphEdges.toKey, toKey), eq(graphEdges.relation, relation))).orderBy(desc(graphEdges.createdAt)).limit(1);
  if (e && !e.invalidAt) {
    await db.update(graphEdges).set({ weight: setWeight ?? Math.min(5, e.weight + delta), evidenceCount: e.evidenceCount + 1, lastReinforcedAt: now }).where(eq(graphEdges.id, e.id));
  } else if (e && e.invalidAt) {
    // Re-activation: new validity interval, history retained.
    await db.insert(graphEdges).values({ id: uid("e"), learnerId, fromKey, toKey, relation, weight: setWeight ?? Math.max(0.5, e.weight * 0.5), evidenceCount: 1, attrs: { reactivatedFrom: e.id }, validFrom: now, lastReinforcedAt: now, createdAt: now });
  } else {
    if (fromKey === "learner:self") await upsertNode(learnerId, "learner", "learner:self", "Learner", now);
    await db.insert(graphEdges).values({ id: uid("e"), learnerId, fromKey, toKey, relation, weight: setWeight ?? Math.max(0.5, delta || 1), evidenceCount: 1, attrs: {}, validFrom: now, lastReinforcedAt: now, createdAt: now });
  }
}

export async function invalidateEdge(learnerId: string, fromKey: string, toKey: string, relation: string, now: Date) {
  await db.update(graphEdges).set({ invalidAt: now }).where(and(eq(graphEdges.learnerId, learnerId), eq(graphEdges.fromKey, fromKey), eq(graphEdges.toKey, toKey), eq(graphEdges.relation, relation), isNull(graphEdges.invalidAt)));
}

export type { Strategy };
