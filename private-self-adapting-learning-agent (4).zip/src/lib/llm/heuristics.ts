import type { ExtractedObservation, OutcomeLabel, Strategy, TurnContext } from "@/lib/types";

// ---------------------------------------------------------------------------
// Deterministic signal extraction from a learner message.
// Used (a) as the whole "model" in offline mode, and (b) as a safety net on the
// real-LLM path for high-stakes signals (goals, corrections, explicit requests)
// so that they are never silently dropped.
// ---------------------------------------------------------------------------

const DOMAIN_HINTS: Record<string, string[]> = {
  bash: ["bash", "shell", "pipe", "grep", "awk", "sed", "xargs", "stdin", "stdout", "stderr", "chmod", "cron", ".sh", "$(", "ls -", "exit code", "set -e", "my script", "redirect", "2>&1", "globbing", "subshell"],
  oop: ["oop", "object oriented", "object-oriented", "inheritance", "polymorphism", "encapsulation", "abstract class", "subclass", "superclass", "composition over", "constructor", "a class ", "classes"],
  python: ["python", "def ", "list comprehension", "pandas", "numpy", "pip ", "decorator", "lambda", "dict"],
  javascript: ["javascript", "typescript", "node.js", "promise", "async", "await", "closure", "prototype", "const ", "=>", "npm"],
  sql: ["sql", "select ", "join", "postgres", "group by", "primary key", "foreign key"],
  statistics: ["statistics", "probability", "bayes", "p-value", "regression", "variance", "distribution", "hypothesis test", "standard deviation"],
  math: ["calculus", "derivative", "integral", "algebra", "matrix", "linear algebra", "eigen", "theorem", "proof"],
  git: ["git ", "commit", "branch", "merge", "rebase", "pull request"],
  networking: ["tcp", "http", "dns", "socket", "ip address", "latency", "packet"],
  music: ["music theory", "chord", "scale", "harmony", "interval", "key signature"],
  spanish: ["spanish", "español", "subjunctive", "conjugat", "ser vs estar", "preterite"],
  economics: ["economics", "inflation", "supply and demand", "gdp", "monetary"],
  chemistry: ["chemistry", "molecule", "reaction", "acid", "covalent", "mole "],
  history: ["history", "empire", "revolution", "century", "war of"],
};

const GOAL_RX = /\b(?:i want to learn|i'd like to learn|i want to understand|teach me|help me learn|my goal is|i need to learn|i'm trying to learn|i am trying to learn|let's learn)\b\s*(?:about\s+)?([^.!?\n]{2,60})/i;
const SWITCH_RX = /\b(?:forget|leave|park|skip|put aside|actually,? (?:let's|lets) (?:switch|move|talk about)|different topic|change (?:of )?(?:topic|subject)|let's move on to|instead, explain|now explain)\b/i;

export function guessDomain(text: string, fallback: string | null): string | null {
  // A stated goal defines the domain ("I want to learn Bash. I use Python at work" → bash).
  const goal = text.match(GOAL_RX);
  if (goal) {
    const g = scoreDomains(goal[1]);
    if (g) return g;
  }
  // After "forget X… explain Y", only the part after the switch phrase counts.
  const sw = text.match(SWITCH_RX);
  if (sw && sw.index != null) {
    const after = text.slice(sw.index + sw[0].length).replace(/^[^.!?]*?(?:for a moment|for now)[.,!?]?/i, "");
    const d = scoreDomains(after);
    if (d) return d;
  }
  return scoreDomains(text) ?? fallback;
}

function scoreDomains(text: string): string | null {
  const t = text.toLowerCase();
  let best: string | null = null;
  let bestScore = 0;
  for (const [domain, hints] of Object.entries(DOMAIN_HINTS)) {
    let score = 0;
    for (const h of hints) if (t.includes(h)) score += h.length > 4 ? 2 : 1;
    if (score > bestScore) {
      bestScore = score;
      best = domain;
    }
  }
  // Generic "learn X" pattern for open domains.
  const m = t.match(/(?:learn|understand|study|get better at|teach me|explain)\s+(?:about\s+)?([a-z][a-z0-9+#.\- ]{1,30}?)(?:[.,!?]|$| please| now| to me| from)/);
  if (!best && m) best = m[1].trim().replace(/\s+/g, "_");
  return best;
}

export function extractConcepts(text: string, domain: string | null): string[] {
  const t = text.toLowerCase();
  const found = new Set<string>();
  const vocab: Record<string, string[]> = {
    bash: ["pipes", "redirection", "variables", "quoting", "loops", "conditionals", "exit codes", "globbing", "subshells", "permissions", "grep", "sed", "awk", "xargs", "find", "cron"],
    oop: ["classes", "objects", "inheritance", "polymorphism", "encapsulation", "abstraction", "interfaces", "composition", "constructors", "methods"],
    python: ["functions", "lists", "dicts", "comprehensions", "classes", "decorators", "generators", "exceptions", "modules"],
    javascript: ["closures", "promises", "async", "prototypes", "scope", "hoisting", "events", "modules", "this"],
    sql: ["joins", "indexes", "aggregation", "subqueries", "transactions", "normalization"],
    statistics: ["probability", "bayes", "distributions", "regression", "variance", "hypothesis testing", "sampling"],
    math: ["derivatives", "integrals", "limits", "matrices", "vectors", "proofs"],
    git: ["commits", "branches", "merging", "rebasing", "remotes"],
  };
  const words = domain && vocab[domain] ? vocab[domain] : Object.values(vocab).flat();
  for (const w of words) {
    const stem = w.replace(/s$/, "");
    if (t.includes(stem)) found.add(w);
  }
  // Explicit "concept: X" or backticked tokens count as concepts in any domain.
  for (const m of t.matchAll(/`([a-z0-9_\-. ]{2,24})`/g)) found.add(m[1].trim());
  return [...found].slice(0, 6);
}

const RX = {
  goal: /\b(?:i want to learn|i'd like to learn|i want to understand|teach me|help me learn|my goal is|i need to learn|i'm trying to learn|i am trying to learn|let's learn)\b\s*(?:about\s+)?([^.!?\n]{2,60})/i,
  switchAway: /\b(?:forget|leave|park|skip|put aside|actually,? (?:let's|lets) (?:switch|move|talk about)|different topic|change (?:of )?(?:topic|subject)|let's move on to|instead, explain|now explain)\b/i,
  confused: /\b(?:i don't get it|i dont get it|i'm confused|im confused|confusing|doesn't make sense|makes no sense|lost me|too abstract|too complicated|what\?|huh\?|i still don't understand|not following|too fast|slow down)\b/i,
  understood: /\b(?:that makes sense|makes sense|got it|i see|i understand now|clear now|ah+,? (?:ok|okay|right)|oh,? that's why|clicked|perfect,? thanks|thanks,? that helps|that helps|crystal clear|now i get it)\b/i,
  disagree: /\b(?:i disagree|that's wrong|thats wrong|that's not right|that is not right|i don't think that's right|you're wrong|no,? that's incorrect|that's not correct|are you sure\?|i don't think so)\b/i,
  correction: /\b(?:that's not true about me|that's not true|you('re| are) wrong about me|i never said|stop assuming|i don't actually|that's not me|i'm not (?:a |an )?(?:beginner|expert|visual learner)|i didn't say|that's outdated|not anymore)\b/i,
  selfNeg: /\b(?:i'm bad at|im bad at|i'm terrible at|i'm not good at|i struggle with|i always struggle|i never understood|i'm hopeless at|i suck at)\b\s*([^.!?\n]{0,40})/i,
  selfPos: /\b(?:i understand this|i already know|i know this|i'm good at|i'm comfortable with|this is easy|i get this|i've mastered|i'm confident (?:with|about|in))\b\s*([^.!?\n]{0,40})/i,
  wantShorter: /\b(?:shorter|too long|tl;?dr|just the gist|be brief|less detail|keep it short|too much text|summarize)\b/i,
  wantDetail: /\b(?:more detail|go deeper|elaborate|in depth|explain more|more thorough|why exactly|under the hood|the full picture)\b/i,
  wantExample: /\b(?:show me an example|give me an example|for example\?|example please|can you show|concrete example|show me code|show me)\b/i,
  wantAnalogy: /\b(?:analogy|metaphor|like in real life|compare it to|real[- ]world)\b/i,
  wantTask: /\b(?:give me (?:an?|a quick|a small|some) (?:exercise|task|challenge|problem)|let me try|practice|challenge me|quiz me|let me practice|test me)\b/i,
  wantSteps: /\b(?:step by step|step-by-step|walk me through|one step at a time)\b/i,
  wantDirect: /\b(?:just tell me|stop asking|don't quiz me|just answer|no questions,? just)\b/i,
  attemptSuccess: /\b(?:it worked|that worked|i solved it|i fixed it|passes now|works now|i got it working|correct\?|done,? it prints|my answer is)\b/i,
  attemptFail: /\b(?:still (?:fails|broken|wrong)|doesn't work|does not work|same error|it errors|still get the error|i tried .* but|not working|i broke it)\b/i,
  context: /\b(?:i'm a |i am a |i work as|my job|at work we|i have an exam|deadline|interview (?:on|next|tomorrow)|i'm on my phone|i only have \d+ minutes|i studied|my background is)\b([^.!?\n]{0,60})/i,
  code: /```[\s\S]*?```|\$\s?[a-z]+\s+-[a-z]+|\bdef\s+\w+\(|\bclass\s+\w+|\bfunction\s+\w+\(|=>|\|\s*grep\b|\bfor\s+\w+\s+in\b/i,
  why: /\bwhy\b/i,
};

export interface HeuristicResult {
  observations: ExtractedObservation[];
  prevTurnOutcome: { label: OutcomeLabel; score: number } | null;
  requestedStrategy: Strategy | null;
  requestedDepth: "brief" | "deep" | null;
  isCorrection: boolean;
  correctionText: string | null;
  isTopicSwitch: boolean;
  domain: string | null;
  concepts: string[];
  isQuestion: boolean;
  goal: string | null;
  hasCode: boolean;
  attempt: "success" | "fail" | null;
}

export function heuristicExtract(userMessage: string, context: TurnContext): HeuristicResult {
  const msg = userMessage.trim();
  const lower = msg.toLowerCase();
  const isTopicSwitch = RX.switchAway.test(lower);
  const domain = guessDomain(msg, isTopicSwitch ? null : context.currentDomainGuess);
  const concepts = extractConcepts(msg, domain);
  const obs: ExtractedObservation[] = [];
  const base = { concepts, domain };

  const goalMatch = msg.match(RX.goal);
  const goal = goalMatch ? goalMatch[1].trim().replace(/[.!?]$/, "") : null;
  if (goal) {
    obs.push({ ...base, kind: "statement", content: `Wants to learn: ${goal}`, signals: { key: `goal:${slug(goal)}`, goal }, salience: 0.9 });
  }
  if (isTopicSwitch) {
    obs.push({ ...base, kind: "topic_switch", content: `Switched topic${domain ? ` to ${domain}` : ""}${context.currentDomainGuess ? ` (from ${context.currentDomainGuess})` : ""}`, signals: { from: context.currentDomainGuess, to: domain }, salience: 0.5 });
  }

  // Outcome of the previous assistant turn, judged from this message.
  const hadAssistantTurn = context.recentMessages.some((m) => m.role === "assistant");
  const attempt: "success" | "fail" | null = RX.attemptSuccess.test(lower) ? "success" : RX.attemptFail.test(lower) ? "fail" : null;
  const prevTurnOutcome = detectOutcome(msg, hadAssistantTurn, isTopicSwitch || !!goal);

  if (prevTurnOutcome && prevTurnOutcome.label !== "unknown" && prevTurnOutcome.label !== "neutral") {
    const prevStrategy = context.lastAssistantMeta?.strategy as string | undefined;
    obs.push({
      ...base,
      kind: "reaction",
      content: `Reacted to ${prevStrategy ?? "previous"} explanation: ${prevTurnOutcome.label}`,
      signals: { outcome: prevTurnOutcome.label, score: prevTurnOutcome.score, strategy: prevStrategy ?? null },
      salience: Math.abs(prevTurnOutcome.score) > 0.5 ? 0.7 : 0.4,
    });
  }

  if (attempt === "success") obs.push({ ...base, kind: "success", content: `Reported a working attempt${concepts.length ? ` on ${concepts.join(", ")}` : ""}`, signals: { polarity: 1 }, salience: 0.8 });
  if (attempt === "fail") obs.push({ ...base, kind: "mistake", content: `Attempt failed${concepts.length ? ` on ${concepts.join(", ")}` : ""}: ${firstSentence(msg)}`, signals: { polarity: -1 }, salience: 0.8 });

  const sn = msg.match(RX.selfNeg);
  if (sn) obs.push({ ...base, kind: "self_report", content: `Self-report (negative): ${firstSentence(sn[0])}`, signals: { level: -0.7, concepts }, salience: 0.6 });
  const sp = msg.match(RX.selfPos);
  if (sp) obs.push({ ...base, kind: "self_report", content: `Self-report (positive): ${firstSentence(sp[0])}`, signals: { level: 0.7, concepts }, salience: 0.6 });

  let requestedStrategy: Strategy | null = null;
  let requestedDepth: "brief" | "deep" | null = null;
  const pushReq = (key: string, content: string) => obs.push({ ...base, kind: "request", content, signals: { key }, salience: 0.7 });
  if (RX.wantShorter.test(lower)) { requestedDepth = "brief"; pushReq("pref:brief", "Asked for shorter / less detailed explanations"); }
  if (RX.wantDetail.test(lower)) { requestedDepth = "deep"; pushReq("pref:deep", "Asked for more depth / detail"); }
  if (RX.wantExample.test(lower)) { requestedStrategy = "worked_example"; pushReq("pref:worked_example", "Asked for a concrete example"); }
  if (RX.wantAnalogy.test(lower)) { requestedStrategy = "analogy"; pushReq("pref:analogy", "Asked for an analogy / real-world comparison"); }
  if (RX.wantTask.test(lower)) { requestedStrategy = "hands_on_task"; pushReq("pref:hands_on_task", "Asked for a practice task"); }
  if (RX.wantSteps.test(lower)) { requestedStrategy = "step_by_step"; pushReq("pref:step_by_step", "Asked to be walked through step by step"); }
  if (RX.wantDirect.test(lower)) { requestedStrategy = "direct_explanation"; pushReq("pref:direct_explanation", "Asked for direct answers rather than questions"); }

  const isCorrection = RX.correction.test(lower);
  if (isCorrection) obs.push({ ...base, kind: "correction", content: `Corrected the tutor's assumption: ${firstSentence(msg)}`, signals: {}, salience: 1 });

  const ctx = msg.match(RX.context);
  if (ctx) obs.push({ ...base, kind: "context", content: `Context: ${firstSentence(ctx[0])}`, signals: { key: `ctx:${slug(ctx[0]).slice(0, 40)}` }, salience: 0.6 });

  const hasCode = RX.code.test(msg);
  if (hasCode) obs.push({ ...base, kind: "code_shared", content: `Shared code${concepts.length ? ` involving ${concepts.join(", ")}` : ""}`, signals: {}, salience: 0.5 });

  const isQuestion = /\?/.test(msg) || RX.why.test(lower);
  if (isQuestion && !goal) obs.push({ ...base, kind: "question", content: `Asked: ${firstSentence(msg)}`, signals: { why: RX.why.test(lower) }, salience: 0.3 });

  // A correction message often QUOTES the belief being rejected ("I don't prefer
  // concrete examples"). Treat nothing in it as fresh preference/self-report evidence.
  const filtered = isCorrection ? obs.filter((o) => !["request", "self_report", "statement", "context"].includes(o.kind)) : obs;

  return {
    observations: filtered,
    prevTurnOutcome,
    // An explicit request inside a correction still shapes THIS reply; it just
    // isn't stored as preference evidence (observations were filtered above).
    requestedStrategy,
    requestedDepth,
    isCorrection,
    correctionText: isCorrection ? msg : null,
    isTopicSwitch,
    domain,
    concepts,
    isQuestion,
    goal,
    hasCode,
    attempt,
  };
}

/** How did the learner react to the previous assistant turn? (cheap, deterministic) */
export function detectOutcome(message: string, hadAssistantTurn: boolean, neutralContext = false): { label: OutcomeLabel; score: number } | null {
  if (!hadAssistantTurn) return null;
  const lower = message.toLowerCase();
  const attempt: "success" | "fail" | null = RX.attemptSuccess.test(lower) ? "success" : RX.attemptFail.test(lower) ? "fail" : null;
  if (RX.disagree.test(lower)) return { label: "disagreed", score: -0.4 };
  if (attempt === "success") return { label: "succeeded", score: 1 };
  if (attempt === "fail") return { label: "failed", score: -0.6 };
  if (RX.confused.test(lower)) return { label: "confused", score: -0.8 };
  if (RX.understood.test(lower)) return { label: "understood", score: 0.9 };
  if (neutralContext || RX.switchAway.test(lower) || RX.goal.test(message)) return { label: "neutral", score: 0 };
  return { label: "unknown", score: 0 };
}

export function slug(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 60);
}

export function firstSentence(s: string): string {
  const t = s.replace(/\s+/g, " ").trim();
  const m = t.match(/^(.{0,140}?[.!?])(\s|$)/);
  return (m ? m[1] : t.slice(0, 140)).trim();
}
