import type { LLMProvider, TurnContext, TurnOutput, Strategy, Depth, ExtractedObservation, OutcomeLabel } from "@/lib/types";
import { STRATEGIES, DEPTHS } from "@/lib/types";
import { heuristicExtract } from "./heuristics";
import { pickCorrectionTarget } from "./offline";

const OBS_KINDS = new Set(["statement", "question", "self_report", "success", "mistake", "reaction", "request", "topic_switch", "correction", "code_shared", "context"]);
const OUTCOMES = new Set<OutcomeLabel>(["understood", "partially", "confused", "disagreed", "succeeded", "failed", "neutral", "unknown"]);

function fmtDate(d: Date, now: Date): string {
  const days = Math.round((now.getTime() - d.getTime()) / 86400000);
  if (days <= 0) return "today";
  if (days === 1) return "yesterday";
  if (days < 30) return `${days} days ago`;
  return `${Math.round(days / 30)} months ago`;
}

export function renderContext(ctx: TurnContext): string {
  const lines: string[] = [];
  if (ctx.isNewSession) {
    lines.push(`SESSION: new session${ctx.gapMinutes != null ? ` after a gap of ${Math.round(ctx.gapMinutes / 60)} hours` : " (first ever)"}.`);
    if (ctx.previousSessionSummaries.length) {
      lines.push("PREVIOUS SESSIONS (most recent first):");
      for (const s of ctx.previousSessionSummaries.slice(0, 4)) lines.push(`- (${fmtDate(s.endedAt, ctx.now)}) ${s.summary}`);
    }
  }
  const active = ctx.beliefs.filter((b) => b.status === "active" || b.status === "contested");
  const weak = ctx.beliefs.filter((b) => b.status === "candidate" || b.status === "dormant");
  if (active.length) {
    lines.push("WHAT I BELIEVE ABOUT THIS LEARNER (priors — weigh against what they do right now; they can be wrong):");
    for (const b of active) {
      lines.push(`- [${b.id}] (${b.kind}${b.domain ? `, ${b.domain}` : ""}; ${b.source}; conf ${b.confidence.toFixed(2)}; ${b.supportCount} for / ${b.contradictionCount} against; ${b.status}${b.status === "contested" ? " — conflicting recent evidence" : ""}; last confirmed ${fmtDate(b.lastConfirmedAt, ctx.now)}) ${b.statement}`);
    }
  }
  if (weak.length) {
    lines.push("WEAK / UNCONFIRMED HUNCHES (do NOT act on these as if true; may be confirmed or refuted by this turn):");
    for (const b of weak.slice(0, 8)) lines.push(`- [${b.id}] (${b.kind}, ${b.status}) ${b.statement}`);
  }
  if (ctx.conceptStates.length) {
    lines.push("CONCEPT EVIDENCE (behaviour-based estimate vs self-report):");
    for (const c of ctx.conceptStates.slice(0, 12)) {
      const disc = c.selfReport != null ? ` self-report ${c.selfReport > 0 ? "confident" : "unsure"}` : "";
      lines.push(`- ${c.concept}${c.domain ? ` (${c.domain})` : ""}: p(known)=${c.pKnown.toFixed(2)} from ${c.successes} ok / ${c.mistakes} mistakes;${disc}; last seen ${fmtDate(c.lastSeenAt, ctx.now)}`);
    }
  }
  if (ctx.strategyStats.length) {
    lines.push("WHAT HAS WORKED (strategy → mean outcome in [-1,1], n):");
    for (const s of ctx.strategyStats.slice(0, 8)) lines.push(`- ${s.strategy}${s.domain ? ` in ${s.domain}` : " (overall)"}: ${s.mean.toFixed(2)} (n=${s.n})`);
  }
  if (ctx.recentObservations.length) {
    lines.push("RECENT RAW OBSERVATIONS (lightly interpreted evidence):");
    for (const o of ctx.recentObservations.slice(0, 10)) lines.push(`- (${o.kind}, ${fmtDate(o.createdAt, ctx.now)}) ${o.content}`);
  }
  if (ctx.researchNotes.length) {
    lines.push("RESEARCH NOTES AVAILABLE:");
    for (const n of ctx.researchNotes) lines.push(`- ${n.topic}: ${n.content.slice(0, 600)}`);
  }
  lines.push(`RECOMMENDED APPROACH: strategy=${ctx.recommendedStrategy}, depth=${ctx.recommendedDepth} (${ctx.strategyReason}). You may override it when the learner's message clearly calls for something else — say why in strategyOverrideReason.`);
  lines.push(ctx.probeAllowed && ctx.probeSuggestion
    ? `PROBING: You MAY include at most one light, natural check about "${ctx.probeSuggestion.concept}" (${ctx.probeSuggestion.reason}) if it fits; never turn the reply into a quiz.`
    : "PROBING: Do not add diagnostic questions this turn; just help.");
  return lines.join("\n");
}

const SYSTEM = `You are a single, continuous personal tutor with a long-term relationship with one learner. Behind the scenes you keep an evidence-based model of them; they never need to manage it.

Principles:
- Respond naturally to what the learner actually wrote. Follow their lead: topic switches, disagreement, pasted code, tangents are all fine.
- Use the learner model as a PRIOR, not a verdict. If their current behaviour contradicts a belief, trust the behaviour and report it in beliefFeedback.
- Do not over-diagnose. Never ask more than one checking question, and only when it is allowed and useful.
- If the learner corrects something about themselves ("that's not true about me"), accept it gracefully, and report it in learnerCorrection.
- Never mention internal machinery (beliefs, confidence, strategies, memory systems). Speak like a thoughtful human tutor.
- If you genuinely lack knowledge on a niche topic, still answer as best you can and set researchRequest.

Return ONLY a JSON object with this exact shape:
{
 "reply": string,
 "strategy": one of ${JSON.stringify(STRATEGIES)},
 "depth": one of ${JSON.stringify(DEPTHS)},
 "domain": string|null (short lowercase domain like "bash", "oop", "statistics"),
 "concepts": string[] (2-6 short lowercase concept names actually involved),
 "observations": [{"kind": one of ["statement","question","self_report","success","mistake","reaction","request","topic_switch","correction","code_shared","context"], "content": string (concrete, evidence-like, no psychological labels), "concepts": string[], "domain": string|null, "signals": object (for request: {"key":"pref:<worked_example|analogy|socratic|step_by_step|hands_on_task|direct_explanation|brief|deep>"}; for self_report: {"level": -1..1}; for success/mistake: {"polarity": 1|-1}; for statement about a goal: {"key":"goal:<slug>","goal":string}; for context: {"key":"ctx:<slug>"}), "salience": 0..1}],
 "prevTurnOutcome": {"label": one of ["understood","partially","confused","disagreed","succeeded","failed","neutral","unknown"], "score": -1..1} | null  (how the learner responded to YOUR previous message; null if there was none),
 "beliefFeedback": [{"beliefId": string, "polarity": "supports"|"contradicts", "note": string}],
 "learnerCorrection": {"beliefId": string|null, "statement": string, "replacement": string|null} | null,
 "probe": {"concept": string, "reason": string} | null,
 "researchRequest": {"topic": string, "reason": string} | null,
 "strategyOverrideReason": string|null
}`;

export class OpenAIProvider implements LLMProvider {
  readonly name: string;
  private apiKey: string;
  private baseUrl: string;
  private model: string;

  constructor(opts?: { apiKey?: string; baseUrl?: string; model?: string }) {
    this.apiKey = opts?.apiKey ?? process.env.OPENAI_API_KEY ?? "";
    this.baseUrl = (opts?.baseUrl ?? process.env.OPENAI_BASE_URL ?? "https://api.openai.com/v1").replace(/\/$/, "");
    this.model = opts?.model ?? process.env.OPENAI_MODEL ?? "gpt-4o-mini";
    this.name = `openai:${this.model}`;
  }

  private async chat(messages: { role: string; content: string }[], json = true): Promise<string> {
    const res = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${this.apiKey}` },
      body: JSON.stringify({
        model: this.model,
        messages,
        temperature: 0.4,
        ...(json ? { response_format: { type: "json_object" } } : {}),
      }),
    });
    if (!res.ok) throw new Error(`LLM error ${res.status}: ${(await res.text()).slice(0, 300)}`);
    const data = (await res.json()) as { choices: { message: { content: string } }[] };
    return data.choices[0]?.message?.content ?? "";
  }

  async turn({ userMessage, context }: { userMessage: string; context: TurnContext }): Promise<TurnOutput> {
    const h = heuristicExtract(userMessage, context);
    const history = context.recentMessages.slice(-16).map((m) => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.content }));
    const messages = [
      { role: "system", content: SYSTEM },
      { role: "system", content: `LEARNER MODEL CONTEXT (today is ${context.now.toISOString().slice(0, 10)}):\n${renderContext(context)}` },
      ...history,
      { role: "user", content: userMessage },
    ];
    const raw = await this.chat(messages);
    let parsed: Partial<TurnOutput> = {};
    try {
      parsed = JSON.parse(raw) as Partial<TurnOutput>;
    } catch {
      const m = raw.match(/\{[\s\S]*\}/);
      try {
        parsed = m ? (JSON.parse(m[0]) as Partial<TurnOutput>) : {};
      } catch {
        parsed = {};
      }
      // Prose (not broken JSON) is still a usable reply.
      if (!parsed.reply && raw.trim() && !raw.trim().startsWith("{")) parsed.reply = raw.trim();
    }
    return this.normalize(parsed, h, context, userMessage);
  }

  private normalize(p: Partial<TurnOutput>, h: ReturnType<typeof heuristicExtract>, context: TurnContext, userMessage: string): TurnOutput {
    const strategy = (STRATEGIES as readonly string[]).includes(p.strategy as string) ? (p.strategy as Strategy) : h.requestedStrategy ?? context.recommendedStrategy;
    const depth = (DEPTHS as readonly string[]).includes(p.depth as string) ? (p.depth as Depth) : h.requestedDepth ?? context.recommendedDepth;
    const domain = typeof p.domain === "string" && p.domain ? p.domain.toLowerCase().trim().replace(/\s+/g, "_") : h.domain;
    const concepts = Array.isArray(p.concepts) ? p.concepts.filter((c): c is string => typeof c === "string").map((c) => c.toLowerCase().trim()).slice(0, 6) : h.concepts;

    const seen = new Set<string>();
    const observations: ExtractedObservation[] = [];
    const push = (o: ExtractedObservation) => {
      const k = `${o.kind}|${o.content.toLowerCase().slice(0, 60)}`;
      if (seen.has(k)) return;
      seen.add(k);
      observations.push(o);
    };
    const correcting = h.isCorrection || !!p.learnerCorrection;
    if (Array.isArray(p.observations)) {
      for (const o of p.observations) {
        if (!o || typeof o !== "object" || !OBS_KINDS.has(String(o.kind)) || typeof o.content !== "string") continue;
        if (correcting && ["request", "self_report", "statement", "context"].includes(String(o.kind))) continue;
        push({
          kind: o.kind,
          content: o.content.slice(0, 300),
          concepts: Array.isArray(o.concepts) ? o.concepts.filter((c): c is string => typeof c === "string").slice(0, 6) : concepts,
          domain: typeof o.domain === "string" ? o.domain : domain,
          signals: o.signals && typeof o.signals === "object" ? (o.signals as Record<string, unknown>) : {},
          salience: typeof o.salience === "number" ? Math.max(0, Math.min(1, o.salience)) : 0.5,
        });
      }
    }
    // Safety net: high-stakes deterministic signals must never be dropped.
    const llmKinds = new Set(observations.map((o) => o.kind));
    for (const o of h.observations) {
      if (["statement", "correction", "request", "topic_switch"].includes(o.kind) && !llmKinds.has(o.kind)) push(o);
      if ((o.kind === "success" || o.kind === "mistake") && !llmKinds.has("success") && !llmKinds.has("mistake")) push(o);
      if (o.kind === "self_report" && !llmKinds.has("self_report")) push(o);
    }

    let prevTurnOutcome: TurnOutput["prevTurnOutcome"] = null;
    if (p.prevTurnOutcome && OUTCOMES.has(p.prevTurnOutcome.label)) {
      prevTurnOutcome = { label: p.prevTurnOutcome.label, score: Math.max(-1, Math.min(1, Number(p.prevTurnOutcome.score) || 0)) };
    } else prevTurnOutcome = h.prevTurnOutcome;
    // Strong deterministic signals override a vague model judgement.
    if (h.prevTurnOutcome && ["confused", "succeeded", "failed", "disagreed"].includes(h.prevTurnOutcome.label) && (!prevTurnOutcome || prevTurnOutcome.label === "unknown" || prevTurnOutcome.label === "neutral")) prevTurnOutcome = h.prevTurnOutcome;

    const validIds = new Set(context.beliefs.map((b) => b.id));
    const beliefFeedback = Array.isArray(p.beliefFeedback)
      ? p.beliefFeedback.filter((f) => f && validIds.has(f.beliefId) && (f.polarity === "supports" || f.polarity === "contradicts")).map((f) => ({ beliefId: f.beliefId, polarity: f.polarity, note: String(f.note ?? "") }))
      : [];

    let learnerCorrection: TurnOutput["learnerCorrection"] = null;
    if (p.learnerCorrection && typeof p.learnerCorrection.statement === "string") {
      learnerCorrection = {
        beliefId: p.learnerCorrection.beliefId && validIds.has(p.learnerCorrection.beliefId) ? p.learnerCorrection.beliefId : null,
        statement: p.learnerCorrection.statement,
        replacement: typeof p.learnerCorrection.replacement === "string" ? p.learnerCorrection.replacement : null,
      };
    }
    if (!learnerCorrection && h.isCorrection) {
      const t = pickCorrectionTarget(userMessage, context);
      learnerCorrection = { beliefId: t?.id ?? null, statement: userMessage, replacement: null };
    }
    if (learnerCorrection && !learnerCorrection.beliefId) {
      const t = pickCorrectionTarget(learnerCorrection.statement, context);
      if (t) learnerCorrection.beliefId = t.id;
    }

    const probe = context.probeAllowed && p.probe && typeof p.probe.concept === "string" ? { concept: p.probe.concept, reason: String(p.probe.reason ?? "") } : null;
    const researchRequest = p.researchRequest && typeof p.researchRequest.topic === "string" ? { topic: p.researchRequest.topic, reason: String(p.researchRequest.reason ?? "") } : null;

    return {
      reply: typeof p.reply === "string" && p.reply.trim() ? p.reply : "Let me think about that with you — could you say a little more about what you're after?",
      strategy,
      depth,
      domain,
      concepts,
      observations,
      prevTurnOutcome,
      beliefFeedback,
      learnerCorrection,
      probe,
      researchRequest,
      strategyOverrideReason: typeof p.strategyOverrideReason === "string" ? p.strategyOverrideReason : null,
    };
  }

  async summarizeSession(messages: { role: string; content: string }[]): Promise<string> {
    const text = messages.map((m) => `${m.role}: ${m.content.slice(0, 400)}`).join("\n").slice(0, 8000);
    const out = await this.chat([
      { role: "system", content: "Summarize this tutoring session in 2-3 sentences for the tutor's own memory: topics, what the learner struggled with or succeeded at, and any explicit requests. Plain text." },
      { role: "user", content: text },
    ], false);
    return out.trim().slice(0, 600);
  }

  async reconcileBelief(input: { candidate: { kind: string; statement: string; domain: string | null }; existing: { id: string; statement: string; kind: string; domain: string | null; status: string }[] }): Promise<{ action: "add" | "support" | "contradict" | "noop"; beliefId: string | null }> {
    if (!input.existing.length) return { action: "add", beliefId: null };
    const raw = await this.chat([
      { role: "system", content: `You maintain a learner model. Given a NEW candidate belief and EXISTING beliefs, decide: "support" if an existing belief says the same thing (return its id), "contradict" if an existing belief in the same scope says the opposite (return its id), "add" if it is genuinely new information, "noop" if it is trivial/not worth storing. Keep scope in mind: a preference in one domain does not contradict a different preference in another domain. Return JSON {"action":..., "beliefId": string|null}.` },
      { role: "user", content: JSON.stringify(input) },
    ]);
    try {
      const p = JSON.parse(raw) as { action?: string; beliefId?: string | null };
      const action = ["add", "support", "contradict", "noop"].includes(p.action ?? "") ? (p.action as "add" | "support" | "contradict" | "noop") : "add";
      const beliefId = p.beliefId && input.existing.some((e) => e.id === p.beliefId) ? p.beliefId : null;
      return { action: action !== "add" && action !== "noop" && !beliefId ? "add" : action, beliefId };
    } catch {
      return { action: "add", beliefId: null };
    }
  }
}

export function createProvider(): LLMProvider {
  if (process.env.OPENAI_API_KEY) return new OpenAIProvider();
  return new OfflineProviderLazy();
}

// Avoid a circular import at module-eval time.
import { OfflineProvider } from "./offline";
class OfflineProviderLazy extends OfflineProvider {}
