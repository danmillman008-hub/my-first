import type { LLMProvider, Strategy, TurnContext, TurnOutput, Depth } from "@/lib/types";
import { heuristicExtract, firstSentence } from "./heuristics";

// ---------------------------------------------------------------------------
// Offline provider: a deterministic stand-in for the model. It makes the app
// usable without an API key and lets the evaluation harness exercise the
// memory / adaptation machinery at scale with reproducible behaviour.
// ---------------------------------------------------------------------------

function topic(ctx: TurnContext, domain: string | null, concepts: string[]): string {
  if (concepts.length) return concepts[0];
  if (domain) return domain.replace(/_/g, " ");
  return "this";
}

function render(strategy: Strategy, depth: Depth, t: string, opts: { probe: string | null; welcomeBack: string | null; correctionAck: string | null; disagreedAck: string | null }): string {
  const parts: string[] = [];
  if (opts.welcomeBack) parts.push(opts.welcomeBack);
  if (opts.correctionAck) parts.push(opts.correctionAck);
  if (opts.disagreedAck) parts.push(opts.disagreedAck);
  const body: Record<Strategy, string> = {
    direct_explanation: `Here's the core idea of ${t}: it exists to solve one specific problem, and once you see that problem the mechanics follow naturally.`,
    worked_example: `Let me show ${t} with a concrete example you can run:\n\n\`\`\`\n# example demonstrating ${t}\n\`\`\`\n\nNotice what changes at each line — that's where ${t} does its work.`,
    analogy: `Think of ${t} like a kitchen assembly line: each station does one job and hands the result to the next. That's the whole idea of ${t}.`,
    socratic: `Before I explain ${t} — what do you expect to happen here, and why? Your guess will tell us exactly which piece to focus on.`,
    step_by_step: `Let's take ${t} one step at a time.\n1. Start with the simplest case.\n2. Add one moving part.\n3. Check the result before continuing.`,
    hands_on_task: `Quick task for ${t}: write the smallest possible version yourself, run it, and paste what you get. We'll build from what actually happens.`,
  };
  parts.push(body[strategy]);
  if (depth === "deep") parts.push(`Going deeper: the reason ${t} behaves this way comes down to how it is evaluated internally, and there are two edge cases worth knowing.`);
  if (depth === "brief") parts[parts.length - 1] = firstSentence(parts[parts.length - 1]);
  if (opts.probe) parts.push(opts.probe);
  return parts.join("\n\n");
}

export class OfflineProvider implements LLMProvider {
  readonly name = "offline";

  async turn({ userMessage, context }: { userMessage: string; context: TurnContext }): Promise<TurnOutput> {
    const h = heuristicExtract(userMessage, context);
    const strategy: Strategy = h.requestedStrategy ?? context.recommendedStrategy;
    const depth: Depth = h.requestedDepth ?? context.recommendedDepth;
    const t = topic(context, h.domain, h.concepts);

    const welcomeBack = context.isNewSession && context.previousSessionSummaries.length
      ? `Welcome back${context.gapMinutes && context.gapMinutes > 60 * 24 ? " — it's been a while" : ""}. Last time: ${firstSentence(context.previousSessionSummaries[0].summary)}`
      : null;

    let correctionAck: string | null = null;
    let learnerCorrection: TurnOutput["learnerCorrection"] = null;
    if (h.isCorrection) {
      // Find the most influential belief that plausibly relates to the correction.
      const target = pickCorrectionTarget(userMessage, context);
      correctionAck = target
        ? `Thanks for correcting me — I'll stop assuming "${target.statement}".`
        : "Thanks for correcting me — I've noted that.";
      learnerCorrection = { beliefId: target?.id ?? null, statement: userMessage, replacement: null };
    }

    const disagreedAck = h.prevTurnOutcome?.label === "disagreed"
      ? "Fair pushback — let me approach it differently rather than repeat myself."
      : null;

    const probe = context.probeAllowed && context.probeSuggestion && !h.isCorrection && !h.isTopicSwitch && !h.goal
      ? `Quick check so I pitch this right: can you tell me in one line what ${context.probeSuggestion.concept} does?`
      : null;

    return {
      reply: render(strategy, depth, t, { probe, welcomeBack, correctionAck, disagreedAck }),
      strategy,
      depth,
      domain: h.domain,
      concepts: h.concepts,
      observations: h.observations,
      prevTurnOutcome: h.prevTurnOutcome,
      beliefFeedback: [],
      learnerCorrection,
      probe: probe && context.probeSuggestion ? { concept: context.probeSuggestion.concept, reason: context.probeSuggestion.reason } : null,
      researchRequest: null,
      strategyOverrideReason: h.requestedStrategy ? "learner explicitly requested this format" : null,
    };
  }

  async summarizeSession(messages: { role: string; content: string }[]): Promise<string> {
    const user = messages.filter((m) => m.role === "user").map((m) => firstSentence(m.content));
    if (!user.length) return "Short session with no learner messages.";
    return `Discussed: ${user.slice(0, 4).join(" · ")}${user.length > 4 ? ` (+${user.length - 4} more)` : ""}`;
  }

  async reconcileBelief(): Promise<{ action: "add" | "support" | "contradict" | "noop"; beliefId: string | null }> {
    // Offline: key-based matching happens in the consolidator; here we only add.
    return { action: "add", beliefId: null };
  }
}

const STOP = new Set(["that", "this", "true", "about", "with", "what", "when", "have", "they", "them", "just", "your", "very", "than", "then", "there", "their", "from", "into", "over", "more", "most", "some", "such", "only", "also", "been", "does", "don't", "dont", "doesn", "really", "actually", "never", "said", "think", "like", "learner", "prefers", "prefer", "works", "well", "explanation"]);
const stem = (w: string) => w.replace(/'s?$/, "");
const wordsMatch = (a: string, b: string) => a === b || (a.length >= 5 && b.startsWith(a)) || (b.length >= 5 && a.startsWith(b));

export function pickCorrectionTarget(userMessage: string, context: TurnContext) {
  const lower = userMessage.toLowerCase();
  const words = new Set(lower.split(/[^a-z0-9']+/).filter((w) => w.length > 3 && !STOP.has(w)).map(stem));
  let best: TurnContext["beliefs"][number] | null = null;
  let bestScore = 0;
  for (const b of context.beliefs) {
    if (b.status === "retired") continue;
    const keyTail = (b.key ?? "").split(":").pop()?.split("_") ?? [];
    const bw = [...b.statement.toLowerCase().split(/[^a-z0-9']+/), ...keyTail].filter((w) => w.length > 3 && !STOP.has(w)).map(stem);
    let overlap = 0;
    for (const w of new Set(bw)) if ([...words].some((u) => wordsMatch(u, w))) overlap++;
    const score = overlap + (b.influence ?? 0) * 0.5;
    // Require a real textual match: retiring the wrong belief is worse than
    // recording the correction without a target.
    if (overlap >= 2 && score > bestScore) {
      bestScore = score;
      best = b;
    }
  }
  return best;
}
