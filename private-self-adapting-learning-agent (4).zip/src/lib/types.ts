import type { ObservationKind, BeliefKind, BeliefStatus } from "@/db/schema";

export type { ObservationKind, BeliefKind, BeliefStatus };

export const STRATEGIES = [
  "direct_explanation",
  "worked_example",
  "analogy",
  "socratic",
  "step_by_step",
  "hands_on_task",
] as const;
export type Strategy = (typeof STRATEGIES)[number];

export const DEPTHS = ["brief", "standard", "deep"] as const;
export type Depth = (typeof DEPTHS)[number];

export type OutcomeLabel =
  | "understood"
  | "partially"
  | "confused"
  | "disagreed"
  | "succeeded"
  | "failed"
  | "neutral"
  | "unknown";

export interface ExtractedObservation {
  kind: ObservationKind;
  content: string;
  concepts: string[];
  domain: string | null;
  /** Light structured hints; NOT conclusions. e.g. { key: "pref:shorter" }, { polarity: -1 } */
  signals: Record<string, unknown>;
  salience: number;
}

export interface BeliefView {
  id: string;
  kind: BeliefKind;
  key: string | null;
  statement: string;
  domain: string | null;
  concepts: string[];
  source: string;
  status: BeliefStatus;
  confidence: number;
  supportCount: number;
  contradictionCount: number;
  distinctSessions: number;
  lastConfirmedAt: Date;
  validFrom: Date;
  invalidAt: Date | null;
  invalidReason: string | null;
  /** Retrieval-time influence in [0,1] combining confidence, recency, scope match */
  influence?: number;
}

export interface ConceptStateView {
  concept: string;
  domain: string | null;
  pKnown: number;
  attempts: number;
  successes: number;
  mistakes: number;
  selfReport: number | null;
  exposures: number;
  lastSeenAt: Date;
}

export interface StrategyStat {
  strategy: Strategy;
  domain: string | null;
  n: number;
  mean: number;
}

export interface TurnContext {
  learnerId: string;
  sessionId: string;
  now: Date;
  isNewSession: boolean;
  gapMinutes: number | null;
  recentMessages: { role: string; content: string; meta: Record<string, unknown>; createdAt: Date }[];
  previousSessionSummaries: { summary: string; endedAt: Date }[];
  beliefs: BeliefView[];
  conceptStates: ConceptStateView[];
  recentObservations: { kind: string; content: string; domain: string | null; createdAt: Date }[];
  strategyStats: StrategyStat[];
  recommendedStrategy: Strategy;
  recommendedDepth: Depth;
  strategyReason: string;
  probeAllowed: boolean;
  probeSuggestion: { concept: string; reason: string } | null;
  lastAssistantMeta: Record<string, unknown> | null;
  researchNotes: { topic: string; content: string; sources: { title: string; url: string }[] }[];
  currentDomainGuess: string | null;
}

export interface TurnOutput {
  reply: string;
  strategy: Strategy;
  depth: Depth;
  domain: string | null;
  concepts: string[];
  observations: ExtractedObservation[];
  /** Judgement of how the learner responded to the PREVIOUS assistant turn */
  prevTurnOutcome: { label: OutcomeLabel; score: number } | null;
  beliefFeedback: { beliefId: string; polarity: "supports" | "contradicts"; note: string }[];
  learnerCorrection: { beliefId: string | null; statement: string; replacement: string | null } | null;
  probe: { concept: string; reason: string } | null;
  researchRequest: { topic: string; reason: string } | null;
  strategyOverrideReason: string | null;
}

export interface LLMProvider {
  readonly name: string;
  turn(input: { userMessage: string; context: TurnContext }): Promise<TurnOutput>;
  summarizeSession(messages: { role: string; content: string }[]): Promise<string>;
  /** Merge a new candidate belief statement against existing ones. */
  reconcileBelief(input: {
    candidate: { kind: string; statement: string; domain: string | null };
    existing: { id: string; statement: string; kind: string; domain: string | null; status: string }[];
  }): Promise<{ action: "add" | "support" | "contradict" | "noop"; beliefId: string | null }>;
}
