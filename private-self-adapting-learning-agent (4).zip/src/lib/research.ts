import { db } from "@/db";
import { and, eq } from "drizzle-orm";
import { researchNotes } from "@/db/schema";

// Open-domain research: the tutor is not limited to curated subjects. When a
// domain/topic is unfamiliar (no note yet) it gathers a grounding note from a
// free public source and caches it. Curated notes are a resource, not a cage —
// the model still decides what it needs and asks for more via researchRequest.

const KNOWN_DOMAINS = new Set(["bash", "oop", "python", "javascript", "sql", "statistics", "math", "git", "networking"]);

async function fetchJson(url: string, ms = 4000): Promise<unknown> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { "user-agent": "self-adapting-tutor/1.0 (research)" } });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

export async function researchTopic(topic: string, domain: string | null): Promise<{ topic: string; content: string; sources: { title: string; url: string }[] } | null> {
  const clean = topic.replace(/_/g, " ").trim();
  if (!clean) return null;
  const existing = await db.select().from(researchNotes).where(and(eq(researchNotes.topic, clean.toLowerCase()))).limit(1);
  if (existing[0]) return { topic: existing[0].topic, content: existing[0].content, sources: existing[0].sources };

  const search = (await fetchJson(`https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=3&srsearch=${encodeURIComponent(clean)}`)) as { query?: { search?: { title: string }[] } } | null;
  const titles = search?.query?.search?.map((s) => s.title) ?? [];
  const parts: string[] = [];
  const sources: { title: string; url: string }[] = [];
  for (const title of titles.slice(0, 2)) {
    const sum = (await fetchJson(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`)) as { extract?: string; content_urls?: { desktop?: { page?: string } } } | null;
    if (sum?.extract) {
      parts.push(`${title}: ${sum.extract}`);
      sources.push({ title, url: sum.content_urls?.desktop?.page ?? `https://en.wikipedia.org/wiki/${encodeURIComponent(title)}` });
    }
  }
  if (!parts.length) return null;
  const note = { topic: clean.toLowerCase(), content: parts.join("\n\n").slice(0, 2400), sources };
  await db.insert(researchNotes).values({ id: `rn_${crypto.randomUUID()}`, topic: note.topic, domain, content: note.content, sources });
  return note;
}

/** Pre-turn: research an unfamiliar domain once so the tutor is grounded. */
export async function ensureDomainGrounding(domain: string | null): Promise<boolean> {
  if (!domain || KNOWN_DOMAINS.has(domain)) return false;
  const existing = await db.select({ id: researchNotes.id }).from(researchNotes).where(eq(researchNotes.domain, domain)).limit(1);
  if (existing[0]) return false;
  const note = await researchTopic(domain, domain);
  return !!note;
}
