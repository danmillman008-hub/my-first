import {
  pgTable,
  text,
  timestamp,
  integer,
  real,
  jsonb,
  boolean,
  index,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// Learners & conversation (one continuous relationship, grouped into sessions
// only by time gaps — the learner never "starts a lesson").
// ---------------------------------------------------------------------------

export const learners = pgTable("learners", {
  id: text("id").primaryKey(),
  name: text("name").notNull().default("Learner"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }).notNull().defaultNow(),
    summary: text("summary"),
    turnCount: integer("turn_count").notNull().default(0),
  },
  (t) => [index("sessions_learner_idx").on(t.learnerId, t.lastActiveAt)],
);

export const messages = pgTable(
  "messages",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id").notNull(),
    role: text("role").notNull(), // 'user' | 'assistant'
    content: text("content").notNull(),
    // For assistant turns: which strategy/depth/etc. were used and why.
    meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("messages_learner_idx").on(t.learnerId, t.createdAt)],
);

// ---------------------------------------------------------------------------
// SHORT-TERM / WORKING MEMORY: observations.
// Broad, recent, lightly interpreted evidence. Never deleted. An observation
// is allowed to stay "just an observation" forever.
// ---------------------------------------------------------------------------

export type ObservationKind =
  | "statement" // learner said something about themselves/goals
  | "question"
  | "self_report" // "I understand" / "I'm bad at this"
  | "success" // demonstrated correct understanding / working code
  | "mistake" // demonstrated error / misconception
  | "reaction" // confusion, satisfaction, disagreement, boredom
  | "request" // asked for a style: "shorter", "give me an example"
  | "topic_switch"
  | "correction" // learner corrected the tutor's memory
  | "code_shared"
  | "context"; // situational: deadline, device, time of day, etc.

export const observations = pgTable(
  "observations",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id").notNull(),
    messageId: text("message_id"),
    kind: text("kind").$type<ObservationKind>().notNull(),
    content: text("content").notNull(),
    concepts: jsonb("concepts").$type<string[]>().notNull().default([]),
    domain: text("domain"), // e.g. "bash", "oop", "statistics"
    // Light structured hints that the consolidator may use. Not conclusions.
    signals: jsonb("signals").$type<Record<string, unknown>>().notNull().default({}),
    salience: real("salience").notNull().default(0.5),
    dedupeKey: text("dedupe_key"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("observations_learner_idx").on(t.learnerId, t.createdAt),
    index("observations_dedupe_idx").on(t.learnerId, t.dedupeKey),
  ],
);

// ---------------------------------------------------------------------------
// LONG-TERM MEMORY: beliefs.
// Claims that earned durability through evidence. A belief is a PRIOR, never a
// verdict: it carries confidence, scope, support & contradiction counts, a
// lifecycle status, and links to the observations that produced it.
// ---------------------------------------------------------------------------

export type BeliefKind =
  | "goal" // learner-stated objective (stated goals are facts, not hypotheses)
  | "preference" // explanation style, format, pacing
  | "tendency" // recurring behavioural pattern
  | "knowledge" // durable statement about what learner knows / struggles with
  | "context" // durable situational fact (job, background, tools they use)
  | "strategy_fit"; // "worked examples work well for this learner in bash"

export type BeliefStatus =
  | "candidate" // one supporting observation; not yet influential
  | "active" // enough independent support; influences behaviour
  | "contested" // active but has recent contradicting evidence
  | "dormant" // not confirmed for a long time; low influence, recoverable
  | "retired"; // invalidated (learner correction or strong contradiction)

export const beliefs = pgTable(
  "beliefs",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    kind: text("kind").$type<BeliefKind>().notNull(),
    // Normalized semantic key (e.g. "pref:worked_example", "goal:learn_bash").
    // Dedup is by (key, domain) so the same preference in two domains stays two
    // scoped beliefs instead of being collapsed into one context-free label.
    key: text("key"),
    statement: text("statement").notNull(),
    // Scope: where does this belief apply? null domain = general.
    domain: text("domain"),
    concepts: jsonb("concepts").$type<string[]>().notNull().default([]),
    source: text("source").notNull().default("inferred"), // 'stated' | 'inferred' | 'observed'
    status: text("status").$type<BeliefStatus>().notNull().default("candidate"),
    confidence: real("confidence").notNull().default(0.3),
    supportCount: integer("support_count").notNull().default(1),
    contradictionCount: integer("contradiction_count").notNull().default(0),
    distinctSessions: integer("distinct_sessions").notNull().default(1),
    validFrom: timestamp("valid_from", { withTimezone: true }).notNull().defaultNow(),
    invalidAt: timestamp("invalid_at", { withTimezone: true }),
    invalidReason: text("invalid_reason"),
    supersededBy: text("superseded_by"),
    lastConfirmedAt: timestamp("last_confirmed_at", { withTimezone: true }).notNull().defaultNow(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("beliefs_learner_idx").on(t.learnerId, t.status)],
);

export const beliefEvidence = pgTable(
  "belief_evidence",
  {
    id: text("id").primaryKey(),
    beliefId: text("belief_id").notNull(),
    observationId: text("observation_id").notNull(),
    polarity: text("polarity").notNull(), // 'supports' | 'contradicts'
    weight: real("weight").notNull().default(1),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("belief_evidence_belief_idx").on(t.beliefId)],
);

// ---------------------------------------------------------------------------
// CONCEPT STATES: behaviour-grounded knowledge tracing.
// Self-report and demonstrated behaviour are tracked separately so the tutor
// can see (and reconcile) the discrepancy instead of collapsing it.
// ---------------------------------------------------------------------------

export const conceptStates = pgTable(
  "concept_states",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    concept: text("concept").notNull(),
    domain: text("domain"),
    // Bayesian-knowledge-tracing-like probability that the learner "has" it.
    pKnown: real("p_known").notNull().default(0.2),
    attempts: integer("attempts").notNull().default(0),
    successes: integer("successes").notNull().default(0),
    mistakes: integer("mistakes").notNull().default(0),
    // Most recent self-report in [-1, 1]; null if none.
    selfReport: real("self_report"),
    exposures: integer("exposures").notNull().default(0),
    firstSeenAt: timestamp("first_seen_at", { withTimezone: true }).notNull().defaultNow(),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
    lastSuccessAt: timestamp("last_success_at", { withTimezone: true }),
    lastMistakeAt: timestamp("last_mistake_at", { withTimezone: true }),
  },
  (t) => [index("concept_states_learner_idx").on(t.learnerId, t.concept)],
);

// ---------------------------------------------------------------------------
// GRAPH: nodes & bi-temporal weighted edges.
// Nodes: concept | goal | pattern | strategy | domain
// Edges: e.g. concept -prerequisite_of-> concept, learner -struggles_with->,
//        strategy -works_for-> concept/domain, goal -requires-> concept ...
// Edges never get deleted; they get invalidated (invalid_at) and may be
// re-activated by fresh evidence.
// ---------------------------------------------------------------------------

export const graphNodes = pgTable(
  "graph_nodes",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    type: text("type").notNull(),
    key: text("key").notNull(), // normalized identifier e.g. "concept:bash/pipes"
    label: text("label").notNull(),
    attrs: jsonb("attrs").$type<Record<string, unknown>>().notNull().default({}),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("graph_nodes_learner_key_idx").on(t.learnerId, t.key)],
);

export const graphEdges = pgTable(
  "graph_edges",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    fromKey: text("from_key").notNull(),
    toKey: text("to_key").notNull(),
    relation: text("relation").notNull(),
    weight: real("weight").notNull().default(1),
    evidenceCount: integer("evidence_count").notNull().default(1),
    attrs: jsonb("attrs").$type<Record<string, unknown>>().notNull().default({}),
    validFrom: timestamp("valid_from", { withTimezone: true }).notNull().defaultNow(),
    invalidAt: timestamp("invalid_at", { withTimezone: true }),
    lastReinforcedAt: timestamp("last_reinforced_at", { withTimezone: true }).notNull().defaultNow(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("graph_edges_learner_idx").on(t.learnerId, t.fromKey, t.toKey)],
);

// ---------------------------------------------------------------------------
// STRATEGY OUTCOMES: "what actually works for this learner, in this context".
// Outcome is judged from the learner's *next* turn (understood / confused /
// disagreed / succeeded on task ...). Feeds a contextual Thompson-sampling
// selector with a global prior and per-domain posteriors.
// ---------------------------------------------------------------------------

export const strategyOutcomes = pgTable(
  "strategy_outcomes",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    strategy: text("strategy").notNull(),
    domain: text("domain"),
    concepts: jsonb("concepts").$type<string[]>().notNull().default([]),
    outcome: real("outcome").notNull(), // -1 .. 1
    outcomeLabel: text("outcome_label").notNull(),
    assistantMessageId: text("assistant_message_id"),
    observationId: text("observation_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("strategy_outcomes_learner_idx").on(t.learnerId, t.domain)],
);

// ---------------------------------------------------------------------------
// AGENT TRACES: every decision the agent made and why (inspectability).
// ---------------------------------------------------------------------------

export const agentTraces = pgTable(
  "agent_traces",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id").notNull(),
    messageId: text("message_id"),
    kind: text("kind").notNull(), // 'turn' | 'consolidation' | 'research' | 'probe' | 'correction'
    payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("agent_traces_learner_idx").on(t.learnerId, t.createdAt)],
);

// ---------------------------------------------------------------------------
// RESEARCH NOTES: open-domain knowledge gathered on demand (shared across
// learners; a resource, not a boundary).
// ---------------------------------------------------------------------------

export const researchNotes = pgTable(
  "research_notes",
  {
    id: text("id").primaryKey(),
    topic: text("topic").notNull(),
    domain: text("domain"),
    content: text("content").notNull(),
    sources: jsonb("sources").$type<{ title: string; url: string }[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("research_notes_topic_idx").on(t.topic)],
);
