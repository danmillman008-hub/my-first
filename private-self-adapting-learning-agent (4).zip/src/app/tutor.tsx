"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import MemoryPanel from "./memory-panel";

type Msg = { id: string; role: string; content: string; meta: Record<string, unknown>; sessionId: string; createdAt: string; pending?: boolean };
type Session = { id: string; startedAt: string; lastActiveAt: string; summary: string | null; turnCount: number };

function getLearnerId(): string {
  if (typeof window === "undefined") return "";
  const url = new URL(window.location.href);
  const fromUrl = url.searchParams.get("learner");
  if (fromUrl) { localStorage.setItem("learnerId", fromUrl); return fromUrl; }
  let id = localStorage.getItem("learnerId");
  if (!id) { id = `learner_${Math.random().toString(36).slice(2, 10)}`; localStorage.setItem("learnerId", id); }
  return id;
}

export default function Tutor() {
  const [learnerId, setLearnerId] = useState("");
  const [messages, setMessages] = useState<Msg[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [provider, setProvider] = useState("");
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [showMemory, setShowMemory] = useState(true);
  const [memoryTick, setMemoryTick] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { setLearnerId(getLearnerId()); }, []);

  const load = useCallback(async (id: string) => {
    const r = await fetch(`/api/chat?learnerId=${encodeURIComponent(id)}`);
    if (!r.ok) return;
    const d = await r.json();
    setMessages(d.messages);
    setSessions(d.sessions);
    setProvider(d.provider);
  }, []);

  useEffect(() => { if (learnerId) void load(learnerId); }, [learnerId, load]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages.length, busy]);

  const sessionStarts = useMemo(() => {
    const starts = new Map<string, Session>();
    for (const s of sessions) starts.set(s.id, s);
    return starts;
  }, [sessions]);

  async function send(text?: string) {
    const content = (text ?? input).trim();
    if (!content || busy || !learnerId) return;
    setInput("");
    setError(null);
    setBusy(true);
    const tempId = `tmp_${Date.now()}`;
    setMessages((m) => [...m, { id: tempId, role: "user", content, meta: {}, sessionId: "", createdAt: new Date().toISOString(), pending: true }]);
    try {
      const r = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ learnerId, message: content }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "request failed");
      await load(learnerId);
      setMemoryTick((t) => t + 1);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
      setMessages((m) => m.filter((x) => x.id !== tempId));
      setInput(content);
    } finally {
      setBusy(false);
    }
  }

  const starters = [
    "I want to learn Bash. How do pipes work?",
    "Why does `ls | grep foo` behave differently from `ls > grep`?",
    "Actually, forget Bash for a moment. Explain OOP to me.",
    "I disagree — that's not how inheritance works.",
  ];

  let lastSession = "";
  return (
    <div className="flex h-screen flex-col bg-[#f6f5f1] text-slate-900">
      <header className="flex items-center justify-between border-b border-slate-200 bg-white/80 px-5 py-3 backdrop-blur">
        <div className="flex items-baseline gap-3">
          <h1 className="text-lg font-semibold tracking-tight">Your tutor</h1>
          <span className="text-xs text-slate-500">one tutor · one continuous relationship</span>
        </div>
        <div className="flex items-center gap-3 text-xs text-slate-500">
          <span className="rounded-full bg-slate-100 px-2 py-0.5 font-mono" title="Model provider">{provider || "…"}</span>
          <span className="hidden font-mono sm:inline" title="Your learner id (share ?learner=… to continue elsewhere)">{learnerId}</span>
          <button onClick={() => setShowMemory((s) => !s)} className="rounded-md border border-slate-300 bg-white px-2.5 py-1 text-slate-700 hover:bg-slate-50">
            {showMemory ? "Hide" : "Show"} what I remember
          </button>
        </div>
      </header>

      <div className="flex min-h-0 flex-1">
        <main className="flex min-w-0 flex-1 flex-col">
          <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-8">
            <div className="mx-auto max-w-3xl space-y-4">
              {messages.length === 0 && (
                <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-600">
                  <p className="text-base font-medium text-slate-800">Just talk. Ask, paste code, switch topics, disagree, come back next week.</p>
                  <p className="mt-2">I keep an evidence-based picture of how you learn and adapt to it over time. You can inspect and correct it anytime in the panel on the right.</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {starters.map((s) => (
                      <button key={s} onClick={() => send(s)} className="rounded-full border border-slate-300 bg-white px-3 py-1 text-xs text-slate-700 hover:border-slate-400 hover:bg-slate-50">{s}</button>
                    ))}
                  </div>
                </div>
              )}
              {messages.map((m) => {
                const newSession = m.sessionId && m.sessionId !== lastSession;
                if (m.sessionId) lastSession = m.sessionId;
                const s = newSession ? sessionStarts.get(m.sessionId) : null;
                return (
                  <div key={m.id}>
                    {newSession && s && (
                      <div className="my-4 flex items-center gap-3 text-[11px] uppercase tracking-wide text-slate-400">
                        <div className="h-px flex-1 bg-slate-200" />
                        {new Date(s.startedAt).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}
                        <div className="h-px flex-1 bg-slate-200" />
                      </div>
                    )}
                    <div className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                      <div className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-[15px] leading-relaxed shadow-sm ${m.role === "user" ? "bg-slate-900 text-white" : "bg-white text-slate-800"} ${m.pending ? "opacity-60" : ""}`}>
                        {m.content}
                        {m.role === "assistant" && (m.meta?.strategy as string | undefined) && (
                          <div className="mt-2 flex flex-wrap gap-1.5 text-[10px] text-slate-400" title={String(m.meta.strategyReason ?? "")}>
                            <span className="rounded bg-slate-100 px-1.5 py-0.5">{String(m.meta.strategy).replace(/_/g, " ")}</span>
                            <span className="rounded bg-slate-100 px-1.5 py-0.5">{String(m.meta.depth)}</span>
                            {m.meta.domain ? <span className="rounded bg-slate-100 px-1.5 py-0.5">{String(m.meta.domain)}</span> : null}
                            {m.meta.probe ? <span className="rounded bg-amber-50 px-1.5 py-0.5 text-amber-700">checked understanding</span> : null}
                            {m.meta.strategyOverrideReason ? <span className="rounded bg-sky-50 px-1.5 py-0.5 text-sky-700">adapted: {String(m.meta.strategyOverrideReason)}</span> : null}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
              {busy && (
                <div className="flex justify-start"><div className="rounded-2xl bg-white px-4 py-3 text-sm text-slate-400 shadow-sm">thinking…</div></div>
              )}
              <div ref={bottomRef} />
            </div>
          </div>
          <form
            onSubmit={(e) => { e.preventDefault(); void send(); }}
            className="border-t border-slate-200 bg-white px-4 py-3 sm:px-8"
          >
            <div className="mx-auto flex max-w-3xl items-end gap-2">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void send(); } }}
                placeholder="Ask anything, paste code, or change the subject…"
                rows={Math.min(8, Math.max(1, input.split("\n").length))}
                className="flex-1 resize-none rounded-xl border border-slate-300 px-3 py-2 text-[15px] outline-none focus:border-slate-500"
              />
              <button type="submit" disabled={busy || !input.trim()} className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-40">Send</button>
            </div>
            {error && <p className="mx-auto mt-2 max-w-3xl text-xs text-red-600">{error}</p>}
          </form>
        </main>

        {showMemory && learnerId && (
          <aside className="hidden w-[420px] shrink-0 overflow-y-auto border-l border-slate-200 bg-white lg:block">
            <MemoryPanel learnerId={learnerId} tick={memoryTick} onChanged={() => setMemoryTick((t) => t + 1)} />
          </aside>
        )}
      </div>
    </div>
  );
}
