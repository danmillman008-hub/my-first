"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

type Belief = { id: string; kind: string; key: string | null; statement: string; domain: string | null; source: string; status: string; confidence: number; supportCount: number; contradictionCount: number; distinctSessions: number; lastConfirmedAt: string; validFrom: string; invalidAt: string | null; invalidReason: string | null; influence: number };
type ConceptState = { concept: string; domain: string | null; pKnown: number; attempts: number; successes: number; mistakes: number; selfReport: number | null; exposures: number; lastSeenAt: string };
type Obs = { id: string; kind: string; content: string; domain: string | null; createdAt: string };
type Stat = { strategy: string; domain: string | null; n: number; mean: number };
type Node = { id: string; type: string; key: string; label: string; active: boolean };
type Edge = { id: string; fromKey: string; toKey: string; relation: string; weight: number; evidenceCount: number; invalidAt: string | null };
type Memory = { beliefs: Belief[]; conceptStates: ConceptState[]; observations: Obs[]; strategyStats: Stat[]; graph: { nodes: Node[]; edges: Edge[] }; sessions: { id: string; startedAt: string; summary: string | null; turnCount: number }[] };
type Evidence = { polarity: string; weight: number; createdAt: string; observation: Obs | null };

const STATUS_STYLE: Record<string, string> = {
  active: "bg-emerald-50 text-emerald-700 border-emerald-200",
  contested: "bg-amber-50 text-amber-700 border-amber-200",
  candidate: "bg-slate-50 text-slate-500 border-slate-200",
  dormant: "bg-slate-50 text-slate-400 border-slate-200",
  retired: "bg-rose-50 text-rose-500 border-rose-200 line-through",
};

export default function MemoryPanel({ learnerId, tick, onChanged }: { learnerId: string; tick: number; onChanged: () => void }) {
  const [mem, setMem] = useState<Memory | null>(null);
  const [tab, setTab] = useState<"beliefs" | "concepts" | "evidence" | "graph">("beliefs");
  const [showHistory, setShowHistory] = useState(false);
  const [open, setOpen] = useState<string | null>(null);
  const [evidence, setEvidence] = useState<Record<string, Evidence[]>>({});
  const [challenge, setChallenge] = useState<{ id: string; note: string; replacement: string } | null>(null);

  const load = useCallback(async () => {
    const r = await fetch(`/api/memory?learnerId=${encodeURIComponent(learnerId)}`);
    if (r.ok) setMem(await r.json());
  }, [learnerId]);
  useEffect(() => { void load(); }, [load, tick]);

  async function openBelief(id: string) {
    setOpen((o) => (o === id ? null : id));
    if (!evidence[id]) {
      const r = await fetch(`/api/memory?learnerId=${encodeURIComponent(learnerId)}&beliefId=${id}`);
      if (r.ok) {
        const d = (await r.json()) as { evidence: Evidence[] };
        setEvidence((e) => ({ ...e, [id]: d.evidence }));
      }
    }
  }

  async function submitChallenge() {
    if (!challenge) return;
    await fetch("/api/memory", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ learnerId, beliefId: challenge.id, note: challenge.note, replacement: challenge.replacement || null }) });
    setChallenge(null);
    setEvidence({});
    onChanged();
    await load();
  }

  const beliefs = useMemo(() => {
    if (!mem) return [];
    const rows = showHistory ? mem.beliefs : mem.beliefs.filter((b) => b.status !== "retired");
    const order: Record<string, number> = { active: 0, contested: 1, candidate: 2, dormant: 3, retired: 4 };
    return [...rows].sort((a, b) => (order[a.status] ?? 9) - (order[b.status] ?? 9) || b.influence - a.influence);
  }, [mem, showHistory]);

  if (!mem) return <div className="p-5 text-sm text-slate-400">Loading memory…</div>;
  const active = mem.beliefs.filter((b) => b.status === "active" || b.status === "contested").length;

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-slate-200 px-5 pt-4">
        <h2 className="text-sm font-semibold text-slate-800">What I currently think helps you</h2>
        <p className="mt-1 text-xs text-slate-500">{active} working beliefs · {mem.observations.length}+ observations · {mem.graph.nodes.length} graph nodes. Everything here is revisable — tell me if something is wrong.</p>
        <div className="mt-3 flex gap-1 text-xs">
          {(["beliefs", "concepts", "evidence", "graph"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`rounded-t-md px-3 py-1.5 capitalize ${tab === t ? "bg-slate-100 font-medium text-slate-900" : "text-slate-500 hover:text-slate-800"}`}>{t}</button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 text-sm">
        {tab === "beliefs" && (
          <div className="space-y-2">
            {mem.strategyStats.filter((s) => s.n >= 2).slice(0, 4).length > 0 && (
              <div className="rounded-lg bg-slate-50 p-3 text-xs text-slate-600">
                <div className="mb-1 font-medium text-slate-700">What has worked so far</div>
                {mem.strategyStats.filter((s) => s.n >= 2).sort((a, b) => b.mean - a.mean).slice(0, 5).map((s) => (
                  <div key={`${s.strategy}${s.domain}`} className="flex justify-between"><span>{s.strategy.replace(/_/g, " ")}{s.domain ? ` · ${s.domain}` : " · overall"}</span><span className={s.mean > 0.2 ? "text-emerald-700" : s.mean < -0.2 ? "text-rose-600" : ""}>{s.mean > 0 ? "+" : ""}{s.mean.toFixed(2)} <span className="text-slate-400">(n={s.n})</span></span></div>
                ))}
              </div>
            )}
            <label className="flex items-center gap-2 text-xs text-slate-500"><input type="checkbox" checked={showHistory} onChange={(e) => setShowHistory(e.target.checked)} /> show retired history</label>
            {beliefs.length === 0 && <p className="text-xs text-slate-400">Nothing durable yet — beliefs earn their place through repeated evidence.</p>}
            {beliefs.map((b) => (
              <div key={b.id} className={`rounded-lg border p-3 ${b.status === "retired" ? "opacity-70" : ""} ${b.status === "candidate" || b.status === "dormant" ? "border-dashed" : ""} border-slate-200`}>
                <button onClick={() => openBelief(b.id)} className="w-full text-left">
                  <div className="flex items-start justify-between gap-2">
                    <span className={`${b.status === "retired" ? "line-through text-slate-400" : "text-slate-800"}`}>{b.statement}</span>
                    <span className={`shrink-0 rounded border px-1.5 py-0.5 text-[10px] ${STATUS_STYLE[b.status]}`}>{b.status}</span>
                  </div>
                  <div className="mt-1 flex flex-wrap gap-x-3 text-[11px] text-slate-400">
                    <span>{b.kind}{b.domain ? ` · ${b.domain}` : " · general"}</span>
                    <span>{b.source}</span>
                    <span title="confidence">conf {Math.round(b.confidence * 100)}%</span>
                    <span>{b.supportCount} for · {b.contradictionCount} against · {b.distinctSessions} session{b.distinctSessions === 1 ? "" : "s"}</span>
                  </div>
                  {b.invalidReason && <div className="mt-1 text-[11px] text-rose-500">retired: {b.invalidReason}</div>}
                </button>
                {open === b.id && (
                  <div className="mt-2 space-y-2 border-t border-slate-100 pt-2">
                    <div className="text-[11px] font-medium text-slate-500">Why I think this</div>
                    {(evidence[b.id] ?? []).length === 0 && <div className="text-[11px] text-slate-400">loading evidence…</div>}
                    {(evidence[b.id] ?? []).map((e, i) => (
                      <div key={i} className="flex gap-2 text-[11px]">
                        <span className={e.polarity === "supports" ? "text-emerald-600" : "text-rose-600"}>{e.polarity === "supports" ? "+" : "−"}</span>
                        <span className="text-slate-600">{e.observation?.content ?? "(observation)"} <span className="text-slate-400">· {new Date(e.createdAt).toLocaleDateString()}</span></span>
                      </div>
                    ))}
                    {b.status !== "retired" && (
                      challenge?.id === b.id ? (
                        <div className="space-y-1.5 rounded-md bg-slate-50 p-2">
                          <input value={challenge.note} onChange={(e) => setChallenge({ ...challenge, note: e.target.value })} placeholder="What's wrong about this?" className="w-full rounded border border-slate-300 px-2 py-1 text-xs" />
                          <input value={challenge.replacement} onChange={(e) => setChallenge({ ...challenge, replacement: e.target.value })} placeholder="Optional: what's actually true?" className="w-full rounded border border-slate-300 px-2 py-1 text-xs" />
                          <div className="flex gap-2"><button onClick={submitChallenge} className="rounded bg-slate-900 px-2 py-1 text-xs text-white">Update memory</button><button onClick={() => setChallenge(null)} className="text-xs text-slate-500">cancel</button></div>
                        </div>
                      ) : (
                        <button onClick={() => setChallenge({ id: b.id, note: "That's not true about me.", replacement: "" })} className="text-[11px] text-rose-600 hover:underline">That&apos;s not true about me</button>
                      )
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {tab === "concepts" && (
          <div className="space-y-1.5">
            {mem.conceptStates.length === 0 && <p className="text-xs text-slate-400">No concept evidence yet.</p>}
            {mem.conceptStates.map((c) => {
              const behaviour = c.attempts ? c.pKnown : null;
              return (
                <div key={`${c.domain}/${c.concept}`} className="rounded-lg border border-slate-200 p-2.5">
                  <div className="flex items-center justify-between"><span className="text-slate-800">{c.concept} <span className="text-[11px] text-slate-400">{c.domain}</span></span><span className="text-[11px] text-slate-400">{c.exposures} exposures</span></div>
                  <div className="mt-1.5 h-1.5 w-full rounded bg-slate-100"><div className="h-1.5 rounded bg-emerald-500" style={{ width: `${Math.round(c.pKnown * 100)}%` }} /></div>
                  <div className="mt-1 flex justify-between text-[11px] text-slate-500">
                    <span>{behaviour == null ? "no attempts observed yet" : `${c.successes} worked · ${c.mistakes} failed → p(known) ${Math.round(c.pKnown * 100)}%`}</span>
                    {c.selfReport != null && <span className={Math.abs(c.selfReport - (2 * c.pKnown - 1)) > 0.9 && c.attempts >= 3 ? "text-amber-600" : ""}>says: {c.selfReport > 0 ? "confident" : "unsure"}</span>}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === "evidence" && (
          <div className="space-y-1.5">
            {mem.sessions.filter((s) => s.summary).slice(0, 3).map((s) => (
              <div key={s.id} className="rounded-lg bg-slate-50 p-2.5 text-xs text-slate-600"><span className="text-slate-400">{new Date(s.startedAt).toLocaleDateString()} · </span>{s.summary}</div>
            ))}
            {mem.observations.map((o) => (
              <div key={o.id} className="flex gap-2 rounded-lg border border-slate-100 p-2 text-xs">
                <span className="shrink-0 rounded bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-500">{o.kind.replace(/_/g, " ")}</span>
                <span className="text-slate-700">{o.content}</span>
                <span className="ml-auto shrink-0 text-[10px] text-slate-400">{new Date(o.createdAt).toLocaleDateString()}</span>
              </div>
            ))}
          </div>
        )}

        {tab === "graph" && <Graph nodes={mem.graph.nodes} edges={mem.graph.edges} />}
      </div>
    </div>
  );
}

function Graph({ nodes, edges }: { nodes: Node[]; edges: Edge[] }) {
  const W = 380, H = 420;
  const live = edges.filter((e) => !e.invalidAt);
  const keys = new Set<string>();
  for (const e of live) { keys.add(e.fromKey); keys.add(e.toKey); }
  const shown = nodes.filter((n) => keys.has(n.key)).slice(0, 60);
  if (!shown.length) return <p className="text-xs text-slate-400">The graph grows as we talk: concepts, goals, strategies and how they connect for you.</p>;
  const byType: Record<string, Node[]> = {};
  for (const n of shown) (byType[n.type] ??= []).push(n);
  const pos = new Map<string, { x: number; y: number }>();
  const types = Object.keys(byType);
  types.forEach((t, ti) => {
    const col = byType[t];
    col.forEach((n, i) => pos.set(n.key, { x: 40 + (ti * (W - 80)) / Math.max(1, types.length - 1), y: 30 + ((i + 0.5) * (H - 60)) / col.length }));
  });
  const color: Record<string, string> = { concept: "#0f766e", domain: "#1d4ed8", goal: "#b45309", strategy: "#7c3aed", learner: "#0f172a" };
  return (
    <div>
      <svg width={W} height={H} className="rounded-lg bg-slate-50">
        {live.map((e) => {
          const a = pos.get(e.fromKey), b = pos.get(e.toKey);
          if (!a || !b) return null;
          const c = e.relation === "struggles_with" ? "#e11d48" : e.relation === "has_grasped" ? "#059669" : e.relation === "works_for" ? "#7c3aed" : "#94a3b8";
          return <line key={e.id} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={c} strokeOpacity={0.6} strokeWidth={Math.min(4, 0.6 + e.weight)}><title>{e.relation} · weight {e.weight.toFixed(2)} · {e.evidenceCount} evidence</title></line>;
        })}
        {shown.map((n) => {
          const p = pos.get(n.key)!;
          return (
            <g key={n.id}>
              <circle cx={p.x} cy={p.y} r={5} fill={color[n.type] ?? "#475569"} />
              <text x={p.x + 8} y={p.y + 3} fontSize={9} fill="#334155">{n.label.slice(0, 18)}</text>
            </g>
          );
        })}
      </svg>
      <div className="mt-2 flex flex-wrap gap-3 text-[10px] text-slate-500">
        {Object.entries(color).map(([t, c]) => (<span key={t} className="flex items-center gap-1"><span className="inline-block h-2 w-2 rounded-full" style={{ background: c }} />{t}</span>))}
        <span className="text-slate-400">{edges.length - live.length} edges invalidated (history kept)</span>
      </div>
    </div>
  );
}
