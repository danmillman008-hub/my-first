import { runTurn, challengeBelief, ensureLearner } from "@/lib/agent";
import { buildTurnContext, loadLearnerMemory } from "@/lib/memory/retrieval";
import { consolidateTurn } from "@/lib/memory/consolidate";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import type { ObservationKind } from "@/lib/types";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

// Minimal Model Context Protocol server (Streamable HTTP transport, JSON-RPC 2.0).
// External assistants read from and write to the SAME learner model the tutor
// uses — no separate, incompatible memory.

const TOOLS = [
  {
    name: "get_learner_context",
    description: "Retrieve what the tutor currently believes about a learner (active beliefs with confidence and evidence counts, concept mastery estimates, which teaching strategies have worked) plus a recommended approach for the given message/domain. Beliefs are priors, not verdicts.",
    inputSchema: { type: "object", properties: { learnerId: { type: "string" }, message: { type: "string", description: "Optional: the learner's current message, used to scope the context to the right domain." } }, required: ["learnerId"] },
  },
  {
    name: "tutor_turn",
    description: "Send a learner message through the full adaptive tutor (memory retrieval, strategy selection, reply, observation extraction, consolidation). Returns the reply and the strategy used.",
    inputSchema: { type: "object", properties: { learnerId: { type: "string" }, message: { type: "string" } }, required: ["learnerId", "message"] },
  },
  {
    name: "record_observation",
    description: "Add a piece of evidence about the learner observed elsewhere (e.g. they solved a task in another tool). Kinds: statement, question, self_report, success, mistake, reaction, request, topic_switch, correction, code_shared, context.",
    inputSchema: { type: "object", properties: { learnerId: { type: "string" }, kind: { type: "string" }, content: { type: "string" }, concepts: { type: "array", items: { type: "string" } }, domain: { type: "string" }, signals: { type: "object" } }, required: ["learnerId", "kind", "content"] },
  },
  {
    name: "list_beliefs",
    description: "List the learner model's beliefs with lifecycle status (candidate/active/contested/dormant/retired), confidence, support/contradiction counts and scope.",
    inputSchema: { type: "object", properties: { learnerId: { type: "string" }, includeRetired: { type: "boolean" } }, required: ["learnerId"] },
  },
  {
    name: "challenge_belief",
    description: "On the learner's behalf, dispute a belief ('that's not true about me'). Retires it (evidence is kept) and optionally records a replacement stated by the learner.",
    inputSchema: { type: "object", properties: { learnerId: { type: "string" }, beliefId: { type: "string" }, note: { type: "string" }, replacement: { type: "string" } }, required: ["learnerId", "beliefId"] },
  },
];

type Rpc = { jsonrpc: "2.0"; id?: number | string | null; method: string; params?: Record<string, unknown> };

function ok(id: Rpc["id"], result: unknown) { return { jsonrpc: "2.0", id: id ?? null, result }; }
function err(id: Rpc["id"], code: number, message: string) { return { jsonrpc: "2.0", id: id ?? null, error: { code, message } }; }
function text(payload: unknown) { return { content: [{ type: "text", text: JSON.stringify(payload, null, 2) }] }; }

async function callTool(name: string, args: Record<string, unknown>) {
  const learnerId = String(args.learnerId ?? "");
  if (!learnerId) throw new Error("learnerId required");
  switch (name) {
    case "get_learner_context": {
      await ensureLearner(learnerId);
      const ctx = await buildTurnContext({ learnerId, userMessage: String(args.message ?? ""), now: new Date() });
      return text({
        domain: ctx.currentDomainGuess,
        beliefs: ctx.beliefs.map((b) => ({ id: b.id, kind: b.kind, statement: b.statement, domain: b.domain, status: b.status, confidence: +b.confidence.toFixed(2), influence: +(b.influence ?? 0).toFixed(2), support: b.supportCount, contradictions: b.contradictionCount, source: b.source })),
        conceptStates: ctx.conceptStates,
        strategyStats: ctx.strategyStats,
        recommended: { strategy: ctx.recommendedStrategy, depth: ctx.recommendedDepth, reason: ctx.strategyReason },
        previousSessions: ctx.previousSessionSummaries,
      });
    }
    case "tutor_turn": {
      const res = await runTurn({ learnerId, userMessage: String(args.message ?? "") });
      return text({ reply: res.reply, strategy: res.meta.strategy, depth: res.meta.depth, domain: res.meta.domain, report: res.report });
    }
    case "record_observation": {
      await ensureLearner(learnerId);
      const [last] = await db.select().from(sessions).where(eq(sessions.learnerId, learnerId)).orderBy(desc(sessions.lastActiveAt)).limit(1);
      let sessionId = last?.id;
      const now = new Date();
      if (!sessionId) { sessionId = `s_${crypto.randomUUID()}`; await db.insert(sessions).values({ id: sessionId, learnerId, startedAt: now, lastActiveAt: now, turnCount: 0 }); }
      const report = await consolidateTurn({
        learnerId, sessionId, userMessageId: `ext_${crypto.randomUUID()}`, assistantMessageId: "", lastAssistantMessage: null, now, mode: "full",
        output: { reply: "", strategy: "direct_explanation", depth: "standard", domain: (args.domain as string | undefined) ?? null, concepts: (args.concepts as string[] | undefined) ?? [], observations: [{ kind: String(args.kind) as ObservationKind, content: String(args.content), concepts: (args.concepts as string[] | undefined) ?? [], domain: (args.domain as string | undefined) ?? null, signals: (args.signals as Record<string, unknown> | undefined) ?? {}, salience: 0.6 }], prevTurnOutcome: null, beliefFeedback: [], learnerCorrection: null, probe: null, researchRequest: null, strategyOverrideReason: null },
      });
      return text({ ok: true, report });
    }
    case "list_beliefs": {
      const mem = await loadLearnerMemory(learnerId);
      const rows = args.includeRetired ? mem.beliefs : mem.beliefs.filter((b) => b.status !== "retired");
      return text(rows.map((b) => ({ id: b.id, kind: b.kind, key: b.key, statement: b.statement, domain: b.domain, status: b.status, confidence: +b.confidence.toFixed(2), support: b.supportCount, contradictions: b.contradictionCount, source: b.source, validFrom: b.validFrom, invalidAt: b.invalidAt, invalidReason: b.invalidReason })));
    }
    case "challenge_belief": {
      const report = await challengeBelief({ learnerId, beliefId: String(args.beliefId), note: String(args.note ?? "That's not true about me."), replacement: (args.replacement as string | undefined) ?? null });
      return text({ ok: true, report });
    }
    default:
      throw new Error(`unknown tool ${name}`);
  }
}

async function handle(msg: Rpc) {
  switch (msg.method) {
    case "initialize":
      return ok(msg.id, { protocolVersion: "2025-03-26", capabilities: { tools: { listChanged: false } }, serverInfo: { name: "self-adapting-tutor", version: "1.0.0" } });
    case "ping":
      return ok(msg.id, {});
    case "tools/list":
      return ok(msg.id, { tools: TOOLS });
    case "tools/call": {
      const name = String(msg.params?.name ?? "");
      const args = (msg.params?.arguments as Record<string, unknown>) ?? {};
      try {
        return ok(msg.id, await callTool(name, args));
      } catch (e) {
        return ok(msg.id, { isError: true, content: [{ type: "text", text: e instanceof Error ? e.message : "tool error" }] });
      }
    }
    default:
      if (msg.method.startsWith("notifications/")) return null;
      return err(msg.id, -32601, `method not found: ${msg.method}`);
  }
}

export async function POST(req: Request) {
  let body: Rpc | Rpc[];
  try {
    body = (await req.json()) as Rpc | Rpc[];
  } catch {
    return Response.json(err(null, -32700, "parse error"), { status: 400 });
  }
  const msgs = Array.isArray(body) ? body : [body];
  const results = (await Promise.all(msgs.map(handle))).filter((r) => r !== null);
  if (!results.length) return new Response(null, { status: 202 });
  return Response.json(Array.isArray(body) ? results : results[0]);
}

export async function GET() {
  return Response.json({ name: "self-adapting-tutor", transport: "streamable-http", endpoint: "/api/mcp", tools: TOOLS.map((t) => t.name) });
}
