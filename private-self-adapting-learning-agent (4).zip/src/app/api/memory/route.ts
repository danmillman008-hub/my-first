import { loadLearnerMemory, loadBeliefEvidence } from "@/lib/memory/retrieval";
import { challengeBelief } from "@/lib/agent";
import { db } from "@/db";
import { graphEdges, graphNodes, agentTraces } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** GET /api/memory?learnerId=...            → full inspectable learner model
 *  GET /api/memory?learnerId=...&beliefId=… → evidence trail for one belief */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const learnerId = url.searchParams.get("learnerId") ?? "";
  const beliefId = url.searchParams.get("beliefId");
  if (!learnerId) return Response.json({ error: "learnerId required" }, { status: 400 });
  if (beliefId) return Response.json({ evidence: await loadBeliefEvidence(beliefId) });
  const mem = await loadLearnerMemory(learnerId);
  const [nodes, edges, traces] = await Promise.all([
    db.select().from(graphNodes).where(eq(graphNodes.learnerId, learnerId)),
    db.select().from(graphEdges).where(eq(graphEdges.learnerId, learnerId)),
    db.select().from(agentTraces).where(eq(agentTraces.learnerId, learnerId)).orderBy(desc(agentTraces.createdAt)).limit(30),
  ]);
  return Response.json({ ...mem, graph: { nodes, edges }, traces });
}

/** POST /api/memory  { learnerId, beliefId, note, replacement? } → learner challenges a belief */
export async function POST(req: Request) {
  const body = (await req.json()) as { learnerId?: string; beliefId?: string; note?: string; replacement?: string | null };
  if (!body.learnerId || !body.beliefId) return Response.json({ error: "learnerId and beliefId required" }, { status: 400 });
  const report = await challengeBelief({ learnerId: body.learnerId, beliefId: body.beliefId, note: body.note?.trim() || "That's not true about me.", replacement: body.replacement?.trim() || null });
  return Response.json({ ok: true, report });
}
