import { runTurn } from "@/lib/agent";
import { db } from "@/db";
import { messages, sessions } from "@/db/schema";
import { and, asc, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { learnerId?: string; message?: string };
    const learnerId = (body.learnerId ?? "").trim();
    const message = (body.message ?? "").trim();
    if (!learnerId || !message) return Response.json({ error: "learnerId and message are required" }, { status: 400 });
    if (message.length > 8000) return Response.json({ error: "message too long" }, { status: 400 });
    const res = await runTurn({ learnerId, userMessage: message });
    return Response.json({
      reply: res.reply,
      sessionId: res.sessionId,
      isNewSession: res.isNewSession,
      meta: res.meta,
      report: res.report,
    });
  } catch (e) {
    console.error(e);
    return Response.json({ error: e instanceof Error ? e.message : "unknown error" }, { status: 500 });
  }
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const learnerId = url.searchParams.get("learnerId") ?? "";
  if (!learnerId) return Response.json({ error: "learnerId required" }, { status: 400 });
  const rows = await db.select().from(messages).where(eq(messages.learnerId, learnerId)).orderBy(desc(messages.createdAt)).limit(120);
  const sess = await db.select().from(sessions).where(and(eq(sessions.learnerId, learnerId))).orderBy(asc(sessions.startedAt));
  return Response.json({
    messages: rows.reverse().map((m) => ({ id: m.id, role: m.role, content: m.content, meta: m.meta, sessionId: m.sessionId, createdAt: m.createdAt })),
    sessions: sess.map((s) => ({ id: s.id, startedAt: s.startedAt, lastActiveAt: s.lastActiveAt, summary: s.summary, turnCount: s.turnCount })),
    provider: process.env.OPENAI_API_KEY ? `openai:${process.env.OPENAI_MODEL ?? "gpt-4o-mini"}` : "offline",
  });
}
