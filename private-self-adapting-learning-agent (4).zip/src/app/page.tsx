import Tutor from "./tutor";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <Tutor />;
}
