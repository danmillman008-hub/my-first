import "dotenv/config";
import { STRATEGIES, type Strategy } from "@/lib/types";
import { runTurn } from "@/lib/agent";
import { OfflineProvider } from "@/lib/llm/offline";
import { mulberry32 } from "@/lib/memory/strategy";
import type { MemoryMode } from "@/lib/memory/retrieval";
import { db } from "@/db";
import { beliefs, graphEdges, graphNodes, observations, agentTraces, strategyOutcomes } from "@/db/schema";
import { and, eq, ne, gt, lt } from "drizzle-orm";

// ---------------------------------------------------------------------------
// Synthetic learners with HIDDEN ground truth. The agent never sees these.
// ---------------------------------------------------------------------------
export interface HiddenLearner {
  id: string;
  seed: number;
  domains: string[];
  /** P(understand | strategy) per domain. */
  affinity: Record<string, Record<Strategy, number>>;
  /** After this session index, affinities are re-drawn (preference drift). -1 = none */
  driftAtSession: number;
  overconfidence: number; // -1 (under) .. 1 (over)
  noise: number; // prob of a random reaction regardless of strategy
  articulates: boolean; // does the learner ever explicitly ask for a format?
  topicSwitchProb: number;
  correctionAtSession: number; // -1 = none
  mastery: Record<string, number>;
}

const DOMAIN_TEXT: Record<string, { concepts: string[]; ask: string[] }> = {
  bash: { concepts: ["pipes", "redirection", "quoting", "exit codes", "loops"], ask: ["Why does `pipes` behave like that in bash?", "How do pipes work in bash?", "Explain redirection in bash", "What do exit codes mean in a shell script?", "How do loops work in bash?"] },
  oop: { concepts: ["classes", "inheritance", "polymorphism", "encapsulation"], ask: ["Explain OOP classes to me", "What is inheritance in OOP?", "Why would I use polymorphism in object oriented code?", "What does encapsulation mean in classes?"] },
  statistics: { concepts: ["probability", "bayes", "variance"], ask: ["Explain bayes theorem in statistics", "What is variance in statistics?", "How does probability work with a distribution?"] },
  sql: { concepts: ["joins", "indexes", "aggregation"], ask: ["How do joins work in sql?", "Why does my sql query need an index?", "Explain group by aggregation in sql"] },
};

export function makeLearner(seed: number, opts: Partial<HiddenLearner> = {}): HiddenLearner {
  const rnd = mulberry32(seed);
  const domains = opts.domains ?? ["bash", "oop"];
  const affinity: HiddenLearner["affinity"] = {};
  for (const d of domains) affinity[d] = drawAffinity(rnd);
  return {
    id: `sim_${seed}_${Math.floor(rnd() * 1e6)}`,
    seed,
    domains,
    affinity,
    driftAtSession: -1,
    overconfidence: 0,
    noise: 0.1,
    articulates: rnd() < 0.5,
    topicSwitchProb: 0.15,
    correctionAtSession: -1,
    mastery: Object.fromEntries(domains.flatMap((d) => DOMAIN_TEXT[d].concepts.map((c) => [`${d}/${c}`, 0.2]))),
    ...opts,
  };
}

function drawAffinity(rnd: () => number): Record<Strategy, number> {
  const order = [...STRATEGIES].sort(() => rnd() - 0.5);
  const out = {} as Record<Strategy, number>;
  order.forEach((s, i) => { out[s] = i === 0 ? 0.85 : i === 1 ? 0.6 : 0.3 + rnd() * 0.15; });
  return out;
}

export function bestStrategy(l: HiddenLearner, domain: string): Strategy {
  const a = l.affinity[domain];
  return (Object.keys(a) as Strategy[]).sort((x, y) => a[y] - a[x])[0];
}

// ---------------------------------------------------------------------------
// Learner simulator: produces the next message given the tutor's last turn.
// ---------------------------------------------------------------------------
interface SimState { domain: string; lastStrategy: Strategy | null; lastConcept: string; turnInSession: number; sessionIdx: number; rnd: () => number; pendingTask: boolean }

function nextMessage(l: HiddenLearner, st: SimState): { text: string; understood: boolean | null } {
  const { rnd } = st;
  const d = DOMAIN_TEXT[st.domain];
  const openers: string[] = [];
  let understood: boolean | null = null;

  if (st.lastStrategy) {
    const p = l.affinity[st.domain][st.lastStrategy];
    const roll = rnd();
    understood = rnd() < l.noise ? rnd() < 0.5 : roll < p;
    if (st.pendingTask) {
      // Behavioural evidence: task success depends on hidden mastery.
      const m = l.mastery[`${st.domain}/${st.lastConcept}`] ?? 0.2;
      const ok = rnd() < Math.min(0.95, m + (understood ? 0.25 : 0) - 0.3 * Math.max(0, l.overconfidence));
      openers.push(ok ? "I tried it and it worked. " : "I tried it but it still fails with the same error. ");
      if (ok) l.mastery[`${st.domain}/${st.lastConcept}`] = Math.min(1, m + 0.15);
      st.pendingTask = false;
    } else {
      openers.push(understood ? pick(rnd, ["That makes sense. ", "Got it, thanks. ", "Ah okay, I see. "]) : pick(rnd, ["I'm confused, that doesn't make sense to me. ", "Hmm, I don't get it. ", "I'm not following, that was too abstract. "]));
    }
    if (understood) {
      const k = `${st.domain}/${st.lastConcept}`;
      l.mastery[k] = Math.min(1, (l.mastery[k] ?? 0.2) + 0.08);
    }
  }

  // Self-report bias (overconfidence hidden property).
  if (rnd() < 0.18) {
    const m = l.mastery[`${st.domain}/${st.lastConcept}`] ?? 0.2;
    const perceived = m + l.overconfidence * 0.6;
    if (perceived > 0.6) openers.push(`I already know ${st.lastConcept}. `);
    else if (perceived < 0.25) openers.push(`I'm bad at ${st.lastConcept}. `);
  }

  // Explicit requests (only for learners who articulate preferences).
  if (l.articulates && rnd() < 0.2) {
    const best = bestStrategy(l, st.domain);
    const req: Partial<Record<Strategy, string>> = { worked_example: "Can you show me an example? ", analogy: "Could you use an analogy? ", hands_on_task: "Let me practice with a task. ", step_by_step: "Walk me through it step by step. ", direct_explanation: "Just tell me directly, no questions. ", socratic: "" };
    if (req[best]) openers.push(req[best]!);
  }

  // Topic switch
  if (l.domains.length > 1 && rnd() < l.topicSwitchProb && st.turnInSession > 1) {
    const other = l.domains.filter((x) => x !== st.domain);
    const nd = pick(rnd, other);
    const label = nd === "oop" ? "OOP" : nd;
    st.domain = nd;
    const c = pick(rnd, DOMAIN_TEXT[nd].concepts);
    st.lastConcept = c;
    return { text: `${openers.join("")}Actually, forget ${st.domain === nd ? "that" : st.domain} for a moment. Explain ${label} ${c} to me.`, understood };
  }

  const i = Math.floor(rnd() * d.ask.length);
  st.lastConcept = d.concepts[i % d.concepts.length];
  return { text: `${openers.join("")}${d.ask[i]}`, understood };
}

function pick<T>(rnd: () => number, arr: T[]): T { return arr[Math.floor(rnd() * arr.length)]; }

// ---------------------------------------------------------------------------
// Run one learner through many sessions with time gaps.
// ---------------------------------------------------------------------------
export interface RunConfig { sessions: number; turnsPerSession: number; gapHours: number[]; mode: MemoryMode; startAt?: Date }
export interface RunResult {
  learnerId: string;
  mode: MemoryMode;
  perSession: { idx: number; bestRate: number; understoodRate: number; probes: number; newSession: boolean; domainSwitches: number }[];
  retiredStayRetired: boolean | null;
  goalPersisted: boolean | null;
  activeBeliefs: number;
  totalBeliefs: number;
  observationsCount: number;
  nodes: number;
  edges: number;
  invalidEdges: number;
  overclaimDetected: boolean;
  underclaimDetected: boolean;
  driftRecoverySessions: number | null;
  welcomeBacks: number;
  firstDomainStrategyFitDomains: string[];
}

export async function runLearner(l: HiddenLearner, cfg: RunConfig): Promise<RunResult> {
  const provider = new OfflineProvider();
  const rnd = mulberry32(l.seed * 7919 + 13);
  let now = cfg.startAt ?? new Date("2026-01-05T09:00:00Z");
  const st: SimState = { domain: l.domains[0], lastStrategy: null, lastConcept: DOMAIN_TEXT[l.domains[0]].concepts[0], turnInSession: 0, sessionIdx: 0, rnd, pendingTask: false };
  const perSession: RunResult["perSession"] = [];
  let correctedBeliefId: string | null = null;
  let welcomeBacks = 0;
  let driftRecoverySessions: number | null = null;

  for (let s = 0; s < cfg.sessions; s++) {
    st.sessionIdx = s;
    st.turnInSession = 0;
    st.lastStrategy = null;
    if (s === l.driftAtSession) for (const d of l.domains) l.affinity[d] = drawAffinity(mulberry32(l.seed * 31 + s));
    let best = 0, understoodN = 0, understoodDen = 0, probes = 0, switches = 0;
    const domainBefore = st.domain;
    for (let t = 0; t < cfg.turnsPerSession; t++) {
      let text: string;
      let understood: boolean | null = null;
      if (s === 0 && t === 0) text = `I want to learn ${l.domains[0]}. ${DOMAIN_TEXT[l.domains[0]].ask[0]}`;
      else if (s === l.correctionAtSession && t === 1 && !correctedBeliefId) {
        // Learner challenges the tutor's most influential inferred belief about them.
        const rows = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, l.id), eq(beliefs.status, "active"), ne(beliefs.source, "stated"))).limit(20);
        const target = rows.sort((a, b) => b.confidence - a.confidence)[0];
        if (target) {
          correctedBeliefId = target.id;
          text = `That's not true about me — ${target.statement.toLowerCase()} is wrong, I never said that. ${DOMAIN_TEXT[st.domain].ask[1]}`;
        } else {
          const m = nextMessage(l, st); text = m.text; understood = m.understood;
        }
      } else {
        const m = nextMessage(l, st); text = m.text; understood = m.understood;
      }
      if (understood != null) { understoodDen++; if (understood) understoodN++; }
      const res = await runTurn({ learnerId: l.id, userMessage: text, now, provider, mode: cfg.mode, rnd, enableResearch: false });
      if (res.isNewSession && /welcome back/i.test(res.reply)) welcomeBacks++;
      const strat = res.meta.strategy as Strategy;
      const dom = (res.meta.domain as string | null) ?? st.domain;
      if (dom !== st.domain) switches++;
      if (l.affinity[dom] && strat === bestStrategy(l, dom)) best++;
      if (res.output.probe) probes++;
      st.lastStrategy = strat;
      // Learners try things on their own too, not only when handed a task.
      st.pendingTask = strat === "hands_on_task" || rnd() < 0.3;
      st.turnInSession++;
      now = new Date(now.getTime() + (2 + Math.floor(rnd() * 4)) * 60000);
    }
    void domainBefore;
    perSession.push({ idx: s, bestRate: best / cfg.turnsPerSession, understoodRate: understoodDen ? understoodN / understoodDen : 0, probes, newSession: true, domainSwitches: switches });
    if (l.driftAtSession >= 0 && s > l.driftAtSession && driftRecoverySessions == null && best / cfg.turnsPerSession >= 0.5) driftRecoverySessions = s - l.driftAtSession;
    const gap = cfg.gapHours[s % cfg.gapHours.length];
    now = new Date(now.getTime() + gap * 3600000);
  }

  // ---- Inspect memory against hidden truth ----
  const allBeliefs = await db.select().from(beliefs).where(eq(beliefs.learnerId, l.id));
  const active = allBeliefs.filter((b) => b.status === "active" || b.status === "contested");
  let retiredStayRetired: boolean | null = null;
  if (correctedBeliefId) {
    const target = allBeliefs.find((b) => b.id === correctedBeliefId)!;
    const re = allBeliefs.filter((b) => b.id !== target.id && b.key === target.key && b.domain === target.domain && b.status !== "retired" && b.createdAt > target.invalidAt!);
    // A belief may legitimately be RE-EARNED from evidence gathered after the
    // correction (behaviour outranks self-report over time); what must never
    // happen is re-creation from the pre-correction evidence.
    let staleReintro = false;
    for (const r of re) {
      const strat = target.key?.replace(/^(fit|unfit):/, "");
      const fresh = (await db.select().from(strategyOutcomes).where(and(eq(strategyOutcomes.learnerId, l.id), eq(strategyOutcomes.strategy, strat ?? ""), eq(strategyOutcomes.domain, target.domain ?? ""), gt(strategyOutcomes.createdAt, target.invalidAt!), lt(strategyOutcomes.createdAt, r.createdAt)))).length;
      if (target.kind !== "strategy_fit" || fresh < 4) staleReintro = true;
    }
    retiredStayRetired = target.status === "retired" && !staleReintro;
  }
  const goal = allBeliefs.find((b) => b.kind === "goal");
  const goalPersisted = goal ? goal.status === "active" : null;
  const obsCount = (await db.select({ id: observations.id }).from(observations).where(eq(observations.learnerId, l.id))).length;
  const nodes = (await db.select({ id: graphNodes.id }).from(graphNodes).where(eq(graphNodes.learnerId, l.id))).length;
  const edgesAll = await db.select().from(graphEdges).where(eq(graphEdges.learnerId, l.id));
  const probesTotal = (await db.select({ id: agentTraces.id }).from(agentTraces).where(and(eq(agentTraces.learnerId, l.id), eq(agentTraces.kind, "probe")))).length;
  void probesTotal;
  return {
    learnerId: l.id,
    mode: cfg.mode,
    perSession,
    retiredStayRetired,
    goalPersisted,
    activeBeliefs: active.length,
    totalBeliefs: allBeliefs.length,
    observationsCount: obsCount,
    nodes,
    edges: edgesAll.length,
    invalidEdges: edgesAll.filter((e) => e.invalidAt).length,
    overclaimDetected: active.some((b) => b.key === "tendency:overclaims"),
    underclaimDetected: active.some((b) => b.key === "tendency:underclaims"),
    driftRecoverySessions,
    welcomeBacks,
    firstDomainStrategyFitDomains: active.filter((b) => b.kind === "strategy_fit" && b.key?.startsWith("fit:")).map((b) => `${b.domain}:${b.key}`),
  };
}

export function mean(xs: number[]) { return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0; }
