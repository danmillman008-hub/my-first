import "dotenv/config";
import { runTurn } from "@/lib/agent";
import { createProvider } from "@/lib/llm/openai";
import { loadLearnerMemory } from "@/lib/memory/retrieval";
import { pool } from "@/db";

// Qualitative product evaluation: one continuous relationship across sessions.
// Uses the real model when OPENAI_API_KEY is set (OPENAI_MODEL / OPENAI_BASE_URL
// optional), otherwise the offline provider. Prints the transcript and memory.

const provider = createProvider();
const L = process.argv[2] ?? `transcript_${Date.now()}`;
let clock = new Date("2026-03-02T18:00:00Z");
const day = 86400000;

const script: (string | { gap: number })[] = [
  "I want to learn Bash. I'm a data analyst and mostly use Python at work.",
  "Why does `ls | grep foo` behave differently from `ls > grep`?",
  "Hmm, that was a bit abstract. Can you show me an example?",
  "That makes sense. What about `2>&1`? I keep seeing it.",
  "Here is what I ran:\n```\n$ find . -name '*.csv' | xargs wc -l > counts.txt 2>&1\n```\nIt worked but I'm not sure why the errors also ended up in the file.",
  "Got it. Actually, forget Bash for a moment. Explain OOP to me.",
  "I disagree — I don't think inheritance is the main point of OOP. Isn't composition better?",
  "Fair. I'm bad at abstract stuff like this, honestly.",
  { gap: 7 * day },
  "Hi again. Back to Bash — how do exit codes work in scripts?",
  "I tried `set -e` in my script and it worked. What else should I know?",
  "You seem to think I'm bad at abstract concepts — that's not true about me, I just hadn't seen OOP before.",
  "Ok. Give me a quick exercise on exit codes.",
  "Done, my script prints 1 when the file is missing. Correct?",
];

async function main() {
  console.log(`provider: ${provider.name}\nlearner: ${L}\n`);
  for (const step of script) {
    if (typeof step !== "string") { clock = new Date(clock.getTime() + step.gap); console.log(`\n===== ${step.gap / day} days later =====\n`); continue; }
    clock = new Date(clock.getTime() + 4 * 60000);
    const res = await runTurn({ learnerId: L, userMessage: step, now: clock, provider });
    console.log(`LEARNER: ${step}\n`);
    console.log(`TUTOR [${res.meta.strategy}/${res.meta.depth}${res.meta.domain ? `/${res.meta.domain}` : ""}${res.output.probe ? " +probe" : ""}${res.meta.strategyOverrideReason ? ` (override: ${res.meta.strategyOverrideReason})` : ""}]: ${res.reply}\n`);
    const r = res.report;
    const notes = [r.observationsAdded ? `${r.observationsAdded} obs` : "", r.beliefsCreated.length ? `+${r.beliefsCreated.length} belief` : "", r.beliefsSupported.length ? `${r.beliefsSupported.length} supported` : "", r.beliefsContradicted.length ? `${r.beliefsContradicted.length} contested` : "", r.beliefsRetired.length ? `${r.beliefsRetired.length} retired` : "", r.outcomeRecorded ? `outcome ${r.outcomeRecorded.strategy}=${r.outcomeRecorded.outcome}` : ""].filter(Boolean);
    console.log(`   · memory: ${notes.join(", ") || "no change"}\n`);
  }
  const mem = await loadLearnerMemory(L, clock);
  console.log("\n===== WHAT THE TUTOR NOW BELIEVES =====");
  for (const b of mem.beliefs) console.log(`[${b.status.padEnd(9)}] (${b.kind}${b.domain ? `/${b.domain}` : ""}, ${b.source}, conf ${b.confidence.toFixed(2)}, +${b.supportCount}/-${b.contradictionCount}) ${b.statement}${b.invalidReason ? `  ← ${b.invalidReason}` : ""}`);
  console.log("\n===== CONCEPT EVIDENCE =====");
  for (const c of mem.conceptStates) console.log(`${c.concept} (${c.domain}): p=${c.pKnown.toFixed(2)} ok=${c.successes} fail=${c.mistakes} self=${c.selfReport ?? "-"}`);
  console.log("\n===== WHAT WORKED =====");
  for (const s of mem.strategyStats) console.log(`${s.strategy}${s.domain ? `/${s.domain}` : ""}: ${s.mean.toFixed(2)} (n=${s.n})`);
  await pool.end();
}

main().catch((e) => { console.error(e); process.exit(1); });
