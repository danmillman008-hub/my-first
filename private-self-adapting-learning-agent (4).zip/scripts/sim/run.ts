import "dotenv/config";
import { makeLearner, runLearner, mean, type RunResult, bestStrategy } from "./harness";
import type { MemoryMode } from "@/lib/memory/retrieval";
import { pool } from "@/db";

// Usage: npx tsx scripts/sim/run.ts [learners=6] [sessions=8] [turns=10] [modes=full,no_adaptation,no_long_term]
const N = Number(process.argv[2] ?? 6);
const SESSIONS = Number(process.argv[3] ?? 8);
const TURNS = Number(process.argv[4] ?? 10);
const MODES = (process.argv[5] ?? "full,no_adaptation,no_long_term").split(",") as MemoryMode[];

function summarize(results: RunResult[]) {
  const early = mean(results.flatMap((r) => r.perSession.slice(0, 2).map((s) => s.bestRate)));
  const late = mean(results.flatMap((r) => r.perSession.slice(-2).map((s) => s.bestRate)));
  const uEarly = mean(results.flatMap((r) => r.perSession.slice(0, 2).map((s) => s.understoodRate)));
  const uLate = mean(results.flatMap((r) => r.perSession.slice(-2).map((s) => s.understoodRate)));
  const probesPer100 = 100 * mean(results.map((r) => r.perSession.reduce((a, s) => a + s.probes, 0) / (r.perSession.length * TURNS)));
  const corr = results.filter((r) => r.retiredStayRetired != null);
  const goals = results.filter((r) => r.goalPersisted != null);
  const drift = results.filter((r) => r.driftRecoverySessions != null);
  return {
    n: results.length,
    bestStrategyRate: { early: +early.toFixed(3), late: +late.toFixed(3) },
    understoodRate: { early: +uEarly.toFixed(3), late: +uLate.toFixed(3) },
    probesPer100Turns: +probesPer100.toFixed(2),
    correctionsHeld: corr.length ? `${corr.filter((r) => r.retiredStayRetired).length}/${corr.length}` : "n/a",
    goalPersisted: goals.length ? `${goals.filter((r) => r.goalPersisted).length}/${goals.length}` : "n/a",
    activeBeliefs: +mean(results.map((r) => r.activeBeliefs)).toFixed(1),
    totalBeliefs: +mean(results.map((r) => r.totalBeliefs)).toFixed(1),
    observations: +mean(results.map((r) => r.observationsCount)).toFixed(0),
    graph: { nodes: +mean(results.map((r) => r.nodes)).toFixed(1), edges: +mean(results.map((r) => r.edges)).toFixed(1), invalidated: +mean(results.map((r) => r.invalidEdges)).toFixed(1) },
    welcomeBacks: +mean(results.map((r) => r.welcomeBacks)).toFixed(1),
    driftRecoverySessions: drift.length ? +mean(drift.map((r) => r.driftRecoverySessions!)).toFixed(1) : "n/a",
    strategyFitBeliefs: +mean(results.map((r) => r.firstDomainStrategyFitDomains.length)).toFixed(2),
    overclaimDetected: `${results.filter((r) => r.overclaimDetected).length}/${results.length}`,
    underclaimDetected: `${results.filter((r) => r.underclaimDetected).length}/${results.length}`,
  };
}

async function main() {
  const t0 = Date.now();
  const cohorts: { name: string; make: (seed: number) => ReturnType<typeof makeLearner> }[] = [
    { name: "baseline", make: (s) => makeLearner(s) },
    { name: "overconfident", make: (s) => makeLearner(s, { overconfidence: 0.9, topicSwitchProb: 0.05 }) },
    { name: "underconfident", make: (s) => makeLearner(s, { overconfidence: -0.9, topicSwitchProb: 0.05 }) },
    { name: "drift", make: (s) => makeLearner(s, { driftAtSession: Math.floor(SESSIONS / 2), articulates: false }) },
    { name: "correction", make: (s) => makeLearner(s, { correctionAtSession: Math.floor(SESSIONS / 2) }) },
    { name: "silent", make: (s) => makeLearner(s, { articulates: false, noise: 0.2 }) },
  ];
  const all: Record<string, Record<string, RunResult[]>> = {};
  for (const mode of MODES) {
    all[mode] = {};
    for (const c of cohorts) {
      const results: RunResult[] = [];
      for (let i = 0; i < N; i++) {
        const seed = 1000 * (cohorts.indexOf(c) + 1) + i;
        const l = c.make(seed);
        l.id = `${l.id}_${mode}`;
        const r = await runLearner(l, { sessions: SESSIONS, turnsPerSession: TURNS, gapHours: [2, 24, 72, 24 * 9, 3, 24 * 20, 24], mode });
        results.push(r);
        if (mode === "full" && i === 0) console.log(`  [${c.name}] hidden best in ${l.domains[0]}: ${bestStrategy(l, l.domains[0])}; fits learned: ${r.firstDomainStrategyFitDomains.join(", ") || "none"}; per-session best-rate: ${r.perSession.map((s) => s.bestRate.toFixed(2)).join(" ")}`);
      }
      all[mode][c.name] = results;
      console.log(`${mode.padEnd(14)} ${c.name.padEnd(14)}`, JSON.stringify(summarize(results)));
    }
  }
  console.log("\n=== OVERALL BY MODE ===");
  for (const mode of MODES) console.log(mode.padEnd(14), JSON.stringify(summarize(Object.values(all[mode]).flat())));
  console.log(`\nturns simulated: ${MODES.length * cohorts.length * N * SESSIONS * TURNS} in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  await pool.end();
}

main().catch((e) => { console.error(e); process.exit(1); });
