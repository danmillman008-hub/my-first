import "dotenv/config";
import { runTurn, challengeBelief } from "@/lib/agent";
import { OfflineProvider } from "@/lib/llm/offline";
import { buildTurnContext, loadLearnerMemory } from "@/lib/memory/retrieval";
import { db, pool } from "@/db";
import { beliefs, observations, graphEdges, researchNotes } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { mulberry32 } from "@/lib/memory/strategy";

const provider = new OfflineProvider();
const results: { name: string; pass: boolean; detail: string }[] = [];
const check = (name: string, pass: boolean, detail = "") => { results.push({ name, pass, detail }); console.log(`${pass ? "PASS" : "FAIL"}  ${name}${detail ? `  — ${detail}` : ""}`); };
const day = 86400000;
let clock = new Date("2026-02-01T10:00:00Z");
const tick = (ms = 3 * 60000) => (clock = new Date(clock.getTime() + ms));
const say = (id: string, text: string, rnd?: () => number) => runTurn({ learnerId: id, userMessage: text, now: tick(), provider, rnd, enableResearch: false });

async function main() {
  const rnd = mulberry32(42);
  const L = `adv_${Date.now()}`;

  // 1. Stated goal is a fact, not a hypothesis. Open domain accepted.
  await say(L, "I want to learn Spanish. How do verb conjugations work?");
  let mem = await loadLearnerMemory(L, clock);
  const goal = mem.beliefs.find((b) => b.kind === "goal");
  check("stated goal becomes active immediately", !!goal && goal.status === "active" && goal.source === "stated", goal?.statement);

  // 2. Duplicate evidence in one session must not inflate support.
  for (let i = 0; i < 5; i++) await say(L, "Can you show me an example? I like a concrete example.");
  mem = await loadLearnerMemory(L, clock);
  const pref = mem.beliefs.find((b) => b.key === "pref:worked_example");
  check("repeated identical request in one session counts once", !!pref && pref.supportCount === 1 && pref.status === "candidate", `support=${pref?.supportCount} status=${pref?.status}`);

  // 3. Independent evidence across sessions promotes candidate → active.
  tick(2 * day);
  await say(L, "Back to Spanish conjugation. Show me an example please.");
  mem = await loadLearnerMemory(L, clock);
  const pref2 = mem.beliefs.find((b) => b.key === "pref:worked_example" && b.domain === "spanish");
  check("second session's support promotes to active", !!pref2 && pref2.status === "active" && pref2.distinctSessions >= 2, `support=${pref2?.supportCount} sessions=${pref2?.distinctSessions} status=${pref2?.status}`);

  // 4. Contradiction is preserved, not overwritten: brief vs deep.
  await say(L, "Keep it short please, too long.");
  tick(1 * day);
  await say(L, "Spanish subjunctive — be brief.");
  mem = await loadLearnerMemory(L, clock);
  const brief = mem.beliefs.find((b) => b.key === "pref:brief" && b.domain === "spanish");
  check("brief preference active after two sessions", brief?.status === "active", brief?.status);
  await say(L, "Actually go deeper on the subjunctive, more detail please.");
  mem = await loadLearnerMemory(L, clock);
  const brief2 = mem.beliefs.find((b) => b.id === brief?.id);
  const deep = mem.beliefs.find((b) => b.key === "pref:deep" && b.domain === "spanish");
  check("opposite request contests (not deletes) prior preference", brief2?.status === "contested" && brief2.contradictionCount === 1 && deep?.status === "candidate", `brief=${brief2?.status}/${brief2?.contradictionCount} deep=${deep?.status}`);
  tick(1 * day);
  await say(L, "More detail on ser vs estar, go deeper.");
  mem = await loadLearnerMemory(L, clock);
  const brief3 = mem.beliefs.find((b) => b.id === brief?.id);
  const deep2 = mem.beliefs.find((b) => b.id === deep?.id);
  check("sustained contradiction retires old preference, history kept", brief3?.status === "retired" && !!brief3.invalidAt && deep2?.status === "active", `brief=${brief3?.status} deep=${deep2?.status}`);

  // 5. Context scope: preference in one domain does not become a general truth.
  const ctxOop = await buildTurnContext({ learnerId: L, userMessage: "Explain OOP inheritance to me", now: clock });
  const generalExample = mem.beliefs.find((b) => b.key === "pref:worked_example" && b.domain === null);
  const spanishExampleInfluence = ctxOop.beliefs.find((b) => b.key === "pref:worked_example" && b.domain === "spanish")?.influence ?? 0;
  const spanishExampleInSpanish = (await buildTurnContext({ learnerId: L, userMessage: "spanish conjugation", now: clock })).beliefs.find((b) => b.key === "pref:worked_example")?.influence ?? 0;
  check("domain-scoped preference has reduced influence in another domain", !generalExample && spanishExampleInfluence < spanishExampleInSpanish, `oop=${spanishExampleInfluence.toFixed(2)} spanish=${spanishExampleInSpanish.toFixed(2)}`);

  // 6. Self-report vs behaviour: overclaim emerges from evidence, retires when they agree.
  const M = `adv_over_${Date.now()}`;
  await say(M, "I want to learn bash. I understand this, pipes are easy. How do pipes work?");
  for (let i = 0; i < 4; i++) await say(M, "I tried the pipes example but it still fails with the same error. I understand this though, pipes are easy.");
  mem = await loadLearnerMemory(M, clock);
  const over = mem.beliefs.find((b) => b.key === "tendency:overclaims");
  const pipes = mem.conceptStates.find((c) => c.concept === "pipes");
  check("overclaiming tendency emerges from repeated failed attempts + confident self-report", !!over && (over.status === "candidate" || over.status === "active"), `p(known)=${pipes?.pKnown.toFixed(2)} attempts=${pipes?.attempts} belief=${over?.status}`);
  tick(2 * day);
  for (let i = 0; i < 6; i++) await say(M, "I tried the pipes task and it worked. I'm confident with pipes.");
  mem = await loadLearnerMemory(M, clock);
  const over2 = mem.beliefs.find((b) => b.id === over?.id);
  check("tendency belief is contested/retired once behaviour matches self-report", !!over2 && over2.status !== "active" && over2.contradictionCount > 0, `status=${over2?.status} for=${over2?.supportCount} against=${over2?.contradictionCount}`);

  // 7. Correction via memory panel retires and preserves evidence trail.
  const target = mem.beliefs.find((b) => b.id === over?.id)!;
  if (target && target.status !== "retired") await challengeBelief({ learnerId: M, beliefId: target.id, note: "That's not true about me", now: tick() });
  mem = await loadLearnerMemory(M, clock);
  const retired = mem.beliefs.find((b) => b.id === over?.id);
  const evidenceKept = (await db.select().from(observations).where(eq(observations.learnerId, M))).length;
  check("learner correction retires belief; evidence observations remain", retired?.status === "retired" && evidenceKept > 5, `status=${retired?.status} reason="${retired?.invalidReason}" observations=${evidenceKept}`);

  // 8. Stale memory → dormant after long gap; revived by new evidence.
  tick(200 * day);
  const back = await say(L, "Hola again! Let's continue Spanish, the preterite tense.");
  mem = await loadLearnerMemory(L, clock);
  const deepAfter = mem.beliefs.find((b) => b.id === deep?.id);
  const goalAfter = mem.beliefs.find((b) => b.id === goal?.id);
  check("200-day gap: inferred preference goes dormant, stated goal stays active (longer horizon)", deepAfter?.status === "dormant" && goalAfter?.status === "dormant" || (deepAfter?.status === "dormant" && goalAfter?.status === "active"), `deep=${deepAfter?.status} goal=${goalAfter?.status}`);
  check("returning after a long gap is acknowledged with continuity", back.isNewSession && /welcome back/i.test(back.reply) && /last time/i.test(back.reply), back.reply.slice(0, 90));
  await say(L, "Go deeper on the preterite, more detail.");
  mem = await loadLearnerMemory(L, clock);
  const revived = mem.beliefs.find((b) => b.id === deep?.id);
  check("dormant belief reactivates with fresh evidence", revived?.status === "active", revived?.status);

  // 9. Topic switch is free and observed.
  const sw = await say(L, "Actually, forget Spanish for a moment. Explain OOP inheritance to me.");
  const swObs = await db.select().from(observations).where(and(eq(observations.learnerId, L), eq(observations.kind, "topic_switch")));
  check("topic switch handled naturally and recorded", sw.meta.domain === "oop" && swObs.length >= 1, `domain=${sw.meta.domain} switches=${swObs.length}`);

  // 10. Graph: struggles_with invalidated when mastery improves (bi-temporal).
  const G = `adv_graph_${Date.now()}`;
  await say(G, "I want to learn sql. How do joins work?");
  for (let i = 0; i < 4; i++) await say(G, "My joins query still fails with the same error.");
  let edges = await db.select().from(graphEdges).where(and(eq(graphEdges.learnerId, G), eq(graphEdges.relation, "struggles_with")));
  const hadStruggle = edges.some((e) => !e.invalidAt);
  for (let i = 0; i < 7; i++) await say(G, "I fixed it, the joins query works now.");
  edges = await db.select().from(graphEdges).where(and(eq(graphEdges.learnerId, G), eq(graphEdges.relation, "struggles_with")));
  const grasped = await db.select().from(graphEdges).where(and(eq(graphEdges.learnerId, G), eq(graphEdges.relation, "has_grasped")));
  check("graph edge struggles_with is invalidated (kept) when behaviour improves; has_grasped appears", hadStruggle && edges.every((e) => e.invalidAt) && grasped.some((e) => !e.invalidAt), `struggle_edges=${edges.length} grasped=${grasped.length}`);

  // 11. Growth bounds: 400 noisy turns don't explode active memory; retrieval stays fast.
  const B = `adv_big_${Date.now()}`;
  const phrases = ["Show me an example of loops", "I'm confused about quoting", "That makes sense, what about redirection?", "Keep it short. Why do exit codes matter?", "I tried it and it worked", "Still fails with the same error on globbing", "Walk me through subshells step by step", "Actually forget bash. Explain OOP classes", "Just tell me directly about polymorphism", "I'm bad at encapsulation"];
  for (let i = 0; i < 400; i++) { if (i % 40 === 0) tick(3 * day); await say(B, phrases[Math.floor(rnd() * phrases.length)], rnd); }
  const t0 = Date.now();
  const bigCtx = await buildTurnContext({ learnerId: B, userMessage: "How do pipes work in bash?", now: clock });
  const retrievalMs = Date.now() - t0;
  mem = await loadLearnerMemory(B, clock);
  const activeN = mem.beliefs.filter((b) => b.status === "active" || b.status === "contested").length;
  check("400 turns: active beliefs bounded, context small, retrieval fast", activeN <= 25 && bigCtx.beliefs.length <= 24 && retrievalMs < 400, `active=${activeN} total=${mem.beliefs.length} ctxBeliefs=${bigCtx.beliefs.length} retrieval=${retrievalMs}ms`);
  check("probing stays rare under noise", (await db.select().from(observations).where(eq(observations.learnerId, B))).length > 100 && (bigCtx.probeAllowed ? 1 : 0) <= 1, "");

  // 12. Open-domain research (network permitting).
  try {
    const R = `adv_research_${Date.now()}`;
    await runTurn({ learnerId: R, userMessage: "I want to learn music theory. What is a chord?", now: tick(), provider, enableResearch: true });
    const notes = await db.select().from(researchNotes).where(eq(researchNotes.domain, "music"));
    check("unfamiliar domain triggers grounding research note", notes.length >= 1, notes[0]?.content.slice(0, 80) ?? "no network?");
  } catch (e) {
    check("unfamiliar domain triggers grounding research note", false, String(e));
  }

  const passed = results.filter((r) => r.pass).length;
  console.log(`\n${passed}/${results.length} checks passed`);
  await pool.end();
  process.exit(passed === results.length ? 0 : 1);
}

main().catch((e) => { console.error(e); process.exit(1); });
