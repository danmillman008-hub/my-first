# Your Tutor — a private, self-adapting learning agent

One tutor. One continuous relationship. You talk; it remembers what matters,
notices how you actually behave, adapts, and gets better at teaching *you*.

## Running

```bash
npm run build && npm start          # http://localhost:3000
```

Environment (`.env`):

| var | purpose |
| --- | --- |
| `DATABASE_URL` | PostgreSQL (required) |
| `OPENAI_API_KEY` | enables the real model path (optional — without it a deterministic offline provider runs) |
| `OPENAI_MODEL` | default `gpt-4o-mini` |
| `OPENAI_BASE_URL` | any OpenAI-compatible endpoint |

Schema: `npx drizzle-kit push`.

## Architecture (the complexity lives behind the conversation)

```
learner message
  └─ buildTurnContext        (src/lib/memory/retrieval.ts)
       session continuity (time-gap based), prior session summaries
       beliefs ranked by INFLUENCE = confidence × status × recency × scope
       concept states (behaviour vs self-report), recent raw observations
       strategy evidence → contextual Thompson sampling (strategy.ts)
       probe policy (rare; only when uncertainty matters for THIS message)
  └─ research if the domain is unfamiliar   (src/lib/research.ts)
  └─ provider.turn()         (src/lib/llm/openai.ts | offline.ts)
       reply + strategy + extracted observations + reaction to last turn
       + belief feedback + learner corrections   (strict JSON, validated)
       heuristic safety net: goals / corrections / requests are never dropped
  └─ consolidateTurn         (src/lib/memory/consolidate.ts)
       observations (short-term, never deleted, deduped per session)
       strategy outcome for the PREVIOUS reply (what actually worked)
       concept states (BKT) — self-report tracked separately from behaviour
       beliefs: candidate → active → contested → dormant/retired (bi-temporal)
       strategy-fit beliefs derived from outcomes, per domain
       graph: nodes + weighted edges that are invalidated, never deleted
  └─ traces (every decision and why)
```

### Two timescales

* **Observations** — broad, lightly interpreted evidence (`statement`, `question`,
  `self_report`, `success`, `mistake`, `reaction`, `request`, `topic_switch`,
  `correction`, `code_shared`, `context`). An observation can stay just an
  observation forever.
* **Beliefs** — claims that *earned* durability. Inferred beliefs need ≥2
  independent supports (different sessions) to become active. Stated goals and
  context are facts (`source: stated`) and are active immediately — they are not
  hypotheses. Every belief keeps provenance (`belief_evidence` → observations),
  support/contradiction counts, a scope (`domain`), `valid_from` / `invalid_at`,
  an `invalid_reason` and `superseded_by`.

### Memory is a prior, not a verdict

* Opposite evidence **contests** a belief first (both sides kept); sustained
  contradiction retires it; a learner correction retires it immediately with the
  evidence intact. Retired beliefs remain inspectable history.
* Long-unconfirmed inferred beliefs go **dormant** (low influence), and are revived
  by fresh support. Nothing is decayed into oblivion.
* Preferences are scoped by domain; a general belief is only created when the same
  preference is active in ≥2 domains. Observed strategy-fit never leaks across
  domains (the shrunk global prior carries cross-domain information instead).
* Self-report and demonstrated behaviour are stored separately; a durable
  discrepancy becomes an *observed tendency* that retires itself once they agree.

### Learning what works

Each reply records `strategy × domain`; the learner's next message is judged
(understood / confused / disagreed / succeeded / failed) and stored as an outcome.
Selection is discounted Thompson sampling (per-outcome discount γ=0.92 + slow
wall-clock decay, pseudo-count cap) with a hierarchical prior (global → domain),
preference-belief priors, sample-based hysteresis (no oscillation) and a change
detector that contests a "works well" belief after a run of failures.

### Inspectable & correctable

The right-hand panel shows working beliefs with status, confidence, evidence trail
("why I think this"), concept evidence, raw observations, session summaries and the
graph. "That's not true about me" retires a belief (evidence kept) and optionally
records what is true instead. `GET/POST /api/memory`.

### MCP

`/api/mcp` is a Streamable-HTTP MCP server exposing the *same* learner model:
`get_learner_context`, `tutor_turn`, `record_observation`, `list_beliefs`,
`challenge_belief`.

## Evidence (evaluation harness)

```bash
npx tsx scripts/sim/run.ts 6 8 10 full,no_long_term,no_adaptation   # cohorts × sessions × turns × modes
npx tsx scripts/sim/adversarial.ts                                   # 18 failure-class checks
npx tsx scripts/sim/transcript.ts                                    # qualitative multi-session transcript
```

Synthetic learners have hidden ground truth the agent never sees: per-domain
strategy affinities, over/under-confidence, noise, articulate vs silent,
preference drift mid-history, topic switching, a scripted correction. Sessions
are separated by simulated gaps of hours to weeks.

Findings that shaped the implementation (all discovered by the harness):

* A stale-`lastAssistant` bug fed the selector the *oldest* turn's strategy.
* Selecting before parsing the learner's reaction made adaptation one turn late.
* Un-discounted posteriors never recovered from preference drift (late best-rate
  0.01) → discounted Thompson sampling (recovery in ~1–2 sessions).
* Task failures attributed at full weight to the last strategy drowned the real
  signal (mastery confound) → half weight for strategy, full weight for concepts.
* Correction messages quoting the belief re-created it → corrections are not
  fresh preference evidence; fit beliefs re-derive only from post-correction data.
* An `unfit` belief learned in OOP leaked into Bash → strategy fit is strictly
  domain-scoped.

Ablations (chance best-strategy rate = 0.17): `no_adaptation` stays flat at ≈0.2;
`full` rises from ≈0.3 to ≈0.5 across 8 sessions with a corresponding rise in
understood-rate; `no_long_term` (bandit only) lands below `full`, showing the
belief layer adds value beyond the bandit. Active beliefs stay bounded (≈5–9 after
80 turns; ≤15 after 400 noisy turns), probing stays ≈6 per 100 turns, goals persist
across 2 months of simulated time, and drift recovers.
