/**
 * Behavioural verification of the self-adapting learning agent.
 * Run: npx tsx scripts/verify.ts <phase>
 * Phases: goal | adapt | remediate | revise | affect | domain | all
 */
import "dotenv/config";
import { db } from "../src/db";
import { goals, decisions, conceptEdges, concepts } from "../src/db/schema";
import { and, desc, eq, inArray } from "drizzle-orm";
import { handleTurn } from "../src/agent/agent";
import { ensureLearner, getStrategyStats, learnerSnapshot, getMasteryMap, getAffect } from "../src/agent/core";
import type { PendingExercise } from "../src/db/schema";

let failures = 0;
function check(cond: unknown, msg: string) {
  console.log(`${cond ? "  ✅" : "  ❌"} ${msg}`);
  if (!cond) failures++;
}

async function goalOf(learnerId: number) {
  const [g] = await db.select().from(goals).where(and(eq(goals.learnerId, learnerId), eq(goals.status, "active"))).orderBy(desc(goals.createdAt)).limit(1);
  return g;
}
async function decisionTypes(learnerId: number) {
  return (await db.select().from(decisions).where(eq(decisions.learnerId, learnerId)).orderBy(desc(decisions.id))).map((d) => d.type);
}

function correctAnswer(p: PendingExercise): string {
  if (p.type === "explain") return `${p.answer} In other words it involves ${(p.accept ?? []).slice(0, 6).join(", ")}, which is why you would use it.`;
  return p.answer;
}
function wrongAnswer(p: PendingExercise): string {
  if (p.options?.length) return p.options.find((o) => o !== p.answer) ?? "none of these";
  if (p.type === "explain") return "It is a thing in programming that does stuff.";
  return "banana";
}

/** Learner who only understands example-style lessons. */
async function simulateExampleLearner(learnerId: number, turns: number) {
  const log: { strategy: string; correct: boolean; type: string }[] = [];
  for (let i = 0; i < turns; i++) {
    const g = await goalOf(learnerId);
    if (!g?.state.pending) {
      await handleTurn(learnerId, "continue");
      continue;
    }
    const p = g.state.pending;
    const good = p.strategy === "example";
    const r = await handleTurn(learnerId, good ? correctAnswer(p) : wrongAnswer(p));
    log.push({ strategy: p.strategy, correct: good, type: p.type });
    if (r.actions.some((a) => a.startsWith("teach:")) && i % 5 === 0) process.stdout.write(`    turn ${i}: ${r.actions.join(" | ")}\n`);
  }
  return log;
}

async function phaseGoal(name: string) {
  console.log("\n[goal] research → knowledge representation → diagnostic");
  const learner = await ensureLearner(name);
  const t0 = Date.now();
  const r = await handleTurn(learner.id, "I want to learn Object-Oriented Programming");
  console.log(`    (${Date.now() - t0} ms) ${r.actions.join(" | ")}`);
  const g = await goalOf(learner.id);
  check(g && g.topic.toLowerCase().includes("object"), "goal created from natural-language intent");
  check(g && g.plan.length >= 6, `plan has ${g?.plan.length ?? 0} concepts (≥6)`);
  check(g?.state.phase === "diagnostic", "agent asks a diagnostic question before teaching");
  const edges = g ? await db.select().from(conceptEdges).where(and(inArray(conceptEdges.toConceptId, g.plan), eq(conceptEdges.type, "prerequisite"))) : [];
  check(edges.length >= 3, `prerequisite edges inferred: ${edges.length} (≥3)`);
  // plan order respects prerequisites
  let ordered = true;
  if (g) for (const e of edges) if (g.plan.includes(e.fromConceptId) && g.plan.includes(e.toConceptId) && g.plan.indexOf(e.fromConceptId) > g.plan.indexOf(e.toConceptId)) ordered = false;
  check(ordered, "learning path is topologically consistent with prerequisites");
  const rows = g ? await db.select().from(concepts).where(inArray(concepts.id, g.plan)) : [];
  check(rows.some((c) => c.discoveredBy === "prerequisite-discovery"), `foundational prerequisite discovered outside the article: ${rows.filter((c) => c.discoveredBy === "prerequisite-discovery").map((c) => c.name).join(", ") || "none"}`);
  console.log("    plan:", g?.plan.map((id) => rows.find((c) => c.id === id)?.name).join(" → "));
  check(/which of these/i.test(r.reply), "reply asks the learner for a self-assessment");
  return learner.id;
}

async function phaseAdapt(learnerId: number) {
  console.log("\n[adapt] learner only understands examples → agent should learn that");
  const r = await handleTurn(learnerId, "none, start from scratch");
  check(r.actions.some((a) => a.startsWith("diagnostic:none")), "self-report interpreted as priors");
  const g = await goalOf(learnerId);
  check(g?.state.phase === "teaching" && !!g.state.pending, "teaching started with a pending exercise");
  const before = await getStrategyStats(learnerId);
  const log = await simulateExampleLearner(learnerId, 22);
  const after = await getStrategyStats(learnerId);
  const mean = (s: { alpha: number; beta: number }) => s.alpha / (s.alpha + s.beta);
  console.log("    strategy posteriors:", Object.fromEntries(Object.entries(after).map(([k, v]) => [k, `${mean(v).toFixed(2)} (${v.successes}/${v.trials})`])));
  check(mean(after.example) > mean(before.example), "posterior for 'example' increased with evidence");
  check(mean(after.example) > mean(after.detailed) && mean(after.example) > mean(after.concise), "'example' now ranks above 'detailed' and 'concise'");
  const firstHalf = log.slice(0, Math.floor(log.length / 2)).filter((l) => l.strategy === "example").length / Math.max(1, Math.floor(log.length / 2));
  const secondHalf = log.slice(Math.floor(log.length / 2)).filter((l) => l.strategy === "example").length / Math.max(1, log.length - Math.floor(log.length / 2));
  console.log(`    share of example-style lessons: first half ${(firstHalf * 100).toFixed(0)}% → second half ${(secondHalf * 100).toFixed(0)}%`);
  check(secondHalf >= firstHalf, "agent shifted its behaviour toward the strategy that works");
  const types = await decisionTypes(learnerId);
  check(types.includes("strategy_switch"), "agent switched strategy after a failed explanation");
  check(types.includes("concept_mastered"), "at least one concept reached mastery from evidence");
  const snap = await learnerSnapshot(learnerId);
  check((snap?.evidenceCount ?? 0) > 20, `evidence persisted (${snap?.evidenceCount} records)`);
  const mastered = snap?.concepts.filter((c) => c.mastered).map((c) => c.name) ?? [];
  console.log("    mastered:", mastered.join(", ") || "none");
}

async function phaseRemediate(name: string) {
  console.log("\n[remediate] learner who always fails → prerequisite remediation / discovery");
  const learner = await ensureLearner(name);
  await handleTurn(learner.id, "teach me object-oriented programming");
  await handleTurn(learner.id, "none");
  for (let i = 0; i < 5; i++) {
    const g = await goalOf(learner.id);
    if (!g?.state.pending) {
      await handleTurn(learner.id, "continue");
      continue;
    }
    const ts = Date.now();
    const r = await handleTurn(learner.id, wrongAnswer(g.state.pending));
    console.log(`    turn ${i} (${Date.now() - ts} ms): ${r.actions.join(" | ")}`);
  }
  const types = await decisionTypes(learner.id);
  check(types.includes("strategy_switch"), "first failure → strategy switch");
  check(types.includes("remediate_prerequisite") || types.includes("discover_prerequisite") || types.includes("simplify"), `repeated failure → re-planning (${types.filter((t) => ["remediate_prerequisite", "discover_prerequisite", "simplify"].includes(t)).join(", ")})`);
  const affect = await getAffect(learner.id);
  check(affect.frustration > 0.3, `frustration inferred from repeated failure (${affect.frustration.toFixed(2)})`);
  const g = await goalOf(learner.id);
  const rows = g ? await db.select().from(concepts).where(inArray(concepts.id, g.plan)) : [];
  const discovered = rows.filter((c) => c.discoveredBy === "prerequisite-discovery" || c.discoveredBy === "llm-agent");
  console.log("    graph now contains discovered concepts:", discovered.map((c) => c.name).join(", ") || "none");
  return learner.id;
}

async function phaseRevise(name: string) {
  console.log("\n[revise] learner over-claims mastery → beliefs revised by evidence");
  const learner = await ensureLearner(name);
  await handleTurn(learner.id, "I want to learn object oriented programming");
  const g0 = await goalOf(learner.id);
  const mmBefore = await getMasteryMap(learner.id, g0!.plan);
  await handleTurn(learner.id, "all of them, I know most of this");
  const mm = await getMasteryMap(learner.id, g0!.plan);
  const p0 = [...mm.values()].filter((m) => m.conceptId !== g0!.rootConceptId).map((m) => m.pKnown);
  check(p0.every((p) => p >= 0.55) && mmBefore.size === 0, "self-reported mastery stored as prior (p≈0.6) with no evidence");
  const g1 = await goalOf(learner.id);
  const cid = g1!.state.pending!.conceptId;
  await handleTurn(learner.id, wrongAnswer(g1!.state.pending!));
  const g2 = await goalOf(learner.id);
  if (g2?.state.pending?.conceptId === cid) await handleTurn(learner.id, wrongAnswer(g2.state.pending));
  const after = (await getMasteryMap(learner.id, [cid])).get(cid)!;
  check(after.pKnown < 0.5, `belief lowered after contradicting evidence: 0.60 → ${after.pKnown.toFixed(2)}`);
  check(after.source === "observed" && after.attempts >= 1, "mastery now grounded in observation, not self-report");
  const types = await decisionTypes(learner.id);
  check(types.includes("belief_revised"), "decision log records the belief revision explicitly");
}

async function phaseAffect(learnerId: number) {
  console.log("\n[affect+preference] explicit signals are captured and used");
  const r1 = await handleTurn(learnerId, "ugh this is so frustrating, I don't get it at all");
  const a = await getAffect(learnerId);
  check(a.frustration > 0.35 && a.confusion > 0.3, `frustration ${a.frustration.toFixed(2)} / confusion ${a.confusion.toFixed(2)} inferred from text`);
  check(r1.actions.includes("intent:reteach"), "confusion statement triggers re-teaching");
  check(/frustrating|simpler|slow down|piece at a time/i.test(r1.reply), "reply acknowledges affect");
  const r2 = await handleTurn(learnerId, "can you give me an example instead?");
  const g = await goalOf(learnerId);
  check(g?.state.pending?.strategy === "example" && r2.actions.includes("preference:example"), "explicit style request honoured and stored as preference");
  const snap = await learnerSnapshot(learnerId);
  check(snap?.preferences.some((p) => p.key === "explanation_style" && p.value === "example"), "preference persisted in learner model");
  const r3 = await handleTurn(learnerId, "status");
  check(/What works for you/.test(r3.reply), "status report exposes the learner model in plain language");
}

async function phaseDomain(learnerId: number) {
  console.log("\n[open-domain] a different subject + a learner question outside the graph");
  const t0 = Date.now();
  const r = await handleTurn(learnerId, "Teach me how photosynthesis works");
  console.log(`    (${Date.now() - t0} ms) ${r.actions.join(" | ")}`);
  const g = await goalOf(learnerId);
  check(g && /photosynthesis/i.test(g.topic) && g.plan.length >= 5, `new domain researched: ${g?.plan.length} concepts`);
  const rows = g ? await db.select().from(concepts).where(inArray(concepts.id, g.plan)) : [];
  console.log("    plan:", rows.map((c) => c.name).join(", "));
  check(rows.every((c) => c.summary.length > 50), "every concept has teachable material");
  await handleTurn(learnerId, "none");
  const q = await handleTurn(learnerId, "what is a chloroplast?");
  check(q.actions.some((a) => a.startsWith("question:")), `learner question handled (${q.actions.find((a) => a.startsWith("question:"))})`);
  const types = await decisionTypes(learnerId);
  check(types.includes("answered_question"), "question answered and logged");
}

(async () => {
  const phase = process.argv[2] ?? "all";
  const tag = process.argv[3] ?? String(Date.now()).slice(-6);
  const nameA = `verify-a-${tag}`;
  const t0 = Date.now();
  if (phase === "goal" || phase === "all") await phaseGoal(nameA);
  if (phase === "adapt" || phase === "all") await phaseAdapt((await ensureLearner(nameA)).id);
  if (phase === "remediate" || phase === "all") await phaseRemediate(`verify-b-${tag}`);
  if (phase === "revise" || phase === "all") await phaseRevise(`verify-c-${tag}`);
  if (phase === "affect" || phase === "all") await phaseAffect((await ensureLearner(nameA)).id);
  if (phase === "domain" || phase === "all") await phaseDomain((await ensureLearner(nameA)).id);
  console.log(`\n${failures === 0 ? "ALL CHECKS PASSED" : `${failures} CHECK(S) FAILED`} in ${Date.now() - t0} ms`);
  process.exit(failures ? 1 : 0);
})().catch((e) => {
  console.error("VERIFY CRASHED", e);
  process.exit(2);
});
