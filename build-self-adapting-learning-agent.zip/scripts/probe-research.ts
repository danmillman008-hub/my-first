import { researchDomain } from "../src/agent/research";
const topic = process.argv[2] ?? "Object-Oriented Programming";
const t0 = Date.now();
researchDomain(topic, { log: (m) => console.log("  ·", m) }).then((r) => {
  if (!r) { console.log("NO RESULT"); return; }
  console.log("root:", r.root.title, "| difficulty", r.root.difficulty.toFixed(2), "| sections", r.root.sections.length, "| examples", r.root.examples.length);
  for (const c of [...r.concepts, ...r.foundational]) console.log(` - ${c.title} [${c.description}] diff=${c.difficulty.toFixed(2)} links=${c.links.length} terms=${c.keyTerms.slice(0,5).join("/")} ex=${c.examples.length}`);
  console.log("prereqs:");
  for (const p of r.prerequisites.filter(p=>p.method!=="part-of-goal")) console.log(`   ${p.from} -> ${p.to} (${p.weight.toFixed(2)}, ${p.method})`);
  console.log("elapsed", Date.now()-t0, "ms");
});
