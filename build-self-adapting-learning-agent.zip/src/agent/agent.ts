/**
 * THE AGENT – flexible intelligence that understands, researches, plans,
 * teaches, diagnoses, adapts and re-plans, while writing every learner-relevant
 * observation into the adaptive core.
 */
import { db } from "@/db";
import { eq } from "drizzle-orm";
import { goals, type GoalState, type PendingExercise } from "@/db/schema";
import {
  STRATEGIES,
  MASTERY_THRESHOLD,
  type Strategy,
  activeGoal,
  addMessage,
  chooseStrategy,
  getAffect,
  getLearner,
  getMastery,
  getMasteryMap,
  getPreferences,
  getStrategyStats,
  inferAffectFromText,
  learnerSnapshot,
  masteryUncertainty,
  observeMastery,
  recentMessages,
  recordDecision,
  recordEvidence,
  setMasteryPrior,
  setPreference,
  updateAffect,
  updateStrategyOutcome,
} from "./core";
import {
  addEdge,
  buildDomain,
  discoverMissingPrerequisites,
  ensureEnriched,
  findConceptByName,
  getConcept,
  getConcepts,
  nextConcept,
  orderPlan,
  prerequisiteEdges,
  upsertConcept,
  type ConceptRow,
} from "./graph";
import { GUESS_RATE, composeLesson, generateExercise, gradeAnswer, pickExerciseType } from "./pedagogy";
import { conceptStem, researchConcept } from "./research";
import { chatJson, llmAvailable, runToolLoop } from "./llm";

type GoalRow = typeof goals.$inferSelect;
type ExtendedState = GoalState & { attempts?: Record<string, number>; skipped?: number[] };

export type TurnResult = { reply: string; goalId: number | null; actions: string[] };

type Intent =
  | { kind: "new_goal"; topic: string }
  | { kind: "answer" }
  | { kind: "continue" }
  | { kind: "skip" }
  | { kind: "request_style"; style: Strategy }
  | { kind: "reteach" }
  | { kind: "quiz" }
  | { kind: "status" }
  | { kind: "pause" }
  | { kind: "ask_concept"; name: string }
  | { kind: "chat" };

const display = (c: ConceptRow) => c.name.replace(/\s*\(.*\)$/, "");

// ---------------------------------------------------------------------------
// Intent understanding
// ---------------------------------------------------------------------------
function cleanTopic(t: string): string {
  return t
    .trim()
    .replace(/^(the basics of|basics of|the fundamentals of|fundamentals of|about)\s+/i, "")
    .replace(/\s+(works?|functions?|in depth|properly|from scratch|please|today)$/i, "")
    .replace(/[.!?]+$/, "")
    .trim();
}

function classifyIntentHeuristic(text: string, hasPending: boolean, hasGoal: boolean): Intent {
  const t = text.trim();
  const goalRe =
    /^(?:hi|hello|hey)?[,.! ]*(?:i(?:'d| would)? (?:want|like|need|wish) to|help me|teach me|can you teach me|let'?s|i'?m trying to|show me how to|i want to get better at|please teach me|learn)\s*(?:learn|understand|study|master|get better at|about|how to)?\s*(?:about\s+|how\s+)?(.{3,80}?)[.!?]*$/i;
  const gm = goalRe.exec(t);
  if (gm && !/^(next|continue|skip|more|it|this|that|again)$/i.test(gm[1].trim())) return { kind: "new_goal", topic: cleanTopic(gm[1]) };
  if (/^(learn|study|topic|goal):\s*(.+)$/i.test(t)) return { kind: "new_goal", topic: /^(?:learn|study|topic|goal):\s*(.+)$/i.exec(t)![1].trim() };
  if (/\b(status|progress|how am i doing|what do you know about me|my model|learner model)\b/i.test(t)) return { kind: "status" };
  if (/\b(take a break|need a break|stop for (now|today)|pause|done for today|enough for today)\b/i.test(t)) return { kind: "pause" };
  if (/^(skip|skip (this|it)|move on|next topic|next concept)\b/i.test(t)) return { kind: "skip" };
  if (/\b(give me|show me|can i (get|have)|another|an?|more)\s+(concrete\s+)?examples?\b|\bexamples? (please|instead)\b/i.test(t)) return { kind: "request_style", style: "example" };
  if (/\b(step[- ]by[- ]step|break it down|smaller steps|slower|one step at a time)\b/i.test(t)) return { kind: "request_style", style: "step_by_step" };
  if (/\b(analogy|metaphor|compare it to)\b/i.test(t)) return { kind: "request_style", style: "analogy" };
  if (/\b(more detail|in depth|elaborate|go deeper|detailed|why does|why is)\b/i.test(t) && !hasPending) return { kind: "request_style", style: "detailed" };
  if (/\b(shorter|brief(ly)?|summar(y|ize)|tl;?dr|concise|too long|just the gist)\b/i.test(t)) return { kind: "request_style", style: "concise" };
  if (/\b(explain (it |that |this )?(differently|again|another way)|didn'?t (get|understand|follow)|i don'?t (get|understand|follow)|confus|lost|makes no sense|what do you mean|huh\??)\b/i.test(t)) return { kind: "reteach" };
  if (/^(quiz me|test me|give me a question|question please|practice)\b/i.test(t)) return { kind: "quiz" };
  const ask = /^(?:so\s+)?what(?:'s| is| are| does)\s+(?:an?\s+|the\s+)?(.{2,60}?)(?:\s+mean)?\??$/i.exec(t) ?? /^(?:explain|define|tell me about)\s+(.{2,60}?)[.?!]*$/i.exec(t);
  if (ask && (!hasPending || /\?$/.test(t) || /^(explain|define|tell me about)/i.test(t))) return { kind: "ask_concept", name: ask[1].trim() };
  if (hasPending) return { kind: "answer" };
  if (ask) return { kind: "ask_concept", name: ask[1].trim() };
  if (/^(next|continue|go on|ok(ay)?|ready|yes|start|begin|let'?s go|sure|go|yep|yeah|proceed)[.! ]*$/i.test(t)) return { kind: "continue" };
  if (!hasGoal && t.split(/\s+/).length <= 6) return { kind: "new_goal", topic: t.replace(/[.!?]+$/, "") };
  return { kind: "chat" };
}

async function classifyIntent(text: string, hasPending: boolean, hasGoal: boolean): Promise<Intent> {
  const heuristic = classifyIntentHeuristic(text, hasPending, hasGoal);
  if (!llmAvailable() || heuristic.kind === "answer") return heuristic;
  const res = await chatJson<{ kind: string; topic?: string; style?: string; name?: string }>(
    `Classify the learner's message for a tutoring agent. kinds: new_goal(topic), answer, continue, skip, request_style(style in ${STRATEGIES.join("|")}), reteach, quiz, status, pause, ask_concept(name), chat. ` +
      `Context: pending exercise=${hasPending}, active goal=${hasGoal}. If there is a pending exercise and the message could be an answer, choose answer.`,
    text,
  );
  if (!res) return heuristic;
  switch (res.kind) {
    case "new_goal":
      return res.topic ? { kind: "new_goal", topic: res.topic } : heuristic;
    case "request_style":
      return STRATEGIES.includes(res.style as Strategy) ? { kind: "request_style", style: res.style as Strategy } : heuristic;
    case "ask_concept":
      return res.name ? { kind: "ask_concept", name: res.name } : heuristic;
    case "answer":
    case "continue":
    case "skip":
    case "reteach":
    case "quiz":
    case "status":
    case "pause":
    case "chat":
      return { kind: res.kind } as Intent;
    default:
      return heuristic;
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
async function saveGoal(goal: GoalRow, patch: Partial<Pick<GoalRow, "plan" | "status" | "state">>): Promise<GoalRow> {
  const [row] = await db
    .update(goals)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(goals.id, goal.id))
    .returning();
  return row;
}

function affectPreface(a: { frustration: number; confusion: number; fatigue: number; engagement: number }): string {
  if (a.frustration > 0.5) return "I can tell this has been frustrating — that's a normal part of learning something new. Let's take a simpler angle.\n\n";
  if (a.fatigue > 0.5) return "You seem a bit tired, so I'll keep this one short. A break after this is a good idea.\n\n";
  if (a.confusion > 0.45) return "Let's slow down and rebuild this one piece at a time.\n\n";
  return "";
}

async function conceptAttempt(state: ExtendedState, conceptId: number, bump: boolean): Promise<number> {
  state.attempts = state.attempts ?? {};
  if (bump) state.attempts[String(conceptId)] = (state.attempts[String(conceptId)] ?? 0) + 1;
  return state.attempts[String(conceptId)] ?? 0;
}

// ---------------------------------------------------------------------------
// Main turn handler
// ---------------------------------------------------------------------------
export async function handleTurn(learnerId: number, message: string): Promise<TurnResult> {
  const learner = await getLearner(learnerId);
  if (!learner) throw new Error("learner not found");
  const actions: string[] = [];
  const history = await recentMessages(learnerId, 6);
  const lastAssistant = [...history].reverse().find((m) => m.role === "assistant");
  const secondsSinceLast = lastAssistant ? (Date.now() - new Date(lastAssistant.createdAt).getTime()) / 1000 : undefined;

  let goal = await activeGoal(learnerId);
  await addMessage(learnerId, "user", message, {}, goal?.id);

  // --- affect observation --------------------------------------------------
  const { delta, signals } = inferAffectFromText(message, secondsSinceLast);
  let affect = await updateAffect(learnerId, delta);
  if (signals.length) {
    await recordEvidence(learnerId, "affect_signal", { signals, delta, secondsSinceLast }, goal?.id, goal?.state.currentConceptId);
    actions.push(`affect:${signals.join("+")}`);
  }

  const state = (goal?.state ?? { phase: "diagnostic", failStreak: 0, failedStrategies: [], taughtCount: 0 }) as ExtendedState;
  const intent = await classifyIntent(message, !!state.pending, !!goal);
  actions.push(`intent:${intent.kind}`);

  let reply = "";
  const meta: Record<string, unknown> = { intent: intent.kind };

  try {
    if (intent.kind === "new_goal") {
      const r = await startGoal(learnerId, message, intent.topic, actions);
      reply = r.reply;
      goal = r.goal;
    } else if (intent.kind === "status") {
      reply = await statusReport(learnerId);
    } else if (!goal) {
      reply =
        `Hi ${learner.name}! Tell me what you'd like to learn — anything, in your own words. For example:\n\n` +
        `- "I want to learn Object-Oriented Programming"\n- "Teach me how photosynthesis works"\n- "Help me understand Bayesian statistics"\n\n` +
        `I'll research the subject, map out the concepts and prerequisites, find out what you already know, and adapt to how you learn best.`;
    } else if (state.phase === "diagnostic") {
      reply = await handleDiagnostic(learnerId, goal, state, message, affect, actions);
    } else {
      switch (intent.kind) {
        case "answer": {
          reply = await handleAnswer(learnerId, goal, state, message, actions);
          break;
        }
        case "request_style": {
          await setPreference(learnerId, "explanation_style", intent.style, 0.8);
          if (state.lastStrategy && state.lastStrategy !== intent.style) await updateStrategyOutcome(learnerId, state.lastStrategy, false, 0.5);
          await recordEvidence(learnerId, "style_request", { requested: intent.style, previous: state.lastStrategy }, goal.id, state.currentConceptId);
          await recordDecision(learnerId, "style_requested", `Learner asked for ${intent.style}; recorded preference (0.8) and a soft negative outcome for "${state.lastStrategy ?? "none"}".`, { style: intent.style }, goal.id);
          actions.push(`preference:${intent.style}`);
          reply = await teach(learnerId, goal, state, actions, { conceptId: state.currentConceptId, requested: intent.style, reason: "learner requested a different explanation style" });
          break;
        }
        case "reteach": {
          if (state.lastStrategy) {
            await updateStrategyOutcome(learnerId, state.lastStrategy, false, 0.7);
            if (!state.failedStrategies.includes(state.lastStrategy)) state.failedStrategies.push(state.lastStrategy);
          }
          affect = await updateAffect(learnerId, { confusion: 0.2 }, 1);
          await recordEvidence(learnerId, "confusion_reported", { strategy: state.lastStrategy }, goal.id, state.currentConceptId);
          reply = await teach(learnerId, goal, state, actions, { conceptId: state.currentConceptId, reason: `learner reported not understanding the "${state.lastStrategy}" explanation` });
          break;
        }
        case "skip": {
          if (state.currentConceptId) {
            state.skipped = [...new Set([...(state.skipped ?? []), state.currentConceptId])];
            await recordDecision(learnerId, "concept_skipped", `Learner chose to skip; concept kept in review queue with unchanged belief.`, { conceptId: state.currentConceptId }, goal.id);
          }
          state.pending = undefined;
          reply = await teach(learnerId, goal, state, actions, { reason: "learner skipped the current concept" });
          break;
        }
        case "quiz": {
          reply = await askOnly(learnerId, goal, state, actions);
          break;
        }
        case "pause": {
          state.pending = undefined;
          await saveGoal(goal, { state });
          reply = (await statusReport(learnerId)) + "\n\nTake your time — say **continue** whenever you're ready and we'll pick up exactly where we left off.";
          break;
        }
        case "ask_concept": {
          reply = await answerQuestion(learnerId, goal, state, intent.name, actions);
          break;
        }
        case "continue":
        case "chat":
        default: {
          if (state.pending) {
            reply = `Whenever you're ready — here's the question again:\n\n${state.pending.prompt}`;
          } else {
            reply = await teach(learnerId, goal, state, actions, { reason: "learner asked to continue" });
          }
        }
      }
    }
  } catch (err) {
    console.error("agent error", err);
    reply = `Something went wrong while I was working on that (${(err as Error).message}). Your progress is saved — try again or say **continue**.`;
  }

  await addMessage(learnerId, "assistant", reply, meta, goal?.id);
  return { reply, goalId: goal?.id ?? null, actions };
}

// ---------------------------------------------------------------------------
// Goal creation: research → knowledge representation → diagnostic
// ---------------------------------------------------------------------------
async function startGoal(learnerId: number, text: string, topic: string, actions: string[]): Promise<{ reply: string; goal: GoalRow }> {
  const prev = await activeGoal(learnerId);
  if (prev) await saveGoal(prev, { status: "paused" });
  const notes: string[] = [];
  const built = await buildDomain(topic, (m) => notes.push(m));
  if (!built) {
    const [g] = await db.insert(goals).values({ learnerId, text, topic, status: "active", plan: [], state: { phase: "teaching", failStreak: 0, failedStrategies: [], taughtCount: 0 } }).returning();
    await recordDecision(learnerId, "research_failed", `Could not locate a reliable source for "${topic}".`, { notes }, g.id);
    return { reply: `I couldn't find reliable material on "${topic}" right now. Could you phrase the subject differently (e.g. a more standard name)?`, goal: g };
  }
  const { root, plan } = built;
  const [g] = await db
    .insert(goals)
    .values({ learnerId, text, topic, rootConceptId: root.id, status: "active", plan, state: { phase: "diagnostic", failStreak: 0, failedStrategies: [], taughtCount: 0 } })
    .returning();
  actions.push(`research:${plan.length}`);
  await recordDecision(learnerId, "goal_created", `Researched "${topic}" and built a ${plan.length}-concept learning path rooted at "${root.name}".`, { notes, plan, rootConceptId: root.id }, g.id);
  await recordEvidence(learnerId, "goal_stated", { text, topic }, g.id);

  // LLM (if present) may refine ordering/prerequisites with its own knowledge – graph stays the source of truth.
  await refinePlanWithLLM(learnerId, g, root);
  const fresh = (await db.select().from(goals).where(eq(goals.id, g.id)))[0];
  const cmap = await getConcepts(fresh.plan);
  const names = fresh.plan.filter((id) => id !== root.id).map((id) => cmap.get(id)?.name ?? "").filter(Boolean);
  const disc = built.research?.foundational.map((f) => f.title) ?? [];
  const reply =
    `Great — let's learn **${display(root)}**.\n\n` +
    `I researched the subject and mapped ${names.length} concepts with their prerequisites` +
    (disc.length ? ` (I also noticed the material presupposes **${disc.join("** and **")}**, so I added ${disc.length > 1 ? "those" : "that"} as a foundation)` : "") +
    `:\n\n${names.map((n, i) => `${i + 1}. ${n.replace(/\s*\(.*\)$/, "")}`).join("\n")}\n\n` +
    `**Quick check before we start:** which of these do you already feel comfortable with? Reply with their names, or say **none** to start from the ground up (or **all** if you mostly want a refresher). I'll verify as we go — this just sets my starting assumptions.`;
  return { reply, goal: fresh };
}

async function refinePlanWithLLM(learnerId: number, goal: GoalRow, root: ConceptRow) {
  if (!llmAvailable()) return;
  const cmap = await getConcepts(goal.plan);
  const list = goal.plan.map((id) => ({ id, name: cmap.get(id)?.name, summary: cmap.get(id)?.summary.slice(0, 200) }));
  const res = await chatJson<{ order: number[]; prerequisites: { from: number; to: number }[]; rationale: string }>(
    `You are curriculum-planning for "${root.name}". Given researched concepts (ids), return {"order":[ids in the best teaching order, root ${root.id} last], "prerequisites":[{from,to}] additional prerequisite edges you are confident about, "rationale": one sentence}. Only use given ids.`,
    JSON.stringify(list),
  );
  if (!res?.order?.length) return;
  const valid = res.order.filter((id) => goal.plan.includes(id));
  for (const id of goal.plan) if (!valid.includes(id)) valid.push(id);
  for (const p of res.prerequisites ?? []) if (goal.plan.includes(p.from) && goal.plan.includes(p.to)) await addEdge(p.from, p.to, "prerequisite", 0.5, { method: "llm-refinement" });
  const plan = await orderPlan(valid, root.id);
  await saveGoal(goal, { plan });
  await recordDecision(learnerId, "plan_refined", `LLM refined the plan: ${res.rationale ?? ""}`, { order: plan }, goal.id);
}

// ---------------------------------------------------------------------------
// Diagnostic: interpret self-report as priors (never as evidence)
// ---------------------------------------------------------------------------
async function handleDiagnostic(learnerId: number, goal: GoalRow, state: ExtendedState, message: string, affect: Awaited<ReturnType<typeof getAffect>>, actions: string[]): Promise<string> {
  const cmap = await getConcepts(goal.plan);
  const t = message.toLowerCase();
  const claimed: number[] = [];
  let mode: "none" | "all" | "some" = "some";
  if (/\b(none|nothing|no|start from (scratch|the beginning|zero)|beginner|new to|from the ground up|start)\b/i.test(t) && !/\b(all|most)\b/.test(t)) mode = "none";
  else if (/\b(all|most|everything|refresher|already know (them|these|all))\b/i.test(t)) mode = "all";
  for (const id of goal.plan) {
    const c = cmap.get(id);
    if (!c || id === goal.rootConceptId) continue;
    const stem = conceptStem(c.name);
    const hit = mode === "all" || (mode === "some" && stem.length > 2 && new RegExp(`\\b${stem.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`, "i").test(t));
    if (hit) claimed.push(id);
    await setMasteryPrior(learnerId, id, hit ? 0.6 : 0.15, "self-report");
  }
  await recordEvidence(learnerId, "self_report", { mode, claimed, text: message }, goal.id);
  await recordDecision(
    learnerId,
    "diagnostic_interpreted",
    claimed.length
      ? `Learner claims familiarity with ${claimed.map((id) => cmap.get(id)?.name).join(", ")} → prior p=0.6 (to be verified by exercises); others p=0.15.`
      : `Learner starts from the ground up → prior p=0.15 for all concepts.`,
    { mode, claimed },
    goal.id,
  );
  actions.push(`diagnostic:${mode}:${claimed.length}`);
  state.phase = "teaching";
  const ack = claimed.length ? `Noted — I'll treat ${claimed.map((id) => display(cmap.get(id)!)).join(", ")} as probably known and verify with a quick question when we reach them.\n\n` : `Noted — we'll build everything from the ground up.\n\n`;
  return ack + (await teach(learnerId, goal, state, actions, { reason: "diagnostic complete", affectOverride: affect }));
}

// ---------------------------------------------------------------------------
// Teaching
// ---------------------------------------------------------------------------
type TeachOpts = { conceptId?: number; requested?: Strategy; reason: string; affectOverride?: Awaited<ReturnType<typeof getAffect>> };

async function teach(learnerId: number, goal: GoalRow, state: ExtendedState, actions: string[], opts: TeachOpts): Promise<string> {
  const affect = opts.affectOverride ?? (await getAffect(learnerId));
  let conceptId = opts.conceptId ?? null;
  let reason = opts.reason;
  if (!conceptId) {
    const plan = goal.plan.filter((id) => !(state.skipped ?? []).includes(id));
    const nx = await nextConcept(learnerId, plan, goal.rootConceptId!);
    if (!nx.conceptId) {
      // maybe only skipped concepts remain
      const remaining = (state.skipped ?? []).filter((id) => id !== goal.rootConceptId);
      if (remaining.length) {
        conceptId = remaining[0];
        state.skipped = remaining.slice(1);
        reason = "returning to a previously skipped concept";
      } else {
        return await completeGoal(learnerId, goal, state);
      }
    } else {
      conceptId = nx.conceptId;
      reason = `${opts.reason}; selected because ${nx.reason}`;
    }
  }
  if (conceptId !== state.currentConceptId) {
    state.failStreak = 0;
    state.failedStrategies = [];
    state.currentConceptId = conceptId;
  }
  let concept = (await getConcept(conceptId))!;
  concept = await ensureEnriched(concept); // lazy research of full material
  const attempt = await conceptAttempt(state, conceptId, true);
  const m = await getMastery(learnerId, conceptId);
  const stats = await getStrategyStats(learnerId);

  const prefRow = (await getPreferences(learnerId)).find((p) => p.key === "explanation_style");
  const preferred = prefRow && STRATEGIES.includes(prefRow.value as Strategy) ? { strategy: prefRow.value as Strategy, confidence: prefRow.confidence } : undefined;
  const choice = chooseStrategy(stats, affect, state.failedStrategies, opts.requested, preferred);
  const strategy = choice.strategy;

  // prerequisites for context
  const edges = await prerequisiteEdges([conceptId]);
  const preIds = edges.filter((e) => e.toConceptId === conceptId).map((e) => e.fromConceptId);
  const preMap = await getConcepts(preIds);

  const lesson = await composeLesson(concept, strategy, {
    affect,
    attempt,
    prerequisites: [...preMap.values()].map(display),
    learnerName: "",
    priorFailedStrategies: state.failedStrategies,
  });

  const exType = pickExerciseType(m.pKnown, affect, attempt);
  const others = [...(await getConcepts(goal.plan.filter((id) => id !== conceptId && id !== goal.rootConceptId))).values()];
  const ex = await generateExercise(concept, exType, others, strategy, Math.min(0.9, m.pKnown + 0.2));
  state.pending = { ...ex, askedAt: new Date().toISOString() };
  state.lastStrategy = strategy;
  state.taughtCount += 1;
  state.lastTaughtAt = new Date().toISOString();
  await saveGoal(goal, { state });

  await recordDecision(
    learnerId,
    "teach",
    `Teaching "${concept.name}" (p=${m.pKnown.toFixed(2)}, ±${masteryUncertainty(m).toFixed(2)}, attempt ${attempt}) because ${reason}. ${choice.rationale}. Exercise: ${exType} (guess rate ${GUESS_RATE[exType]}).`,
    { conceptId, strategy, samples: choice.samples, exerciseType: exType, pKnown: m.pKnown, attempt },
    goal.id,
  );
  await recordEvidence(learnerId, "lesson_delivered", { strategy, attempt, exerciseType: exType }, goal.id, conceptId);
  actions.push(`teach:${concept.slug}:${strategy}:${exType}`);

  const progress = `<sub>Concept ${Math.max(1, goal.plan.indexOf(conceptId) + 1)} of ${goal.plan.length - 1} · style: ${strategy.replace("_", " ")} · my belief you know this: ${(m.pKnown * 100).toFixed(0)}%</sub>\n\n`;
  return `${affectPreface(affect)}${progress}${lesson}\n\n---\n**Check your understanding:** ${ex.prompt}`;
}

async function askOnly(learnerId: number, goal: GoalRow, state: ExtendedState, actions: string[]): Promise<string> {
  const conceptId = state.currentConceptId ?? goal.plan[0];
  const concept = (await getConcept(conceptId))!;
  const m = await getMastery(learnerId, conceptId);
  const affect = await getAffect(learnerId);
  const exType = pickExerciseType(m.pKnown, affect, 1);
  const others = [...(await getConcepts(goal.plan.filter((id) => id !== conceptId && id !== goal.rootConceptId))).values()];
  const ex = await generateExercise(concept, exType, others, (state.lastStrategy as Strategy) ?? "concise", Math.min(0.9, m.pKnown + 0.2));
  state.pending = { ...ex, askedAt: new Date().toISOString() };
  state.currentConceptId = conceptId;
  await saveGoal(goal, { state });
  actions.push(`quiz:${concept.slug}:${exType}`);
  return `Practice question on **${display(concept)}**:\n\n${ex.prompt}`;
}

async function completeGoal(learnerId: number, goal: GoalRow, state: ExtendedState): Promise<string> {
  state.phase = "completed";
  state.pending = undefined;
  await saveGoal(goal, { state, status: "completed" });
  await recordDecision(learnerId, "goal_completed", `All planned concepts reached mastery threshold ${MASTERY_THRESHOLD}.`, {}, goal.id);
  const snap = await learnerSnapshot(learnerId);
  const best = snap?.strategies.slice().sort((a, b) => b.mean - a.mean)[0];
  return (
    `🎉 You've reached the mastery threshold on every concept in **${goal.topic}**.\n\n` +
    (best ? `What I learned about you: explanations in the **${best.strategy.replace("_", " ")}** style worked best (posterior success ${(best.mean * 100).toFixed(0)}%). ` : "") +
    `Tell me the next thing you'd like to learn, or ask me to **quiz** you for retention.`
  );
}

// ---------------------------------------------------------------------------
// Answer handling: evidence → belief update → adaptation
// ---------------------------------------------------------------------------
async function handleAnswer(learnerId: number, goal: GoalRow, state: ExtendedState, message: string, actions: string[]): Promise<string> {
  const ex = state.pending as PendingExercise;
  const concept = (await getConcept(ex.conceptId))!;
  const grade = await gradeAnswer(ex, message, concept);
  const before = await getMastery(learnerId, ex.conceptId);
  const wasSelfReported = before.source === "self-report" && before.attempts === 0 && before.pKnown >= 0.5;
  const upd = await observeMastery(learnerId, ex.conceptId, grade.correct, GUESS_RATE[ex.type]);
  await updateStrategyOutcome(learnerId, ex.strategy, grade.correct);
  await recordEvidence(
    learnerId,
    "exercise_result",
    { type: ex.type, strategy: ex.strategy, correct: grade.correct, score: grade.score, method: grade.method, answer: message.slice(0, 300), pBefore: upd.before, pAfter: upd.after },
    goal.id,
    ex.conceptId,
  );
  actions.push(`graded:${grade.correct ? "correct" : "wrong"}:${ex.type}`);
  state.pending = undefined;

  const affectDelta = grade.correct
    ? { confidence: 0.12, frustration: -0.12, confusion: -0.1, engagement: 0.05 }
    : { frustration: 0.1 + 0.1 * state.failStreak, confusion: 0.12, confidence: -0.1 };
  const affect = await updateAffect(learnerId, affectDelta, 0.9);

  if (wasSelfReported && !grade.correct) {
    await recordDecision(
      learnerId,
      "belief_revised",
      `Learner self-reported knowing "${concept.name}" but answered incorrectly → belief lowered from ${upd.before.toFixed(2)} to ${upd.after.toFixed(2)}; treating it as not yet known.`,
      { conceptId: ex.conceptId, before: upd.before, after: upd.after },
      goal.id,
    );
    actions.push("belief_revised");
  }

  const feedback = `${grade.correct ? "✅" : "❌"} ${grade.feedback} <sub>(belief: ${(upd.before * 100).toFixed(0)}% → ${(upd.after * 100).toFixed(0)}%)</sub>\n\n`;

  if (grade.correct) {
    state.failStreak = 0;
    if (upd.after >= MASTERY_THRESHOLD) {
      await recordDecision(learnerId, "concept_mastered", `"${concept.name}" reached p=${upd.after.toFixed(2)} ≥ ${MASTERY_THRESHOLD} after ${upd.row.attempts} attempts (${upd.row.correct} correct). Moving on.`, { conceptId: ex.conceptId }, goal.id);
      actions.push(`mastered:${concept.slug}`);
      return feedback + `**${display(concept)}** — solid. ` + (await teach(learnerId, goal, state, actions, { reason: `"${concept.name}" mastered` }));
    }
    // not yet confident → a harder check on the same concept, no re-teach
    const nextType = pickExerciseType(upd.after, affect, 1);
    const others = [...(await getConcepts(goal.plan.filter((id) => id !== ex.conceptId && id !== goal.rootConceptId))).values()];
    const nx = await generateExercise(concept, nextType, others, ex.strategy as Strategy, Math.min(0.95, upd.after + 0.2));
    state.pending = { ...nx, askedAt: new Date().toISOString() };
    await saveGoal(goal, { state });
    await recordDecision(learnerId, "verify_mastery", `Correct, but p=${upd.after.toFixed(2)} < ${MASTERY_THRESHOLD} → one more ${nextType} check on "${concept.name}" before moving on.`, { conceptId: ex.conceptId, exerciseType: nextType }, goal.id);
    return feedback + `One more to be sure:\n\n${nx.prompt}`;
  }

  // ---- incorrect: adapt ---------------------------------------------------
  state.failStreak += 1;
  if (!state.failedStrategies.includes(ex.strategy)) state.failedStrategies.push(ex.strategy);

  // Optional LLM deliberation with tools (agentic freedom); deterministic policy otherwise.
  const llmPlan = state.failStreak >= 2 ? await deliberate(learnerId, goal, state, concept) : null;
  const action = llmPlan?.action ?? (state.failStreak === 1 ? "reteach" : state.failStreak === 2 ? "remediate" : "discover");

  if (action === "remediate" || action === "discover") {
    const edges = await prerequisiteEdges([ex.conceptId]);
    const preIds = edges.filter((e) => e.toConceptId === ex.conceptId).map((e) => e.fromConceptId);
    const mm = await getMasteryMap(learnerId, preIds);
    const weak = preIds
      .map((id) => ({ id, p: mm.get(id)?.pKnown ?? 0.15, attempts: mm.get(id)?.attempts ?? 0 }))
      .filter((x) => x.p < 0.8 || x.attempts === 0)
      .sort((a, b) => a.p - b.p);
    if (weak.length && action === "remediate") {
      const pre = (await getConcept(weak[0].id))!;
      await recordDecision(
        learnerId,
        "remediate_prerequisite",
        `Two failures on "${concept.name}" with different strategies (${state.failedStrategies.join(", ")}) → hypothesis: missing prerequisite. Weakest prerequisite is "${pre.name}" (p=${weak[0].p.toFixed(2)}, ${weak[0].attempts} attempts). Backing up to it.`,
        { conceptId: ex.conceptId, prerequisiteId: pre.id },
        goal.id,
      );
      actions.push(`remediate:${pre.slug}`);
      return feedback + `Before we push further on ${display(concept)}, let's make sure the foundation is solid.\n\n` + (await teach(learnerId, goal, state, actions, { conceptId: pre.id, reason: `prerequisite of "${concept.name}" after repeated failure` }));
    }
    if (action === "discover" || !weak.length) {
      const found = await discoverMissingPrerequisites(concept, goal.plan, goal.rootConceptId).catch(() => []);
      if (found.length) {
        const idx = goal.plan.indexOf(ex.conceptId);
        const plan = [...goal.plan.slice(0, idx), ...found.map((f) => f.id), ...goal.plan.slice(idx)];
        goal = await saveGoal(goal, { plan });
        await recordDecision(
          learnerId,
          "discover_prerequisite",
          `Repeated failure on "${concept.name}" and no unlearned prerequisite in the graph → investigated the concept's references and added ${found.map((f) => `"${f.name}"`).join(", ")} as prerequisite(s); revised the learning path.`,
          { conceptId: ex.conceptId, added: found.map((f) => f.id), plan },
          goal.id,
        );
        actions.push(`discover:${found.map((f) => f.slug).join(",")}`);
        return feedback + `I think something upstream is missing. I looked into what **${display(concept)}** depends on and found **${found.map(display).join("** and **")}** — let's cover that first.\n\n` + (await teach(learnerId, goal, state, actions, { conceptId: found[0].id, reason: `newly discovered prerequisite of "${concept.name}"` }));
      }
    }
    // fall through: simplify
    await recordDecision(learnerId, "simplify", `No prerequisite to fall back to for "${concept.name}"; simplifying: worked steps + recognition-level check.`, { conceptId: ex.conceptId }, goal.id);
    return feedback + (await teach(learnerId, goal, state, actions, { conceptId: ex.conceptId, requested: state.failedStrategies.includes("step_by_step") ? "example" : "step_by_step", reason: "simplifying after repeated failure" }));
  }

  // reteach with a different strategy
  await recordDecision(learnerId, "strategy_switch", `"${ex.strategy}" did not lead to a correct answer on "${concept.name}" → re-teaching with a different strategy (excluding ${state.failedStrategies.join(", ")}).`, { conceptId: ex.conceptId, failed: state.failedStrategies }, goal.id);
  actions.push("strategy_switch");
  return feedback + (await teach(learnerId, goal, state, actions, { conceptId: ex.conceptId, requested: llmPlan?.strategy, reason: `"${ex.strategy}" explanation did not work` }));
}

/** LLM tool-use deliberation when stuck: it can inspect state, research, extend the graph, then choose an action. */
async function deliberate(learnerId: number, goal: GoalRow, state: ExtendedState, concept: ConceptRow): Promise<{ action: "reteach" | "remediate" | "discover" | "simplify"; strategy?: Strategy; note: string } | null> {
  if (!llmAvailable()) return null;
  let decision: { action: "reteach" | "remediate" | "discover" | "simplify"; strategy?: Strategy; note: string } | null = null;
  try {
    const result = await runToolLoop(
      `You are the reasoning core of an adaptive tutor. The learner failed ${state.failStreak} times on "${concept.name}" (failed strategies: ${state.failedStrategies.join(", ")}). Investigate using tools, then call decide exactly once.`,
      `Concept summary: ${concept.summary.slice(0, 800)}`,
      [
        { name: "get_learner_state", description: "Learner mastery, affect, strategy posteriors, recent decisions.", input_schema: { type: "object", properties: {} } },
        { name: "research_concept", description: "Research a concept title on Wikipedia and return its summary.", input_schema: { type: "object", properties: { title: { type: "string" } }, required: ["title"] } },
        { name: "add_prerequisite", description: "Add a researched concept as a prerequisite of the current concept and into the plan.", input_schema: { type: "object", properties: { title: { type: "string" } }, required: ["title"] } },
        { name: "decide", description: "Final decision.", input_schema: { type: "object", properties: { action: { type: "string", enum: ["reteach", "remediate", "discover", "simplify"] }, strategy: { type: "string", enum: [...STRATEGIES] }, note: { type: "string" } }, required: ["action", "note"] } },
      ],
      async (name, input) => {
        if (name === "get_learner_state") return learnerSnapshot(learnerId);
        if (name === "research_concept") return researchConcept(String(input.title));
        if (name === "add_prerequisite") {
          const rc = await researchConcept(String(input.title));
          if (!rc) return { ok: false };
          const row = await upsertConcept(rc, "llm-agent", concept.domain ?? undefined);
          await addEdge(row.id, concept.id, "prerequisite", 0.5, { method: "llm-agent" });
          if (!goal.plan.includes(row.id)) {
            const idx = goal.plan.indexOf(concept.id);
            goal = await saveGoal(goal, { plan: [...goal.plan.slice(0, idx), row.id, ...goal.plan.slice(idx)] });
          }
          return { ok: true, id: row.id };
        }
        if (name === "decide") {
          decision = { action: input.action as "reteach", strategy: input.strategy as Strategy | undefined, note: String(input.note ?? "") };
          return { ok: true };
        }
        return { error: "unknown tool" };
      },
    );
    if (result) await recordDecision(learnerId, "llm_deliberation", decision ? (decision as { note: string }).note : result.finalText.slice(0, 500), { calls: result.calls.map((c) => c.name) }, goal.id);
  } catch (e) {
    console.error("deliberation failed", e);
  }
  return decision;
}

// ---------------------------------------------------------------------------
// Learner questions → research when the graph lacks the concept
// ---------------------------------------------------------------------------
async function answerQuestion(learnerId: number, goal: GoalRow, state: ExtendedState, name: string, actions: string[]): Promise<string> {
  let c = await findConceptByName(name);
  let discovered = false;
  if (!c) {
    const rc = await researchConcept(name);
    if (rc) {
      c = await upsertConcept(rc, "learner-question", goal.topic);
      if (state.currentConceptId) await addEdge(c.id, state.currentConceptId, "related", 0.3, { method: "learner-question" });
      discovered = true;
    }
  }
  if (!c) return `I couldn't find solid material on "${name}". Could you rephrase it?`;
  c = await ensureEnriched(c);
  await recordEvidence(learnerId, "question_asked", { name, conceptId: c.id, discovered }, goal.id, state.currentConceptId);
  await recordDecision(learnerId, "answered_question", discovered ? `Learner asked about "${name}", which was not in the graph → researched it and added it as a related concept.` : `Learner asked about "${c.name}" (already in graph).`, { conceptId: c.id }, goal.id);
  actions.push(`question:${c.slug}${discovered ? ":researched" : ""}`);
  const affect = await getAffect(learnerId);
  const lesson = await composeLesson(c, "concise", { affect, attempt: 1, prerequisites: [], learnerName: "", priorFailedStrategies: [] });
  const tail = state.pending ? `\n\n---\nBack to the question when you're ready:\n\n${state.pending.prompt}` : `\n\nSay **continue** to carry on with the lesson.`;
  return lesson + tail;
}

// ---------------------------------------------------------------------------
// Status
// ---------------------------------------------------------------------------
async function statusReport(learnerId: number): Promise<string> {
  const snap = await learnerSnapshot(learnerId);
  if (!snap) return "No learner found.";
  const planConcepts = snap.goal ? snap.goal.plan.map((id) => snap.concepts.find((c) => c.id === id)).filter(Boolean) : [];
  const lines = planConcepts
    .filter((c) => c!.id !== snap.goal?.rootConceptId)
    .map((c) => `- ${c!.name.replace(/\s*\(.*\)$/, "")}: ${(c!.pKnown * 100).toFixed(0)}% ±${(c!.uncertainty * 100).toFixed(0)} (${c!.attempts} attempts)${c!.mastered ? " ✅" : ""}`);
  const strat = snap.strategies
    .slice()
    .sort((a, b) => b.mean - a.mean)
    .map((s) => `${s.strategy.replace("_", " ")} ${(s.mean * 100).toFixed(0)}% (${s.trials})`)
    .join(", ");
  const a = snap.affect;
  return (
    `**Where you are** (${snap.goal ? snap.goal.topic : "no active goal"}):\n${lines.join("\n") || "_no concepts yet_"}\n\n` +
    `**What works for you** (posterior success by explanation style): ${strat}\n\n` +
    `**How you seem right now:** engagement ${(a.engagement * 100).toFixed(0)}%, confidence ${(a.confidence * 100).toFixed(0)}%, confusion ${(a.confusion * 100).toFixed(0)}%, frustration ${(a.frustration * 100).toFixed(0)}%, fatigue ${(a.fatigue * 100).toFixed(0)}%\n\n` +
    `_${snap.evidenceCount} pieces of evidence recorded; ${snap.decisions.length} recent decisions are visible in the side panel._`
  );
}

// ---------------------------------------------------------------------------
// Recommendation (for MCP / external assistants)
// ---------------------------------------------------------------------------
export async function recommendation(learnerId: number) {
  const goal = await activeGoal(learnerId);
  if (!goal) return { action: "ask_for_goal", rationale: "No active goal." };
  const state = goal.state as ExtendedState;
  if (state.phase === "diagnostic") return { action: "collect_self_report", rationale: "Awaiting the learner's self-assessment for the new plan.", goalId: goal.id };
  if (state.pending) return { action: "await_answer", conceptId: state.pending.conceptId, exerciseType: state.pending.type, prompt: state.pending.prompt, goalId: goal.id };
  const nx = await nextConcept(learnerId, goal.plan, goal.rootConceptId!);
  const stats = await getStrategyStats(learnerId);
  const affect = await getAffect(learnerId);
  const choice = chooseStrategy(stats, affect, state.failedStrategies);
  const c = nx.conceptId ? await getConcept(nx.conceptId) : null;
  return { action: nx.conceptId ? "teach" : "complete", conceptId: nx.conceptId, concept: c?.name, reason: nx.reason, suggestedStrategy: choice.strategy, strategyRationale: choice.rationale, goalId: goal.id };
}

