/**
 * ADAPTIVE CORE – persistent learner-state and evidence system.
 * Everything the agent learns about a learner is written here in a structured,
 * interpretable, revisable form. Beliefs are probabilities, never labels.
 */
import { db } from "@/db";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import {
  affectStates,
  concepts,
  conceptEdges,
  decisions,
  evidence,
  goals,
  learners,
  mastery,
  messages,
  preferences,
  strategyStats,
} from "@/db/schema";

export const STRATEGIES = ["concise", "detailed", "example", "analogy", "step_by_step"] as const;
export type Strategy = (typeof STRATEGIES)[number];

export const MASTERY_THRESHOLD = 0.85;

// ---------------------------------------------------------------------------
// Learners
// ---------------------------------------------------------------------------
export async function ensureLearner(name: string) {
  const existing = await db.select().from(learners).where(eq(learners.name, name)).limit(1);
  if (existing[0]) return existing[0];
  const [row] = await db.insert(learners).values({ name }).returning();
  await db.insert(affectStates).values({ learnerId: row.id }).onConflictDoNothing();
  return row;
}

export async function getLearner(id: number) {
  const [row] = await db.select().from(learners).where(eq(learners.id, id)).limit(1);
  return row ?? null;
}

// ---------------------------------------------------------------------------
// Mastery: BKT update + Beta pseudo-counts for uncertainty + dormancy decay
// ---------------------------------------------------------------------------
export type MasteryRow = typeof mastery.$inferSelect;

const BKT = { pLearn: 0.18, pSlip: 0.1 };

export function decayedPKnown(row: Pick<MasteryRow, "pKnown" | "lastSeenAt" | "streak">, now = Date.now()): number {
  if (!row.lastSeenAt) return row.pKnown;
  const days = (now - new Date(row.lastSeenAt).getTime()) / 86_400_000;
  if (days <= 0) return row.pKnown;
  // half-life grows with streak (spacing effect): 5d, 10d, 20d ...
  const halfLife = 5 * Math.pow(2, Math.max(0, Math.min(5, row.streak)));
  const floor = 0.15;
  return floor + (row.pKnown - floor) * Math.pow(0.5, days / halfLife);
}

export function masteryUncertainty(row: Pick<MasteryRow, "alpha" | "beta">): number {
  const a = row.alpha;
  const b = row.beta;
  const variance = (a * b) / ((a + b) * (a + b) * (a + b + 1));
  return Math.sqrt(variance) * 2; // ~ 95% half-width, in [0, 1]
}

export async function getMastery(learnerId: number, conceptId: number): Promise<MasteryRow> {
  const [row] = await db
    .select()
    .from(mastery)
    .where(and(eq(mastery.learnerId, learnerId), eq(mastery.conceptId, conceptId)))
    .limit(1);
  if (row) return { ...row, pKnown: decayedPKnown(row) };
  const [created] = await db.insert(mastery).values({ learnerId, conceptId }).onConflictDoNothing().returning();
  if (created) return created;
  const [again] = await db.select().from(mastery).where(and(eq(mastery.learnerId, learnerId), eq(mastery.conceptId, conceptId)));
  return again;
}

export async function getMasteryMap(learnerId: number, conceptIds: number[]): Promise<Map<number, MasteryRow>> {
  if (!conceptIds.length) return new Map();
  const rows = await db.select().from(mastery).where(and(eq(mastery.learnerId, learnerId), inArray(mastery.conceptId, conceptIds)));
  return new Map(rows.map((r) => [r.conceptId, { ...r, pKnown: decayedPKnown(r) }]));
}

/** Set a prior belief (e.g., from self-report). Does not count as evidence of mastery. */
export async function setMasteryPrior(learnerId: number, conceptId: number, p: number, source: string) {
  const cur = await getMastery(learnerId, conceptId);
  if (cur.attempts > 0) return cur; // never override observed evidence with a self-report
  const alpha = 1 + 3 * p;
  const beta = 1 + 3 * (1 - p);
  const [row] = await db
    .update(mastery)
    .set({ pKnown: p, alpha, beta, source, updatedAt: new Date() })
    .where(eq(mastery.id, cur.id))
    .returning();
  return row;
}

/**
 * Bayesian Knowledge Tracing observation update.
 * pGuess depends on the exercise format (4-option recognition ≈ 0.25, free recall ≈ 0.05).
 */
export function bktUpdate(pKnown: number, correct: boolean, pGuess: number): number {
  const pSlip = BKT.pSlip;
  const pObsGivenKnown = correct ? 1 - pSlip : pSlip;
  const pObsGivenUnknown = correct ? pGuess : 1 - pGuess;
  const posterior = (pKnown * pObsGivenKnown) / (pKnown * pObsGivenKnown + (1 - pKnown) * pObsGivenUnknown);
  return posterior + (1 - posterior) * BKT.pLearn;
}

export async function observeMastery(
  learnerId: number,
  conceptId: number,
  correct: boolean,
  pGuess: number,
  weight = 1,
): Promise<{ before: number; after: number; row: MasteryRow }> {
  const cur = await getMastery(learnerId, conceptId);
  const before = cur.pKnown;
  let after = bktUpdate(before, correct, pGuess);
  if (weight < 1) after = before + (after - before) * weight;
  const [row] = await db
    .update(mastery)
    .set({
      pKnown: after,
      alpha: cur.alpha + (correct ? weight : 0),
      beta: cur.beta + (correct ? 0 : weight),
      attempts: cur.attempts + 1,
      correct: cur.correct + (correct ? 1 : 0),
      streak: correct ? cur.streak + 1 : 0,
      source: "observed",
      lastSeenAt: new Date(),
      updatedAt: new Date(),
    })
    .where(eq(mastery.id, cur.id))
    .returning();
  return { before, after, row };
}

// ---------------------------------------------------------------------------
// Teaching strategy posteriors (per learner Thompson sampling)
// ---------------------------------------------------------------------------
export type StrategyRow = typeof strategyStats.$inferSelect;

/** Global weak priors – learned pattern: examples/steps help novices a bit more. */
const STRATEGY_PRIOR: Record<Strategy, [number, number]> = {
  concise: [1.2, 1.2],
  detailed: [1.2, 1.2],
  example: [1.5, 1.1],
  analogy: [1.2, 1.2],
  step_by_step: [1.4, 1.1],
};

export async function getStrategyStats(learnerId: number): Promise<Record<Strategy, StrategyRow>> {
  const rows = await db.select().from(strategyStats).where(eq(strategyStats.learnerId, learnerId));
  const map = new Map(rows.map((r) => [r.strategy, r]));
  const missing = STRATEGIES.filter((s) => !map.has(s));
  if (missing.length) {
    const inserted = await db
      .insert(strategyStats)
      .values(missing.map((s) => ({ learnerId, strategy: s, alpha: STRATEGY_PRIOR[s][0], beta: STRATEGY_PRIOR[s][1] })))
      .onConflictDoNothing()
      .returning();
    for (const r of inserted) map.set(r.strategy, r);
  }
  return Object.fromEntries(STRATEGIES.map((s) => [s, map.get(s)!])) as Record<Strategy, StrategyRow>;
}

function sampleBeta(a: number, b: number): number {
  // Marsaglia–Tsang gamma sampling
  const gamma = (k: number): number => {
    if (k < 1) return gamma(k + 1) * Math.pow(Math.random(), 1 / k);
    const d = k - 1 / 3;
    const c = 1 / Math.sqrt(9 * d);
    for (;;) {
      let x: number;
      let v: number;
      do {
        const u1 = Math.random();
        const u2 = Math.random();
        x = Math.sqrt(-2 * Math.log(u1 || 1e-9)) * Math.cos(2 * Math.PI * u2);
        v = 1 + c * x;
      } while (v <= 0);
      v = v * v * v;
      const u = Math.random();
      if (u < 1 - 0.0331 * x * x * x * x) return d * v;
      if (Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
    }
  };
  const x = gamma(a);
  const y = gamma(b);
  return x / (x + y);
}

export type AffectRow = typeof affectStates.$inferSelect;

/**
 * Choose a strategy by Thompson sampling, modulated by affect and by what has
 * already failed on the current concept. Returns rationale for the decision log.
 */
export function chooseStrategy(
  stats: Record<Strategy, StrategyRow>,
  affect: AffectRow,
  exclude: string[] = [],
  requested?: Strategy,
  preferred?: { strategy: Strategy; confidence: number },
): { strategy: Strategy; rationale: string; samples: Record<string, number> } {
  if (requested) return { strategy: requested, rationale: `learner explicitly asked for ${requested}`, samples: {} };
  const samples: Record<string, number> = {};
  let best: Strategy = "example";
  let bestVal = -1;
  for (const s of STRATEGIES) {
    let v = sampleBeta(stats[s].alpha, stats[s].beta);
    // affect modulation
    if (affect.confusion > 0.5 && (s === "step_by_step" || s === "example")) v += 0.12;
    if (affect.fatigue > 0.5 && s === "concise") v += 0.15;
    if (affect.fatigue > 0.5 && s === "detailed") v -= 0.15;
    if (affect.frustration > 0.5 && s === "detailed") v -= 0.1;
    if (preferred && preferred.strategy === s && !exclude.includes(s)) v += 0.2 * preferred.confidence;
    if (exclude.includes(s)) v -= 0.5;
    samples[s] = Number(v.toFixed(3));
    if (v > bestVal) {
      bestVal = v;
      best = s;
    }
  }
  const mean = (s: Strategy) => (stats[s].alpha / (stats[s].alpha + stats[s].beta)).toFixed(2);
  const rationale =
    `Thompson sample chose "${best}" (posterior means: ${STRATEGIES.map((s) => `${s}=${mean(s)}`).join(", ")}` +
    (exclude.length ? `; excluded after failure: ${exclude.join(",")}` : "") +
    (preferred ? `; stated preference "${preferred.strategy}" boosted` : "") +
    (affect.confusion > 0.5 ? "; confusion high → favour worked steps/examples" : "") +
    (affect.fatigue > 0.5 ? "; fatigue high → favour concise" : "") +
    ")";
  return { strategy: best, rationale, samples };
}

export async function updateStrategyOutcome(learnerId: number, strategy: string, success: boolean, weight = 1) {
  await getStrategyStats(learnerId);
  await db
    .update(strategyStats)
    .set({
      alpha: sql`${strategyStats.alpha} + ${success ? weight : 0}`,
      beta: sql`${strategyStats.beta} + ${success ? 0 : weight}`,
      trials: sql`${strategyStats.trials} + 1`,
      successes: sql`${strategyStats.successes} + ${success ? 1 : 0}`,
      updatedAt: new Date(),
    })
    .where(and(eq(strategyStats.learnerId, learnerId), eq(strategyStats.strategy, strategy)));
}

// ---------------------------------------------------------------------------
// Preferences
// ---------------------------------------------------------------------------
export async function setPreference(learnerId: number, key: string, value: unknown, confidence: number) {
  await db
    .insert(preferences)
    .values({ learnerId, key, value, confidence })
    .onConflictDoUpdate({ target: [preferences.learnerId, preferences.key], set: { value, confidence, updatedAt: new Date() } });
}

export async function getPreferences(learnerId: number) {
  return db.select().from(preferences).where(eq(preferences.learnerId, learnerId));
}

// ---------------------------------------------------------------------------
// Affect
// ---------------------------------------------------------------------------
export async function getAffect(learnerId: number): Promise<AffectRow> {
  const [row] = await db.select().from(affectStates).where(eq(affectStates.learnerId, learnerId)).limit(1);
  if (row) return row;
  const [created] = await db.insert(affectStates).values({ learnerId }).onConflictDoNothing().returning();
  if (created) return created;
  const [again] = await db.select().from(affectStates).where(eq(affectStates.learnerId, learnerId)).limit(1);
  return again;
}

export type AffectDelta = Partial<Record<"frustration" | "confusion" | "engagement" | "fatigue" | "confidence", number>>;

const clamp01 = (x: number) => Math.max(0, Math.min(1, x));

/** Apply decay toward baseline, then deltas. Returns new state. */
export async function updateAffect(learnerId: number, delta: AffectDelta, decay = 0.85): Promise<AffectRow> {
  const cur = await getAffect(learnerId);
  const base = { frustration: 0.1, confusion: 0.1, engagement: 0.6, fatigue: 0.1, confidence: 0.5 };
  const next = { ...base };
  for (const k of Object.keys(base) as (keyof typeof base)[]) {
    const decayed = base[k] + (cur[k] - base[k]) * decay;
    next[k] = clamp01(decayed + (delta[k] ?? 0));
  }
  const [row] = await db.update(affectStates).set({ ...next, updatedAt: new Date() }).where(eq(affectStates.id, cur.id)).returning();
  return row;
}

const AFFECT_LEXICON: { re: RegExp; delta: AffectDelta; label: string }[] = [
  { re: /\b(frustrat|annoy|hate this|this sucks|ugh+|argh|give up|pointless|stupid)\w*/i, delta: { frustration: 0.35, engagement: -0.1 }, label: "frustration" },
  { re: /\b(confus|don'?t (get|understand|follow)|lost|no idea|makes no sense|unclear|what\?+|huh)\b/i, delta: { confusion: 0.35 }, label: "confusion" },
  { re: /\b(tired|exhausted|sleepy|long day|brain is fried|need a break|enough for today)\b/i, delta: { fatigue: 0.4 }, label: "fatigue" },
  { re: /\b(bored|boring|slow|already know|too easy|obvious)\b/i, delta: { engagement: -0.25, confidence: 0.1 }, label: "boredom" },
  { re: /\b(got it|makes sense|i see|cool|nice|awesome|interesting|love (this|it)|thanks?)\b/i, delta: { engagement: 0.15, confidence: 0.1, confusion: -0.1 }, label: "positive" },
  { re: /\b(not sure|maybe|i think|guess|probably|\?\?)\b/i, delta: { confidence: -0.1 }, label: "hedging" },
  { re: /\b(idk|dunno|no clue|pass|skip)\b/i, delta: { confusion: 0.15, confidence: -0.15 }, label: "avoidance" },
];

export function inferAffectFromText(text: string, secondsSinceLast?: number): { delta: AffectDelta; signals: string[] } {
  const delta: AffectDelta = {};
  const signals: string[] = [];
  for (const { re, delta: d, label } of AFFECT_LEXICON) {
    if (re.test(text)) {
      signals.push(label);
      for (const [k, v] of Object.entries(d)) delta[k as keyof AffectDelta] = (delta[k as keyof AffectDelta] ?? 0) + v;
    }
  }
  if (text.trim().length > 160) {
    delta.engagement = (delta.engagement ?? 0) + 0.1;
    signals.push("elaborated");
  }
  if (secondsSinceLast !== undefined) {
    if (secondsSinceLast > 240) {
      delta.fatigue = (delta.fatigue ?? 0) + 0.1;
      delta.engagement = (delta.engagement ?? 0) - 0.1;
      signals.push("slow-response");
    } else if (secondsSinceLast < 4 && text.trim().length < 8) {
      delta.engagement = (delta.engagement ?? 0) - 0.05;
      signals.push("rapid-minimal");
    }
  }
  return { delta, signals };
}

// ---------------------------------------------------------------------------
// Evidence + decisions (append-only, interpretable)
// ---------------------------------------------------------------------------
export async function recordEvidence(learnerId: number, kind: string, payload: Record<string, unknown>, goalId?: number | null, conceptId?: number | null) {
  const [row] = await db.insert(evidence).values({ learnerId, kind, payload, goalId: goalId ?? null, conceptId: conceptId ?? null }).returning();
  return row;
}

export async function recordDecision(learnerId: number, type: string, rationale: string, payload: Record<string, unknown> = {}, goalId?: number | null) {
  const [row] = await db.insert(decisions).values({ learnerId, type, rationale, payload, goalId: goalId ?? null }).returning();
  return row;
}

export async function addMessage(learnerId: number, role: "user" | "assistant" | "system", content: string, meta: Record<string, unknown> = {}, goalId?: number | null) {
  const [row] = await db.insert(messages).values({ learnerId, role, content, meta, goalId: goalId ?? null }).returning();
  return row;
}

export async function recentMessages(learnerId: number, limit = 40) {
  const rows = await db.select().from(messages).where(eq(messages.learnerId, learnerId)).orderBy(desc(messages.createdAt), desc(messages.id)).limit(limit);
  return rows.reverse();
}

// ---------------------------------------------------------------------------
// Goals
// ---------------------------------------------------------------------------
export async function activeGoal(learnerId: number) {
  const [g] = await db
    .select()
    .from(goals)
    .where(and(eq(goals.learnerId, learnerId), eq(goals.status, "active")))
    .orderBy(desc(goals.createdAt))
    .limit(1);
  return g ?? null;
}

// ---------------------------------------------------------------------------
// Snapshot for UI / MCP
// ---------------------------------------------------------------------------
export async function learnerSnapshot(learnerId: number) {
  const learner = await getLearner(learnerId);
  if (!learner) return null;
  const goal = await activeGoal(learnerId);
  const allGoals = await db.select().from(goals).where(eq(goals.learnerId, learnerId)).orderBy(desc(goals.createdAt));
  const affect = await getAffect(learnerId);
  const strategies = await getStrategyStats(learnerId);
  const prefs = await getPreferences(learnerId);
  const recentDecisions = await db.select().from(decisions).where(eq(decisions.learnerId, learnerId)).orderBy(desc(decisions.createdAt), desc(decisions.id)).limit(25);
  const [{ count: evidenceCount }] = await db.select({ count: sql<number>`count(*)::int` }).from(evidence).where(eq(evidence.learnerId, learnerId));
  const masteryRows = await db.select().from(mastery).where(eq(mastery.learnerId, learnerId));
  const conceptIds = new Set<number>([...masteryRows.map((m) => m.conceptId), ...(goal?.plan ?? [])]);
  if (goal?.rootConceptId) conceptIds.add(goal.rootConceptId);
  const conceptRows = conceptIds.size ? await db.select().from(concepts).where(inArray(concepts.id, [...conceptIds])) : [];
  const edges = conceptIds.size
    ? await db.select().from(conceptEdges).where(and(inArray(conceptEdges.fromConceptId, [...conceptIds]), inArray(conceptEdges.toConceptId, [...conceptIds])))
    : [];
  const mmap = new Map(masteryRows.map((m) => [m.conceptId, m]));
  const conceptView = conceptRows.map((c) => {
    const m = mmap.get(c.id);
    const p = m ? decayedPKnown(m) : 0.2;
    return {
      id: c.id,
      name: c.name,
      slug: c.slug,
      difficulty: c.difficulty,
      sourceUrl: c.sourceUrl,
      discoveredBy: c.discoveredBy,
      pKnown: Number(p.toFixed(3)),
      uncertainty: m ? Number(masteryUncertainty(m).toFixed(3)) : 0.5,
      attempts: m?.attempts ?? 0,
      correct: m?.correct ?? 0,
      source: m?.source ?? "prior",
      lastSeenAt: m?.lastSeenAt ?? null,
      mastered: p >= MASTERY_THRESHOLD && (m?.attempts ?? 0) > 0,
    };
  });
  return {
    learner,
    goal: goal
      ? {
          id: goal.id,
          text: goal.text,
          topic: goal.topic,
          status: goal.status,
          plan: goal.plan,
          rootConceptId: goal.rootConceptId,
          phase: goal.state.phase,
          currentConceptId: goal.state.currentConceptId ?? null,
          pending: goal.state.pending ? { type: goal.state.pending.type, prompt: goal.state.pending.prompt, options: goal.state.pending.options, strategy: goal.state.pending.strategy } : null,
          failStreak: goal.state.failStreak,
          taughtCount: goal.state.taughtCount,
        }
      : null,
    goals: allGoals.map((g) => ({ id: g.id, text: g.text, topic: g.topic, status: g.status, createdAt: g.createdAt })),
    affect: {
      frustration: affect.frustration,
      confusion: affect.confusion,
      engagement: affect.engagement,
      fatigue: affect.fatigue,
      confidence: affect.confidence,
      updatedAt: affect.updatedAt,
    },
    strategies: STRATEGIES.map((s) => ({
      strategy: s,
      mean: Number((strategies[s].alpha / (strategies[s].alpha + strategies[s].beta)).toFixed(3)),
      alpha: strategies[s].alpha,
      beta: strategies[s].beta,
      trials: strategies[s].trials,
      successes: strategies[s].successes,
    })),
    preferences: prefs.map((p) => ({ key: p.key, value: p.value, confidence: p.confidence })),
    concepts: conceptView,
    edges: edges.map((e) => ({ from: e.fromConceptId, to: e.toConceptId, type: e.type, weight: e.weight })),
    decisions: recentDecisions.map((d) => ({ id: d.id, type: d.type, rationale: d.rationale, payload: d.payload, createdAt: d.createdAt })),
    evidenceCount,
    llm: llmStatus(),
  };
}

export function llmStatus() {
  if (process.env.ANTHROPIC_API_KEY) return { provider: "anthropic", model: process.env.LLM_MODEL ?? "claude-sonnet-4-5" };
  if (process.env.OPENAI_API_KEY) return { provider: "openai", model: process.env.LLM_MODEL ?? "gpt-4o-mini" };
  return { provider: "none", model: "deterministic reasoner" };
}
