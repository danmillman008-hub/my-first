/**
 * Open-domain research: given a topic in natural language, investigate it on
 * Wikipedia, extract a candidate concept set, infer prerequisite relations from
 * the hyperlink structure (RefD – Liang et al., EMNLP 2015 "Measuring
 * Prerequisite Relations Among Concepts") and produce a knowledge representation
 * the agent can teach from.
 */

const WIKI_API = "https://en.wikipedia.org/w/api.php";
const WIKI_REST = "https://en.wikipedia.org/api/rest_v1";
const UA = "PrivateSelfAdaptingLearningAgent/1.0 (research module; contact: local)";

export type ResearchedConcept = {
  title: string;
  slug: string;
  summary: string;
  description: string;
  sections: { title: string; text: string }[];
  links: string[];
  keyTerms: string[];
  examples: string[];
  sourceUrl: string;
  score: number;
  difficulty: number;
};

export type PrereqRelation = { from: string; to: string; weight: number; method: string };

export type DomainResearch = {
  topic: string;
  root: ResearchedConcept;
  concepts: ResearchedConcept[]; // excludes root
  foundational: ResearchedConcept[]; // discovered outside the article's own link set
  prerequisites: PrereqRelation[];
  notes: string[];
};

// ---- Polite, throttled, cached HTTP layer (Wikimedia rate-limits bursts) ----
const cache = new Map<string, unknown>();
let lastRequestAt = 0;
let inflight: Promise<void> = Promise.resolve();
const MIN_GAP_MS = 200;
const CORE = "https://api.wikimedia.org/core/v1/wikipedia/en";

async function throttledFetchJson(url: string, timeoutMs = 15000): Promise<unknown> {
  if (cache.has(url)) return cache.get(url);
  const run = async () => {
    for (let attempt = 0; attempt < 2; attempt++) {
      const wait = Math.max(0, lastRequestAt + MIN_GAP_MS - Date.now());
      if (wait) await new Promise((r) => setTimeout(r, wait));
      lastRequestAt = Date.now();
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), timeoutMs);
      try {
        const headers: Record<string, string> = { "User-Agent": UA, "Api-User-Agent": UA, Accept: "application/json" };
        if (url.startsWith(CORE) && process.env.WIKIMEDIA_ACCESS_TOKEN) headers.Authorization = `Bearer ${process.env.WIKIMEDIA_ACCESS_TOKEN}`;
        const started = Date.now();
        const res = await fetch(url, { headers, signal: ctrl.signal });
        const text = await res.text();
        if (process.env.DEBUG_RESEARCH) console.error(`[research] ${res.status} ${Date.now() - started}ms ${url.slice(0, 110)}`);
        if (res.status === 429 || /too many requests/i.test(text.slice(0, 200))) {
          const ra = Number(res.headers.get("retry-after"));
          const delay = Number.isFinite(ra) && ra > 0 ? Math.min(6000, ra * 1000 + 300) : 1500;
          if (attempt === 1) throw new Error("rate limited");
          await new Promise((r) => setTimeout(r, delay));
          continue;
        }
        if (res.status === 404) {
          cache.set(url, null);
          return null;
        }
        if (!res.ok) throw new Error(`http ${res.status}`);
        const json = JSON.parse(text);
        cache.set(url, json);
        return json;
      } finally {
        clearTimeout(t);
      }
    }
    throw new Error("rate limited");
  };
  const p = inflight.then(run, run);
  inflight = p.then(
    () => undefined,
    () => undefined,
  );
  return p;
}

async function wikiGet(params: Record<string, string>): Promise<unknown> {
  const url = new URL(WIKI_API);
  for (const [k, v] of Object.entries({ format: "json", formatversion: "2", origin: "*", ...params })) {
    url.searchParams.set(k, v);
  }
  return throttledFetchJson(url.toString());
}

export type WikiSummary = { title: string; description: string; extract: string; url: string; type: string };

// ---- Wikitext processing --------------------------------------------------

function stripTemplates(wt: string): string {
  // iteratively remove innermost {{...}} blocks
  let prev = "";
  let cur = wt;
  let guard = 0;
  while (prev !== cur && guard++ < 50) {
    prev = cur;
    cur = cur.replace(/\{\{[^{}]*\}\}/g, "");
  }
  return cur;
}

function stripFileLinks(wt: string): string {
  let prev = "";
  let cur = wt;
  let guard = 0;
  while (prev !== cur && guard++ < 20) {
    prev = cur;
    cur = cur.replace(/\[\[(?:File|Image|Category):[^\[\]]*(?:\[\[[^\[\]]*\]\][^\[\]]*)*\]\]/gi, "");
  }
  return cur;
}

/** Convert wikitext to readable plain text, keeping `== Heading ==` lines. */
export function wikitextToPlain(wt: string): string {
  let t = wt.replace(/<!--[\s\S]*?-->/g, "");
  t = t.replace(/<ref[^>]*\/>/gi, "").replace(/<ref[^>]*>[\s\S]*?<\/ref>/gi, "");
  t = t.replace(/<(math|gallery|timeline|syntaxhighlight|source|pre|code)[^>]*>[\s\S]*?<\/\1>/gi, "");
  t = stripTemplates(t);
  t = t.replace(/\{\|[\s\S]*?\|\}/g, "");
  t = stripFileLinks(t);
  t = t.replace(/\[\[([^\]|]+)\|([^\]]+)\]\]/g, "$2").replace(/\[\[([^\]]+)\]\]/g, "$1");
  t = t.replace(/\[https?:\/\/[^\s\]]+\s+([^\]]+)\]/g, "$1").replace(/\[https?:\/\/[^\s\]]+\]/g, "");
  t = t.replace(/'{2,5}/g, "");
  t = t.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "");
  t = t.replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#\d+;/g, "");
  t = t
    .split("\n")
    .map((l) => l.replace(/^[*#:;]+\s*/, "").trim())
    .filter((l) => l && !/^\|/.test(l))
    .join("\n");
  return t;
}

// ---- Sources: Wikimedia Core API (primary), REST summary, Action API (fallback)

export async function searchTitle(topic: string): Promise<string | null> {
  // Cheapest path first: an exact-title lookup on the REST summary endpoint (follows redirects).
  const guess = topic.trim().replace(/\s+/g, " ");
  const direct = (await restSummary(guess[0].toUpperCase() + guess.slice(1))) ?? (await restSummary(guess.toLowerCase().replace(/^./, (c) => c.toUpperCase())));
  if (direct && direct.type === "standard" && direct.extract.length > 100 && !/^list of/i.test(direct.title)) return direct.title;
  const hits = await coreSearch(topic, 5);
  if (hits.length) {
    const good = hits.find((h) => !/^list of|disambiguation/i.test(h.title) && !/disambiguation/i.test(h.description));
    return (good ?? hits[0]).title;
  }
  try {
    const j = (await wikiGet({ action: "query", list: "search", srsearch: topic, srlimit: "5", srprop: "" })) as {
      query?: { search?: { title: string }[] };
    } | null;
    const s = j?.query?.search ?? [];
    if (!s.length) return null;
    return (s.find((h) => !/^list of|disambiguation/i.test(h.title)) ?? s[0]).title;
  } catch {
    return null;
  }
}

export async function coreSearch(q: string, limit = 5): Promise<{ title: string; description: string; excerpt: string }[]> {
  try {
    const j = (await throttledFetchJson(`${CORE}/search/page?q=${encodeURIComponent(q)}&limit=${limit}`)) as {
      pages?: { title: string; description?: string | null; excerpt?: string }[];
    } | null;
    return (j?.pages ?? []).map((p) => ({ title: p.title, description: p.description ?? "", excerpt: (p.excerpt ?? "").replace(/<[^>]+>/g, "") }));
  } catch {
    return [];
  }
}

async function corePageSource(title: string, depth = 0): Promise<{ title: string; wikitext: string } | null> {
  try {
    const j = (await throttledFetchJson(`${CORE}/page/${encodeURIComponent(title.replace(/ /g, "_"))}`)) as {
      title?: string;
      source?: string;
    } | null;
    if (!j?.source) return null;
    const m = /^\s*#REDIRECT\s*\[\[([^\]|#]+)/i.exec(j.source);
    if (m && depth < 2) return corePageSource(m[1].trim(), depth + 1);
    return { title: j.title ?? title, wikitext: j.source };
  } catch {
    return null;
  }
}

async function restSummary(title: string): Promise<WikiSummary | null> {
  try {
    const j = (await throttledFetchJson(`${WIKI_REST}/page/summary/${encodeURIComponent(title.replace(/ /g, "_"))}`)) as {
      title: string;
      description?: string;
      extract?: string;
      type?: string;
      content_urls?: { desktop?: { page?: string } };
    } | null;
    if (!j) return null;
    return {
      title: j.title,
      description: j.description ?? "",
      extract: j.extract ?? "",
      type: j.type ?? "standard",
      url: j.content_urls?.desktop?.page ?? `https://en.wikipedia.org/wiki/${encodeURIComponent(j.title)}`,
    };
  } catch {
    return null;
  }
}

/** Per-title metadata: description + intro. REST summary first, Core search as fallback. */
export async function fetchSummaries(titles: string[]): Promise<Map<string, WikiSummary & { links: string[] }>> {
  const out = new Map<string, WikiSummary & { links: string[] }>();
  for (const t of titles) {
    let s = await restSummary(t);
    if (!s) {
      const hits = await coreSearch(t, 1);
      const h = hits[0];
      if (h && h.title.toLowerCase() === t.toLowerCase().replace(/_/g, " ")) {
        s = { title: h.title, description: h.description, extract: h.excerpt, type: "standard", url: `https://en.wikipedia.org/wiki/${encodeURIComponent(h.title)}` };
      }
    }
    if (s && s.extract) out.set(t, { ...s, links: [] });
  }
  return out;
}

export async function fetchSummary(title: string): Promise<(WikiSummary & { links: string[] }) | null> {
  const m = await fetchSummaries([title]);
  return m.get(title) ?? null;
}

type PageData = { title: string; extract: string; links: string[]; wikitext: string };

async function fetchPage(title: string): Promise<PageData | null> {
  const src = await corePageSource(title);
  if (src) {
    const plain = wikitextToPlain(src.wikitext);
    const links = [...new Set(orderedWikiLinks(src.wikitext).map((l) => l.title))];
    if (plain.length > 200) return { title: src.title, extract: plain, links, wikitext: src.wikitext };
  }
  // Fallback: action API extracts + links
  try {
    const q = (await wikiGet({
      action: "query",
      prop: "extracts|links",
      explaintext: "1",
      exsectionformat: "wiki",
      titles: title,
      redirects: "1",
      pllimit: "500",
      plnamespace: "0",
    })) as { query?: { pages?: { title: string; extract?: string; links?: { title: string }[] }[] } } | null;
    const page = q?.query?.pages?.[0];
    if (!page || !page.extract) return null;
    return { title: page.title, extract: page.extract, links: (page.links ?? []).map((l) => l.title), wikitext: "" };
  } catch {
    return null;
  }
}

export function slugify(s: string): string {
  return s
    .toLowerCase()
    .replace(/\(.*?\)/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

const STOP = new Set(
  "the a an and or of to in is are was were be been being that this these those it its as by for with on at from which who whom whose what when where why how not no can may might will would should could also such than then there their them they he she his her we our you your i into onto upon about over under between among within without while during before after above below up down out off again further once here all any both each few more most other some own same so too very just only but if because until unless although though however thus hence therefore etc via per using used use uses one two three".split(
    " ",
  ),
);

const META_TITLES =
  /^(isbn|doi|s2cid|pmid|pmc|arxiv|bibcode|oclc|issn|wayback machine|jstor|citeseerx|hdl|zbl|mr|lccn|ol|internet archive|category:|help:|wikipedia:|template:|portal:|file:|list of |glossary of |outline of |index of |timeline of |history of |comparison of )/i;

function looksLikeConceptTitle(t: string): boolean {
  if (META_TITLES.test(t)) return false;
  if (/\d{3,}/.test(t)) return false;
  if (t.includes(":")) return false;
  if (t.length > 45 || t.length < 3) return false;
  if (/\((programming language|company|film|book|album|band|magazine|software|video game|journal|operating system)\)/i.test(t)) return false;
  return true;
}

const NON_CONCEPT_DESC =
  /scientist|programmer|engineer|mathematician|physicist|philosopher|author|professor|researcher|inventor|entrepreneur|person|people|born|company|corporation|organization|university|institute|programming language$|^language$|software$|^operating system|film|novel|book|album|journal|magazine|website|conference|standard body|wikimedia|list article|year|century|country|city|nationality|language family|surname|given name|group of|brand|product line/i;

export function isConceptLike(description: string, extract: string): boolean {
  if (description && NON_CONCEPT_DESC.test(description)) return false;
  if (/^[A-Z][\w.\- ]+ \((?:born|\d{4}|c\. )/.test(extract)) return false;
  if (/\bis an? (?:[A-Z][a-z]+ )?(?:computer scientist|programmer|software engineer|mathematician|company|corporation|programming language)\b/.test(extract.slice(0, 220)))
    return false;
  return true;
}

function parseSections(extract: string): { title: string; text: string }[] {
  const lines = extract.split("\n");
  const out: { title: string; text: string }[] = [];
  let cur = { title: "Overview", text: "" };
  for (const line of lines) {
    const m = /^(={2,4})\s*(.+?)\s*\1\s*$/.exec(line);
    if (m) {
      if (cur.text.trim()) out.push({ title: cur.title, text: cur.text.trim() });
      cur = { title: m[2], text: "" };
    } else {
      cur.text += line + "\n";
    }
  }
  if (cur.text.trim()) out.push({ title: cur.title, text: cur.text.trim() });
  const drop = /^(see also|references|external links|further reading|notes|bibliography|citations|sources|footnotes)$/i;
  return out.filter((s) => !drop.test(s.title)).map((s) => ({ title: s.title, text: s.text.slice(0, 4000) }));
}

export function splitSentences(text: string): string[] {
  return text
    .replace(/^\s*=+[^=\n]*=+\s*$/gm, "\n") // drop heading lines
    .replace(/==+[^=]*==+/g, " ") // drop inline heading fragments
    .replace(/\s+([,;:.])/g, "$1") // close template gaps like "is , meaning"
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?])\s+(?=[A-Z(])/)
    .map((s) => s.trim())
    .filter((s) => s.length > 30 && s.length < 400 && !/^[=*]/.test(s));
}

export function extractKeyTerms(text: string, extra: string[] = []): string[] {
  const freq = new Map<string, number>();
  for (const raw of text.toLowerCase().match(/[a-z][a-z\-]{3,}/g) ?? []) {
    if (STOP.has(raw)) continue;
    freq.set(raw, (freq.get(raw) ?? 0) + 1);
  }
  const top = [...freq.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([w]) => w);
  return [...new Set([...extra.map((e) => e.toLowerCase()), ...top])].slice(0, 14);
}

export function extractExamples(text: string): string[] {
  return splitSentences(text)
    .filter((s) => /\b(for example|for instance|e\.g\.|such as|consider|imagine|suppose)\b/i.test(s))
    .filter((s) => !/==|\b(is|are|of|the|an?|be|as|and)[,.]\s/.test(s) && !/(ISBN|doi:|Retrieved|pp\.)/.test(s))
    .slice(0, 8);
}

function toConcept(title: string, page: PageData | null, summary: WikiSummary | null, score: number): ResearchedConcept | null {
  const extract = page?.extract ?? summary?.extract ?? "";
  if (!extract) return null;
  const sections = page ? parseSections(page.extract) : [{ title: "Overview", text: summary?.extract ?? "" }];
  const intro = summary?.extract || sections[0]?.text.slice(0, 1200) || "";
  return {
    title,
    slug: slugify(title),
    summary: intro.slice(0, 1500),
    description: summary?.description ?? "",
    sections,
    links: page?.links ?? [],
    keyTerms: extractKeyTerms(intro + " " + (sections[0]?.text ?? "")),
    examples: extractExamples(extract),
    sourceUrl: summary?.url ?? `https://en.wikipedia.org/wiki/${encodeURIComponent(title.replace(/ /g, "_"))}`,
    score,
    difficulty: 0.5,
  };
}

/** Extract [[links]] from wikitext in document order, tagged with the section index. */
function orderedWikiLinks(wikitext: string): { title: string; section: number; pos: number }[] {
  const out: { title: string; section: number; pos: number }[] = [];
  let section = 0;
  const lines = wikitext.split("\n");
  let pos = 0;
  for (const line of lines) {
    if (/^==[^=]/.test(line)) section++;
    const re = /\[\[([^\]|#]+)(?:\|[^\]]*)?\]\]/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(line))) {
      const t = m[1].trim();
      if (t && !t.includes(":")) out.push({ title: (t[0].toUpperCase() + t.slice(1)).replace(/_/g, " "), section, pos: pos++ });
    }
  }
  return out;
}

/**
 * RefD(A,B): fraction of A's related concepts that refer to B minus fraction of
 * B's related concepts that refer to A. Positive ⇒ B is a prerequisite of A.
 */
export function refD(a: string, b: string, links: Map<string, Set<string>>, universe: Set<string>): number {
  const la = links.get(a) ?? new Set();
  const lb = links.get(b) ?? new Set();
  const relA = [...la].filter((c) => universe.has(c) && c !== a);
  const relB = [...lb].filter((c) => universe.has(c) && c !== b);
  const refersTo = (c: string, target: string) => (links.get(c)?.has(target) ? 1 : 0);
  const left = relA.length ? relA.reduce((s, c) => s + refersTo(c, b), 0) / relA.length : 0;
  const right = relB.length ? relB.reduce((s, c) => s + refersTo(c, a), 0) / relB.length : 0;
  return left - right;
}

// ---- HTML fallback parser (REST page/html) --------------------------------
async function restHtmlPage(title: string): Promise<PageData | null> {
  try {
    const url = `${WIKI_REST}/page/html/${encodeURIComponent(title.replace(/ /g, "_"))}`;
    if (cache.has(url)) return cache.get(url) as PageData | null;
    const wait = Math.max(0, lastRequestAt + MIN_GAP_MS - Date.now());
    if (wait) await new Promise((r) => setTimeout(r, wait));
    lastRequestAt = Date.now();
    const res = await fetch(url, { headers: { "User-Agent": UA, "Api-User-Agent": UA }, signal: AbortSignal.timeout(15000) });
    if (process.env.DEBUG_RESEARCH) console.error(`[research] ${res.status} ${url}`);
    if (!res.ok) return null;
    let html = await res.text();
    html = html.replace(/<(style|script|table|figure|figcaption|math)[\s\S]*?<\/\1>/gi, "").replace(/<sup[^>]*class="[^"]*reference[^"]*"[\s\S]*?<\/sup>/gi, "");
    const links: string[] = [];
    const re = /rel="mw:WikiLink" href="\.\/([^"#?]+)/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(html))) links.push(decodeURIComponent(m[1]).replace(/_/g, " "));
    let text = html.replace(/<h([2-4])[^>]*>([\s\S]*?)<\/h\1>/gi, (_x, _l, inner: string) => `\n== ${inner.replace(/<[^>]+>/g, "").trim()} ==\n`);
    text = text.replace(/<\/(p|li|div|section)>/gi, "\n").replace(/<[^>]+>/g, "");
    text = text.replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#\d+;/g, "");
    text = text.split("\n").map((l) => l.trim()).filter(Boolean).join("\n");
    const data = { title, extract: text, links: [...new Set(links)], wikitext: "" };
    cache.set(url, data);
    return data;
  } catch {
    return null;
  }
}

async function fetchPageAny(title: string): Promise<PageData | null> {
  return (await fetchPage(title)) ?? (await restHtmlPage(title));
}

/** Normalised concept name used for mention detection ("Class (programming)" → "class"). */
export function conceptStem(title: string): string {
  return title
    .toLowerCase()
    .replace(/\s*\(.*\)$/, "")
    .replace(/[^a-z0-9 \-]/g, "")
    .trim();
}

export function mentions(text: string, title: string): number {
  const stem = conceptStem(title);
  if (stem.length < 3) return 0;
  const esc = stem.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const re = new RegExp(`\\b${esc}(s|es|ing|ed)?\\b`, "gi");
  return (text.match(re) ?? []).length;
}

/** Estimate intrinsic difficulty: concepts referenced by many peers are more fundamental. */
function estimateDifficulty(concepts: ResearchedConcept[], rootOrder: Map<string, number>): void {
  const inbound = new Map<string, number>();
  for (const c of concepts) for (const other of concepts) if (other !== c && mentions(other.summary, c.title) > 0) inbound.set(c.title, (inbound.get(c.title) ?? 0) + 1);
  const max = Math.max(1, ...inbound.values());
  const maxOrder = Math.max(1, ...rootOrder.values());
  for (const c of concepts) {
    const inb = (inbound.get(c.title) ?? 0) / max;
    const ord = (rootOrder.get(c.title) ?? maxOrder) / maxOrder;
    c.difficulty = Math.max(0.05, Math.min(0.95, 0.35 - 0.3 * inb + 0.45 * ord));
  }
}

/**
 * Prerequisite inference. Signal 1 (text RefD): if B's name is used inside A's
 * definition, A presupposes B. Signal 2 (link RefD, when links are known):
 * reference-distance over hyperlinks. Signal 3: difficulty gap.
 */
export function inferPrerequisites(concepts: ResearchedConcept[], rootTitle: string): PrereqRelation[] {
  const universe = new Set(concepts.map((c) => c.title));
  const links = new Map(concepts.map((c) => [c.title, new Set(c.links)]));
  const haveLinks = concepts.filter((c) => c.links.length > 0).length >= Math.max(2, concepts.length * 0.5);
  const cands: PrereqRelation[] = [];
  for (const a of concepts) {
    if (a.title === rootTitle) continue;
    for (const b of concepts) {
      if (a === b || b.title === rootTitle) continue;
      const mAB = mentions(a.summary, b.title); // A's definition uses B
      const mBA = mentions(b.summary, a.title);
      let score = 0;
      let method = "";
      if (mAB > 0 && mAB >= mBA) {
        score += Math.min(0.6, 0.3 + 0.1 * mAB) - (mBA > 0 ? 0.15 : 0);
        method = "definition-mention";
      }
      if (haveLinks) {
        const rd = refD(a.title, b.title, links, universe);
        const direct = (links.get(a.title)?.has(b.title) ? 0.3 : 0) - (links.get(b.title)?.has(a.title) ? 0.3 : 0);
        if (rd + direct > 0) {
          score += rd + direct;
          method = method ? "definition-mention+refd" : "refd";
        }
      }
      score += (a.difficulty - b.difficulty) * 0.3;
      if (score > 0.2 && method) cands.push({ from: b.title, to: a.title, weight: Math.min(1, score), method });
    }
  }
  cands.sort((x, y) => y.weight - x.weight);
  const adj = new Map<string, Set<string>>();
  const reaches = (from: string, target: string): boolean => {
    const seen = new Set<string>();
    const stack = [from];
    while (stack.length) {
      const n = stack.pop()!;
      if (n === target) return true;
      if (seen.has(n)) continue;
      seen.add(n);
      for (const m of adj.get(n) ?? []) stack.push(m);
    }
    return false;
  };
  const perTarget = new Map<string, number>();
  const kept: PrereqRelation[] = [];
  for (const e of cands) {
    if ((perTarget.get(e.to) ?? 0) >= 3) continue;
    if (reaches(e.to, e.from)) continue;
    if (!adj.has(e.from)) adj.set(e.from, new Set());
    adj.get(e.from)!.add(e.to);
    perTarget.set(e.to, (perTarget.get(e.to) ?? 0) + 1);
    kept.push(e);
  }
  return kept;
}

export async function researchDomain(
  topic: string,
  opts: { maxConcepts?: number; log?: (m: string) => void } = {},
): Promise<DomainResearch | null> {
  const maxConcepts = opts.maxConcepts ?? 9;
  const notes: string[] = [];
  const log = (m: string) => {
    notes.push(m);
    opts.log?.(m);
  };

  const title = await searchTitle(topic);
  if (!title) return null;
  log(`Resolved "${topic}" → Wikipedia article "${title}"`);
  const rootPage = await fetchPageAny(title);
  if (!rootPage) return null;
  const rootSummary = await fetchSummary(rootPage.title);
  const root = toConcept(rootPage.title, rootPage, rootSummary, 100);
  if (!root) return null;

  // --- Candidate concepts from ordered links in the article body -------------
  const ordered = rootPage.wikitext ? orderedWikiLinks(rootPage.wikitext) : rootPage.links.map((t, i) => ({ title: t, section: i < 25 ? 0 : 3, pos: i }));
  const headings = new Set(root.sections.map((s) => s.title.toLowerCase()));
  const lower = rootPage.extract.toLowerCase();
  const scores = new Map<string, number>();
  const firstPos = new Map<string, number>();
  for (const l of ordered) {
    if (!looksLikeConceptTitle(l.title)) continue;
    const norm = conceptStem(l.title);
    if (!firstPos.has(l.title)) firstPos.set(l.title, l.pos);
    let s = scores.get(l.title) ?? 0;
    if (l.section === 0) s += 3;
    else if (l.section <= 4) s += 1.5;
    else s += 0.4;
    if (headings.has(norm)) s += 4;
    const occurrences = lower.split(norm).length - 1;
    s += Math.min(3, Math.log2(occurrences + 1));
    scores.set(l.title, s);
  }
  const ranked = [...scores.entries()].filter(([t]) => t !== rootPage.title).sort((a, b) => b[1] - a[1]).slice(0, Math.min(20, maxConcepts * 2 + 2));
  log(`Found ${ranked.length} candidate concepts from article structure`);

  // --- Verify candidates (lightweight summaries): drop people/languages/products
  const metas = await fetchSummaries(ranked.map(([t]) => t));
  const seen = new Set<string>([rootPage.title]);
  const concepts: ResearchedConcept[] = [];
  const rootOrder = new Map<string, number>();
  for (const [t, s] of ranked) {
    const summary = metas.get(t);
    if (!summary || summary.type !== "standard") continue;
    if (!isConceptLike(summary.description, summary.extract)) continue;
    if (seen.has(summary.title)) continue;
    seen.add(summary.title);
    const rc = toConcept(summary.title, null, summary, s);
    if (!rc) continue;
    rootOrder.set(rc.title, firstPos.get(t) ?? 999);
    concepts.push(rc);
    if (concepts.length >= maxConcepts) break;
  }
  log(`Kept ${concepts.length} verified concepts: ${concepts.map((c) => c.title).join(", ")}`);

  // --- Foundational prerequisite discovery: root links (not chosen) that many
  //     chosen concepts presuppose in their own definitions.
  const inSet = new Set([root.title, ...concepts.map((c) => c.title)]);
  const shared: [string, number][] = [];
  for (const [t] of scores) {
    if (inSet.has(t) || metas.has(t)) continue;
    const n = concepts.filter((c) => mentions(c.summary, t) > 0).length;
    if (n >= Math.max(2, Math.ceil(concepts.length * 0.35))) shared.push([t, n]);
  }
  shared.sort((a, b) => b[1] - a[1]);
  const foundational: ResearchedConcept[] = [];
  if (shared.length) {
    const fm = await fetchSummaries(shared.slice(0, 4).map(([t]) => t));
    for (const [t, n] of shared.slice(0, 4)) {
      if (foundational.length >= 2) break;
      const summary = fm.get(t);
      if (!summary || summary.type !== "standard" || !isConceptLike(summary.description, summary.extract) || inSet.has(summary.title)) continue;
      const fc = toConcept(summary.title, null, summary, 1);
      if (!fc) continue;
      foundational.push(fc);
      inSet.add(fc.title);
      rootOrder.set(fc.title, 0);
      log(`Discovered foundational prerequisite "${fc.title}" – presupposed by ${n} of ${concepts.length} concept definitions`);
    }
  }

  const everything = [root, ...concepts, ...foundational];
  estimateDifficulty(everything, rootOrder);
  for (const f of foundational) f.difficulty = Math.min(f.difficulty, 0.2);
  const prerequisites = inferPrerequisites(everything, root.title);
  for (const f of foundational) {
    for (const c of concepts) {
      if (mentions(c.summary, f.title) > 0 && !prerequisites.some((p) => p.from === f.title && p.to === c.title)) {
        prerequisites.push({ from: f.title, to: c.title, weight: 0.45, method: "shared-definition-mention" });
      }
    }
  }
  for (const c of [...concepts, ...foundational]) prerequisites.push({ from: c.title, to: root.title, weight: 0.6, method: "part-of-goal" });
  log(`Inferred ${prerequisites.filter((p) => p.method !== "part-of-goal").length} prerequisite edges`);

  return { topic, root, concepts, foundational, prerequisites, notes };
}

/** Full-page enrichment for a single concept (sections, examples, links). One request; done lazily. */
export async function enrichConcept(title: string): Promise<Pick<ResearchedConcept, "sections" | "links" | "examples" | "keyTerms"> | null> {
  const page = await fetchPageAny(title);
  if (!page) return null;
  const sections = parseSections(page.extract);
  return {
    sections,
    links: page.links,
    examples: extractExamples(page.extract),
    keyTerms: extractKeyTerms((sections[0]?.text ?? "") + " " + (sections[1]?.text ?? "")),
  };
}

/** Investigate a single concept (missing prerequisite, or a learner asks about something new). */
export async function researchConcept(title: string): Promise<ResearchedConcept | null> {
  const resolved = (await searchTitle(title)) ?? title;
  const summary = await fetchSummary(resolved);
  if (!summary) return null;
  if (!isConceptLike(summary.description, summary.extract)) return null;
  const c = toConcept(summary.title, null, summary, 1);
  if (!c) return null;
  const enriched = await enrichConcept(summary.title);
  if (enriched) Object.assign(c, enriched);
  return c;
}

/** Find prerequisite candidates for a concept from what its own text references that we do not yet know. */
export async function discoverPrerequisitesFor(
  concept: { title: string; links: string[]; summary?: string },
  known: Set<string>,
  limit = 2,
  domainTerms: string[] = [],
): Promise<ResearchedConcept[]> {
  const out: ResearchedConcept[] = [];
  const intro = (concept.summary ?? "").toLowerCase();
  const onDomain = (text: string) => !domainTerms.length || domainTerms.some((t) => t.length > 3 && text.toLowerCase().includes(t.toLowerCase()));
  const cands = concept.links
    .filter((l) => !known.has(l) && looksLikeConceptTitle(l))
    .map((l) => ({ l, inIntro: intro.includes(conceptStem(l)) ? 1 : 0 }))
    .sort((a, b) => b.inIntro - a.inIntro)
    .slice(0, 8)
    .map((x) => x.l);
  if (!cands.length) return out;
  const metas = await fetchSummaries(cands);
  for (const t of cands) {
    if (out.length >= limit) break;
    const s = metas.get(t);
    if (!s || s.type !== "standard" || !isConceptLike(s.description, s.extract) || known.has(s.title)) continue;
    if (!onDomain(s.description + " " + s.extract.slice(0, 600))) continue;
    const c = toConcept(s.title, null, s, 1);
    if (c) {
      c.difficulty = 0.3;
      out.push(c);
      known.add(c.title);
    }
  }
  return out;
}
