/**
 * Pedagogy: compose lessons in a chosen strategy and generate/grade exercises.
 * Uses the LLM when available; otherwise composes from researched material.
 */
import type { PendingExercise } from "@/db/schema";
import type { ConceptRow } from "./graph";
import { splitSentences, conceptStem } from "./research";
import type { Strategy } from "./core";
import { chatJson, llmAvailable } from "./llm";

const displayName = (c: ConceptRow) => c.name.replace(/\s*\(.*\)$/, "");

function definitionSentences(c: ConceptRow): string[] {
  const s = splitSentences(c.summary);
  return s.length ? s : splitSentences(c.content.sections[0]?.text ?? "");
}

function bodySentences(c: ConceptRow): string[] {
  const out: string[] = [];
  for (const sec of c.content.sections.slice(0, 6)) {
    if (/^(history|etymology|criticism|see also|references)$/i.test(sec.title)) continue;
    out.push(...splitSentences(sec.text).slice(0, 4));
  }
  return out;
}

export type LessonContext = {
  affect: { frustration: number; confusion: number; fatigue: number; confidence: number };
  attempt: number; // how many times this concept has been taught to this learner
  prerequisites: string[];
  learnerName: string;
  priorFailedStrategies: string[];
};

export async function composeLesson(c: ConceptRow, strategy: Strategy, ctx: LessonContext): Promise<string> {
  const llm = await composeLessonLLM(c, strategy, ctx);
  if (llm) return llm;
  return composeLessonHeuristic(c, strategy, ctx);
}

async function composeLessonLLM(c: ConceptRow, strategy: Strategy, ctx: LessonContext): Promise<string | null> {
  if (!llmAvailable()) return null;
  const material = [c.summary, ...c.content.sections.slice(0, 4).map((s) => `## ${s.title}\n${s.text.slice(0, 1200)}`)].join("\n\n");
  const styleGuide: Record<Strategy, string> = {
    concise: "3–5 sentences, no fluff, one crisp definition and the single most important insight.",
    detailed: "A thorough explanation: definition, why it exists, how it works, common pitfalls. ~200 words.",
    example: "Lead with a concrete, worked example (code if the domain is programming), then generalise to the definition.",
    analogy: "Open with a vivid everyday analogy, map each part of the analogy to the concept, then state the definition.",
    step_by_step: "Numbered steps that build the idea incrementally from the prerequisites; each step one idea.",
  };
  const res = await chatJson<{ lesson: string }>(
    `You are a personal tutor. Write a lesson about "${c.name}" in the "${strategy}" style: ${styleGuide[strategy]}\n` +
      `Learner context: attempt ${ctx.attempt} on this concept; strategies that already failed: ${ctx.priorFailedStrategies.join(", ") || "none"}; ` +
      `frustration ${ctx.affect.frustration.toFixed(2)}, confusion ${ctx.affect.confusion.toFixed(2)}, fatigue ${ctx.affect.fatigue.toFixed(2)}. ` +
      `Known prerequisites: ${ctx.prerequisites.join(", ") || "none"}. Use markdown. Ground yourself in the source material; do not invent facts.`,
    `Source material:\n${material.slice(0, 6000)}`,
    { maxTokens: 900 },
  );
  return res?.lesson ?? null;
}

function composeLessonHeuristic(c: ConceptRow, strategy: Strategy, ctx: LessonContext): string {
  const name = displayName(c);
  const defs = definitionSentences(c);
  const body = bodySentences(c);
  const examples = (c.content.examples ?? []).filter((e) => !defs.includes(e));
  const pre = ctx.prerequisites.length ? `_Builds on: ${ctx.prerequisites.join(", ")}._\n\n` : "";
  const reteach = ctx.attempt > 1 ? `Let's look at **${name}** from a different angle this time.\n\n` : "";
  const header = `### ${name}\n\n`;
  const src = c.sourceUrl ? `\n\n<sub>Source: ${c.sourceUrl}</sub>` : "";

  switch (strategy) {
    case "concise": {
      const core = defs.slice(0, 2).join(" ");
      const key = body.find((s) => /\b(allows|enables|means|used to|purpose|so that|key|main)\b/i.test(s)) ?? body[0] ?? "";
      return `${header}${reteach}${pre}**In short:** ${core}${key ? `\n\n**Why it matters:** ${key}` : ""}${src}`;
    }
    case "detailed": {
      const paras = [defs.slice(0, 3).join(" "), ...c.content.sections.slice(1, 4).map((s) => `**${s.title}.** ${splitSentences(s.text).slice(0, 3).join(" ")}`)].filter(Boolean);
      return `${header}${reteach}${pre}${paras.join("\n\n")}${src}`;
    }
    case "example": {
      const ex = examples.slice(0, 2);
      const exText = ex.length
        ? ex.map((e) => `> ${e}`).join("\n>\n")
        : `> Think of a concrete situation where you would need *${name}*: ${defs[0] ?? ""}`;
      return `${header}${reteach}${pre}**Start with an example:**\n\n${exText}\n\n**What the example shows:** ${defs.slice(0, 2).join(" ")}${src}`;
    }
    case "analogy": {
      const analogy = body.find((s) => /\b(like|analog|similar to|think of|as if|imagine|metaphor)\b/i.test(s));
      const framing = analogy
        ? `**An analogy from the literature:** ${analogy}`
        : `**An analogy:** Think of *${name}* as a blueprint-and-instances relationship: the general idea is the blueprint, and every real use is one instance built from it.`;
      return `${header}${reteach}${pre}${framing}\n\n**Mapping it back:** ${defs.slice(0, 2).join(" ")}${src}`;
    }
    case "step_by_step": {
      const steps = [...defs.slice(0, 2), ...body.slice(0, 3)].filter(Boolean).slice(0, 5);
      const list = steps.map((s, i) => `${i + 1}. ${s}`).join("\n");
      return `${header}${reteach}${pre}**One idea at a time:**\n\n${list}${src}`;
    }
  }
}

// ---------------------------------------------------------------------------
// Exercises
// ---------------------------------------------------------------------------

export type ExerciseType = PendingExercise["type"];

export function pickExerciseType(pKnown: number, affect: { frustration: number; fatigue: number }, attempt: number): ExerciseType {
  if (affect.frustration > 0.6 || affect.fatigue > 0.6) return "recognition";
  if (pKnown < 0.4) return attempt % 2 === 0 ? "recognition" : "truefalse";
  if (pKnown < 0.7) return "cloze";
  return "explain";
}

export const GUESS_RATE: Record<ExerciseType, number> = { recognition: 0.25, truefalse: 0.5, cloze: 0.1, explain: 0.05 };

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function maskConcept(sentence: string, c: ConceptRow): string {
  const stem = conceptStem(c.name);
  const re = new RegExp(`\\b${stem.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(s|es)?\\b`, "gi");
  return sentence.replace(re, "_____");
}

export async function generateExercise(
  c: ConceptRow,
  type: ExerciseType,
  distractors: ConceptRow[],
  strategy: Strategy,
  difficulty: number,
): Promise<Omit<PendingExercise, "askedAt">> {
  const llm = await generateExerciseLLM(c, type, distractors, strategy, difficulty);
  if (llm) return llm;
  return generateExerciseHeuristic(c, type, distractors, strategy, difficulty);
}

async function generateExerciseLLM(c: ConceptRow, type: ExerciseType, distractors: ConceptRow[], strategy: Strategy, difficulty: number) {
  if (!llmAvailable()) return null;
  const spec: Record<ExerciseType, string> = {
    recognition: 'A 4-option multiple choice question testing understanding (not trivia). {"prompt":..., "options":[4 strings], "answer": exact text of the correct option}',
    truefalse: 'A true/false statement that requires understanding. {"prompt": statement, "options":["True","False"], "answer":"True"|"False"}',
    cloze: 'A fill-in-the-blank sentence where the blank is a key term. {"prompt":..., "answer": the term, "accept":[synonyms]}',
    explain: 'An open question asking the learner to explain or apply the concept. {"prompt":..., "answer": model answer, "accept":[6-10 key terms a good answer contains]}',
  };
  const res = await chatJson<{ prompt: string; options?: string[]; answer: string; accept?: string[] }>(
    `Generate one ${type} exercise about "${c.name}" at difficulty ${difficulty.toFixed(2)} (0 easy – 1 hard). ${spec[type]}. Ground in the material; distractor concepts available: ${distractors.map((d) => d.name).join(", ")}.`,
    `Material:\n${c.summary}\n${c.content.sections
      .slice(0, 3)
      .map((s) => s.text.slice(0, 800))
      .join("\n")}`,
  );
  if (!res?.prompt || !res.answer) return null;
  return { conceptId: c.id, type, prompt: res.prompt, options: res.options, answer: res.answer, accept: res.accept, strategy, difficulty };
}

function generateExerciseHeuristic(c: ConceptRow, type: ExerciseType, distractors: ConceptRow[], strategy: Strategy, difficulty: number): Omit<PendingExercise, "askedAt"> {
  const name = displayName(c);
  const defs = definitionSentences(c);
  const def = defs[0] ?? c.summary.slice(0, 200);
  switch (type) {
    case "recognition": {
      const options = shuffle([name, ...shuffle(distractors.map(displayName)).slice(0, 3)]);
      return {
        conceptId: c.id,
        type,
        prompt: `Which concept does this describe?\n\n> ${maskConcept(def, c)}\n\n${options.map((o, i) => `${"ABCD"[i]}. ${o}`).join("\n")}`,
        options,
        answer: name,
        accept: [name, ...(c.keyTerms.slice(0, 2))],
        strategy,
        difficulty,
      };
    }
    case "truefalse": {
      const truth = Math.random() < 0.5;
      let statement = def;
      if (!truth && distractors.length) {
        // swap in a distractor's definition attributed to this concept
        const d = distractors[Math.floor(Math.random() * distractors.length)];
        const dDef = definitionSentences(d)[0] ?? d.summary.slice(0, 200);
        statement = maskConcept(dDef, d).replace(/_____/g, name);
        if (!statement.includes(name)) statement = `${name}: ${dDef}`;
      }
      return { conceptId: c.id, type, prompt: `True or false?\n\n> ${statement}`, options: ["True", "False"], answer: truth ? "True" : "False", strategy, difficulty };
    }
    case "cloze": {
      const candidates = [...defs, ...bodySentences(c)].filter((s) => new RegExp(`\\b${conceptStem(c.name)}`, "i").test(s));
      const sentence = candidates[Math.min(candidates.length - 1, Math.floor(difficulty * candidates.length))] ?? def;
      return {
        conceptId: c.id,
        type,
        prompt: `Fill in the blank:\n\n> ${maskConcept(sentence, c)}`,
        answer: name,
        accept: [name, conceptStem(c.name)],
        strategy,
        difficulty,
      };
    }
    case "explain": {
      const terms = [...new Set(c.keyTerms)].filter((t) => t.length > 3).slice(0, 10);
      return {
        conceptId: c.id,
        type,
        prompt: `In your own words: what is **${name}**, and why would you use it? (2–4 sentences)`,
        answer: defs.slice(0, 2).join(" "),
        accept: terms,
        strategy,
        difficulty,
      };
    }
  }
}

// ---------------------------------------------------------------------------
// Grading
// ---------------------------------------------------------------------------
export type GradeResult = { correct: boolean; score: number; feedback: string; method: string };

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();

export async function gradeAnswer(ex: PendingExercise, answer: string, c: ConceptRow): Promise<GradeResult> {
  const a = norm(answer);
  if (ex.type === "recognition" || ex.type === "truefalse") {
    const options = ex.options ?? [];
    const letter = /^([a-d])\b/i.exec(answer.trim());
    let chosen: string | null = null;
    if (letter && options.length > 2) chosen = options["ABCD".indexOf(letter[1].toUpperCase())] ?? null;
    if (!chosen) chosen = options.find((o) => norm(o) === a) ?? options.find((o) => a.includes(norm(o)) || norm(o).includes(a)) ?? null;
    if (!chosen && ex.type === "truefalse") chosen = /^(t|true|yes|correct|y)\b/i.test(answer) ? "True" : /^(f|false|no|incorrect|n)\b/i.test(answer) ? "False" : null;
    const correct = !!chosen && norm(chosen) === norm(ex.answer);
    return { correct, score: correct ? 1 : 0, feedback: correct ? "Correct." : `Not quite — the answer was **${ex.answer}**.`, method: "exact" };
  }
  if (ex.type === "cloze") {
    const accept = [ex.answer, ...(ex.accept ?? [])].map(norm);
    const correct = accept.some((x) => x && (a === x || a.includes(x) || (x.length > 5 && x.includes(a) && a.length >= x.length - 2)));
    return { correct, score: correct ? 1 : 0, feedback: correct ? "Correct." : `The missing term was **${ex.answer}**.`, method: "match" };
  }
  // explain: LLM grading if available, else key-term coverage + length
  const llm = await gradeExplainLLM(ex, answer, c);
  if (llm) return llm;
  const terms = (ex.accept ?? []).map(norm).filter(Boolean);
  const hits = terms.filter((t) => a.includes(t));
  const coverage = terms.length ? hits.length / terms.length : 0;
  const words = a.split(" ").filter(Boolean).length;
  const score = Math.min(1, coverage * 1.6 + (words >= 15 ? 0.2 : words >= 8 ? 0.1 : 0));
  const correct = score >= 0.5 && words >= 6;
  return {
    correct,
    score,
    feedback: correct
      ? `Good explanation — you covered ${hits.length} of the key ideas (${hits.slice(0, 4).join(", ")}).`
      : `That explanation is missing key ideas${terms.length ? ` such as: ${terms.filter((t) => !hits.includes(t)).slice(0, 3).join(", ")}` : ""}. A reference answer: ${ex.answer}`,
    method: "keyterm-coverage",
  };
}

async function gradeExplainLLM(ex: PendingExercise, answer: string, c: ConceptRow): Promise<GradeResult | null> {
  if (!llmAvailable()) return null;
  const res = await chatJson<{ score: number; feedback: string; misconception?: string }>(
    `Grade a learner's explanation of "${c.name}". Return {"score": 0..1, "feedback": one or two sentences, "misconception": short label or null}. Be fair; reward correct understanding in plain words.`,
    `Question: ${ex.prompt}\nReference: ${ex.answer}\nLearner answer: ${answer}`,
  );
  if (!res || typeof res.score !== "number") return null;
  return { correct: res.score >= 0.6, score: res.score, feedback: res.feedback + (res.misconception ? ` (Watch out for: ${res.misconception}.)` : ""), method: "llm" };
}
