/**
 * Optional LLM backend. The agent uses it for whatever reasoning/generation is
 * useful (concept refinement, lesson writing, grading, intent, tool-use). When
 * no key is configured every caller falls back to the deterministic reasoner.
 */

export type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

export type ToolDef = {
  name: string;
  description: string;
  input_schema: Record<string, unknown>;
};

export function llmAvailable(): boolean {
  return !!(process.env.ANTHROPIC_API_KEY || process.env.OPENAI_API_KEY);
}

const anthropicModel = () => process.env.LLM_MODEL ?? "claude-sonnet-4-5";
const openaiModel = () => process.env.LLM_MODEL ?? "gpt-4o-mini";

export async function chat(messages: ChatMessage[], opts: { maxTokens?: number; temperature?: number } = {}): Promise<string | null> {
  if (process.env.ANTHROPIC_API_KEY) {
    const system = messages.filter((m) => m.role === "system").map((m) => m.content).join("\n\n");
    const rest = messages.filter((m) => m.role !== "system");
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: anthropicModel(), max_tokens: opts.maxTokens ?? 1200, temperature: opts.temperature ?? 0.4, system, messages: rest }),
      signal: AbortSignal.timeout(60000),
    });
    if (!res.ok) throw new Error(`anthropic ${res.status}: ${(await res.text()).slice(0, 200)}`);
    const j = (await res.json()) as { content: { type: string; text?: string }[] };
    return j.content.filter((c) => c.type === "text").map((c) => c.text ?? "").join("");
  }
  if (process.env.OPENAI_API_KEY) {
    const base = process.env.OPENAI_BASE_URL ?? "https://api.openai.com/v1";
    const res = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({ model: openaiModel(), messages, max_tokens: opts.maxTokens ?? 1200, temperature: opts.temperature ?? 0.4 }),
      signal: AbortSignal.timeout(60000),
    });
    if (!res.ok) throw new Error(`openai ${res.status}: ${(await res.text()).slice(0, 200)}`);
    const j = (await res.json()) as { choices: { message: { content: string } }[] };
    return j.choices[0]?.message?.content ?? null;
  }
  return null;
}

/** Ask for JSON; tolerant of code fences. Returns null when no LLM or parse failure. */
export async function chatJson<T>(system: string, user: string, opts: { maxTokens?: number } = {}): Promise<T | null> {
  if (!llmAvailable()) return null;
  try {
    const text = await chat(
      [
        { role: "system", content: system + "\nRespond with a single JSON object and nothing else." },
        { role: "user", content: user },
      ],
      { maxTokens: opts.maxTokens ?? 1500, temperature: 0.2 },
    );
    if (!text) return null;
    const m = /\{[\s\S]*\}/.exec(text.replace(/```(?:json)?/g, ""));
    return m ? (JSON.parse(m[0]) as T) : null;
  } catch {
    return null;
  }
}

/**
 * Bounded tool-use loop (Anthropic tool calling; OpenAI function calling).
 * The agent decides which core operations to invoke; the caller executes them.
 */
export async function runToolLoop(
  system: string,
  user: string,
  tools: ToolDef[],
  execute: (name: string, input: Record<string, unknown>) => Promise<unknown>,
  maxSteps = 6,
): Promise<{ finalText: string; calls: { name: string; input: Record<string, unknown>; output: unknown }[] } | null> {
  if (!llmAvailable()) return null;
  const calls: { name: string; input: Record<string, unknown>; output: unknown }[] = [];
  if (process.env.ANTHROPIC_API_KEY) {
    type Block = { type: string; text?: string; id?: string; name?: string; input?: Record<string, unknown> };
    const msgs: { role: "user" | "assistant"; content: unknown }[] = [{ role: "user", content: user }];
    for (let step = 0; step < maxSteps; step++) {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model: anthropicModel(), max_tokens: 1500, system, tools, messages: msgs }),
        signal: AbortSignal.timeout(90000),
      });
      if (!res.ok) throw new Error(`anthropic ${res.status}`);
      const j = (await res.json()) as { content: Block[]; stop_reason: string };
      msgs.push({ role: "assistant", content: j.content });
      const uses = j.content.filter((b) => b.type === "tool_use");
      if (!uses.length || j.stop_reason !== "tool_use") {
        return { finalText: j.content.filter((b) => b.type === "text").map((b) => b.text ?? "").join(""), calls };
      }
      const results = [];
      for (const u of uses) {
        const output = await execute(u.name!, u.input ?? {});
        calls.push({ name: u.name!, input: u.input ?? {}, output });
        results.push({ type: "tool_result", tool_use_id: u.id, content: JSON.stringify(output).slice(0, 6000) });
      }
      msgs.push({ role: "user", content: results });
    }
    return { finalText: "", calls };
  }
  // OpenAI function calling
  const base = process.env.OPENAI_BASE_URL ?? "https://api.openai.com/v1";
  type OAMsg = { role: string; content: string | null; tool_calls?: { id: string; function: { name: string; arguments: string } }[]; tool_call_id?: string };
  const msgs: OAMsg[] = [
    { role: "system", content: system },
    { role: "user", content: user },
  ];
  const oaTools = tools.map((t) => ({ type: "function", function: { name: t.name, description: t.description, parameters: t.input_schema } }));
  for (let step = 0; step < maxSteps; step++) {
    const res = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({ model: openaiModel(), messages: msgs, tools: oaTools }),
      signal: AbortSignal.timeout(90000),
    });
    if (!res.ok) throw new Error(`openai ${res.status}`);
    const j = (await res.json()) as { choices: { message: OAMsg }[] };
    const m = j.choices[0].message;
    msgs.push(m);
    if (!m.tool_calls?.length) return { finalText: m.content ?? "", calls };
    for (const tc of m.tool_calls) {
      let input: Record<string, unknown> = {};
      try {
        input = JSON.parse(tc.function.arguments || "{}");
      } catch {
        /* ignore */
      }
      const output = await execute(tc.function.name, input);
      calls.push({ name: tc.function.name, input, output });
      msgs.push({ role: "tool", tool_call_id: tc.id, content: JSON.stringify(output).slice(0, 6000) });
    }
  }
  return { finalText: "", calls };
}
