/**
 * Knowledge representation: persist researched concepts into the graph, plan
 * learning paths over prerequisite edges, and extend the graph when the agent
 * discovers missing knowledge.
 */
import { db } from "@/db";
import { and, eq, inArray, or } from "drizzle-orm";
import { concepts, conceptEdges, type ConceptContent } from "@/db/schema";
import { discoverPrerequisitesFor, enrichConcept, researchDomain, searchTitle, type DomainResearch, type ResearchedConcept, slugify } from "./research";
import { MASTERY_THRESHOLD, getMasteryMap } from "./core";

export type ConceptRow = typeof concepts.$inferSelect;
export type EdgeRow = typeof conceptEdges.$inferSelect;

export async function upsertConcept(rc: ResearchedConcept, discoveredBy: string, domain?: string): Promise<ConceptRow> {
  const content: ConceptContent = { sections: rc.sections, links: rc.links, examples: rc.examples };
  const [existing] = await db.select().from(concepts).where(eq(concepts.slug, rc.slug)).limit(1);
  if (existing) {
    // extend, never shrink, what we know about a concept
    const merged: ConceptContent = {
      sections: existing.content.sections.length >= rc.sections.length ? existing.content.sections : rc.sections,
      links: (existing.content.links?.length ?? 0) >= rc.links.length ? existing.content.links : rc.links,
      examples: (existing.content.examples?.length ?? 0) >= rc.examples.length ? existing.content.examples : rc.examples,
    };
    const [row] = await db
      .update(concepts)
      .set({ content: merged, summary: existing.summary || rc.summary, keyTerms: existing.keyTerms.length ? existing.keyTerms : rc.keyTerms })
      .where(eq(concepts.id, existing.id))
      .returning();
    return row;
  }
  const [row] = await db
    .insert(concepts)
    .values({
      slug: rc.slug,
      name: rc.title,
      summary: rc.summary,
      content,
      sourceUrl: rc.sourceUrl,
      difficulty: rc.difficulty,
      keyTerms: rc.keyTerms,
      domain: domain ?? null,
      discoveredBy,
    })
    .onConflictDoNothing()
    .returning();
  if (row) return row;
  const [again] = await db.select().from(concepts).where(eq(concepts.slug, rc.slug)).limit(1);
  return again;
}

export async function addEdge(fromId: number, toId: number, type: string, weight: number, evidence: Record<string, unknown> = {}) {
  if (fromId === toId) return;
  // refuse to create a cycle in the prerequisite graph
  if (type === "prerequisite" && (await reaches(toId, fromId))) return;
  await db.insert(conceptEdges).values({ fromConceptId: fromId, toConceptId: toId, type, weight, evidence }).onConflictDoNothing();
}

async function reaches(from: number, target: number): Promise<boolean> {
  const seen = new Set<number>();
  let frontier = [from];
  while (frontier.length) {
    const rows = await db.select().from(conceptEdges).where(and(inArray(conceptEdges.fromConceptId, frontier), eq(conceptEdges.type, "prerequisite")));
    frontier = [];
    for (const r of rows) {
      if (r.toConceptId === target) return true;
      if (!seen.has(r.toConceptId)) {
        seen.add(r.toConceptId);
        frontier.push(r.toConceptId);
      }
    }
  }
  return false;
}

export async function getConcept(id: number): Promise<ConceptRow | null> {
  const [c] = await db.select().from(concepts).where(eq(concepts.id, id)).limit(1);
  return c ?? null;
}

export async function getConcepts(ids: number[]): Promise<Map<number, ConceptRow>> {
  if (!ids.length) return new Map();
  const rows = await db.select().from(concepts).where(inArray(concepts.id, ids));
  return new Map(rows.map((r) => [r.id, r]));
}

export async function findConceptByName(name: string): Promise<ConceptRow | null> {
  const slug = slugify(name);
  const [c] = await db.select().from(concepts).where(eq(concepts.slug, slug)).limit(1);
  if (c) return c;
  const all = await db.select().from(concepts);
  const n = name.toLowerCase();
  const exact = all.find((x) => x.name.toLowerCase().replace(/\s*\(.*\)$/, "") === n.replace(/\s*\(.*\)$/, ""));
  if (exact) return exact;
  // only accept a fuzzy match when the query is a parenthetical-free version of the concept name
  return all.find((x) => x.slug.replace(/-+$/, "") === slug || x.slug.startsWith(slug + "-")) ?? null;
}

/** Prerequisite edges among a set of concepts (+ any prerequisite pointing into the set). */
export async function prerequisiteEdges(conceptIds: number[]): Promise<EdgeRow[]> {
  if (!conceptIds.length) return [];
  return db
    .select()
    .from(conceptEdges)
    .where(and(eq(conceptEdges.type, "prerequisite"), or(inArray(conceptEdges.toConceptId, conceptIds), inArray(conceptEdges.fromConceptId, conceptIds))));
}

/**
 * Build / reuse the knowledge representation for a topic.
 * Returns the root concept and a topologically ordered plan.
 */
export async function buildDomain(topic: string, log: (m: string) => void): Promise<{ root: ConceptRow; plan: number[]; research: DomainResearch | null; reused: boolean } | null> {
  // Reuse an existing representation when this subject was researched before.
  const resolved = await searchTitle(topic).catch(() => null);
  const existingRoot = resolved ? await findConceptByName(resolved) : await findConceptByName(topic);
  if (existingRoot) {
    const members = (await db.select().from(conceptEdges).where(and(eq(conceptEdges.toConceptId, existingRoot.id), eq(conceptEdges.type, "part_of")))).map((e) => e.fromConceptId);
    if (members.length >= 3) {
      log(`Reusing existing knowledge representation for "${existingRoot.name}" (${members.length} concepts)`);
      const plan = await orderPlan(members, existingRoot.id);
      return { root: existingRoot, plan, research: null, reused: true };
    }
  }
  const research = await researchDomain(topic, { log });
  if (!research) return null;
  const domain = research.root.title;
  const root = await upsertConcept(research.root, "research", domain);
  const idByTitle = new Map<string, number>([[research.root.title, root.id]]);
  for (const c of research.concepts) idByTitle.set(c.title, (await upsertConcept(c, "research", domain)).id);
  for (const c of research.foundational) idByTitle.set(c.title, (await upsertConcept(c, "prerequisite-discovery", domain)).id);
  for (const p of research.prerequisites) {
    const from = idByTitle.get(p.from);
    const to = idByTitle.get(p.to);
    if (!from || !to) continue;
    await addEdge(from, to, p.method === "part-of-goal" ? "part_of" : "prerequisite", p.weight, { method: p.method });
  }
  const members = [...idByTitle.values()].filter((id) => id !== root.id);
  const plan = await orderPlan(members, root.id);
  return { root, plan, research, reused: false };
}

/** Topological order over prerequisite edges; ties broken by difficulty. Root last. */
export async function orderPlan(memberIds: number[], rootId: number): Promise<number[]> {
  const ids = [...new Set(memberIds.filter((id) => id !== rootId))];
  const rows = await getConcepts(ids);
  const edges = (await prerequisiteEdges(ids)).filter((e) => ids.includes(e.fromConceptId) && ids.includes(e.toConceptId));
  const indeg = new Map<number, number>(ids.map((id) => [id, 0]));
  const out = new Map<number, number[]>();
  for (const e of edges) {
    indeg.set(e.toConceptId, (indeg.get(e.toConceptId) ?? 0) + 1);
    out.set(e.fromConceptId, [...(out.get(e.fromConceptId) ?? []), e.toConceptId]);
  }
  const ready = ids.filter((id) => indeg.get(id) === 0);
  const result: number[] = [];
  const diff = (id: number) => rows.get(id)?.difficulty ?? 0.5;
  while (ready.length) {
    ready.sort((a, b) => diff(a) - diff(b));
    const n = ready.shift()!;
    result.push(n);
    for (const m of out.get(n) ?? []) {
      indeg.set(m, indeg.get(m)! - 1);
      if (indeg.get(m) === 0) ready.push(m);
    }
  }
  for (const id of ids) if (!result.includes(id)) result.push(id); // cycle safety
  result.push(rootId);
  return result;
}

/**
 * Pick the next concept to work on: the first plan item that is not mastered and
 * whose prerequisites (within the plan) are mastered or confidently known.
 * Falls back to the least-known prerequisite if the frontier is blocked.
 */
export async function nextConcept(learnerId: number, plan: number[], rootId: number): Promise<{ conceptId: number | null; reason: string }> {
  const mm = await getMasteryMap(learnerId, plan);
  const edges = (await prerequisiteEdges(plan)).filter((e) => plan.includes(e.fromConceptId) && plan.includes(e.toConceptId));
  const known = (id: number) => {
    const m = mm.get(id);
    return !!m && m.pKnown >= MASTERY_THRESHOLD && m.attempts > 0;
  };
  const likelyKnown = (id: number) => {
    const m = mm.get(id);
    return !!m && m.pKnown >= 0.7;
  };
  for (const id of plan) {
    if (known(id)) continue;
    if (id === rootId) continue;
    const prereqs = edges.filter((e) => e.toConceptId === id).map((e) => e.fromConceptId);
    const blocking = prereqs.filter((p) => !likelyKnown(p) && !known(p));
    if (!blocking.length) return { conceptId: id, reason: prereqs.length ? `prerequisites satisfied (${prereqs.length})` : "no prerequisites" };
    // frontier blocked → go to the weakest prerequisite
    blocking.sort((a, b) => (mm.get(a)?.pKnown ?? 0.2) - (mm.get(b)?.pKnown ?? 0.2));
    return { conceptId: blocking[0], reason: `prerequisite of the next planned concept is not yet known` };
  }
  return { conceptId: null, reason: "all planned concepts mastered" };
}

/** Lazily fetch full material for a concept before teaching it (one request, persisted). */
export async function ensureEnriched(c: ConceptRow): Promise<ConceptRow> {
  if (c.content.sections.length > 1 || (c.content.links?.length ?? 0) > 0) return c;
  const e = await enrichConcept(c.name).catch(() => null);
  if (!e) return c;
  const [row] = await db
    .update(concepts)
    .set({ content: { sections: e.sections.length ? e.sections : c.content.sections, links: e.links, examples: e.examples }, keyTerms: c.keyTerms.length >= 6 ? c.keyTerms : e.keyTerms })
    .where(eq(concepts.id, c.id))
    .returning();
  return row;
}

/**
 * Agent runs into repeated failure on a concept and the graph offers no unlearned
 * prerequisite → investigate the concept's own references for missing prerequisites.
 */
export async function discoverMissingPrerequisites(c: ConceptRow, planIds: number[], rootId?: number | null): Promise<ConceptRow[]> {
  const enriched = await ensureEnriched(c);
  const planConcepts = await getConcepts(planIds);
  const known = new Set<string>([...planConcepts.values()].map((x) => x.name));
  known.add(enriched.name);
  // Domain relevance: discovered prerequisites must connect to the goal's vocabulary.
  const root = rootId ? planConcepts.get(rootId) ?? (await getConcept(rootId)) : null;
  const domainTerms = root ? [...new Set([...root.name.toLowerCase().split(/[^a-z]+/), ...root.keyTerms])].filter((t) => t.length > 3) : [];
  const found = await discoverPrerequisitesFor({ title: enriched.name, links: enriched.content.links ?? [], summary: enriched.summary }, known, 2, domainTerms);
  const rows: ConceptRow[] = [];
  for (const f of found) {
    const row = await upsertConcept(f, "prerequisite-discovery", enriched.domain ?? undefined);
    await addEdge(row.id, enriched.id, "prerequisite", 0.5, { method: "failure-driven-discovery" });
    rows.push(row);
  }
  return rows;
}
