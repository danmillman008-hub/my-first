import {
  pgTable,
  serial,
  text,
  integer,
  real,
  jsonb,
  timestamp,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// ADAPTIVE CORE: persistent learner-state + evidence system.
// The agent is free to act; everything it learns about the learner lands here.
// ---------------------------------------------------------------------------

export const learners = pgTable("learners", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/** Concept graph nodes. Open-domain: the agent adds nodes when it researches a subject. */
export const concepts = pgTable(
  "concepts",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    summary: text("summary").notNull().default(""),
    /** Longer teaching material (plain text extract, sections). */
    content: jsonb("content").$type<ConceptContent>().notNull().default({ sections: [] }),
    sourceUrl: text("source_url"),
    /** 0..1 estimated intrinsic difficulty. */
    difficulty: real("difficulty").notNull().default(0.5),
    keyTerms: jsonb("key_terms").$type<string[]>().notNull().default([]),
    domain: text("domain"),
    discoveredBy: text("discovered_by").notNull().default("research"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("concepts_slug_idx").on(t.slug)],
);

export type ConceptSection = { title: string; text: string };
export type ConceptContent = {
  sections: ConceptSection[];
  /** Titles of linked wiki pages – used for prerequisite inference (RefD). */
  links?: string[];
  examples?: string[];
};

export const conceptEdges = pgTable(
  "concept_edges",
  {
    id: serial("id").primaryKey(),
    fromConceptId: integer("from_concept_id").notNull().references(() => concepts.id),
    toConceptId: integer("to_concept_id").notNull().references(() => concepts.id),
    /** prerequisite: from must be known before to. part_of: from is a component of to. related. */
    type: text("type").notNull().default("prerequisite"),
    weight: real("weight").notNull().default(0.5),
    evidence: jsonb("evidence").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    uniqueIndex("concept_edges_unique").on(t.fromConceptId, t.toConceptId, t.type),
    index("concept_edges_to_idx").on(t.toConceptId),
  ],
);

export type PendingExercise = {
  conceptId: number;
  type: "recognition" | "cloze" | "truefalse" | "explain";
  prompt: string;
  options?: string[];
  answer: string;
  /** additional acceptable answers / key terms */
  accept?: string[];
  strategy: string;
  difficulty: number;
  askedAt: string;
};

export type GoalState = {
  phase: "diagnostic" | "teaching" | "completed";
  currentConceptId?: number;
  pending?: PendingExercise;
  /** strategy used for last lesson on currentConceptId */
  lastStrategy?: string;
  /** failures in a row on the current concept */
  failStreak: number;
  /** strategies that failed on current concept */
  failedStrategies: string[];
  taughtCount: number;
  lastTaughtAt?: string;
  reviewQueue?: number[];
};

export const goals = pgTable("goals", {
  id: serial("id").primaryKey(),
  learnerId: integer("learner_id").notNull().references(() => learners.id),
  text: text("text").notNull(),
  topic: text("topic").notNull(),
  rootConceptId: integer("root_concept_id").references(() => concepts.id),
  status: text("status").notNull().default("active"),
  /** ordered concept ids (learning path) – agent may revise */
  plan: jsonb("plan").$type<number[]>().notNull().default([]),
  state: jsonb("state").$type<GoalState>().notNull().default({ phase: "diagnostic", failStreak: 0, failedStrategies: [], taughtCount: 0 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

/** Evolving belief about mastery of one concept for one learner. */
export const mastery = pgTable(
  "mastery",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id").notNull().references(() => learners.id),
    conceptId: integer("concept_id").notNull().references(() => concepts.id),
    /** BKT-style probability that the learner knows the concept. */
    pKnown: real("p_known").notNull().default(0.2),
    /** Beta posterior pseudo-counts – used for uncertainty. */
    alpha: real("alpha").notNull().default(1),
    beta: real("beta").notNull().default(3),
    attempts: integer("attempts").notNull().default(0),
    correct: integer("correct").notNull().default(0),
    streak: integer("streak").notNull().default(0),
    source: text("source").notNull().default("prior"),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("mastery_unique").on(t.learnerId, t.conceptId)],
);

/** Per-learner posterior of "this teaching strategy leads to a correct follow-up". */
export const strategyStats = pgTable(
  "strategy_stats",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id").notNull().references(() => learners.id),
    strategy: text("strategy").notNull(),
    alpha: real("alpha").notNull().default(1),
    beta: real("beta").notNull().default(1),
    trials: integer("trials").notNull().default(0),
    successes: integer("successes").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("strategy_stats_unique").on(t.learnerId, t.strategy)],
);

export const preferences = pgTable(
  "preferences",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id").notNull().references(() => learners.id),
    key: text("key").notNull(),
    value: jsonb("value").$type<unknown>().notNull(),
    confidence: real("confidence").notNull().default(0.5),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("preferences_unique").on(t.learnerId, t.key)],
);

export const affectStates = pgTable(
  "affect_states",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id").notNull().references(() => learners.id),
    frustration: real("frustration").notNull().default(0.1),
    confusion: real("confusion").notNull().default(0.1),
    engagement: real("engagement").notNull().default(0.6),
    fatigue: real("fatigue").notNull().default(0.1),
    confidence: real("confidence").notNull().default(0.5),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("affect_states_unique").on(t.learnerId)],
);

/** Append-only evidence log: every observation about the learner. */
export const evidence = pgTable(
  "evidence",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id").notNull().references(() => learners.id),
    goalId: integer("goal_id"),
    conceptId: integer("concept_id"),
    kind: text("kind").notNull(),
    payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("evidence_learner_idx").on(t.learnerId, t.createdAt)],
);

/** Interpretable log of agent decisions with rationale. */
export const decisions = pgTable(
  "decisions",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id").notNull().references(() => learners.id),
    goalId: integer("goal_id"),
    type: text("type").notNull(),
    rationale: text("rationale").notNull(),
    payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("decisions_learner_idx").on(t.learnerId, t.createdAt)],
);

export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id").notNull().references(() => learners.id),
    goalId: integer("goal_id"),
    role: text("role").notNull(),
    content: text("content").notNull(),
    meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("messages_learner_idx").on(t.learnerId, t.createdAt)],
);
