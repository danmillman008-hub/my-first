/**
 * MCP access layer (official @modelcontextprotocol/sdk, Streamable HTTP).
 * External assistants can read learner state, the concept graph, get
 * recommendations, record evidence, run tutoring turns and extend the graph.
 * MCP is an integration surface – the intelligence lives in the agent/core.
 */
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { db } from "@/db";
import { and, desc, eq, inArray } from "drizzle-orm";
import { concepts, conceptEdges, evidence, learners, messages } from "@/db/schema";
import { activeGoal, ensureLearner, getMasteryMap, learnerSnapshot, observeMastery, recordDecision, recordEvidence, setMasteryPrior } from "@/agent/core";
import { handleTurn, recommendation } from "@/agent/agent";
import { addEdge, findConceptByName, upsertConcept } from "@/agent/graph";
import { researchConcept } from "@/agent/research";

const text = (v: unknown) => ({ content: [{ type: "text" as const, text: typeof v === "string" ? v : JSON.stringify(v, null, 2) }] });

export function createMcpServer() {
  const server = new McpServer({ name: "private-self-adapting-learning-agent", version: "1.0.0" });

  server.registerTool(
    "list_learners",
    { description: "List learners known to the adaptive core.", inputSchema: {} },
    async () => text({ learners: await db.select().from(learners).orderBy(desc(learners.createdAt)).limit(100) }),
  );

  server.registerTool(
    "ensure_learner",
    { description: "Create (or fetch) a learner by name.", inputSchema: { name: z.string().min(1).max(60) } },
    async ({ name }) => text(await ensureLearner(name)),
  );

  server.registerTool(
    "get_learner_state",
    {
      description: "Full persistent learner model: goal & plan, per-concept mastery beliefs with uncertainty, affect, strategy posteriors, preferences, recent decisions.",
      inputSchema: { learnerId: z.number().int() },
    },
    async ({ learnerId }) => text((await learnerSnapshot(learnerId)) ?? { error: "not found" }),
  );

  server.registerTool(
    "get_concept_graph",
    {
      description: "Concept graph (nodes + prerequisite/part_of/related edges). Optionally filtered by domain substring.",
      inputSchema: { domain: z.string().optional(), limit: z.number().int().min(1).max(500).optional() },
    },
    async ({ domain, limit }) => {
      const all = await db.select().from(concepts).limit(limit ?? 200);
      const nodes = domain ? all.filter((c) => (c.domain ?? "").toLowerCase().includes(domain.toLowerCase())) : all;
      const ids = nodes.map((n) => n.id);
      const edges = ids.length ? await db.select().from(conceptEdges).where(and(inArray(conceptEdges.fromConceptId, ids), inArray(conceptEdges.toConceptId, ids))) : [];
      return text({
        nodes: nodes.map((n) => ({ id: n.id, name: n.name, slug: n.slug, domain: n.domain, difficulty: n.difficulty, discoveredBy: n.discoveredBy, summary: n.summary.slice(0, 300), sourceUrl: n.sourceUrl })),
        edges: edges.map((e) => ({ from: e.fromConceptId, to: e.toConceptId, type: e.type, weight: e.weight, evidence: e.evidence })),
      });
    },
  );

  server.registerTool(
    "get_concept",
    { description: "Full material for one concept (by id or name).", inputSchema: { id: z.number().int().optional(), name: z.string().optional() } },
    async ({ id, name }) => {
      const c = id ? (await db.select().from(concepts).where(eq(concepts.id, id)))[0] : name ? await findConceptByName(name) : null;
      return text(c ?? { error: "not found" });
    },
  );

  server.registerTool(
    "get_recommendation",
    { description: "What the agent would do next for this learner and why (concept, strategy, rationale).", inputSchema: { learnerId: z.number().int() } },
    async ({ learnerId }) => text(await recommendation(learnerId)),
  );

  server.registerTool(
    "tutor_turn",
    { description: "Run one tutoring turn: send the learner's message through the agent and return its reply. This updates the learner model.", inputSchema: { learnerId: z.number().int(), message: z.string().min(1) } },
    async ({ learnerId, message }) => text(await handleTurn(learnerId, message)),
  );

  server.registerTool(
    "record_evidence",
    {
      description: "Record external evidence about the learner. kind='observation' stores raw evidence; kind='mastery_observation' also updates the mastery belief (needs conceptId, correct, optional guessRate); kind='mastery_prior' sets a prior (needs conceptId, p).",
      inputSchema: {
        learnerId: z.number().int(),
        kind: z.enum(["observation", "mastery_observation", "mastery_prior"]),
        conceptId: z.number().int().optional(),
        correct: z.boolean().optional(),
        guessRate: z.number().min(0).max(1).optional(),
        p: z.number().min(0).max(1).optional(),
        payload: z.record(z.string(), z.unknown()).optional(),
        source: z.string().optional(),
      },
    },
    async ({ learnerId, kind, conceptId, correct, guessRate, p, payload, source }) => {
      const goal = await activeGoal(learnerId);
      if (kind === "mastery_observation" && conceptId !== undefined && correct !== undefined) {
        const upd = await observeMastery(learnerId, conceptId, correct, guessRate ?? 0.1);
        await recordEvidence(learnerId, "external_mastery_observation", { correct, source: source ?? "mcp", ...payload }, goal?.id, conceptId);
        await recordDecision(learnerId, "external_evidence", `External assistant (${source ?? "mcp"}) reported ${correct ? "success" : "failure"} on concept ${conceptId}; belief ${upd.before.toFixed(2)} → ${upd.after.toFixed(2)}.`, { conceptId }, goal?.id);
        return text({ ok: true, before: upd.before, after: upd.after });
      }
      if (kind === "mastery_prior" && conceptId !== undefined && p !== undefined) {
        const row = await setMasteryPrior(learnerId, conceptId, p, source ?? "mcp-prior");
        return text({ ok: true, pKnown: row.pKnown, note: row.attempts > 0 ? "observed evidence exists; prior not applied" : "prior applied" });
      }
      const row = await recordEvidence(learnerId, "external_observation", { source: source ?? "mcp", ...payload }, goal?.id, conceptId);
      return text({ ok: true, id: row.id });
    },
  );

  server.registerTool(
    "get_history",
    { description: "Interaction history (messages) and evidence log for a learner.", inputSchema: { learnerId: z.number().int(), limit: z.number().int().min(1).max(200).optional() } },
    async ({ learnerId, limit }) => {
      const msgs = await db.select().from(messages).where(eq(messages.learnerId, learnerId)).orderBy(desc(messages.createdAt)).limit(limit ?? 50);
      const ev = await db.select().from(evidence).where(eq(evidence.learnerId, learnerId)).orderBy(desc(evidence.createdAt)).limit(limit ?? 50);
      return text({ messages: msgs.reverse(), evidence: ev.reverse() });
    },
  );

  server.registerTool(
    "get_mastery",
    { description: "Mastery beliefs for specific concepts.", inputSchema: { learnerId: z.number().int(), conceptIds: z.array(z.number().int()).min(1) } },
    async ({ learnerId, conceptIds }) => text(Object.fromEntries([...(await getMasteryMap(learnerId, conceptIds)).entries()])),
  );

  server.registerTool(
    "add_concept",
    {
      description: "Extend the concept graph. Researches the concept (Wikipedia) unless summary is provided; optionally links it as a prerequisite of / related to another concept.",
      inputSchema: {
        name: z.string().min(2),
        summary: z.string().optional(),
        domain: z.string().optional(),
        prerequisiteOf: z.number().int().optional(),
        relatedTo: z.number().int().optional(),
      },
    },
    async ({ name, summary, domain, prerequisiteOf, relatedTo }) => {
      let rc = summary ? null : await researchConcept(name);
      if (!rc) {
        rc = {
          title: name,
          slug: name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, ""),
          summary: summary ?? "",
          description: "",
          sections: [{ title: "Overview", text: summary ?? "" }],
          links: [],
          keyTerms: [],
          examples: [],
          sourceUrl: "",
          score: 1,
          difficulty: 0.5,
        };
      }
      const row = await upsertConcept(rc, "mcp", domain);
      if (prerequisiteOf) await addEdge(row.id, prerequisiteOf, "prerequisite", 0.5, { method: "mcp" });
      if (relatedTo) await addEdge(row.id, relatedTo, "related", 0.3, { method: "mcp" });
      return text({ ok: true, concept: { id: row.id, name: row.name, slug: row.slug } });
    },
  );

  server.registerTool(
    "add_prerequisite",
    { description: "Add a prerequisite edge between two existing concepts (from must be learned before to). Cycles are refused.", inputSchema: { fromConceptId: z.number().int(), toConceptId: z.number().int(), weight: z.number().min(0).max(1).optional() } },
    async ({ fromConceptId, toConceptId, weight }) => {
      await addEdge(fromConceptId, toConceptId, "prerequisite", weight ?? 0.5, { method: "mcp" });
      return text({ ok: true });
    },
  );

  return server;
}
