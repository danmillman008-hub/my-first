"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type Snapshot = {
  learner: { id: number; name: string };
  goal: {
    id: number;
    text: string;
    topic: string;
    plan: number[];
    rootConceptId: number | null;
    phase: string;
    currentConceptId: number | null;
    pending: { type: string; strategy: string } | null;
    failStreak: number;
    taughtCount: number;
  } | null;
  goals: { id: number; topic: string; status: string }[];
  affect: { frustration: number; confusion: number; engagement: number; fatigue: number; confidence: number };
  strategies: { strategy: string; mean: number; trials: number; successes: number }[];
  preferences: { key: string; value: unknown; confidence: number }[];
  concepts: { id: number; name: string; pKnown: number; uncertainty: number; attempts: number; correct: number; mastered: boolean; discoveredBy: string; source: string; sourceUrl: string | null }[];
  edges: { from: number; to: number; type: string }[];
  decisions: { id: number; type: string; rationale: string; createdAt: string }[];
  evidenceCount: number;
  llm: { provider: string; model: string };
};

type Msg = { id: number | string; role: string; content: string };

function renderMarkdown(md: string): string {
  const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const lines = md.split("\n");
  let html = "";
  let inList = false;
  let inQuote = false;
  const inline = (s: string) =>
    s
      .replace(/&lt;sub&gt;([\s\S]*?)&lt;\/sub&gt;/g, '<span class="text-xs text-slate-500">$1</span>')
      .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
      .replace(/_(.+?)_/g, "<em>$1</em>")
      .replace(/`(.+?)`/g, '<code class="rounded bg-slate-100 px-1 text-[0.9em]">$1</code>')
      .replace(/(https?:\/\/[^\s<]+)/g, '<a class="underline text-indigo-600" target="_blank" rel="noreferrer" href="$1">$1</a>');
  for (const raw of lines) {
    const line = esc(raw);
    if (/^\s*[-*] /.test(line) || /^\s*\d+\. /.test(line)) {
      if (!inList) {
        html += /^\s*\d+\. /.test(line) ? '<ol class="list-decimal pl-5 space-y-1">' : '<ul class="list-disc pl-5 space-y-1">';
        inList = true;
      }
      html += `<li>${inline(line.replace(/^\s*([-*]|\d+\.) /, ""))}</li>`;
      continue;
    } else if (inList) {
      html += html.endsWith("</li>") && html.includes("<ol") && html.lastIndexOf("<ol") > html.lastIndexOf("<ul") ? "</ol>" : "</ul>";
      inList = false;
    }
    if (/^&gt; ?/.test(line)) {
      if (!inQuote) {
        html += '<blockquote class="border-l-4 border-indigo-200 bg-indigo-50/60 pl-3 py-1 my-2 rounded-r">';
        inQuote = true;
      }
      html += `<p>${inline(line.replace(/^&gt; ?/, ""))}</p>`;
      continue;
    } else if (inQuote) {
      html += "</blockquote>";
      inQuote = false;
    }
    if (/^### /.test(line)) html += `<h3 class="text-lg font-semibold mt-2 mb-1">${inline(line.slice(4))}</h3>`;
    else if (/^---\s*$/.test(line)) html += '<hr class="my-3 border-slate-200" />';
    else if (line.trim() === "") html += "";
    else html += `<p class="my-1">${inline(line)}</p>`;
  }
  if (inList) html += "</ul>";
  if (inQuote) html += "</blockquote>";
  return html;
}

function Bar({ value, color, label, right }: { value: number; color: string; label: string; right?: string }) {
  return (
    <div className="text-xs">
      <div className="flex justify-between text-slate-600">
        <span className="truncate pr-2">{label}</span>
        <span className="tabular-nums">{right ?? `${Math.round(value * 100)}%`}</span>
      </div>
      <div className="mt-0.5 h-1.5 w-full rounded bg-slate-200">
        <div className={`h-1.5 rounded ${color}`} style={{ width: `${Math.max(2, Math.min(100, value * 100))}%` }} />
      </div>
    </div>
  );
}

export default function HomePage() {
  const [learnerName, setLearnerName] = useState("");
  const [learnerId, setLearnerId] = useState<number | null>(null);
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<"model" | "decisions" | "graph">("model");
  const bottomRef = useRef<HTMLDivElement>(null);

  const refresh = useCallback(async (id: number) => {
    const [s, m] = await Promise.all([fetch(`/api/learners/${id}/state`).then((r) => r.json()), fetch(`/api/learners/${id}/messages`).then((r) => r.json())]);
    setSnap(s);
    setMsgs(m.messages ?? []);
  }, []);

  useEffect(() => {
    const saved = typeof window !== "undefined" ? window.localStorage.getItem("learnerId") : null;
    const savedName = typeof window !== "undefined" ? window.localStorage.getItem("learnerName") : null;
    if (saved) {
      setLearnerId(Number(saved));
      setLearnerName(savedName ?? "");
      void refresh(Number(saved));
    }
  }, [refresh]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, busy]);

  async function start() {
    const name = learnerName.trim();
    if (!name) return;
    const r = await fetch("/api/learners", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name }) }).then((x) => x.json());
    setLearnerId(r.learner.id);
    window.localStorage.setItem("learnerId", String(r.learner.id));
    window.localStorage.setItem("learnerName", name);
    await refresh(r.learner.id);
  }

  async function send(text?: string) {
    const message = (text ?? input).trim();
    if (!message || !learnerId || busy) return;
    setInput("");
    setBusy(true);
    setMsgs((m) => [...m, { id: `u-${Date.now()}`, role: "user", content: message }]);
    try {
      const r = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ learnerId, message }) }).then((x) => x.json());
      setMsgs((m) => [...m, { id: `a-${Date.now()}`, role: "assistant", content: r.reply ?? r.error ?? "…" }]);
      await refresh(learnerId);
    } finally {
      setBusy(false);
    }
  }

  function signOut() {
    window.localStorage.removeItem("learnerId");
    window.localStorage.removeItem("learnerName");
    setLearnerId(null);
    setSnap(null);
    setMsgs([]);
  }

  if (!learnerId) {
    return (
      <main className="grid min-h-screen place-items-center px-6 py-12">
        <section className="w-full max-w-lg rounded-3xl bg-white p-10 shadow-[0_24px_60px_rgba(16,24,40,0.12)]">
          <p className="text-xs uppercase tracking-widest text-indigo-600">Private · self-adapting</p>
          <h1 className="mt-2 text-3xl font-semibold text-slate-950">Learning Agent</h1>
          <p className="mt-3 text-sm text-slate-600">
            Tell it what you want to learn. It researches the subject, builds the concept graph and prerequisites, finds out what you know, teaches you, and keeps adapting to how you learn — all stored in a persistent learner model you can inspect.
          </p>
          <form
            className="mt-6 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              void start();
            }}
          >
            <input value={learnerName} onChange={(e) => setLearnerName(e.target.value)} placeholder="Your name" className="flex-1 rounded-xl border border-slate-300 px-4 py-2.5 outline-none focus:border-indigo-500" />
            <button className="rounded-xl bg-indigo-600 px-5 py-2.5 font-medium text-white hover:bg-indigo-700">Start</button>
          </form>
        </section>
      </main>
    );
  }

  const rootId = snap?.goal?.rootConceptId ?? null;
  const planConcepts = snap?.goal ? snap.goal.plan.map((id) => snap.concepts.find((c) => c.id === id)).filter((c): c is NonNullable<typeof c> => !!c && c.id !== rootId) : [];
  const nameOf = (id: number) => snap?.concepts.find((c) => c.id === id)?.name.replace(/\s*\(.*\)$/, "") ?? `#${id}`;

  return (
    <main className="mx-auto flex h-screen max-w-7xl flex-col gap-4 p-4">
      <header className="flex items-center justify-between rounded-2xl bg-white px-5 py-3 shadow-sm">
        <div>
          <h1 className="text-lg font-semibold text-slate-900">Private Self-Adapting Learning Agent</h1>
          <p className="text-xs text-slate-500">
            Learner <strong>{snap?.learner.name ?? learnerName}</strong> · reasoning: {snap?.llm.provider === "none" ? "deterministic reasoner (set ANTHROPIC_API_KEY or OPENAI_API_KEY to enable LLM)" : `${snap?.llm.provider} / ${snap?.llm.model}`} · MCP endpoint: <code>/api/mcp</code>
          </p>
        </div>
        <button onClick={signOut} className="text-xs text-slate-500 underline">
          switch learner
        </button>
      </header>

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-4 lg:grid-cols-[1fr_380px]">
        {/* Chat */}
        <section className="flex min-h-0 flex-col rounded-2xl bg-white shadow-sm">
          <div className="flex-1 space-y-4 overflow-y-auto p-5">
            {msgs.length === 0 && (
              <div className="rounded-xl bg-indigo-50 p-4 text-sm text-slate-700">
                <p className="font-medium">What would you like to learn?</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {["I want to learn Object-Oriented Programming", "Teach me how photosynthesis works", "Help me understand Bayesian statistics"].map((s) => (
                    <button key={s} onClick={() => void send(s)} className="rounded-full border border-indigo-200 bg-white px-3 py-1 text-xs hover:bg-indigo-100">
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {msgs.map((m) => (
              <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${m.role === "user" ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-800"}`} dangerouslySetInnerHTML={{ __html: m.role === "user" ? m.content.replace(/</g, "&lt;") : renderMarkdown(m.content) }} />
              </div>
            ))}
            {busy && (
              <div className="flex justify-start">
                <div className="rounded-2xl bg-slate-100 px-4 py-3 text-sm text-slate-500">thinking… (researching, planning, updating your model)</div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>
          <form
            className="flex gap-2 border-t border-slate-100 p-3"
            onSubmit={(e) => {
              e.preventDefault();
              void send();
            }}
          >
            <input value={input} onChange={(e) => setInput(e.target.value)} disabled={busy} placeholder={snap?.goal?.pending ? "Type your answer…" : "Say what you want to learn, or ask anything…"} className="flex-1 rounded-xl border border-slate-300 px-4 py-2.5 text-sm outline-none focus:border-indigo-500" />
            <button disabled={busy} className="rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50">
              Send
            </button>
          </form>
          <div className="flex flex-wrap gap-1.5 px-3 pb-3 text-xs">
            {["continue", "give me an example", "step by step", "explain it differently", "quiz me", "status", "skip"].map((s) => (
              <button key={s} onClick={() => void send(s)} disabled={busy} className="rounded-full border border-slate-200 px-2.5 py-1 text-slate-600 hover:bg-slate-50 disabled:opacity-50">
                {s}
              </button>
            ))}
          </div>
        </section>

        {/* Learner model */}
        <aside className="flex min-h-0 flex-col rounded-2xl bg-white shadow-sm">
          <div className="flex border-b border-slate-100 text-sm">
            {(["model", "decisions", "graph"] as const).map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`flex-1 px-3 py-2.5 capitalize ${tab === t ? "border-b-2 border-indigo-600 font-medium text-indigo-700" : "text-slate-500"}`}>
                {t === "model" ? "Learner model" : t === "decisions" ? "Agent decisions" : "Concept graph"}
              </button>
            ))}
          </div>
          <div className="flex-1 space-y-5 overflow-y-auto p-4">
            {!snap && <p className="text-sm text-slate-500">Loading…</p>}
            {snap && tab === "model" && (
              <>
                <div>
                  <h2 className="text-xs font-semibold uppercase tracking-wide text-slate-500">Goal</h2>
                  <p className="mt-1 text-sm text-slate-800">{snap.goal ? `${snap.goal.topic} · ${snap.goal.phase}` : "none yet"}</p>
                </div>
                <div>
                  <h2 className="text-xs font-semibold uppercase tracking-wide text-slate-500">Mastery beliefs (learning path)</h2>
                  <div className="mt-2 space-y-2">
                    {planConcepts.length === 0 && <p className="text-xs text-slate-500">No path yet.</p>}
                    {planConcepts.map((c) => (
                      <Bar
                        key={c.id}
                        value={c.pKnown}
                        color={c.mastered ? "bg-emerald-500" : c.id === snap.goal?.currentConceptId ? "bg-indigo-500" : "bg-slate-400"}
                        label={`${c.id === snap.goal?.currentConceptId ? "▶ " : ""}${c.name.replace(/\s*\(.*\)$/, "")}${c.discoveredBy !== "research" ? " ✧" : ""}`}
                        right={`${Math.round(c.pKnown * 100)}% ±${Math.round(c.uncertainty * 100)} · ${c.correct}/${c.attempts}`}
                      />
                    ))}
                  </div>
                  <p className="mt-1 text-[10px] text-slate-400">✧ = discovered by the agent (prerequisite discovery / question). ± = uncertainty of the belief.</p>
                </div>
                <div>
                  <h2 className="text-xs font-semibold uppercase tracking-wide text-slate-500">Affect (inferred)</h2>
                  <div className="mt-2 space-y-2">
                    <Bar value={snap.affect.engagement} color="bg-emerald-500" label="engagement" />
                    <Bar value={snap.affect.confidence} color="bg-sky-500" label="confidence" />
                    <Bar value={snap.affect.confusion} color="bg-amber-500" label="confusion" />
                    <Bar value={snap.affect.frustration} color="bg-rose-500" label="frustration" />
                    <Bar value={snap.affect.fatigue} color="bg-violet-500" label="fatigue" />
                  </div>
                </div>
                <div>
                  <h2 className="text-xs font-semibold uppercase tracking-wide text-slate-500">What works for you (strategy posteriors)</h2>
                  <div className="mt-2 space-y-2">
                    {snap.strategies
                      .slice()
                      .sort((a, b) => b.mean - a.mean)
                      .map((s) => (
                        <Bar key={s.strategy} value={s.mean} color="bg-indigo-500" label={s.strategy.replace("_", " ")} right={`${Math.round(s.mean * 100)}% · ${s.successes}/${s.trials}`} />
                      ))}
                  </div>
                </div>
                {snap.preferences.length > 0 && (
                  <div>
                    <h2 className="text-xs font-semibold uppercase tracking-wide text-slate-500">Stated preferences</h2>
                    <ul className="mt-1 text-xs text-slate-700">
                      {snap.preferences.map((p) => (
                        <li key={p.key}>
                          {p.key}: <strong>{String(p.value)}</strong> (confidence {Math.round(p.confidence * 100)}%)
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                <p className="text-[11px] text-slate-400">{snap.evidenceCount} evidence records · {snap.goals.length} goal(s)</p>
              </>
            )}
            {snap && tab === "decisions" && (
              <ol className="space-y-3">
                {snap.decisions.length === 0 && <p className="text-xs text-slate-500">No decisions yet.</p>}
                {snap.decisions.map((d) => (
                  <li key={d.id} className="rounded-lg border border-slate-100 p-2.5">
                    <div className="flex items-center justify-between">
                      <span className="rounded bg-indigo-50 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-indigo-700">{d.type.replace(/_/g, " ")}</span>
                      <span className="text-[10px] text-slate-400">{new Date(d.createdAt).toLocaleTimeString()}</span>
                    </div>
                    <p className="mt-1 text-xs text-slate-700">{d.rationale}</p>
                  </li>
                ))}
              </ol>
            )}
            {snap && tab === "graph" && (
              <div className="space-y-3">
                <p className="text-xs text-slate-500">Prerequisite structure inferred from research (edges: from → to means “learn from before to”).</p>
                {planConcepts.map((c) => {
                  const pre = snap.edges.filter((e) => e.type === "prerequisite" && e.to === c.id).map((e) => nameOf(e.from));
                  return (
                    <div key={c.id} className="rounded-lg border border-slate-100 p-2.5 text-xs">
                      <div className="flex items-center justify-between">
                        <strong className="text-slate-800">{c.name.replace(/\s*\(.*\)$/, "")}</strong>
                        {c.sourceUrl && (
                          <a href={c.sourceUrl} target="_blank" rel="noreferrer" className="text-[10px] text-indigo-600 underline">
                            source
                          </a>
                        )}
                      </div>
                      <p className="text-slate-500">{pre.length ? `requires: ${pre.join(", ")}` : "no prerequisites"}</p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </aside>
      </div>
    </main>
  );
}
