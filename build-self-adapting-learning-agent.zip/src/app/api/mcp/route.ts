import { WebStandardStreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js";
import { createMcpServer } from "@/mcp/server";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

// Stateless Streamable HTTP: a fresh server + transport per request.
async function handle(req: Request) {
  const server = createMcpServer();
  const transport = new WebStandardStreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
  await server.connect(transport);
  try {
    return await transport.handleRequest(req);
  } finally {
    // close after response is produced (JSON mode responds synchronously)
    setTimeout(() => void server.close().catch(() => undefined), 0);
  }
}

export const POST = handle;
export const GET = handle;
export const DELETE = handle;
