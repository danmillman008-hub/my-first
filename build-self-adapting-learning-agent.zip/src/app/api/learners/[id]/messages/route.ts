import { recentMessages } from "@/agent/core";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const rows = await recentMessages(Number(id), 80);
  return Response.json({ messages: rows.map((m) => ({ id: m.id, role: m.role, content: m.content, createdAt: m.createdAt })) });
}
