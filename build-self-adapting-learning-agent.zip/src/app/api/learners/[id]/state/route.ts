import { learnerSnapshot } from "@/agent/core";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const snap = await learnerSnapshot(Number(id));
  if (!snap) return Response.json({ error: "not found" }, { status: 404 });
  return Response.json(snap);
}
