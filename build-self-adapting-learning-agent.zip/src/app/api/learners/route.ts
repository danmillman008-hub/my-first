import { db } from "@/db";
import { learners } from "@/db/schema";
import { ensureLearner } from "@/agent/core";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(learners).orderBy(desc(learners.createdAt)).limit(50);
  return Response.json({ learners: rows });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { name?: string };
  const name = (body.name ?? "").trim().slice(0, 60);
  if (!name) return Response.json({ error: "name required" }, { status: 400 });
  const learner = await ensureLearner(name);
  return Response.json({ learner });
}
