import { handleTurn } from "@/agent/agent";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { learnerId?: number; message?: string };
  const learnerId = Number(body.learnerId);
  const message = (body.message ?? "").toString().trim().slice(0, 4000);
  if (!learnerId || !message) return Response.json({ error: "learnerId and message required" }, { status: 400 });
  try {
    const result = await handleTurn(learnerId, message);
    return Response.json(result);
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}
