# Private Self-Adapting Learning Agent

Tell it what you want to learn in plain language. It researches the subject, builds a concept graph with
prerequisites, finds out what you already know, teaches you, observes the evidence, updates a persistent
learner model, and changes strategy when the current one is not working.

```
LEARNER ──▶ AGENT (src/agent/agent.ts)            ──▶ ADAPTIVE CORE (Postgres via Drizzle)
            understand · research · plan · teach       concepts + prerequisite edges (open-domain)
            diagnose · adapt · re-plan · investigate    mastery beliefs (BKT + Beta uncertainty + decay)
            optional LLM reasoning / tool use           strategy posteriors (Thompson sampling)
                                                        affect · preferences · evidence · decisions
MCP (/api/mcp, official SDK, Streamable HTTP) ──▶ read state / graph / recommendations, record evidence, tutor turns, extend graph
```

## How it works

| Stage | Implementation |
|---|---|
| Understand goal | Intent parsing (`agent.ts`), LLM-classified when a key is present |
| Research domain | `research.ts`: Wikimedia Core API + REST (throttled, cached, multi-source failover); candidate concepts from article link structure, non-concepts (people/languages/products) filtered by page descriptions |
| Knowledge representation | Prerequisites inferred with definition-mention + RefD reference distance (Liang et al. 2015); foundational prerequisites discovered *outside* the article; cycle-free graph persisted in `concepts`/`concept_edges`, reused & extended on later requests |
| Starting state | Self-report becomes a **prior**, never evidence; verified by exercises |
| Teach | Strategy chosen by per-learner Thompson sampling (concise / detailed / example / analogy / step-by-step), modulated by affect and stated preference; lesson composed from researched material (LLM when available) |
| Observe | 4 exercise formats with format-specific guess rates; grading; response-time & lexical affect signals |
| Update model | BKT posterior + Beta counts (uncertainty) + spacing-based decay; strategy posterior; affect decay; append-only evidence; interpretable decision log |
| Adapt / re-plan | fail → strategy switch → weakest prerequisite remediation → **failure-driven discovery** of missing prerequisites (research + graph extension + path revision); over-claimed mastery is revised down by evidence |
| Investigate on demand | Learner questions outside the graph trigger research and graph extension |

No LLM key is required. With `ANTHROPIC_API_KEY` or `OPENAI_API_KEY` (optional `LLM_MODEL`, `OPENAI_BASE_URL`) the agent
additionally uses the model for intent, curriculum refinement, lesson writing, exercise generation, free-response grading,
and a bounded tool-use deliberation loop when a learner is stuck. `WIKIMEDIA_ACCESS_TOKEN` raises research rate limits.

## Verification

```
npx tsx scripts/verify.ts all        # 33 behavioural checks against the real DB and live research
npx tsx scripts/mcp-test.ts <url>    # MCP client test against a running server (/api/mcp)
npx tsx scripts/probe-research.ts "<topic>"   # inspect the graph the researcher builds for any topic
```

Scenarios covered: open-domain research → graph → topologically consistent path; a learner who only understands
examples (agent's `example` posterior rises to ≈0.95 and its lesson choice shifts to 100% example); a learner who always
fails (strategy switch → prerequisite remediation → discovery of new prerequisites; frustration inferred); a learner who
over-claims (prior 0.60 revised to 0.22 by evidence, logged as `belief_revised`); explicit affect/preference statements;
a second domain (photosynthesis) and an out-of-graph question that is researched on demand.

## MCP

Endpoint: `POST /api/mcp` (stateless Streamable HTTP). Tools: `list_learners`, `ensure_learner`, `get_learner_state`,
`get_concept_graph`, `get_concept`, `get_mastery`, `get_recommendation`, `tutor_turn`, `record_evidence`, `get_history`,
`add_concept`, `add_prerequisite`.
