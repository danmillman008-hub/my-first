# Human–AI Adaptation Laboratory

> Can an AI become genuinely better at working with one particular human over a long period of time?

This repository is both the **system** (a chat assistant that learns how to work with one person, with every belief
inspectable, disputable and erasable) and the **laboratory** that tests whether it actually works (simulated people
with hidden, changing, context-dependent preferences and a model of the AI; six memory conditions; per-session metrics).

Read [`docs/FINDINGS.md`](docs/FINDINGS.md) for what was investigated, measured and concluded.

## Run

```bash
npm install
npx drizzle-kit push        # creates the tables
npm run dev                 # http://localhost:3000
```

Without an LLM key the app runs on a clearly-labelled offline model so the memory layer, UI and lab work end to end.
Set `ANTHROPIC_API_KEY` (or `OPENAI_API_KEY`, or `GEMINI_API_KEY`) in the environment to use a real model — chosen at
request time, no rebuild. Optional: `ANTHROPIC_MODEL`, `OPENAI_MODEL`, `GEMINI_MODEL`, `LLM_PROVIDER=mock`.

* `/` — the workbench: chat on the left, *what it believes about you* on the right (beliefs with basis/confidence/
  evidence and a **not true** button, evidence log with per-item delete, the self-model, the exact brief the model
  receives). Each reply has a **why this turn** trace.
* `/lab` — the laboratory: run it, read the tables and the time-course charts.
* `/findings` — the findings document.

```bash
npx tsx scripts/lab.ts                    # lab in the terminal  (SESSIONS=30 SEEDS=3 CURVE=drifter …)
npx tsx scripts/sweep.ts                  # recency half-life sweep + 30-session horizon
```

## Layout

```
src/lib/core/model.ts     pure core: evidence → beliefs (lifecycle, corrections, change detection, tensions),
                          facts, self-model ledger, turn planning. No I/O. Shared by app and lab.
src/lib/sim/human.ts      the simulated person (hidden truth, wrong self-knowledge, drift, politeness, trust)
src/lib/sim/lab.ts        conditions, metrics, runner
src/lib/agent/turn.ts     one real turn: brief → model → reflection → evidence
src/lib/agent/store.ts    Postgres access (Drizzle)
src/lib/llm/index.ts      Anthropic / OpenAI / Gemini / offline providers
src/app/api/*             chat, memory (GET/DELETE), beliefs/[id] (DELETE = "not true"), observations/[id],
                          facts, sessions, lab, status, health
src/components/Workbench.tsx, src/app/lab/*, src/app/findings/page.tsx
docs/FINDINGS.md          what we learned
```

Secrets are read from the environment server-side only and never written to source, logs or the database.
