# The Human–AI Adaptation Laboratory — findings

Question: can an AI become genuinely better at working with one particular human over time — and what is the
smallest machinery that makes that happen?

This document records what was investigated, what was built, what was measured, and what we now believe.
Numbers come from the laboratory in this repository (deterministic; re-run at /lab or `npx tsx scripts/lab.ts`).

## 1. What the archive taught (evidence, not instructions)

The archive (`danmillman008-hub/my-first`) contains 16 generations. The newest of them had already done a forensic
pass over the rest. What survives across their own labs:

* **Reaction metrics are not outcomes.** An explain-only tutor *won* on "that makes sense" while producing almost no
  learning. Every generation that optimised reactions (Thompson-sampling style bandits, affect engines) showed ≈0 benefit.
* **Epistemics about the person mattered every time they were measured:** claimed ≠ demonstrated, corrections must
  retire a belief *and* guard against immediate re-inference, credit for an approach must be assigned on the *next*
  turn, evidence must be append-only and inspectable.
* **Heavy structure never paid for itself:** concept graphs (4 attempts), curated subject packs, MCP servers, regex
  perception — thousands of lines, no measured adaptation benefit, and most of the recurring bugs.
* **Two things were never tested:** (a) the model *deciding* rather than a deterministic engine deciding, because no
  generation ever had an LLM key at build time; (b) **co-adaptation** — the human changing their behaviour in response
  to the AI. Every simulated learner was a passive responder.

Graphify (`pip install graphifyy`) runs offline as an AST extractor (1.5k nodes / 3k edges over six generations).
Its only structural finding was that every generation has a monolithic `engine.ts` god-node — consistent with the
forensics, but the written DECISIONS/EVALUATION documents were far more informative than the graph. Verdict: not
worth its complexity for this problem.

No LLM key is present in this sandbox either. The live path (Anthropic / OpenAI / Gemini, chosen at request time from
the environment) is implemented and validated against API documentation, but every number below comes from the
offline laboratory. Its claims are about the *memory layer*, not about any model's prose.

## 2. What was built

Roughly 1.2k lines of core, deliberately small:

* **Evidence log** (append-only, with message provenance): `stated` / `demonstrated` / `reaction` / `correction`
  observations on five continuous *working dimensions* (depth, examples, checks, directness, pace), each scoped to a
  context (quick task / learning / debugging / planning) or general. Plus **facts** ("nurse", "uses Rust") with
  supersession and retraction.
* **Beliefs are derived, never stored.** `deriveBeliefs(evidence)` is a pure function: recency-weighted evidence,
  kind weights (demonstrated 1.0 > stated 0.6 > reaction 0–0.25), confidence capped at 0.92, inferred beliefs need
  two sessions before they are acted on, corrections retire and guard for 14 days, a CUSUM change-point test marks
  "the person may have changed", and **tensions** (what they say vs what works) are surfaced rather than resolved.
  Because beliefs are derived, deleting one piece of evidence re-derives everything honestly.
* **Self-model:** a ledger of what the AI tried (approach vector, context, which beliefs it relied on) whose outcome is
  filled in from the *next* human turn. It yields "what has actually worked with this person when debugging" and can
  disagree with a belief.
* **Brief compiler:** everything above becomes ~100–250 tokens of epistemically labelled notes for the model, plus a
  planned approach and at most one question to raise (an unknown dimension, or a tension).
* **Reflection:** after replying, the model extracts structured evidence from the exchange (JSON, validated and
  clamped). The model reads; the layer keeps the books.
* **The person's controls:** every belief shows basis, confidence, evidence count and status; "not true" records a
  correction; any evidence item can be deleted; facts can be marked no longer true; everything can be erased; the exact
  brief is visible; every reply has a "why this turn" trace.
* **The laboratory:** five simulated people with hidden context-dependent preferences, wrong self-knowledge,
  unannounced drift, changing facts, politeness bias, and a *model of the AI* (trust) that governs how much they bother
  to explain themselves. Six conditions share the identical core. Perception is deliberately noisy.

## 3. What the laboratory showed (12 sessions × 8 turns × 4 seeds × 5 people)

| condition | fit early → late (hidden) | success late | restatements / session | trust late (hidden) | context tokens |
|---|---|---|---|---|---|
| none (no memory) | 0.71 → 0.69 | 0.74 | 1.26 | 0.58 | 0 |
| transcript (raw recent history) | 0.82 → **0.77** | 0.80 | 0.31 | 0.88 | 1146 |
| beliefs_static (no change detection) | 0.85 → 0.92 | 0.89 | 0.47 | 0.95 | 78 |
| beliefs_react (reactions count) | 0.86 → 0.93 | 0.92 | 0.44 | 0.96 | 104 |
| beliefs | 0.85 → 0.93 | 0.90 | 0.45 | 0.96 | 78 |
| full (beliefs + self-model + probes/tensions) | **0.88 → 0.94** | **0.92** | 0.74 | 0.86 | 125 |

Over 30 sessions: belief-based conditions keep improving (0.87 → 0.97), restatements fall to ≈0, the brief stays
≈100 tokens with 7–8 active beliefs; the transcript baseline *degrades* (0.87 → 0.80) while costing 12× the context.

### 3.1 Findings

1. **Adaptation is real and measurable, and it is longitudinal.** Fit improves monotonically across sessions for every
   evidence-based condition, for every person, and is still improving at session 30. The per-message view would miss it.
2. **Raw memory becomes harmful over time.** A transcript is nearly as good as beliefs in the first sessions and then
   gets *worse*, because it treats every self-description as true forever and cannot tell claim from demonstration. This
   is the archive's "stale memory" result reproduced with a different mechanism.
3. **The biggest single win is distinguishing what people say from what works for them.** The two people with poor
   self-knowledge (the "terse engineer" who says they like detail; the "polite novice" who says theory is fine) are
   where memory conditions separate from transcript by 0.2–0.3 fit. The stable, self-aware person gains almost nothing
   from any machinery (0.93 → 0.99) — a useful control: memory should help a little and never hurt, and it doesn't.
4. **A co-adaptation trap exists.** Asking people about themselves ("how do you like me to handle X?") buys trust fast
   (1.0 by session 2) — but it creates *stated commitments* that may be wrong. When the AI then correctly follows
   demonstrated behaviour instead, the person sees their words ignored, trust erodes, and they start restating
   themselves more. The `full` condition's higher restatement count is exactly this. The remedy that worked was
   **surfacing the tension once** ("you said X, but Y seems to work better — keep Y?"): the person's own self-model
   updates, trust for the terse engineer recovered from 0.60 to 0.76, and restatements fell by 17%. Both sides adapt.
5. **Trust and fit diverge.** The transcript condition earns high trust (it obeys what it was told) with low fit.
   A system optimised for "did it listen to me" would ship the transcript. The hidden outcome says otherwise. Any
   evaluation must include an outcome the person cannot directly report.
6. **Reactions as evidence: it depends on the person.** Counting "thanks, helpful" helps the blunt engineer (whose
   reactions are honest) and slows drift recovery for polite people (whose reactions confirm whatever the AI is doing).
   Since politeness is itself unknown, the default is to give reactions no weight and let the self-model use them only
   as a tie-breaker. Overall difference: within noise.
7. **Explicit change detection earned little.** Recency weighting alone recovers from an unannounced change in 2–6
   sessions; CUSUM adds ~0.01 fit at 30 sessions. Worth keeping because it is cheap and it *labels* the belief
   "may have changed" for the person and the model — but it is not the mechanism that does the work.
8. **How fast should adaptation be allowed to change?** Evidence should lose half its weight in about 1–3 weeks.
   3 days forgets hard-won stable preferences (terse engineer 0.93 → 0.87); ≥60 days traps the person who changed
   (drifter recovery 2 → 5 sessions). The system is robust across 7–21 days.
9. **The smallest machinery that works:** an append-only evidence log with kinds, a pure derivation into beliefs with
   recency weighting + correction guard + cross-session requirement, facts with supersession, and a compact brief.
   That is ≈300 lines and produces >90% of the gain. The self-model and the probes add a modest early advantage and the
   tension mechanism; everything else in the archive (graphs, bandits, affect, item banks, MCP) was not needed.
10. **A simulated human is useful for exactly one thing:** finding failure modes of the *bookkeeping* — stale facts,
    over-trust of claims, the commitment trap, memory bloat. It says nothing about whether a model reads people well or
    teaches well; every effect size here is partly a property of the simulation.

### 3.2 What could not be shown here

* Whether a live model follows the brief, extracts evidence conservatively, and raises tensions gracefully. The
  reflection prompt is validated structurally, not behaviourally.
* Human learning outcomes. The lab's "success" is a hidden function of fit; real learning needs real people over weeks.
* Whether five dimensions are the right representation of "how someone works". They are a first, inspectable guess.

## 4. What adaptation turned out to mean

Not memory as such, and not tone. It meant: keeping the distinction between what a person claims, what they
demonstrate, and how they react; being willing to be corrected and to notice change; knowing what you yourself have
tried with them; giving them the means to see and fix what you think; and — the part no previous generation had —
occasionally telling them what you have noticed, so that *their* model of themselves and of you can update too.

## 5. Next steps with a key

`ANTHROPIC_API_KEY`, `OPENAI_API_KEY` or `GEMINI_API_KEY` in the environment switches the provider at request time.
Then: run a live lab where the simulated person is verbalised by a model and correctness is still dictated by hidden
state; measure extraction precision of the reflection step against the sim's ground truth; tune the tension wording
from real traces; and only then put it in front of the real person for weeks, watching restatements and corrections.
