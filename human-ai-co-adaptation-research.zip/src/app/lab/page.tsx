import { db } from "@/db";
import { desc } from "drizzle-orm";
import { labRuns } from "@/db/schema";
import { nid } from "@/lib/agent/store";
import { runLab, DEFAULT_LAB, CONDITION_DESCRIPTIONS, ARCHETYPES, LabSummary } from "@/lib/sim/lab";
import LabClient from "./LabClient";

export const dynamic = "force-dynamic";

export default async function LabPage() {
  let rows = await db.select().from(labRuns).orderBy(desc(labRuns.createdAt)).limit(1);
  if (!rows.length) {
    const t0 = Date.now();
    const { summary } = runLab(DEFAULT_LAB);
    rows = await db.insert(labRuns).values({ id: nid("lab_"), config: DEFAULT_LAB, summary, durationMs: Date.now() - t0 }).returning();
  }
  const r = rows[0];
  const initial = { id: r.id, createdAt: r.createdAt.toISOString(), config: r.config as { sessions: number; seeds: number; turnsPerSession: number }, summary: r.summary as LabSummary, durationMs: r.durationMs };
  return <LabClient initial={initial} descriptions={CONDITION_DESCRIPTIONS} archetypes={ARCHETYPES.map((a) => ({ name: a.name, description: a.description }))} />;
}
