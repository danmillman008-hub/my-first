"use client";
import { useState } from "react";
import Link from "next/link";
import type { LabSummary, SessionMetrics } from "@/lib/sim/lab";

type Run = { id: string; createdAt: string; config: { sessions: number; seeds: number; turnsPerSession: number }; summary: LabSummary; durationMs: number };
const COND_COLORS: Record<string, string> = { none: "#94a3b8", transcript: "#f59e0b", beliefs_static: "#a78bfa", beliefs_react: "#f472b6", beliefs: "#6366f1", full: "#059669" };
const f = (x: number | undefined) => x == null || Number.isNaN(x) ? "–" : x.toFixed(2);

export default function LabClient({ initial, descriptions, archetypes }: { initial: Run | null; descriptions: Record<string, string>; archetypes: { name: string; description: string }[] }) {
  const [run, setRun] = useState<Run | null>(initial);
  const [busy, setBusy] = useState(false);
  const [sessions, setSessions] = useState(initial?.config.sessions ?? 12);
  const [seeds, setSeeds] = useState(initial?.config.seeds ?? 4);
  const [metric, setMetric] = useState<keyof SessionMetrics>("fit");

  async function rerun() {
    setBusy(true);
    const d = await (await fetch("/api/lab", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ sessions, seeds }) })).json();
    setRun(d.run); setBusy(false);
  }
  const conds = run ? Object.keys(run.summary.byCondition) : [];
  return (
    <div className="mx-auto max-w-6xl px-6 py-8 text-sm">
      <div className="mb-6 flex items-end justify-between">
        <div>
          <Link href="/" className="text-xs text-indigo-600 hover:underline">← back to the workbench</Link>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight">Laboratory</h1>
          <p className="mt-1 max-w-3xl text-slate-600">Simulated people with hidden, context-dependent, changing preferences and imperfect self-knowledge, run against the same core under different memory conditions. The AI never sees hidden state; its perception of messages is deliberately noisy. Metrics are per session so the time-course is visible.</p>
        </div>
        <form onSubmit={(e) => { e.preventDefault(); rerun(); }} className="flex items-center gap-2 text-xs">
          <label>sessions <input type="number" min={4} max={30} value={sessions} onChange={(e) => setSessions(+e.target.value)} className="w-14 rounded border px-1 py-0.5" /></label>
          <label>seeds <input type="number" min={1} max={8} value={seeds} onChange={(e) => setSeeds(+e.target.value)} className="w-12 rounded border px-1 py-0.5" /></label>
          <button disabled={busy} className="rounded bg-slate-900 px-3 py-1.5 text-white disabled:opacity-50">{busy ? "running…" : "run lab"}</button>
        </form>
      </div>
      {!run && <p>No runs yet.</p>}
      {run && (
        <>
          <p className="mb-2 text-xs text-slate-500">run {run.id} · {new Date(run.createdAt).toLocaleString()} · {run.summary.runs} runs ({run.config.sessions} sessions × {run.config.turnsPerSession} turns × {run.config.seeds} seeds × {archetypes.length} people × {conds.length} conditions) in {run.durationMs} ms</p>
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-left text-slate-600"><tr>
                <th className="p-2">condition</th><th className="p-2" title="hidden: match between how the AI worked and the person's real preference">fit early → late</th><th className="p-2" title="hidden task/learning outcome">success early → late</th><th className="p-2" title="visible but politeness-biased">“thanks” late</th><th className="p-2">restatements /session</th><th className="p-2">violations</th><th className="p-2">stale facts</th><th className="p-2" title="mean |belief − truth| for dims acted on">belief err (late)</th><th className="p-2">probes</th><th className="p-2" title="hidden: the person's model of whether the AI listens">trust (late)</th><th className="p-2">context tokens</th>
              </tr></thead>
              <tbody>{conds.map((c) => { const s = run.summary.byCondition[c]; return (
                <tr key={c} className="border-t border-slate-100">
                  <td className="p-2 font-medium" style={{ color: COND_COLORS[c] }}>{c}<div className="max-w-xs font-normal text-slate-500">{descriptions[c]}</div></td>
                  <td className="p-2">{f(s.early.fit)} → <b>{f(s.late.fit)}</b></td><td className="p-2">{f(s.early.success)} → <b>{f(s.late.success)}</b></td><td className="p-2">{f(s.late.reactionPositive)}</td><td className="p-2">{f(s.all.restatements)}</td><td className="p-2">{f(s.all.violations)}</td><td className="p-2">{f(s.all.staleFactUses)}</td><td className="p-2">{f(s.late.beliefError)}</td><td className="p-2">{f(s.all.probes)}</td><td className="p-2">{f(s.late.trust)}</td><td className="p-2">{Math.round(s.all.contextTokens ?? 0)}</td>
                </tr>); })}</tbody>
            </table>
          </div>

          <div className="mt-6 rounded-xl border border-slate-200 bg-white p-4">
            <div className="mb-2 flex items-center gap-3 text-xs">
              <span className="font-medium">time course:</span>
              {(["fit", "success", "trust", "restatements", "violations", "activeBeliefs", "reactionPositive"] as (keyof SessionMetrics)[]).map((m) => <button key={m} onClick={() => setMetric(m)} className={`rounded px-2 py-0.5 ${metric === m ? "bg-slate-900 text-white" : "bg-slate-100"}`}>{m}</button>)}
            </div>
            <Chart run={run} metric={metric} conds={conds} />
            <div className="mt-2 flex flex-wrap gap-3 text-xs">{conds.map((c) => <span key={c} className="flex items-center gap-1"><span className="inline-block h-2 w-4" style={{ background: COND_COLORS[c] }} />{c}</span>)}</div>
          </div>

          <h2 className="mt-8 text-lg font-semibold">Per person</h2>
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-left text-slate-600"><tr><th className="p-2">person</th>{conds.map((c) => <th key={c} className="p-2" style={{ color: COND_COLORS[c] }}>{c}</th>)}</tr></thead>
              <tbody>{archetypes.map((a) => (
                <tr key={a.name} className="border-t border-slate-100 align-top">
                  <td className="p-2"><div className="font-medium">{a.name}</div><div className="max-w-xs text-slate-500">{a.description}</div></td>
                  {conds.map((c) => { const r = run.summary.byConditionArchetype[c][a.name]; return <td key={c} className="p-2">fit {f(r.fitEarly)} → <b>{f(r.fitLate)}</b><br />success late {f(r.successLate)}<br />restate {f(r.restatements)} · viol {f(r.violations)}{r.driftRecovery != null && <><br />recovery {r.driftRecovery} sess.</>}</td>; })}
                </tr>))}</tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

function Chart({ run, metric, conds }: { run: Run; metric: keyof SessionMetrics; conds: string[] }) {
  const W = 900, H = 220, P = 30;
  const series = conds.map((c) => ({ c, ys: run.summary.byCondition[c].perSession.map((m) => (m[metric] as number) ?? 0) }));
  const all = series.flatMap((s) => s.ys).filter((y) => !Number.isNaN(y));
  const lo = Math.min(...all), hi = Math.max(...all);
  const n = run.config.sessions;
  const x = (i: number) => P + (i / Math.max(1, n - 1)) * (W - 2 * P);
  const y = (v: number) => H - P - ((v - lo) / Math.max(1e-6, hi - lo)) * (H - 2 * P);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full">
      <line x1={P} y1={H - P} x2={W - P} y2={H - P} stroke="#e2e8f0" /><line x1={P} y1={P} x2={P} y2={H - P} stroke="#e2e8f0" />
      <text x={4} y={P + 4} fontSize={10} fill="#64748b">{hi.toFixed(2)}</text><text x={4} y={H - P} fontSize={10} fill="#64748b">{lo.toFixed(2)}</text>
      {Array.from({ length: n }, (_, i) => <text key={i} x={x(i)} y={H - P + 12} fontSize={9} fill="#94a3b8" textAnchor="middle">s{i}</text>)}
      {series.map((s) => <polyline key={s.c} fill="none" stroke={COND_COLORS[s.c]} strokeWidth={s.c === "full" || s.c === "beliefs" ? 2.5 : 1.5} points={s.ys.map((v, i) => `${x(i)},${y(Number.isNaN(v) ? lo : v)}`).join(" ")} />)}
    </svg>
  );
}
