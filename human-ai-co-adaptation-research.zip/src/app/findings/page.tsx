import fs from "node:fs";
import path from "node:path";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default function FindingsPage() {
  let md = "";
  try { md = fs.readFileSync(path.join(process.cwd(), "docs", "FINDINGS.md"), "utf8"); } catch { md = "FINDINGS.md not found."; }
  return (
    <div className="mx-auto max-w-3xl px-6 py-8">
      <Link href="/" className="text-xs text-indigo-600 hover:underline">← back to the workbench</Link>
      <article className="prose-sm mt-4 whitespace-pre-wrap font-mono text-[12.5px] leading-relaxed text-slate-800">{md}</article>
    </div>
  );
}
