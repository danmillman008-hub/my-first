import { getProvider } from "@/lib/llm";
export const dynamic = "force-dynamic";
export async function GET() {
  const p = getProvider();
  return Response.json({ provider: p.name, live: p.live });
}
