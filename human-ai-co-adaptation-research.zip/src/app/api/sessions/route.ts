import { DEFAULT_PERSON, ensurePerson, listSessions } from "@/lib/agent/store";
export const dynamic = "force-dynamic";
export async function GET() {
  const personId = await ensurePerson(DEFAULT_PERSON);
  return Response.json({ sessions: await listSessions(personId) });
}
