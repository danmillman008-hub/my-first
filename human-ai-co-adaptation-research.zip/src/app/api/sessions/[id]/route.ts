import { NextRequest } from "next/server";
import { loadMessages } from "@/lib/agent/store";
export const dynamic = "force-dynamic";
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const rows = await loadMessages(id, 200);
  return Response.json({ messages: rows.map((m) => ({ id: m.id, role: m.role, content: m.content, meta: m.meta, createdAt: m.createdAt })) });
}
