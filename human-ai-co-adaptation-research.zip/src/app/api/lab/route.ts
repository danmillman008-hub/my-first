import { NextRequest } from "next/server";
import { db } from "@/db";
import { desc } from "drizzle-orm";
import { labRuns } from "@/db/schema";
import { nid } from "@/lib/agent/store";
import { runLab, DEFAULT_LAB } from "@/lib/sim/lab";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function GET() {
  const rows = await db.select().from(labRuns).orderBy(desc(labRuns.createdAt)).limit(10);
  return Response.json({ runs: rows });
}

/** Run the laboratory (simulated people × conditions) and store the summary. Deterministic for a given config. */
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as { sessions?: number; seeds?: number; turnsPerSession?: number };
  const cfg = { ...DEFAULT_LAB, sessions: clampInt(body.sessions, 4, 30, DEFAULT_LAB.sessions), seeds: clampInt(body.seeds, 1, 8, DEFAULT_LAB.seeds), turnsPerSession: clampInt(body.turnsPerSession, 4, 16, DEFAULT_LAB.turnsPerSession) };
  const t0 = Date.now();
  const { summary } = runLab(cfg);
  const durationMs = Date.now() - t0;
  const [row] = await db.insert(labRuns).values({ id: nid("lab_"), config: cfg, summary, durationMs }).returning();
  return Response.json({ run: row });
}

function clampInt(v: unknown, lo: number, hi: number, d: number) { const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, Math.round(n))) : d; }
