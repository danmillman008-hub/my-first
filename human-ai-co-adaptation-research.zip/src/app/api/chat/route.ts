import { NextRequest } from "next/server";
import { runTurn } from "@/lib/agent/turn";
import { DEFAULT_PERSON, ensurePerson } from "@/lib/agent/store";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as { message?: string; sessionId?: string | null };
  const message = (body.message ?? "").trim();
  if (!message) return Response.json({ error: "message required" }, { status: 400 });
  const personId = await ensurePerson(DEFAULT_PERSON);
  try {
    const result = await runTurn(personId, body.sessionId ?? null, message.slice(0, 8000));
    return Response.json(result);
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}
