import { NextRequest } from "next/server";
import { db } from "@/db";
import { observations } from "@/db/schema";
import { DEFAULT_PERSON, ensurePerson, nid } from "@/lib/agent/store";
import { DIMS, CONTEXTS, Dim } from "@/lib/core/model";

export const dynamic = "force-dynamic";

/** "That's not true about me": records a correction, which retires the belief and guards re-inference. */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [dim, scope] = decodeURIComponent(id).split("@");
  if (!DIMS.includes(dim as Dim) || !(scope === "any" || CONTEXTS.includes(scope as (typeof CONTEXTS)[number]))) return Response.json({ error: "bad belief id" }, { status: 400 });
  const personId = await ensurePerson(DEFAULT_PERSON);
  await db.insert(observations).values({ id: nid("o_"), personId, sessionId: "ui", kind: "correction", dim, scope, value: 0.5, note: "marked as not true by the person (UI)" });
  return Response.json({ ok: true });
}
