import { db } from "@/db";
import { eq } from "drizzle-orm";
import { approachRecords, factObservations, observations, sessions } from "@/db/schema";
import { DEFAULT_PERSON, ensurePerson, loadPersonState } from "@/lib/agent/store";
import { compileBrief } from "@/lib/agent/turn";
import { CONTEXTS, ledgerSuggestion } from "@/lib/core/model";

export const dynamic = "force-dynamic";

/** Everything the system believes about the person, with evidence, plus the exact brief the model receives. */
export async function GET() {
  const personId = await ensurePerson(DEFAULT_PERSON);
  const now = Date.now();
  const state = await loadPersonState(personId, now);
  const selfModel = CONTEXTS.map((c) => ({ context: c, attributed: state.ledger.filter((l) => l.context === c && l.outcome).length, successRate: rate(state.ledger.filter((l) => l.context === c && l.outcome?.known !== false && l.outcome).map((l) => l.outcome!.success)), suggestion: ledgerSuggestion(state.ledger, c, now)?.approach ?? null }));
  const brief = compileBrief(state, "quick_task", now, new Set());
  return Response.json({
    beliefs: state.beliefs,
    facts: state.facts,
    observations: state.observations.slice(-200),
    factObservations: state.factObservations,
    selfModel,
    ledgerSize: state.ledger.length,
    brief: brief.text,
    briefTokens: brief.tokens,
  });
}

/** Erase everything known about the person (evidence, self-model, conversations). */
export async function DELETE() {
  const personId = await ensurePerson(DEFAULT_PERSON);
  await db.delete(observations).where(eq(observations.personId, personId));
  await db.delete(factObservations).where(eq(factObservations.personId, personId));
  await db.delete(approachRecords).where(eq(approachRecords.personId, personId));
  await db.delete(sessions).where(eq(sessions.personId, personId));
  return Response.json({ ok: true });
}

function rate(xs: boolean[]) { return xs.length ? xs.filter(Boolean).length / xs.length : null; }
