import { NextRequest } from "next/server";
import { db } from "@/db";
import { factObservations } from "@/db/schema";
import { DEFAULT_PERSON, ensurePerson, nid } from "@/lib/agent/store";

export const dynamic = "force-dynamic";

/** The person retracts or states a fact directly. */
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as { key?: string; value?: string; kind?: "stated" | "retracted" };
  if (!body.key || !body.value) return Response.json({ error: "key and value required" }, { status: 400 });
  const personId = await ensurePerson(DEFAULT_PERSON);
  await db.insert(factObservations).values({ id: nid("f_"), personId, sessionId: "ui", key: body.key.slice(0, 60), value: body.value.slice(0, 120), kind: body.kind === "retracted" ? "retracted" : "stated" });
  return Response.json({ ok: true });
}
