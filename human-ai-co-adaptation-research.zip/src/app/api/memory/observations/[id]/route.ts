import { NextRequest } from "next/server";
import { db } from "@/db";
import { and, eq } from "drizzle-orm";
import { observations } from "@/db/schema";
import { DEFAULT_PERSON, ensurePerson } from "@/lib/agent/store";

export const dynamic = "force-dynamic";

/** Delete a single piece of evidence; beliefs are re-derived from what remains. */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const personId = await ensurePerson(DEFAULT_PERSON);
  await db.delete(observations).where(and(eq(observations.id, id), eq(observations.personId, personId)));
  return Response.json({ ok: true });
}
