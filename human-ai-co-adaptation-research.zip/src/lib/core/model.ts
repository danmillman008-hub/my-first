/**
 * Pure, deterministic core. No I/O. Shared by the live agent and the lab.
 *
 * The unit of adaptation is a *working dimension*: a continuous 0..1 axis describing how the
 * AI works with the person (how deep, how example-driven, how often it checks, how direct, how fast).
 * Everything the system believes about the person is a Belief over (dimension, context) or a Fact,
 * and every belief carries its evidence trail, its basis (stated vs demonstrated) and a status.
 *
 * Inherited from the archive (validated repeatedly): claim ≠ demonstration; corrections retire beliefs
 * and block re-inference for a guard period; confidence is capped; inferred beliefs need cross-session
 * support before being acted on.  New in this generation: recency-window drift detection ("the person
 * changed"), tensions (claim contradicts demonstration, surfaced rather than silently resolved), and a
 * self-model (what the AI tried and what happened next) that is attributed on the *next* turn.
 */

export const DIMS = ["depth", "examples", "checks", "directness", "pace"] as const;
export type Dim = (typeof DIMS)[number];
export const CONTEXTS = ["quick_task", "learning", "debugging", "planning"] as const;
export type Context = (typeof CONTEXTS)[number];
export type Scope = Context | "any";

export type Approach = Record<Dim, number>;
export const NEUTRAL: Approach = { depth: 0.5, examples: 0.5, checks: 0.5, directness: 0.5, pace: 0.5 };

export const DIM_LABELS: Record<Dim, [string, string]> = {
  depth: ["terse, essentials only", "thorough, full background"],
  examples: ["principles first", "concrete examples first"],
  checks: ["never quizzes / checks", "frequently checks understanding"],
  directness: ["gentle, hedged", "blunt, direct"],
  pace: ["slow, one step at a time", "fast, several steps at once"],
};

export type EvidenceKind = "stated" | "demonstrated" | "reaction" | "correction";

/** One append-only observation. Evidence is never edited; beliefs are derived from it. */
export type Observation = {
  id: string;
  at: number; // ms
  sessionId: string;
  kind: EvidenceKind;
  dim: Dim;
  scope: Scope;
  value: number; // 0..1 where the person seems to sit on this dim (for correction: ignored)
  note?: string;
  sourceMessageId?: string;
};

export type FactObservation = {
  id: string;
  at: number;
  sessionId: string;
  key: string; // e.g. "occupation", "language", "already_knows:git"
  value: string;
  kind: "stated" | "retracted";
  sourceMessageId?: string;
};

export type BeliefStatus = "candidate" | "active" | "contested" | "retired";
export type Basis = "stated" | "demonstrated" | "mixed";

export type Belief = {
  id: string; // `${dim}@${scope}`
  dim: Dim;
  scope: Scope;
  estimate: number; // 0..1
  confidence: number; // 0..CONFIDENCE_CAP
  status: BeliefStatus;
  basis: Basis;
  support: number; // weighted evidence mass
  sessions: string[];
  lastEvidenceAt: number;
  guardUntil: number; // ms; after a correction, inference is blocked until then
  driftDetectedAt?: number;
  tension?: string; // claim vs demonstration disagreement, if any
  evidenceIds: string[];
  history: { at: number; estimate: number; status: BeliefStatus; why: string }[];
};

export type Fact = {
  key: string;
  value: string;
  status: "active" | "retracted";
  statedAt: number;
  retractedAt?: number;
  sessions: string[];
};

export const CONFIDENCE_CAP = 0.92;
export const CORRECTION_GUARD_MS = 14 * 86_400_000;
/** Tunable for experiments: how fast old evidence loses weight (half-life in days). */
export const TUNING = { recencyHalfLifeDays: 21 };
const RECENCY_HALF_LIFE_MS_FN = () => TUNING.recencyHalfLifeDays * 86_400_000;
export const KIND_WEIGHT: Record<EvidenceKind, number> = {
  demonstrated: 1.0, // what the person actually did / responded well to
  stated: 0.6, // what they say about themselves — a claim
  reaction: 0.25, // "thanks, that helped" — noisy, politeness-biased (archive lesson)
  correction: 0,
};

export const clamp = (x: number, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, x));

export type BeliefOptions = {
  driftDetection: boolean; // CUSUM change-point detection: "the person changed"
  crossSessionRequired: boolean; // inferred beliefs need ≥2 sessions before active
  reactionWeight: number; // how much "thanks, helpful" counts (0 = ignore reactions entirely)
};
export const DEFAULT_BELIEF_OPTIONS: BeliefOptions = { driftDetection: true, crossSessionRequired: true, reactionWeight: 0 };
export const CUSUM_SLACK = 0.1; // deviations smaller than this are noise
export const CUSUM_THRESHOLD = 0.45; // accumulated consistent deviation that declares a change
export const PRE_CHANGE_WEIGHT = 0.15; // evidence from before a detected change keeps this much weight

/**
 * Derive the full belief set from the evidence log. Deterministic, so beliefs can always be
 * re-derived after the person deletes evidence ("that's not true about me").
 */
export function deriveBeliefs(
  observations: Observation[],
  now: number,
  opts: BeliefOptions = DEFAULT_BELIEF_OPTIONS,
  retiredByUser: Set<string> = new Set(),
): Belief[] {
  const byKey = new Map<string, Observation[]>();
  for (const o of [...observations].sort((a, b) => a.at - b.at)) {
    const k = `${o.dim}@${o.scope}`;
    if (!byKey.has(k)) byKey.set(k, []);
    byKey.get(k)!.push(o);
  }
  const out: Belief[] = [];
  for (const [id, obs] of byKey) {
    const [dim, scope] = id.split("@") as [Dim, Scope];
    const b: Belief = {
      id, dim, scope, estimate: 0.5, confidence: 0, status: "candidate", basis: "stated", support: 0,
      sessions: [], lastEvidenceAt: 0, guardUntil: 0, evidenceIds: [], history: [],
    };
    type W = { o: Observation; w: number };
    let kept: W[] = []; // evidence since the last correction
    let cp = 0; // index in `kept` of the last detected change-point
    let sPos = 0, sNeg = 0;
    const wmean = (xs: W[]) => { let a = 0, b = 0; for (const x of xs) { a += x.w; b += x.w * x.o.value; } return a > 0 ? [b / a, a] : [0.5, 0]; };
    for (const o of obs) {
      b.evidenceIds.push(o.id);
      if (!b.sessions.includes(o.sessionId)) b.sessions.push(o.sessionId);
      b.lastEvidenceAt = o.at;
      if (o.kind === "correction") {
        // The person said "that's not me": drop everything, guard re-inference.
        kept = []; cp = 0; sPos = sNeg = 0;
        b.guardUntil = o.at + CORRECTION_GUARD_MS;
        b.status = "retired";
        b.history.push({ at: o.at, estimate: b.estimate, status: "retired", why: "corrected by person" });
        continue;
      }
      // During a guard only explicit statements may rebuild the belief.
      if (o.at < b.guardUntil && o.kind !== "stated") continue;
      const kw = o.kind === "reaction" ? opts.reactionWeight : KIND_WEIGHT[o.kind];
      if (kw <= 0) continue;
      const recency = Math.pow(0.5, (now - o.at) / RECENCY_HALF_LIFE_MS_FN());
      const w = kw * (0.35 + 0.65 * recency);
      // CUSUM against the estimate formed since the last change-point (needs a few points first).
      if (opts.driftDetection && kept.length - cp >= 3 && o.kind !== "reaction") {
        const [est] = wmean(kept.slice(cp));
        const dev = o.value - est;
        sPos = Math.max(0, sPos + dev - CUSUM_SLACK);
        sNeg = Math.max(0, sNeg - dev - CUSUM_SLACK);
        if (sPos > CUSUM_THRESHOLD || sNeg > CUSUM_THRESHOLD) {
          cp = Math.max(0, kept.length - 2); // the run that triggered it began ~2 points ago
          sPos = sNeg = 0;
          b.driftDetectedAt = o.at;
          b.history.push({ at: o.at, estimate: est, status: "contested", why: "recent evidence consistently contradicts the earlier pattern — the person may have changed" });
        }
      }
      kept.push({ o, w });
      if (b.status === "retired" && o.kind === "stated") {
        b.status = "candidate";
        b.history.push({ at: o.at, estimate: o.value, status: "candidate", why: "re-stated by person after correction" });
      }
    }
    // Estimate: evidence before a detected change keeps little weight.
    const weighted = kept.map((x, i) => ({ ...x, w: i < cp ? x.w * PRE_CHANGE_WEIGHT : x.w }));
    const [estimate, wsum] = wmean(weighted);
    if (wsum === 0) {
      if (b.status === "retired" || retiredByUser.has(id)) { b.estimate = 0.5; b.confidence = 0; out.push(b); }
      continue;
    }
    b.support = wsum;
    b.estimate = estimate;
    const window = weighted.slice(-6).map((x) => ({ at: x.o.at, value: x.o.value, w: x.w }));
    // Basis and tension: do claims and demonstrations agree?
    const [sV, statedMass] = wmean(weighted.filter((x) => x.o.kind === "stated"));
    const [dV, demoMass] = wmean(weighted.filter((x) => x.o.kind !== "stated"));
    if (statedMass > 0.3 && demoMass > 0.6) {
      b.basis = "mixed";
      if (Math.abs(sV - dV) > 0.3) b.tension = `says ${describe(dim, sV)} but responds better to ${describe(dim, dV)}`;
    } else b.basis = demoMass > statedMass ? "demonstrated" : "stated";
    const recentlyDrifted = b.driftDetectedAt != null && kept.length - cp <= 5;
    if (recentlyDrifted) b.status = "contested";
    // Confidence grows with support and with agreement (low dispersion); capped.
    const disp = window.length > 1 ? Math.sqrt(window.reduce((s, x) => s + x.w * (x.value - b.estimate) ** 2, 0) / window.reduce((s, x) => s + x.w, 0)) : 0.25;
    b.confidence = clamp(CONFIDENCE_CAP * (1 - Math.exp(-b.support / 1.6)) * (1 - clamp(disp - 0.1, 0, 0.6)), 0, CONFIDENCE_CAP);
    if (retiredByUser.has(id)) { b.status = "retired"; b.confidence = 0; }
    else if (!recentlyDrifted) {
      const inferredOnly = statedMass === 0;
      const enoughSessions = !opts.crossSessionRequired || !inferredOnly || b.sessions.length >= 2;
      b.status = b.confidence >= 0.35 && enoughSessions ? "active" : "candidate";
    }
    out.push(b);
  }
  // Tensions across scopes: a general self-description vs what demonstrably works in a context.
  for (const b of out) {
    if (b.scope === "any" || b.basis !== "demonstrated" || b.confidence < 0.4 || b.status === "retired") continue;
    const g = out.find((x) => x.dim === b.dim && x.scope === "any" && x.basis === "stated" && x.status !== "retired" && x.confidence > 0.2);
    if (g && Math.abs(g.estimate - b.estimate) > 0.3) b.tension = `says ${describe(b.dim, g.estimate)} but in ${b.scope.replace("_", " ")} responds better to ${describe(b.dim, b.estimate)}`;
  }
  return out;
}

export function describe(dim: Dim, v: number): string {
  const [lo, hi] = DIM_LABELS[dim];
  if (v < 0.35) return lo;
  if (v > 0.65) return hi;
  return `middle on ${dim}`;
}

export function deriveFacts(obs: FactObservation[]): Fact[] {
  const out: Fact[] = [];
  const current = new Map<string, Fact>();
  for (const o of [...obs].sort((a, b) => a.at - b.at)) {
    const f = current.get(o.key);
    if (o.kind === "retracted") {
      if (f && f.value === o.value) { f.status = "retracted"; f.retractedAt = o.at; current.delete(o.key); }
      continue;
    }
    if (f && f.value === o.value) { if (!f.sessions.includes(o.sessionId)) f.sessions.push(o.sessionId); continue; }
    if (f) { f.status = "retracted"; f.retractedAt = o.at; } // superseded by a new value
    const nf: Fact = { key: o.key, value: o.value, status: "active", statedAt: o.at, sessions: [o.sessionId] };
    current.set(o.key, nf); out.push(nf);
  }
  return out;
}

/** The belief the agent should use for a dimension in a context: context-specific beats general. */
export function beliefFor(beliefs: Belief[], dim: Dim, ctx: Context): Belief | undefined {
  const usable = (b: Belief | undefined) => b && (b.status === "active" || b.status === "contested") ? b : undefined;
  return usable(beliefs.find((b) => b.dim === dim && b.scope === ctx)) ?? usable(beliefs.find((b) => b.dim === dim && b.scope === "any"));
}

// ───────────────────────────── self-model: what I tried, what happened ─────────────────────────────

export type ApproachRecord = {
  id: string;
  at: number;
  sessionId: string;
  context: Context;
  approach: Approach;
  basedOn: string[]; // belief ids used
  outcome?: { success: boolean; reaction: number; correction: boolean; at: number; known?: boolean }; // filled on next turn (known=false: no outcome signal was visible)
};

/**
 * What the ledger says works in a context: an outcome-weighted centroid of past approaches,
 * weighting task success (not reactions — reactions are what the old style-bandits chased).
 */
export function ledgerSuggestion(ledger: ApproachRecord[], ctx: Context, now: number): { approach: Approach; mass: number } | null {
  const rel = ledger.filter((r) => r.context === ctx && r.outcome);
  if (rel.length < 3) return null;
  const acc: Approach = { ...NEUTRAL };
  let mass = 0;
  for (const d of DIMS) acc[d] = 0;
  for (const r of rel) {
    const o = r.outcome!;
    const recency = Math.pow(0.5, (now - r.at) / RECENCY_HALF_LIFE_MS_FN());
    const w = (o.success ? 1 : 0.15) * (o.correction ? 0.2 : 1) * (0.4 + 0.6 * recency);
    mass += w;
    for (const d of DIMS) acc[d] += w * r.approach[d];
  }
  if (mass <= 0) return null;
  for (const d of DIMS) acc[d] /= mass;
  return { approach: acc, mass };
}

/** Where the self-model and the beliefs disagree — the AI's own evidence that a belief may be wrong. */
export function selfModelDisagreements(beliefs: Belief[], ledger: ApproachRecord[], ctx: Context, now: number): { dim: Dim; belief: number; worked: number }[] {
  const s = ledgerSuggestion(ledger, ctx, now);
  if (!s || s.mass < 2) return [];
  const out: { dim: Dim; belief: number; worked: number }[] = [];
  for (const d of DIMS) {
    const b = beliefFor(beliefs, d, ctx);
    if (b && Math.abs(b.estimate - s.approach[d]) > 0.3) out.push({ dim: d, belief: b.estimate, worked: s.approach[d] });
  }
  return out;
}

// ───────────────────────────── choosing how to work this turn ─────────────────────────────

export type Condition = "none" | "transcript" | "beliefs_static" | "beliefs_react" | "beliefs" | "full";

export type Probe =
  | { kind: "unknown"; dim: Dim } // we know nothing about this dimension: ask
  | { kind: "tension"; dim: Dim; stated: number; demonstrated: number }; // what they say ≠ what works: surface it

export type TurnPlan = {
  approach: Approach;
  basedOn: string[];
  probe?: Probe;
  notes: string[];
};

/**
 * Deterministic policy used by the lab (and as the fallback when no LLM is configured).
 * Explicit requests in the current message always win. Then beliefs, then the self-model, then neutral.
 */
export function planTurn(args: {
  condition: Condition;
  ctx: Context;
  beliefs: Belief[];
  ledger: ApproachRecord[];
  transcriptHints?: Partial<Approach>; // raw "last thing they said" memory for the transcript baseline
  explicit?: Partial<Approach>; // requests in the current message
  now: number;
  turnsSoFar: number;
  surfaced?: Set<string>; // belief ids whose tension has already been raised with the person
}): TurnPlan {
  const { condition, ctx, beliefs, ledger, now } = args;
  const approach: Approach = { ...NEUTRAL };
  const basedOn: string[] = [];
  const notes: string[] = [];
  let probe: Probe | undefined;
  if (condition === "transcript" && args.transcriptHints) {
    for (const d of DIMS) if (args.transcriptHints[d] != null) { approach[d] = args.transcriptHints[d]!; basedOn.push(`transcript:${d}`); }
  }
  if (condition === "beliefs" || condition === "beliefs_static" || condition === "beliefs_react" || condition === "full") {
    for (const d of DIMS) {
      const b = beliefFor(beliefs, d, ctx);
      if (b) { approach[d] = b.estimate; basedOn.push(b.id); }
    }
  }
  if (condition === "full") {
    const s = ledgerSuggestion(ledger, ctx, now);
    if (s && s.mass >= 2) {
      const k = clamp(s.mass / 8, 0, 0.5); // the more successful history, the more weight
      for (const d of DIMS) {
        const b = beliefFor(beliefs, d, ctx);
        const blend = b ? k * (1 - b.confidence) : k; // strong beliefs resist the ledger
        approach[d] = (1 - blend) * approach[d] + blend * s.approach[d];
      }
      notes.push(`ledger blended (mass ${s.mass.toFixed(1)})`);
    }
    // Surface a claim-vs-demonstration tension once, so the person's own self-model can update
    // (or they can insist, in which case we follow what they say).
    const tense = beliefs.find((b) => b.tension && b.confidence > 0.5 && (b.scope === ctx || b.scope === "any") && !(args.surfaced?.has(b.id)));
    if (tense) {
      const st = beliefs.find((b) => b.dim === tense.dim && b.scope === "any");
      probe = { kind: "tension", dim: tense.dim, stated: st?.estimate ?? 0.5, demonstrated: tense.estimate };
      notes.push(`raising tension: ${tense.tension}`);
    } else if (args.turnsSoFar % 4 === 1) {
      // Otherwise, early on, ask about one dimension we know nothing about (at most once per few turns).
      const unknown = DIMS.filter((d) => !beliefFor(beliefs, d, ctx) && !beliefs.some((b) => b.dim === d && b.status !== "retired"));
      if (unknown.length) probe = { kind: "unknown", dim: unknown[0] };
    }
  }
  if (args.explicit) for (const d of DIMS) if (args.explicit[d] != null) { approach[d] = args.explicit[d]!; basedOn.push(`explicit:${d}`); }
  return { approach, basedOn, probe, notes };
}

export function approachDistance(a: Approach, b: Approach): number {
  return DIMS.reduce((s, d) => s + Math.abs(a[d] - b[d]), 0) / DIMS.length;
}
