/**
 * A simulated person with hidden state the AI never sees.
 *
 * Deliberately not a static profile:
 *  - preferences are context-dependent (quick task vs learning vs debugging vs planning)
 *  - what the person *says* about themselves can be wrong (self-knowledge error)
 *  - preferences drift at a hidden session index (the person changes)
 *  - facts about their life can change (job, language) and they may forget to mention it
 *  - reactions are politeness-biased: "thanks, helpful" even when the fit was poor
 *  - the person has a model of the AI: trust in its memory. Trust rises when the AI acts on what
 *    it was told and falls when it violates it. High trust ⇒ the person stops restating themselves
 *    (co-adaptation: the better the AI remembers, the less evidence it is given).
 */
import { Approach, Context, Dim, DIMS, CONTEXTS, NEUTRAL, Probe, clamp, approachDistance } from "../core/model";

export type Rng = () => number;
export function mulberry32(seed: number): Rng {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export type Archetype = {
  name: string;
  description: string;
  truth: Record<Context, Partial<Approach>>; // hidden effective preferences (unspecified dims = 0.5)
  selfKnowledgeError: Partial<Record<Dim, number>>; // stated = truth + error (they are wrong about themselves)
  drift?: { atSession: number; ctx: Context | "all"; dim: Dim; to: number; announce: number }; // announce: P(person tells the AI about the change)
  factChange?: { atSession: number; key: string; from: string; to: string };
  facts: Record<string, string>;
  politeness: number; // P(positive reaction | poor fit)
  assertiveness: number; // P(correct the AI | it violated a stated preference)
  volunteering: number; // P(state a preference unprompted early on)
  initialTrust: number;
  contextMix: Partial<Record<Context, number>>;
};

export const ARCHETYPES: Archetype[] = [
  {
    name: "terse-engineer",
    description: "Wants short direct answers for tasks, but thorough explanations when actually learning. Says they 'like detail' (wrong for tasks).",
    truth: { quick_task: { depth: 0.15, directness: 0.85, pace: 0.8, checks: 0.1 }, learning: { depth: 0.8, examples: 0.7, checks: 0.6 }, debugging: { depth: 0.3, directness: 0.9, pace: 0.7, checks: 0.2 }, planning: { depth: 0.6, directness: 0.7 } },
    selfKnowledgeError: { depth: 0.45 },
    facts: { occupation: "backend engineer", language: "Go", "already_knows:git": "yes" },
    politeness: 0.25, assertiveness: 0.7, volunteering: 0.5, initialTrust: 0.3,
    contextMix: { quick_task: 0.45, learning: 0.2, debugging: 0.25, planning: 0.1 },
  },
  {
    name: "polite-novice",
    description: "Learns best from concrete examples and frequent checks, but says 'I'm fine with theory'. Very polite; rarely corrects the AI.",
    truth: { quick_task: { depth: 0.5, examples: 0.8, pace: 0.3 }, learning: { depth: 0.6, examples: 0.9, checks: 0.8, pace: 0.2 }, debugging: { examples: 0.8, pace: 0.3, directness: 0.3 }, planning: { depth: 0.5, pace: 0.3 } },
    selfKnowledgeError: { examples: -0.5, checks: -0.4 },
    facts: { occupation: "nurse", language: "Python", "goal": "automate rota spreadsheets" },
    politeness: 0.75, assertiveness: 0.15, volunteering: 0.6, initialTrust: 0.5,
    contextMix: { quick_task: 0.25, learning: 0.5, debugging: 0.15, planning: 0.1 },
  },
  {
    name: "drifter",
    description: "Starts as a beginner wanting slow paced, example-heavy help; by mid-way has become competent and wants fast, terse answers. Changes job language too.",
    truth: { quick_task: { depth: 0.6, pace: 0.25, examples: 0.75 }, learning: { depth: 0.7, pace: 0.2, examples: 0.8, checks: 0.6 }, debugging: { pace: 0.3, examples: 0.7 }, planning: { depth: 0.6 } },
    selfKnowledgeError: {},
    drift: { atSession: 6, ctx: "all", dim: "pace", to: 0.85, announce: 0.2 }, // mostly unaware: they just got better
    factChange: { atSession: 7, key: "language", from: "JavaScript", to: "Rust" },
    facts: { occupation: "student", language: "JavaScript" },
    politeness: 0.5, assertiveness: 0.45, volunteering: 0.5, initialTrust: 0.4,
    contextMix: { quick_task: 0.35, learning: 0.35, debugging: 0.2, planning: 0.1 },
  },
  {
    name: "contradictor",
    description: "States a preference for being quizzed, then retracts it two sessions later and hates being quizzed. Blunt.",
    truth: { quick_task: { checks: 0.1, directness: 0.9 }, learning: { checks: 0.15, directness: 0.9, depth: 0.7 }, debugging: { checks: 0.1, directness: 0.9 }, planning: { checks: 0.1 } },
    selfKnowledgeError: { checks: 0.7 }, // initially claims to want checks
    drift: { atSession: 3, ctx: "all", dim: "checks", to: 0.1, announce: 0.95 }, // truth was already low; this is when they *retract* the claim
    facts: { occupation: "product manager", language: "SQL" },
    politeness: 0.2, assertiveness: 0.9, volunteering: 0.8, initialTrust: 0.3,
    contextMix: { quick_task: 0.3, learning: 0.3, debugging: 0.1, planning: 0.3 },
  },
  {
    name: "steady-explorer",
    description: "Stable, middle-of-the-road preferences with mild context dependence. A control: memory should help a little and never hurt.",
    truth: { quick_task: { depth: 0.4, directness: 0.6 }, learning: { depth: 0.65, examples: 0.6, checks: 0.5 }, debugging: { depth: 0.45, directness: 0.65 }, planning: { depth: 0.6 } },
    selfKnowledgeError: { depth: 0.1 },
    facts: { occupation: "data analyst", language: "R" },
    politeness: 0.5, assertiveness: 0.5, volunteering: 0.4, initialTrust: 0.5,
    contextMix: { quick_task: 0.3, learning: 0.3, debugging: 0.2, planning: 0.2 },
  },
];

export type HumanTurn = {
  context: Context;
  text: string;
  stated: { dim: Dim; value: number; scope: Context | "any" }[]; // what the person says about themselves this turn
  statedFacts: { key: string; value: string; kind: "stated" | "retracted" }[];
  restated: boolean; // had to repeat themselves
  correction: { dim: Dim } | null; // "no, I told you I don't want X"
  explicitRequest: Partial<Approach>; // "just give me the command" (turn-local)
};

export type HumanReaction = {
  fit: number; // hidden
  success: boolean; // hidden task outcome
  reactionPositive: boolean; // visible, politeness-biased
  violatedStated: Dim | null; // hidden: AI contradicted something the person had explicitly told it
  trust: number; // hidden
};

export class SimHuman {
  readonly a: Archetype;
  readonly rng: Rng;
  truth: Record<Context, Approach>;
  facts: Record<string, string>;
  toldFacts = new Set<string>();
  toldPrefs = new Map<Dim, number>(); // what they have told the AI (they remember telling, roughly)
  trust: number;
  session = 0;
  turn = 0;
  lastViolation: Dim | null = null;
  factRetracted = false;

  constructor(a: Archetype, seed: number) {
    this.a = a;
    this.rng = mulberry32(seed);
    this.truth = {} as Record<Context, Approach>;
    for (const c of CONTEXTS) this.truth[c] = { ...NEUTRAL, ...a.truth[c] };
    this.facts = { ...a.facts };
    this.trust = a.initialTrust;
  }

  startSession(index: number) {
    this.session = index;
    this.turn = 0;
    const d = this.a.drift;
    if (d && index === d.atSession) {
      for (const c of CONTEXTS) if (d.ctx === "all" || d.ctx === c) this.truth[c][d.dim] = d.to;
      // After a real change the person's own account of themselves updates too.
      if (this.a.name === "contradictor") this.toldPrefs.delete(d.dim);
    }
    const f = this.a.factChange;
    if (f && index === f.atSession) this.facts[f.key] = f.to;
    // Between sessions people forget a little of what they told the AI, so they may repeat themselves.
    for (const k of [...this.toldFacts]) if (this.rng() < 0.15) this.toldFacts.delete(k);
  }

  /** What the person *would say* they prefer on a dim (their possibly-wrong self-model). */
  private statedValue(dim: Dim, ctx: Context): number {
    const err = this.a.selfKnowledgeError[dim] ?? 0;
    // A drift that the person is aware of overrides old self-knowledge error.
    const d = this.a.drift;
    const drifted = d && d.dim === dim && this.session >= d.atSession;
    return clamp(this.truth[ctx][dim] + (drifted ? 0 : err) + (this.rng() - 0.5) * 0.1);
  }

  pickContext(): Context {
    let r = this.rng();
    for (const c of CONTEXTS) { r -= this.a.contextMix[c] ?? 0; if (r <= 0) return c; }
    return "quick_task";
  }

  speak(probe: Probe | null): HumanTurn {
    this.turn++;
    const context = this.pickContext();
    const stated: HumanTurn["stated"] = [];
    const statedFacts: HumanTurn["statedFacts"] = [];
    let restated = false;
    let correction: HumanTurn["correction"] = null;
    const explicitRequest: Partial<Approach> = {};
    const parts: string[] = [];

    // Correct the AI if it violated something they had told it (assertiveness-gated).
    if (this.lastViolation && this.rng() < this.a.assertiveness) {
      const dim = this.lastViolation;
      correction = { dim };
      const v = this.statedValue(dim, context);
      stated.push({ dim, value: v, scope: "any" });
      this.toldPrefs.set(dim, v);
      restated = true;
      parts.push(`(again) I told you: I prefer ${v > 0.5 ? "more" : "less"} ${dim}.`);
    }
    this.lastViolation = null;

    // Answer a probe honestly-but-fallibly.
    if (probe?.kind === "unknown") {
      const v = this.statedValue(probe.dim, context);
      stated.push({ dim: probe.dim, value: v, scope: "any" });
      this.toldPrefs.set(probe.dim, v);
      parts.push(`You asked — I'd say I prefer ${v > 0.5 ? "more" : "less"} ${probe.dim}.`);
    } else if (probe?.kind === "tension") {
      // "You said X, but Y seems to work better for you — shall I keep doing Y?"
      // The person's self-model can update from the AI's evidence (openness ∝ 1 − assertiveness/2).
      const accepts = this.rng() < 0.85 - 0.4 * this.a.assertiveness;
      const v = accepts ? probe.demonstrated : probe.stated;
      stated.push({ dim: probe.dim, value: v, scope: "any" });
      this.toldPrefs.set(probe.dim, v);
      if (accepts) { const err = this.a.selfKnowledgeError[probe.dim]; if (err) this.a.selfKnowledgeError[probe.dim] = err * 0.3; }
      parts.push(accepts ? `Huh — you're right, ${probe.demonstrated > 0.5 ? "more" : "less"} ${probe.dim} does work better for me. Keep doing that.` : `No, I really do prefer ${probe.stated > 0.5 ? "more" : "less"} ${probe.dim}.`);
    }

    // Volunteer a preference: likely early, when trust is low, or after a change they are aware of.
    const d = this.a.drift;
    const awareOfChange = d && this.session === d.atSession && this.turn <= 2;
    const pVolunteer = awareOfChange ? d.announce : this.a.volunteering * (1 - this.trust) * (this.session === 0 ? 1 : 0.35);
    if (this.rng() < pVolunteer) {
      const dim = awareOfChange ? d!.dim : DIMS[Math.floor(this.rng() * DIMS.length)];
      const v = this.statedValue(dim, context);
      const already = this.toldPrefs.has(dim);
      stated.push({ dim, value: v, scope: "any" });
      this.toldPrefs.set(dim, v);
      if (already && !awareOfChange) restated = true;
      parts.push(`${awareOfChange ? "Things have changed: " : ""}I ${already ? "still " : ""}prefer ${v > 0.5 ? "more" : "less"} ${dim}.`);
    }

    // Facts about themselves: mention when relevant; restate if they forgot they told the AI or trust is low.
    const keys = Object.keys(this.facts);
    const key = keys[Math.floor(this.rng() * keys.length)];
    const fc = this.a.factChange;
    if (fc && this.session >= fc.atSession && !this.factRetracted && this.rng() < 0.6) {
      statedFacts.push({ key: fc.key, value: fc.from, kind: "retracted" }, { key: fc.key, value: fc.to, kind: "stated" });
      this.factRetracted = true; this.toldFacts.add(fc.key);
      parts.push(`By the way I moved from ${fc.from} to ${fc.to}.`);
    } else if (!this.toldFacts.has(key) && this.rng() < 0.5) {
      statedFacts.push({ key, value: this.facts[key], kind: "stated" });
      this.toldFacts.add(key);
      parts.push(`For context: my ${key} is ${this.facts[key]}.`);
    } else if (this.toldFacts.has(key) && this.rng() < 0.35 * (1 - this.trust)) {
      statedFacts.push({ key, value: this.facts[key], kind: "stated" });
      restated = true;
      parts.push(`(as I said) my ${key} is ${this.facts[key]}.`);
    }

    // Turn-local explicit request, sometimes (these must always be honoured).
    if (this.rng() < 0.15) {
      const dim = DIMS[Math.floor(this.rng() * DIMS.length)];
      explicitRequest[dim] = this.truth[context][dim] > 0.5 ? 0.9 : 0.1;
      parts.push(`This time, ${explicitRequest[dim]! > 0.5 ? "go heavy on" : "skip the"} ${dim}.`);
    }

    parts.push(`[${context}] ${requestText(context, this.facts.language ?? "code")}`);
    return { context, text: parts.join(" "), stated, statedFacts, restated, correction, explicitRequest };
  }

  /** The person experiences the AI's approach. Hidden outcome + visible, biased reaction. */
  react(context: Context, approach: Approach, aiUsedFacts: Record<string, string>): HumanReaction {
    const dist = approachDistance(approach, this.truth[context]);
    let fit = 1 - dist * 2.2; // neutral approach vs a strongly-opinionated person ⇒ ~0.4 fit
    // Using a stale fact (wrong language/job) hurts the outcome.
    for (const [k, v] of Object.entries(aiUsedFacts)) {
      if (!this.facts[k]) continue;
      fit += this.facts[k] === v ? 0.08 : -0.25; // personalised correctly vs acting on a stale fact
    }
    fit = clamp(fit);
    const success = this.rng() < 0.15 + 0.8 * fit;
    const reactionPositive = this.rng() < (fit > 0.6 ? 0.9 : this.a.politeness);
    // Did the AI contradict something the person explicitly told it?
    // (People only notice/complain when it is actually going badly — if the AI ignored a self-description
    //  that was wrong and things went well, nobody objects.)
    let violatedStated: Dim | null = null;
    if (fit < 0.55) for (const [dim, v] of this.toldPrefs) if (Math.abs(approach[dim] - v) > 0.45) { violatedStated = dim; break; }
    this.lastViolation = violatedStated;
    // Human's model of the AI: does it listen / remember?
    // Trust grows only when the AI visibly acts on what it was told; it is lost faster than it is gained.
    if (violatedStated) this.trust = clamp(this.trust - 0.12);
    else if (this.toldPrefs.size > 0) {
      const honoured = [...this.toldPrefs].every(([dim, v]) => Math.abs(approach[dim] - v) < 0.3);
      this.trust = clamp(this.trust + (honoured && fit > 0.5 ? 0.04 : -0.01));
    }
    return { fit, success, reactionPositive, violatedStated, trust: this.trust };
  }
}

function requestText(ctx: Context, lang: string): string {
  switch (ctx) {
    case "quick_task": return `How do I parse a date string in ${lang}?`;
    case "learning": return `Can you help me understand how concurrency works in ${lang}?`;
    case "debugging": return `My ${lang} script fails with a nil/None error on line 12 — what's wrong?`;
    case "planning": return `I want to build a small tool in ${lang} to track my expenses. Where do I start?`;
  }
}
