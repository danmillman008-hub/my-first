/**
 * The laboratory: runs the same core against simulated people under different conditions and
 * measures whether the AI actually gets better at working with *this* person over time.
 *
 * The AI never sees hidden state. Its perception of the person's messages is deliberately noisy
 * (a stand-in for imperfect LLM extraction). Hidden outcomes (fit, task success) are recorded by the
 * lab, not by the agent. Reactions are visible but politeness-biased.
 */
import {
  Approach, ApproachRecord, Belief, Condition, Context, DIMS, Dim, FactObservation, Observation, NEUTRAL,
  clamp, deriveBeliefs, deriveFacts, planTurn, CONTEXTS,
} from "../core/model";
import { ARCHETYPES, Archetype, SimHuman, mulberry32 } from "./human";
import type { Probe } from "../core/model";

export const CONDITIONS: Condition[] = ["none", "transcript", "beliefs_static", "beliefs_react", "beliefs", "full"];
export const CONDITION_DESCRIPTIONS: Record<Condition, string> = {
  none: "No memory beyond the current message.",
  transcript: "Raw recent history (last 30 messages): most recent statement per topic wins. No lifecycle.",
  beliefs_static: "Evidence → beliefs with lifecycle and corrections, but NO drift detection (memory can go stale).",
  beliefs_react: "beliefs + treats visible reactions (\"thanks, helpful\") as weak evidence.",
  beliefs: "Evidence → beliefs with lifecycle, corrections and CUSUM change-point detection; reactions ignored.",
  full: "beliefs + self-model (what I tried and what happened next) + occasional probing of unknown dimensions.",
};

export type SessionMetrics = {
  session: number;
  fit: number; // hidden: how well the AI's way of working matched the person's real (context-dependent) preference
  success: number; // hidden task/learning outcome rate
  reactionPositive: number; // visible, politeness-biased — reported to show it is NOT a good target
  restatements: number; // times the person had to repeat something they had already said
  corrections: number; // "I told you…"
  violations: number; // AI contradicted something explicitly stated
  staleFactUses: number; // AI acted on a fact that was no longer true
  beliefError: number; // mean |belief − truth| over beliefs acted on (NaN if none)
  activeBeliefs: number;
  probes: number;
  trust: number; // hidden: person's model of whether the AI listens/remembers
  contextTokens: number; // rough size of what the AI is given about the past
};

export type RunResult = {
  condition: Condition;
  archetype: string;
  seed: number;
  sessions: SessionMetrics[];
  finalBeliefs: Belief[];
};

export type LabConfig = { sessions: number; turnsPerSession: number; seeds: number; conditions?: Condition[]; archetypes?: string[] };
export const DEFAULT_LAB: LabConfig = { sessions: 12, turnsPerSession: 8, seeds: 4 };

const DAY = 86_400_000;
let idc = 0;
const nid = () => `o${++idc}`;

export function runOne(cond: Condition, a: Archetype, seed: number, cfg: LabConfig): RunResult {
  const human = new SimHuman(a, seed * 7919 + 17);
  const prng = mulberry32(seed * 104729 + 3); // perception noise, independent of the human's randomness
  const obs: Observation[] = [];
  const factObs: FactObservation[] = [];
  const ledger: ApproachRecord[] = [];
  const transcript: { stated: { dim: Dim; value: number }[]; facts: { key: string; value: string; kind: string }[] }[] = [];
  const sessions: SessionMetrics[] = [];
  let pendingProbe: Probe | null = null;
  const surfaced = new Set<string>();
  let turnsSoFar = 0;
  let lastRecord: ApproachRecord | null = null;
  let lastReactionPositive = false;
  let lastFollowUp = false;
  let beliefs: Belief[] = [];

  for (let s = 0; s < cfg.sessions; s++) {
    const sessionId = `s${s}`;
    human.startSession(s);
    const m: SessionMetrics = { session: s, fit: 0, success: 0, reactionPositive: 0, restatements: 0, corrections: 0, violations: 0, staleFactUses: 0, beliefError: 0, activeBeliefs: 0, probes: 0, trust: 0, contextTokens: 0 };
    let errSum = 0, errN = 0;
    for (let t = 0; t < cfg.turnsPerSession; t++) {
      const now = s * 2 * DAY + t * 60_000 + 1;
      turnsSoFar++;
      const h = human.speak(pendingProbe);
      pendingProbe = null;
      m.restatements += h.restated ? 1 : 0;
      m.corrections += h.correction ? 1 : 0;

      // ── attribute the outcome of the previous approach on THIS turn (archive rule: next-turn credit)
      if (lastRecord) lastRecord.outcome = { success: !lastFollowUp, reaction: lastReactionPositive ? 1 : 0, correction: !!h.correction, at: now };

      // ── perceive (noisy): stated preferences, corrections, facts
      if (cond !== "none") {
        for (const st of h.stated) if (prng() < 0.9) obs.push({ id: nid(), at: now, sessionId, kind: "stated", dim: st.dim, scope: st.scope, value: clamp(st.value + (prng() - 0.5) * 0.1) });
        if (h.correction && prng() < 0.85) obs.push({ id: nid(), at: now - 1, sessionId, kind: "correction", dim: h.correction.dim, scope: "any", value: 0.5 });
        for (const f of h.statedFacts) if (prng() < 0.9) factObs.push({ id: nid(), at: now, sessionId, key: f.key, value: f.value, kind: f.kind });
        transcript.push({ stated: h.stated, facts: h.statedFacts });
        if (transcript.length > 30) transcript.shift();
      }

      // ── decide how to work this turn
      let transcriptHints: Partial<Approach> | undefined;
      let usedFacts: Record<string, string> = {};
      if (cond === "transcript") {
        transcriptHints = {};
        const facts: Record<string, string> = {};
        for (const msg of transcript) {
          for (const st of msg.stated) transcriptHints[st.dim] = st.value;
          for (const f of msg.facts) { if (f.kind === "retracted") delete facts[f.key]; else facts[f.key] = f.value; }
        }
        usedFacts = facts;
        m.contextTokens += transcript.length * 45;
      } else if (cond !== "none") {
        beliefs = deriveBeliefs(obs, now, { driftDetection: cond !== "beliefs_static", crossSessionRequired: true, reactionWeight: cond === "beliefs_react" ? 0.25 : 0 });
        for (const f of deriveFacts(factObs)) if (f.status === "active") usedFacts[f.key] = f.value;
        const act = beliefs.filter((b) => b.status === "active" || b.status === "contested");
        m.contextTokens += act.length * 14 + Object.keys(usedFacts).length * 8 + (cond === "full" ? 40 : 0);
      }
      // A fact stated in the current message is always fresh, whatever the condition.
      for (const f of h.statedFacts) { if (f.kind === "retracted") delete usedFacts[f.key]; else usedFacts[f.key] = f.value; }

      const plan = planTurn({ condition: cond, ctx: h.context, beliefs, ledger, transcriptHints, explicit: h.explicitRequest, now, turnsSoFar, surfaced });
      if (plan.probe) { pendingProbe = plan.probe; m.probes++; if (plan.probe.kind === "tension") for (const b of beliefs) if (b.dim === plan.probe.dim && b.tension) surfaced.add(b.id); }

      // ── the person experiences it
      const r = human.react(h.context, plan.approach, usedFacts);
      m.fit += r.fit; m.success += r.success ? 1 : 0; m.reactionPositive += r.reactionPositive ? 1 : 0;
      m.violations += r.violatedStated ? 1 : 0;
      for (const [k, v] of Object.entries(usedFacts)) if (human.facts[k] && human.facts[k] !== v) m.staleFactUses++;
      m.trust = r.trust;
      // Observable outcome signal for the agent: a failed task usually shows up as a follow-up ("that didn't work").
      lastFollowUp = r.success ? prng() < 0.1 : prng() < 0.8;
      lastReactionPositive = r.reactionPositive;

      // ── belief accuracy against hidden truth (for the dims the AI acted on)
      for (const id of plan.basedOn) {
        if (!id.includes("@")) continue;
        const [dim] = id.split("@") as [Dim];
        errSum += Math.abs(plan.approach[dim] - human.truth[h.context][dim]); errN++;
      }

      // ── demonstrated evidence: the person's behaviour leaks the *direction* of their real preference
      //    (follow-up questions wanting more, "ok ok got it" wanting less, skipping the example…).
      //    Perceived noisily: only mismatches > 0.2 leak, seen ~25% of the time, misread direction 25% of the time, ±0.15 noise.
      if (cond !== "none" && cond !== "transcript") {
        for (const d of DIMS) {
          const gap = human.truth[h.context][d] - plan.approach[d];
          // small mismatches produce no visible behaviour; large ones are noticed only sometimes
          if (Math.abs(gap) < 0.2 || prng() >= 0.25) continue;
          const dir = prng() < 0.25 ? -Math.sign(gap) : Math.sign(gap);
          const v = plan.approach[d] + dir * Math.min(0.3, Math.abs(gap)) + (prng() - 0.5) * 0.3;
          obs.push({ id: nid(), at: now + 2, sessionId, kind: "demonstrated", dim: d, scope: h.context, value: clamp(v) });
        }
        if (prng() < 0.6) {
          // reactions are recorded as weak evidence for whatever was done (this is what politeness poisons)
          const d = DIMS[Math.floor(prng() * DIMS.length)];
          obs.push({ id: nid(), at: now + 3, sessionId, kind: "reaction", dim: d, scope: h.context, value: r.reactionPositive ? plan.approach[d] : clamp(1 - plan.approach[d]) });
        }
      }
      lastRecord = { id: nid(), at: now, sessionId, context: h.context, approach: plan.approach, basedOn: plan.basedOn };
      if (cond === "full") ledger.push(lastRecord);
    }
    const T = cfg.turnsPerSession;
    m.fit /= T; m.success /= T; m.reactionPositive /= T; m.contextTokens /= T;
    m.beliefError = errN ? errSum / errN : NaN;
    m.activeBeliefs = beliefs.filter((b) => b.status === "active" || b.status === "contested").length;
    sessions.push(m);
  }
  return { condition: cond, archetype: a.name, seed, sessions, finalBeliefs: beliefs };
}

export type LabSummary = {
  config: LabConfig;
  byCondition: Record<string, { early: Partial<SessionMetrics>; late: Partial<SessionMetrics>; all: Partial<SessionMetrics>; perSession: SessionMetrics[] }>;
  byConditionArchetype: Record<string, Record<string, { fitEarly: number; fitLate: number; successLate: number; restatements: number; violations: number; driftRecovery: number | null }>>;
  runs: number;
  notes: string[];
};

const KEYS: (keyof SessionMetrics)[] = ["fit", "success", "reactionPositive", "restatements", "corrections", "violations", "staleFactUses", "beliefError", "activeBeliefs", "probes", "trust", "contextTokens"];

function mean(xs: number[]): number { const v = xs.filter((x) => !Number.isNaN(x)); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : NaN; }
function avgMetrics(ms: SessionMetrics[]): Partial<SessionMetrics> {
  const o: Partial<SessionMetrics> = {};
  for (const k of KEYS) (o as Record<string, number>)[k] = +mean(ms.map((m) => m[k] as number)).toFixed(3);
  return o;
}

export function runLab(cfg: LabConfig = DEFAULT_LAB): { summary: LabSummary; results: RunResult[] } {
  idc = 0;
  const conds = cfg.conditions ?? CONDITIONS;
  const archs = ARCHETYPES.filter((a) => !cfg.archetypes || cfg.archetypes.includes(a.name));
  const results: RunResult[] = [];
  for (const c of conds) for (const a of archs) for (let s = 1; s <= cfg.seeds; s++) results.push(runOne(c, a, s, cfg));
  const summary: LabSummary = { config: cfg, byCondition: {}, byConditionArchetype: {}, runs: results.length, notes: [] };
  const third = Math.max(1, Math.floor(cfg.sessions / 3));
  for (const c of conds) {
    const rs = results.filter((r) => r.condition === c);
    const all = rs.flatMap((r) => r.sessions);
    const perSession: SessionMetrics[] = [];
    for (let s = 0; s < cfg.sessions; s++) perSession.push({ ...(avgMetrics(all.filter((m) => m.session === s)) as SessionMetrics), session: s });
    summary.byCondition[c] = { early: avgMetrics(all.filter((m) => m.session < third)), late: avgMetrics(all.filter((m) => m.session >= cfg.sessions - third)), all: avgMetrics(all), perSession };
    summary.byConditionArchetype[c] = {};
    for (const a of archs) {
      const ar = rs.filter((r) => r.archetype === a.name).flatMap((r) => r.sessions);
      const early = ar.filter((m) => m.session < third), late = ar.filter((m) => m.session >= cfg.sessions - third);
      let driftRecovery: number | null = null;
      if (a.drift) {
        const pre = mean(ar.filter((m) => m.session >= a.drift!.atSession - 2 && m.session < a.drift!.atSession).map((m) => m.fit));
        for (let s = a.drift.atSession; s < cfg.sessions; s++) {
          const f = mean(ar.filter((m) => m.session === s).map((m) => m.fit));
          if (f >= pre - 0.03) { driftRecovery = s - a.drift.atSession; break; }
        }
        if (driftRecovery === null) driftRecovery = cfg.sessions - a.drift.atSession; // never recovered within horizon
      }
      summary.byConditionArchetype[c][a.name] = {
        fitEarly: +mean(early.map((m) => m.fit)).toFixed(3), fitLate: +mean(late.map((m) => m.fit)).toFixed(3),
        successLate: +mean(late.map((m) => m.success)).toFixed(3), restatements: +mean(ar.map((m) => m.restatements)).toFixed(2),
        violations: +mean(ar.map((m) => m.violations)).toFixed(2), driftRecovery,
      };
    }
  }
  return { summary, results };
}

export { ARCHETYPES, CONTEXTS, NEUTRAL };
