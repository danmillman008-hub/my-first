import { db } from "@/db";
import { and, asc, desc, eq } from "drizzle-orm";
import { approachRecords, factObservations, messages, observations, people, sessions } from "@/db/schema";
import {
  ApproachRecord, Belief, Context, Dim, Fact, FactObservation, Observation, Scope, deriveBeliefs, deriveFacts, DEFAULT_BELIEF_OPTIONS,
} from "../core/model";

export const DEFAULT_PERSON = "me";
export const nid = (p = "") => p + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

export async function ensurePerson(id = DEFAULT_PERSON) {
  const found = await db.select().from(people).where(eq(people.id, id));
  if (!found.length) await db.insert(people).values({ id, name: "You" });
  return id;
}

export type PersonState = {
  observations: Observation[];
  facts: Fact[];
  factObservations: FactObservation[];
  beliefs: Belief[];
  ledger: ApproachRecord[];
  pending: ApproachRecord | null; // last approach whose outcome is not yet attributed
};

export async function loadPersonState(personId: string, now = Date.now()): Promise<PersonState> {
  const [obsRows, factRows, ledgerRows] = await Promise.all([
    db.select().from(observations).where(eq(observations.personId, personId)).orderBy(asc(observations.at)),
    db.select().from(factObservations).where(eq(factObservations.personId, personId)).orderBy(asc(factObservations.at)),
    db.select().from(approachRecords).where(eq(approachRecords.personId, personId)).orderBy(asc(approachRecords.at)),
  ]);
  const obs: Observation[] = obsRows.map((r) => ({ id: r.id, at: r.at.getTime(), sessionId: r.sessionId, kind: r.kind as Observation["kind"], dim: r.dim as Dim, scope: r.scope as Scope, value: r.value, note: r.note ?? undefined, sourceMessageId: r.messageId ?? undefined }));
  const fobs: FactObservation[] = factRows.map((r) => ({ id: r.id, at: r.at.getTime(), sessionId: r.sessionId, key: r.key, value: r.value, kind: r.kind as FactObservation["kind"], sourceMessageId: r.messageId ?? undefined }));
  const ledger: ApproachRecord[] = ledgerRows.map((r) => ({ id: r.id, at: r.at.getTime(), sessionId: r.sessionId, context: r.context as Context, approach: r.approach as ApproachRecord["approach"], basedOn: r.basedOn as string[], outcome: (r.outcome as ApproachRecord["outcome"]) ?? undefined }));
  const pending = [...ledgerRows].reverse().find((r) => !r.outcomeFilled);
  return {
    observations: obs,
    factObservations: fobs,
    facts: deriveFacts(fobs),
    beliefs: deriveBeliefs(obs, now, DEFAULT_BELIEF_OPTIONS),
    ledger,
    pending: pending ? ledger.find((l) => l.id === pending.id) ?? null : null,
  };
}

export async function ensureSession(personId: string, sessionId?: string | null) {
  if (sessionId) {
    const found = await db.select().from(sessions).where(and(eq(sessions.id, sessionId), eq(sessions.personId, personId)));
    if (found.length) return found[0];
  }
  const id = nid("s_");
  const [row] = await db.insert(sessions).values({ id, personId, title: "New conversation" }).returning();
  return row;
}

export async function loadMessages(sessionId: string, limit = 30) {
  const rows = await db.select().from(messages).where(eq(messages.sessionId, sessionId)).orderBy(desc(messages.createdAt)).limit(limit);
  return rows.reverse();
}

export async function listSessions(personId: string) {
  return db.select().from(sessions).where(eq(sessions.personId, personId)).orderBy(desc(sessions.lastActiveAt));
}
