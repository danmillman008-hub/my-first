/**
 * One conversational turn with the real person.
 *
 *   load evidence → derive beliefs/facts/self-model → compile a brief → model replies
 *   → model reflects (structured JSON) → append evidence, attribute previous turn's outcome
 *
 * The model owns the pedagogy and the prose. The layer owns bookkeeping and epistemics:
 * what is claimed vs demonstrated, what was corrected, what changed, what we tried and what happened.
 */
import { db } from "@/db";
import { eq } from "drizzle-orm";
import { approachRecords, factObservations, messages, observations, sessions } from "@/db/schema";
import {
  Approach, Belief, CONTEXTS, Context, DIMS, DIM_LABELS, Dim, Fact, NEUTRAL, Probe, beliefFor, describe, ledgerSuggestion, planTurn, selfModelDisagreements, clamp,
} from "../core/model";
import { ChatMessage, getProvider } from "../llm";
import { PersonState, ensureSession, loadMessages, loadPersonState, nid } from "./store";

export type Brief = { text: string; approach: Approach; probe?: Probe; basedOn: string[]; tokens: number; context: Context };

const ctxLabel = (c: string) => c.replace("_", " ");

/** Compile everything the model should know about this person into a compact, epistemically honest brief. */
export function compileBrief(state: PersonState, guessedContext: Context, now: number, surfaced: Set<string>): Brief {
  const { beliefs, facts, ledger } = state;
  const lines: string[] = [];
  const active = beliefs.filter((b) => b.status === "active" || b.status === "contested");
  const activeFacts = facts.filter((f) => f.status === "active");
  const retired = beliefs.filter((b) => b.status === "retired" && now - b.lastEvidenceAt < 14 * 86_400_000);
  const recentlyRetracted = facts.filter((f) => f.status === "retracted" && f.retractedAt && now - f.retractedAt < 30 * 86_400_000);

  if (activeFacts.length) lines.push("FACTS the person has told you (treat as current unless they say otherwise):", ...activeFacts.map((f) => `- ${f.key}: ${f.value}`));
  if (recentlyRetracted.length) lines.push("NO LONGER TRUE (do not assume):", ...recentlyRetracted.map((f) => `- ${f.key} was ${f.value}`));
  if (active.length) {
    lines.push("HOW THIS PERSON WORKS (beliefs derived from evidence; each is a belief, not a fact):");
    for (const c of ["any", ...CONTEXTS] as const) {
      const bs = active.filter((b) => b.scope === c);
      if (!bs.length) continue;
      lines.push(`  ${c === "any" ? "in general" : `when ${ctxLabel(c)}`}:`);
      for (const b of bs) {
        const tag = b.status === "contested" ? " [may have changed recently]" : "";
        lines.push(`  - ${describe(b.dim, b.estimate)} (${b.basis}, confidence ${(b.confidence * 100).toFixed(0)}%, ${b.evidenceIds.length} obs)${tag}`);
      }
    }
  }
  const tensions = active.filter((b) => b.tension);
  if (tensions.length) lines.push("TENSIONS (what they say ≠ what works; do not silently pick a side):", ...tensions.map((b) => `- ${b.tension}`));
  if (retired.length) lines.push("Do NOT assume (the person corrected these recently): " + retired.map((b) => `${b.dim} preference`).join(", "));
  const dis = selfModelDisagreements(beliefs, ledger, guessedContext, now);
  if (dis.length) lines.push("YOUR OWN HISTORY disagrees with a belief: " + dis.map((d) => `${d.dim}: believed ${d.belief.toFixed(2)}, what actually worked ≈ ${d.worked.toFixed(2)}`).join("; "));
  const sug = ledgerSuggestion(ledger, guessedContext, now);
  if (sug && sug.mass >= 2) lines.push(`WHAT HAS WORKED with them when ${ctxLabel(guessedContext)} (from ${ledger.filter((l) => l.context === guessedContext && l.outcome).length} attributed turns): ` + DIMS.map((d) => `${d}=${sug.approach[d].toFixed(2)}`).join(" "));

  const plan = planTurn({ condition: "full", ctx: guessedContext, beliefs, ledger, now, turnsSoFar: ledger.length + 1, surfaced });
  lines.push(`PLANNED APPROACH: ` + DIMS.map((d) => `${d}=${plan.approach[d].toFixed(2)}`).join(" ") + `  (0..1 on each axis; ${DIMS.map((d) => `${d}: ${DIM_LABELS[d][0]} ↔ ${DIM_LABELS[d][1]}`).join("; ")}). Follow it unless the current message asks otherwise; explicit requests always win.`);
  if (plan.probe) {
    const q = plan.probe.kind === "unknown"
      ? `If natural, ask briefly how they'd like you to handle ${plan.probe.dim} (${DIM_LABELS[plan.probe.dim][0]} vs ${DIM_LABELS[plan.probe.dim][1]}).`
      : `You told them nothing yet, but they said they prefer ${describe(plan.probe.dim, plan.probe.stated)} while ${describe(plan.probe.dim, plan.probe.demonstrated)} has worked better. Raise this once, briefly and without judgement, and let them decide.`;
    lines.push(`QUESTION TO RAISE: ${q}`);
  }
  if (!lines.length) lines.push("You know nothing about this person yet. Work neutrally and pay attention to how they respond.");
  const text = lines.join("\n");
  return { text, approach: plan.approach, probe: plan.probe, basedOn: plan.basedOn, tokens: Math.round(text.length / 4), context: guessedContext };
}

const SYSTEM = `You are a capable assistant working with one particular person over a long period. You decide how to answer; the notes below tell you what has been learned about this person so far. They are beliefs derived from evidence, with provenance and confidence — not facts about the person. Never present a belief back to them as certain; if something seems off, ask. The person can see and delete everything you remember.

Rules: honour explicit requests in the current message over any note. Do not mention these notes unless asked ("what do you remember about me?"), in which case answer plainly and invite correction.`;

const REFLECT = `You are the reflection step of a system that learns how to work with one person over time. Read the exchange and extract evidence. Be conservative: only record what the message actually supports. Distinguish what the person SAYS about themselves (kind "stated") from what their behaviour SHOWS (kind "demonstrated": e.g. they asked a follow-up wanting more depth → depth evidence toward 1; they said "ok got it, too long" → depth toward 0). Record "correction" when they say the assistant remembered them wrongly or ignored what they said. Dimensions (0..1): depth (terse↔thorough), examples (principles↔examples first), checks (never quizzed↔often checked), directness (gentle↔blunt), pace (one step↔many steps). Scope is the context the evidence applies to ("quick_task" | "learning" | "debugging" | "planning") or "any" for general statements. Facts are stable things about the person (occupation, language, tools, goals, "already_knows:<topic>"); use kind "retracted" when something is no longer true.

Return ONLY JSON: {"context": one of quick_task|learning|debugging|planning, "approachUsed": {depth,examples,checks,directness,pace} as you judge the ASSISTANT REPLY actually was, "observations": [{"kind","dim","scope","value","note"}], "facts": [{"key","value","kind"}], "previousOutcome": {"success": true|false|null (did the PREVIOUS assistant reply seem to work, judging from this user message), "reaction": 0..1|null, "correction": boolean}, "explicit": {dim: value} for turn-local requests like "just the command"}`;

export type TurnResult = {
  sessionId: string;
  reply: string;
  trace: { brief: string; briefTokens: number; approach: Approach; provider: string; live: boolean; reflection: unknown; noted: string[] };
};

export async function runTurn(personId: string, sessionIdIn: string | null, userText: string): Promise<TurnResult> {
  const now = Date.now();
  const provider = getProvider();
  const session = await ensureSession(personId, sessionIdIn);
  const history = await loadMessages(session.id, 24);
  const state = await loadPersonState(personId, now);
  const surfaced = new Set<string>(history.flatMap((m) => ((m.meta as { surfaced?: string[] } | null)?.surfaced ?? [])));

  const userMsgId = nid("m_");
  await db.insert(messages).values({ id: userMsgId, sessionId: session.id, role: "user", content: userText });

  // A cheap context guess for the brief (the reflection will decide properly afterwards).
  const guessed = guessContext(userText, state);
  const brief = compileBrief(state, guessed, now, surfaced);

  const convo: ChatMessage[] = [
    { role: "system", content: `${SYSTEM}\n\n=== NOTES ABOUT THIS PERSON ===\n${brief.text}` },
    ...history.map((m) => ({ role: m.role as "user" | "assistant", content: m.content })),
    { role: "user", content: userText },
  ];
  let reply: string;
  try { reply = await provider.complete(convo); } catch (e) { reply = `I hit an error talking to the model (${(e as Error).message.slice(0, 120)}). Nothing about you was changed.`; }

  // Reflection: structured extraction by the model; bookkeeping by us.
  const reflectInput = `NOTES THE ASSISTANT HAD:\n${brief.text}\n\nPREVIOUS ASSISTANT REPLY:\n${history.filter((m) => m.role === "assistant").slice(-1)[0]?.content?.slice(0, 1200) ?? "(none)"}\n\nUSER MESSAGE:\n${userText}\n\nASSISTANT REPLY:\n${reply.slice(0, 2000)}`;
  let reflection: Reflection = emptyReflection(brief.approach, guessed);
  try {
    const raw = await provider.complete([{ role: "system", content: REFLECT }, { role: "user", content: reflectInput }], { json: true, maxTokens: 900 });
    reflection = validateReflection(JSON.parse(raw.replace(/^```(?:json)?/m, "").replace(/```$/m, "").trim()), brief.approach, guessed);
  } catch { /* keep the empty reflection: nothing learned this turn */ }

  const noted: string[] = [];
  const t = new Date(now);
  // 1. Attribute the outcome of the previous approach (next-turn credit).
  if (state.pending) {
    const o = reflection.previousOutcome;
    const outcome = { success: o.success ?? true, reaction: o.reaction ?? 0.5, correction: o.correction, at: now, known: o.success != null };
    await db.update(approachRecords).set({ outcome, outcomeFilled: true }).where(eq(approachRecords.id, state.pending.id));
    if (o.success != null) noted.push(`previous approach ${o.success ? "worked" : "did not work"}${o.correction ? " (you corrected me)" : ""}`);
  }
  // 2. Append evidence with provenance.
  for (const ob of reflection.observations) {
    await db.insert(observations).values({ id: nid("o_"), personId, sessionId: session.id, messageId: userMsgId, at: t, kind: ob.kind, dim: ob.dim, scope: ob.scope, value: ob.value, note: ob.note });
    noted.push(`${ob.kind}: ${ob.dim}${ob.scope !== "any" ? ` (${ctxLabel(ob.scope)})` : ""} → ${describe(ob.dim, ob.value)}`);
  }
  if (reflection.previousOutcome.correction && !reflection.observations.some((o) => o.kind === "correction")) noted.push("correction noted (no specific dimension identified)");
  for (const f of reflection.facts) {
    await db.insert(factObservations).values({ id: nid("f_"), personId, sessionId: session.id, messageId: userMsgId, at: t, key: f.key, value: f.value, kind: f.kind });
    noted.push(`${f.kind === "retracted" ? "no longer" : "fact"}: ${f.key} = ${f.value}`);
  }
  // 3. Record what we did (self-model), to be attributed on the next turn.
  const assistantMsgId = nid("m_");
  await db.insert(approachRecords).values({ id: nid("a_"), personId, sessionId: session.id, messageId: assistantMsgId, at: new Date(now + 1), context: reflection.context, approach: reflection.approachUsed, basedOn: brief.basedOn });
  const newlySurfaced = brief.probe?.kind === "tension" ? state.beliefs.filter((b) => b.dim === brief.probe!.dim && b.tension).map((b) => b.id) : [];
  await db.insert(messages).values({ id: assistantMsgId, sessionId: session.id, role: "assistant", content: reply, meta: { brief: brief.text, briefTokens: brief.tokens, approach: reflection.approachUsed, provider: provider.name, live: provider.live, reflection, noted, surfaced: newlySurfaced } });
  await db.update(sessions).set({ lastActiveAt: new Date(), ...(history.length === 0 ? { title: userText.slice(0, 60) } : {}) }).where(eq(sessions.id, session.id));

  return { sessionId: session.id, reply, trace: { brief: brief.text, briefTokens: brief.tokens, approach: reflection.approachUsed, provider: provider.name, live: provider.live, reflection, noted } };
}

type Reflection = {
  context: Context;
  approachUsed: Approach;
  observations: { kind: "stated" | "demonstrated" | "reaction" | "correction"; dim: Dim; scope: Context | "any"; value: number; note?: string }[];
  facts: { key: string; value: string; kind: "stated" | "retracted" }[];
  previousOutcome: { success: boolean | null; reaction: number | null; correction: boolean };
  explicit: Partial<Approach>;
};

function emptyReflection(approach: Approach, ctx: Context): Reflection {
  return { context: ctx, approachUsed: approach, observations: [], facts: [], previousOutcome: { success: null, reaction: null, correction: false }, explicit: {} };
}

/** Never trust model JSON blindly: clamp, whitelist, drop anything malformed. */
function validateReflection(raw: unknown, fallbackApproach: Approach, fallbackCtx: Context): Reflection {
  const r = (raw ?? {}) as Record<string, unknown>;
  const ctx = CONTEXTS.includes(r.context as Context) ? (r.context as Context) : fallbackCtx;
  const au = (r.approachUsed ?? {}) as Record<string, unknown>;
  const approachUsed: Approach = { ...NEUTRAL };
  for (const d of DIMS) approachUsed[d] = typeof au[d] === "number" ? clamp(au[d] as number) : fallbackApproach[d];
  const kinds = new Set(["stated", "demonstrated", "reaction", "correction"]);
  const observationsOut: Reflection["observations"] = [];
  for (const o of Array.isArray(r.observations) ? (r.observations as Record<string, unknown>[]).slice(0, 12) : []) {
    if (!kinds.has(String(o.kind)) || !DIMS.includes(o.dim as Dim)) continue;
    const scope = CONTEXTS.includes(o.scope as Context) ? (o.scope as Context) : "any";
    observationsOut.push({ kind: o.kind as Reflection["observations"][number]["kind"], dim: o.dim as Dim, scope, value: typeof o.value === "number" ? clamp(o.value) : 0.5, note: typeof o.note === "string" ? o.note.slice(0, 200) : undefined });
  }
  const facts: Reflection["facts"] = [];
  for (const f of Array.isArray(r.facts) ? (r.facts as Record<string, unknown>[]).slice(0, 8) : []) {
    if (typeof f.key !== "string" || typeof f.value !== "string" || !f.key.trim()) continue;
    facts.push({ key: f.key.trim().toLowerCase().slice(0, 60), value: f.value.trim().slice(0, 120), kind: f.kind === "retracted" ? "retracted" : "stated" });
  }
  const po = (r.previousOutcome ?? {}) as Record<string, unknown>;
  const explicit: Partial<Approach> = {};
  const ex = (r.explicit ?? {}) as Record<string, unknown>;
  for (const d of DIMS) if (typeof ex[d] === "number") explicit[d] = clamp(ex[d] as number);
  return {
    context: ctx, approachUsed, observations: observationsOut, facts,
    previousOutcome: { success: typeof po.success === "boolean" ? po.success : null, reaction: typeof po.reaction === "number" ? clamp(po.reaction) : null, correction: po.correction === true },
    explicit,
  };
}

function guessContext(text: string, state: PersonState): Context {
  const t = text.toLowerCase();
  if (/\b(bug|error|fails|failing|crash|exception|traceback|doesn't work|not working)\b/.test(t)) return "debugging";
  if (/\b(understand|learn|teach|explain|why does|how does .* work)\b/.test(t)) return "learning";
  if (/\b(plan|design|architecture|where do i start|roadmap|approach for)\b/.test(t)) return "planning";
  // Default to the context this person most often works in, else quick task.
  const counts = new Map<Context, number>();
  for (const l of state.ledger) counts.set(l.context, (counts.get(l.context) ?? 0) + 1);
  const top = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];
  return top && top[1] > 5 && !/\?$/.test(t.trim()) ? top[0] : "quick_task";
}

export type { Belief, Fact };
export { beliefFor };
