/**
 * LLM provider abstraction. Keys are read from the environment server-side only and never logged.
 * Provider is chosen at request time so a key added later is picked up without a rebuild.
 */
export type ChatMessage = { role: "system" | "user" | "assistant"; content: string };
export type Provider = { name: string; live: boolean; complete: (messages: ChatMessage[], opts?: { json?: boolean; maxTokens?: number }) => Promise<string> };

export function getProvider(): Provider {
  if (process.env.LLM_PROVIDER === "mock") return mockProvider();
  if (process.env.ANTHROPIC_API_KEY) return anthropic(process.env.ANTHROPIC_API_KEY);
  if (process.env.OPENAI_API_KEY) return openai(process.env.OPENAI_API_KEY);
  if (process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY) return gemini((process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY)!);
  return mockProvider();
}

function anthropic(key: string): Provider {
  const model = process.env.ANTHROPIC_MODEL || "claude-sonnet-4-5";
  const base = process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com";
  return {
    name: `anthropic:${model}`, live: true,
    async complete(messages, opts) {
      const system = messages.filter((m) => m.role === "system").map((m) => m.content).join("\n\n");
      const rest = messages.filter((m) => m.role !== "system").map((m) => ({ role: m.role, content: m.content }));
      const res = await fetch(`${base}/v1/messages`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model, max_tokens: opts?.maxTokens ?? 1200, system, messages: rest }),
      });
      if (!res.ok) throw new Error(`anthropic ${res.status}: ${(await res.text()).slice(0, 300)}`);
      const data = (await res.json()) as { content: { type: string; text?: string }[] };
      return data.content.filter((c) => c.type === "text").map((c) => c.text ?? "").join("");
    },
  };
}

function openai(key: string): Provider {
  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";
  const base = process.env.OPENAI_BASE_URL || "https://api.openai.com/v1";
  return {
    name: `openai:${model}`, live: true,
    async complete(messages, opts) {
      const res = await fetch(`${base}/chat/completions`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
        body: JSON.stringify({ model, messages, max_tokens: opts?.maxTokens ?? 1200, ...(opts?.json ? { response_format: { type: "json_object" } } : {}) }),
      });
      if (!res.ok) throw new Error(`openai ${res.status}: ${(await res.text()).slice(0, 300)}`);
      const data = (await res.json()) as { choices: { message: { content: string } }[] };
      return data.choices[0]?.message?.content ?? "";
    },
  };
}

function gemini(key: string): Provider {
  const model = process.env.GEMINI_MODEL || "gemini-2.0-flash";
  return {
    name: `gemini:${model}`, live: true,
    async complete(messages, opts) {
      const system = messages.filter((m) => m.role === "system").map((m) => m.content).join("\n\n");
      const contents = messages.filter((m) => m.role !== "system").map((m) => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] }));
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents, generationConfig: { maxOutputTokens: opts?.maxTokens ?? 1200, ...(opts?.json ? { responseMimeType: "application/json" } : {}) } }),
      });
      if (!res.ok) throw new Error(`gemini ${res.status}: ${(await res.text()).slice(0, 300)}`);
      const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
      return data.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
    },
  };
}

/**
 * Offline model. Not intelligent: it exists so the memory layer, UI and lab run end to end without a key.
 * It reads the brief's "work this turn" line and produces a response whose *shape* follows it, and it
 * performs reflection with simple lexical heuristics. Every reply is labelled as offline.
 */
function mockProvider(): Provider {
  return {
    name: "offline-mock", live: false,
    async complete(messages, opts) {
      const last = messages[messages.length - 1]?.content ?? "";
      if (opts?.json) return mockReflect(messages);
      const sys = messages.find((m) => m.role === "system")?.content ?? "";
      const approachLine = sys.match(/PLANNED APPROACH: (.*)/)?.[1] ?? "";
      const ask = sys.match(/QUESTION TO RAISE: (.*)/)?.[1];
      const depth = Number(approachLine.match(/depth=([\d.]+)/)?.[1] ?? 0.5);
      const examples = Number(approachLine.match(/examples=([\d.]+)/)?.[1] ?? 0.5);
      const checks = Number(approachLine.match(/checks=([\d.]+)/)?.[1] ?? 0.5);
      const topic = last.replace(/\s+/g, " ").slice(0, 80);
      const parts = [`(offline model — no LLM key configured; showing how the layer would shape a reply)`, `On “${topic}”:`];
      parts.push(depth > 0.65 ? "Here is the full picture, including the background you'd need to reason about edge cases." : depth < 0.35 ? "Short version:" : "Here's the essential explanation.");
      if (examples > 0.6) parts.push("Concrete example first: …then the general rule.");
      else if (examples < 0.4) parts.push("Principle first: …then how it applies here.");
      if (checks > 0.6) parts.push("Quick check before we move on: can you tell me in one line what you'd expect to happen?");
      if (ask) parts.push(ask);
      return parts.join("\n\n");
    },
  };
}

function mockReflect(messages: ChatMessage[]): string {
  const src = messages[messages.length - 1]?.content ?? "";
  const user = (src.match(/USER MESSAGE:\n([\s\S]*?)\n\nASSISTANT REPLY:/)?.[1] ?? "").toLowerCase();
  const obs: { kind: string; dim: string; scope: string; value: number; note: string }[] = [];
  const facts: { key: string; value: string; kind: string }[] = [];
  const add = (dim: string, value: number, note: string, kind = "stated") => obs.push({ kind, dim, scope: "any", value, note });
  if (/\b(shorter|too long|just the answer|brief|concise|tl;dr|skip the background)\b/.test(user)) add("depth", 0.15, "asked for brevity");
  if (/\b(more detail|in depth|thorough|explain fully|background)\b/.test(user)) add("depth", 0.85, "asked for depth");
  if (/\b(example|show me|concrete)\b/.test(user)) add("examples", 0.85, "asked for an example");
  if (/\b(theory|principle|why does|conceptually)\b/.test(user)) add("examples", 0.2, "asked for principles");
  if (/\b(quiz me|test me|check me)\b/.test(user)) add("checks", 0.85, "asked to be checked");
  if (/\b(don't quiz|stop quizzing|no quizzes|don't test me)\b/.test(user)) add("checks", 0.1, "asked not to be checked");
  if (/\b(be blunt|be direct|don't sugarcoat)\b/.test(user)) add("directness", 0.9, "asked for directness");
  if (/\b(slow down|one step at a time|step by step)\b/.test(user)) add("pace", 0.15, "asked to slow down");
  if (/\b(faster|speed up|skip ahead)\b/.test(user)) add("pace", 0.85, "asked to go faster");
  let correction = false;
  if (/\b(i told you|i already said|as i said|again,|that's not (true|me)|no, i)\b/.test(user)) correction = true;
  const occ = user.match(/\bi(?:'m| am) an? ([a-z ]{3,30}?)(?:[.,;]| and | who | at | in |$)/);
  if (occ) facts.push({ key: "occupation", value: occ[1].trim(), kind: "stated" });
  const lang = user.match(/\b(?:i use|i work in|i write|i code in|switched to|moved to|now using) ([a-z+#]{1,20})\b/);
  if (lang) facts.push({ key: "language", value: lang[1], kind: "stated" });
  const already = user.match(/\bi already know ([a-z ]{2,30}?)(?:[.,;]|$)/);
  if (already) facts.push({ key: `already_knows:${already[1].trim()}`, value: "yes", kind: "stated" });
  const context = /\b(bug|error|fails|crash|exception|traceback|doesn't work)\b/.test(user) ? "debugging" : /\b(understand|learn|teach|explain how|why does)\b/.test(user) ? "learning" : /\b(plan|design|architecture|where do i start|roadmap)\b/.test(user) ? "planning" : "quick_task";
  const negative = /\b(didn't work|still don't|doesn't help|not what i|confus|wrong)\b/.test(user);
  const positive = /\b(thanks|helpful|great|perfect|that works|makes sense)\b/.test(user);
  const approachLine = src.match(/PLANNED APPROACH: (.*)/)?.[1] ?? "";
  const num = (k: string) => Number(approachLine.match(new RegExp(`${k}=([\\d.]+)`))?.[1] ?? 0.5);
  return JSON.stringify({
    context,
    approachUsed: { depth: num("depth"), examples: num("examples"), checks: num("checks"), directness: num("directness"), pace: num("pace") },
    observations: obs,
    facts,
    previousOutcome: { success: negative ? false : positive ? true : null, reaction: positive ? 1 : negative ? 0 : null, correction },
    explicit: {},
  });
}
