"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";

type Belief = { id: string; dim: string; scope: string; estimate: number; confidence: number; status: string; basis: string; evidenceIds: string[]; tension?: string; driftDetectedAt?: number; history: { at: number; why: string }[] };
type Fact = { key: string; value: string; status: string; statedAt: number };
type Obs = { id: string; at: number; kind: string; dim: string; scope: string; value: number; note?: string };
type Memory = { beliefs: Belief[]; facts: Fact[]; observations: Obs[]; selfModel: { context: string; attributed: number; successRate: number | null; suggestion: Record<string, number> | null }[]; ledgerSize: number; brief: string; briefTokens: number };
type Msg = { id: string; role: "user" | "assistant"; content: string; meta?: { noted?: string[]; brief?: string; briefTokens?: number; provider?: string; live?: boolean; approach?: Record<string, number> } | null };
type Session = { id: string; title: string; lastActiveAt: string };

const DIM_LABELS: Record<string, [string, string]> = {
  depth: ["terse", "thorough"], examples: ["principles", "examples"], checks: ["no checks", "checks often"], directness: ["gentle", "blunt"], pace: ["one step", "fast"],
};
const label = (s: string) => s.replace("_", " ");

export default function Workbench() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [memory, setMemory] = useState<Memory | null>(null);
  const [status, setStatus] = useState<{ provider: string; live: boolean } | null>(null);
  const [tab, setTab] = useState<"beliefs" | "evidence" | "self" | "brief">("beliefs");
  const [openTrace, setOpenTrace] = useState<string | null>(null);
  const bottom = useRef<HTMLDivElement>(null);

  const refreshMemory = useCallback(async () => setMemory(await (await fetch("/api/memory")).json()), []);
  const refreshSessions = useCallback(async () => setSessions((await (await fetch("/api/sessions")).json()).sessions), []);
  useEffect(() => { refreshMemory(); refreshSessions(); fetch("/api/status").then((r) => r.json()).then(setStatus); }, [refreshMemory, refreshSessions]);
  useEffect(() => { bottom.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  async function openSession(id: string | null) {
    setSessionId(id); setOpenTrace(null);
    if (!id) return setMsgs([]);
    const d = await (await fetch(`/api/sessions/${id}`)).json();
    setMsgs(d.messages);
  }

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    setInput(""); setBusy(true);
    const tempId = "tmp" + Date.now();
    setMsgs((m) => [...m, { id: tempId, role: "user", content: text }]);
    try {
      const r = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ message: text, sessionId }) });
      const d = await r.json();
      if (d.error) throw new Error(d.error);
      setSessionId(d.sessionId);
      setMsgs((m) => [...m, { id: "a" + Date.now(), role: "assistant", content: d.reply, meta: { noted: d.trace.noted, brief: d.trace.brief, briefTokens: d.trace.briefTokens, provider: d.trace.provider, live: d.trace.live, approach: d.trace.approach } }]);
      refreshMemory(); refreshSessions();
    } catch (e) {
      setMsgs((m) => [...m, { id: "e" + Date.now(), role: "assistant", content: `Error: ${(e as Error).message}` }]);
    } finally { setBusy(false); }
  }

  async function notTrue(id: string) { await fetch(`/api/memory/beliefs/${encodeURIComponent(id)}`, { method: "DELETE" }); refreshMemory(); }
  async function dropObs(id: string) { await fetch(`/api/memory/observations/${id}`, { method: "DELETE" }); refreshMemory(); }
  async function retractFact(f: Fact) { await fetch(`/api/memory/facts`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ key: f.key, value: f.value, kind: "retracted" }) }); refreshMemory(); }
  async function eraseAll() { if (!confirm("Erase everything the system knows about you, including all conversations?")) return; await fetch("/api/memory", { method: "DELETE" }); setMsgs([]); setSessionId(null); refreshMemory(); refreshSessions(); }

  const active = memory?.beliefs.filter((b) => b.status !== "retired") ?? [];
  const retired = memory?.beliefs.filter((b) => b.status === "retired") ?? [];

  return (
    <div className="grid h-screen grid-cols-[220px_1fr_400px] bg-slate-50 text-slate-900">
      {/* sessions */}
      <aside className="flex flex-col border-r border-slate-200 bg-white">
        <div className="border-b border-slate-200 p-4">
          <h1 className="text-sm font-semibold tracking-tight">Adaptation Lab</h1>
          <p className="mt-1 text-xs text-slate-500">one AI · one person · over time</p>
          <div className="mt-2 flex items-center gap-2 text-xs">
            <span className={`inline-block h-2 w-2 rounded-full ${status?.live ? "bg-emerald-500" : "bg-amber-400"}`} />
            <span className="truncate text-slate-600" title={status?.provider}>{status ? (status.live ? status.provider : "offline model (no key)") : "…"}</span>
          </div>
        </div>
        <button onClick={() => openSession(null)} className="m-3 rounded-lg bg-slate-900 px-3 py-2 text-xs font-medium text-white hover:bg-slate-700">+ New conversation</button>
        <div className="flex-1 overflow-y-auto px-2">
          {sessions.map((s) => (
            <button key={s.id} onClick={() => openSession(s.id)} className={`mb-1 block w-full truncate rounded-md px-2 py-1.5 text-left text-xs hover:bg-slate-100 ${s.id === sessionId ? "bg-slate-100 font-medium" : ""}`}>{s.title}</button>
          ))}
        </div>
        <div className="border-t border-slate-200 p-3 text-xs">
          <Link href="/lab" className="text-indigo-600 hover:underline">Laboratory results →</Link>
          <div className="mt-1"><Link href="/findings" className="text-indigo-600 hover:underline">Findings →</Link></div>
        </div>
      </aside>

      {/* chat */}
      <main className="flex flex-col">
        <div className="flex-1 overflow-y-auto px-8 py-6">
          {msgs.length === 0 && (
            <div className="mx-auto mt-16 max-w-lg text-center text-sm text-slate-500">
              <p className="text-base font-medium text-slate-700">Just talk.</p>
              <p className="mt-2">Ask for help, ask to be taught, say “I already know X”, say “too long”, say “actually that’s not how I work”. The panel on the right shows what the system comes to believe — every item is a belief with evidence, and you can dispute or delete any of it.</p>
            </div>
          )}
          {msgs.map((m) => (
            <div key={m.id} className={`mb-4 flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${m.role === "user" ? "bg-slate-900 text-white" : "bg-white shadow-sm ring-1 ring-slate-200"}`}>
                <div className="whitespace-pre-wrap">{m.content}</div>
                {m.role === "assistant" && m.meta && (
                  <div className="mt-2 border-t border-slate-100 pt-2 text-xs text-slate-500">
                    <button onClick={() => setOpenTrace(openTrace === m.id ? null : m.id)} className="hover:text-slate-800">why this turn {openTrace === m.id ? "▾" : "▸"}</button>
                    {openTrace === m.id && (
                      <div className="mt-2 space-y-2">
                        <div><span className="font-medium">approach used:</span> {m.meta.approach && Object.entries(m.meta.approach).map(([k, v]) => `${k} ${v.toFixed(2)}`).join(" · ")}</div>
                        <div><span className="font-medium">noted from your message:</span> {m.meta.noted?.length ? <ul className="ml-4 list-disc">{m.meta.noted.map((n, i) => <li key={i}>{n}</li>)}</ul> : " nothing new"}</div>
                        <details><summary className="cursor-pointer">brief given to the model ({m.meta.briefTokens} tokens, {m.meta.provider})</summary><pre className="mt-1 whitespace-pre-wrap rounded bg-slate-50 p-2 font-mono text-[11px]">{m.meta.brief}</pre></details>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
          {busy && <div className="text-xs text-slate-400">thinking…</div>}
          <div ref={bottom} />
        </div>
        <form onSubmit={(e) => { e.preventDefault(); send(); }} className="border-t border-slate-200 bg-white p-4">
          <div className="flex gap-2">
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Message…" className="flex-1 rounded-xl border border-slate-300 px-4 py-2.5 text-sm outline-none focus:border-slate-500" />
            <button disabled={busy} className="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-500 disabled:opacity-50">Send</button>
          </div>
        </form>
      </main>

      {/* memory */}
      <aside className="flex flex-col border-l border-slate-200 bg-white">
        <div className="border-b border-slate-200 p-4">
          <h2 className="text-sm font-semibold">What it believes about you</h2>
          <div className="mt-2 flex gap-1 text-xs">
            {(["beliefs", "evidence", "self", "brief"] as const).map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`rounded-md px-2 py-1 ${tab === t ? "bg-slate-900 text-white" : "bg-slate-100 hover:bg-slate-200"}`}>{t === "self" ? "self-model" : t}</button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-4 text-xs">
          {!memory && <p className="text-slate-400">loading…</p>}
          {memory && tab === "beliefs" && (
            <div className="space-y-4">
              <section>
                <h3 className="mb-1 font-medium text-slate-700">Facts you told it</h3>
                {memory.facts.filter((f) => f.status === "active").length === 0 && <p className="text-slate-400">none yet</p>}
                {memory.facts.filter((f) => f.status === "active").map((f) => (
                  <div key={f.key} className="mb-1 flex items-center justify-between rounded border border-slate-200 px-2 py-1">
                    <span><span className="text-slate-500">{f.key}:</span> {f.value}</span>
                    <button onClick={() => retractFact(f)} className="text-rose-600 hover:underline">no longer true</button>
                  </div>
                ))}
              </section>
              <section>
                <h3 className="mb-1 font-medium text-slate-700">How you like to work <span className="font-normal text-slate-400">({active.length} beliefs)</span></h3>
                {active.length === 0 && <p className="text-slate-400">nothing inferred yet — it will form beliefs only from evidence, and only act on them once there is enough.</p>}
                {active.map((b) => (
                  <div key={b.id} className="mb-2 rounded-lg border border-slate-200 p-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{b.dim} <span className="font-normal text-slate-500">· {b.scope === "any" ? "in general" : label(b.scope)}</span></span>
                      <span className={`rounded px-1.5 py-0.5 text-[10px] uppercase ${b.status === "active" ? "bg-emerald-100 text-emerald-700" : b.status === "contested" ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-600"}`}>{b.status}</span>
                    </div>
                    <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-500">
                      <span className="w-16 text-right">{DIM_LABELS[b.dim]?.[0]}</span>
                      <div className="relative h-1.5 flex-1 rounded bg-slate-200"><div className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-600" style={{ left: `${b.estimate * 100}%`, opacity: 0.4 + 0.6 * b.confidence }} /></div>
                      <span className="w-16">{DIM_LABELS[b.dim]?.[1]}</span>
                    </div>
                    <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
                      <span>{b.basis} · confidence {(b.confidence * 100).toFixed(0)}% · {b.evidenceIds.length} obs{b.driftDetectedAt ? " · change detected" : ""}</span>
                      <button onClick={() => notTrue(b.id)} className="text-rose-600 hover:underline">not true</button>
                    </div>
                    {b.tension && <div className="mt-1 rounded bg-amber-50 px-2 py-1 text-[11px] text-amber-800">tension: {b.tension}</div>}
                  </div>
                ))}
              </section>
              {retired.length > 0 && (
                <section>
                  <h3 className="mb-1 font-medium text-slate-700">Retired (you corrected these)</h3>
                  {retired.map((b) => <div key={b.id} className="text-slate-500">{b.dim} · {b.scope === "any" ? "in general" : label(b.scope)} — {b.history.slice(-1)[0]?.why}</div>)}
                </section>
              )}
              <button onClick={eraseAll} className="mt-4 w-full rounded-lg border border-rose-300 py-2 text-rose-700 hover:bg-rose-50">Erase everything it knows about me</button>
            </div>
          )}
          {memory && tab === "evidence" && (
            <div>
              <p className="mb-2 text-slate-500">Append-only evidence, newest first. Delete any item; beliefs are re-derived from what remains.</p>
              {[...memory.observations].reverse().map((o) => (
                <div key={o.id} className="mb-1 flex items-start justify-between gap-2 rounded border border-slate-100 px-2 py-1">
                  <span><span className={`mr-1 rounded px-1 text-[10px] uppercase ${o.kind === "demonstrated" ? "bg-indigo-100 text-indigo-700" : o.kind === "stated" ? "bg-sky-100 text-sky-700" : o.kind === "correction" ? "bg-rose-100 text-rose-700" : "bg-slate-100"}`}>{o.kind}</span>{o.dim} {o.kind !== "correction" && `→ ${o.value.toFixed(2)}`} <span className="text-slate-400">({o.scope === "any" ? "general" : label(o.scope)}{o.note ? ` · ${o.note}` : ""}) {new Date(o.at).toLocaleDateString()}</span></span>
                  <button onClick={() => dropObs(o.id)} className="shrink-0 text-rose-600 hover:underline">delete</button>
                </div>
              ))}
              {memory.observations.length === 0 && <p className="text-slate-400">no evidence yet</p>}
            </div>
          )}
          {memory && tab === "self" && (
            <div>
              <p className="mb-2 text-slate-500">What the AI has tried with you and how it went (outcome attributed from your next message). {memory.ledgerSize} turns recorded.</p>
              {memory.selfModel.map((s) => (
                <div key={s.context} className="mb-2 rounded-lg border border-slate-200 p-2">
                  <div className="font-medium">{label(s.context)} <span className="font-normal text-slate-500">· {s.attributed} attributed turns{s.successRate != null ? ` · ${(s.successRate * 100).toFixed(0)}% seemed to work` : ""}</span></div>
                  {s.suggestion ? <div className="mt-1 text-slate-600">what has worked: {Object.entries(s.suggestion).map(([k, v]) => `${k} ${v.toFixed(2)}`).join(" · ")}</div> : <div className="mt-1 text-slate-400">not enough history yet</div>}
                </div>
              ))}
            </div>
          )}
          {memory && tab === "brief" && (
            <div>
              <p className="mb-2 text-slate-500">The exact notes the model receives about you at the start of a turn (~{memory.briefTokens} tokens).</p>
              <pre className="whitespace-pre-wrap rounded bg-slate-50 p-2 font-mono text-[11px]">{memory.brief}</pre>
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}
