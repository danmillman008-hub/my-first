import { pgTable, text, timestamp, integer, real, jsonb, boolean, index } from "drizzle-orm/pg-core";

/** The person the AI is learning to work with. One row per human. */
export const people = pgTable("people", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  personId: text("person_id").notNull().references(() => people.id, { onDelete: "cascade" }),
  title: text("title").notNull().default("Conversation"),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  lastActiveAt: timestamp("last_active_at", { withTimezone: true }).notNull().defaultNow(),
});

export const messages = pgTable("messages", {
  id: text("id").primaryKey(),
  sessionId: text("session_id").notNull().references(() => sessions.id, { onDelete: "cascade" }),
  role: text("role").notNull(), // user | assistant
  content: text("content").notNull(),
  meta: jsonb("meta"), // assistant: { brief, reflection, provider, approach }
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("messages_session_idx").on(t.sessionId)]);

/** Append-only evidence about how the person works. Beliefs are derived, never stored as truth. */
export const observations = pgTable("observations", {
  id: text("id").primaryKey(),
  personId: text("person_id").notNull().references(() => people.id, { onDelete: "cascade" }),
  sessionId: text("session_id").notNull(),
  messageId: text("message_id"), // provenance: which message this was read from
  at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
  kind: text("kind").notNull(), // stated | demonstrated | reaction | correction
  dim: text("dim").notNull(),
  scope: text("scope").notNull(), // context or "any"
  value: real("value").notNull(),
  note: text("note"),
}, (t) => [index("observations_person_idx").on(t.personId)]);

/** Append-only statements of fact about the person ("I'm a nurse", "I moved to Rust"). */
export const factObservations = pgTable("fact_observations", {
  id: text("id").primaryKey(),
  personId: text("person_id").notNull().references(() => people.id, { onDelete: "cascade" }),
  sessionId: text("session_id").notNull(),
  messageId: text("message_id"),
  at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
  key: text("key").notNull(),
  value: text("value").notNull(),
  kind: text("kind").notNull(), // stated | retracted
}, (t) => [index("fact_obs_person_idx").on(t.personId)]);

/** The AI's self-model: what it tried, on what basis, and what happened next. */
export const approachRecords = pgTable("approach_records", {
  id: text("id").primaryKey(),
  personId: text("person_id").notNull().references(() => people.id, { onDelete: "cascade" }),
  sessionId: text("session_id").notNull(),
  messageId: text("message_id"),
  at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
  context: text("context").notNull(),
  approach: jsonb("approach").notNull(),
  basedOn: jsonb("based_on").notNull(),
  outcome: jsonb("outcome"), // { success, reaction, correction, at } — filled on the next user turn
  outcomeFilled: boolean("outcome_filled").notNull().default(false),
}, (t) => [index("approach_person_idx").on(t.personId)]);

/** Laboratory runs (simulated people), kept so results are inspectable and reproducible. */
export const labRuns = pgTable("lab_runs", {
  id: text("id").primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  config: jsonb("config").notNull(),
  summary: jsonb("summary").notNull(),
  durationMs: integer("duration_ms").notNull(),
});
