import { runLab, CONDITIONS } from "../src/lib/sim/lab";
const sessions = Number(process.env.SESSIONS ?? 12), seeds = Number(process.env.SEEDS ?? 4);
const { summary } = runLab({ sessions, turnsPerSession: 8, seeds });
const fmt = (x: unknown) => typeof x === "number" ? (Number.isNaN(x) ? "  -  " : x.toFixed(2).padStart(5)) : String(x);
console.log(`runs=${summary.runs} sessions=${sessions} seeds=${seeds}`);
console.log("cond            | fitE  fitL  | succE succL | reactL | restate corr viol staleF | bErr act probes trust ctxTok");
for (const c of CONDITIONS) {
  const e = summary.byCondition[c].early, l = summary.byCondition[c].late, a = summary.byCondition[c].all;
  console.log(`${c.padEnd(15)} | ${fmt(e.fit)} ${fmt(l.fit)} | ${fmt(e.success)} ${fmt(l.success)} | ${fmt(l.reactionPositive)}  | ${fmt(a.restatements)}   ${fmt(a.corrections)} ${fmt(a.violations)} ${fmt(a.staleFactUses)} | ${fmt(l.beliefError)} ${fmt(l.activeBeliefs)} ${fmt(a.probes)} ${fmt(l.trust)} ${fmt(a.contextTokens)}`);
}
console.log("\nper archetype (fitEarly→fitLate, driftRecovery sessions):");
for (const [arch] of Object.entries(summary.byConditionArchetype.none)) {
  console.log(arch.padEnd(16) + CONDITIONS.map((c) => { const r = summary.byConditionArchetype[c][arch]; return `${c}:${r.fitEarly.toFixed(2)}→${r.fitLate.toFixed(2)}${r.driftRecovery != null ? `(dr${r.driftRecovery})` : ""}`; }).join("  "));
}
if (process.env.CURVE) {
  const arch = process.env.CURVE;
  const { results } = runLab({ sessions, turnsPerSession: 8, seeds, archetypes: [arch] });
  console.log(`\nfit per session for ${arch}:`);
  for (const c of CONDITIONS) { const rs = results.filter((r) => r.condition === c); const row = []; for (let s = 0; s < sessions; s++) row.push((rs.reduce((a, r) => a + r.sessions[s].fit, 0) / rs.length).toFixed(2)); console.log(c.padEnd(15), row.join(" ")); }
  console.log(`trust per session for ${arch}:`);
  for (const c of CONDITIONS) { const rs = results.filter((r) => r.condition === c); const row = []; for (let s = 0; s < sessions; s++) row.push((rs.reduce((a, r) => a + r.sessions[s].trust, 0) / rs.length).toFixed(2)); console.log(c.padEnd(15), row.join(" ")); }
}
