import { runLab } from "../src/lib/sim/lab";
import { TUNING } from "../src/lib/core/model";
console.log("== recency half-life sweep (12 sessions, 4 seeds) — late fit / drifter recovery / drifter late fit ==");
for (const hl of [3, 7, 21, 60, 1000]) {
  TUNING.recencyHalfLifeDays = hl;
  const { summary } = runLab({ sessions: 12, turnsPerSession: 8, seeds: 4, conditions: ["beliefs", "full"] });
  for (const c of ["beliefs", "full"] as const) { const s = summary.byCondition[c]; const d = summary.byConditionArchetype[c]["drifter"]; const te = summary.byConditionArchetype[c]["terse-engineer"];
    console.log(`hl=${String(hl).padStart(4)}d ${c.padEnd(8)} lateFit=${s.late.fit} lateSuccess=${s.late.success} restate=${s.all.restatements} | drifter late=${d.fitLate} recovery=${d.driftRecovery} | terse late=${te.fitLate}`); }
}
TUNING.recencyHalfLifeDays = 21;
console.log("\n== long horizon: 30 sessions, 3 seeds ==");
const { summary } = runLab({ sessions: 30, turnsPerSession: 8, seeds: 3 });
for (const [c, s] of Object.entries(summary.byCondition)) {
  const curve = s.perSession.map((m) => m.fit);
  const q = (a: number, b: number) => (curve.slice(a, b).reduce((x, y) => x + y, 0) / (b - a)).toFixed(3);
  console.log(`${c.padEnd(15)} fit s0-4=${q(0,5)} s5-9=${q(5,10)} s10-19=${q(10,20)} s20-29=${q(20,30)} | restate late=${s.late.restatements} trust late=${s.late.trust} activeBeliefs late=${s.late.activeBeliefs} ctxTok=${Math.round(s.all.contextTokens!)}`);
}
