import "server-only";
import { and, asc, count, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  activityLog, courses, enrollments, lessonProgress, lessons, modules, stepProgress, steps, users,
  type Course, type Lesson, type Module, type Step,
} from "@/db/schema";

export type CourseWithStats = Course & { lessonCount: number; enrolledCount: number };

export async function listPublishedCourses(opts: { q?: string; category?: string; level?: string } = {}) {
  const rows = await db
    .select({
      course: courses,
      lessonCount: sql<number>`(select count(*) from ${lessons} l join ${modules} m on l.module_id = m.id where m.course_id = ${courses}.id)`.mapWith(Number),
      enrolledCount: sql<number>`(select count(*) from ${enrollments} e where e.course_id = ${courses}.id)`.mapWith(Number),
    })
    .from(courses)
    .where(eq(courses.status, "published"))
    .orderBy(asc(courses.position), asc(courses.id));

  const q = opts.q?.trim().toLowerCase();
  return rows
    .map((r) => ({ ...r.course, lessonCount: r.lessonCount, enrolledCount: r.enrolledCount }) as CourseWithStats)
    .filter((c) => !opts.category || c.category === opts.category)
    .filter((c) => !opts.level || c.level === opts.level)
    .filter((c) => !q || c.title.toLowerCase().includes(q) || c.tagline.toLowerCase().includes(q) || c.tags.some((t) => t.toLowerCase().includes(q)));
}

export async function listCategories() {
  const rows = await db.selectDistinct({ category: courses.category }).from(courses).where(eq(courses.status, "published"));
  return rows.map((r) => r.category).sort();
}

export type CourseTree = Course & { modules: (Module & { lessons: Lesson[] })[] };

export async function getCourseTree(where: { slug?: string; id?: number }, includeDrafts = false): Promise<CourseTree | null> {
  const cond = where.id !== undefined ? eq(courses.id, where.id) : eq(courses.slug, where.slug ?? "");
  const [course] = await db.select().from(courses).where(cond).limit(1);
  if (!course) return null;
  if (!includeDrafts && course.status !== "published") return null;

  const mods = await db.select().from(modules).where(eq(modules.courseId, course.id)).orderBy(asc(modules.position), asc(modules.id));
  const modIds = mods.map((m) => m.id);
  const lessonRows = modIds.length
    ? await db.select().from(lessons).where(inArray(lessons.moduleId, modIds)).orderBy(asc(lessons.position), asc(lessons.id))
    : [];
  const visibleLessons = includeDrafts ? lessonRows : lessonRows.filter((l) => l.status === "published");

  return {
    ...course,
    modules: mods.map((m) => ({ ...m, lessons: visibleLessons.filter((l) => l.moduleId === m.id) })),
  };
}

export function flattenLessons(tree: CourseTree): Lesson[] {
  return tree.modules.flatMap((m) => m.lessons);
}

export async function getLessonSteps(lessonId: number): Promise<Step[]> {
  return db.select().from(steps).where(eq(steps.lessonId, lessonId)).orderBy(asc(steps.position), asc(steps.id));
}

export async function getCompletedLessonIds(userId: number, lessonIds: number[]): Promise<Set<number>> {
  if (!lessonIds.length) return new Set();
  const rows = await db.select({ lessonId: lessonProgress.lessonId }).from(lessonProgress)
    .where(and(eq(lessonProgress.userId, userId), inArray(lessonProgress.lessonId, lessonIds)));
  return new Set(rows.map((r) => r.lessonId));
}

export async function getCompletedStepIds(userId: number, stepIds: number[]): Promise<Set<number>> {
  if (!stepIds.length) return new Set();
  const rows = await db.select({ stepId: stepProgress.stepId }).from(stepProgress)
    .where(and(eq(stepProgress.userId, userId), inArray(stepProgress.stepId, stepIds)));
  return new Set(rows.map((r) => r.stepId));
}

export async function isEnrolled(userId: number, courseId: number) {
  const [row] = await db.select({ courseId: enrollments.courseId }).from(enrollments)
    .where(and(eq(enrollments.userId, userId), eq(enrollments.courseId, courseId))).limit(1);
  return !!row;
}

export type EnrolledCourseProgress = { course: Course; total: number; completed: number; nextLesson: Lesson | null };

export async function getUserEnrollments(userId: number): Promise<EnrolledCourseProgress[]> {
  const enrolled = await db.select({ course: courses }).from(enrollments)
    .innerJoin(courses, eq(enrollments.courseId, courses.id))
    .where(eq(enrollments.userId, userId))
    .orderBy(desc(enrollments.enrolledAt));

  const result: EnrolledCourseProgress[] = [];
  for (const { course } of enrolled) {
    const tree = await getCourseTree({ id: course.id });
    if (!tree) continue;
    const all = flattenLessons(tree);
    const done = await getCompletedLessonIds(userId, all.map((l) => l.id));
    result.push({
      course,
      total: all.length,
      completed: all.filter((l) => done.has(l.id)).length,
      nextLesson: all.find((l) => !done.has(l.id)) ?? null,
    });
  }
  return result;
}

export async function getRecentActivity(userId: number, limit = 8) {
  return db.select().from(activityLog).where(eq(activityLog.userId, userId)).orderBy(desc(activityLog.createdAt)).limit(limit);
}

export async function getLeaderboard(limit = 5) {
  return db.select({ id: users.id, name: users.name, xp: users.xp, streak: users.streak }).from(users).orderBy(desc(users.xp)).limit(limit);
}

export async function getAdminStats() {
  const [[u], [c], [l], [lp], [e]] = await Promise.all([
    db.select({ v: count() }).from(users),
    db.select({ v: count() }).from(courses),
    db.select({ v: count() }).from(lessons),
    db.select({ v: count() }).from(lessonProgress),
    db.select({ v: count() }).from(enrollments),
  ]);
  return { users: u.v, courses: c.v, lessons: l.v, completions: lp.v, enrollments: e.v };
}

export async function listAllCourses() {
  return db.select({
    course: courses,
    lessonCount: sql<number>`(select count(*) from ${lessons} l join ${modules} m on l.module_id = m.id where m.course_id = ${courses}.id)`.mapWith(Number),
    enrolledCount: sql<number>`(select count(*) from ${enrollments} e where e.course_id = ${courses}.id)`.mapWith(Number),
  }).from(courses).orderBy(asc(courses.position), asc(courses.id));
}

export async function listUsers() {
  return db.select({
    id: users.id, email: users.email, name: users.name, role: users.role, plan: users.plan, xp: users.xp, streak: users.streak, createdAt: users.createdAt,
    completions: sql<number>`(select count(*) from ${lessonProgress} lp where lp.user_id = ${users}.id)`.mapWith(Number),
  }).from(users).orderBy(desc(users.createdAt));
}

export async function getLessonWithContext(lessonId: number) {
  const [row] = await db.select({ lesson: lessons, module: modules, course: courses }).from(lessons)
    .innerJoin(modules, eq(lessons.moduleId, modules.id))
    .innerJoin(courses, eq(modules.courseId, courses.id))
    .where(eq(lessons.id, lessonId)).limit(1);
  return row ?? null;
}

export async function getRecentAuditLog(limit = 20) {
  return db.select({ log: activityLog, userName: users.name }).from(activityLog)
    .leftJoin(users, eq(activityLog.userId, users.id))
    .orderBy(desc(activityLog.createdAt)).limit(limit);
}
