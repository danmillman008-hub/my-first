import "server-only";
import { count } from "drizzle-orm";
import { db } from "@/db";
import { courses, lessons, modules, steps, users, type StepContent } from "@/db/schema";
import { hashPassword } from "./auth";

type SeedLesson = { slug: string; title: string; description: string; xp: number; steps: StepContent[] };
type SeedModule = { title: string; lessons: SeedLesson[] };
type SeedCourse = {
  slug: string; title: string; tagline: string; description: string; category: string;
  level: string; icon: string; color: string; tags: string[]; isPremium: boolean; modules: SeedModule[];
};

const SEED: SeedCourse[] = [
  {
    slug: "python-fundamentals",
    title: "Python Fundamentals",
    tagline: "Learn Python from zero with bite-sized interactive lessons.",
    description: "Start your coding journey with Python. You'll learn variables, data types, control flow and functions through short lessons, quizzes and hands-on coding exercises.",
    category: "Programming", level: "beginner", icon: "🐍", color: "emerald",
    tags: ["python", "beginner", "coding"], isPremium: false,
    modules: [
      {
        title: "Getting Started",
        lessons: [
          {
            slug: "hello-python", title: "Hello, Python!", description: "Print your first message and understand how Python runs code.", xp: 20,
            steps: [
              { kind: "text", body: "## Welcome to Python\n\nPython is one of the most popular programming languages in the world. It's used for web apps, data science, automation and AI.\n\nThe simplest Python program prints text to the screen:\n\n```python\nprint(\"Hello, world!\")\n```\n\n`print()` is a **function** — it takes a value and displays it." },
              { kind: "quiz", question: "What does the `print()` function do?", options: ["Saves a file", "Displays a value on the screen", "Creates a variable", "Stops the program"], correctIndex: 1, explanation: "print() outputs whatever you pass to it." },
              { kind: "code", prompt: "Write a program that prints **Hello, Learnly!**", language: "python", starterCode: "# Print the message below\n", solution: "print(\"Hello, Learnly!\")", checks: ["print(", "Hello, Learnly!"], hint: "Use print() with the text inside quotes." },
              { kind: "fill", prompt: "Complete the code so it prints the number 42.", template: "___(42)", answer: "print", hint: "Which function displays output?" },
            ],
          },
          {
            slug: "variables", title: "Variables", description: "Store and reuse values with variables.", xp: 25,
            steps: [
              { kind: "text", body: "## Variables\n\nA variable is a named container for a value.\n\n```python\nname = \"Ada\"\nage = 36\n```\n\nYou create one with `=`. The name goes on the left, the value on the right. Python figures out the type automatically." },
              { kind: "fill", prompt: "Create a variable called `city` that holds the text \"Paris\".", template: "city ___ \"Paris\"", answer: "=", hint: "The assignment operator." },
              { kind: "quiz", question: "Which of these is a valid variable name?", options: ["2fast", "my-var", "user_name", "class"], correctIndex: 2, explanation: "Names can't start with digits, contain dashes, or be keywords like `class`." },
              { kind: "code", prompt: "Create a variable `score` with the value `100`, then print it.", language: "python", starterCode: "# your code here\n", solution: "score = 100\nprint(score)", checks: ["score = 100", "print(score)"] },
            ],
          },
          {
            slug: "data-types", title: "Data Types", description: "Strings, integers, floats and booleans.", xp: 25,
            steps: [
              { kind: "text", body: "## Basic data types\n\n| Type | Example |\n|---|---|\n| `str` | `\"hello\"` |\n| `int` | `42` |\n| `float` | `3.14` |\n| `bool` | `True` / `False` |\n\nUse `type(value)` to check a value's type." },
              { kind: "quiz", question: "What is the type of `3.0`?", options: ["int", "float", "str", "bool"], correctIndex: 1 },
              { kind: "quiz", question: "Which value is a boolean?", options: ["\"True\"", "1", "True", "true"], correctIndex: 2, explanation: "Python booleans are capitalized: True and False." },
              { kind: "fill", prompt: "Convert the string \"7\" to an integer.", template: "number = ___(\"7\")", answer: "int" },
            ],
          },
        ],
      },
      {
        title: "Control Flow",
        lessons: [
          {
            slug: "if-statements", title: "If Statements", description: "Make decisions in your code.", xp: 30,
            steps: [
              { kind: "text", body: "## Making decisions\n\n```python\ntemperature = 30\nif temperature > 25:\n    print(\"It's hot!\")\nelse:\n    print(\"It's fine.\")\n```\n\nIndentation matters in Python — the indented block runs only when the condition is `True`." },
              { kind: "fill", prompt: "Complete the condition so the message prints when `age` is at least 18.", template: "if age ___ 18:\n    print(\"Adult\")", answer: ">=" },
              { kind: "code", prompt: "Write an `if` statement that prints \"Even\" when `n` is even. Use the modulo operator `%`.", language: "python", starterCode: "n = 8\n# your code here\n", solution: "n = 8\nif n % 2 == 0:\n    print(\"Even\")", checks: ["if n % 2 == 0", "print(\"Even\")"], hint: "n % 2 gives the remainder of n divided by 2." },
            ],
          },
          {
            slug: "loops", title: "Loops", description: "Repeat actions with for and while loops.", xp: 30,
            steps: [
              { kind: "text", body: "## for loops\n\n```python\nfor i in range(3):\n    print(i)\n```\n\nThis prints `0`, `1`, `2`. `range(n)` produces numbers from 0 up to (but not including) n." },
              { kind: "quiz", question: "How many times does `for i in range(5)` run?", options: ["4", "5", "6", "Infinite"], correctIndex: 1 },
              { kind: "code", prompt: "Print every item in the `fruits` list using a for loop.", language: "python", starterCode: "fruits = [\"apple\", \"banana\", \"cherry\"]\n", solution: "fruits = [\"apple\", \"banana\", \"cherry\"]\nfor fruit in fruits:\n    print(fruit)", checks: ["for ", " in fruits", "print("] },
            ],
          },
        ],
      },
    ],
  },
  {
    slug: "sql-for-data-analysis",
    title: "SQL for Data Analysis",
    tagline: "Query real datasets with SELECT, WHERE, GROUP BY and JOINs.",
    description: "Learn to ask questions of data with SQL. This course walks you through querying, filtering, aggregating and joining tables — the daily bread of every data analyst.",
    category: "Data", level: "beginner", icon: "🗄️", color: "sky",
    tags: ["sql", "data", "analytics"], isPremium: false,
    modules: [
      {
        title: "Querying Data",
        lessons: [
          {
            slug: "select-basics", title: "SELECT Basics", description: "Retrieve columns from a table.", xp: 20,
            steps: [
              { kind: "text", body: "## Your first query\n\n```sql\nSELECT name, price FROM products;\n```\n\n`SELECT` picks the columns, `FROM` picks the table. Use `*` to select every column." },
              { kind: "fill", prompt: "Select all columns from the `customers` table.", template: "SELECT ___ FROM customers;", answer: "*" },
              { kind: "code", prompt: "Write a query that returns the `title` and `year` columns from the `films` table.", language: "sql", starterCode: "-- your query\n", solution: "SELECT title, year FROM films;", checks: ["SELECT", "title", "year", "FROM films"] },
            ],
          },
          {
            slug: "filtering-where", title: "Filtering with WHERE", description: "Return only rows that match a condition.", xp: 25,
            steps: [
              { kind: "text", body: "## WHERE\n\n```sql\nSELECT * FROM films WHERE year > 2000;\n```\n\nCombine conditions with `AND` / `OR`. Text values use single quotes: `'Drama'`." },
              { kind: "quiz", question: "Which query returns films released in 1999?", options: ["SELECT * FROM films WHERE year = 1999;", "SELECT * FROM films year = 1999;", "SELECT * WHERE year = 1999 FROM films;", "SELECT films WHERE year == 1999;"], correctIndex: 0 },
              { kind: "code", prompt: "Return all films with `genre` equal to 'Comedy' and `year` after 2010.", language: "sql", starterCode: "SELECT * FROM films\n", solution: "SELECT * FROM films\nWHERE genre = 'Comedy' AND year > 2010;", checks: ["WHERE", "genre = 'Comedy'", "AND", "year > 2010"] },
            ],
          },
        ],
      },
      {
        title: "Aggregating & Joining",
        lessons: [
          {
            slug: "group-by", title: "GROUP BY & Aggregates", description: "Count, sum and average across groups.", xp: 30,
            steps: [
              { kind: "text", body: "## Aggregates\n\n```sql\nSELECT genre, COUNT(*) AS total\nFROM films\nGROUP BY genre;\n```\n\nCommon aggregate functions: `COUNT`, `SUM`, `AVG`, `MIN`, `MAX`." },
              { kind: "fill", prompt: "Compute the average `budget` of all films.", template: "SELECT ___(budget) FROM films;", answer: "AVG" },
              { kind: "code", prompt: "Count the number of films per `year`, aliasing the count as `n`.", language: "sql", starterCode: "", solution: "SELECT year, COUNT(*) AS n FROM films GROUP BY year;", checks: ["COUNT(*)", "AS n", "GROUP BY year"] },
            ],
          },
          {
            slug: "joins", title: "JOINs", description: "Combine rows from multiple tables.", xp: 35,
            steps: [
              { kind: "text", body: "## INNER JOIN\n\n```sql\nSELECT f.title, d.name\nFROM films f\nINNER JOIN directors d ON f.director_id = d.id;\n```\n\nA JOIN links rows where the `ON` condition matches." },
              { kind: "quiz", question: "Which JOIN keeps all rows from the left table even without a match?", options: ["INNER JOIN", "LEFT JOIN", "CROSS JOIN", "SELF JOIN"], correctIndex: 1 },
              { kind: "code", prompt: "Join `orders` to `customers` on `orders.customer_id = customers.id`, selecting `customers.name` and `orders.total`.", language: "sql", starterCode: "SELECT customers.name, orders.total\n", solution: "SELECT customers.name, orders.total\nFROM orders\nJOIN customers ON orders.customer_id = customers.id;", checks: ["FROM orders", "JOIN customers", "ON orders.customer_id = customers.id"] },
            ],
          },
        ],
      },
    ],
  },
  {
    slug: "javascript-essentials",
    title: "JavaScript Essentials",
    tagline: "The language of the web — functions, arrays and the DOM.",
    description: "Master the core of modern JavaScript: variables, functions, arrays, objects and how to make web pages interactive.",
    category: "Web Development", level: "intermediate", icon: "⚡", color: "amber",
    tags: ["javascript", "web", "frontend"], isPremium: true,
    modules: [
      {
        title: "Language Basics",
        lessons: [
          {
            slug: "let-const", title: "let & const", description: "Modern variable declarations.", xp: 20,
            steps: [
              { kind: "text", body: "## let and const\n\n```js\nconst pi = 3.14;   // cannot be reassigned\nlet count = 0;     // can change\ncount = count + 1;\n```\n\nPrefer `const` by default and use `let` only when the value must change." },
              { kind: "quiz", question: "Which declaration prevents reassignment?", options: ["var", "let", "const", "static"], correctIndex: 2 },
              { kind: "fill", prompt: "Declare a constant named `API_URL`.", template: "___ API_URL = \"https://api.example.com\";", answer: "const" },
            ],
          },
          {
            slug: "arrow-functions", title: "Arrow Functions", description: "Concise function syntax.", xp: 25,
            steps: [
              { kind: "text", body: "## Arrow functions\n\n```js\nconst double = (n) => n * 2;\ndouble(4); // 8\n```\n\nSingle-expression arrows return implicitly." },
              { kind: "code", prompt: "Write an arrow function `square` that returns the square of its argument.", language: "javascript", starterCode: "const square = ", solution: "const square = (n) => n * n;", checks: ["const square", "=>", "*"] },
              { kind: "quiz", question: "What does `[1,2,3].map(x => x + 1)` return?", options: ["[1,2,3]", "[2,3,4]", "6", "undefined"], correctIndex: 1 },
            ],
          },
        ],
      },
    ],
  },
];

let seeded: Promise<void> | null = null;

/** Idempotent demo-data seeding. Never throws so static prerendering can't fail on it. */
export function ensureSeeded(): Promise<void> {
  if (!seeded) {
    seeded = runSeed().catch((err) => {
      seeded = null;
      console.warn("[seed] skipped:", err instanceof Error ? err.message : err);
    });
  }
  return seeded;
}

async function runSeed() {
  const [{ value: userCount }] = await db.select({ value: count() }).from(users);
  if (userCount === 0) {
    await db.insert(users).values([
      { email: "admin@learnly.dev", passwordHash: hashPassword("admin123"), name: "Admin", role: "admin", plan: "pro" },
      { email: "learner@learnly.dev", passwordHash: hashPassword("learner123"), name: "Sam Learner", role: "learner" },
    ]);
  }

  const [{ value: courseCount }] = await db.select({ value: count() }).from(courses);
  if (courseCount > 0) return;

  for (const [ci, c] of SEED.entries()) {
    const [course] = await db.insert(courses).values({
      slug: c.slug, title: c.title, tagline: c.tagline, description: c.description, category: c.category,
      level: c.level, icon: c.icon, color: c.color, tags: c.tags, isPremium: c.isPremium, status: "published", position: ci,
    }).returning();
    for (const [mi, m] of c.modules.entries()) {
      const [mod] = await db.insert(modules).values({ courseId: course.id, title: m.title, position: mi }).returning();
      for (const [li, l] of m.lessons.entries()) {
        const [lesson] = await db.insert(lessons).values({
          moduleId: mod.id, slug: l.slug, title: l.title, description: l.description, xpReward: l.xp, position: li,
        }).returning();
        await db.insert(steps).values(l.steps.map((s, si) => ({ lessonId: lesson.id, type: s.kind, content: s, position: si })));
      }
    }
  }
}
