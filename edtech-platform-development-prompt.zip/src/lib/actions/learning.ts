"use server";

import { and, eq, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { activityLog, courses, enrollments, lessonProgress, lessons, stepProgress, steps, users } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { flattenLessons, getCourseTree } from "@/lib/queries";

export async function enrollAction(formData: FormData) {
  const courseId = Number(formData.get("courseId"));
  const slug = String(formData.get("slug") ?? "");
  const user = await requireUser(`/courses/${slug}`);

  const [course] = await db.select().from(courses).where(eq(courses.id, courseId)).limit(1);
  if (!course || course.status !== "published") return;

  await db.insert(enrollments).values({ userId: user.id, courseId }).onConflictDoNothing();
  await db.insert(activityLog).values({ userId: user.id, action: "course.enrolled", meta: { courseId, title: course.title } });

  const tree = await getCourseTree({ id: courseId });
  const first = tree ? flattenLessons(tree)[0] : null;
  revalidatePath(`/courses/${slug}`);
  revalidatePath("/dashboard");
  redirect(first ? `/learn/${slug}/${first.slug}` : `/courses/${slug}`);
}

/** Records a single step as completed (idempotent). */
export async function submitStepAction(stepId: number, correct: boolean, attempts: number) {
  const user = await requireUser();
  const [step] = await db.select().from(steps).where(eq(steps.id, stepId)).limit(1);
  if (!step) return { ok: false as const };

  await db
    .insert(stepProgress)
    .values({ userId: user.id, stepId, correct, attempts: Math.max(1, attempts) })
    .onConflictDoNothing();
  return { ok: true as const };
}

function todayKey(d = new Date()) {
  return d.toISOString().slice(0, 10);
}

/** Marks lesson complete, awards XP, updates streak. Returns navigation info. */
export async function completeLessonAction(lessonId: number, score: number) {
  const user = await requireUser();
  const [lesson] = await db.select().from(lessons).where(eq(lessons.id, lessonId)).limit(1);
  if (!lesson) return { ok: false as const, xpAwarded: 0, streak: user.streak, alreadyDone: false };

  const inserted = await db
    .insert(lessonProgress)
    .values({ userId: user.id, lessonId, score })
    .onConflictDoNothing()
    .returning();

  const alreadyDone = inserted.length === 0;
  let xpAwarded = 0;
  let streak = user.streak;

  if (!alreadyDone) {
    xpAwarded = lesson.xpReward;
    const today = todayKey();
    const yesterday = todayKey(new Date(Date.now() - 86_400_000));
    if (user.lastActiveDate === today) streak = user.streak;
    else if (user.lastActiveDate === yesterday) streak = user.streak + 1;
    else streak = 1;

    await db.update(users).set({ xp: sql`${users.xp} + ${xpAwarded}`, streak, lastActiveDate: today }).where(eq(users.id, user.id));
    await db.insert(activityLog).values({ userId: user.id, action: "lesson.completed", meta: { lessonId, title: lesson.title, xp: xpAwarded, score } });
  }

  revalidatePath("/dashboard");
  revalidatePath("/profile");
  return { ok: true as const, xpAwarded, streak, alreadyDone };
}

/** Resets progress for a lesson so it can be retried. */
export async function resetLessonAction(lessonId: number) {
  const user = await requireUser();
  const stepIds = await db.select({ id: steps.id }).from(steps).where(eq(steps.lessonId, lessonId));
  for (const s of stepIds) {
    await db.delete(stepProgress).where(and(eq(stepProgress.userId, user.id), eq(stepProgress.stepId, s.id)));
  }
  return { ok: true as const };
}

export async function upgradePlanAction() {
  const user = await requireUser("/profile");
  // Payment integration point: swap this for a Stripe Checkout session in production.
  await db.update(users).set({ plan: user.plan === "pro" ? "free" : "pro" }).where(eq(users.id, user.id));
  await db.insert(activityLog).values({ userId: user.id, action: "plan.changed", meta: { to: user.plan === "pro" ? "free" : "pro" } });
  revalidatePath("/profile");
}
