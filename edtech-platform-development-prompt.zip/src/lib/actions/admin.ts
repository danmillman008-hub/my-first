"use server";

import { eq, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { activityLog, courses, lessons, modules, steps, users, type StepContent } from "@/db/schema";
import { requireStaff } from "@/lib/auth";

export type ActionState = { error?: string; success?: string } | undefined;

function slugify(s: string) {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 120) || `item-${Date.now()}`;
}
function str(fd: FormData, key: string) {
  return String(fd.get(key) ?? "").trim();
}
async function audit(userId: number, action: string, meta: Record<string, unknown>) {
  await db.insert(activityLog).values({ userId, action, meta });
}
function revalidateContent() {
  revalidatePath("/", "layout");
}

// ---------- Courses ----------
export async function createCourseAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const admin = await requireStaff();
  const title = str(fd, "title");
  if (title.length < 3) return { error: "Title must be at least 3 characters." };
  const slug = str(fd, "slug") ? slugify(str(fd, "slug")) : slugify(title);
  const [exists] = await db.select({ id: courses.id }).from(courses).where(eq(courses.slug, slug)).limit(1);
  if (exists) return { error: `Slug "${slug}" is already used.` };

  const [course] = await db.insert(courses).values({
    title, slug,
    tagline: str(fd, "tagline"), description: str(fd, "description"),
    category: str(fd, "category") || "Programming", level: str(fd, "level") || "beginner",
    icon: str(fd, "icon") || "📘", color: str(fd, "color") || "indigo",
    tags: str(fd, "tags").split(",").map((t) => t.trim()).filter(Boolean),
    isPremium: fd.get("isPremium") === "on",
    position: Number(fd.get("position") || 0),
  }).returning();
  await audit(admin.id, "course.created", { courseId: course.id, title });
  revalidateContent();
  redirect(`/admin/courses/${course.id}`);
}

export async function updateCourseAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const admin = await requireStaff();
  const id = Number(fd.get("id"));
  const title = str(fd, "title");
  if (!id || title.length < 3) return { error: "Title must be at least 3 characters." };
  const slug = slugify(str(fd, "slug") || title);
  const [conflict] = await db.select({ id: courses.id }).from(courses).where(eq(courses.slug, slug)).limit(1);
  if (conflict && conflict.id !== id) return { error: `Slug "${slug}" is already used.` };

  await db.update(courses).set({
    title, slug,
    tagline: str(fd, "tagline"), description: str(fd, "description"),
    category: str(fd, "category") || "Programming", level: str(fd, "level") || "beginner",
    icon: str(fd, "icon") || "📘", color: str(fd, "color") || "indigo",
    tags: str(fd, "tags").split(",").map((t) => t.trim()).filter(Boolean),
    isPremium: fd.get("isPremium") === "on",
    position: Number(fd.get("position") || 0),
    updatedAt: new Date(),
  }).where(eq(courses.id, id));
  await audit(admin.id, "course.updated", { courseId: id, title });
  revalidateContent();
  return { success: "Course saved." };
}

export async function setCourseStatusAction(fd: FormData) {
  const admin = await requireStaff();
  const id = Number(fd.get("id"));
  const status = str(fd, "status");
  if (!["draft", "published", "archived"].includes(status)) return;
  await db.update(courses).set({ status, updatedAt: new Date() }).where(eq(courses.id, id));
  await audit(admin.id, `course.${status}`, { courseId: id });
  revalidateContent();
}

export async function deleteCourseAction(fd: FormData) {
  const admin = await requireStaff();
  const id = Number(fd.get("id"));
  await db.delete(courses).where(eq(courses.id, id));
  await audit(admin.id, "course.deleted", { courseId: id });
  revalidateContent();
  redirect("/admin/courses");
}

// ---------- Modules ----------
export async function createModuleAction(fd: FormData) {
  await requireStaff();
  const courseId = Number(fd.get("courseId"));
  const title = str(fd, "title");
  if (!courseId || !title) return;
  const [{ max }] = await db.select({ max: sql<number>`coalesce(max(${modules.position}), -1)`.mapWith(Number) }).from(modules).where(eq(modules.courseId, courseId));
  await db.insert(modules).values({ courseId, title, position: max + 1 });
  revalidateContent();
}

export async function renameModuleAction(fd: FormData) {
  await requireStaff();
  const id = Number(fd.get("id"));
  const title = str(fd, "title");
  if (!id || !title) return;
  await db.update(modules).set({ title }).where(eq(modules.id, id));
  revalidateContent();
}

export async function deleteModuleAction(fd: FormData) {
  await requireStaff();
  await db.delete(modules).where(eq(modules.id, Number(fd.get("id"))));
  revalidateContent();
}

export async function moveModuleAction(fd: FormData) {
  await requireStaff();
  const id = Number(fd.get("id"));
  const dir = str(fd, "dir") === "up" ? -1 : 1;
  const [mod] = await db.select().from(modules).where(eq(modules.id, id)).limit(1);
  if (!mod) return;
  const siblings = await db.select().from(modules).where(eq(modules.courseId, mod.courseId)).orderBy(modules.position, modules.id);
  const idx = siblings.findIndex((m) => m.id === id);
  const swap = siblings[idx + dir];
  if (!swap) return;
  await db.update(modules).set({ position: idx + dir }).where(eq(modules.id, mod.id));
  await db.update(modules).set({ position: idx }).where(eq(modules.id, swap.id));
  // Normalise remaining positions
  for (const [i, m] of siblings.entries()) {
    if (m.id !== mod.id && m.id !== swap.id) await db.update(modules).set({ position: i }).where(eq(modules.id, m.id));
  }
  revalidateContent();
}

// ---------- Lessons ----------
export async function createLessonAction(fd: FormData) {
  const admin = await requireStaff();
  const moduleId = Number(fd.get("moduleId"));
  const title = str(fd, "title");
  if (!moduleId || !title) return;
  const [{ max }] = await db.select({ max: sql<number>`coalesce(max(${lessons.position}), -1)`.mapWith(Number) }).from(lessons).where(eq(lessons.moduleId, moduleId));
  const [lesson] = await db.insert(lessons).values({
    moduleId, title, slug: `${slugify(title)}-${Date.now().toString(36)}`, position: max + 1, status: "draft",
    xpReward: Number(fd.get("xpReward") || 20),
  }).returning();
  await audit(admin.id, "lesson.created", { lessonId: lesson.id, title });
  revalidateContent();
  redirect(`/admin/lessons/${lesson.id}`);
}

export async function updateLessonAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const admin = await requireStaff();
  const id = Number(fd.get("id"));
  const title = str(fd, "title");
  if (!id || title.length < 2) return { error: "Title is required." };
  await db.update(lessons).set({
    title, slug: slugify(str(fd, "slug") || title), description: str(fd, "description"),
    xpReward: Math.max(0, Number(fd.get("xpReward") || 0)),
    status: str(fd, "status") === "published" ? "published" : "draft",
  }).where(eq(lessons.id, id));
  await audit(admin.id, "lesson.updated", { lessonId: id, title });
  revalidateContent();
  return { success: "Lesson saved." };
}

export async function deleteLessonAction(fd: FormData) {
  const admin = await requireStaff();
  const id = Number(fd.get("id"));
  const courseId = Number(fd.get("courseId"));
  await db.delete(lessons).where(eq(lessons.id, id));
  await audit(admin.id, "lesson.deleted", { lessonId: id });
  revalidateContent();
  if (courseId) redirect(`/admin/courses/${courseId}`);
}

export async function moveLessonAction(fd: FormData) {
  await requireStaff();
  const id = Number(fd.get("id"));
  const dir = str(fd, "dir") === "up" ? -1 : 1;
  const [lesson] = await db.select().from(lessons).where(eq(lessons.id, id)).limit(1);
  if (!lesson) return;
  const siblings = await db.select().from(lessons).where(eq(lessons.moduleId, lesson.moduleId)).orderBy(lessons.position, lessons.id);
  const idx = siblings.findIndex((l) => l.id === id);
  if (!siblings[idx + dir]) return;
  const reordered = [...siblings];
  [reordered[idx], reordered[idx + dir]] = [reordered[idx + dir], reordered[idx]];
  for (const [i, l] of reordered.entries()) await db.update(lessons).set({ position: i }).where(eq(lessons.id, l.id));
  revalidateContent();
}

// ---------- Steps ----------
function parseStepContent(fd: FormData): { content: StepContent } | { error: string } {
  const kind = str(fd, "kind");
  switch (kind) {
    case "text": {
      const body = str(fd, "body");
      if (!body) return { error: "Body is required." };
      return { content: { kind, body } };
    }
    case "quiz": {
      const question = str(fd, "question");
      const options = [0, 1, 2, 3].map((i) => str(fd, `option${i}`)).filter(Boolean);
      const correctIndex = Number(fd.get("correctIndex") ?? 0);
      if (!question || options.length < 2) return { error: "Quiz needs a question and at least 2 options." };
      if (correctIndex < 0 || correctIndex >= options.length) return { error: "Correct answer index is out of range." };
      return { content: { kind, question, options, correctIndex, explanation: str(fd, "explanation") || undefined } };
    }
    case "code": {
      const prompt = str(fd, "prompt");
      const checks = str(fd, "checks").split("\n").map((c) => c.trim()).filter(Boolean);
      if (!prompt || !checks.length) return { error: "Code exercise needs a prompt and at least one check string." };
      return {
        content: {
          kind, prompt, language: str(fd, "language") || "python",
          starterCode: String(fd.get("starterCode") ?? ""), solution: String(fd.get("solution") ?? ""), checks,
          hint: str(fd, "hint") || undefined,
        },
      };
    }
    case "fill": {
      const prompt = str(fd, "prompt");
      const template = String(fd.get("template") ?? "");
      const answer = str(fd, "answer");
      if (!prompt || !template.includes("___") || !answer) return { error: "Fill-in needs a prompt, a template containing ___ and an answer." };
      return { content: { kind, prompt, template, answer, hint: str(fd, "hint") || undefined } };
    }
    default:
      return { error: "Unknown step type." };
  }
}

export async function saveStepAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const admin = await requireStaff();
  const lessonId = Number(fd.get("lessonId"));
  const stepId = Number(fd.get("stepId") || 0);
  const parsed = parseStepContent(fd);
  if ("error" in parsed) return { error: parsed.error };

  if (stepId) {
    await db.update(steps).set({ type: parsed.content.kind, content: parsed.content }).where(eq(steps.id, stepId));
  } else {
    const [{ max }] = await db.select({ max: sql<number>`coalesce(max(${steps.position}), -1)`.mapWith(Number) }).from(steps).where(eq(steps.lessonId, lessonId));
    await db.insert(steps).values({ lessonId, type: parsed.content.kind, content: parsed.content, position: max + 1 });
  }
  await audit(admin.id, stepId ? "step.updated" : "step.created", { lessonId, stepId });
  revalidateContent();
  return { success: stepId ? "Step updated." : "Step added." };
}

export async function deleteStepAction(fd: FormData) {
  await requireStaff();
  await db.delete(steps).where(eq(steps.id, Number(fd.get("id"))));
  revalidateContent();
}

export async function moveStepAction(fd: FormData) {
  await requireStaff();
  const id = Number(fd.get("id"));
  const dir = str(fd, "dir") === "up" ? -1 : 1;
  const [step] = await db.select().from(steps).where(eq(steps.id, id)).limit(1);
  if (!step) return;
  const siblings = await db.select().from(steps).where(eq(steps.lessonId, step.lessonId)).orderBy(steps.position, steps.id);
  const idx = siblings.findIndex((s) => s.id === id);
  if (!siblings[idx + dir]) return;
  const reordered = [...siblings];
  [reordered[idx], reordered[idx + dir]] = [reordered[idx + dir], reordered[idx]];
  for (const [i, s] of reordered.entries()) await db.update(steps).set({ position: i }).where(eq(steps.id, s.id));
  revalidateContent();
}

// ---------- Users ----------
export async function setUserRoleAction(fd: FormData) {
  const admin = await requireStaff();
  if (admin.role !== "admin") return;
  const id = Number(fd.get("id"));
  const role = str(fd, "role");
  if (!["learner", "instructor", "admin"].includes(role) || id === admin.id) return;
  await db.update(users).set({ role }).where(eq(users.id, id));
  await audit(admin.id, "user.role_changed", { targetUserId: id, role });
  revalidatePath("/admin/users");
}

export async function setUserPlanAction(fd: FormData) {
  const admin = await requireStaff();
  if (admin.role !== "admin") return;
  const id = Number(fd.get("id"));
  const plan = str(fd, "plan");
  if (!["free", "pro"].includes(plan)) return;
  await db.update(users).set({ plan }).where(eq(users.id, id));
  await audit(admin.id, "user.plan_changed", { targetUserId: id, plan });
  revalidatePath("/admin/users");
}
