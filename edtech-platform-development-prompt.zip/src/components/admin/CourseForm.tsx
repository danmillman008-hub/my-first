"use client";

import { useActionState } from "react";
import type { Course } from "@/db/schema";
import { createCourseAction, updateCourseAction, type ActionState } from "@/lib/actions/admin";
import { btnPrimary, colorOptions, inputCls } from "@/components/ui";

const CATEGORIES = ["Programming", "Data", "Web Development", "AI & ML", "DevOps", "Design", "Business"];

export function CourseForm({ course }: { course?: Course }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(course ? updateCourseAction : createCourseAction, undefined);

  return (
    <form action={action} className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6">
      {course && <input type="hidden" name="id" value={course.id} />}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Title"><input name="title" required defaultValue={course?.title} className={inputCls} placeholder="Python Fundamentals" /></Field>
        <Field label="Slug (URL)"><input name="slug" defaultValue={course?.slug} className={inputCls} placeholder="auto-generated from title" /></Field>
      </div>
      <Field label="Tagline"><input name="tagline" defaultValue={course?.tagline} className={inputCls} placeholder="One sentence shown on cards" /></Field>
      <Field label="Description"><textarea name="description" rows={4} defaultValue={course?.description} className={inputCls} /></Field>
      <div className="grid gap-4 sm:grid-cols-4">
        <Field label="Category">
          <select name="category" defaultValue={course?.category ?? "Programming"} className={inputCls}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
        </Field>
        <Field label="Level">
          <select name="level" defaultValue={course?.level ?? "beginner"} className={inputCls}>{["beginner", "intermediate", "advanced"].map((l) => <option key={l}>{l}</option>)}</select>
        </Field>
        <Field label="Icon (emoji)"><input name="icon" defaultValue={course?.icon ?? "📘"} className={inputCls} maxLength={4} /></Field>
        <Field label="Color">
          <select name="color" defaultValue={course?.color ?? "indigo"} className={inputCls}>{colorOptions.map((c) => <option key={c}>{c}</option>)}</select>
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-[1fr_120px_auto]">
        <Field label="Tags (comma separated)"><input name="tags" defaultValue={course?.tags.join(", ")} className={inputCls} placeholder="python, beginner" /></Field>
        <Field label="Sort order"><input name="position" type="number" defaultValue={course?.position ?? 0} className={inputCls} /></Field>
        <label className="flex items-center gap-2 self-end pb-2 text-sm font-medium"><input type="checkbox" name="isPremium" defaultChecked={course?.isPremium} className="h-4 w-4 rounded" /> PRO only</label>
      </div>

      {state?.error && <p className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">{state.error}</p>}
      {state?.success && <p className="rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{state.success}</p>}

      <button disabled={pending} className={btnPrimary}>{pending ? "Saving…" : course ? "Save changes" : "Create course"}</button>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block text-sm font-medium text-slate-700">{label}<div className="mt-1">{children}</div></label>;
}
