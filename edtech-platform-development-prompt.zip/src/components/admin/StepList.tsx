"use client";

import { useState } from "react";
import type { Step, StepContent } from "@/db/schema";
import { deleteStepAction, moveStepAction } from "@/lib/actions/admin";
import { StepEditor } from "./StepEditor";
import { Badge, btnGhost, btnSecondary } from "@/components/ui";

function summary(c: StepContent) {
  switch (c.kind) {
    case "text": return c.body.replace(/[#`*]/g, "").split("\n").find((l) => l.trim()) ?? "";
    case "quiz": return c.question;
    case "fill": return c.prompt;
    case "code": return c.prompt;
  }
}
const KIND_LABEL: Record<StepContent["kind"], string> = { text: "📖 Text", quiz: "❓ Quiz", fill: "✏️ Fill", code: "💻 Code" };

export function StepList({ lessonId, steps }: { lessonId: number; steps: Step[] }) {
  const [editing, setEditing] = useState<number | null>(null);
  const [adding, setAdding] = useState(steps.length === 0);

  return (
    <div className="space-y-3">
      {steps.map((s, i) => {
        const c = s.content as StepContent;
        return (
          <div key={s.id} className="rounded-2xl border border-slate-200 bg-white">
            <div className="flex items-center gap-3 px-4 py-3">
              <span className="w-6 text-xs font-bold text-slate-400">{i + 1}</span>
              <Badge tone="indigo">{KIND_LABEL[c.kind]}</Badge>
              <p className="min-w-0 flex-1 truncate text-sm text-slate-700">{summary(c)}</p>
              <form action={moveStepAction}><input type="hidden" name="id" value={s.id} /><input type="hidden" name="dir" value="up" /><button className={btnGhost} disabled={i === 0}>↑</button></form>
              <form action={moveStepAction}><input type="hidden" name="id" value={s.id} /><input type="hidden" name="dir" value="down" /><button className={btnGhost} disabled={i === steps.length - 1}>↓</button></form>
              <button onClick={() => setEditing(editing === s.id ? null : s.id)} className={btnGhost}>{editing === s.id ? "Close" : "Edit"}</button>
              <form action={deleteStepAction} onSubmit={(e) => { if (!confirm("Delete this step?")) e.preventDefault(); }}>
                <input type="hidden" name="id" value={s.id} /><button className={`${btnGhost} text-rose-600`}>Delete</button>
              </form>
            </div>
            {editing === s.id && <div className="border-t border-slate-100 p-3"><StepEditor key={s.id} lessonId={lessonId} step={s} onDone={() => setEditing(null)} /></div>}
          </div>
        );
      })}

      {adding ? (
        <StepEditor lessonId={lessonId} onDone={() => setAdding(false)} />
      ) : (
        <button onClick={() => setAdding(true)} className={`${btnSecondary} w-full border-dashed py-3`}>+ Add step</button>
      )}
    </div>
  );
}
