"use client";

import { useActionState } from "react";
import type { Lesson } from "@/db/schema";
import { updateLessonAction, type ActionState } from "@/lib/actions/admin";
import { btnPrimary, inputCls } from "@/components/ui";

export function LessonForm({ lesson }: { lesson: Lesson }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(updateLessonAction, undefined);
  return (
    <form action={action} className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5">
      <input type="hidden" name="id" value={lesson.id} />
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block text-sm font-medium">Title<input name="title" required defaultValue={lesson.title} className={`${inputCls} mt-1`} /></label>
        <label className="block text-sm font-medium">Slug<input name="slug" defaultValue={lesson.slug} className={`${inputCls} mt-1`} /></label>
      </div>
      <label className="block text-sm font-medium">Description<input name="description" defaultValue={lesson.description} className={`${inputCls} mt-1`} /></label>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block text-sm font-medium">XP reward<input name="xpReward" type="number" min={0} defaultValue={lesson.xpReward} className={`${inputCls} mt-1`} /></label>
        <label className="block text-sm font-medium">Status
          <select name="status" defaultValue={lesson.status} className={`${inputCls} mt-1`}><option value="draft">draft (hidden from learners)</option><option value="published">published</option></select>
        </label>
      </div>
      {state?.error && <p className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">{state.error}</p>}
      {state?.success && <p className="rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{state.success}</p>}
      <button disabled={pending} className={btnPrimary}>{pending ? "Saving…" : "Save lesson"}</button>
    </form>
  );
}
