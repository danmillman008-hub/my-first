"use client";

import { useActionState, useState } from "react";
import type { Step, StepContent } from "@/db/schema";
import { saveStepAction, type ActionState } from "@/lib/actions/admin";
import { btnPrimary, btnSecondary, inputCls } from "@/components/ui";

type Kind = StepContent["kind"];
const KINDS: { value: Kind; label: string; desc: string }[] = [
  { value: "text", label: "📖 Text", desc: "Markdown explanation" },
  { value: "quiz", label: "❓ Quiz", desc: "Multiple choice" },
  { value: "fill", label: "✏️ Fill-in", desc: "Complete the blank" },
  { value: "code", label: "💻 Code", desc: "Coding exercise" },
];

export function StepEditor({ lessonId, step, onDone }: { lessonId: number; step?: Step; onDone?: () => void }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(saveStepAction, undefined);
  const initial = step?.content as StepContent | undefined;
  const [kind, setKind] = useState<Kind>(initial?.kind ?? "text");
  const mono = `${inputCls} font-mono`;

  return (
    <form action={action} className="space-y-4 rounded-2xl border border-indigo-200 bg-indigo-50/40 p-5">
      <input type="hidden" name="lessonId" value={lessonId} />
      {step && <input type="hidden" name="stepId" value={step.id} />}
      <input type="hidden" name="kind" value={kind} />

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {KINDS.map((k) => (
          <button type="button" key={k.value} onClick={() => setKind(k.value)} className={`rounded-xl border p-3 text-left text-sm ${kind === k.value ? "border-indigo-500 bg-white ring-2 ring-indigo-200" : "border-slate-200 bg-white hover:border-slate-400"}`}>
            <div className="font-semibold">{k.label}</div><div className="text-xs text-slate-500">{k.desc}</div>
          </button>
        ))}
      </div>

      {kind === "text" && (
        <L label="Body (Markdown: ## headings, **bold**, `code`, ```lang fences, | tables |, - lists)">
          <textarea name="body" rows={10} required defaultValue={initial?.kind === "text" ? initial.body : ""} className={mono} />
        </L>
      )}

      {kind === "quiz" && (
        <>
          <L label="Question"><input name="question" required defaultValue={initial?.kind === "quiz" ? initial.question : ""} className={inputCls} /></L>
          <div className="grid gap-2 sm:grid-cols-2">
            {[0, 1, 2, 3].map((i) => (
              <L key={i} label={`Option ${String.fromCharCode(65 + i)}${i < 2 ? "" : " (optional)"}`}>
                <input name={`option${i}`} required={i < 2} defaultValue={initial?.kind === "quiz" ? initial.options[i] ?? "" : ""} className={mono} />
              </L>
            ))}
          </div>
          <div className="grid gap-2 sm:grid-cols-[160px_1fr]">
            <L label="Correct option">
              <select name="correctIndex" defaultValue={initial?.kind === "quiz" ? initial.correctIndex : 0} className={inputCls}>
                {[0, 1, 2, 3].map((i) => <option key={i} value={i}>{String.fromCharCode(65 + i)}</option>)}
              </select>
            </L>
            <L label="Explanation (shown after answering)"><input name="explanation" defaultValue={initial?.kind === "quiz" ? initial.explanation ?? "" : ""} className={inputCls} /></L>
          </div>
        </>
      )}

      {kind === "fill" && (
        <>
          <L label="Prompt"><input name="prompt" required defaultValue={initial?.kind === "fill" ? initial.prompt : ""} className={inputCls} /></L>
          <L label="Template — use ___ (three underscores) for the blank">
            <textarea name="template" rows={3} required defaultValue={initial?.kind === "fill" ? initial.template : ""} className={mono} placeholder={"___(\"Hello\")"} />
          </L>
          <div className="grid gap-2 sm:grid-cols-2">
            <L label="Answer"><input name="answer" required defaultValue={initial?.kind === "fill" ? initial.answer : ""} className={mono} /></L>
            <L label="Hint (optional)"><input name="hint" defaultValue={initial?.kind === "fill" ? initial.hint ?? "" : ""} className={inputCls} /></L>
          </div>
        </>
      )}

      {kind === "code" && (
        <>
          <div className="grid gap-2 sm:grid-cols-[1fr_160px]">
            <L label="Prompt (Markdown inline supported)"><input name="prompt" required defaultValue={initial?.kind === "code" ? initial.prompt : ""} className={inputCls} /></L>
            <L label="Language">
              <select name="language" defaultValue={initial?.kind === "code" ? initial.language : "python"} className={inputCls}>
                {["python", "sql", "javascript", "typescript", "html", "css", "bash"].map((l) => <option key={l}>{l}</option>)}
              </select>
            </L>
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            <L label="Starter code"><textarea name="starterCode" rows={6} defaultValue={initial?.kind === "code" ? initial.starterCode : ""} className={mono} /></L>
            <L label="Solution (revealed after 2 failed attempts)"><textarea name="solution" rows={6} defaultValue={initial?.kind === "code" ? initial.solution : ""} className={mono} /></L>
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            <L label="Checks — one per line; the learner's code must contain each (whitespace/case-insensitive)">
              <textarea name="checks" rows={4} required defaultValue={initial?.kind === "code" ? initial.checks.join("\n") : ""} className={mono} placeholder={"print(\nHello"} />
            </L>
            <L label="Hint (optional)"><input name="hint" defaultValue={initial?.kind === "code" ? initial.hint ?? "" : ""} className={inputCls} /></L>
          </div>
        </>
      )}

      {state?.error && <p className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">{state.error}</p>}
      {state?.success && <p className="rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{state.success}</p>}

      <div className="flex gap-2">
        <button disabled={pending} className={btnPrimary}>{pending ? "Saving…" : step ? "Update step" : "Add step"}</button>
        {onDone && <button type="button" onClick={onDone} className={btnSecondary}>Close</button>}
      </div>
    </form>
  );
}

function L({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block text-xs font-medium text-slate-600">{label}<div className="mt-1">{children}</div></label>;
}
