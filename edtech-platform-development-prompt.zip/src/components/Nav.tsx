import Link from "next/link";
import { getCurrentUser, isStaff } from "@/lib/auth";
import { logoutAction } from "@/lib/actions/auth";

export async function Nav() {
  const user = await getCurrentUser();

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <Link href="/" className="flex items-center gap-2 text-lg font-bold tracking-tight text-slate-900">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 text-sm text-white">L</span>
          Learnly
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-medium text-slate-600 md:flex">
          <Link href="/courses" className="hover:text-slate-900">Courses</Link>
          {user && <Link href="/dashboard" className="hover:text-slate-900">Dashboard</Link>}
          {isStaff(user) && <Link href="/admin" className="hover:text-slate-900">Admin</Link>}
        </nav>

        <div className="flex items-center gap-3">
          {user ? (
            <>
              <div className="hidden items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700 sm:flex">
                <span title="Streak">🔥 {user.streak}</span>
                <span className="text-slate-300">|</span>
                <span title="XP">⚡ {user.xp} XP</span>
              </div>
              <Link href="/profile" className="grid h-9 w-9 place-items-center rounded-full bg-indigo-100 text-sm font-bold text-indigo-700" title={user.name}>
                {user.name.slice(0, 1).toUpperCase()}
              </Link>
              <form action={logoutAction}>
                <button className="text-sm font-medium text-slate-500 hover:text-slate-900">Log out</button>
              </form>
            </>
          ) : (
            <>
              <Link href="/login" className="text-sm font-medium text-slate-600 hover:text-slate-900">Log in</Link>
              <Link href="/register" className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-700">Get started</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
