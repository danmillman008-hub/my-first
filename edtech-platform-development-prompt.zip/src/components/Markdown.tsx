import { Fragment, type ReactNode } from "react";

/** Minimal, dependency-free markdown renderer for lesson content. */
function inline(text: string, keyPrefix: string): ReactNode[] {
  const parts: ReactNode[] = [];
  const re = /(`[^`]+`|\*\*[^*]+\*\*)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    const tok = m[0];
    if (tok.startsWith("`")) {
      parts.push(<code key={`${keyPrefix}-${i++}`} className="rounded bg-slate-800 px-1.5 py-0.5 font-mono text-[0.9em] text-emerald-300">{tok.slice(1, -1)}</code>);
    } else {
      parts.push(<strong key={`${keyPrefix}-${i++}`} className="font-semibold text-white">{tok.slice(2, -2)}</strong>);
    }
    last = m.index + tok.length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

export function Markdown({ source }: { source: string }) {
  const lines = source.replace(/\r\n/g, "\n").split("\n");
  const out: ReactNode[] = [];
  let i = 0;
  let key = 0;

  while (i < lines.length) {
    const line = lines[i];

    if (line.startsWith("```")) {
      const lang = line.slice(3).trim();
      const buf: string[] = [];
      i++;
      while (i < lines.length && !lines[i].startsWith("```")) buf.push(lines[i++]);
      i++;
      out.push(
        <div key={key++} className="my-4 overflow-hidden rounded-xl border border-slate-700 bg-slate-950">
          {lang && <div className="border-b border-slate-800 px-4 py-1.5 font-mono text-xs uppercase tracking-wide text-slate-400">{lang}</div>}
          <pre className="overflow-x-auto p-4 font-mono text-sm leading-relaxed text-emerald-200">{buf.join("\n")}</pre>
        </div>,
      );
      continue;
    }

    if (line.startsWith("|")) {
      const rows: string[][] = [];
      while (i < lines.length && lines[i].startsWith("|")) {
        const cells = lines[i].split("|").slice(1, -1).map((c) => c.trim());
        if (!cells.every((c) => /^-+$/.test(c))) rows.push(cells);
        i++;
      }
      const [head, ...body] = rows;
      out.push(
        <div key={key++} className="my-4 overflow-x-auto rounded-xl border border-slate-700">
          <table className="w-full text-sm">
            <thead className="bg-slate-800 text-left text-slate-200">
              <tr>{head.map((c, ci) => <th key={ci} className="px-3 py-2 font-semibold">{inline(c, `h${ci}`)}</th>)}</tr>
            </thead>
            <tbody>
              {body.map((r, ri) => (
                <tr key={ri} className="border-t border-slate-800">
                  {r.map((c, ci) => <td key={ci} className="px-3 py-2 text-slate-300">{inline(c, `r${ri}${ci}`)}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>,
      );
      continue;
    }

    if (line.startsWith("## ")) { out.push(<h2 key={key++} className="mb-3 mt-2 text-2xl font-bold text-white">{inline(line.slice(3), `h2${key}`)}</h2>); i++; continue; }
    if (line.startsWith("# ")) { out.push(<h1 key={key++} className="mb-3 text-3xl font-bold text-white">{inline(line.slice(2), `h1${key}`)}</h1>); i++; continue; }
    if (line.startsWith("- ")) {
      const items: string[] = [];
      while (i < lines.length && lines[i].startsWith("- ")) items.push(lines[i++].slice(2));
      out.push(<ul key={key++} className="my-3 list-disc space-y-1 pl-6 text-slate-300">{items.map((it, ii) => <li key={ii}>{inline(it, `li${ii}`)}</li>)}</ul>);
      continue;
    }
    if (!line.trim()) { i++; continue; }

    const para: string[] = [];
    while (i < lines.length && lines[i].trim() && !/^(```|\||## |# |- )/.test(lines[i])) para.push(lines[i++]);
    out.push(<p key={key++} className="my-3 leading-relaxed text-slate-300">{inline(para.join(" "), `p${key}`)}</p>);
  }

  return <Fragment>{out}</Fragment>;
}
