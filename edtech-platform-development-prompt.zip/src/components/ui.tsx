import Link from "next/link";
import type { ReactNode } from "react";
import type { Course } from "@/db/schema";

export const colorMap: Record<string, { bg: string; text: string; ring: string; solid: string }> = {
  indigo: { bg: "bg-indigo-50", text: "text-indigo-700", ring: "ring-indigo-200", solid: "bg-indigo-600" },
  emerald: { bg: "bg-emerald-50", text: "text-emerald-700", ring: "ring-emerald-200", solid: "bg-emerald-600" },
  sky: { bg: "bg-sky-50", text: "text-sky-700", ring: "ring-sky-200", solid: "bg-sky-600" },
  amber: { bg: "bg-amber-50", text: "text-amber-700", ring: "ring-amber-200", solid: "bg-amber-500" },
  rose: { bg: "bg-rose-50", text: "text-rose-700", ring: "ring-rose-200", solid: "bg-rose-600" },
  violet: { bg: "bg-violet-50", text: "text-violet-700", ring: "ring-violet-200", solid: "bg-violet-600" },
};
export const colorOptions = Object.keys(colorMap);
export function palette(color: string) {
  return colorMap[color] ?? colorMap.indigo;
}

export function Badge({ children, tone = "slate" }: { children: ReactNode; tone?: "slate" | "green" | "amber" | "red" | "indigo" }) {
  const tones = {
    slate: "bg-slate-100 text-slate-700",
    green: "bg-emerald-100 text-emerald-700",
    amber: "bg-amber-100 text-amber-800",
    red: "bg-rose-100 text-rose-700",
    indigo: "bg-indigo-100 text-indigo-700",
  };
  return <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${tones[tone]}`}>{children}</span>;
}

export function StatusBadge({ status }: { status: string }) {
  const tone = status === "published" ? "green" : status === "archived" ? "red" : "amber";
  return <Badge tone={tone}>{status}</Badge>;
}

export function ProgressBar({ value, color = "indigo", className = "" }: { value: number; color?: string; className?: string }) {
  const pct = Math.max(0, Math.min(100, Math.round(value)));
  return (
    <div className={`h-2 w-full overflow-hidden rounded-full bg-slate-200 ${className}`}>
      <div className={`h-full rounded-full ${palette(color).solid} transition-all`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export function CourseCard({ course, lessonCount, progress }: { course: Course; lessonCount?: number; progress?: number }) {
  const p = palette(course.color);
  return (
    <Link href={`/courses/${course.slug}`} className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
      <div className="flex items-start justify-between">
        <span className={`grid h-12 w-12 place-items-center rounded-xl text-2xl ${p.bg} ring-1 ${p.ring}`}>{course.icon}</span>
        <div className="flex gap-1.5">
          {course.isPremium && <Badge tone="amber">PRO</Badge>}
          <Badge>{course.level}</Badge>
        </div>
      </div>
      <h3 className="mt-4 text-lg font-bold text-slate-900 group-hover:text-indigo-700">{course.title}</h3>
      <p className="mt-1 line-clamp-2 text-sm text-slate-600">{course.tagline}</p>
      <div className="mt-auto pt-4">
        {progress !== undefined ? (
          <>
            <div className="mb-1 flex justify-between text-xs text-slate-500"><span>{Math.round(progress)}% complete</span><span>{lessonCount} lessons</span></div>
            <ProgressBar value={progress} color={course.color} />
          </>
        ) : (
          <div className="flex items-center gap-3 text-xs text-slate-500">
            <span>{course.category}</span>
            {lessonCount !== undefined && <><span>·</span><span>{lessonCount} lessons</span></>}
          </div>
        )}
      </div>
    </Link>
  );
}

export function EmptyState({ title, description, action }: { title: string; description: string; action?: ReactNode }) {
  return (
    <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center">
      <p className="text-lg font-semibold text-slate-800">{title}</p>
      <p className="mt-1 text-sm text-slate-500">{description}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export const inputCls = "w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200";
export const btnPrimary = "inline-flex items-center justify-center rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50";
export const btnSecondary = "inline-flex items-center justify-center rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50";
export const btnDanger = "inline-flex items-center justify-center rounded-lg border border-rose-200 bg-rose-50 px-3 py-1.5 text-xs font-semibold text-rose-700 hover:bg-rose-100";
export const btnGhost = "inline-flex items-center justify-center rounded-md px-2 py-1 text-xs font-medium text-slate-500 hover:bg-slate-100 hover:text-slate-900 disabled:opacity-30";
