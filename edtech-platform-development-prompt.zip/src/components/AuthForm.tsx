"use client";

import Link from "next/link";
import { useActionState } from "react";
import { loginAction, registerAction, type AuthState } from "@/lib/actions/auth";
import { btnPrimary, inputCls } from "@/components/ui";

export function AuthForm({ mode, next }: { mode: "login" | "register"; next?: string }) {
  const action = mode === "login" ? loginAction : registerAction;
  const [state, formAction, pending] = useActionState<AuthState, FormData>(action, undefined);

  return (
    <div className="mx-auto w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
      <h1 className="text-2xl font-bold">{mode === "login" ? "Welcome back" : "Create your account"}</h1>
      <p className="mt-1 text-sm text-slate-500">
        {mode === "login" ? "Log in to continue your streak." : "Free forever for core courses. No credit card needed."}
      </p>

      <form action={formAction} className="mt-6 space-y-4">
        <input type="hidden" name="next" value={next ?? ""} />
        {mode === "register" && (
          <label className="block text-sm font-medium">
            Name
            <input name="name" required minLength={2} className={`${inputCls} mt-1`} placeholder="Ada Lovelace" />
          </label>
        )}
        <label className="block text-sm font-medium">
          Email
          <input name="email" type="email" required className={`${inputCls} mt-1`} placeholder="you@example.com" />
        </label>
        <label className="block text-sm font-medium">
          Password
          <input name="password" type="password" required minLength={6} className={`${inputCls} mt-1`} placeholder="••••••••" />
        </label>

        {state?.error && <p className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">{state.error}</p>}

        <button disabled={pending} className={`${btnPrimary} w-full py-2.5`}>
          {pending ? "Please wait…" : mode === "login" ? "Log in" : "Create account"}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-slate-500">
        {mode === "login" ? (
          <>New here? <Link href={`/register${next ? `?next=${encodeURIComponent(next)}` : ""}`} className="font-semibold text-indigo-600">Create an account</Link></>
        ) : (
          <>Already have an account? <Link href={`/login${next ? `?next=${encodeURIComponent(next)}` : ""}`} className="font-semibold text-indigo-600">Log in</Link></>
        )}
      </p>

      {mode === "login" && (
        <div className="mt-6 rounded-xl bg-slate-50 p-3 text-xs text-slate-600">
          <p className="font-semibold text-slate-700">Demo accounts</p>
          <p>Admin: <code>admin@learnly.dev</code> / <code>admin123</code></p>
          <p>Learner: <code>learner@learnly.dev</code> / <code>learner123</code></p>
        </div>
      )}
    </div>
  );
}
