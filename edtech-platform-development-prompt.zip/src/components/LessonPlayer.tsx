"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import type { Step, StepContent } from "@/db/schema";
import { Markdown } from "@/components/Markdown";
import { completeLessonAction, resetLessonAction, submitStepAction } from "@/lib/actions/learning";

type Props = {
  lesson: { id: number; title: string; xpReward: number };
  course: { slug: string; title: string };
  steps: Step[];
  completedStepIds: number[];
  lessonAlreadyCompleted: boolean;
  nextLessonSlug: string | null;
  prevLessonSlug: string | null;
};

type Feedback = { correct: boolean; message: string } | null;

function normalize(s: string) {
  return s.replace(/\s+/g, " ").trim().toLowerCase();
}

export function LessonPlayer(props: Props) {
  const { lesson, course, steps, nextLessonSlug } = props;
  const router = useRouter();
  const [pending, startTransition] = useTransition();

  const firstIncomplete = useMemo(() => {
    const done = new Set(props.completedStepIds);
    const idx = steps.findIndex((s) => !done.has(s.id));
    return idx === -1 ? 0 : idx;
  }, [steps, props.completedStepIds]);

  const [index, setIndex] = useState(props.lessonAlreadyCompleted ? 0 : firstIncomplete);
  const [feedback, setFeedback] = useState<Feedback>(null);
  const [attempts, setAttempts] = useState(0);
  const [mistakes, setMistakes] = useState(0);
  const [finished, setFinished] = useState<{ xpAwarded: number; streak: number; alreadyDone: boolean } | null>(null);
  const [showHint, setShowHint] = useState(false);

  // per-step input state
  const [choice, setChoice] = useState<number | null>(null);
  const [code, setCode] = useState<string>("");
  const [codeInit, setCodeInit] = useState<number | null>(null);
  const [fill, setFill] = useState("");

  const step = steps[index];
  const content = step?.content as StepContent | undefined;
  const total = steps.length;
  const isLast = index === total - 1;

  if (content?.kind === "code" && codeInit !== step.id) {
    setCode(content.starterCode);
    setCodeInit(step.id);
  }

  function resetInputs() {
    setChoice(null); setFill(""); setFeedback(null); setAttempts(0); setShowHint(false);
  }

  function check() {
    if (!content) return;
    const n = attempts + 1;
    setAttempts(n);
    let correct = false;
    let message = "";

    if (content.kind === "quiz") {
      if (choice === null) return;
      correct = choice === content.correctIndex;
      message = correct ? (content.explanation ?? "Nice work!") : `Not quite. ${n >= 2 ? `The correct answer is "${content.options[content.correctIndex]}".` : "Try again."}`;
    } else if (content.kind === "code") {
      const missing = content.checks.filter((c) => !normalize(code).includes(normalize(c)));
      correct = missing.length === 0;
      message = correct ? "All checks passed! ✓" : `Check failed: your code should contain \`${missing[0]}\``;
    } else if (content.kind === "fill") {
      correct = normalize(fill) === normalize(content.answer);
      message = correct ? "Correct!" : n >= 3 ? `The answer was "${content.answer}".` : "Not quite — try again.";
    }

    if (!correct) setMistakes((m) => m + 1);
    setFeedback({ correct, message });
    if (correct) {
      startTransition(async () => { await submitStepAction(step.id, n === 1, n); });
    }
  }

  function goNext() {
    if (!content) return;
    if (content.kind === "text") {
      startTransition(async () => { await submitStepAction(step.id, true, 1); });
    }
    if (isLast) {
      const score = Math.max(0, Math.round(100 - (mistakes / Math.max(1, total)) * 50));
      startTransition(async () => {
        const res = await completeLessonAction(lesson.id, score);
        if (res.ok) setFinished({ xpAwarded: res.xpAwarded, streak: res.streak, alreadyDone: res.alreadyDone });
        router.refresh();
      });
      return;
    }
    setIndex((i) => i + 1);
    resetInputs();
  }

  function retryLesson() {
    startTransition(async () => {
      await resetLessonAction(lesson.id);
      setIndex(0); setMistakes(0); setFinished(null); resetInputs(); setCodeInit(null);
    });
  }

  const canAdvance = content?.kind === "text" || feedback?.correct;

  if (finished) {
    return (
      <div className="mx-auto max-w-xl rounded-3xl border border-slate-800 bg-slate-900 p-10 text-center text-white shadow-2xl">
        <div className="text-6xl">🎉</div>
        <h2 className="mt-4 text-3xl font-bold">Lesson complete!</h2>
        <p className="mt-2 text-slate-400">{lesson.title}</p>
        <div className="mt-8 grid grid-cols-2 gap-4">
          <div className="rounded-2xl bg-slate-800 p-4"><div className="text-3xl font-bold text-amber-300">+{finished.xpAwarded}</div><div className="text-xs text-slate-400">XP earned {finished.alreadyDone && "(already completed)"}</div></div>
          <div className="rounded-2xl bg-slate-800 p-4"><div className="text-3xl font-bold text-orange-400">🔥 {finished.streak}</div><div className="text-xs text-slate-400">day streak</div></div>
        </div>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">
          {nextLessonSlug ? (
            <Link href={`/learn/${course.slug}/${nextLessonSlug}`} className="rounded-xl bg-indigo-500 px-6 py-3 font-semibold hover:bg-indigo-400">Next lesson →</Link>
          ) : (
            <Link href={`/courses/${course.slug}`} className="rounded-xl bg-emerald-500 px-6 py-3 font-semibold hover:bg-emerald-400">Course finished! View course</Link>
          )}
          <Link href="/dashboard" className="rounded-xl border border-white/15 px-6 py-3 font-semibold hover:bg-white/5">Dashboard</Link>
        </div>
        <button onClick={retryLesson} className="mt-4 text-sm text-slate-400 underline hover:text-white">Retry lesson</button>
      </div>
    );
  }

  if (!step || !content) {
    return <div className="rounded-2xl bg-slate-900 p-8 text-center text-slate-300">This lesson has no steps yet.</div>;
  }

  return (
    <div className="mx-auto max-w-3xl">
      {/* progress */}
      <div className="mb-6 flex items-center gap-4">
        <Link href={`/courses/${course.slug}`} className="text-slate-400 hover:text-white" aria-label="Exit lesson">✕</Link>
        <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-slate-800">
          <div className="h-full rounded-full bg-emerald-400 transition-all duration-500" style={{ width: `${((index + (canAdvance ? 1 : 0)) / total) * 100}%` }} />
        </div>
        <span className="text-xs font-semibold text-slate-400">{index + 1}/{total}</span>
      </div>

      <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 shadow-2xl sm:p-8">
        {content.kind === "text" && <Markdown source={content.body} />}

        {content.kind === "quiz" && (
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-indigo-400">Quiz</p>
            <h2 className="mt-2 text-xl font-semibold text-white"><Markdown source={content.question} /></h2>
            <div className="mt-5 space-y-2">
              {content.options.map((opt, i) => {
                const selected = choice === i;
                const showState = feedback && selected;
                return (
                  <button
                    key={i}
                    disabled={!!feedback?.correct}
                    onClick={() => { setChoice(i); setFeedback(null); }}
                    className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-left text-sm transition ${
                      showState ? (feedback.correct ? "border-emerald-400 bg-emerald-500/10 text-emerald-200" : "border-rose-400 bg-rose-500/10 text-rose-200")
                      : selected ? "border-indigo-400 bg-indigo-500/10 text-white" : "border-slate-700 bg-slate-800/60 text-slate-200 hover:border-slate-500"
                    }`}
                  >
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md bg-slate-700 font-mono text-xs">{String.fromCharCode(65 + i)}</span>
                    <span className="font-mono">{opt}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {content.kind === "fill" && (
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-indigo-400">Fill in the blank</p>
            <div className="mt-2 text-lg text-white"><Markdown source={content.prompt} /></div>
            <pre className="mt-4 whitespace-pre-wrap rounded-xl border border-slate-700 bg-slate-950 p-4 font-mono text-sm text-emerald-200">
              {content.template.split("___").map((part, i, arr) => (
                <span key={i}>
                  {part}
                  {i < arr.length - 1 && (
                    <input
                      value={fill}
                      onChange={(e) => { setFill(e.target.value); setFeedback(null); }}
                      onKeyDown={(e) => { if (e.key === "Enter") (feedback?.correct ? goNext() : check()); }}
                      disabled={!!feedback?.correct}
                      autoFocus
                      className="mx-1 inline-block w-28 rounded border border-indigo-400/60 bg-slate-900 px-2 py-0.5 font-mono text-white focus:outline-none focus:ring-2 focus:ring-indigo-400"
                      placeholder="…"
                    />
                  )}
                </span>
              ))}
            </pre>
          </div>
        )}

        {content.kind === "code" && (
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-indigo-400">Coding exercise · {content.language}</p>
            <div className="mt-2 text-lg text-white"><Markdown source={content.prompt} /></div>
            <div className="mt-4 overflow-hidden rounded-xl border border-slate-700 bg-slate-950">
              <div className="flex items-center justify-between border-b border-slate-800 px-4 py-1.5 text-xs text-slate-400">
                <span className="font-mono">main.{content.language === "python" ? "py" : content.language === "sql" ? "sql" : "js"}</span>
                <button onClick={() => { setCode(content.starterCode); setFeedback(null); }} className="hover:text-white">Reset</button>
              </div>
              <textarea
                value={code}
                onChange={(e) => { setCode(e.target.value); setFeedback(null); }}
                disabled={!!feedback?.correct}
                spellCheck={false}
                rows={Math.max(6, code.split("\n").length + 1)}
                className="w-full resize-y bg-transparent p-4 font-mono text-sm leading-relaxed text-emerald-100 focus:outline-none"
              />
            </div>
            {showHint && attempts >= 2 && content.solution && (
              <div className="mt-3 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-sm text-amber-200">
                <p className="font-semibold">Solution</p>
                <pre className="mt-1 whitespace-pre-wrap font-mono text-xs">{content.solution}</pre>
              </div>
            )}
          </div>
        )}

        {/* hint */}
        {(content.kind === "code" || content.kind === "fill") && content.hint && attempts >= 1 && !feedback?.correct && (
          <p className="mt-4 text-sm text-slate-400">💡 Hint: {content.hint}</p>
        )}

        {/* feedback */}
        {feedback && (
          <div className={`mt-5 rounded-xl border px-4 py-3 text-sm ${feedback.correct ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-200" : "border-rose-500/40 bg-rose-500/10 text-rose-200"}`}>
            {feedback.correct ? "✓ " : "✗ "}{feedback.message}
          </div>
        )}

        {/* actions */}
        <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-slate-500">
            {props.prevLessonSlug && index === 0 && <Link href={`/learn/${course.slug}/${props.prevLessonSlug}`} className="hover:text-white">← Previous lesson</Link>}
            {content.kind === "code" && attempts >= 2 && !feedback?.correct && (
              <button onClick={() => setShowHint(true)} className="ml-3 underline hover:text-white">Show solution</button>
            )}
          </div>
          {canAdvance ? (
            <button onClick={goNext} disabled={pending} className="rounded-xl bg-emerald-500 px-6 py-2.5 font-semibold text-slate-950 shadow-lg shadow-emerald-500/20 hover:bg-emerald-400 disabled:opacity-60">
              {isLast ? "Finish lesson" : "Continue →"}
            </button>
          ) : (
            <button
              onClick={check}
              disabled={(content.kind === "quiz" && choice === null) || (content.kind === "fill" && !fill.trim())}
              className="rounded-xl bg-indigo-500 px-6 py-2.5 font-semibold text-white shadow-lg shadow-indigo-500/20 hover:bg-indigo-400 disabled:opacity-40"
            >
              Check
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
