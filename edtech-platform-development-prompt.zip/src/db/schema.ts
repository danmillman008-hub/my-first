import {
  boolean,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

// ---------- Users & Auth ----------
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: varchar("name", { length: 120 }).notNull(),
  role: varchar("role", { length: 20 }).notNull().default("learner"), // learner | instructor | admin
  plan: varchar("plan", { length: 20 }).notNull().default("free"), // free | pro
  xp: integer("xp").notNull().default(0),
  streak: integer("streak").notNull().default(0),
  lastActiveDate: varchar("last_active_date", { length: 10 }), // YYYY-MM-DD
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  token: varchar("token", { length: 128 }).primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------- Content (CMS) ----------
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  title: varchar("title", { length: 200 }).notNull(),
  tagline: varchar("tagline", { length: 300 }).notNull().default(""),
  description: text("description").notNull().default(""),
  category: varchar("category", { length: 60 }).notNull().default("Programming"),
  level: varchar("level", { length: 20 }).notNull().default("beginner"), // beginner | intermediate | advanced
  icon: varchar("icon", { length: 8 }).notNull().default("📘"),
  color: varchar("color", { length: 30 }).notNull().default("indigo"),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  status: varchar("status", { length: 20 }).notNull().default("draft"), // draft | published | archived
  isPremium: boolean("is_premium").notNull().default(false),
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const modules = pgTable("modules", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id")
    .notNull()
    .references(() => courses.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 200 }).notNull(),
  position: integer("position").notNull().default(0),
});

export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  moduleId: integer("module_id")
    .notNull()
    .references(() => modules.id, { onDelete: "cascade" }),
  slug: varchar("slug", { length: 160 }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description").notNull().default(""),
  xpReward: integer("xp_reward").notNull().default(20),
  status: varchar("status", { length: 20 }).notNull().default("published"), // draft | published
  position: integer("position").notNull().default(0),
});

// A lesson is a sequence of small steps (Mimo-style).
// type: text | quiz | code | fill
export type StepContent =
  | { kind: "text"; body: string }
  | { kind: "quiz"; question: string; options: string[]; correctIndex: number; explanation?: string }
  | { kind: "code"; prompt: string; language: string; starterCode: string; solution: string; checks: string[]; hint?: string }
  | { kind: "fill"; prompt: string; template: string; answer: string; hint?: string };

export const steps = pgTable("steps", {
  id: serial("id").primaryKey(),
  lessonId: integer("lesson_id")
    .notNull()
    .references(() => lessons.id, { onDelete: "cascade" }),
  type: varchar("type", { length: 20 }).notNull(),
  content: jsonb("content").$type<StepContent>().notNull(),
  position: integer("position").notNull().default(0),
});

// ---------- Learning progress ----------
export const enrollments = pgTable(
  "enrollments",
  {
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    courseId: integer("course_id")
      .notNull()
      .references(() => courses.id, { onDelete: "cascade" }),
    enrolledAt: timestamp("enrolled_at").notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.courseId] })],
);

export const stepProgress = pgTable(
  "step_progress",
  {
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    stepId: integer("step_id")
      .notNull()
      .references(() => steps.id, { onDelete: "cascade" }),
    correct: boolean("correct").notNull().default(true),
    attempts: integer("attempts").notNull().default(1),
    completedAt: timestamp("completed_at").notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.stepId] })],
);

export const lessonProgress = pgTable(
  "lesson_progress",
  {
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    lessonId: integer("lesson_id")
      .notNull()
      .references(() => lessons.id, { onDelete: "cascade" }),
    score: integer("score").notNull().default(100),
    completedAt: timestamp("completed_at").notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.lessonId] })],
);

// ---------- Analytics / Audit ----------
export const activityLog = pgTable("activity_log", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  action: varchar("action", { length: 60 }).notNull(),
  meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type User = typeof users.$inferSelect;
export type Course = typeof courses.$inferSelect;
export type Module = typeof modules.$inferSelect;
export type Lesson = typeof lessons.$inferSelect;
export type Step = typeof steps.$inferSelect;
