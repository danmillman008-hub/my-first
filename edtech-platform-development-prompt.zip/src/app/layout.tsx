import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Nav } from "@/components/Nav";
import { ensureSeeded } from "@/lib/seed";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "Learnly — Learn to code, one step at a time", template: "%s · Learnly" },
  description: "Interactive, bite-sized coding and data lessons with quizzes, exercises, XP and streaks.",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  await ensureSeeded();
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 text-slate-900 antialiased">
        <Nav />
        {children}
      </body>
    </html>
  );
}
