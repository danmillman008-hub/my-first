import Link from "next/link";
import type { ReactNode } from "react";
import { requireStaff } from "@/lib/auth";

export const metadata = { title: "Admin" };

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const user = await requireStaff();
  const links = [
    ["/admin", "Overview"],
    ["/admin/courses", "Courses"],
    ...(user.role === "admin" ? [["/admin/users", "Users"]] : []),
  ];
  return (
    <div className="mx-auto grid max-w-7xl gap-8 px-4 py-8 sm:px-6 lg:grid-cols-[220px_1fr]">
      <aside className="h-fit rounded-2xl border border-slate-200 bg-white p-4 lg:sticky lg:top-24">
        <p className="px-2 text-xs font-semibold uppercase tracking-wide text-slate-400">CMS</p>
        <nav className="mt-2 flex gap-1 lg:flex-col">
          {links.map(([href, label]) => (
            <Link key={href} href={href} className="rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100">{label}</Link>
          ))}
        </nav>
        <p className="mt-4 border-t border-slate-100 px-2 pt-3 text-xs text-slate-400">Signed in as {user.name} ({user.role})</p>
      </aside>
      <div className="min-w-0">{children}</div>
    </div>
  );
}
