import Link from "next/link";
import { notFound } from "next/navigation";
import { LessonForm } from "@/components/admin/LessonForm";
import { StepList } from "@/components/admin/StepList";
import { StatusBadge, btnDanger, btnSecondary } from "@/components/ui";
import { deleteLessonAction } from "@/lib/actions/admin";
import { getLessonSteps, getLessonWithContext } from "@/lib/queries";

export default async function AdminLessonPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const ctx = await getLessonWithContext(Number(id));
  if (!ctx) notFound();
  const steps = await getLessonSteps(ctx.lesson.id);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <Link href={`/admin/courses/${ctx.course.id}`} className="text-sm text-slate-500 hover:text-slate-800">← {ctx.course.title}</Link>
          <h1 className="mt-1 flex items-center gap-3 text-2xl font-bold">{ctx.lesson.title} <StatusBadge status={ctx.lesson.status} /></h1>
          <p className="text-sm text-slate-500">Module: {ctx.module.title} · {steps.length} steps</p>
        </div>
        <div className="flex gap-2">
          <Link href={`/learn/${ctx.course.slug}/${ctx.lesson.slug}`} target="_blank" className={btnSecondary}>Preview as learner</Link>
          <form action={deleteLessonAction}>
            <input type="hidden" name="id" value={ctx.lesson.id} /><input type="hidden" name="courseId" value={ctx.course.id} />
            <button className={`${btnDanger} px-4 py-2 text-sm`}>Delete lesson</button>
          </form>
        </div>
      </div>

      <div className="grid gap-8 xl:grid-cols-[380px_1fr]">
        <section>
          <h2 className="mb-3 text-lg font-bold">Lesson settings</h2>
          <LessonForm lesson={ctx.lesson} />
          <p className="mt-3 text-xs text-slate-500">Preview requires you to be enrolled in the course and (for PRO courses) on the PRO plan.</p>
        </section>
        <section>
          <h2 className="mb-3 text-lg font-bold">Steps</h2>
          <StepList lessonId={ctx.lesson.id} steps={steps} />
        </section>
      </div>
    </div>
  );
}
