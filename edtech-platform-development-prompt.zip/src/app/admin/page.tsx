import Link from "next/link";
import { btnPrimary } from "@/components/ui";
import { getAdminStats, getRecentAuditLog } from "@/lib/queries";

export default async function AdminOverview() {
  const [stats, log] = await Promise.all([getAdminStats(), getRecentAuditLog()]);
  const cards = [
    ["Users", stats.users], ["Courses", stats.courses], ["Lessons", stats.lessons], ["Enrollments", stats.enrollments], ["Lesson completions", stats.completions],
  ] as const;

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Overview</h1>
        <Link href="/admin/courses/new" className={btnPrimary}>+ New course</Link>
      </div>
      <div className="mt-6 grid gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {cards.map(([label, value]) => (
          <div key={label} className="rounded-2xl border border-slate-200 bg-white p-4">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</p>
            <p className="mt-1 text-3xl font-bold">{value}</p>
          </div>
        ))}
      </div>

      <section className="mt-8 rounded-2xl border border-slate-200 bg-white">
        <div className="border-b border-slate-100 px-5 py-3"><h2 className="font-bold">Audit log & activity</h2></div>
        <ul className="divide-y divide-slate-100 text-sm">
          {log.map(({ log: l, userName }) => (
            <li key={l.id} className="flex items-center justify-between gap-4 px-5 py-2.5">
              <div className="min-w-0">
                <span className="rounded bg-slate-100 px-1.5 py-0.5 font-mono text-xs text-slate-700">{l.action}</span>
                <span className="ml-2 text-slate-600">{userName ?? "system"}</span>
                <span className="ml-2 truncate text-xs text-slate-400">{JSON.stringify(l.meta)}</span>
              </div>
              <span className="shrink-0 text-xs text-slate-400">{new Date(l.createdAt).toLocaleString()}</span>
            </li>
          ))}
          {log.length === 0 && <li className="px-5 py-6 text-center text-slate-400">No activity yet.</li>}
        </ul>
      </section>
    </div>
  );
}
