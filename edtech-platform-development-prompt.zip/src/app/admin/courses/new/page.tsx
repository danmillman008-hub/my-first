import Link from "next/link";
import { CourseForm } from "@/components/admin/CourseForm";

export default function NewCoursePage() {
  return (
    <div className="max-w-3xl">
      <Link href="/admin/courses" className="text-sm text-slate-500 hover:text-slate-800">← Courses</Link>
      <h1 className="mt-2 text-2xl font-bold">New course</h1>
      <p className="mb-6 text-sm text-slate-500">Courses are created as drafts. Add modules and lessons, then publish.</p>
      <CourseForm />
    </div>
  );
}
