import Link from "next/link";
import { notFound } from "next/navigation";
import { CourseForm } from "@/components/admin/CourseForm";
import { StatusBadge, btnDanger, btnGhost, btnSecondary, inputCls } from "@/components/ui";
import {
  createLessonAction, createModuleAction, deleteCourseAction, deleteLessonAction, deleteModuleAction,
  moveLessonAction, moveModuleAction, renameModuleAction, setCourseStatusAction,
} from "@/lib/actions/admin";
import { getCourseTree } from "@/lib/queries";

export default async function AdminCourseEditPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const course = await getCourseTree({ id: Number(id) }, true);
  if (!course) notFound();

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <Link href="/admin/courses" className="text-sm text-slate-500 hover:text-slate-800">← Courses</Link>
          <h1 className="mt-1 flex items-center gap-3 text-2xl font-bold">{course.icon} {course.title} <StatusBadge status={course.status} /></h1>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link href={`/courses/${course.slug}`} target="_blank" className={btnSecondary}>Preview</Link>
          {course.status !== "published" && (
            <form action={setCourseStatusAction}><input type="hidden" name="id" value={course.id} /><input type="hidden" name="status" value="published" /><button className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500">Publish</button></form>
          )}
          {course.status === "published" && (
            <form action={setCourseStatusAction}><input type="hidden" name="id" value={course.id} /><input type="hidden" name="status" value="draft" /><button className={btnSecondary}>Unpublish</button></form>
          )}
          {course.status !== "archived" && (
            <form action={setCourseStatusAction}><input type="hidden" name="id" value={course.id} /><input type="hidden" name="status" value="archived" /><button className={btnSecondary}>Archive</button></form>
          )}
          <form action={deleteCourseAction}><input type="hidden" name="id" value={course.id} /><button className={`${btnDanger} px-4 py-2 text-sm`}>Delete</button></form>
        </div>
      </div>

      <div className="grid gap-8 xl:grid-cols-[1fr_1fr]">
        <section>
          <h2 className="mb-3 text-lg font-bold">Course details</h2>
          <CourseForm course={course} />
        </section>

        <section>
          <h2 className="mb-3 text-lg font-bold">Curriculum</h2>
          <div className="space-y-4">
            {course.modules.map((m, mi) => (
              <div key={m.id} className="rounded-2xl border border-slate-200 bg-white">
                <div className="flex items-center gap-2 border-b border-slate-100 px-4 py-3">
                  <span className="text-xs font-bold text-slate-400">M{mi + 1}</span>
                  <form action={renameModuleAction} className="flex flex-1 gap-2">
                    <input type="hidden" name="id" value={m.id} />
                    <input name="title" defaultValue={m.title} className={`${inputCls} py-1`} />
                    <button className={btnGhost}>Rename</button>
                  </form>
                  <form action={moveModuleAction}><input type="hidden" name="id" value={m.id} /><input type="hidden" name="dir" value="up" /><button className={btnGhost} disabled={mi === 0}>↑</button></form>
                  <form action={moveModuleAction}><input type="hidden" name="id" value={m.id} /><input type="hidden" name="dir" value="down" /><button className={btnGhost} disabled={mi === course.modules.length - 1}>↓</button></form>
                  <form action={deleteModuleAction}><input type="hidden" name="id" value={m.id} /><button className={btnDanger}>Delete</button></form>
                </div>
                <ul className="divide-y divide-slate-100">
                  {m.lessons.map((l, li) => (
                    <li key={l.id} className="flex items-center gap-2 px-4 py-2 text-sm">
                      <span className="w-5 text-xs text-slate-400">{li + 1}</span>
                      <Link href={`/admin/lessons/${l.id}`} className="flex-1 font-medium text-slate-800 hover:text-indigo-700">{l.title}</Link>
                      <StatusBadge status={l.status} />
                      <span className="text-xs text-slate-400">{l.xpReward} XP</span>
                      <form action={moveLessonAction}><input type="hidden" name="id" value={l.id} /><input type="hidden" name="dir" value="up" /><button className={btnGhost} disabled={li === 0}>↑</button></form>
                      <form action={moveLessonAction}><input type="hidden" name="id" value={l.id} /><input type="hidden" name="dir" value="down" /><button className={btnGhost} disabled={li === m.lessons.length - 1}>↓</button></form>
                      <form action={deleteLessonAction}><input type="hidden" name="id" value={l.id} /><button className={btnGhost}>✕</button></form>
                    </li>
                  ))}
                  <li className="px-4 py-2">
                    <form action={createLessonAction} className="flex gap-2">
                      <input type="hidden" name="moduleId" value={m.id} />
                      <input name="title" required placeholder="New lesson title…" className={`${inputCls} py-1`} />
                      <input name="xpReward" type="number" defaultValue={20} className={`${inputCls} w-20 py-1`} title="XP reward" />
                      <button className={`${btnSecondary} whitespace-nowrap py-1`}>+ Lesson</button>
                    </form>
                  </li>
                </ul>
              </div>
            ))}

            <form action={createModuleAction} className="flex gap-2 rounded-2xl border border-dashed border-slate-300 bg-white p-4">
              <input type="hidden" name="courseId" value={course.id} />
              <input name="title" required placeholder="New module title…" className={inputCls} />
              <button className={`${btnSecondary} whitespace-nowrap`}>+ Module</button>
            </form>
          </div>
        </section>
      </div>
    </div>
  );
}
