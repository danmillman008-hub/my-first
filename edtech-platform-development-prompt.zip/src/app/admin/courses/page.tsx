import Link from "next/link";
import { Badge, StatusBadge, btnPrimary, btnGhost } from "@/components/ui";
import { setCourseStatusAction } from "@/lib/actions/admin";
import { listAllCourses } from "@/lib/queries";

export default async function AdminCoursesPage() {
  const rows = await listAllCourses();
  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Courses</h1>
        <Link href="/admin/courses/new" className={btnPrimary}>+ New course</Link>
      </div>

      <div className="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
            <tr><th className="px-4 py-3">Course</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Lessons</th><th className="px-4 py-3">Enrolled</th><th className="px-4 py-3">Updated</th><th className="px-4 py-3 text-right">Actions</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map(({ course: c, lessonCount, enrolledCount }) => (
              <tr key={c.id}>
                <td className="px-4 py-3">
                  <Link href={`/admin/courses/${c.id}`} className="flex items-center gap-3 font-medium text-slate-900 hover:text-indigo-700">
                    <span className="text-xl">{c.icon}</span>
                    <span>{c.title}<span className="block text-xs font-normal text-slate-400">/{c.slug} · {c.level}{c.isPremium && " · PRO"}</span></span>
                  </Link>
                </td>
                <td className="px-4 py-3"><StatusBadge status={c.status} /></td>
                <td className="px-4 py-3">{lessonCount}</td>
                <td className="px-4 py-3">{enrolledCount}</td>
                <td className="px-4 py-3 text-xs text-slate-500">{new Date(c.updatedAt).toLocaleDateString()}</td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-1">
                    <Link href={`/courses/${c.slug}`} className={btnGhost} target="_blank">Preview</Link>
                    <Link href={`/admin/courses/${c.id}`} className={btnGhost}>Edit</Link>
                    <form action={setCourseStatusAction}>
                      <input type="hidden" name="id" value={c.id} />
                      <input type="hidden" name="status" value={c.status === "published" ? "draft" : "published"} />
                      <button className={btnGhost}>{c.status === "published" ? "Unpublish" : "Publish"}</button>
                    </form>
                  </div>
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={6} className="px-4 py-10 text-center text-slate-400">No courses yet. <Badge>Create one</Badge></td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
