import { redirect } from "next/navigation";
import { Badge, inputCls } from "@/components/ui";
import { requireStaff } from "@/lib/auth";
import { setUserPlanAction, setUserRoleAction } from "@/lib/actions/admin";
import { listUsers } from "@/lib/queries";

export default async function AdminUsersPage() {
  const me = await requireStaff();
  if (me.role !== "admin") redirect("/admin");
  const rows = await listUsers();

  return (
    <div>
      <h1 className="text-2xl font-bold">Users</h1>
      <p className="text-sm text-slate-500">{rows.length} registered users</p>
      <div className="mt-6 overflow-x-auto rounded-2xl border border-slate-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
            <tr><th className="px-4 py-3">User</th><th className="px-4 py-3">Role</th><th className="px-4 py-3">Plan</th><th className="px-4 py-3">XP</th><th className="px-4 py-3">Streak</th><th className="px-4 py-3">Completed</th><th className="px-4 py-3">Joined</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((u) => (
              <tr key={u.id}>
                <td className="px-4 py-3"><div className="font-medium">{u.name}{u.id === me.id && <Badge tone="indigo">you</Badge>}</div><div className="text-xs text-slate-500">{u.email}</div></td>
                <td className="px-4 py-3">
                  {u.id === me.id ? <Badge>{u.role}</Badge> : (
                    <form action={setUserRoleAction}>
                      <input type="hidden" name="id" value={u.id} />
                      <select name="role" defaultValue={u.role} className={`${inputCls} w-auto py-1`}>
                        <option value="learner">learner</option><option value="instructor">instructor</option><option value="admin">admin</option>
                      </select>
                      <button className="ml-2 text-xs font-semibold text-indigo-600">Save</button>
                    </form>
                  )}
                </td>
                <td className="px-4 py-3">
                  <form action={setUserPlanAction}>
                    <input type="hidden" name="id" value={u.id} />
                    <select name="plan" defaultValue={u.plan} className={`${inputCls} w-auto py-1`}><option value="free">free</option><option value="pro">pro</option></select>
                    <button className="ml-2 text-xs font-semibold text-indigo-600">Save</button>
                  </form>
                </td>
                <td className="px-4 py-3">{u.xp}</td>
                <td className="px-4 py-3">🔥 {u.streak}</td>
                <td className="px-4 py-3">{u.completions}</td>
                <td className="px-4 py-3 text-xs text-slate-500">{new Date(u.createdAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
