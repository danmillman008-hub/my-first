import { NextResponse } from "next/server";
import { listPublishedCourses } from "@/lib/queries";
import { ensureSeeded } from "@/lib/seed";

/** Public, read-only catalog endpoint (API-first; usable by a future mobile app). */
export async function GET(req: Request) {
  await ensureSeeded();
  const { searchParams } = new URL(req.url);
  const courses = await listPublishedCourses({
    q: searchParams.get("q") ?? undefined,
    category: searchParams.get("category") ?? undefined,
    level: searchParams.get("level") ?? undefined,
  });
  return NextResponse.json({ data: courses });
}
