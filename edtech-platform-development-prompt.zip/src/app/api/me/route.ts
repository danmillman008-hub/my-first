import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getUserEnrollments } from "@/lib/queries";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const enrollments = await getUserEnrollments(user.id);
  return NextResponse.json({
    data: {
      id: user.id, name: user.name, email: user.email, role: user.role, plan: user.plan, xp: user.xp, streak: user.streak,
      enrollments: enrollments.map((e) => ({ courseId: e.course.id, slug: e.course.slug, completed: e.completed, total: e.total })),
    },
  });
}
