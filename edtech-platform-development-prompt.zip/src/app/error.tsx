"use client";

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <main className="mx-auto max-w-xl px-4 py-24 text-center">
      <p className="text-6xl">⚠️</p>
      <h1 className="mt-4 text-3xl font-bold">Something went wrong</h1>
      <p className="mt-2 text-slate-600">{error.message || "An unexpected error occurred."}</p>
      <button onClick={reset} className="mt-6 rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-500">Try again</button>
    </main>
  );
}
