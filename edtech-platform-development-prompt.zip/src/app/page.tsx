import Link from "next/link";
import { CourseCard } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { listPublishedCourses } from "@/lib/queries";

export default async function LandingPage() {
  const [user, courses] = await Promise.all([getCurrentUser(), listPublishedCourses()]);

  return (
    <main>
      <section className="relative overflow-hidden bg-slate-950 text-white">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(99,102,241,0.35),transparent_60%)]" />
        <div className="relative mx-auto grid max-w-7xl gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:py-28">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-indigo-400/30 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300">
              ✨ Interactive learning · 5 minutes a day
            </span>
            <h1 className="mt-6 text-4xl font-extrabold leading-tight tracking-tight sm:text-6xl">
              Learn to code <span className="bg-gradient-to-r from-indigo-400 to-emerald-400 bg-clip-text text-transparent">one step at a time</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg text-slate-300">
              Bite-sized lessons, hands-on exercises and instant feedback. Build a daily streak, earn XP and actually finish what you start.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href={user ? "/dashboard" : "/register"} className="rounded-xl bg-indigo-500 px-6 py-3 text-base font-semibold text-white shadow-lg shadow-indigo-500/30 hover:bg-indigo-400">
                {user ? "Continue learning" : "Start for free"}
              </Link>
              <Link href="/courses" className="rounded-xl border border-white/15 px-6 py-3 text-base font-semibold text-white hover:bg-white/5">
                Browse courses
              </Link>
            </div>
            <dl className="mt-10 grid grid-cols-3 gap-6 text-sm">
              {[["Lessons", "Short & focused"], ["Exercises", "Code in the browser"], ["Progress", "XP, streaks & badges"]].map(([k, v]) => (
                <div key={k}><dt className="font-semibold text-white">{k}</dt><dd className="text-slate-400">{v}</dd></div>
              ))}
            </dl>
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-5 shadow-2xl backdrop-blur">
            <div className="mb-3 flex items-center justify-between text-xs text-slate-400">
              <span>Lesson 2 · Variables</span><span>Step 3 of 4</span>
            </div>
            <div className="mb-4 h-1.5 w-full rounded-full bg-slate-800"><div className="h-full w-3/4 rounded-full bg-emerald-400" /></div>
            <p className="font-semibold text-white">Create a variable <code className="rounded bg-slate-800 px-1.5 text-emerald-300">score</code> with the value 100, then print it.</p>
            <pre className="mt-4 rounded-xl border border-slate-700 bg-slate-950 p-4 font-mono text-sm text-emerald-200">{`score = 100\nprint(score)`}</pre>
            <div className="mt-4 flex items-center justify-between rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">
              <span>✓ Correct! +25 XP</span><span className="font-semibold">Continue →</span>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-bold">Popular courses</h2>
            <p className="text-slate-600">Start with a path built for beginners, or jump straight into data.</p>
          </div>
          <Link href="/courses" className="text-sm font-semibold text-indigo-600 hover:text-indigo-800">View all →</Link>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {courses.slice(0, 6).map((c) => <CourseCard key={c.id} course={c} lessonCount={c.lessonCount} />)}
        </div>
      </section>

      <section className="border-t border-slate-200 bg-white">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 py-16 sm:px-6 md:grid-cols-3">
          {[
            ["📱", "Learn anywhere", "Mobile-first lessons designed for a few minutes at a time."],
            ["🧪", "Practice by doing", "Quizzes, fill-in-the-blank and real coding exercises with instant checks."],
            ["🔥", "Stay motivated", "Daily streaks, XP and a leaderboard keep you coming back."],
          ].map(([icon, title, desc]) => (
            <div key={title} className="rounded-2xl border border-slate-200 p-6">
              <div className="text-3xl">{icon}</div>
              <h3 className="mt-3 text-lg font-bold">{title}</h3>
              <p className="mt-1 text-sm text-slate-600">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-slate-200 py-8 text-center text-sm text-slate-500">© {new Date().getFullYear()} Learnly. Built with Next.js & PostgreSQL.</footer>
    </main>
  );
}
