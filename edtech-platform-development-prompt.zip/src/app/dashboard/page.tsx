import Link from "next/link";
import { CourseCard, EmptyState, btnPrimary } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { getLeaderboard, getRecentActivity, getUserEnrollments, listPublishedCourses } from "@/lib/queries";

export const metadata = { title: "Dashboard" };

const LEVEL_XP = 100;

export default async function DashboardPage() {
  const user = await requireUser("/dashboard");
  const [enrollments, activity, leaderboard, catalog] = await Promise.all([
    getUserEnrollments(user.id), getRecentActivity(user.id), getLeaderboard(), listPublishedCourses(),
  ]);

  const level = Math.floor(user.xp / LEVEL_XP) + 1;
  const levelProgress = ((user.xp % LEVEL_XP) / LEVEL_XP) * 100;
  const inProgress = enrollments.filter((e) => e.nextLesson);
  const continueItem = inProgress[0];
  const enrolledIds = new Set(enrollments.map((e) => e.course.id));
  const suggestions = catalog.filter((c) => !enrolledIds.has(c.id)).slice(0, 3);
  const totalCompleted = enrollments.reduce((s, e) => s + e.completed, 0);

  return (
    <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Hey {user.name.split(" ")[0]} 👋</h1>
          <p className="text-slate-600">{continueItem ? "Keep the momentum going." : "Ready to start something new?"}</p>
        </div>
        <Link href="/courses" className="text-sm font-semibold text-indigo-600 hover:text-indigo-800">Browse catalog →</Link>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Day streak" value={`🔥 ${user.streak}`} sub={user.lastActiveDate === new Date().toISOString().slice(0, 10) ? "Active today" : "Complete a lesson to extend it"} />
        <Stat label="Total XP" value={`⚡ ${user.xp}`} sub={`Level ${level} · ${LEVEL_XP - (user.xp % LEVEL_XP)} XP to next`} progress={levelProgress} />
        <Stat label="Lessons completed" value={String(totalCompleted)} sub={`${enrollments.length} course${enrollments.length === 1 ? "" : "s"} enrolled`} />
        <Stat label="Plan" value={user.plan === "pro" ? "PRO ✨" : "Free"} sub={user.plan === "pro" ? "All courses unlocked" : "Upgrade to unlock PRO courses"} href="/profile" />
      </div>

      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_320px]">
        <div className="space-y-10">
          {continueItem && (
            <section className="rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 p-6 text-white shadow-lg">
              <p className="text-xs font-semibold uppercase tracking-wide text-indigo-200">Continue where you left off</p>
              <h2 className="mt-1 text-2xl font-bold">{continueItem.course.icon} {continueItem.course.title}</h2>
              <p className="mt-1 text-indigo-100">Next: {continueItem.nextLesson!.title} · +{continueItem.nextLesson!.xpReward} XP</p>
              <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-white/20"><div className="h-full bg-white" style={{ width: `${(continueItem.completed / Math.max(1, continueItem.total)) * 100}%` }} /></div>
              <Link href={`/learn/${continueItem.course.slug}/${continueItem.nextLesson!.slug}`} className="mt-5 inline-flex rounded-xl bg-white px-5 py-2.5 text-sm font-semibold text-indigo-700 hover:bg-indigo-50">Resume lesson →</Link>
            </section>
          )}

          <section>
            <h2 className="mb-4 text-xl font-bold">My courses</h2>
            {enrollments.length === 0 ? (
              <EmptyState title="You're not enrolled in any course yet" description="Pick a course from the catalog and start your first lesson." action={<Link href="/courses" className={btnPrimary}>Explore courses</Link>} />
            ) : (
              <div className="grid gap-5 sm:grid-cols-2">
                {enrollments.map((e) => <CourseCard key={e.course.id} course={e.course} lessonCount={e.total} progress={e.total ? (e.completed / e.total) * 100 : 0} />)}
              </div>
            )}
          </section>

          {suggestions.length > 0 && (
            <section>
              <h2 className="mb-4 text-xl font-bold">Recommended for you</h2>
              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {suggestions.map((c) => <CourseCard key={c.id} course={c} lessonCount={c.lessonCount} />)}
              </div>
            </section>
          )}
        </div>

        <aside className="space-y-6">
          <section className="rounded-2xl border border-slate-200 bg-white p-5">
            <h3 className="font-bold">Leaderboard</h3>
            <ol className="mt-3 space-y-2 text-sm">
              {leaderboard.map((u, i) => (
                <li key={u.id} className={`flex items-center justify-between rounded-lg px-2 py-1.5 ${u.id === user.id ? "bg-indigo-50 font-semibold text-indigo-800" : ""}`}>
                  <span className="flex items-center gap-2"><span className="w-5 text-slate-400">{["🥇", "🥈", "🥉"][i] ?? `${i + 1}.`}</span>{u.name}</span>
                  <span className="text-slate-500">{u.xp} XP</span>
                </li>
              ))}
            </ol>
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white p-5">
            <h3 className="font-bold">Recent activity</h3>
            {activity.length === 0 ? <p className="mt-2 text-sm text-slate-500">Nothing yet — complete a lesson!</p> : (
              <ul className="mt-3 space-y-2 text-sm">
                {activity.map((a) => (
                  <li key={a.id} className="flex items-start gap-2">
                    <span>{a.action === "lesson.completed" ? "✅" : a.action === "course.enrolled" ? "📚" : a.action === "plan.changed" ? "✨" : "•"}</span>
                    <div className="min-w-0">
                      <p className="truncate text-slate-800">{describe(a.action, a.meta)}</p>
                      <p className="text-xs text-slate-400">{new Date(a.createdAt).toLocaleString()}</p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </aside>
      </div>
    </main>
  );
}

function describe(action: string, meta: Record<string, unknown>) {
  switch (action) {
    case "lesson.completed": return `Completed "${meta.title}" (+${meta.xp} XP)`;
    case "course.enrolled": return `Enrolled in ${meta.title}`;
    case "plan.changed": return `Switched to ${String(meta.to).toUpperCase()} plan`;
    case "user.registered": return "Joined Learnly";
    case "user.login": return "Logged in";
    default: return action;
  }
}

function Stat({ label, value, sub, progress, href }: { label: string; value: string; sub: string; progress?: number; href?: string }) {
  const inner = (
    <>
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-1 text-2xl font-bold">{value}</p>
      <p className="mt-0.5 text-xs text-slate-500">{sub}</p>
      {progress !== undefined && <div className="mt-2 h-1.5 w-full rounded-full bg-slate-200"><div className="h-full rounded-full bg-indigo-500" style={{ width: `${progress}%` }} /></div>}
    </>
  );
  const cls = "rounded-2xl border border-slate-200 bg-white p-5";
  return href ? <Link href={href} className={`${cls} block hover:border-indigo-300`}>{inner}</Link> : <div className={cls}>{inner}</div>;
}
