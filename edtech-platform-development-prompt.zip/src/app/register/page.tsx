import { redirect } from "next/navigation";
import { AuthForm } from "@/components/AuthForm";
import { getCurrentUser } from "@/lib/auth";

export const metadata = { title: "Create account" };

export default async function RegisterPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  if (await getCurrentUser()) redirect(next && next.startsWith("/") ? next : "/dashboard");
  return (
    <main className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <AuthForm mode="register" next={next} />
    </main>
  );
}
