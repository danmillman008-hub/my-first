import Link from "next/link";
import { CourseCard, EmptyState, inputCls } from "@/components/ui";
import { listCategories, listPublishedCourses } from "@/lib/queries";

export const metadata = { title: "Courses" };

const LEVELS = ["beginner", "intermediate", "advanced"];

export default async function CoursesPage({ searchParams }: { searchParams: Promise<{ q?: string; category?: string; level?: string }> }) {
  const params = await searchParams;
  const [courses, categories] = await Promise.all([listPublishedCourses(params), listCategories()]);

  return (
    <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Course catalog</h1>
        <p className="mt-1 text-slate-600">Pick a path and start learning today.</p>
      </div>

      <form className="mb-8 grid gap-3 rounded-2xl border border-slate-200 bg-white p-4 sm:grid-cols-[1fr_auto_auto_auto]">
        <input name="q" defaultValue={params.q ?? ""} placeholder="Search courses, tags…" className={inputCls} />
        <select name="category" defaultValue={params.category ?? ""} className={inputCls}>
          <option value="">All categories</option>
          {categories.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <select name="level" defaultValue={params.level ?? ""} className={inputCls}>
          <option value="">All levels</option>
          {LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
        </select>
        <div className="flex gap-2">
          <button className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-700">Filter</button>
          {(params.q || params.category || params.level) && (
            <Link href="/courses" className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">Clear</Link>
          )}
        </div>
      </form>

      {courses.length === 0 ? (
        <EmptyState title="No courses match" description="Try a different search or clear the filters." />
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {courses.map((c) => <CourseCard key={c.id} course={c} lessonCount={c.lessonCount} />)}
        </div>
      )}
    </main>
  );
}
