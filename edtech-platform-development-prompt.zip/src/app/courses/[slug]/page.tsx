import Link from "next/link";
import { notFound } from "next/navigation";
import { Badge, ProgressBar, btnPrimary, palette } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { enrollAction } from "@/lib/actions/learning";
import { flattenLessons, getCompletedLessonIds, getCourseTree, isEnrolled } from "@/lib/queries";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const course = await getCourseTree({ slug });
  return { title: course?.title ?? "Course", description: course?.tagline };
}

export default async function CourseDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [course, user] = await Promise.all([getCourseTree({ slug }), getCurrentUser()]);
  if (!course) notFound();

  const all = flattenLessons(course);
  const enrolled = user ? await isEnrolled(user.id, course.id) : false;
  const done = user ? await getCompletedLessonIds(user.id, all.map((l) => l.id)) : new Set<number>();
  const completed = all.filter((l) => done.has(l.id)).length;
  const nextLesson = all.find((l) => !done.has(l.id)) ?? all[0];
  const totalXp = all.reduce((s, l) => s + l.xpReward, 0);
  const p = palette(course.color);
  const locked = course.isPremium && user?.plan !== "pro" && !enrolled;

  return (
    <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="grid gap-8 lg:grid-cols-[1fr_360px]">
        <div>
          <Link href="/courses" className="text-sm text-slate-500 hover:text-slate-800">← All courses</Link>
          <div className="mt-4 flex items-start gap-4">
            <span className={`grid h-16 w-16 shrink-0 place-items-center rounded-2xl text-3xl ${p.bg} ring-1 ${p.ring}`}>{course.icon}</span>
            <div>
              <div className="flex flex-wrap gap-1.5">
                <Badge>{course.category}</Badge><Badge>{course.level}</Badge>{course.isPremium && <Badge tone="amber">PRO</Badge>}
              </div>
              <h1 className="mt-2 text-3xl font-bold">{course.title}</h1>
              <p className="mt-1 text-lg text-slate-600">{course.tagline}</p>
            </div>
          </div>
          <p className="mt-6 max-w-3xl leading-relaxed text-slate-700">{course.description}</p>

          <h2 className="mt-10 text-xl font-bold">Curriculum</h2>
          <div className="mt-4 space-y-4">
            {course.modules.map((m, mi) => (
              <div key={m.id} className="rounded-2xl border border-slate-200 bg-white">
                <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3">
                  <h3 className="font-semibold">Module {mi + 1}: {m.title}</h3>
                  <span className="text-xs text-slate-500">{m.lessons.length} lessons</span>
                </div>
                <ul className="divide-y divide-slate-100">
                  {m.lessons.map((l) => {
                    const isDone = done.has(l.id);
                    const canOpen = enrolled && !locked;
                    return (
                      <li key={l.id} className="flex items-center gap-3 px-5 py-3">
                        <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-full text-xs font-bold ${isDone ? "bg-emerald-500 text-white" : "bg-slate-100 text-slate-500"}`}>{isDone ? "✓" : m.lessons.indexOf(l) + 1}</span>
                        <div className="min-w-0 flex-1">
                          {canOpen ? (
                            <Link href={`/learn/${course.slug}/${l.slug}`} className="font-medium text-slate-900 hover:text-indigo-700">{l.title}</Link>
                          ) : (
                            <span className="font-medium text-slate-700">{l.title}</span>
                          )}
                          <p className="truncate text-xs text-slate-500">{l.description}</p>
                        </div>
                        <span className="text-xs font-semibold text-slate-400">+{l.xpReward} XP</span>
                      </li>
                    );
                  })}
                  {m.lessons.length === 0 && <li className="px-5 py-3 text-sm text-slate-400">No lessons yet.</li>}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <aside className="h-fit rounded-2xl border border-slate-200 bg-white p-6 shadow-sm lg:sticky lg:top-24">
          <dl className="grid grid-cols-3 gap-3 text-center text-sm">
            <div><dt className="text-2xl font-bold">{course.modules.length}</dt><dd className="text-slate-500">modules</dd></div>
            <div><dt className="text-2xl font-bold">{all.length}</dt><dd className="text-slate-500">lessons</dd></div>
            <div><dt className="text-2xl font-bold">{totalXp}</dt><dd className="text-slate-500">XP</dd></div>
          </dl>

          {enrolled && (
            <div className="mt-5">
              <div className="mb-1 flex justify-between text-xs text-slate-500"><span>{completed}/{all.length} lessons</span><span>{all.length ? Math.round((completed / all.length) * 100) : 0}%</span></div>
              <ProgressBar value={all.length ? (completed / all.length) * 100 : 0} color={course.color} />
            </div>
          )}

          <div className="mt-6">
            {!user ? (
              <Link href={`/login?next=${encodeURIComponent(`/courses/${course.slug}`)}`} className={`${btnPrimary} w-full py-3`}>Log in to enroll</Link>
            ) : locked ? (
              <div className="space-y-3">
                <p className="rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-800">This is a PRO course. Upgrade your plan to unlock it.</p>
                <Link href="/profile" className={`${btnPrimary} w-full py-3`}>Upgrade to PRO</Link>
              </div>
            ) : enrolled ? (
              nextLesson ? (
                <Link href={`/learn/${course.slug}/${nextLesson.slug}`} className={`${btnPrimary} w-full py-3`}>
                  {completed === 0 ? "Start course" : completed === all.length ? "Review course" : "Continue learning"}
                </Link>
              ) : <p className="text-sm text-slate-500">No lessons published yet.</p>
            ) : (
              <form action={enrollAction}>
                <input type="hidden" name="courseId" value={course.id} />
                <input type="hidden" name="slug" value={course.slug} />
                <button className={`${btnPrimary} w-full py-3`}>Enroll for free</button>
              </form>
            )}
          </div>

          {course.tags.length > 0 && (
            <div className="mt-6 flex flex-wrap gap-1.5">{course.tags.map((t) => <Badge key={t}>#{t}</Badge>)}</div>
          )}
        </aside>
      </div>
    </main>
  );
}
