import { Badge, btnPrimary, btnSecondary } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { upgradePlanAction } from "@/lib/actions/learning";
import { getUserEnrollments } from "@/lib/queries";

export const metadata = { title: "Profile" };

const BADGES = [
  { id: "first", icon: "🌱", title: "First Steps", desc: "Complete your first lesson", check: (s: { completed: number; xp: number; streak: number; courses: number }) => s.completed >= 1 },
  { id: "five", icon: "🚀", title: "On a Roll", desc: "Complete 5 lessons", check: (s: { completed: number }) => s.completed >= 5 },
  { id: "xp100", icon: "⚡", title: "Century", desc: "Earn 100 XP", check: (s: { xp: number }) => s.xp >= 100 },
  { id: "streak3", icon: "🔥", title: "Consistent", desc: "3-day streak", check: (s: { streak: number }) => s.streak >= 3 },
  { id: "finisher", icon: "🏆", title: "Finisher", desc: "Complete a whole course", check: (s: { finished: number }) => s.finished >= 1 },
  { id: "explorer", icon: "🧭", title: "Explorer", desc: "Enroll in 3 courses", check: (s: { courses: number }) => s.courses >= 3 },
];

export default async function ProfilePage() {
  const user = await requireUser("/profile");
  const enrollments = await getUserEnrollments(user.id);
  const stats = {
    completed: enrollments.reduce((s, e) => s + e.completed, 0),
    xp: user.xp, streak: user.streak, courses: enrollments.length,
    finished: enrollments.filter((e) => e.total > 0 && e.completed === e.total).length,
  };

  return (
    <main className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
      <div className="flex items-center gap-5 rounded-2xl border border-slate-200 bg-white p-6">
        <div className="grid h-20 w-20 place-items-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 text-3xl font-bold text-white">{user.name.slice(0, 1).toUpperCase()}</div>
        <div className="flex-1">
          <h1 className="text-2xl font-bold">{user.name}</h1>
          <p className="text-sm text-slate-500">{user.email}</p>
          <div className="mt-2 flex gap-2"><Badge tone="indigo">{user.role}</Badge><Badge tone={user.plan === "pro" ? "amber" : "slate"}>{user.plan.toUpperCase()} plan</Badge></div>
        </div>
        <div className="hidden text-right sm:block">
          <p className="text-3xl font-bold">⚡ {user.xp}</p>
          <p className="text-xs text-slate-500">Member since {new Date(user.createdAt).toLocaleDateString()}</p>
        </div>
      </div>

      <section className="mt-8">
        <h2 className="text-xl font-bold">Badges</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          {BADGES.map((b) => {
            const earned = b.check(stats);
            return (
              <div key={b.id} className={`rounded-2xl border p-4 ${earned ? "border-amber-200 bg-amber-50" : "border-slate-200 bg-white opacity-60"}`}>
                <div className={`text-3xl ${earned ? "" : "grayscale"}`}>{b.icon}</div>
                <p className="mt-2 font-semibold">{b.title}</p>
                <p className="text-xs text-slate-500">{b.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      <section className="mt-8 rounded-2xl border border-slate-200 bg-white p-6">
        <h2 className="text-xl font-bold">Subscription</h2>
        <p className="mt-1 text-sm text-slate-600">
          {user.plan === "pro" ? "You have full access to every PRO course. Thanks for supporting Learnly!" : "Upgrade to PRO to unlock premium courses and projects."}
        </p>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div className={`rounded-xl border p-4 ${user.plan === "free" ? "border-indigo-400 ring-2 ring-indigo-100" : "border-slate-200"}`}>
            <p className="font-semibold">Free</p><p className="text-2xl font-bold">$0</p>
            <ul className="mt-2 space-y-1 text-sm text-slate-600"><li>✓ Core courses</li><li>✓ XP & streaks</li><li>✗ PRO courses</li></ul>
          </div>
          <div className={`rounded-xl border p-4 ${user.plan === "pro" ? "border-amber-400 ring-2 ring-amber-100" : "border-slate-200"}`}>
            <p className="font-semibold">PRO</p><p className="text-2xl font-bold">$12<span className="text-sm font-normal text-slate-500">/mo</span></p>
            <ul className="mt-2 space-y-1 text-sm text-slate-600"><li>✓ Everything in Free</li><li>✓ All PRO courses</li><li>✓ Projects & certificates</li></ul>
          </div>
        </div>
        <form action={upgradePlanAction} className="mt-4">
          <button className={user.plan === "pro" ? btnSecondary : btnPrimary}>{user.plan === "pro" ? "Downgrade to Free" : "Upgrade to PRO (demo checkout)"}</button>
        </form>
        <p className="mt-2 text-xs text-slate-400">Demo mode: this toggles the plan instantly. Wire <code>upgradePlanAction</code> to Stripe Checkout for real payments.</p>
      </section>
    </main>
  );
}
