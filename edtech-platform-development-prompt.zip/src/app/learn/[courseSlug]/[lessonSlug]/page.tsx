import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { LessonPlayer } from "@/components/LessonPlayer";
import { requireUser } from "@/lib/auth";
import { flattenLessons, getCompletedLessonIds, getCompletedStepIds, getCourseTree, getLessonSteps, isEnrolled } from "@/lib/queries";

export async function generateMetadata({ params }: { params: Promise<{ courseSlug: string; lessonSlug: string }> }) {
  const { courseSlug, lessonSlug } = await params;
  const tree = await getCourseTree({ slug: courseSlug });
  const lesson = tree ? flattenLessons(tree).find((l) => l.slug === lessonSlug) : null;
  return { title: lesson ? `${lesson.title} · ${tree?.title}` : "Lesson" };
}

export default async function LessonPage({ params }: { params: Promise<{ courseSlug: string; lessonSlug: string }> }) {
  const { courseSlug, lessonSlug } = await params;
  const user = await requireUser(`/learn/${courseSlug}/${lessonSlug}`);
  const tree = await getCourseTree({ slug: courseSlug });
  if (!tree) notFound();

  const all = flattenLessons(tree);
  const idx = all.findIndex((l) => l.slug === lessonSlug);
  if (idx === -1) notFound();
  const lesson = all[idx];

  const enrolled = await isEnrolled(user.id, tree.id);
  if (!enrolled) redirect(`/courses/${courseSlug}`);
  if (tree.isPremium && user.plan !== "pro") redirect(`/courses/${courseSlug}`);

  const steps = await getLessonSteps(lesson.id);
  const [completedSteps, completedLessons] = await Promise.all([
    getCompletedStepIds(user.id, steps.map((s) => s.id)),
    getCompletedLessonIds(user.id, [lesson.id]),
  ]);

  const moduleOf = tree.modules.find((m) => m.id === lesson.moduleId);

  return (
    <main className="min-h-[calc(100vh-4rem)] bg-slate-950 px-4 py-8 sm:px-6">
      <div className="mx-auto mb-4 max-w-3xl text-xs text-slate-500">
        <Link href={`/courses/${tree.slug}`} className="hover:text-slate-300">{tree.title}</Link>
        <span className="mx-2">/</span><span>{moduleOf?.title}</span>
        <span className="mx-2">/</span><span className="text-slate-300">{lesson.title}</span>
      </div>
      <LessonPlayer
        key={lesson.id}
        lesson={{ id: lesson.id, title: lesson.title, xpReward: lesson.xpReward }}
        course={{ slug: tree.slug, title: tree.title }}
        steps={steps}
        completedStepIds={[...completedSteps]}
        lessonAlreadyCompleted={completedLessons.has(lesson.id)}
        nextLessonSlug={all[idx + 1]?.slug ?? null}
        prevLessonSlug={all[idx - 1]?.slug ?? null}
      />
    </main>
  );
}
