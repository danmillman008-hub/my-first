# Learnly — Interactive Learning Platform (Mimo / DataCamp style)

Production-ready MVP of an EdTech platform: bite-sized lessons, interactive exercises, XP/streaks, learner dashboard and a full CMS/admin panel — built with **Next.js (App Router) + TypeScript + PostgreSQL (Drizzle ORM) + Tailwind**.

## Demo accounts
| Role | Email | Password |
|---|---|---|
| Admin | `admin@learnly.dev` | `admin123` |
| Learner | `learner@learnly.dev` | `learner123` |

Demo content (3 courses, 11 lessons, 36 steps) is seeded automatically on first request.

## Architecture
```
Browser ── Next.js App Router (RSC + Server Actions) ── Drizzle ORM ── PostgreSQL
              │
              ├─ /api/*  JSON endpoints (API-first; reusable by a mobile app)
              └─ Cookie sessions (httpOnly) + role-based access control
```
- **Auth**: email/password with `scrypt` hashing, DB-backed sessions in an httpOnly cookie (`src/lib/auth.ts`). Designed so Supabase Auth can replace it by swapping `getCurrentUser()`.
- **RBAC**: roles `learner | instructor | admin`. `/admin/*` requires staff; user management requires `admin`.
- **Content engine**: Course → Module → Lesson → Step. Step kinds: `text` (Markdown), `quiz` (MCQ), `fill` (fill-in-the-blank), `code` (exercise validated by required snippets).
- **Gamification**: XP per lesson, daily streak, levels, badges, leaderboard.
- **Audit/analytics**: `activity_log` table records logins, enrollments, completions, plan changes and every CMS mutation.

## Data model (`src/db/schema.ts`)
`users`, `sessions`, `courses`, `modules`, `lessons`, `steps` (JSONB content), `enrollments`, `step_progress`, `lesson_progress`, `activity_log`.

## Routes
| Path | Purpose |
|---|---|
| `/` | Landing |
| `/courses`, `/courses/[slug]` | Catalog with search/filter, course detail + enroll |
| `/learn/[course]/[lesson]` | Lesson player (steps, instant feedback, retry, XP) |
| `/dashboard`, `/profile` | Progress, streak, leaderboard, badges, plan |
| `/login`, `/register` | Auth |
| `/admin` | CMS overview + audit log |
| `/admin/courses`, `/admin/courses/[id]` | Course CRUD, draft/publish/archive, modules & lessons ordering |
| `/admin/lessons/[id]` | Lesson settings + step editor (all 4 step types) |
| `/admin/users` | Role & plan management (admin only) |
| `GET /api/courses`, `GET /api/me`, `GET /api/health` | JSON API |

## Key folders
```
src/app/            pages & API routes
src/components/     UI, LessonPlayer, admin editors
src/lib/auth.ts     sessions, password hashing, guards
src/lib/queries.ts  read models
src/lib/actions/    server actions: auth, learning engine, CMS
src/lib/seed.ts     idempotent demo seed
src/db/             Drizzle client + schema
```

## Development
```bash
npm install
npx drizzle-kit push       # apply schema
npm run dev
```
Env: `DATABASE_URL` in `.env`.

## Production notes / roadmap
- **Payments**: `upgradePlanAction` is a demo toggle — replace with Stripe Checkout + webhook that sets `users.plan`.
- **Media**: add S3-compatible uploads for lesson images/videos (store URLs in step content).
- **Email**: hook `activity_log` events to a transactional email provider.
- **Code execution**: swap the snippet-check validator for a sandboxed runner (e.g. Piston/Judge0) for real output checks.
- **Versioning**: add `lesson_revisions` table if content history is required.
