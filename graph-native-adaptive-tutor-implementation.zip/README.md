# Graph-Native Adaptive Tutor

A private adaptive tutor built **on top of** the existing Graphify graph engine, borrowing
auto-tutor's pedagogy (Bloom-level downgrade, Socratic checks, ✅/🔄/⏳ mastery, file-driven
"cite the material" lessons). The chat is the product; a thin personalization layer makes
Graphify's graph dynamic per learner.

```
corpus/*.md ──(Graphify: extract → build → cluster → export)──▶ graphify-out/graph.json  ◀── canonical graph
                                                                    │            │
                                          graphify-mcp (Graphify's own MCP)      │ read-only adapter (src/graphify)
                                                                                 ▼
                                    src/adaptive  (evidence · preferences · affect · mastery · branches/decay · policy · paths)
                                                                                 │
                                    src/tutor     (policy → explanation; optional LLM rewrite)
                                                  │                                  │
                                    /api/chat + minimal chat UI          src/mcp (thin MCP adapter: stdio + Streamable HTTP /mcp)
                                                                                 │
                                    PostgreSQL overlay: tutor_learners / tutor_interactions / tutor_concept_state / tutor_branch_state
```

## Run

```bash
# 1. deps
npm install
pip install "graphifyy[mcp]"            # Graphify (Python) — only needed to (re)build the graph or run graphify-mcp

# 2. environment
cp .env.example .env                    # set DATABASE_URL; TUTOR_LLM_API_KEY is optional (local dev only)
npx drizzle-kit push                    # creates the overlay tables

# 3. (optional) rebuild the canonical graph from ./corpus with Graphify itself
npm run graph:build                     # or: GRAPHIFY_SRC=/path/to/graphify npm run graph:build

# 4. app
npm run build && npm start              # http://localhost:3000

# 5. MCP
npm run mcp:stdio                       # tutor MCP over stdio
#   Streamable HTTP: http://localhost:3000/mcp  (set TUTOR_MCP_API_KEY to require x-api-key / Bearer)
npm run mcp:graphify                    # Graphify's own MCP server (graph queries) over stdio
npm run mcp:graphify -- http 8080       # …or Streamable HTTP on :8080/mcp
npm run mcp:smoke                       # protocol smoke test against the running /mcp

# 6. tests (unit + e2e acceptance scenario + MCP + PostgreSQL persistence)
npm test
```

## MCP surface (tutor)

Tools: `get_learning_state`, `get_concept`, `get_related_concepts`, `get_current_policy`,
`record_interaction`, `reactivate_branch`, `apply_decay`.
Resources: `user://local/state`, `graph://concept/{id}`. Prompt: `explain_current_concept`.
Graph search / traversal / shortest paths: use Graphify's server (`query_graph`, `get_neighbors`, `shortest_path`, …).

Concept ids are Graphify node ids; branch keys are Graphify edge keys `source|relation|target`.
