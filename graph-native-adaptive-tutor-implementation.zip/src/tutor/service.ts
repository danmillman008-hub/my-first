// Tutor service: the single entry point used by the chat API and the MCP
// adapter. Composes Graphify adapter + adaptive engine + renderer.
import { reactivateBranch, runDecay, stepInteraction } from "@/adaptive/engine";
import { applyDecay, effectiveStrength, masteryLabel } from "@/adaptive/branches";
import { rankBranches } from "@/adaptive/paths";
import type { TutorStore } from "@/adaptive/store";
import { argmax, initialLearner, type LearnerState } from "@/adaptive/types";
import { getGraph, GraphifyGraph, parseBranchKey } from "@/graphify/adapter";
import { renderExplanation, title } from "./explain";
import { maybeRewriteWithLlm } from "./llm";

export interface TutorDeps {
  graph: GraphifyGraph;
  store: TutorStore;
  useLlm?: boolean;
}

export async function chatTurn(deps: TutorDeps, learnerId: string, message: string, now?: number, conceptId?: string) {
  const step = await stepInteraction({ graph: deps.graph, store: deps.store, learnerId, message, now, conceptId });
  const draft = renderExplanation(deps.graph, step);
  const { text, generator } = deps.useLlm ? await maybeRewriteWithLlm(draft, step.policy, step.concept.label) : { text: draft, generator: "template" as const };
  return {
    reply: text,
    generator,
    concept: { id: step.concept.id, label: title(step.concept), kind: step.concept.node_kind, community: step.concept.community_name ?? step.concept.community },
    policy: step.policy,
    signals: step.signals,
    outcomeOfPrevious: step.outcome,
    affect: step.learner.affect.dominant,
    depth: argmax(step.learner.depth),
    style: argmax(step.learner.style),
    mastery: step.conceptState.mastery,
    branchUsed: step.branchUsed?.key ?? null,
    reactivated: step.reactivated,
    nextBranches: step.ranked.slice(0, 3).map((b) => ({ key: b.branch.key, to: b.branch.to, score: Number(b.score.toFixed(3)), strength: Number(b.effectiveStrength.toFixed(3)), dormant: b.dormant })),
  };
}

/** Graph-native personalised snapshot (used by the UI side panel and MCP). */
export async function learnerSnapshot(deps: TutorDeps, learnerId: string, now = Date.now()) {
  const learner: LearnerState = (await deps.store.getLearner(learnerId)) ?? initialLearner(learnerId);
  const concepts = await deps.store.getConceptStates(learnerId);
  const branches = (await deps.store.getBranchStates(learnerId)).map((b) => applyDecay(b, now));
  const current = learner.currentConceptId ? deps.graph.node(learner.currentConceptId) : undefined;
  const ranked = current ? rankBranches(deps.graph.branches(current.id), new Map(branches.map((b) => [b.branchKey, b])), new Map(concepts.map((c) => [c.conceptId, c])), learner.affect.dominant, now) : [];
  return {
    learnerId,
    graph: { source: "graphify-out/graph.json", ...deps.graph.size },
    currentConcept: current ? { id: current.id, label: title(current), community: current.community_name ?? current.community } : null,
    preferences: { depth: argmax(learner.depth), depthBelief: learner.depth, style: argmax(learner.style), styleBelief: learner.style },
    affect: learner.affect,
    concepts: concepts
      .filter((c) => c.exposures > 0 || c.conceptId === current?.id)
      .map((c) => ({ id: c.conceptId, label: (() => { const n = deps.graph.node(c.conceptId); return n ? title(n) : c.conceptId; })(), mastery: Number(c.mastery.toFixed(3)), status: masteryLabel(c.mastery), exposures: c.exposures, styleBias: c.styleBias })),
    branches: branches
      .map((b) => ({ key: b.branchKey, ...parseBranchKey(b.branchKey), strength: Number(effectiveStrength(b, now).toFixed(3)), dormant: b.dormant, uses: b.uses, successes: b.successes, reactivations: b.reactivations }))
      .sort((a, b) => b.strength - a.strength),
    nextBranches: ranked.slice(0, 5).map((b) => ({ key: b.branch.key, to: b.branch.to, score: Number(b.score.toFixed(3)), dormant: b.dormant, reasons: b.reasons })),
  };
}

export { runDecay, reactivateBranch };

// ---- runtime wiring (Postgres + graph.json) ---------------------------------
let runtime: TutorDeps | undefined;

export async function getRuntimeDeps(): Promise<TutorDeps> {
  if (runtime) return runtime;
  const [{ db }, { PgStore }] = await Promise.all([import("@/db"), import("@/adaptive/store-pg")]);
  runtime = { graph: getGraph(), store: new PgStore(db), useLlm: Boolean(process.env.TUTOR_LLM_API_KEY) };
  return runtime;
}
