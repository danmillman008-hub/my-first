// Optional LLM rewrite of the deterministic explanation, constrained by the
// policy. Server-side only. If no key is configured or the call fails, the
// template explanation is used unchanged (the app never depends on the LLM).
import type { Policy } from "@/adaptive/types";

const MODEL = process.env.TUTOR_LLM_MODEL ?? "gemini-2.0-flash";

export async function maybeRewriteWithLlm(draft: string, policy: Policy, conceptLabel: string): Promise<{ text: string; generator: "template" | "llm" }> {
  const key = process.env.TUTOR_LLM_API_KEY;
  if (!key || process.env.TUTOR_LLM_DISABLED === "1") return { text: draft, generator: "template" };
  const instruction = [
    `You are a private adaptive tutor. Rewrite the draft explanation of "${conceptLabel}" for the learner.`,
    `Target depth: ${policy.depth}. Primary style: ${policy.style}${policy.secondaryStyle ? `, secondary: ${policy.secondaryStyle}` : ""}.`,
    `Teaching moves to include: ${policy.moves.join(", ") || "none"}.`,
    "Only use facts present in the draft. Keep any 'Quick check' question and 'Related next' list.",
  ].join("\n");
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 8000);
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: instruction }] }, contents: [{ role: "user", parts: [{ text: draft }] }] }),
      signal: ctrl.signal,
    });
    clearTimeout(t);
    if (!res.ok) return { text: draft, generator: "template" };
    const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
    const text = data.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("").trim();
    return text ? { text, generator: "llm" } : { text: draft, generator: "template" };
  } catch {
    return { text: draft, generator: "template" };
  }
}
