// Turns (concept + policy + ranked branches) into a tutor message.
//
// Content comes from the Graphify-indexed source material (file-driven, like
// auto-tutor's "cite the material" rule). Depth controls how much of the
// section is used; style controls framing; policy moves add Socratic checks,
// related-concept offers, etc. Deterministic so tests can assert on it.
import type { GraphifyGraph, GraphifyNode } from "@/graphify/adapter";
import type { StepResult } from "@/adaptive/engine";
import { masteryIcon } from "@/adaptive/branches";
import type { Depth, Style } from "@/adaptive/types";

const sentences = (t: string) => t.replace(/\s+/g, " ").split(/(?<=[.!?])\s+(?=[A-Z(∫])/).filter((s) => s.trim().length > 0);

export const title = (n: GraphifyNode) => n.label.replace(/\.md$/, "").replace(/[-_]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

const DEPTH_SENTENCES: Record<Depth, number> = { concise: 1, standard: 2, detailed: 5, deep: 8 };

/** Pick the heading node under the same page whose label matches a style (e.g. "…Example", "…Analogy"). */
function styleSection(graph: GraphifyGraph, concept: GraphifyNode, style: Style): GraphifyNode | undefined {
  const want: Partial<Record<Style, RegExp>> = {
    "example-driven": /example|problem|rule/i,
    "analogy-based": /analogy|intuition|why it matters|slope/i,
    "step-by-step": /definition|statement|test|laws|rules/i,
    practical: /problem|matters|application|rules/i,
    technical: /definition|theorem|epsilon|statement|test/i,
  };
  const re = want[style];
  if (!re) return undefined;
  const pageId = concept.node_kind === "page" ? concept.id : concept.source_file?.replace(/\.md$/, "").replace(/-/g, "_");
  if (!pageId) return undefined;
  // Graphify's markdown extractor hangs sub-headings off the H1 node, which
  // itself hangs off the page node: walk both `contains` hops.
  const h1 = graph.neighbors(pageId).filter((n) => n.node_kind === "heading");
  const candidates = [...h1, ...h1.flatMap((h) => graph.neighbors(h.id))].filter((n) => n.node_kind === "heading" && n.source_file === (concept.source_file ?? n.source_file));
  return [...new Map(candidates.map((n) => [n.id, n])).values()]
    .filter((n) => n.id !== concept.id && n.source_location !== "L1" && re.test(n.label))
    .sort((a, b) => a.label.localeCompare(b.label))[0];
}

export function renderExplanation(graph: GraphifyGraph, r: StepResult): string {
  const { concept, policy, conceptState } = r;
  const src = graph.sourceText(concept.id) || graph.sourceText(concept.source_file?.replace(/\.md$/, "").replace(/-/g, "_") ?? "");
  const body = sentences(src);
  const n = DEPTH_SENTENCES[policy.depth];
  const parts: string[] = [];

  // Opening framed by affect / moves.
  if (policy.moves.includes("slow_down")) parts.push("Let's slow down and take this one piece at a time.");
  else if (policy.moves.includes("vary_approach")) parts.push(`Let me come at ${title(concept)} from a different angle.`);
  else if (r.branchUsed && r.learner.currentConceptId) parts.push(`Moving along the graph via “${r.branchUsed.edge.relation}” to ${title(concept)}.`);
  else parts.push(`**${title(concept)}** ${masteryIcon(conceptState.mastery)}`);

  // Core explanation, styled.
  const core = body.slice(0, n);
  if (policy.style === "step-by-step" || policy.moves.includes("step_by_step")) {
    parts.push(core.map((s, i) => `${i + 1}. ${s}`).join("\n"));
  } else {
    parts.push(core.join(" "));
  }

  // Style-driven supplementary section chosen from the graph (contains-edges).
  const styles: Style[] = [policy.style, ...(policy.secondaryStyle ? [policy.secondaryStyle] : [])];
  const seen = new Set<string>();
  for (const st of styles) {
    const sec = styleSection(graph, concept, st);
    if (!sec || seen.has(sec.id)) continue;
    seen.add(sec.id);
    const text = sentences(graph.sourceText(sec.id)).slice(0, Math.max(1, Math.ceil(n / 2))).join(" ");
    if (!text) continue;
    const lead = st === "example-driven" ? "For example" : st === "analogy-based" ? "Think of it this way" : st === "technical" ? "More precisely" : st === "practical" ? "In practice" : "Concretely";
    parts.push(`${lead} — *${sec.label}*: ${text}`);
  }
  if (policy.moves.includes("use_analogy") && !seen.size) parts.push("Analogy: think of a limit as the destination you are heading toward, not the place you are standing.");

  // Socratic / comprehension move (Remember → Understand → Apply, by mastery).
  if (policy.moves.includes("socratic_question") || policy.moves.includes("check_understanding")) {
    const m = conceptState.mastery;
    const q = m < 0.4 ? `In one sentence, what does ${title(concept).toLowerCase()} describe?` : m < 0.8 ? `Can you explain in your own words why ${title(concept).toLowerCase()} works the way it does?` : `Where would you apply ${title(concept).toLowerCase()} in a problem you've seen before?`;
    parts.push(`Quick check: ${q}`);
  }
  if (policy.moves.includes("encourage")) parts.push("You're closer than it feels — this is a genuinely tricky spot.");

  // Related concepts, ordered by the path ranking (graph state influences what is offered).
  if (policy.moves.includes("offer_related") || policy.moves.includes("go_deeper") || policy.depth === "deep") {
    const next = r.ranked.filter((b) => graph.node(b.branch.to)?.node_kind === "page" || b.branch.edge.relation === "references").slice(0, 3);
    if (next.length) parts.push(`Related next: ${next.map((b) => `${title(graph.node(b.branch.to)!)}${b.dormant ? " (revisit)" : ""}`).join(", ")}.`);
  }
  if (policy.moves.includes("wrap_up")) parts.push("That's a good place to pause; we can pick this up again later.");
  return parts.filter(Boolean).join("\n\n");
}
