// MCP Streamable HTTP endpoint (spec 2025-03-26+) served by the official SDK's
// WebStandardStreamableHTTPServerTransport. Stateless mode: each request gets
// a fresh transport bound to the shared tutor server (no custom JSON protocol).
import { WebStandardStreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js";
import { createTutorMcpServer } from "@/mcp/server";
import { getRuntimeDeps } from "@/tutor/service";

export const dynamic = "force-dynamic";

function unauthorized() {
  return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { "content-type": "application/json" } });
}

async function handle(req: Request): Promise<Response> {
  const required = process.env.TUTOR_MCP_API_KEY;
  if (required) {
    const auth = req.headers.get("authorization") ?? "";
    const key = req.headers.get("x-api-key") ?? (auth.startsWith("Bearer ") ? auth.slice(7) : "");
    if (key !== required) return unauthorized();
  }
  const deps = await getRuntimeDeps();
  const server = createTutorMcpServer(deps);
  // Stateless + JSON response mode: the JSON-RPC result is fully produced before
  // handleRequest resolves, so the per-request server can be closed afterwards.
  const transport = new WebStandardStreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
  await server.connect(transport);
  try {
    return await transport.handleRequest(req);
  } finally {
    void server.close().catch(() => undefined);
  }
}

export const GET = handle;
export const POST = handle;
export const DELETE = handle;
