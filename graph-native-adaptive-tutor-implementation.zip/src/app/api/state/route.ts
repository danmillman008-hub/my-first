import { NextResponse } from "next/server";
import { getRuntimeDeps, learnerSnapshot } from "@/tutor/service";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const learnerId = url.searchParams.get("learnerId") ?? "local";
  if (!/^[\w.-]{1,64}$/.test(learnerId)) return NextResponse.json({ error: "bad learnerId" }, { status: 400 });
  const deps = await getRuntimeDeps();
  return NextResponse.json(await learnerSnapshot(deps, learnerId));
}
