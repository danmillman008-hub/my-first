import { NextResponse } from "next/server";
import { chatTurn, getRuntimeDeps } from "@/tutor/service";

export const dynamic = "force-dynamic";

const LEARNER_RE = /^[\w.-]{1,64}$/;

export async function POST(req: Request) {
  let body: { message?: unknown; learnerId?: unknown; conceptId?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "invalid JSON" }, { status: 400 });
  }
  const message = typeof body.message === "string" ? body.message.trim().slice(0, 4000) : "";
  if (!message) return NextResponse.json({ error: "message is required" }, { status: 400 });
  const learnerId = typeof body.learnerId === "string" && LEARNER_RE.test(body.learnerId) ? body.learnerId : "local";
  const conceptId = typeof body.conceptId === "string" ? body.conceptId : undefined;
  const deps = await getRuntimeDeps();
  const result = await chatTurn(deps, learnerId, message, undefined, conceptId);
  return NextResponse.json(result);
}
