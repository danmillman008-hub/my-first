import { TutorChat } from "./tutor-chat";

export default function Page() {
  return <TutorChat />;
}
