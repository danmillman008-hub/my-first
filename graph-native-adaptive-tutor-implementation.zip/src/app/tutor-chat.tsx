"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type Msg = { role: "tutor" | "learner"; text: string; meta?: string };
type Snapshot = {
  currentConcept: { label: string } | null;
  preferences: { depth: string; style: string };
  affect: { dominant: string };
  branches: { key: string; strength: number; dormant: boolean }[];
};

const LEARNER_KEY = "tutor.learnerId";

export function TutorChat() {
  const [learnerId, setLearnerId] = useState("local");
  const [messages, setMessages] = useState<Msg[]>([
    { role: "tutor", text: "Hi — I'm your adaptive tutor. Ask me about limits, derivatives, integrals, the chain rule, continuity, optimization or the fundamental theorem. I adapt depth, style and pacing as we go." },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [showState, setShowState] = useState(true);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let id = window.localStorage.getItem(LEARNER_KEY);
    if (!id) {
      id = `learner-${Math.random().toString(36).slice(2, 8)}`;
      window.localStorage.setItem(LEARNER_KEY, id);
    }
    setLearnerId(id);
  }, []);

  const refresh = useCallback(async (id: string) => {
    const res = await fetch(`/api/state?learnerId=${encodeURIComponent(id)}`, { cache: "no-store" });
    if (res.ok) setSnap((await res.json()) as Snapshot);
  }, []);

  useEffect(() => {
    if (learnerId) void refresh(learnerId);
  }, [learnerId, refresh]);

  useEffect(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), [messages]);

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    setBusy(true);
    setMessages((m) => [...m, { role: "learner", text }]);
    try {
      const res = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ message: text, learnerId }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "request failed");
      const meta = `${data.concept.label} · ${data.policy.depth} · ${data.policy.style} · ${data.affect}${data.reactivated?.length ? ` · reactivated ${data.reactivated.length}` : ""}`;
      setMessages((m) => [...m, { role: "tutor", text: data.reply, meta }]);
      void refresh(learnerId);
    } catch (e) {
      setMessages((m) => [...m, { role: "tutor", text: `Something went wrong: ${e instanceof Error ? e.message : "unknown error"}` }]);
    } finally {
      setBusy(false);
    }
  }

  const active = snap?.branches.filter((b) => !b.dormant).length ?? 0;
  const dormant = snap?.branches.filter((b) => b.dormant).length ?? 0;

  return (
    <main className="mx-auto flex h-dvh max-w-3xl flex-col p-3 sm:p-6">
      <header className="flex items-center justify-between border-b border-slate-300 pb-3">
        <h1 className="text-lg font-semibold">Adaptive Tutor</h1>
        <button onClick={() => setShowState((s) => !s)} className="text-xs text-slate-500 hover:text-slate-800">
          {showState ? "hide state" : "show state"}
        </button>
      </header>

      {showState && snap && (
        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-600">
          <span>Concept: <b>{snap.currentConcept?.label ?? "—"}</b></span>
          <span>Depth: <b>{snap.preferences.depth}</b></span>
          <span>Style: <b>{snap.preferences.style}</b></span>
          <span>State: <b>{snap.affect.dominant}</b></span>
          <span>Branches: <b>{active}</b> active / <b>{dormant}</b> dormant</span>
        </div>
      )}

      <section className="my-3 flex-1 space-y-3 overflow-y-auto rounded-lg bg-white p-4 shadow-sm">
        {messages.map((m, i) => (
          <div key={i} className={m.role === "learner" ? "flex justify-end" : "flex justify-start"}>
            <div className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2 text-sm leading-relaxed ${m.role === "learner" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-900"}`}>
              {m.text}
              {m.meta && <div className="mt-1 text-[10px] uppercase tracking-wide text-slate-400">{m.meta}</div>}
            </div>
          </div>
        ))}
        {busy && <div className="text-xs text-slate-400">thinking…</div>}
        <div ref={endRef} />
      </section>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          void send();
        }}
        className="flex gap-2"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask something..."
          className="flex-1 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-slate-500"
          autoFocus
        />
        <button type="submit" disabled={busy || !input.trim()} className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-40">
          Send
        </button>
      </form>
    </main>
  );
}
