// Thin READ-ONLY adapter over Graphify's canonical graph.json.
//
// Graphify (Python, NetworkX) owns extraction, building, clustering, export and
// the graph MCP server. This module only parses the node-link JSON that
// Graphify's `export.to_json` writes and exposes the two primitives the
// personalization layer needs: node lookup and 1-hop adjacency. It performs no
// search ranking, BFS/DFS or path-finding — those remain Graphify's
// (`query_graph`, `get_neighbors`, `shortest_path` via `graphify-mcp`).
import fs from "node:fs";
import path from "node:path";

export interface GraphifyNode {
  id: string;
  label: string;
  norm_label?: string;
  node_kind?: string; // "page" | "heading" | ...
  file_type?: string;
  source_file?: string;
  source_location?: string; // e.g. "L12"
  community?: number | null;
  community_name?: string;
}

export interface GraphifyEdge {
  source: string;
  target: string;
  relation: string;
  confidence?: string;
  confidence_score?: number;
  weight?: number;
}

export interface GraphifyBranch {
  key: string; // "<source>|<relation>|<target>"
  edge: GraphifyEdge;
  from: string;
  to: string; // neighbour reached from `from`
}

interface NodeLinkFile {
  nodes: GraphifyNode[];
  links?: GraphifyEdge[];
  edges?: GraphifyEdge[];
}

export const branchKey = (e: GraphifyEdge): string => `${e.source}|${e.relation}|${e.target}`;

export function parseBranchKey(key: string): { source: string; relation: string; target: string } | null {
  const parts = key.split("|");
  if (parts.length !== 3) return null;
  return { source: parts[0], relation: parts[1], target: parts[2] };
}

export class GraphifyGraph {
  private nodes = new Map<string, GraphifyNode>();
  private adjacency = new Map<string, GraphifyBranch[]>();
  private edgesByKey = new Map<string, GraphifyEdge>();
  private byNormLabel = new Map<string, string[]>();

  constructor(
    data: NodeLinkFile,
    private readonly corpusRoot?: string,
  ) {
    for (const n of data.nodes) {
      this.nodes.set(n.id, n);
      const norm = (n.norm_label ?? n.label ?? "").toLowerCase();
      const list = this.byNormLabel.get(norm) ?? [];
      list.push(n.id);
      this.byNormLabel.set(norm, list);
    }
    for (const e of data.links ?? data.edges ?? []) {
      const key = branchKey(e);
      this.edgesByKey.set(key, e);
      this.push(e.source, { key, edge: e, from: e.source, to: e.target });
      this.push(e.target, { key, edge: e, from: e.target, to: e.source });
    }
  }

  private push(id: string, b: GraphifyBranch) {
    const list = this.adjacency.get(id) ?? [];
    list.push(b);
    this.adjacency.set(id, list);
  }

  static load(graphPath: string, corpusRoot?: string): GraphifyGraph {
    const raw = fs.readFileSync(graphPath, "utf-8");
    return new GraphifyGraph(JSON.parse(raw) as NodeLinkFile, corpusRoot);
  }

  get size() {
    return { nodes: this.nodes.size, edges: this.edgesByKey.size };
  }

  node(id: string): GraphifyNode | undefined {
    return this.nodes.get(id);
  }

  allNodes(): GraphifyNode[] {
    return [...this.nodes.values()];
  }

  edge(key: string): GraphifyEdge | undefined {
    return this.edgesByKey.get(key);
  }

  allEdges(): GraphifyEdge[] {
    return [...this.edgesByKey.values()];
  }

  /** Branches (Graphify edges) incident to a node, oriented away from it. */
  branches(id: string): GraphifyBranch[] {
    return this.adjacency.get(id) ?? [];
  }

  neighbors(id: string): GraphifyNode[] {
    return this.branches(id)
      .map((b) => this.nodes.get(b.to))
      .filter((n): n is GraphifyNode => Boolean(n));
  }

  /**
   * Resolve the concept a free-text message talks about, using Graphify's own
   * `norm_label` field. Longest matching label wins; "page" nodes are
   * preferred over their identically named top-level heading nodes.
   */
  resolveConcept(text: string): GraphifyNode | undefined {
    const hay = ` ${text.toLowerCase().replace(/[^a-z0-9\s-]/g, " ")} `;
    let best: GraphifyNode | undefined;
    let bestLen = 0;
    for (const n of this.nodes.values()) {
      const label = (n.norm_label ?? n.label).toLowerCase().replace(/\.md$/, "").replace(/[-_]+/g, " ").trim();
      if (label.length < 4) continue;
      const variants = [label, label.endsWith("s") ? label.slice(0, -1) : `${label}s`];
      for (const v of variants) {
        if (hay.includes(` ${v} `)) {
          const score = v.length + (n.node_kind === "page" ? 0.5 : 0);
          if (score > bestLen) {
            bestLen = score;
            best = n;
          }
        }
      }
    }
    return best;
  }

  /** The section of source material a node was extracted from (file-driven teaching). */
  sourceText(id: string, maxChars = 900): string {
    const n = this.nodes.get(id);
    if (!n?.source_file || !this.corpusRoot) return "";
    const file = path.join(this.corpusRoot, n.source_file);
    if (!fs.existsSync(file)) return "";
    const lines = fs.readFileSync(file, "utf-8").split("\n");
    const start = Math.max(0, Number((n.source_location ?? "L1").replace(/^L/, "")) - 1);
    const startLevel = headingLevel(lines[start]) || 1;
    const out: string[] = [];
    for (let i = start + 1; i < lines.length; i++) {
      const lvl = headingLevel(lines[i]);
      if (lvl && lvl <= startLevel) break;
      if (lvl) continue; // skip nested heading lines for page nodes
      out.push(lines[i]);
    }
    return out.join("\n").replace(/\[\[([^\]|]+)(\|([^\]]+))?\]\]/g, (_m, a, _b, c) => c ?? a).trim().slice(0, maxChars);
  }
}

function headingLevel(line: string | undefined): number {
  const m = /^(#{1,6})\s/.exec(line ?? "");
  return m ? m[1].length : 0;
}

let cached: GraphifyGraph | undefined;

/** Process-wide cached graph (graph.json is immutable at runtime for the tutor). */
export function getGraph(): GraphifyGraph {
  if (cached) return cached;
  const root = process.cwd();
  const graphPath = process.env.GRAPHIFY_GRAPH ?? path.join(root, process.env.GRAPHIFY_OUT ?? "graphify-out", "graph.json");
  const corpus = process.env.TUTOR_CORPUS ?? path.join(root, "corpus");
  cached = GraphifyGraph.load(graphPath, corpus);
  return cached;
}
