// Personalization OVERLAY only.
//
// The knowledge graph itself (nodes, edges, communities) lives in Graphify's
// canonical graphify-out/graph.json and is never duplicated here. Every row
// below references Graphify identifiers:
//   - concept_id  == Graphify node id
//   - branch_key  == "<source>|<relation>|<target>" of a Graphify edge
import {
  boolean,
  doublePrecision,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const tutorLearners = pgTable("tutor_learners", {
  id: text("id").primaryKey(),
  // Belief distributions over depth / style, plus affect state (small JSON).
  depthBelief: jsonb("depth_belief").notNull(),
  styleBelief: jsonb("style_belief").notNull(),
  affect: jsonb("affect").notNull(),
  currentConceptId: text("current_concept_id"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const tutorInteractions = pgTable("tutor_interactions", {
  id: serial("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  conceptId: text("concept_id"),
  branchKey: text("branch_key"),
  messageLength: integer("message_length").notNull(),
  // Detected evidence signals (e.g. ["simplify","example","confusion"]).
  signals: jsonb("signals").notNull(),
  depthUsed: text("depth_used").notNull(),
  styleUsed: text("style_used").notNull(),
  outcome: text("outcome").notNull(),
  followUpIndex: integer("follow_up_index").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const tutorConceptState = pgTable(
  "tutor_concept_state",
  {
    learnerId: text("learner_id").notNull(),
    conceptId: text("concept_id").notNull(),
    mastery: doublePrecision("mastery").notNull().default(0),
    exposures: integer("exposures").notNull().default(0),
    confusions: integer("confusions").notNull().default(0),
    successes: integer("successes").notNull().default(0),
    // Locally learned style preference for this concept (cautiously propagated).
    styleBias: jsonb("style_bias").notNull(),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull(),
  },
  (t) => [primaryKey({ columns: [t.learnerId, t.conceptId] })],
);

export const tutorBranchState = pgTable(
  "tutor_branch_state",
  {
    learnerId: text("learner_id").notNull(),
    branchKey: text("branch_key").notNull(),
    strength: doublePrecision("strength").notNull(),
    successes: integer("successes").notNull().default(0),
    uses: integer("uses").notNull().default(0),
    dormant: boolean("dormant").notNull().default(false),
    reactivations: integer("reactivations").notNull().default(0),
    lastReinforcedAt: timestamp("last_reinforced_at", { withTimezone: true }).notNull(),
  },
  (t) => [primaryKey({ columns: [t.learnerId, t.branchKey] })],
);
