// Thin MCP adapter for the adaptive tutor (official @modelcontextprotocol/sdk).
//
// Contains NO graph or personalization logic: every tool/resource/prompt is a
// one-line delegation to the tutor service or the Graphify adapter. Graph
// queries proper (search, traversal, shortest paths) stay with Graphify's own
// MCP server (`python -m graphify.serve graphify-out/graph.json`).
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { ResourceTemplate } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { chatTurn, learnerSnapshot, reactivateBranch, runDecay, type TutorDeps } from "@/tutor/service";
import { parseBranchKey } from "@/graphify/adapter";

const json = (v: unknown) => ({ content: [{ type: "text" as const, text: JSON.stringify(v, null, 2) }] });
const DEFAULT_LEARNER = process.env.TUTOR_DEFAULT_LEARNER ?? "local";

export function createTutorMcpServer(deps: TutorDeps): McpServer {
  const server = new McpServer({ name: "adaptive-tutor", version: "0.1.0" });
  const learnerArg = z.string().min(1).max(64).regex(/^[\w.-]+$/).default(DEFAULT_LEARNER).describe("Learner id");

  // ---- read tools -----------------------------------------------------------
  server.registerTool(
    "get_learning_state",
    { description: "Graph-native personalised state: preferences, affect, concept mastery, branch strengths/dormancy and ranked next branches.", inputSchema: { learnerId: learnerArg } },
    async ({ learnerId }) => json(await learnerSnapshot(deps, learnerId)),
  );
  server.registerTool(
    "get_concept",
    { description: "A Graphify concept node with its incident branches (from graphify-out/graph.json).", inputSchema: { conceptId: z.string() } },
    async ({ conceptId }) => {
      const node = deps.graph.node(conceptId);
      if (!node) return { isError: true, content: [{ type: "text", text: `Unknown concept: ${conceptId}` }] };
      return json({ node, branches: deps.graph.branches(conceptId).map((b) => ({ key: b.key, relation: b.edge.relation, to: b.to })), sourceExcerpt: deps.graph.sourceText(conceptId, 400) });
    },
  );
  server.registerTool(
    "get_related_concepts",
    { description: "1-hop neighbours of a concept, ranked by the learner's branch state (strength, success, recency, affect).", inputSchema: { conceptId: z.string(), learnerId: learnerArg } },
    async ({ conceptId, learnerId }) => {
      if (!deps.graph.node(conceptId)) return { isError: true, content: [{ type: "text", text: `Unknown concept: ${conceptId}` }] };
      const snap = await learnerSnapshot(deps, learnerId);
      const strengths = new Map(snap.branches.map((b) => [b.key, b]));
      return json(deps.graph.branches(conceptId).map((b) => ({ key: b.key, to: b.to, label: deps.graph.node(b.to)?.label, relation: b.edge.relation, state: strengths.get(b.key) ?? null })));
    },
  );
  server.registerTool(
    "get_current_policy",
    { description: "Current explanation policy inputs for the learner (depth, style, affect, current concept).", inputSchema: { learnerId: learnerArg } },
    async ({ learnerId }) => {
      const s = await learnerSnapshot(deps, learnerId);
      return json({ currentConcept: s.currentConcept, depth: s.preferences.depth, style: s.preferences.style, affect: s.affect.dominant, nextBranches: s.nextBranches });
    },
  );

  // ---- safe mutation tools (only through the engine) ------------------------
  server.registerTool(
    "record_interaction",
    { description: "Run one adaptive tutor turn for a learner message. Updates preferences, affect, mastery and branch state and returns the tutor reply + policy.", inputSchema: { message: z.string().min(1).max(4000), learnerId: learnerArg, conceptId: z.string().optional() } },
    async ({ message, learnerId, conceptId }) => json(await chatTurn(deps, learnerId, message, undefined, conceptId)),
  );
  server.registerTool(
    "reactivate_branch",
    { description: "Explicitly reactivate a (possibly dormant) branch, identified by its Graphify edge key '<source>|<relation>|<target>'.", inputSchema: { branchKey: z.string(), learnerId: learnerArg } },
    async ({ branchKey, learnerId }) => {
      const parsed = parseBranchKey(branchKey);
      if (!parsed || !deps.graph.edge(branchKey)) return { isError: true, content: [{ type: "text", text: `Unknown branch: ${branchKey}` }] };
      return json(await reactivateBranch(deps.store, learnerId, branchKey));
    },
  );
  server.registerTool(
    "apply_decay",
    { description: "Materialise time decay/dormancy for all of a learner's branches (idempotent maintenance).", inputSchema: { learnerId: learnerArg } },
    async ({ learnerId }) => json(await runDecay(deps.store, learnerId)),
  );

  // ---- resources ------------------------------------------------------------
  server.registerResource("learner-state", `user://${DEFAULT_LEARNER}/state`, { description: "Personalised learner state", mimeType: "application/json" }, async (uri) => ({
    contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify(await learnerSnapshot(deps, DEFAULT_LEARNER), null, 2) }],
  }));
  server.registerResource(
    "concept",
    new ResourceTemplate("graph://concept/{id}", { list: async () => ({ resources: deps.graph.allNodes().map((n) => ({ uri: `graph://concept/${n.id}`, name: n.label, mimeType: "application/json" })) }) }),
    { description: "Graphify concept node" },
    async (uri, { id }) => {
      const node = deps.graph.node(String(id));
      return { contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify(node ? { node, branches: deps.graph.branches(node.id).map((b) => b.key) } : { error: "not found" }) }] };
    },
  );

  // ---- prompts --------------------------------------------------------------
  server.registerPrompt(
    "explain_current_concept",
    { description: "Explain the learner's current concept using their learned depth/style/affect policy.", argsSchema: { learnerId: z.string().optional() } },
    async ({ learnerId }) => {
      const s = await learnerSnapshot(deps, learnerId ?? DEFAULT_LEARNER);
      return {
        messages: [{ role: "user", content: { type: "text", text: `Explain "${s.currentConcept?.label ?? "the first concept"}" at ${s.preferences.depth} depth in a ${s.preferences.style} style. Learner state: ${s.affect.dominant}. Offer these related concepts next: ${s.nextBranches.map((b) => b.to).join(", ") || "none"}.` } }],
      };
    },
  );
  return server;
}
