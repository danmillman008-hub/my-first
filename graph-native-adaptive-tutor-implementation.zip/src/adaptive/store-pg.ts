// Drizzle/PostgreSQL implementation of TutorStore (overlay tables only).
import { and, desc, eq, sql } from "drizzle-orm";
import type { NodePgDatabase } from "drizzle-orm/node-postgres";
import { tutorBranchState, tutorConceptState, tutorInteractions, tutorLearners } from "@/db/schema";
import type { TutorStore } from "./store";
import type { Affect, Belief, BranchState, ConceptState, Depth, InteractionRecord, LearnerState, Outcome, Signal, Style } from "./types";

export class PgStore implements TutorStore {
  constructor(private readonly db: NodePgDatabase) {}

  async getLearner(id: string): Promise<LearnerState | null> {
    const [row] = await this.db.select().from(tutorLearners).where(eq(tutorLearners.id, id)).limit(1);
    if (!row) return null;
    return {
      id: row.id,
      depth: row.depthBelief as Belief<Depth>,
      style: row.styleBelief as Belief<Style>,
      affect: row.affect as LearnerState["affect"],
      currentConceptId: row.currentConceptId,
    };
  }

  async saveLearner(s: LearnerState) {
    await this.db
      .insert(tutorLearners)
      .values({ id: s.id, depthBelief: s.depth, styleBelief: s.style, affect: s.affect, currentConceptId: s.currentConceptId, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: tutorLearners.id,
        set: { depthBelief: s.depth, styleBelief: s.style, affect: s.affect, currentConceptId: s.currentConceptId, updatedAt: new Date() },
      });
  }

  async getConceptStates(learnerId: string): Promise<ConceptState[]> {
    const rows = await this.db.select().from(tutorConceptState).where(eq(tutorConceptState.learnerId, learnerId));
    return rows.map((r) => ({
      conceptId: r.conceptId,
      mastery: r.mastery,
      exposures: r.exposures,
      confusions: r.confusions,
      successes: r.successes,
      styleBias: r.styleBias as Partial<Belief<Style>>,
      lastSeenAt: r.lastSeenAt.getTime(),
    }));
  }

  async saveConceptStates(learnerId: string, states: ConceptState[]) {
    for (const c of states) {
      const values = {
        learnerId,
        conceptId: c.conceptId,
        mastery: c.mastery,
        exposures: c.exposures,
        confusions: c.confusions,
        successes: c.successes,
        styleBias: c.styleBias,
        lastSeenAt: new Date(c.lastSeenAt),
      };
      await this.db
        .insert(tutorConceptState)
        .values(values)
        .onConflictDoUpdate({ target: [tutorConceptState.learnerId, tutorConceptState.conceptId], set: values });
    }
  }

  async getBranchStates(learnerId: string): Promise<BranchState[]> {
    const rows = await this.db.select().from(tutorBranchState).where(eq(tutorBranchState.learnerId, learnerId));
    return rows.map((r) => ({
      branchKey: r.branchKey,
      strength: r.strength,
      successes: r.successes,
      uses: r.uses,
      dormant: r.dormant,
      reactivations: r.reactivations,
      lastReinforcedAt: r.lastReinforcedAt.getTime(),
    }));
  }

  async saveBranchStates(learnerId: string, states: BranchState[]) {
    for (const b of states) {
      const values = {
        learnerId,
        branchKey: b.branchKey,
        strength: b.strength,
        successes: b.successes,
        uses: b.uses,
        dormant: b.dormant,
        reactivations: b.reactivations,
        lastReinforcedAt: new Date(b.lastReinforcedAt),
      };
      await this.db
        .insert(tutorBranchState)
        .values(values)
        .onConflictDoUpdate({ target: [tutorBranchState.learnerId, tutorBranchState.branchKey], set: values });
    }
  }

  async addInteraction(r: InteractionRecord) {
    await this.db.insert(tutorInteractions).values({
      learnerId: r.learnerId,
      conceptId: r.conceptId,
      branchKey: r.branchKey,
      messageLength: r.messageLength,
      signals: r.signals,
      depthUsed: r.depthUsed,
      styleUsed: r.styleUsed,
      outcome: r.outcome,
      followUpIndex: r.followUpIndex,
      createdAt: new Date(r.createdAt),
    });
  }

  async recentInteractions(learnerId: string, limit: number): Promise<InteractionRecord[]> {
    const rows = await this.db
      .select()
      .from(tutorInteractions)
      .where(and(eq(tutorInteractions.learnerId, learnerId), sql`true`))
      .orderBy(desc(tutorInteractions.createdAt), desc(tutorInteractions.id))
      .limit(limit);
    return rows.map((r) => ({
      learnerId: r.learnerId,
      conceptId: r.conceptId,
      branchKey: r.branchKey,
      messageLength: r.messageLength,
      signals: r.signals as Signal[],
      depthUsed: r.depthUsed as Depth,
      styleUsed: r.styleUsed as Style,
      outcome: r.outcome as Outcome,
      followUpIndex: r.followUpIndex,
      createdAt: r.createdAt.getTime(),
    }));
  }
}

export type { Affect };
