// Explanation-path selection: rank the Graphify branches leaving the current
// concept using graph relevance, branch strength, previous success, recency,
// learner mastery and affect. The candidate set comes straight from Graphify
// adjacency; this module only scores it.
import type { GraphifyBranch } from "@/graphify/adapter";
import { effectiveStrength, successRate } from "./branches";
import type { Affect, BranchState, ConceptState } from "./types";

const RELATION_PRIOR: Record<string, number> = { references: 1, contains: 0.75 };

export interface RankedBranch {
  branch: GraphifyBranch;
  state: BranchState | null;
  score: number;
  effectiveStrength: number;
  dormant: boolean;
  reasons: string[];
}

export function rankBranches(
  candidates: GraphifyBranch[],
  branchStates: Map<string, BranchState>,
  conceptStates: Map<string, ConceptState>,
  affect: Affect,
  now: number,
): RankedBranch[] {
  const ranked = candidates.map((branch) => {
    const state = branchStates.get(branch.key) ?? null;
    const reasons: string[] = [];
    const relevance = (RELATION_PRIOR[branch.edge.relation] ?? 0.6) * (branch.edge.confidence_score ?? 1) * (branch.edge.weight ?? 1);
    const eff = state ? effectiveStrength(state, now) : 0;
    const success = state ? successRate(state) : 0.5;
    const recency = state ? Math.exp(-(now - state.lastReinforcedAt) / (3 * 24 * 3600 * 1000)) : 0;
    const targetMastery = conceptStates.get(branch.to)?.mastery ?? 0;

    let score = 0.35 * relevance + 0.3 * eff + 0.15 * success + 0.1 * recency;
    reasons.push(`relevance=${relevance.toFixed(2)}`, `strength=${eff.toFixed(2)}`, `success=${success.toFixed(2)}`);
    if (affect === "curious" && !state) ((score += 0.15), reasons.push("curious → unexplored bonus"));
    if (affect === "confused" && targetMastery > 0.5) ((score += 0.15), reasons.push("confused → prefer a mastered neighbour as anchor"));
    if ((affect === "bored" || affect === "engaged") && targetMastery < 0.4) ((score += 0.1), reasons.push("ready for something new"));
    if (state?.dormant) ((score -= 0.1), reasons.push("dormant (reactivatable)"));
    return { branch, state, score, effectiveStrength: eff, dormant: Boolean(state?.dormant), reasons };
  });
  return ranked.sort((a, b) => b.score - a.score || a.branch.key.localeCompare(b.branch.key));
}
