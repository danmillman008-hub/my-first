// Persistence boundary for the overlay state. The graph is NOT stored here.
import type { BranchState, ConceptState, InteractionRecord, LearnerState } from "./types";

export interface TutorStore {
  getLearner(id: string): Promise<LearnerState | null>;
  saveLearner(state: LearnerState): Promise<void>;
  getConceptStates(learnerId: string): Promise<ConceptState[]>;
  saveConceptStates(learnerId: string, states: ConceptState[]): Promise<void>;
  getBranchStates(learnerId: string): Promise<BranchState[]>;
  saveBranchStates(learnerId: string, states: BranchState[]): Promise<void>;
  addInteraction(record: InteractionRecord): Promise<void>;
  recentInteractions(learnerId: string, limit: number): Promise<InteractionRecord[]>;
}

export class MemoryStore implements TutorStore {
  learners = new Map<string, LearnerState>();
  concepts = new Map<string, Map<string, ConceptState>>();
  branches = new Map<string, Map<string, BranchState>>();
  interactions: InteractionRecord[] = [];

  async getLearner(id: string) {
    return this.learners.get(id) ?? null;
  }
  async saveLearner(state: LearnerState) {
    this.learners.set(state.id, structuredClone(state));
  }
  async getConceptStates(learnerId: string) {
    return [...(this.concepts.get(learnerId)?.values() ?? [])].map((c) => structuredClone(c));
  }
  async saveConceptStates(learnerId: string, states: ConceptState[]) {
    const m = this.concepts.get(learnerId) ?? new Map();
    for (const s of states) m.set(s.conceptId, structuredClone(s));
    this.concepts.set(learnerId, m);
  }
  async getBranchStates(learnerId: string) {
    return [...(this.branches.get(learnerId)?.values() ?? [])].map((b) => structuredClone(b));
  }
  async saveBranchStates(learnerId: string, states: BranchState[]) {
    const m = this.branches.get(learnerId) ?? new Map();
    for (const s of states) m.set(s.branchKey, structuredClone(s));
    this.branches.set(learnerId, m);
  }
  async addInteraction(record: InteractionRecord) {
    this.interactions.push(structuredClone(record));
  }
  async recentInteractions(learnerId: string, limit: number) {
    return this.interactions.filter((i) => i.learnerId === learnerId).slice(-limit).reverse();
  }
}
