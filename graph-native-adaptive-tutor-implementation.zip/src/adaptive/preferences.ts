// Lightweight, explainable belief updates for explanation depth and style.
//
// Each interaction produces a small "target" vector from its signals. The
// belief moves a fixed fraction (rate) toward that target, so a single message
// nudges the belief while repeated signals shift it decisively.
import { type Belief, type Depth, DEPTHS, type Style, STYLES, normalize, type Signal } from "./types";

const DEPTH_RATE = 0.28;
const STYLE_RATE = 0.22;

const shift = (d: Depth, by: number): Depth => DEPTHS[Math.min(DEPTHS.length - 1, Math.max(0, DEPTHS.indexOf(d) + by))];

export function depthTarget(signals: Signal[], depthUsed: Depth): Partial<Belief<Depth>> {
  const t: Partial<Belief<Depth>> = {};
  const has = (s: Signal) => signals.includes(s);
  const add = (d: Depth, w: number) => (t[d] = (t[d] ?? 0) + w);
  if (has("simplify") || has("short_message")) add(shift(depthUsed, -1), 1);
  if (has("confusion")) add(shift(depthUsed, -1), 0.6);
  if (has("more_detail") || has("technical")) add(shift(depthUsed, +1), 1);
  if (has("curiosity") || has("long_message")) add(shift(depthUsed, +1), 0.5);
  if (has("boredom")) add(shift(depthUsed, -1), 0.4); // bored => shorter, faster
  if (has("acknowledge") || has("continue")) add(depthUsed, 0.7); // the used depth worked
  return t;
}

export function styleTarget(signals: Signal[], styleUsed: Style): Partial<Belief<Style>> {
  const t: Partial<Belief<Style>> = {};
  const has = (s: Signal) => signals.includes(s);
  const add = (s: Style, w: number) => (t[s] = (t[s] ?? 0) + w);
  if (has("example")) add("example-driven", 1);
  if (has("analogy")) add("analogy-based", 1);
  if (has("steps")) add("step-by-step", 1);
  if (has("practical")) add("practical", 1);
  if (has("technical") || has("more_detail")) add("technical", 0.6);
  if (has("confusion")) {
    add("example-driven", 0.4);
    add("step-by-step", 0.4);
  }
  if (has("simplify")) add("analogy-based", 0.3);
  if (has("acknowledge") || has("continue")) add(styleUsed, 0.7);
  return t;
}

export function updateBelief<T extends string>(belief: Belief<T>, target: Partial<Belief<T>>, rate: number): Belief<T> {
  const mass = Object.values<number | undefined>(target).reduce<number>((s, v) => s + (v ?? 0), 0);
  if (mass <= 0) return belief;
  const next = { ...belief } as Belief<T>;
  for (const k of Object.keys(belief) as T[]) {
    const tgt = (target[k] ?? 0) / mass;
    next[k] = (1 - rate) * belief[k] + rate * tgt;
  }
  return normalize(next);
}

export const updateDepth = (b: Belief<Depth>, signals: Signal[], used: Depth) => updateBelief(b, depthTarget(signals, used), DEPTH_RATE);
export const updateStyle = (b: Belief<Style>, signals: Signal[], used: Style) => updateBelief(b, styleTarget(signals, used), STYLE_RATE);

/** Blend the global style belief with a concept-local bias (local wins modestly). */
export function effectiveStyle(global: Belief<Style>, local: Partial<Belief<Style>>): Belief<Style> {
  const out = { ...global };
  for (const s of STYLES) out[s] = global[s] + 0.5 * (local[s] ?? 0);
  return normalize(out);
}

/** Cautious propagation: a fraction of the local style evidence flows to neighbours. */
export function propagateStyleBias(target: Partial<Belief<Style>>, factor = 0.3): Partial<Belief<Style>> {
  const out: Partial<Belief<Style>> = {};
  for (const [k, v] of Object.entries(target) as [Style, number][]) if (v > 0) out[k] = v * factor;
  return out;
}

export function mergeBias(existing: Partial<Belief<Style>>, delta: Partial<Belief<Style>>, cap = 1): Partial<Belief<Style>> {
  const out = { ...existing };
  for (const [k, v] of Object.entries(delta) as [Style, number][]) out[k] = Math.min(cap, (out[k] ?? 0) * 0.85 + v);
  return out;
}
