// One adaptive interaction step. Pure with respect to time (clock injected);
// all persistence goes through TutorStore, all graph reads through the
// Graphify adapter.
import type { GraphifyBranch, GraphifyGraph, GraphifyNode } from "@/graphify/adapter";
import { updateAffect } from "./affect";
import { applyDecay, newBranchState, newConceptState, reactivate, reinforce, updateMastery } from "./branches";
import { rankBranches, type RankedBranch } from "./paths";
import { decidePolicy } from "./policy";
import { effectiveStyle, mergeBias, propagateStyleBias, styleTarget, updateDepth, updateStyle } from "./preferences";
import { detectSignals, inferOutcome } from "./signals";
import type { TutorStore } from "./store";
import type { BranchState, ConceptState, InteractionRecord, LearnerState, Outcome, Policy, Signal } from "./types";
import { initialLearner } from "./types";

export interface StepResult {
  learner: LearnerState;
  concept: GraphifyNode;
  conceptState: ConceptState;
  policy: Policy;
  signals: Signal[];
  outcome: Outcome; // outcome inferred for the PREVIOUS explanation
  branchUsed: GraphifyBranch | null;
  ranked: RankedBranch[]; // candidate next branches, best first
  reactivated: string[]; // branch keys reactivated this step
  followUpIndex: number;
}

export interface StepOptions {
  graph: GraphifyGraph;
  store: TutorStore;
  learnerId: string;
  message: string;
  now?: number;
  /** Explicit concept override (e.g. UI click). Otherwise resolved from the message. */
  conceptId?: string;
}

const NAV_SIGNALS: Signal[] = ["curiosity", "boredom"];

export async function stepInteraction(o: StepOptions): Promise<StepResult> {
  const now = o.now ?? Date.now();
  const { graph, store, learnerId } = o;
  const learner = (await store.getLearner(learnerId)) ?? initialLearner(learnerId);
  const signals = detectSignals(o.message);
  const conceptStates = new Map((await store.getConceptStates(learnerId)).map((c) => [c.conceptId, c]));
  const branchStates = new Map((await store.getBranchStates(learnerId)).map((b) => [b.branchKey, b]));
  const [prev] = await store.recentInteractions(learnerId, 1);

  // 1. Time passes: fold decay into every branch (deterministic, monotonic).
  for (const [k, b] of branchStates) branchStates.set(k, applyDecay(b, now));

  // 2. Resolve the concept + the Graphify branch used to get there.
  const current = learner.currentConceptId ? graph.node(learner.currentConceptId) : undefined;
  let concept = o.conceptId ? graph.node(o.conceptId) : graph.resolveConcept(o.message);
  let branchUsed: GraphifyBranch | null = null;
  if (!concept && current) {
    const wantsMove = signals.some((s) => NAV_SIGNALS.includes(s)) && !signals.includes("confusion");
    if (wantsMove) {
      const best = rankBranches(graph.branches(current.id), branchStates, conceptStates, learner.affect.dominant, now)[0];
      if (best) ((concept = graph.node(best.branch.to)), (branchUsed = best.branch));
    }
    concept ??= current;
  }
  concept ??= graph.allNodes().find((n) => n.node_kind === "page") ?? graph.allNodes()[0];
  if (!branchUsed && current && concept.id !== current.id) branchUsed = graph.branches(current.id).find((b) => b.to === concept!.id) ?? null;

  const sameConcept = current?.id === concept.id;
  const followUpIndex = sameConcept && prev?.conceptId === concept.id ? prev.followUpIndex + 1 : 0;
  const outcome = inferOutcome(signals, sameConcept);

  // 3. Learn from the previous explanation's outcome.
  let depth = learner.depth;
  let style = learner.style;
  if (prev) {
    depth = updateDepth(depth, signals, prev.depthUsed);
    style = updateStyle(style, signals, prev.styleUsed);
    if (prev.conceptId) {
      const pc = conceptStates.get(prev.conceptId) ?? newConceptState(prev.conceptId, now);
      conceptStates.set(prev.conceptId, updateMastery(pc, outcome, now));
    }
    if (prev.branchKey) {
      const pb = branchStates.get(prev.branchKey) ?? newBranchState(prev.branchKey, now);
      branchStates.set(prev.branchKey, reinforce(pb, now, outcome));
    }
  }

  // 4. Branch dynamics for this step: traversal reinforces; returning to a concept
  //    reactivates its dormant branches (relevance-driven reactivation).
  const reactivated: string[] = [];
  if (branchUsed) {
    const b = branchStates.get(branchUsed.key) ?? newBranchState(branchUsed.key, now);
    if (b.dormant) reactivated.push(b.branchKey);
    branchStates.set(branchUsed.key, reinforce(b, now, "explored"));
  }
  for (const b of graph.branches(concept.id)) {
    const st = branchStates.get(b.key);
    if (st?.dormant && !reactivated.includes(b.key)) {
      branchStates.set(b.key, reactivate(st, now));
      reactivated.push(b.key);
    }
  }

  // 5. Affect + concept-local style bias (with cautious propagation to neighbours).
  const affect = updateAffect(learner.affect, signals);
  const conceptState = conceptStates.get(concept.id) ?? newConceptState(concept.id, now);
  const localTarget = styleTarget(signals, prev?.styleUsed ?? "conceptual");
  if (Object.keys(localTarget).length) {
    conceptState.styleBias = mergeBias(conceptState.styleBias, localTarget);
    const spill = propagateStyleBias(localTarget);
    for (const nb of graph.neighbors(concept.id)) {
      const ns = conceptStates.get(nb.id) ?? newConceptState(nb.id, now);
      ns.styleBias = mergeBias(ns.styleBias, spill);
      conceptStates.set(nb.id, ns);
    }
  }
  conceptState.exposures += 0; // exposure counted when outcome arrives (next turn)
  conceptState.lastSeenAt = now;
  conceptStates.set(concept.id, conceptState);

  // 6. Policy from composed state.
  const policy = decidePolicy({
    depthBelief: depth,
    styleBelief: effectiveStyle(style, conceptState.styleBias),
    affect: affect.dominant,
    affectScores: affect.scores,
    mastery: conceptState.mastery,
    exposures: conceptState.exposures,
    followUpIndex,
    signals,
    branch: branchUsed ? (branchStates.get(branchUsed.key) ?? null) : null,
    now,
  });

  // 7. Candidate next paths.
  const ranked = rankBranches(graph.branches(concept.id), branchStates, conceptStates, affect.dominant, now);

  // 8. Persist evidence + state.
  const record: InteractionRecord = {
    learnerId,
    conceptId: concept.id,
    branchKey: branchUsed?.key ?? null,
    messageLength: o.message.length,
    signals,
    depthUsed: policy.depth,
    styleUsed: policy.style,
    outcome,
    followUpIndex,
    createdAt: now,
  };
  const nextLearner: LearnerState = { id: learnerId, depth, style, affect, currentConceptId: concept.id };
  await store.saveLearner(nextLearner);
  await store.saveConceptStates(learnerId, [...conceptStates.values()]);
  await store.saveBranchStates(learnerId, [...branchStates.values()]);
  await store.addInteraction(record);

  return { learner: nextLearner, concept, conceptState, policy, signals, outcome, branchUsed, ranked, reactivated, followUpIndex };
}

/** Maintenance: materialise decay/dormancy for all branches at `now` (no interaction). */
export async function runDecay(store: TutorStore, learnerId: string, now = Date.now()): Promise<BranchState[]> {
  const decayed = (await store.getBranchStates(learnerId)).map((b) => applyDecay(b, now));
  await store.saveBranchStates(learnerId, decayed);
  return decayed;
}

/** Explicit reactivation of one branch (used by the safe MCP mutation). */
export async function reactivateBranch(store: TutorStore, learnerId: string, branchKey: string, now = Date.now()): Promise<BranchState> {
  const existing = (await store.getBranchStates(learnerId)).find((b) => b.branchKey === branchKey) ?? newBranchState(branchKey, now);
  const next = reactivate(existing, now);
  await store.saveBranchStates(learnerId, [next]);
  return next;
}
