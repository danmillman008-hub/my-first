// Shared types for the adaptive personalization layer.
// Concept ids and branch keys always refer to Graphify nodes / edges.

export const DEPTHS = ["concise", "standard", "detailed", "deep"] as const;
export type Depth = (typeof DEPTHS)[number];

export const STYLES = [
  "conceptual",
  "practical",
  "example-driven",
  "analogy-based",
  "step-by-step",
  "technical",
] as const;
export type Style = (typeof STYLES)[number];

export const AFFECTS = [
  "engaged",
  "curious",
  "confused",
  "hesitant",
  "frustrated",
  "bored",
  "fatigued",
  "neutral",
] as const;
export type Affect = (typeof AFFECTS)[number];

/** Rough evidence signals detected from a single learner message. */
export type Signal =
  | "simplify"
  | "more_detail"
  | "example"
  | "analogy"
  | "steps"
  | "practical"
  | "technical"
  | "confusion"
  | "curiosity"
  | "hesitation"
  | "frustration"
  | "boredom"
  | "fatigue"
  | "acknowledge"
  | "continue"
  | "reject"
  | "short_message"
  | "long_message"
  | "repeat"
  | "question";

export type Outcome = "continued" | "clarified" | "confused" | "accepted" | "rejected" | "explored";

export type Belief<T extends string> = Record<T, number>;

export interface AffectState {
  scores: Belief<Affect>;
  dominant: Affect;
}

export interface LearnerState {
  id: string;
  depth: Belief<Depth>;
  style: Belief<Style>;
  affect: AffectState;
  currentConceptId: string | null;
}

export interface ConceptState {
  conceptId: string;
  mastery: number; // 0..1, lightweight estimate — not a validated measure
  exposures: number;
  confusions: number;
  successes: number;
  styleBias: Partial<Belief<Style>>; // locally learned, cautiously propagated
  lastSeenAt: number; // epoch ms
}

export interface BranchState {
  branchKey: string; // Graphify edge key "<source>|<relation>|<target>"
  strength: number; // 0..1 historical strength at lastReinforcedAt
  successes: number;
  uses: number;
  dormant: boolean;
  reactivations: number;
  lastReinforcedAt: number; // epoch ms
}

export interface InteractionRecord {
  learnerId: string;
  conceptId: string | null;
  branchKey: string | null;
  messageLength: number;
  signals: Signal[];
  depthUsed: Depth;
  styleUsed: Style;
  outcome: Outcome;
  followUpIndex: number;
  createdAt: number;
}

export interface Policy {
  depth: Depth;
  style: Style;
  secondaryStyle: Style | null;
  moves: PolicyMove[];
  rationale: string[];
}

export type PolicyMove =
  | "use_example"
  | "use_analogy"
  | "step_by_step"
  | "check_understanding"
  | "socratic_question"
  | "offer_related"
  | "slow_down"
  | "encourage"
  | "go_deeper"
  | "vary_approach"
  | "wrap_up";

export const uniform = <T extends string>(keys: readonly T[]): Belief<T> =>
  Object.fromEntries(keys.map((k) => [k, 1 / keys.length])) as Belief<T>;

export const argmax = <T extends string>(b: Belief<T>): T =>
  (Object.entries(b) as [T, number][]).reduce((best, cur) => (cur[1] > best[1] ? cur : best))[0];

export const normalize = <T extends string>(b: Belief<T>): Belief<T> => {
  const total = Object.values<number>(b).reduce((s, v) => s + Math.max(0, v), 0) || 1;
  return Object.fromEntries(Object.entries<number>(b).map(([k, v]) => [k, Math.max(0, v) / total])) as Belief<T>;
};

export function initialLearner(id: string): LearnerState {
  const depth = uniform(DEPTHS);
  depth.standard += 0.2; // mild prior toward "standard", as auto-tutor starts at Understand level
  const style = uniform(STYLES);
  style.conceptual += 0.1;
  const scores = Object.fromEntries(AFFECTS.map((a) => [a, 0])) as Belief<Affect>;
  return { id, depth: normalize(depth), style: normalize(style), affect: { scores, dominant: "neutral" }, currentConceptId: null };
}
