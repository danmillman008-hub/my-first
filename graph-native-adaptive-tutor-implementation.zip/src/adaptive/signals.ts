// Rough, auditable evidence extraction from a learner message.
// This is deliberately a small keyword table, not NLP or emotion recognition.
import type { Outcome, Signal } from "./types";

const PATTERNS: Array<[Signal, RegExp]> = [
  ["simplify", /\b(simpl(er|y|ify)|plain(er)? (english|words)|easier|too (hard|complex|complicated)|dumb it down|eli5|in short|shorter|briefly)\b/i],
  ["more_detail", /\b(more detail|in depth|elaborate|expand|go deeper|deeper|tell me more|why (does|is|do)|rigorous|formal(ly)?|proof)\b/i],
  ["example", /\b(example|for instance|show me|concrete|instance)\b/i],
  ["analogy", /\b(analog(y|ies)|metaphor|like what|compare it to|picture)\b/i],
  ["steps", /\b(step[- ]by[- ]step|steps|walk me through|one at a time|break (it|this) down|procedure)\b/i],
  ["practical", /\b(practical|real[- ]world|use(d)? for|apply|application|when would i)\b/i],
  ["technical", /\b(technical|precise(ly)?|formal definition|notation|theorem|rigor)\b/i],
  ["confusion", /\b(don'?t (get|understand|follow)|confus(ed|ing)|lost|no idea|what\?|huh|makes no sense|still don'?t|not clear|unclear)\b/i],
  ["curiosity", /\b(interesting|curious|what about|what if|how does (this|that) relate|related|connect(s|ed)? to|cool|fascinating|wonder)\b/i],
  ["hesitation", /\b(i think|maybe|not sure|i guess|perhaps|kind of|sort of|um+|hmm+|possibly)\b/i],
  ["frustration", /\b(frustrat(ed|ing)|annoying|ugh|again\?|give up|this is (hard|impossible)|seriously|argh)\b/i],
  ["boredom", /\b(bor(ed|ing)|already know|skip|move on|next|whatever|yeah yeah|obvious)\b/i],
  ["fatigue", /\b(tired|exhausted|long day|brain is fried|enough for (now|today)|later)\b/i],
  ["acknowledge", /\b(got it|makes sense|i see|understood|ok(ay)?[,.! ]|thanks|thank you|clear now|that helps|great)\b/i],
  ["reject", /\b(that'?s (not|wrong)|no,? (that|this)|not what i (asked|meant)|incorrect|doesn'?t answer)\b/i],
];

export function detectSignals(message: string): Signal[] {
  const text = message.trim();
  const found = new Set<Signal>();
  for (const [sig, re] of PATTERNS) if (re.test(text)) found.add(sig);
  const words = text.split(/\s+/).filter(Boolean).length;
  if (words <= 3) found.add("short_message");
  if (words >= 45) found.add("long_message");
  if (/\?\s*$/.test(text) || /^(what|why|how|when|where|which|can|could|does|is|are)\b/i.test(text)) found.add("question");
  if (found.has("acknowledge") && found.has("question")) found.add("continue");
  if (found.has("acknowledge") && !found.has("confusion") && !found.has("reject")) found.add("continue");
  return [...found];
}

/** Infer the outcome of the PREVIOUS explanation from the learner's next message. */
export function inferOutcome(signals: Signal[], sameConceptAsBefore: boolean): Outcome {
  const has = (s: Signal) => signals.includes(s);
  if (has("reject")) return "rejected";
  if (has("confusion") || has("frustration")) return "confused";
  if (has("simplify") || has("example") || has("steps") || has("analogy")) return "clarified";
  if (has("acknowledge") || has("continue")) return "accepted";
  if (!sameConceptAsBefore || has("curiosity")) return "explored";
  return "continued";
}
