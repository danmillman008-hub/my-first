// Rough interaction-state model (NOT emotion recognition).
// Signals push small impulses into a decaying score vector; the dominant
// state is only reported when it clears a threshold, otherwise "neutral".
import { type Affect, type AffectState, AFFECTS, type Belief, type Signal } from "./types";

const RATE = 0.35; // how quickly the state follows new evidence
const THRESHOLD = 0.22;

const IMPULSES: Partial<Record<Signal, Partial<Belief<Affect>>>> = {
  confusion: { confused: 1, frustrated: 0.2 },
  simplify: { confused: 0.6 },
  frustration: { frustrated: 1, confused: 0.3 },
  reject: { frustrated: 0.5 },
  hesitation: { hesitant: 1 },
  short_message: { hesitant: 0.2, bored: 0.2 },
  curiosity: { curious: 1, engaged: 0.4 },
  more_detail: { curious: 0.6, engaged: 0.3 },
  question: { engaged: 0.3 },
  long_message: { engaged: 0.5 },
  acknowledge: { engaged: 0.5 },
  continue: { engaged: 0.4 },
  boredom: { bored: 1 },
  fatigue: { fatigued: 1 },
  repeat: { confused: 0.4, frustrated: 0.3 },
};

export function updateAffect(state: AffectState, signals: Signal[]): AffectState {
  const impulse = Object.fromEntries(AFFECTS.map((a) => [a, 0])) as Belief<Affect>;
  for (const s of signals) for (const [a, w] of Object.entries(IMPULSES[s] ?? {}) as [Affect, number][]) impulse[a] += w;
  const max = Math.max(...Object.values(impulse), 1);
  const scores = { ...state.scores };
  for (const a of AFFECTS) {
    if (a === "neutral") continue;
    scores[a] = Math.min(1, (1 - RATE) * state.scores[a] + RATE * (impulse[a] / max));
  }
  scores.neutral = 0;
  let dominant: Affect = "neutral";
  let best = THRESHOLD;
  for (const a of AFFECTS) if (a !== "neutral" && scores[a] > best) ((best = scores[a]), (dominant = a));
  return { scores, dominant };
}
