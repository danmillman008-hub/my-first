// Response policy: converts graph + learner state into an explanation strategy.
//
// Implemented as a table of small, independent adjusters. Each adjuster reads
// the policy inputs and may contribute a depth shift, style boosts, moves and
// a one-line rationale. The final strategy is the sum of contributions —
// composable signals rather than a hand-written decision tree.
import type { Affect, Belief, BranchState, Depth, Policy, PolicyMove, Signal, Style } from "./types";
import { DEPTHS, argmax } from "./types";
import { effectiveStrength } from "./branches";

export interface PolicyInputs {
  depthBelief: Belief<Depth>;
  styleBelief: Belief<Style>; // already blended with concept-local bias
  affect: Affect;
  affectScores: Belief<Affect>;
  mastery: number;
  exposures: number;
  followUpIndex: number; // consecutive turns on the same concept
  signals: Signal[];
  branch: BranchState | null; // branch used to reach this concept, if any
  now: number;
}

interface Contribution {
  depthShift?: number;
  styleBoost?: Partial<Belief<Style>>;
  moves?: PolicyMove[];
  why?: string;
}

type Adjuster = (i: PolicyInputs) => Contribution | null;

const ADJUSTERS: Adjuster[] = [
  // Auto-tutor's "dynamic downgrade": confusion => step down, use examples/steps.
  (i) =>
    i.affect === "confused"
      ? { depthShift: -1, styleBoost: { "example-driven": 0.5, "step-by-step": 0.5 }, moves: ["use_example", "step_by_step", "check_understanding"], why: "confusion detected → downgrade depth, concrete examples, step-by-step" }
      : null,
  (i) =>
    i.affect === "frustrated"
      ? { depthShift: -1, styleBoost: { "analogy-based": 0.4, "step-by-step": 0.3 }, moves: ["slow_down", "encourage", "vary_approach"], why: "frustration → slow down, change approach, encourage" }
      : null,
  (i) =>
    i.affect === "curious"
      ? { depthShift: +1, styleBoost: { conceptual: 0.2 }, moves: ["go_deeper", "offer_related"], why: "curiosity → allow deeper exploration and surface related concepts" }
      : null,
  (i) => (i.affect === "hesitant" ? { styleBoost: { "step-by-step": 0.3 }, moves: ["socratic_question", "encourage"], why: "hesitation → guide with a small Socratic question" } : null),
  (i) => (i.affect === "bored" ? { depthShift: -1, moves: ["offer_related", "vary_approach"], why: "boredom → shorter, move to a related concept" } : null),
  (i) => (i.affect === "fatigued" ? { depthShift: -1, moves: ["wrap_up"], why: "fatigue → concise wrap-up" } : null),
  (i) => (i.affect === "engaged" ? { moves: ["check_understanding"], why: "engaged → keep pace, light comprehension check" } : null),
  // Mastery (auto-tutor ✅/🔄/⏳): low mastery pulls toward Remember/Understand level.
  (i) => (i.mastery < 0.25 && i.exposures > 0 ? { depthShift: -1, styleBoost: { "example-driven": 0.2 }, why: "low mastery → simpler framing" } : null),
  (i) => (i.mastery >= 0.8 ? { depthShift: +1, styleBoost: { technical: 0.2 }, moves: ["go_deeper", "socratic_question"], why: "high mastery → deeper, more rigorous, apply-level questions" } : null),
  // Explicit in-message requests always count.
  (i) => (i.signals.includes("example") ? { styleBoost: { "example-driven": 0.6 }, moves: ["use_example"], why: "learner asked for an example" } : null),
  (i) => (i.signals.includes("analogy") ? { styleBoost: { "analogy-based": 0.6 }, moves: ["use_analogy"], why: "learner asked for an analogy" } : null),
  (i) => (i.signals.includes("steps") ? { styleBoost: { "step-by-step": 0.6 }, moves: ["step_by_step"], why: "learner asked for steps" } : null),
  (i) => (i.signals.includes("simplify") ? { depthShift: -1, why: "learner asked to simplify" } : null),
  (i) => (i.signals.includes("more_detail") ? { depthShift: +1, why: "learner asked for more detail" } : null),
  // Repeated follow-ups on the same concept: vary the approach instead of repeating.
  (i) => (i.followUpIndex >= 2 ? { moves: ["vary_approach"], why: `follow-up #${i.followUpIndex} on same concept → vary approach` } : null),
  // Strong, previously successful branch: trust it and go a bit further.
  (i) =>
    i.branch && effectiveStrength(i.branch, i.now) > 0.6 && i.branch.uses > 0 && i.branch.successes / i.branch.uses > 0.6
      ? { moves: ["go_deeper"], why: "arrived via a strong, previously successful branch" }
      : null,
  (i) => (i.branch?.dormant ? { moves: ["check_understanding"], why: "branch was dormant → re-establish footing" } : null),
];

export function decidePolicy(i: PolicyInputs): Policy {
  const contributions = ADJUSTERS.map((a) => a(i)).filter((c): c is Contribution => Boolean(c));
  const baseDepth = argmax(i.depthBelief);
  const shift = Math.max(-2, Math.min(2, contributions.reduce((s, c) => s + (c.depthShift ?? 0), 0)));
  const depth = DEPTHS[Math.min(DEPTHS.length - 1, Math.max(0, DEPTHS.indexOf(baseDepth) + Math.sign(shift) * Math.min(1, Math.abs(shift))))];

  const styleScore = { ...i.styleBelief };
  for (const c of contributions) for (const [s, w] of Object.entries(c.styleBoost ?? {}) as [Style, number][]) styleScore[s] += w;
  const ranked = (Object.entries(styleScore) as [Style, number][]).sort((a, b) => b[1] - a[1]);
  const style = ranked[0][0];
  const secondaryStyle = ranked[1][1] > 0.2 ? ranked[1][0] : null;

  const moves = [...new Set(contributions.flatMap((c) => c.moves ?? []))];
  const rationale = [`base depth from belief: ${baseDepth}`, ...contributions.map((c) => c.why).filter((w): w is string => Boolean(w))];
  return { depth, style, secondaryStyle, moves, rationale };
}
