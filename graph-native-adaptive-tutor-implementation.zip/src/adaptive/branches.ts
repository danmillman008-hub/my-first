// Branch dynamics over Graphify edges: strengthening, exponential time decay,
// dormancy and reactivation. Pure, deterministic, clock-injected.
//
//   effective_strength(now) = strength × 0.5 ^ ((now − lastReinforcedAt) / HALF_LIFE)
//
// Strength is bounded in [0, 1]: reinforcement is saturating, decay is
// monotonic non-increasing, and reactivation restores a floor so a branch the
// learner returns to becomes usable again immediately.
import type { BranchState, ConceptState, Outcome } from "./types";

export const BRANCH = {
  halfLifeMs: Number(process.env.TUTOR_BRANCH_HALF_LIFE_MS ?? 7 * 24 * 3600 * 1000),
  dormantThreshold: 0.15,
  reactivationFloor: 0.35,
  initialStrength: 0.3,
  reinforceGain: 0.25,
} as const;

export const newBranchState = (branchKey: string, now: number): BranchState => ({
  branchKey,
  strength: BRANCH.initialStrength,
  successes: 0,
  uses: 0,
  dormant: false,
  reactivations: 0,
  lastReinforcedAt: now,
});

export function effectiveStrength(b: BranchState, now: number, halfLifeMs = BRANCH.halfLifeMs): number {
  const dt = Math.max(0, now - b.lastReinforcedAt);
  return b.strength * Math.pow(0.5, dt / halfLifeMs);
}

/** Materialise decay: fold elapsed time into `strength`; flip dormant if below threshold. */
export function applyDecay(b: BranchState, now: number, halfLifeMs = BRANCH.halfLifeMs): BranchState {
  const strength = effectiveStrength(b, now, halfLifeMs);
  return { ...b, strength, lastReinforcedAt: Math.max(b.lastReinforcedAt, now), dormant: b.dormant || strength < BRANCH.dormantThreshold };
}

const OUTCOME_GAIN: Record<Outcome, number> = {
  accepted: 1,
  continued: 0.8,
  explored: 0.7,
  clarified: 0.5,
  confused: 0.25,
  rejected: 0,
};

/** A used branch gets stronger; how much depends on how well the interaction went. */
export function reinforce(b: BranchState, now: number, outcome: Outcome): BranchState {
  const eff = effectiveStrength(b, now);
  const gain = BRANCH.reinforceGain * OUTCOME_GAIN[outcome];
  const strength = Math.min(1, eff + gain * (1 - eff));
  const wasDormant = b.dormant;
  return {
    ...b,
    strength: wasDormant ? Math.max(strength, BRANCH.reactivationFloor) : strength,
    uses: b.uses + 1,
    successes: b.successes + (outcome === "accepted" || outcome === "continued" ? 1 : 0),
    dormant: false,
    reactivations: b.reactivations + (wasDormant ? 1 : 0),
    lastReinforcedAt: now,
  };
}

/** Explicit reactivation (learner returned to a related concept / MCP request). */
export function reactivate(b: BranchState, now: number): BranchState {
  const eff = effectiveStrength(b, now);
  return {
    ...b,
    strength: Math.max(eff, BRANCH.reactivationFloor),
    dormant: false,
    reactivations: b.reactivations + (b.dormant ? 1 : 0),
    lastReinforcedAt: now,
  };
}

export const successRate = (b: BranchState) => (b.uses === 0 ? 0.5 : b.successes / b.uses);

// ---- Mastery (reuses auto-tutor's ✅ / 🔄 / ⏳ states) -----------------------

export const newConceptState = (conceptId: string, now: number): ConceptState => ({
  conceptId,
  mastery: 0,
  exposures: 0,
  confusions: 0,
  successes: 0,
  styleBias: {},
  lastSeenAt: now,
});

const MASTERY_DELTA: Record<Outcome, (m: number) => number> = {
  accepted: (m) => m + 0.18 * (1 - m),
  continued: (m) => m + 0.12 * (1 - m),
  explored: (m) => m + 0.06 * (1 - m),
  clarified: (m) => m + 0.03 * (1 - m),
  confused: (m) => m - 0.12 * m,
  rejected: (m) => m - 0.15 * m,
};

export function updateMastery(c: ConceptState, outcome: Outcome, now: number): ConceptState {
  return {
    ...c,
    mastery: Math.min(1, Math.max(0, MASTERY_DELTA[outcome](c.mastery))),
    exposures: c.exposures + 1,
    confusions: c.confusions + (outcome === "confused" ? 1 : 0),
    successes: c.successes + (outcome === "accepted" || outcome === "continued" ? 1 : 0),
    lastSeenAt: now,
  };
}

export type MasteryLabel = "mastered" | "in_progress" | "to_learn";
export const masteryLabel = (m: number): MasteryLabel => (m >= 0.8 ? "mastered" : m >= 0.4 ? "in_progress" : "to_learn");
export const masteryIcon = (m: number) => ({ mastered: "✅", in_progress: "🔄", to_learn: "⏳" })[masteryLabel(m)];
