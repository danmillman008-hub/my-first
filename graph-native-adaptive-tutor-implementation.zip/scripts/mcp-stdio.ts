// Adaptive tutor MCP server over stdio (for Claude Desktop / IDE clients).
//   npx tsx scripts/mcp-stdio.ts
// Uses the same thin adapter as the Streamable HTTP route.
import "dotenv/config";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { createTutorMcpServer } from "@/mcp/server";
import { getRuntimeDeps } from "@/tutor/service";

async function main() {
  const deps = await getRuntimeDeps();
  const server = createTutorMcpServer(deps);
  await server.connect(new StdioServerTransport());
  process.stderr.write("adaptive-tutor MCP server (stdio) ready\n");
}

main().catch((err) => {
  process.stderr.write(`mcp-stdio failed: ${err instanceof Error ? err.message : String(err)}\n`);
  process.exit(1);
});
