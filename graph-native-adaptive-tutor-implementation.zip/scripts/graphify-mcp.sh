#!/usr/bin/env bash
# Start Graphify's OWN MCP server (unchanged upstream code) on graphify-out/graph.json.
#   ./scripts/graphify-mcp.sh                # stdio
#   ./scripts/graphify-mcp.sh http 8080      # Streamable HTTP on http://127.0.0.1:8080/mcp
# Requires: pip install "graphifyy[mcp]"  (or GRAPHIFY_SRC=/path/to/checkout)
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="${GRAPHIFY_SRC:-}${PYTHONPATH:+:$PYTHONPATH}"
TRANSPORT="${1:-stdio}"
PORT="${2:-8080}"
if [ "$TRANSPORT" = "http" ]; then
  exec python3 -m graphify.serve graphify-out/graph.json --transport http --port "$PORT" ${GRAPHIFY_API_KEY:+--api-key "$GRAPHIFY_API_KEY"}
fi
exec python3 -m graphify.serve graphify-out/graph.json --transport stdio
