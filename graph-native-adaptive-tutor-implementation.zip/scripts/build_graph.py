#!/usr/bin/env python3
"""Build graphify-out/graph.json from ./corpus using Graphify's public library API.

This is the documented standalone pipeline from Graphify's ARCHITECTURE.md:
    collect_files -> extract -> build -> cluster -> export.to_json
Nothing here re-implements Graphify; it only orchestrates the existing stages.

Usage:
    python3 scripts/build_graph.py            # uses installed `graphifyy`
    GRAPHIFY_SRC=/path/to/graphify python3 scripts/build_graph.py   # use a checkout
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

src = os.environ.get("GRAPHIFY_SRC")
if src:
    sys.path.insert(0, src)

try:
    from graphify.extract import extract, collect_files
    from graphify.build import build
    from graphify.cluster import cluster
    from graphify.export import to_json
except ImportError as exc:  # pragma: no cover
    sys.exit(
        f"graphify not importable ({exc}). Install it with: pip install 'graphifyy[mcp]' "
        "or set GRAPHIFY_SRC to a checkout of https://github.com/Graphify-Labs/graphify"
    )

ROOT = Path(__file__).resolve().parent.parent
corpus = ROOT / "corpus"
out_dir = ROOT / os.environ.get("GRAPHIFY_OUT", "graphify-out")
out_dir.mkdir(parents=True, exist_ok=True)

files = collect_files(corpus)
extraction = extract(files, root=corpus.resolve())
G = build([extraction])
communities = cluster(G)
ok = to_json(G, communities, str(out_dir / "graph.json"), force=True)
print(f"graph.json written={ok} nodes={G.number_of_nodes()} edges={G.number_of_edges()} communities={len(communities)}")
