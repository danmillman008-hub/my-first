// Protocol smoke test against the running Streamable HTTP endpoint.
//   BASE_URL=http://127.0.0.1:3000 npx tsx scripts/mcp-smoke.ts
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

async function main() {
  const base = process.env.BASE_URL ?? "http://127.0.0.1:3000";
  const headers: Record<string, string> = process.env.TUTOR_MCP_API_KEY ? { "x-api-key": process.env.TUTOR_MCP_API_KEY } : {};
  const transport = new StreamableHTTPClientTransport(new URL("/mcp", base), { requestInit: { headers } });
  const client = new Client({ name: "smoke", version: "0" });
  await client.connect(transport);
  const tools = (await client.listTools()).tools.map((t) => t.name);
  console.log("tools:", tools.join(", "));
  const res = await client.callTool({ name: "get_learning_state", arguments: { learnerId: "smoke" } });
  const state = JSON.parse((res.content as { text: string }[])[0].text);
  console.log("graph:", state.graph, "depth:", state.preferences.depth);
  const turn = await client.callTool({ name: "record_interaction", arguments: { learnerId: "smoke", message: "Explain the chain rule with an example" } });
  const t = JSON.parse((turn.content as { text: string }[])[0].text);
  console.log("turn concept:", t.concept.id, "policy:", t.policy.depth, t.policy.style);
  const templates = await client.listResourceTemplates();
  console.log("resource templates:", templates.resourceTemplates.map((r) => r.uriTemplate).join(", "));
  await client.close();
  console.log("MCP Streamable HTTP OK");
}
main().catch((e) => {
  console.error("MCP smoke failed:", e);
  process.exit(1);
});
