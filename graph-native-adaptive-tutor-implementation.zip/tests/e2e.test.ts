// End-to-end acceptance scenario over the REAL Graphify graph (graphify-out/graph.json)
// with an in-memory overlay store and an injected clock.
import assert from "node:assert/strict";
import path from "node:path";
import { test } from "node:test";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { InMemoryTransport } from "@modelcontextprotocol/sdk/inMemory.js";
import { MemoryStore } from "@/adaptive/store";
import { argmax } from "@/adaptive/types";
import { GraphifyGraph } from "@/graphify/adapter";
import { createTutorMcpServer } from "@/mcp/server";
import { chatTurn, learnerSnapshot, type TutorDeps } from "@/tutor/service";

const ROOT = process.cwd();
const DAY = 24 * 3600 * 1000;
const MIN = 60 * 1000;

function deps(): TutorDeps {
  const graph = GraphifyGraph.load(path.join(ROOT, "graphify-out/graph.json"), path.join(ROOT, "corpus"));
  return { graph, store: new MemoryStore(), useLlm: false };
}

test("graph integrity: Graphify graph.json is the authoritative substrate", () => {
  const { graph } = deps();
  assert.ok(graph.size.nodes >= 30 && graph.size.edges >= 30);
  const d = graph.node("derivatives");
  assert.ok(d && d.node_kind === "page" && d.source_file === "derivatives.md");
  assert.ok(graph.edge("derivatives|references|integrals"), "Graphify references edge present");
  assert.equal(graph.resolveConcept("Can you explain derivatives?")?.id, "derivatives");
  assert.equal(graph.resolveConcept("tell me about the chain rule")?.id, "chain_rule");
  assert.equal(graph.resolveConcept("what is the power rule")?.id, "derivatives_power_rule");
  assert.ok(graph.sourceText("derivatives_power_rule").includes("n·x^(n-1)"));
});

test("acceptance scenario: adaptation is derived from state", async () => {
  const d = deps();
  const L = "alice";
  let t = Date.UTC(2026, 0, 1);
  const say = (msg: string, dt = MIN) => chatTurn(d, L, msg, (t += dt));

  // 1–2. Learner asks about Concept A; tutor gives a standard explanation.
  const r1 = await say("Can you explain derivatives?");
  assert.equal(r1.concept.id, "derivatives");
  assert.equal(r1.policy.depth, "standard");
  assert.ok(r1.reply.includes("rate of change"));

  // Touch Branch C (derivatives -> integrals) once, then return to derivatives.
  const rC = await say("What about integrals?");
  assert.equal(rC.branchUsed, "derivatives|references|integrals");
  await say("Back to derivatives please.");

  // 3. Repeated simplification / example / confusion.
  await say("Can you explain that more simply?");
  await say("Give me an example.");
  const r3 = await say("I still don't understand.");

  // 4–5. State updated; future responses simpler, example-driven, step-by-step.
  assert.equal(r3.depth, "concise", "depth belief moved to concise");
  assert.equal(r3.style, "example-driven", "style belief moved to example-driven");
  assert.equal(r3.affect, "confused");
  assert.equal(r3.policy.depth, "concise");
  assert.ok(r3.policy.moves.includes("use_example") && r3.policy.moves.includes("step_by_step"));
  assert.ok(/^1\. /m.test(r3.reply), "step-by-step numbered explanation");
  assert.ok(/For example|Concretely/.test(r3.reply), "example section pulled from the graph");
  const interactions = await d.store.recentInteractions(L, 10);
  assert.equal(interactions.length, 6);
  assert.ok(interactions[0].signals.includes("confusion"));

  // 6–7. Learner moves repeatedly through Branch B (derivatives <-> chain rule).
  const B = "chain_rule|references|derivatives";
  for (let i = 0; i < 4; i++) {
    const a = await say("Got it. Now tell me about the chain rule.");
    assert.equal(a.branchUsed, B);
    await say("Makes sense, back to derivatives.");
  }
  let snap = await learnerSnapshot(d, L, t);
  const bB = snap.branches.find((b) => b.key === B)!;
  const bC = snap.branches.find((b) => b.key === "derivatives|references|integrals")!;
  assert.ok(bB.strength > 0.6, `branch B strengthened (${bB.strength})`);
  assert.ok(bB.uses >= 8);
  assert.ok(bC.strength < bB.strength && bC.uses * 3 <= bB.uses, `branch C barely used (${bC.uses} vs ${bB.uses})`);
  assert.ok(snap.preferences.depth !== "deep");
  // Graph state influences path selection: from derivatives, the strong branch B ranks above C.
  const order = snap.nextBranches.map((b) => b.key);
  assert.ok(order.indexOf(B) < order.indexOf("derivatives|references|integrals"), `B before C in ${order.join(" > ")}`);

  // 9–10. Time passes: C decays below threshold and becomes dormant; B survives.
  t += 17 * DAY;
  snap = await learnerSnapshot(d, L, t);
  const dormantC = snap.branches.find((b) => b.key === "derivatives|references|integrals")!;
  const liveB = snap.branches.find((b) => b.key === B)!;
  assert.equal(dormantC.dormant, true, "branch C dormant after decay");
  assert.ok(dormantC.strength < 0.15);
  assert.equal(liveB.dormant, false, "branch B still active");
  assert.ok(liveB.strength > dormantC.strength);

  // 11–12. Learner returns to a concept related to Branch C: reactivated.
  const r12 = await say("Let's revisit integrals.");
  assert.equal(r12.concept.id, "integrals");
  assert.ok(r12.reactivated.includes("derivatives|references|integrals"), "branch C reactivated");
  snap = await learnerSnapshot(d, L, t);
  const backC = snap.branches.find((b) => b.key === "derivatives|references|integrals")!;
  assert.equal(backC.dormant, false);
  assert.ok(backC.strength >= 0.35 && backC.reactivations === 1);

  // After reactivation the branch is usable again: it ranks among the top candidates from derivatives.
  await say("Back to derivatives again.");
  snap = await learnerSnapshot(d, L, t);
  assert.ok(snap.nextBranches.slice(0, 2).some((b) => b.key === "derivatives|references|integrals"), "reactivated branch is selectable again");

  // 13–14. MCP client requests the personalised graph-native state.
  const server = createTutorMcpServer(d);
  const [ct, st] = InMemoryTransport.createLinkedPair();
  await server.connect(st);
  const client = new Client({ name: "test", version: "0" });
  await client.connect(ct);
  const tools = (await client.listTools()).tools.map((x) => x.name).sort();
  assert.deepEqual(tools, ["apply_decay", "get_concept", "get_current_policy", "get_learning_state", "get_related_concepts", "reactivate_branch", "record_interaction"]);
  const state = await client.callTool({ name: "get_learning_state", arguments: { learnerId: L } });
  const payload = JSON.parse((state.content as { text: string }[])[0].text);
  assert.equal(payload.currentConcept.id, "derivatives");
  assert.equal(payload.preferences.depth, "concise");
  assert.ok(payload.branches.some((b: { key: string; reactivations: number }) => b.key === "derivatives|references|integrals" && b.reactivations === 1));
  assert.equal(payload.graph.source, "graphify-out/graph.json");

  const bad = await client.callTool({ name: "reactivate_branch", arguments: { branchKey: "nope|x|y", learnerId: L } });
  assert.equal(bad.isError, true, "mutation refuses unknown branch");
  const ok = await client.callTool({ name: "reactivate_branch", arguments: { branchKey: "continuity|references|limits", learnerId: L } });
  assert.notEqual(ok.isError, true);
  const turn = await client.callTool({ name: "record_interaction", arguments: { message: "Explain limits briefly", learnerId: L } });
  assert.equal(JSON.parse((turn.content as { text: string }[])[0].text).concept.id, "limits");

  const res = await client.readResource({ uri: "graph://concept/derivatives" });
  assert.ok(JSON.parse((res.contents[0] as { text: string }).text).node.id === "derivatives");
  const templates = await client.listResourceTemplates();
  assert.ok(templates.resourceTemplates.some((r) => r.uriTemplate === "graph://concept/{id}"));
  const prompt = await client.getPrompt({ name: "explain_current_concept", arguments: { learnerId: L } });
  assert.ok(prompt.messages[0].content.type === "text" && /concise/.test(prompt.messages[0].content.text));
  await client.close();
  await server.close();
  void argmax;
});
