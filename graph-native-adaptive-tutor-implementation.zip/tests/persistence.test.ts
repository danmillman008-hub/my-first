// Persistence: overlay state survives a "restart" (new store instance, new
// process-level cache). Skipped when PostgreSQL is not reachable.
import assert from "node:assert/strict";
import path from "node:path";
import { test } from "node:test";
import "dotenv/config";
import { drizzle } from "drizzle-orm/node-postgres";
import { sql } from "drizzle-orm";
import { Pool } from "pg";
import { PgStore } from "@/adaptive/store-pg";
import { GraphifyGraph } from "@/graphify/adapter";
import { chatTurn, learnerSnapshot } from "@/tutor/service";

test("persistence: learner/branch/concept state survives restart (PostgreSQL)", async (t) => {
  const url = process.env.DATABASE_URL;
  if (!url) return t.skip("DATABASE_URL not set");
  const pool = new Pool({ connectionString: url, connectionTimeoutMillis: 2000 });
  try {
    await pool.query("select 1");
  } catch {
    await pool.end();
    return t.skip("database not reachable");
  }
  const db = drizzle(pool);
  const graph = GraphifyGraph.load(path.join(process.cwd(), "graphify-out/graph.json"), path.join(process.cwd(), "corpus"));
  const L = `persist-${Date.now()}`;
  try {
    const first = { graph, store: new PgStore(db), useLlm: false };
    let now = Date.UTC(2026, 1, 1);
    await chatTurn(first, L, "Explain limits", (now += 60_000));
    await chatTurn(first, L, "Can you explain that more simply?", (now += 60_000));
    await chatTurn(first, L, "Interesting, what about continuity?", (now += 60_000));

    // "Restart": brand-new store over a fresh connection.
    const pool2 = new Pool({ connectionString: url });
    const second = { graph, store: new PgStore(drizzle(pool2)), useLlm: false };
    const snap = await learnerSnapshot(second, L, now);
    assert.equal(snap.currentConcept?.id, "continuity");
    assert.ok(snap.branches.some((b) => b.key === "continuity|references|limits" && b.uses >= 1));
    assert.ok(snap.concepts.some((c) => c.id === "limits" && c.exposures >= 1));
    assert.ok(snap.preferences.depthBelief.concise > 0.25);
    const history = await second.store.recentInteractions(L, 10);
    assert.equal(history.length, 3);
    assert.ok(history[1].signals.includes("simplify"));
    await pool2.end();
  } finally {
    await db.execute(sql`delete from tutor_interactions where learner_id = ${L}`);
    await db.execute(sql`delete from tutor_branch_state where learner_id = ${L}`);
    await db.execute(sql`delete from tutor_concept_state where learner_id = ${L}`);
    await db.execute(sql`delete from tutor_learners where id = ${L}`);
    await pool.end();
  }
});
