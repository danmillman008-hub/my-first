import assert from "node:assert/strict";
import { test } from "node:test";
import { detectSignals, inferOutcome } from "@/adaptive/signals";
import { updateDepth, updateStyle } from "@/adaptive/preferences";
import { updateAffect } from "@/adaptive/affect";
import { BRANCH, applyDecay, effectiveStrength, newBranchState, newConceptState, reactivate, reinforce, updateMastery } from "@/adaptive/branches";
import { decidePolicy, type PolicyInputs } from "@/adaptive/policy";
import { argmax, initialLearner } from "@/adaptive/types";

const DAY = 24 * 3600 * 1000;

test("signals: rough evidence detection", () => {
  assert.ok(detectSignals("Can you explain that more simply?").includes("simplify"));
  assert.ok(detectSignals("Give me an example.").includes("example"));
  assert.ok(detectSignals("I still don't understand.").includes("confusion"));
  assert.ok(detectSignals("Interesting, what about integrals?").includes("curiosity"));
  assert.equal(inferOutcome(detectSignals("Got it, thanks!"), true), "accepted");
  assert.equal(inferOutcome(detectSignals("I'm lost"), true), "confused");
});

test("preference adaptation: repeated simplify requests move depth to concise", () => {
  let depth = initialLearner("x").depth;
  assert.equal(argmax(depth), "standard");
  for (let i = 0; i < 3; i++) depth = updateDepth(depth, detectSignals("Can you explain that more simply?"), "standard");
  assert.equal(argmax(depth), "concise");
  // and repeated detail requests move it back up
  for (let i = 0; i < 5; i++) depth = updateDepth(depth, detectSignals("Go deeper, more detail please"), argmax(depth));
  assert.ok(["detailed", "deep"].includes(argmax(depth)));
});

test("style adaptation: repeated example requests make example-driven dominant", () => {
  let style = initialLearner("x").style;
  for (let i = 0; i < 3; i++) style = updateStyle(style, detectSignals("Give me an example."), "conceptual");
  assert.equal(argmax(style), "example-driven");
});

test("affect: repeated confusion vs curiosity yield different dominant states", () => {
  let a = initialLearner("x").affect;
  assert.equal(a.dominant, "neutral");
  for (let i = 0; i < 2; i++) a = updateAffect(a, detectSignals("I don't understand, this is confusing"));
  assert.equal(a.dominant, "confused");
  let b = initialLearner("y").affect;
  for (let i = 0; i < 2; i++) b = updateAffect(b, detectSignals("Interesting! What about how this connects to integrals?"));
  assert.equal(b.dominant, "curious");
});

test("branches: strengthening is bounded and increases with useful interactions", () => {
  const t0 = 1_000_000;
  let b = newBranchState("a|references|b", t0);
  const s0 = b.strength;
  b = reinforce(b, t0 + 1, "accepted");
  b = reinforce(b, t0 + 2, "accepted");
  assert.ok(b.strength > s0);
  for (let i = 0; i < 50; i++) b = reinforce(b, t0 + 3 + i, "accepted");
  assert.ok(b.strength <= 1);
  assert.equal(b.uses, 52);
});

test("branches: decay is deterministic, monotonic and leads to dormancy", () => {
  const t0 = 0;
  const b = { ...newBranchState("a|references|b", t0), strength: 0.6 };
  const s7 = effectiveStrength(b, t0 + 7 * DAY, 7 * DAY);
  const s14 = effectiveStrength(b, t0 + 14 * DAY, 7 * DAY);
  assert.ok(Math.abs(s7 - 0.3) < 1e-9);
  assert.ok(Math.abs(s14 - 0.15) < 1e-9);
  assert.ok(s14 < s7 && s7 < b.strength);
  const decayed = applyDecay(b, t0 + 21 * DAY, 7 * DAY);
  assert.ok(decayed.strength < BRANCH.dormantThreshold);
  assert.equal(decayed.dormant, true);
  // reactivation restores a usable floor and clears dormancy
  const back = reactivate(decayed, t0 + 22 * DAY);
  assert.equal(back.dormant, false);
  assert.ok(back.strength >= BRANCH.reactivationFloor);
  assert.equal(back.reactivations, 1);
});

test("mastery: bounded lightweight estimate reacts to outcomes", () => {
  let c = newConceptState("limits", 0);
  for (let i = 0; i < 6; i++) c = updateMastery(c, "accepted", i);
  assert.ok(c.mastery > 0.6 && c.mastery <= 1);
  c = updateMastery(c, "confused", 7);
  assert.ok(c.mastery < 0.7);
});

test("policy: different graph/learner states produce different strategies", () => {
  const base: PolicyInputs = {
    depthBelief: initialLearner("x").depth,
    styleBelief: initialLearner("x").style,
    affect: "neutral",
    affectScores: initialLearner("x").affect.scores,
    mastery: 0.5,
    exposures: 2,
    followUpIndex: 0,
    signals: [],
    branch: null,
    now: 0,
  };
  const neutral = decidePolicy(base);
  const confused = decidePolicy({ ...base, affect: "confused" });
  const curious = decidePolicy({ ...base, affect: "curious", mastery: 0.9 });
  assert.equal(neutral.depth, "standard");
  assert.equal(confused.depth, "concise");
  assert.ok(confused.moves.includes("use_example") && confused.moves.includes("step_by_step"));
  assert.ok(["detailed", "deep"].includes(curious.depth));
  assert.ok(curious.moves.includes("offer_related"));
  const strong = decidePolicy({ ...base, branch: { branchKey: "a|references|b", strength: 0.9, uses: 4, successes: 4, dormant: false, reactivations: 0, lastReinforcedAt: 0 } });
  assert.ok(strong.moves.includes("go_deeper"));
  assert.notDeepEqual(neutral.rationale, confused.rationale);
});
