# Fundamental Theorem

The Fundamental Theorem of Calculus links [[Derivatives]] and [[Integrals]]: differentiation and integration are inverse processes. It also gives the practical recipe for evaluating definite integrals.

## FTC Part One

If F(x) = ∫ₐˣ f(t) dt with f continuous, then F'(x) = f(x). Accumulating f and then differentiating returns f itself.

## FTC Part Two

If F is any antiderivative of f, then ∫ₐᵇ f(x) dx = F(b) - F(a). Example: ∫₀² 2x dx = [x²]₀² = 4 - 0 = 4. No rectangles needed.

## Why It Matters

Before the theorem, areas required limits of sums. After it, you only need an antiderivative. Think of an odometer (accumulated distance) and a speedometer (rate): the theorem says each can be recovered from the other.
