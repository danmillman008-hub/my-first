# Limits

A limit describes the value a function approaches as its input gets closer and closer to some point, even if the function never actually reaches that value. Limits are the foundation for [[Continuity]] and [[Derivatives]].

## Intuition for Limits

Imagine walking toward a wall and halving your remaining distance at every step. You never touch the wall, but the distance you are heading toward is clearly zero. That target value is the limit. In symbols we write lim x→a f(x) = L, read "the limit of f(x) as x approaches a equals L".

## One-Sided Limits

A one-sided limit looks at the approach from only the left or only the right. If the two one-sided limits disagree, the two-sided limit does not exist. Example: f(x) = |x|/x is -1 from the left of zero and +1 from the right, so no limit exists at zero.

## Epsilon-Delta Definition

The formal definition: lim x→a f(x) = L means that for every ε > 0 there exists a δ > 0 such that whenever 0 < |x - a| < δ, we have |f(x) - L| < ε. In plain words: you can force the output as close to L as you like by keeping the input close enough to a.

## Limit Laws

Limits respect addition, subtraction, multiplication, and division (when the denominator's limit is not zero). These laws let you compute complex limits by breaking them into simple pieces such as constants and powers of x.
