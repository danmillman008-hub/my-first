# Integrals

An integral accumulates quantities: total area under a curve, total distance from a velocity, total volume from cross-sections. Integrals are the reverse of [[Derivatives]], a fact made precise by the [[Fundamental Theorem]]. They require [[Continuity]] (or something close) on the interval.

## Riemann Sums

Approximate the area under f from a to b by slicing it into n thin rectangles of width Δx and adding their areas Σ f(xᵢ)Δx. As n grows the approximation improves; the definite integral is the limit of these sums.

## Definite vs Indefinite Integrals

A definite integral ∫ₐᵇ f(x) dx is a number: the signed area between a and b. An indefinite integral ∫ f(x) dx is a family of functions F(x) + C whose derivative is f. The constant C reflects that infinitely many functions share the same derivative.

## Basic Integration Rules

∫ xⁿ dx = xⁿ⁺¹/(n+1) + C for n ≠ -1, reversing the power rule. Integrals are linear: constants factor out and sums split. Example: ∫ (2x + 3) dx = x² + 3x + C.
