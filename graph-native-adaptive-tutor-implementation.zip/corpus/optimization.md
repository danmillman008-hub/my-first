# Optimization

Optimization uses [[Derivatives]] to find the largest or smallest value of a quantity: cheapest cost, maximal area, shortest time. Nested formulas often need the [[Chain Rule]].

## Critical Points

A critical point is where f'(x) = 0 or f'(x) is undefined. Maxima and minima of a smooth function on an open interval can only occur at critical points, because the tangent must be flat at a peak or valley.

## Second Derivative Test

At a critical point c: if f''(c) > 0 the curve is concave up (a local minimum); if f''(c) < 0 it is concave down (a local maximum); if f''(c) = 0 the test is inconclusive.

## Fence Problem

You have 100 m of fence to enclose a rectangle against a wall (one side needs no fence). Area A = x(100 - 2x). A' = 100 - 4x = 0 gives x = 25, so the best rectangle is 25 m by 50 m, enclosing 1250 m².
