# Continuity

A function is continuous at a point when its [[Limits|limit]] there equals its actual value: no jumps, holes, or vertical asymptotes. Continuity is what makes [[Derivatives]] and [[Integrals]] well-behaved.

## Definition of Continuity

f is continuous at a if three things hold: f(a) is defined, lim x→a f(x) exists, and the two are equal. If any of the three fails, the function is discontinuous at a.

## Types of Discontinuity

A removable discontinuity is a single missing point (a hole) that could be patched. A jump discontinuity happens when the one-sided limits differ. An infinite discontinuity happens near a vertical asymptote such as 1/x at zero.

## Intermediate Value Theorem

If f is continuous on [a, b] and N is any value between f(a) and f(b), then some c in (a, b) satisfies f(c) = N. Example: if a temperature reading goes from 10° to 20° continuously, at some instant it was exactly 15°.
