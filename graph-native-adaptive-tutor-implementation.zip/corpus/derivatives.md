# Derivatives

The derivative measures the instantaneous rate of change of a function: how fast the output is changing at one exact input. It is defined using [[Limits]] and unlocks the [[Chain Rule]], [[Optimization]], and, through the [[Fundamental Theorem]], connects to [[Integrals]].

## Derivative as a Limit

The derivative of f at x is f'(x) = lim h→0 [f(x + h) - f(x)] / h. The fraction is the average rate of change over a tiny interval of width h; the limit shrinks that interval to a single instant.

## Derivative as Slope

Geometrically, f'(x) is the slope of the tangent line to the curve at x. A positive derivative means the curve is rising, negative means falling, and zero means momentarily flat. Example: a car's speedometer reading is the derivative of its position.

## Power Rule

For f(x) = x^n, the derivative is f'(x) = n·x^(n-1). Example: the derivative of x³ is 3x². Combined with linearity, the power rule differentiates every polynomial.

## Product and Quotient Rules

(uv)' = u'v + uv'. (u/v)' = (u'v - uv') / v². These handle functions built by multiplying or dividing simpler functions.
