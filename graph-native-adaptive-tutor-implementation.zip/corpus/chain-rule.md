# Chain Rule

The chain rule differentiates a composition of functions: when one function is applied inside another. It builds directly on [[Derivatives]] and is essential for [[Optimization]] problems with nested expressions.

## Chain Rule Statement

If y = f(g(x)), then dy/dx = f'(g(x)) · g'(x). Differentiate the outer function while leaving the inside alone, then multiply by the derivative of the inside.

## Chain Rule Example

Differentiate (3x² + 1)⁵. Outer: u⁵ with derivative 5u⁴. Inner: 3x² + 1 with derivative 6x. Result: 5(3x² + 1)⁴ · 6x = 30x(3x² + 1)⁴.

## Gears Analogy

Picture two gears. If gear A turns twice as fast as the crank, and gear B turns three times as fast as gear A, then gear B turns six times as fast as the crank. Rates multiply, exactly as the chain rule says.
