# Gemini + an adaptive human–LLM compatibility layer

A plain chat with **Gemini 3.6 Flash** — and behind it a layer that makes the model *know this person longitudinally* without taking any of the model's (or the person's) freedom away.

The person can chat, argue, switch topics, ask for just the answer, or ask to be taught. The model decides how to respond. What the layer adds is what a model cannot do on its own: remember across sessions **with the right epistemics** — what was demonstrated vs. merely claimed, what was explained and whether it landed, which approaches led to progress, what the person said about themselves (and later retracted), and how all of that decays with time. Everything it believes is inspectable, correctable and erasable by the person.

```
person ─► chat ─► [ brief compiled from evidence ] ─► Gemini (+ 4 memory tools) ─► reply
                                  ▲                                        │
                                  └──── deterministic memory rules ◄── reflection (structured JSON)
```

Read in this order: [docs/FORENSICS.md](docs/FORENSICS.md) (what 17 previous attempts taught), [docs/RESEARCH.md](docs/RESEARCH.md) (capabilities of current models, memory, learner modelling, sources), [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) (capability map, learner model, memory semantics), [docs/EVALUATION.md](docs/EVALUATION.md) (baselines and results), [docs/DECISIONS.md](docs/DECISIONS.md).

## Quick start

```bash
cp .env.example .env         # set DATABASE_URL and GEMINI_API_KEY
npm install
npm run db:push              # creates the tables (drizzle-kit push)
npm run dev                  # http://localhost:3000
```

Without `GEMINI_API_KEY` the app runs on an offline, clearly-labelled mock model (amber dot in the sidebar) so the memory layer, UI, tests and lab work end-to-end; teaching quality obviously requires the real model.

## Using it

- Just talk. Ask a question, ask to be taught, say "I already know X", say "actually that's not how I learn".
- **What it knows about you** (right panel): per-skill evidence with predicted recall, beliefs with source/confidence/status and a *not true* button, and the exact brief the model receives. **Erase all memory** deletes everything.
- **why this turn** under each reply shows the trace: brief size, tools called, and what the reflection extracted.
- Ask it directly: "what do you remember about me?", "forget that I said I prefer analogies", "quiz me on what we did last week".

## Scripts

| command | what |
| --- | --- |
| `npm test` | 15 unit tests of the pure memory semantics, brief compiler and reflection validation |
| `npm run test:behaviour` | 6 behavioural tests against the real engine + Postgres (offline model) |
| `npm run lab` | synthetic-learner lab, offline; writes `lab/out/summary.{md,json}` |
| `npm run lab:live` | same lab with Gemini as tutor, learner-verbaliser and judge (needs the key) |
| `npm run db:push` | apply the schema |

## Configuration

| variable | default | notes |
| --- | --- | --- |
| `DATABASE_URL` | — | Postgres |
| `GEMINI_API_KEY` / `GOOGLE_API_KEY` | — | server-side only |
| `GEMINI_MODEL` | `gemini-3.6-flash` | any Gemini model id; capabilities are described in `GeminiProvider.profile` |
| `LLM_PROVIDER` | auto | `mock` forces the offline model |

## API

| route | purpose |
| --- | --- |
| `POST /api/chat` `{message, sessionId?, mode?}` | streams NDJSON events `session · text · tool · memory · done · error`; `mode` ∈ `layer` (default) · `transcript` · `none` (evaluation baselines) |
| `GET /api/sessions`, `POST /api/sessions`, `GET /api/sessions/:id` | conversations |
| `GET /api/memory` | everything believed about you + the compiled brief |
| `DELETE /api/memory/beliefs/:id` | "that's not true about me" |
| `DELETE /api/memory` | erase everything |
| `GET /api/status`, `GET /api/health` | provider / liveness |

## What is deliberately not here

No curriculum, no item bank, no grading engine, no teaching policy, no style bandit, no affect detection, no concept graph, no embeddings. Each was either shown not to help in previous generations or is already done better by the model itself (see DECISIONS.md). The layer is ~1.5k lines and the pedagogy is entirely the model's.

## Status and gaps

- Built and validated offline (unit, behavioural, lab). **No Gemini key was present in the build sandbox**, so the live path (`GeminiProvider`) is implemented against the current REST documentation but was not exercised against the API here; the live lab has not produced numbers yet.
- Next steps with a key: run `npm run lab:live`, tune the brief wording from real traces, add per-learner forgetting calibration, and consider pgvector once a learner's history exceeds the brief budget regularly.
