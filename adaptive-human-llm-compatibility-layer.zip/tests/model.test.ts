import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { compileBrief } from "../src/lib/memory/brief";
import {
  applyEvidence,
  beliefWeight,
  contradictBelief,
  isBeliefLive,
  newBelief,
  newSkillState,
  predictedRecall,
  retireBelief,
  skillStatus,
  supportBelief,
  CONFIDENCE_CAP,
  DAY_MS,
} from "../src/lib/memory/model";
import type { MemorySnapshot } from "../src/lib/memory/store";
import { sanitizeReflection } from "../src/lib/agent/reflect";
import { MockProvider } from "../src/lib/llm/mock";

const t0 = new Date("2026-09-01T10:00:00Z");
const at = (days: number) => new Date(t0.getTime() + days * DAY_MS);

describe("skill evidence semantics", () => {
  it("a claim is a prior, never a demonstration", () => {
    const s = applyEvidence(newSkillState("x", "X", "t", t0), { kind: "claimed", note: "knows it" }, "s1", t0);
    assert.equal(skillStatus(s, t0), "claimed");
    assert.equal(s.unaidedSuccesses, 0);
    assert.ok(s.pKnown > 0 && s.pKnown < 0.5);
    // A later failure overrides the prior
    const f = applyEvidence(s, { kind: "failed" }, "s1", t0);
    assert.ok(f.pKnown < s.pKnown);
    assert.equal(f.claimedLevel, "knows it"); // claim is remembered as a claim
  });

  it("explanation is exposure, not learning", () => {
    let s = newSkillState("x", "X", "t", t0);
    for (let i = 0; i < 5; i++) s = applyEvidence(s, { kind: "explained" }, "s1", t0);
    assert.equal(skillStatus(s, t0), "exposed");
    assert.ok(s.pKnown <= 0.3);
    assert.equal(s.explanations, 5);
  });

  it("aided success counts less than unaided and does not grow stability", () => {
    const base = newSkillState("x", "X", "t", t0);
    const aided = applyEvidence(base, { kind: "demonstrated", aided: true }, "s1", t0);
    const unaided = applyEvidence(base, { kind: "demonstrated", aided: false }, "s1", t0);
    assert.ok(unaided.pKnown > aided.pKnown);
    assert.ok(unaided.stabilityDays > aided.stabilityDays);
    assert.equal(skillStatus(aided, t0), "learning");
    assert.equal(skillStatus(unaided, t0), "demonstrated");
  });

  it("recall decays with time and spaced success grows stability more than massed", () => {
    let s = applyEvidence(newSkillState("x", "X", "t", t0), { kind: "demonstrated" }, "s1", t0);
    const r0 = predictedRecall(s, t0);
    const r7 = predictedRecall(s, at(7));
    assert.ok(r7 < r0);
    assert.equal(skillStatus(s, at(7)), "fading");
    const massed = applyEvidence(s, { kind: "demonstrated" }, "s1", new Date(t0.getTime() + 60_000));
    const spaced = applyEvidence(s, { kind: "demonstrated" }, "s2", at(3));
    assert.ok(spaced.stabilityDays > massed.stabilityDays);
    s = spaced;
    assert.ok(predictedRecall(s, at(10)) > r7);
  });

  it("misconception is tracked and clears only after repeated unaided success", () => {
    let s = applyEvidence(newSkillState("x", "X", "t", t0), { kind: "misconception", note: "thinks base case is optional" }, "s1", t0);
    assert.equal(skillStatus(s, t0), "misconception");
    s = applyEvidence(s, { kind: "demonstrated" }, "s1", t0);
    assert.equal(s.misconceptionActive, true);
    s = applyEvidence(s, { kind: "demonstrated" }, "s2", at(2));
    assert.equal(s.misconceptionActive, false);
  });
});

describe("belief lifecycle", () => {
  const fact = { key: "prefers_examples", statement: "Prefers examples", kind: "preference" as const, stated: false };

  it("inferred beliefs need two sessions before becoming active; stated ones are active immediately", () => {
    let b = newBelief(fact, "s1", t0);
    assert.equal(b.status, "candidate");
    b = supportBelief(b, fact, "s1", t0)!;
    assert.equal(b.status, "candidate"); // same session
    b = supportBelief(b, fact, "s2", at(1))!;
    assert.equal(b.status, "active");
    const stated = newBelief({ ...fact, stated: true }, "s1", t0);
    assert.equal(stated.status, "active");
    assert.equal(stated.source, "stated");
  });

  it("confidence is capped", () => {
    let b = newBelief({ ...fact, stated: true }, "s1", t0);
    for (let i = 0; i < 20; i++) b = supportBelief(b, { ...fact, stated: true }, `s${i}`, at(i))!;
    assert.ok(b.confidence <= CONFIDENCE_CAP);
  });

  it("correction retires immediately and blocks inferred re-derivation for 14 days, but a fresh statement revives", () => {
    const b = retireBelief(newBelief({ ...fact, stated: true }, "s1", t0), "learner said so", at(1));
    assert.equal(b.status, "retired");
    assert.equal(isBeliefLive(b, at(1)), false);
    assert.equal(supportBelief(b, fact, "s3", at(5)), null); // inferred → blocked
    const revived = supportBelief(b, { ...fact, stated: true }, "s3", at(5));
    assert.equal(revived?.status, "active");
    const later = supportBelief(b, fact, "s9", at(20));
    assert.equal(later, null); // retired beliefs never silently revive from inference
  });

  it("contradictions demote to contested; temporary context expires", () => {
    let b = newBelief({ ...fact, stated: true }, "s1", t0);
    b = contradictBelief(b, at(1));
    assert.equal(b.status, "contested");
    const tired = newBelief({ key: "context_tired", statement: "Is tired", kind: "context", stated: true, temporary: true }, "s1", t0);
    assert.equal(isBeliefLive(tired, t0), true);
    assert.equal(isBeliefLive(tired, at(1)), false);
  });

  it("read-time weight decays with age for durable beliefs", () => {
    const b = newBelief({ ...fact, stated: true }, "s1", t0);
    assert.ok(beliefWeight(b, at(120)) < beliefWeight(b, t0) / 2);
  });
});

describe("brief compiler", () => {
  const profile = new MockProvider().profile;
  const mem = (over: Partial<MemorySnapshot> = {}): MemorySnapshot => ({
    learnerId: "l",
    skills: [],
    beliefs: [],
    approaches: [],
    openLoop: null,
    sessionCount: 2,
    firstSeenAt: t0,
    lastSeenAt: at(1),
    messageCount: 10,
    ...over,
  });

  it("new learner gets a minimal brief", () => {
    const b = compileBrief(mem({ messageCount: 0, sessionCount: 0 }), { now: t0, profile });
    assert.match(b.text, /new learner/i);
    assert.ok(b.approxTokens < 60);
  });

  it("never shows retired beliefs as live and tells the model not to assume them", () => {
    const retired = retireBelief(newBelief({ key: "k", statement: "Prefers analogies", kind: "preference", stated: true }, "s1", t0), "corrected", at(1));
    const b = compileBrief(mem({ beliefs: [retired] }), { now: at(2), profile });
    assert.match(b.text, /Do NOT assume.*Prefers analogies/);
    assert.doesNotMatch(b.text, /\(stated · .*Prefers analogies/);
  });

  it("labels claims as unverified and ranks skills mentioned in the message first", () => {
    const claimed = applyEvidence(newSkillState("closures", "closures", "js", t0), { kind: "claimed", note: "comfortable" }, "s1", t0);
    const demo = applyEvidence(newSkillState("recursion", "recursion", "cs", t0), { kind: "demonstrated" }, "s1", t0);
    const b = compileBrief(mem({ skills: [claimed, demo] }), { now: at(1), profile, currentMessage: "help me with recursion" });
    assert.match(b.text, /claims "comfortable" \(unverified\)/);
    assert.ok(b.text.indexOf("- recursion") < b.text.indexOf("- closures"));
  });

  it("respects the model's brief budget and points to recall_memory for the rest", () => {
    const skills = Array.from({ length: 200 }, (_, i) => applyEvidence(newSkillState(`s${i}`, `Skill number ${i} with a long label`, "t", t0), { kind: "demonstrated" }, "s1", t0));
    const b = compileBrief(mem({ skills }), { now: at(1), profile: { ...profile, briefBudgetTokens: 600 } });
    assert.ok(b.approxTokens < 900, `brief too large: ${b.approxTokens}`);
    assert.ok(b.omitted.skills > 0);
    assert.match(b.text, /recall_memory/);
  });
});

describe("reflection sanitizer", () => {
  it("drops malformed entries and clamps lengths", () => {
    const r = sanitizeReflection({
      evidence: [{ skill: "x", label: "X", topic: "t", kind: "demonstrated", aided: false, note: "ok" }, { skill: "y", label: "Y", topic: "t", kind: "bogus" as never, aided: false, note: "" }],
      facts: [{ key: "k", statement: "", kind: "preference", stated: true, scope: "general", temporary: false }],
      corrections: [{ key: "", note: "" }],
      approach: { approach: "", skill: "" },
      previousApproachOutcome: "nope" as never,
      openLoop: "   ",
    });
    assert.equal(r.evidence.length, 1);
    assert.equal(r.facts.length, 0);
    assert.equal(r.corrections.length, 0);
    assert.equal(r.approach, null);
    assert.equal(r.previousApproachOutcome, null);
    assert.equal(r.openLoop, null);
  });
});
