/**
 * Behavioural tests against the real engine + database with the offline mock model.
 * Run: npm run test:behaviour   (requires DATABASE_URL)
 */
import "dotenv/config";
process.env.LLM_PROVIDER = "mock";

import assert from "node:assert/strict";
import { after, describe, it } from "node:test";
import { pool } from "../src/db";
import { runTurn } from "../src/lib/agent/turn";
import { executeTool } from "../src/lib/agent/tools";
import { getProvider } from "../src/lib/llm";
import { compileBrief } from "../src/lib/memory/brief";
import { DAY_MS } from "../src/lib/memory/model";
import { eraseLearner, loadMemory } from "../src/lib/memory/store";

const t0 = new Date("2026-09-01T10:00:00Z");
const at = (mins: number) => new Date(t0.getTime() + mins * 60_000);
const profile = getProvider().profile;
const brief = async (learnerId: string, now: Date, msg?: string) => compileBrief(await loadMemory(learnerId), { now, profile, currentMessage: msg }).text;

after(() => pool.end());

describe("compatibility layer behaviour", () => {
  it("claims are shown as unverified until demonstrated; demonstration is attributed to the posing turn", async () => {
    const L = "t-claim-" + Date.now();
    await eraseLearner(L);
    await runTurn({ learnerId: L, sessionId: L + "s1", userText: "I already know Bayes' theorem well.", now: at(0) });
    let b = await brief(L, at(1));
    assert.match(b, /Bayes' theorem \[claimed\]/);
    assert.match(b, /\(unverified\)/);
    await runTurn({ learnerId: L, sessionId: L + "s1", userText: "My answer: bayes_theorem-key", now: at(2) });
    b = await brief(L, at(3));
    assert.match(b, /Bayes' theorem \[demonstrated\]/);
    assert.match(b, /1 unaided ✓/);
    await eraseLearner(L);
  });

  it("a learner correction retires the belief, the brief says so, and inference cannot re-create it", async () => {
    const L = "t-corr-" + Date.now();
    await eraseLearner(L);
    await runTurn({ learnerId: L, sessionId: L + "s1", userText: "I prefer worked examples.", now: at(0) });
    assert.match(await brief(L, at(1)), /\(stated · 0\.80 · .*\) Prefers worked examples/);
    await runTurn({ learnerId: L, sessionId: L + "s2", userText: "Actually, I don't prefer worked examples.", now: new Date(t0.getTime() + 2 * DAY_MS) });
    const b = await brief(L, new Date(t0.getTime() + 2 * DAY_MS + 60_000));
    assert.match(b, /Do NOT assume.*Prefers worked examples/);
    assert.doesNotMatch(b, /\(stated · .*Prefers worked examples/);
    const mem = await loadMemory(L);
    const belief = mem.beliefs.find((x) => x.key === "prefers_worked_examples");
    assert.equal(belief?.status, "retired");
    assert.ok(belief?.guardUntil && belief.guardUntil.getTime() > t0.getTime() + 15 * DAY_MS);
    await eraseLearner(L);
  });

  it("approach outcomes are attributed on the NEXT learner turn, not the same turn", async () => {
    const L = "t-attr-" + Date.now();
    await eraseLearner(L);
    const r1 = await runTurn({ learnerId: L, sessionId: L + "s1", userText: "Can you explain closures in JavaScript?", now: at(0) });
    assert.equal(r1.trace.memoryDelta?.approach?.approach, "formal");
    assert.equal(r1.trace.memoryDelta?.resolvedApproach, null);
    const r2 = await runTurn({ learnerId: L, sessionId: L + "s1", userText: "My answer: I'm not sure at all.", now: at(1) });
    assert.equal(r2.trace.memoryDelta?.resolvedApproach?.outcome, "stuck");
    const b = await brief(L, at(2));
    assert.match(b, /stuck after formal/);
    await eraseLearner(L);
  });

  it("temporary context expires instead of becoming a trait", async () => {
    const L = "t-ctx-" + Date.now();
    await eraseLearner(L);
    await runTurn({ learnerId: L, sessionId: L + "s1", userText: "I'm really tired tonight.", now: at(0) });
    assert.match(await brief(L, at(5)), /Is tired right now/);
    assert.doesNotMatch(await brief(L, new Date(t0.getTime() + DAY_MS)), /Is tired right now/);
    await eraseLearner(L);
  });

  it("memory tools work: remember → in brief, recall_memory finds episodes, forget retires", async () => {
    const L = "t-tools-" + Date.now();
    await eraseLearner(L);
    const ctx = { learnerId: L, sessionId: L + "s1", now: at(0) };
    await runTurn({ learnerId: L, sessionId: L + "s1", userText: "Let's talk about monads in Haskell today.", now: at(0) });
    await executeTool("remember", { statement: "Wants to pass the AWS Solutions Architect exam in November", kind: "goal" }, ctx);
    assert.match(await brief(L, at(1)), /AWS Solutions Architect/);
    const rec = (await executeTool("recall_memory", { query: "monads haskell" }, ctx)) as { episodes: unknown[] };
    assert.ok(rec.episodes.length >= 1);
    const fg = (await executeTool("forget", { what: "AWS exam" }, ctx)) as { retired: string[] };
    assert.equal(fg.retired.length, 1);
    assert.doesNotMatch(await brief(L, at(2)), /\(stated · .*AWS Solutions Architect/);
    await eraseLearner(L);
  });

  it("baselines run through the same path: 'none' carries nothing across sessions, 'layer' carries a compact brief", async () => {
    const L = "t-base-" + Date.now();
    await eraseLearner(L);
    await runTurn({ learnerId: L, sessionId: L + "s1", userText: "I prefer analogies.", now: at(0) });
    const none = await runTurn({ learnerId: L, sessionId: L + "s2", userText: "Can you explain TCP three-way handshake?", mode: "none", now: at(60) });
    const layer = await runTurn({ learnerId: L, sessionId: L + "s3", userText: "Can you explain TCP three-way handshake?", mode: "layer", now: at(120) });
    assert.doesNotMatch(none.text, /analogy/);
    assert.match(layer.text, /analogy/);
    assert.equal(none.trace.briefTokens, 0);
    assert.ok(layer.trace.briefTokens > 0 && layer.trace.briefTokens < profile.briefBudgetTokens);
    await eraseLearner(L);
  });
});
