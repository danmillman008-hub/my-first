"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { MemoryPanel } from "./MemoryPanel";

type Msg = {
  id?: number;
  role: "user" | "assistant";
  content: string;
  tools?: { name: string; summary: string }[];
  memory?: MemoryDeltaLite;
  trace?: TraceLite;
  streaming?: boolean;
};
type MemoryDeltaLite = {
  skills: { label: string; kind: string; pKnownBefore: number; pKnownAfter: number }[];
  beliefs: { statement: string; action: string }[];
  approach: { approach: string; skill: string } | null;
  resolvedApproach: { approach: string; skill: string; outcome: string } | null;
  openLoop: string | null;
};
type TraceLite = { mode: string; provider: string; briefTokens: number; promptTokens?: number; durationMs: number; tools?: { name: string; summary: string }[]; memoryDelta?: MemoryDeltaLite };
type Session = { id: string; title: string | null; firstMessage: string | null; lastActiveAt: string; count: number };
type Status = { provider: string; live: boolean; profile: { name: string } };

export function Chat() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<Status | null>(null);
  const [panelOpen, setPanelOpen] = useState(true);
  const [memoryVersion, setMemoryVersion] = useState(0);
  const [showWhy, setShowWhy] = useState<number | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const loadSessions = useCallback(async () => {
    const r = await fetch("/api/sessions");
    if (r.ok) setSessions((await r.json()).sessions);
  }, []);

  useEffect(() => {
    void loadSessions();
    fetch("/api/status")
      .then((r) => r.json())
      .then(setStatus)
      .catch(() => {});
  }, [loadSessions]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs]);

  const openSession = async (id: string) => {
    setSessionId(id);
    const r = await fetch(`/api/sessions/${id}`);
    if (!r.ok) return;
    const data = await r.json();
    setMsgs(
      data.messages.map((m: { id: number; role: "user" | "assistant"; content: string; trace: TraceLite | null }) => ({
        id: m.id,
        role: m.role,
        content: m.content,
        trace: m.trace ?? undefined,
        tools: m.trace?.tools,
        memory: m.trace?.memoryDelta,
      })),
    );
  };

  const newChat = () => {
    setSessionId(null);
    setMsgs([]);
    textareaRef.current?.focus();
  };

  const send = async () => {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    setBusy(true);
    setMsgs((m) => [...m, { role: "user", content: text }, { role: "assistant", content: "", streaming: true, tools: [] }]);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ message: text, sessionId }),
      });
      if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      const apply = (line: string) => {
        if (!line.trim()) return;
        let ev: Record<string, unknown>;
        try {
          ev = JSON.parse(line);
        } catch {
          return;
        }
        setMsgs((m) => {
          const copy = [...m];
          const last = { ...copy[copy.length - 1] };
          if (ev.type === "session") {
            setSessionId((s) => s ?? (ev.sessionId as string));
          } else if (ev.type === "text") {
            last.content += ev.delta as string;
          } else if (ev.type === "tool") {
            last.tools = [...(last.tools ?? []), { name: ev.name as string, summary: ev.summary as string }];
          } else if (ev.type === "memory") {
            last.memory = ev.delta as MemoryDeltaLite;
          } else if (ev.type === "done") {
            last.streaming = false;
            last.id = ev.messageId as number;
            last.trace = ev.trace as TraceLite;
          } else if (ev.type === "error") {
            last.streaming = false;
            last.content = last.content || `⚠️ ${ev.message as string}`;
          }
          copy[copy.length - 1] = last;
          return copy;
        });
      };
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        let i: number;
        while ((i = buf.indexOf("\n")) >= 0) {
          apply(buf.slice(0, i));
          buf = buf.slice(i + 1);
        }
      }
      if (buf) apply(buf);
    } catch (err) {
      setMsgs((m) => {
        const copy = [...m];
        const last = { ...copy[copy.length - 1], streaming: false };
        last.content = last.content || `⚠️ ${err instanceof Error ? err.message : "request failed"}`;
        copy[copy.length - 1] = last;
        return copy;
      });
    } finally {
      setBusy(false);
      setMemoryVersion((v) => v + 1);
      void loadSessions();
    }
  };

  return (
    <div className="flex h-screen w-full bg-[#f7f7f8] text-slate-900">
      {/* Sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-200 bg-white md:flex">
        <div className="p-3">
          <button onClick={newChat} className="w-full rounded-xl border border-slate-200 px-3 py-2 text-left text-sm font-medium hover:bg-slate-50">
            + New chat
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-2 pb-3">
          {sessions.map((s) => (
            <button
              key={s.id}
              onClick={() => openSession(s.id)}
              className={`mb-1 block w-full truncate rounded-lg px-3 py-2 text-left text-sm hover:bg-slate-100 ${s.id === sessionId ? "bg-slate-100 font-medium" : ""}`}
              title={s.firstMessage ?? ""}
            >
              {s.title ?? s.firstMessage ?? "Conversation"}
            </button>
          ))}
          {!sessions.length && <p className="px-3 py-2 text-xs text-slate-400">No conversations yet.</p>}
        </div>
        <div className="border-t border-slate-200 p-3 text-[11px] text-slate-500">
          {status ? (
            <span>
              <span className={`mr-1 inline-block h-2 w-2 rounded-full ${status.live ? "bg-emerald-500" : "bg-amber-400"}`} />
              {status.live ? status.profile.name : "offline mock model (set GEMINI_API_KEY)"}
            </span>
          ) : (
            "…"
          )}
        </div>
      </aside>

      {/* Main */}
      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-4 py-2">
          <div className="flex items-center gap-2">
            <button onClick={newChat} className="rounded-lg px-2 py-1 text-sm hover:bg-slate-100 md:hidden">
              +
            </button>
            <h1 className="text-sm font-semibold tracking-tight">Gemini</h1>
            <span className="text-xs text-slate-400">· with a memory that learns how you learn</span>
          </div>
          <button onClick={() => setPanelOpen((p) => !p)} className="rounded-lg border border-slate-200 px-2.5 py-1 text-xs hover:bg-slate-50">
            {panelOpen ? "Hide" : "What it knows about you"}
          </button>
        </header>

        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-3xl px-4 py-6">
            {!msgs.length && (
              <div className="mt-24 text-center">
                <h2 className="text-2xl font-semibold">What would you like to work on?</h2>
                <p className="mt-2 text-sm text-slate-500">Ask anything, or ask to be taught. It remembers what actually worked for you — and you can correct it any time.</p>
                <div className="mx-auto mt-6 grid max-w-xl grid-cols-1 gap-2 sm:grid-cols-2">
                  {[
                    "I understand recursion, but why do we need a base case?",
                    "Teach me how TCP handshakes work",
                    "Quiz me on what we covered last time",
                    "Just give me the answer: derivative of x·ln(x)?",
                  ].map((s) => (
                    <button key={s} onClick={() => setInput(s)} className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-left text-sm hover:bg-slate-50">
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {msgs.map((m, i) => (
              <div key={i} className={`mb-6 flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[85%] ${m.role === "user" ? "rounded-2xl bg-slate-900 px-4 py-2.5 text-white" : "w-full"}`}>
                  {m.role === "user" ? (
                    <p className="whitespace-pre-wrap text-[15px] leading-relaxed">{m.content}</p>
                  ) : (
                    <div>
                      {m.tools?.map((t, j) => (
                        <div key={j} className="mb-2 inline-flex items-center gap-1 rounded-full border border-slate-200 bg-white px-2.5 py-0.5 text-[11px] text-slate-500">
                          <span className="font-mono">{t.name}</span> · {t.summary}
                        </div>
                      ))}
                      <div className="md text-[15px]">
                        <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content || (m.streaming ? "▍" : "")}</ReactMarkdown>
                      </div>
                      {m.memory && <MemoryChips d={m.memory} />}
                      {m.trace && !m.streaming && (
                        <div className="mt-1">
                          <button onClick={() => setShowWhy(showWhy === i ? null : i)} className="text-[11px] text-slate-400 hover:text-slate-600">
                            {showWhy === i ? "hide" : "why this turn"}
                          </button>
                          {showWhy === i && (
                            <pre className="mt-1 max-h-72 overflow-auto rounded-lg bg-white p-2 text-[11px] text-slate-600 ring-1 ring-slate-200">
                              {JSON.stringify(
                                { mode: m.trace.mode, provider: m.trace.provider, briefTokens: m.trace.briefTokens, promptTokens: m.trace.promptTokens, durationMs: m.trace.durationMs, tools: m.trace.tools, reflection: (m.trace as { reflection?: unknown }).reflection },
                                null,
                                2,
                              )}
                            </pre>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={bottomRef} />
          </div>
        </div>

        <div className="border-t border-slate-200 bg-white p-3">
          <div className="mx-auto flex max-w-3xl items-end gap-2 rounded-2xl border border-slate-300 bg-white px-3 py-2 shadow-sm focus-within:border-slate-400">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send();
                }
              }}
              rows={1}
              placeholder="Message Gemini…"
              className="max-h-40 min-h-[24px] flex-1 resize-none bg-transparent text-[15px] outline-none"
            />
            <button onClick={() => void send()} disabled={busy || !input.trim()} className="rounded-xl bg-slate-900 px-3 py-1.5 text-sm text-white disabled:opacity-40">
              {busy ? "…" : "Send"}
            </button>
          </div>
          <p className="mx-auto mt-1 max-w-3xl text-center text-[11px] text-slate-400">Everything it remembers about you is inspectable and deletable in the panel.</p>
        </div>
      </main>

      {panelOpen && (
        <aside className="hidden w-[22rem] shrink-0 overflow-y-auto border-l border-slate-200 bg-white lg:block">
          <MemoryPanel version={memoryVersion} onChanged={() => setMemoryVersion((v) => v + 1)} />
        </aside>
      )}
    </div>
  );
}

function MemoryChips({ d }: { d: MemoryDeltaLite }) {
  const chips: { text: string; tone: string }[] = [];
  for (const s of d.skills) {
    const dir = s.pKnownAfter > s.pKnownBefore ? "↑" : s.pKnownAfter < s.pKnownBefore ? "↓" : "·";
    chips.push({ text: `${s.kind}: ${s.label} ${dir}`, tone: s.kind === "demonstrated" ? "bg-emerald-50 text-emerald-700" : s.kind === "failed" || s.kind === "misconception" ? "bg-rose-50 text-rose-700" : "bg-slate-100 text-slate-600" });
  }
  for (const b of d.beliefs) chips.push({ text: `${b.action}: ${b.statement}`, tone: b.action === "retired" ? "bg-amber-50 text-amber-700" : "bg-indigo-50 text-indigo-700" });
  if (d.resolvedApproach) chips.push({ text: `${d.resolvedApproach.approach} → ${d.resolvedApproach.outcome}`, tone: "bg-slate-100 text-slate-600" });
  if (!chips.length) return null;
  return (
    <div className="mt-2 flex flex-wrap gap-1">
      {chips.map((c, i) => (
        <span key={i} className={`rounded-full px-2 py-0.5 text-[11px] ${c.tone}`}>
          {c.text}
        </span>
      ))}
    </div>
  );
}
