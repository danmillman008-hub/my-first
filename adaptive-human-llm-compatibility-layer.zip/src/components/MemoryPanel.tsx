"use client";

import { useEffect, useState } from "react";

type Memory = {
  relationship: { sessions: number; messages: number; firstSeenAt: string | null; lastSeenAt: string | null };
  skills: {
    skill: string;
    label: string;
    status: string;
    predictedRecall: number;
    unaidedSuccesses: number;
    aidedSuccesses: number;
    failures: number;
    explanations: number;
    claimedLevel: string | null;
    misconception: string | null;
  }[];
  beliefs: { id: number; statement: string; kind: string; source: string; status: string; live: boolean; confidence: number; supportCount: number; retiredReason: string | null }[];
  approaches: { approach: string; tried: number; progressed: number; stuck: number }[];
  openLoop: { text: string } | null;
  brief: { text: string; approxTokens: number };
};

const STATUS_TONE: Record<string, string> = {
  demonstrated: "bg-emerald-100 text-emerald-800",
  fading: "bg-amber-100 text-amber-800",
  learning: "bg-sky-100 text-sky-800",
  exposed: "bg-slate-100 text-slate-700",
  claimed: "bg-violet-100 text-violet-800",
  misconception: "bg-rose-100 text-rose-800",
  unseen: "bg-slate-100 text-slate-500",
};

export function MemoryPanel({ version, onChanged }: { version: number; onChanged: () => void }) {
  const [mem, setMem] = useState<Memory | null>(null);
  const [tab, setTab] = useState<"skills" | "about" | "brief">("skills");
  const [confirmErase, setConfirmErase] = useState(false);

  useEffect(() => {
    fetch("/api/memory")
      .then((r) => r.json())
      .then(setMem)
      .catch(() => {});
  }, [version]);

  const retire = async (id: number) => {
    await fetch(`/api/memory/beliefs/${id}`, { method: "DELETE" });
    onChanged();
  };
  const erase = async () => {
    await fetch("/api/memory", { method: "DELETE" });
    setConfirmErase(false);
    onChanged();
    location.reload();
  };

  if (!mem) return <div className="p-4 text-xs text-slate-400">Loading…</div>;
  const liveBeliefs = mem.beliefs.filter((b) => b.live);
  const retired = mem.beliefs.filter((b) => !b.live);

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-slate-200 p-4">
        <h2 className="text-sm font-semibold">What it knows about you</h2>
        <p className="mt-0.5 text-[11px] text-slate-500">
          {mem.relationship.sessions} conversation{mem.relationship.sessions === 1 ? "" : "s"} · {mem.relationship.messages} messages · brief ≈{mem.brief.approxTokens} tokens
        </p>
        <div className="mt-3 flex gap-1 text-xs">
          {(["skills", "about", "brief"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`rounded-lg px-2.5 py-1 ${tab === t ? "bg-slate-900 text-white" : "hover:bg-slate-100"}`}>
              {t === "skills" ? `Skills (${mem.skills.length})` : t === "about" ? `About you (${liveBeliefs.length})` : "Model brief"}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 text-sm">
        {tab === "skills" && (
          <div className="space-y-2">
            {mem.openLoop && <div className="rounded-lg border border-dashed border-slate-300 p-2 text-xs text-slate-600">Open thread: {mem.openLoop.text}</div>}
            {!mem.skills.length && <p className="text-xs text-slate-400">Nothing yet. Skills appear as you demonstrate, attempt, or claim them.</p>}
            {mem.skills.map((s) => (
              <div key={s.skill} className="rounded-xl border border-slate-200 p-2.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate font-medium">{s.label}</span>
                  <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] ${STATUS_TONE[s.status] ?? ""}`}>{s.status}</span>
                </div>
                <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full rounded-full bg-emerald-500" style={{ width: `${Math.round(s.predictedRecall * 100)}%` }} />
                </div>
                <p className="mt-1 text-[11px] text-slate-500">
                  recall≈{Math.round(s.predictedRecall * 100)}% · {s.unaidedSuccesses} unaided ✓ · {s.aidedSuccesses} aided ✓ · {s.failures} ✗ · explained {s.explanations}×
                  {s.claimedLevel && <> · claims “{s.claimedLevel}”</>}
                </p>
                {s.misconception && <p className="mt-1 text-[11px] text-rose-700">misconception: {s.misconception}</p>}
              </div>
            ))}
            {!!mem.approaches.length && (
              <div className="mt-4">
                <h3 className="mb-1 text-xs font-semibold text-slate-600">Approaches → your response on the next turn</h3>
                {mem.approaches.map((a) => (
                  <div key={a.approach} className="flex justify-between text-xs text-slate-600">
                    <span className="font-mono">{a.approach}</span>
                    <span>
                      progressed {a.progressed}/{a.tried}
                      {a.stuck ? ` · stuck ${a.stuck}` : ""}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === "about" && (
          <div className="space-y-2">
            {!liveBeliefs.length && <p className="text-xs text-slate-400">Nothing yet. Tell it about yourself, or it will note what you say over time (never from single reactions).</p>}
            {liveBeliefs.map((b) => (
              <div key={b.id} className="rounded-xl border border-slate-200 p-2.5">
                <p>{b.statement}</p>
                <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
                  <span>
                    {b.kind} · {b.source} · {b.status} · {Math.round(b.confidence * 100)}%
                  </span>
                  <button onClick={() => retire(b.id)} className="text-rose-600 hover:underline">
                    not true
                  </button>
                </div>
              </div>
            ))}
            {!!retired.length && (
              <details className="mt-3 text-xs text-slate-500">
                <summary className="cursor-pointer">Retired / expired ({retired.length})</summary>
                {retired.map((b) => (
                  <p key={b.id} className="mt-1 line-through">
                    {b.statement} {b.retiredReason && <span className="no-underline">— {b.retiredReason}</span>}
                  </p>
                ))}
              </details>
            )}
          </div>
        )}

        {tab === "brief" && (
          <div>
            <p className="mb-2 text-[11px] text-slate-500">Exactly what the model receives about you before each reply (advisory, with provenance and age).</p>
            <pre className="whitespace-pre-wrap rounded-xl bg-slate-50 p-3 text-[11px] leading-relaxed text-slate-700 ring-1 ring-slate-200">{mem.brief.text}</pre>
          </div>
        )}
      </div>

      <div className="border-t border-slate-200 p-3 text-[11px]">
        {confirmErase ? (
          <div className="flex items-center justify-between">
            <span className="text-rose-700">Erase everything about you?</span>
            <span className="flex gap-2">
              <button onClick={erase} className="rounded bg-rose-600 px-2 py-0.5 text-white">
                Erase
              </button>
              <button onClick={() => setConfirmErase(false)} className="rounded border px-2 py-0.5">
                Cancel
              </button>
            </span>
          </div>
        ) : (
          <button onClick={() => setConfirmErase(true)} className="text-slate-400 hover:text-rose-600">
            Erase all memory
          </button>
        )}
      </div>
    </div>
  );
}
