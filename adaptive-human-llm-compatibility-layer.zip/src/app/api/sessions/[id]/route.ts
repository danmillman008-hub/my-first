import { db } from "@/db";
import { messages } from "@/db/schema";
import { getLearnerId } from "@/lib/identity";
import { and, asc, eq } from "drizzle-orm";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id: learnerId } = getLearnerId(req);
  const { id } = await ctx.params;
  const rows = await db
    .select({ id: messages.id, role: messages.role, content: messages.content, trace: messages.trace, createdAt: messages.createdAt })
    .from(messages)
    .where(and(eq(messages.sessionId, id), eq(messages.learnerId, learnerId)))
    .orderBy(asc(messages.id));
  return Response.json({ messages: rows });
}
