import { db } from "@/db";
import { messages, sessions } from "@/db/schema";
import { getLearnerId, newSessionId, withLearnerCookie } from "@/lib/identity";
import { asc, desc, eq, inArray } from "drizzle-orm";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const { id, isNew } = getLearnerId(req);
  const rows = await db
    .select({ id: sessions.id, title: sessions.title, startedAt: sessions.startedAt, lastActiveAt: sessions.lastActiveAt })
    .from(sessions)
    .where(eq(sessions.learnerId, id))
    .orderBy(desc(sessions.lastActiveAt))
    .limit(50);

  const ids = rows.map((r) => r.id);
  const firstMessages = new Map<string, string>();
  const counts = new Map<string, number>();
  if (ids.length) {
    const msgs = await db
      .select({ sessionId: messages.sessionId, role: messages.role, content: messages.content })
      .from(messages)
      .where(inArray(messages.sessionId, ids))
      .orderBy(asc(messages.id));
    for (const m of msgs) {
      counts.set(m.sessionId, (counts.get(m.sessionId) ?? 0) + 1);
      if (m.role === "user" && !firstMessages.has(m.sessionId)) firstMessages.set(m.sessionId, m.content.slice(0, 80));
    }
  }
  const out = rows.map((r) => ({ ...r, firstMessage: firstMessages.get(r.id) ?? null, count: counts.get(r.id) ?? 0 }));
  return withLearnerCookie(Response.json({ learnerId: id, sessions: out }), id, isNew);
}

export async function POST(req: NextRequest) {
  const { id, isNew } = getLearnerId(req);
  return withLearnerCookie(Response.json({ sessionId: newSessionId(), learnerId: id }), id, isNew);
}
