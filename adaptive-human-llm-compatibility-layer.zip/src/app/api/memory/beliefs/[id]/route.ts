import { getLearnerId } from "@/lib/identity";
import { retireBeliefById } from "@/lib/memory/store";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

/** DELETE /api/memory/beliefs/:id — the learner says "that's not true about me". */
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id: learnerId } = getLearnerId(req);
  const { id } = await ctx.params;
  const beliefId = Number(id);
  if (!Number.isInteger(beliefId)) return Response.json({ error: "bad id" }, { status: 400 });
  const retired = await retireBeliefById(learnerId, beliefId, "corrected by learner in UI");
  if (!retired) return Response.json({ error: "not found" }, { status: 404 });
  return Response.json({ ok: true, belief: retired });
}
