import { getProvider } from "@/lib/llm";
import { compileBrief } from "@/lib/memory/brief";
import { isBeliefLive, predictedRecall, skillStatus, summarizeApproaches } from "@/lib/memory/model";
import { eraseLearner, listBeliefRows, loadMemory } from "@/lib/memory/store";
import { getLearnerId, withLearnerCookie } from "@/lib/identity";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

/** GET /api/memory — everything the layer believes about this learner, inspectable. */
export async function GET(req: NextRequest) {
  const { id, isNew } = getLearnerId(req);
  const now = new Date();
  const [mem, beliefRows] = await Promise.all([loadMemory(id), listBeliefRows(id)]);
  const brief = compileBrief(mem, { now, profile: getProvider().profile });
  const body = {
    learnerId: id,
    relationship: { sessions: mem.sessionCount, messages: mem.messageCount, firstSeenAt: mem.firstSeenAt, lastSeenAt: mem.lastSeenAt },
    skills: mem.skills
      .map((s) => ({
        skill: s.skill,
        label: s.label,
        topic: s.topic,
        status: skillStatus(s, now),
        predictedRecall: Math.round(predictedRecall(s, now) * 100) / 100,
        pKnown: Math.round(s.pKnown * 100) / 100,
        stabilityDays: Math.round(s.stabilityDays * 10) / 10,
        unaidedSuccesses: s.unaidedSuccesses,
        aidedSuccesses: s.aidedSuccesses,
        failures: s.failures,
        explanations: s.explanations,
        claimedLevel: s.claimedLevel,
        misconception: s.misconceptionActive ? s.misconception : null,
        lastSeenAt: s.lastSeenAt,
      }))
      .sort((a, b) => new Date(b.lastSeenAt).getTime() - new Date(a.lastSeenAt).getTime()),
    beliefs: beliefRows.map((b) => ({
      id: b.id,
      key: b.key,
      statement: b.statement,
      kind: b.kind,
      source: b.source,
      status: b.status,
      live: isBeliefLive(
        { ...b, sessionIds: b.sessionIds ?? [] } as Parameters<typeof isBeliefLive>[0],
        now,
      ),
      confidence: Math.round(b.confidence * 100) / 100,
      supportCount: b.supportCount,
      contradictionCount: b.contradictionCount,
      scope: b.scope,
      lastSeenAt: b.lastSeenAt,
      retiredReason: b.retiredReason,
      expiresAt: b.expiresAt,
    })),
    approaches: summarizeApproaches(mem.approaches.filter((a) => a.outcome !== "pending")),
    openLoop: mem.openLoop,
    brief: { text: brief.text, approxTokens: brief.approxTokens, included: brief.included, omitted: brief.omitted },
  };
  return withLearnerCookie(Response.json(body), id, isNew);
}

/** DELETE /api/memory — erase everything about this learner. */
export async function DELETE(req: NextRequest) {
  const { id } = getLearnerId(req);
  await eraseLearner(id);
  return Response.json({ ok: true });
}
