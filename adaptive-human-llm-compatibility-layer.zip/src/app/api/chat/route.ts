import { runTurn, type TurnEvent, type TurnMode } from "@/lib/agent/turn";
import { getLearnerId, newSessionId, withLearnerCookie } from "@/lib/identity";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

/**
 * POST /api/chat  { message: string, sessionId?: string, mode?: "layer" | "transcript" | "none" }
 * Streams newline-delimited JSON events: text | tool | memory | done | error.
 */
export async function POST(req: NextRequest) {
  const { id: learnerId, isNew } = getLearnerId(req);
  let body: { message?: string; sessionId?: string; mode?: TurnMode };
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "invalid json" }, { status: 400 });
  }
  const message = (body.message ?? "").toString().trim();
  if (!message) return Response.json({ error: "message required" }, { status: 400 });
  if (message.length > 20_000) return Response.json({ error: "message too long" }, { status: 413 });
  const sessionId = body.sessionId && /^[a-zA-Z0-9-]{8,64}$/.test(body.sessionId) ? body.sessionId : newSessionId();
  const mode: TurnMode = body.mode === "transcript" || body.mode === "none" ? body.mode : "layer";

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (e: TurnEvent | { type: "session"; sessionId: string }) => controller.enqueue(encoder.encode(JSON.stringify(e) + "\n"));
      send({ type: "session", sessionId });
      try {
        await runTurn({ learnerId, sessionId, userText: message, mode, onEvent: send, signal: req.signal });
      } catch (err) {
        const msg = err instanceof Error ? err.message : "unknown error";
        console.error("turn failed", err);
        send({ type: "error", message: msg });
      } finally {
        controller.close();
      }
    },
  });

  const res = new Response(stream, {
    headers: { "content-type": "application/x-ndjson; charset=utf-8", "cache-control": "no-store", "x-session-id": sessionId },
  });
  return withLearnerCookie(res, learnerId, isNew);
}
