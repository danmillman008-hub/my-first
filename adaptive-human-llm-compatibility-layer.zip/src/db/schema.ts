import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/**
 * Memory substrate for the Human–LLM compatibility layer.
 *
 * Design rule: everything the LLM cannot do persistently / verifiably lives here.
 * Everything pedagogical (what to explain, how, when to challenge) is decided by the model,
 * informed by a compiled brief built from these tables.
 *
 *  - messages        : raw episodic record (what was said)               — append-only
 *  - observations    : extracted evidence, with provenance to a message   — append-only
 *  - beliefs         : durable statements about the person (lifecycle)   — mutable, auditable
 *  - skill_states    : per-skill evidence model (claimed vs demonstrated, decay)
 *  - approach_ledger : which teaching approach was tried on which skill and what happened
 */

export const learners = pgTable("learners", {
  id: text("id").primaryKey(),
  displayName: text("display_name"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    title: text("title"),
    startedAt: timestamp("started_at", { withTimezone: true }).defaultNow().notNull(),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("sessions_learner_idx").on(t.learnerId, t.lastActiveAt)],
);

export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id").notNull(),
    role: text("role").notNull(), // user | assistant
    content: text("content").notNull(),
    /** Provider-native parts (function calls/responses, thought signatures) for faithful replay. */
    parts: jsonb("parts"),
    /** Trace of what the layer did for this turn (brief size, tools used, reflection). */
    trace: jsonb("trace"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("messages_session_idx").on(t.sessionId, t.id), index("messages_learner_idx").on(t.learnerId, t.id)],
);

export const observations = pgTable(
  "observations",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id").notNull(),
    messageId: integer("message_id"),
    kind: text("kind").notNull(), // evidence | fact | approach | correction | open_loop
    payload: jsonb("payload").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("observations_learner_idx").on(t.learnerId, t.id)],
);

export const beliefs = pgTable(
  "beliefs",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    key: text("key").notNull(), // normalized slug, e.g. "prefers_examples_first"
    statement: text("statement").notNull(), // human readable
    kind: text("kind").notNull(), // preference | background | goal | context | tendency
    source: text("source").notNull(), // stated | inferred
    status: text("status").notNull(), // candidate | active | contested | retired
    confidence: real("confidence").notNull(),
    supportCount: integer("support_count").notNull().default(1),
    contradictionCount: integer("contradiction_count").notNull().default(0),
    sessionIds: jsonb("session_ids").$type<string[]>().notNull().default([]),
    scope: text("scope").notNull().default("general"), // general | <topic>
    firstSeenAt: timestamp("first_seen_at", { withTimezone: true }).defaultNow().notNull(),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).defaultNow().notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
    retiredAt: timestamp("retired_at", { withTimezone: true }),
    retiredReason: text("retired_reason"),
    /** After a learner correction, inference of the same key is blocked until this time. */
    guardUntil: timestamp("guard_until", { withTimezone: true }),
  },
  (t) => [index("beliefs_learner_idx").on(t.learnerId, t.status)],
);

export const skillStates = pgTable(
  "skill_states",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    skill: text("skill").notNull(), // normalized slug
    label: text("label").notNull(),
    topic: text("topic").notNull().default("general"),
    pKnown: real("p_known").notNull().default(0),
    stabilityDays: real("stability_days").notNull().default(1),
    attempts: integer("attempts").notNull().default(0),
    unaidedSuccesses: integer("unaided_successes").notNull().default(0),
    aidedSuccesses: integer("aided_successes").notNull().default(0),
    failures: integer("failures").notNull().default(0),
    explanations: integer("explanations").notNull().default(0),
    claimedLevel: text("claimed_level"), // what the learner *says* (never evidence)
    misconception: text("misconception"),
    misconceptionActive: boolean("misconception_active").notNull().default(false),
    lastSuccessAt: timestamp("last_success_at", { withTimezone: true }),
    lastUnaidedSuccessAt: timestamp("last_unaided_success_at", { withTimezone: true }),
    lastFailureAt: timestamp("last_failure_at", { withTimezone: true }),
    lastExplainedAt: timestamp("last_explained_at", { withTimezone: true }),
    sessionIds: jsonb("session_ids").$type<string[]>().notNull().default([]),
    firstSeenAt: timestamp("first_seen_at", { withTimezone: true }).defaultNow().notNull(),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("skill_states_learner_idx").on(t.learnerId, t.skill)],
);

export const approachLedger = pgTable(
  "approach_ledger",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id").notNull(),
    messageId: integer("message_id"),
    approach: text("approach").notNull(), // worked_example | execution_trace | analogy | socratic | formal | direct_answer | exercise | ...
    skill: text("skill").notNull(),
    outcome: text("outcome").notNull().default("pending"), // pending | progressed | stuck | disengaged | unclear
    note: text("note"),
    triedAt: timestamp("tried_at", { withTimezone: true }).defaultNow().notNull(),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  },
  (t) => [index("approach_learner_idx").on(t.learnerId, t.skill)],
);
