import { db } from "@/db";
import { approachLedger, beliefs, learners, messages, observations, sessions, skillStates } from "@/db/schema";
import { and, desc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import {
  applyEvidence,
  contradictBelief,
  newBelief,
  newSkillState,
  normalizeKey,
  retireBelief,
  supportBelief,
  type Belief,
  type BeliefKind,
  type EvidenceKind,
  type FactInput,
  type SkillState,
} from "./model";

export type MemorySnapshot = {
  learnerId: string;
  skills: SkillState[];
  beliefs: Belief[];
  approaches: { approach: string; skill: string; outcome: string; triedAt: Date; note: string | null }[];
  openLoop: { text: string; at: Date; sessionId: string } | null;
  sessionCount: number;
  firstSeenAt: Date | null;
  lastSeenAt: Date | null;
  messageCount: number;
};

type SkillRow = typeof skillStates.$inferSelect;
type BeliefRow = typeof beliefs.$inferSelect;

const rowToSkill = (r: SkillRow): SkillState => ({
  skill: r.skill,
  label: r.label,
  topic: r.topic,
  pKnown: r.pKnown,
  stabilityDays: r.stabilityDays,
  attempts: r.attempts,
  unaidedSuccesses: r.unaidedSuccesses,
  aidedSuccesses: r.aidedSuccesses,
  failures: r.failures,
  explanations: r.explanations,
  claimedLevel: r.claimedLevel,
  misconception: r.misconception,
  misconceptionActive: r.misconceptionActive,
  lastSuccessAt: r.lastSuccessAt,
  lastUnaidedSuccessAt: r.lastUnaidedSuccessAt,
  lastFailureAt: r.lastFailureAt,
  lastExplainedAt: r.lastExplainedAt,
  sessionIds: r.sessionIds ?? [],
  firstSeenAt: r.firstSeenAt,
  lastSeenAt: r.lastSeenAt,
});

const rowToBelief = (r: BeliefRow): Belief => ({
  key: r.key,
  statement: r.statement,
  kind: r.kind as BeliefKind,
  source: r.source as Belief["source"],
  status: r.status as Belief["status"],
  confidence: r.confidence,
  supportCount: r.supportCount,
  contradictionCount: r.contradictionCount,
  sessionIds: r.sessionIds ?? [],
  scope: r.scope,
  firstSeenAt: r.firstSeenAt,
  lastSeenAt: r.lastSeenAt,
  expiresAt: r.expiresAt,
  retiredAt: r.retiredAt,
  retiredReason: r.retiredReason,
  guardUntil: r.guardUntil,
});

export async function ensureLearner(learnerId: string) {
  await db.insert(learners).values({ id: learnerId }).onConflictDoNothing();
}

export async function loadMemory(learnerId: string): Promise<MemorySnapshot> {
  const [skillRows, beliefRows, approachRows, loopRows, sessionRows, msgCount] = await Promise.all([
    db.select().from(skillStates).where(eq(skillStates.learnerId, learnerId)),
    db.select().from(beliefs).where(eq(beliefs.learnerId, learnerId)).orderBy(desc(beliefs.lastSeenAt)),
    db
      .select()
      .from(approachLedger)
      .where(eq(approachLedger.learnerId, learnerId))
      .orderBy(desc(approachLedger.triedAt))
      .limit(200),
    db
      .select()
      .from(observations)
      .where(and(eq(observations.learnerId, learnerId), eq(observations.kind, "open_loop")))
      .orderBy(desc(observations.id))
      .limit(1),
    db.select({ id: sessions.id, startedAt: sessions.startedAt, lastActiveAt: sessions.lastActiveAt }).from(sessions).where(eq(sessions.learnerId, learnerId)),
    db.select({ n: sql<number>`count(*)::int` }).from(messages).where(eq(messages.learnerId, learnerId)),
  ]);

  const loop = loopRows[0];
  const loopPayload = loop?.payload as { text?: string } | undefined;
  return {
    learnerId,
    skills: skillRows.map(rowToSkill),
    beliefs: beliefRows.map(rowToBelief),
    approaches: approachRows.map((r) => ({ approach: r.approach, skill: r.skill, outcome: r.outcome, triedAt: r.triedAt, note: r.note })),
    openLoop: loop && loopPayload?.text ? { text: loopPayload.text, at: loop.createdAt, sessionId: loop.sessionId } : null,
    sessionCount: sessionRows.length,
    firstSeenAt: sessionRows.length ? new Date(Math.min(...sessionRows.map((s) => s.startedAt.getTime()))) : null,
    lastSeenAt: sessionRows.length ? new Date(Math.max(...sessionRows.map((s) => s.lastActiveAt.getTime()))) : null,
    messageCount: msgCount[0]?.n ?? 0,
  };
}

// ---------------- Reflection output → memory (deterministic application) ----------------

export type ReflectionOutput = {
  evidence: { skill: string; label: string; topic: string; kind: EvidenceKind; aided: boolean; note: string }[];
  facts: { key: string; statement: string; kind: BeliefKind; stated: boolean; scope: string; temporary: boolean }[];
  corrections: { key: string; note: string }[];
  approach: { approach: string; skill: string } | null;
  previousApproachOutcome: "progressed" | "stuck" | "disengaged" | "unclear" | null;
  openLoop: string | null;
};

export type MemoryDelta = {
  skills: { skill: string; label: string; kind: EvidenceKind; pKnownBefore: number; pKnownAfter: number }[];
  beliefs: { key: string; statement: string; action: "created" | "supported" | "contradicted" | "retired" | "blocked" | "revived" }[];
  approach: { approach: string; skill: string } | null;
  resolvedApproach: { approach: string; skill: string; outcome: string } | null;
  openLoop: string | null;
};

export async function applyReflection(
  learnerId: string,
  sessionId: string,
  messageId: number | null,
  r: ReflectionOutput,
  now = new Date(),
): Promise<MemoryDelta> {
  const delta: MemoryDelta = { skills: [], beliefs: [], approach: null, resolvedApproach: null, openLoop: null };

  // 1. Resolve the previous pending approach (attribution: next learner response on the same thread).
  if (r.previousApproachOutcome) {
    const pending = await db
      .select()
      .from(approachLedger)
      .where(and(eq(approachLedger.learnerId, learnerId), eq(approachLedger.outcome, "pending")))
      .orderBy(desc(approachLedger.id))
      .limit(1);
    if (pending[0]) {
      await db.update(approachLedger).set({ outcome: r.previousApproachOutcome, resolvedAt: now }).where(eq(approachLedger.id, pending[0].id));
      delta.resolvedApproach = { approach: pending[0].approach, skill: pending[0].skill, outcome: r.previousApproachOutcome };
    }
  }

  // 2. Evidence → skill states.
  for (const ev of r.evidence) {
    const skill = normalizeKey(ev.skill || ev.label);
    if (!skill) continue;
    const existing = await db
      .select()
      .from(skillStates)
      .where(and(eq(skillStates.learnerId, learnerId), eq(skillStates.skill, skill)))
      .limit(1);
    const prev = existing[0] ? rowToSkill(existing[0]) : newSkillState(skill, ev.label || skill, ev.topic || "general", now);
    const next = applyEvidence(prev, { kind: ev.kind, aided: ev.aided, note: ev.note }, sessionId, now);
    const values = { ...next, learnerId };
    if (existing[0]) {
      await db.update(skillStates).set(values).where(eq(skillStates.id, existing[0].id));
    } else {
      await db.insert(skillStates).values(values);
    }
    delta.skills.push({ skill, label: next.label, kind: ev.kind, pKnownBefore: prev.pKnown, pKnownAfter: next.pKnown });
    await db.insert(observations).values({ learnerId, sessionId, messageId, kind: "evidence", payload: { ...ev, skill }, createdAt: now });
  }

  // 3. Corrections first (they must win over facts extracted from the same turn).
  for (const c of r.corrections) {
    const key = normalizeKey(c.key);
    const rows = await db
      .select()
      .from(beliefs)
      .where(and(eq(beliefs.learnerId, learnerId), or(eq(beliefs.key, key), ilike(beliefs.key, `%${key.replace(/^prefers_/, "")}%`))));
    for (const row of rows) {
      if (row.status === "retired") continue;
      const retired = retireBelief(rowToBelief(row), c.note || "learner correction", now);
      await db.update(beliefs).set({ ...retired }).where(eq(beliefs.id, row.id));
      delta.beliefs.push({ key: row.key, statement: row.statement, action: "retired" });
    }
    await db.insert(observations).values({ learnerId, sessionId, messageId, kind: "correction", payload: { ...c, key }, createdAt: now });
  }

  // 4. Facts → beliefs.
  for (const f of r.facts) {
    const key = normalizeKey(f.key);
    if (!key) continue;
    if (r.corrections.some((c) => normalizeKey(c.key) === key)) continue; // never re-create what was just corrected
    const fact: FactInput = { ...f, key };
    const rows = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, learnerId), eq(beliefs.key, key))).orderBy(desc(beliefs.id)).limit(1);
    const prevRow = rows[0];
    if (!prevRow) {
      const b = newBelief(fact, sessionId, now);
      await db.insert(beliefs).values({ ...b, learnerId });
      delta.beliefs.push({ key, statement: b.statement, action: "created" });
    } else {
      const prev = rowToBelief(prevRow);
      const next = supportBelief(prev, fact, sessionId, now);
      if (!next) {
        delta.beliefs.push({ key, statement: prev.statement, action: "blocked" });
      } else if (prev.status === "retired") {
        await db.insert(beliefs).values({ ...next, learnerId });
        delta.beliefs.push({ key, statement: next.statement, action: "revived" });
      } else {
        await db.update(beliefs).set({ ...next }).where(eq(beliefs.id, prevRow.id));
        delta.beliefs.push({ key, statement: next.statement, action: "supported" });
      }
    }
    await db.insert(observations).values({ learnerId, sessionId, messageId, kind: "fact", payload: { ...fact }, createdAt: now });
  }

  // 5. Approach used this turn → pending ledger entry.
  if (r.approach?.approach) {
    const skill = normalizeKey(r.approach.skill || "general");
    await db.insert(approachLedger).values({ learnerId, sessionId, messageId, approach: normalizeKey(r.approach.approach), skill, outcome: "pending", triedAt: now });
    delta.approach = { approach: normalizeKey(r.approach.approach), skill };
  }

  // 6. Open loop.
  if (r.openLoop !== null) {
    await db.insert(observations).values({ learnerId, sessionId, messageId, kind: "open_loop", payload: { text: r.openLoop }, createdAt: now });
    delta.openLoop = r.openLoop;
  }

  return delta;
}

// ---------------- Direct learner control (inspect / correct / erase) ----------------

export async function retireBeliefById(learnerId: string, id: number, reason: string, now = new Date()) {
  const rows = await db.select().from(beliefs).where(and(eq(beliefs.id, id), eq(beliefs.learnerId, learnerId))).limit(1);
  if (!rows[0]) return null;
  const retired = retireBelief(rowToBelief(rows[0]), reason, now);
  await db.update(beliefs).set({ ...retired }).where(eq(beliefs.id, id));
  await db.insert(observations).values({ learnerId, sessionId: "ui", kind: "correction", payload: { key: rows[0].key, note: reason, via: "ui" } });
  return retired;
}

export async function markBeliefContradicted(learnerId: string, key: string, now = new Date()) {
  const rows = await db.select().from(beliefs).where(and(eq(beliefs.learnerId, learnerId), eq(beliefs.key, key), inArray(beliefs.status, ["active", "candidate", "contested"])));
  for (const row of rows) {
    await db.update(beliefs).set({ ...contradictBelief(rowToBelief(row), now) }).where(eq(beliefs.id, row.id));
  }
}

export async function eraseLearner(learnerId: string) {
  await Promise.all([
    db.delete(approachLedger).where(eq(approachLedger.learnerId, learnerId)),
    db.delete(observations).where(eq(observations.learnerId, learnerId)),
    db.delete(beliefs).where(eq(beliefs.learnerId, learnerId)),
    db.delete(skillStates).where(eq(skillStates.learnerId, learnerId)),
    db.delete(messages).where(eq(messages.learnerId, learnerId)),
  ]);
  await db.delete(sessions).where(eq(sessions.learnerId, learnerId));
  await db.delete(learners).where(eq(learners.id, learnerId));
}

/** Lexical episodic search (adequate at single-learner scale; see docs/MEMORY.md for the embedding decision). */
export async function searchEpisodes(learnerId: string, query: string, limit = 8) {
  const terms = query
    .toLowerCase()
    .split(/\W+/)
    .filter((t) => t.length > 2)
    .slice(0, 6);
  if (!terms.length) return [];
  const conds = terms.map((t) => ilike(messages.content, `%${t}%`));
  const rows = await db
    .select({ id: messages.id, role: messages.role, content: messages.content, createdAt: messages.createdAt, sessionId: messages.sessionId })
    .from(messages)
    .where(and(eq(messages.learnerId, learnerId), or(...conds)))
    .orderBy(desc(messages.id))
    .limit(limit * 3);
  // Rank by number of matched terms, then recency.
  return rows
    .map((r) => ({ ...r, score: terms.filter((t) => r.content.toLowerCase().includes(t)).length }))
    .sort((a, b) => b.score - a.score || b.id - a.id)
    .slice(0, limit);
}

export async function listBeliefRows(learnerId: string) {
  return db.select().from(beliefs).where(eq(beliefs.learnerId, learnerId)).orderBy(desc(beliefs.lastSeenAt));
}
