/**
 * Pure memory semantics. No I/O. Everything here is deterministic and unit-tested.
 *
 * Inherited (and re-validated in the archive's labs) rules:
 *  - A self-report is a claim, never evidence. It sets a weak prior only when nothing was demonstrated.
 *  - Aided success counts half; only unaided success grows stability meaningfully.
 *  - Spaced success (> 1 day since last success) grows stability much more than massed success.
 *  - Being explained something is exposure, not learning: small bump, tracked separately.
 *  - Inferred beliefs need ≥2 supports across ≥2 sessions before they are shown as active.
 *  - A learner correction retires a belief immediately and blocks re-inference for 14 days.
 *  - Temporary context ("I'm tired") expires within hours and never becomes a trait.
 *  - Confidence is capped (0.92): the layer must never present a belief as certain.
 */

export const DAY_MS = 86_400_000;
export const CONFIDENCE_CAP = 0.92;
export const CORRECTION_GUARD_DAYS = 14;
export const TEMP_CONTEXT_HOURS = 6;
export const DESIRED_RETENTION = 0.85;

export type EvidenceKind = "demonstrated" | "failed" | "claimed" | "explained" | "misconception";

export type SkillState = {
  skill: string;
  label: string;
  topic: string;
  pKnown: number;
  stabilityDays: number;
  attempts: number;
  unaidedSuccesses: number;
  aidedSuccesses: number;
  failures: number;
  explanations: number;
  claimedLevel: string | null;
  misconception: string | null;
  misconceptionActive: boolean;
  lastSuccessAt: Date | null;
  lastUnaidedSuccessAt: Date | null;
  lastFailureAt: Date | null;
  lastExplainedAt: Date | null;
  sessionIds: string[];
  firstSeenAt: Date;
  lastSeenAt: Date;
};

export function newSkillState(skill: string, label: string, topic: string, now: Date): SkillState {
  return {
    skill,
    label,
    topic,
    pKnown: 0,
    stabilityDays: 1,
    attempts: 0,
    unaidedSuccesses: 0,
    aidedSuccesses: 0,
    failures: 0,
    explanations: 0,
    claimedLevel: null,
    misconception: null,
    misconceptionActive: false,
    lastSuccessAt: null,
    lastUnaidedSuccessAt: null,
    lastFailureAt: null,
    lastExplainedAt: null,
    sessionIds: [],
    firstSeenAt: now,
    lastSeenAt: now,
  };
}

/** Half-life recall model: p = pKnown · 2^(−Δt / stability). */
export function predictedRecall(s: Pick<SkillState, "pKnown" | "stabilityDays" | "lastSuccessAt">, now: Date): number {
  if (!s.lastSuccessAt) return s.pKnown;
  const days = Math.max(0, (now.getTime() - s.lastSuccessAt.getTime()) / DAY_MS);
  return s.pKnown * Math.pow(2, -days / Math.max(0.1, s.stabilityDays));
}

export type SkillStatus = "unseen" | "claimed" | "exposed" | "learning" | "demonstrated" | "fading" | "misconception";

export function skillStatus(s: SkillState, now: Date): SkillStatus {
  if (s.misconceptionActive) return "misconception";
  if (s.unaidedSuccesses === 0 && s.aidedSuccesses === 0) {
    if (s.failures > 0) return "learning";
    if (s.explanations > 0) return "exposed";
    if (s.claimedLevel) return "claimed";
    return "unseen";
  }
  if (s.unaidedSuccesses === 0) return "learning";
  const r = predictedRecall(s, now);
  const decayed = r < s.pKnown * 0.85; // time has actually eroded it
  if (decayed && r < DESIRED_RETENTION) return "fading";
  if (s.pKnown < 0.5) return "learning";
  return "demonstrated";
}

export function applyEvidence(
  prev: SkillState,
  ev: { kind: EvidenceKind; aided?: boolean; note?: string; claimedLevel?: string },
  sessionId: string,
  now: Date,
): SkillState {
  const s: SkillState = { ...prev, lastSeenAt: now, sessionIds: prev.sessionIds.includes(sessionId) ? prev.sessionIds : [...prev.sessionIds, sessionId] };
  const daysSinceSuccess = s.lastSuccessAt ? (now.getTime() - s.lastSuccessAt.getTime()) / DAY_MS : Infinity;
  const spaced = daysSinceSuccess >= 1;

  switch (ev.kind) {
    case "demonstrated": {
      const p = predictedRecall(s, now);
      const weight = ev.aided ? 0.5 : 1;
      // Desirable difficulty: a success when recall was low is worth more.
      const gain = weight * 0.35 * (1 - p) * (1 + (1 - p));
      s.pKnown = clamp(Math.max(p, s.pKnown * 0.5) + gain, 0, 0.98);
      s.attempts++;
      if (ev.aided) s.aidedSuccesses++;
      else s.unaidedSuccesses++;
      if (!ev.aided) {
        s.stabilityDays = spaced ? s.stabilityDays * (1.8 + 1.5 * (1 - p)) : Math.min(s.stabilityDays * 1.25, Math.max(s.stabilityDays, 3));
        s.lastUnaidedSuccessAt = now;
      } else {
        s.stabilityDays = Math.max(s.stabilityDays, 1.5);
      }
      s.lastSuccessAt = now;
      // A claim verified by an unaided demonstration with no prior teaching here = pre-existing, stable knowledge.
      if (!ev.aided && prev.claimedLevel && prev.explanations === 0 && prev.failures === 0) {
        s.pKnown = Math.max(s.pKnown, 0.85);
        s.stabilityDays = Math.max(s.stabilityDays, 14);
      }
      // A correct answer on a misconception-tagged skill is weak evidence the misconception is gone.
      if (s.misconceptionActive && !ev.aided && s.unaidedSuccesses >= 2) s.misconceptionActive = false;
      break;
    }
    case "failed": {
      const p = predictedRecall(s, now);
      s.pKnown = clamp(p * 0.6, 0, 1);
      s.stabilityDays = Math.max(0.5, s.stabilityDays * 0.7);
      s.attempts++;
      s.failures++;
      s.lastFailureAt = now;
      break;
    }
    case "claimed": {
      s.claimedLevel = ev.claimedLevel ?? ev.note ?? "knows it";
      // Prior only when nothing has been demonstrated.
      if (s.unaidedSuccesses + s.aidedSuccesses + s.failures === 0) s.pKnown = Math.max(s.pKnown, 0.35);
      break;
    }
    case "explained": {
      s.explanations++;
      s.lastExplainedAt = now;
      // Exposure ≠ learning, but it is not nothing.
      if (s.unaidedSuccesses === 0) s.pKnown = clamp(Math.max(s.pKnown, 0.08 + 0.04 * Math.min(s.explanations, 3)), 0, 0.3);
      break;
    }
    case "misconception": {
      s.misconception = ev.note ?? s.misconception ?? "misconception observed";
      s.misconceptionActive = true;
      s.pKnown = clamp(predictedRecall(s, now) * 0.7, 0, 1);
      break;
    }
  }
  return s;
}

// ---------------- Beliefs ----------------

export type BeliefKind = "preference" | "background" | "goal" | "context" | "tendency";
export type BeliefSource = "stated" | "inferred";
export type BeliefStatus = "candidate" | "active" | "contested" | "retired";

export type Belief = {
  key: string;
  statement: string;
  kind: BeliefKind;
  source: BeliefSource;
  status: BeliefStatus;
  confidence: number;
  supportCount: number;
  contradictionCount: number;
  sessionIds: string[];
  scope: string;
  firstSeenAt: Date;
  lastSeenAt: Date;
  expiresAt: Date | null;
  retiredAt: Date | null;
  retiredReason: string | null;
  guardUntil: Date | null;
};

export type FactInput = {
  key: string;
  statement: string;
  kind: BeliefKind;
  stated: boolean;
  scope?: string;
  temporary?: boolean;
};

export function newBelief(f: FactInput, sessionId: string, now: Date): Belief {
  const temporary = f.temporary || f.kind === "context";
  const b: Belief = {
    key: f.key,
    statement: f.statement,
    kind: f.kind,
    source: f.stated ? "stated" : "inferred",
    status: f.stated ? "active" : "candidate",
    confidence: f.stated ? 0.8 : 0.4,
    supportCount: 1,
    contradictionCount: 0,
    sessionIds: [sessionId],
    scope: f.scope ?? "general",
    firstSeenAt: now,
    lastSeenAt: now,
    expiresAt: temporary ? new Date(now.getTime() + TEMP_CONTEXT_HOURS * 3_600_000) : null,
    retiredAt: null,
    retiredReason: null,
    guardUntil: null,
  };
  return b;
}

/** Fold a new observation of the same key into an existing belief. Returns null if blocked by a correction guard. */
export function supportBelief(prev: Belief, f: FactInput, sessionId: string, now: Date): Belief | null {
  if (prev.status === "retired") {
    if (prev.guardUntil && prev.guardUntil > now && !f.stated) return null; // blocked: inferred re-derivation after correction
    // A fresh *stated* fact revives as a new belief.
    return f.stated ? newBelief(f, sessionId, now) : null;
  }
  const b: Belief = { ...prev, lastSeenAt: now, statement: f.statement || prev.statement };
  b.supportCount++;
  if (!b.sessionIds.includes(sessionId)) b.sessionIds = [...b.sessionIds, sessionId];
  if (f.stated) {
    b.source = "stated";
    b.confidence = Math.min(CONFIDENCE_CAP, b.confidence + 0.1);
    b.status = "active";
  } else {
    b.confidence = Math.min(CONFIDENCE_CAP, b.confidence + 0.12);
    if (b.status === "candidate" && b.supportCount >= 2 && b.sessionIds.length >= 2) b.status = "active";
    if (b.status === "candidate" && b.supportCount >= 3) b.status = "active";
  }
  if (b.expiresAt) b.expiresAt = new Date(now.getTime() + TEMP_CONTEXT_HOURS * 3_600_000);
  return b;
}

export function contradictBelief(prev: Belief, now: Date): Belief {
  const b: Belief = { ...prev, lastSeenAt: now };
  b.contradictionCount++;
  b.confidence = Math.max(0.05, b.confidence - 0.2);
  if (b.contradictionCount >= b.supportCount) b.status = "contested";
  return b;
}

/** Learner says "that's not true about me". Immediate retirement + re-derivation guard. */
export function retireBelief(prev: Belief, reason: string, now: Date): Belief {
  return {
    ...prev,
    status: "retired",
    retiredAt: now,
    retiredReason: reason,
    guardUntil: new Date(now.getTime() + CORRECTION_GUARD_DAYS * DAY_MS),
    lastSeenAt: now,
  };
}

export function isBeliefLive(b: Belief, now: Date): boolean {
  if (b.status === "retired") return false;
  if (b.expiresAt && b.expiresAt <= now) return false;
  return true;
}

/** Read-time influence: how much weight a belief should carry right now (recency + status + source). */
export function beliefWeight(b: Belief, now: Date): number {
  const ageDays = (now.getTime() - b.lastSeenAt.getTime()) / DAY_MS;
  const recency = b.kind === "context" ? 1 : Math.pow(0.5, ageDays / 60); // 60-day half-life for durable beliefs
  const statusFactor = b.status === "active" ? 1 : b.status === "contested" ? 0.5 : 0.35;
  return b.confidence * recency * statusFactor;
}

// ---------------- Approach ledger ----------------

export type ApproachOutcome = "pending" | "progressed" | "stuck" | "disengaged" | "unclear";

export type ApproachStats = { approach: string; tried: number; progressed: number; stuck: number };

export function summarizeApproaches(rows: { approach: string; outcome: string }[]): ApproachStats[] {
  const m = new Map<string, ApproachStats>();
  for (const r of rows) {
    const s = m.get(r.approach) ?? { approach: r.approach, tried: 0, progressed: 0, stuck: 0 };
    s.tried++;
    if (r.outcome === "progressed") s.progressed++;
    if (r.outcome === "stuck" || r.outcome === "disengaged") s.stuck++;
    m.set(r.approach, s);
  }
  return [...m.values()].sort((a, b) => b.tried - a.tried);
}

export function clamp(x: number, lo: number, hi: number) {
  return Math.min(hi, Math.max(lo, x));
}

export function normalizeKey(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 64);
}

/** Session boundary: inferred from an inactivity gap (no explicit "start session" needed). */
export const SESSION_GAP_MS = 45 * 60_000;
