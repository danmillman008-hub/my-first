import type { ModelProfile } from "@/lib/llm/types";
import { beliefWeight, isBeliefLive, predictedRecall, skillStatus, summarizeApproaches, DAY_MS, type SkillState } from "./model";
import type { MemorySnapshot } from "./store";

/**
 * Context compiler: memory snapshot → compact "learner brief" for the model.
 *
 * Principles
 *  - Advisory, not prescriptive: every line is evidence with provenance, confidence and age;
 *    the model decides what to do with it.
 *  - Budgeted: `profile.briefBudgetTokens` bounds what is inlined; the rest is reachable by tool.
 *  - Relevance-ranked: skills mentioned in the current message, misconceptions, fading skills and
 *    open loops come first.
 *  - Never presents a claim as demonstrated, or an inference as a fact.
 */

export type BriefOptions = {
  now?: Date;
  currentMessage?: string;
  profile: ModelProfile;
};

export type CompiledBrief = {
  text: string;
  approxTokens: number;
  included: { skills: number; beliefs: number; approaches: number };
  omitted: { skills: number; beliefs: number };
};

export function compileBrief(mem: MemorySnapshot, opts: BriefOptions): CompiledBrief {
  const now = opts.now ?? new Date();
  const budgetChars = opts.profile.briefBudgetTokens * 4;
  const msg = (opts.currentMessage ?? "").toLowerCase();

  const lines: string[] = [];
  const push = (s: string) => lines.push(s);

  // ---- header
  const isNew = mem.messageCount === 0;
  if (isNew) {
    push("# Learner brief");
    push("This is a new learner. No history yet. Learn about them through the conversation; do not assume a level.");
    return finish(lines, { skills: 0, beliefs: 0, approaches: 0 }, { skills: 0, beliefs: 0 });
  }
  push("# Learner brief (compiled from evidence; advisory)");
  push(
    `Relationship: ${mem.sessionCount} session${mem.sessionCount === 1 ? "" : "s"}, ${mem.messageCount} messages` +
      (mem.lastSeenAt ? `, last active ${age(mem.lastSeenAt, now)}` : "") +
      (mem.firstSeenAt ? `, since ${mem.firstSeenAt.toISOString().slice(0, 10)}` : "") +
      ".",
  );

  // ---- open loop
  if (mem.openLoop && now.getTime() - mem.openLoop.at.getTime() < 14 * DAY_MS) {
    push(`Open thread (${age(mem.openLoop.at, now)}): ${mem.openLoop.text}`);
  }

  // ---- beliefs
  const live = mem.beliefs.filter((b) => isBeliefLive(b, now)).sort((a, b) => beliefWeight(b, now) - beliefWeight(a, now));
  const retiredRecently = mem.beliefs.filter((b) => b.status === "retired" && b.retiredAt && now.getTime() - b.retiredAt.getTime() < 30 * DAY_MS);
  let beliefsIncluded = 0;
  if (live.length) {
    push("");
    push("## About this person (source · confidence · last seen)");
    for (const b of live) {
      if (charCount(lines) > budgetChars * 0.35) break;
      const flag = b.status === "candidate" ? " · tentative" : b.status === "contested" ? " · contested" : "";
      const scope = b.scope !== "general" ? ` · scope: ${b.scope}` : "";
      push(`- (${b.source} · ${b.confidence.toFixed(2)} · ${age(b.lastSeenAt, now)}${flag}${scope}) ${b.statement}`);
      beliefsIncluded++;
    }
  }
  if (retiredRecently.length) {
    push(`Do NOT assume (learner corrected this): ${retiredRecently.map((b) => `"${b.statement}"`).join("; ")}.`);
  }

  // ---- skills
  const ranked = rankSkills(mem.skills, msg, now);
  let skillsIncluded = 0;
  if (ranked.length) {
    push("");
    push("## Skill evidence (what they demonstrated vs. claimed; predicted recall decays with time)");
    for (const s of ranked) {
      if (charCount(lines) > budgetChars * 0.85) break;
      push(skillLine(s, mem, now));
      skillsIncluded++;
    }
  }

  // ---- approaches
  const stats = summarizeApproaches(mem.approaches.filter((a) => a.outcome !== "pending"));
  let approachesIncluded = 0;
  if (stats.length && charCount(lines) < budgetChars * 0.95) {
    push("");
    push("## What has been tried (approach → learner response on the next turn)");
    push(
      stats
        .slice(0, 6)
        .map((s) => `${s.approach}: progressed ${s.progressed}/${s.tried}${s.stuck ? `, stuck ${s.stuck}` : ""}`)
        .join(" · "),
    );
    approachesIncluded = Math.min(6, stats.length);
  }

  return finish(
    lines,
    { skills: skillsIncluded, beliefs: beliefsIncluded, approaches: approachesIncluded },
    { skills: ranked.length - skillsIncluded, beliefs: live.length - beliefsIncluded },
  );
}

function finish(lines: string[], included: CompiledBrief["included"], omitted: CompiledBrief["omitted"]): CompiledBrief {
  if (omitted.skills > 0 || omitted.beliefs > 0) {
    lines.push("");
    lines.push(`(${omitted.skills} more skills and ${omitted.beliefs} more notes are not shown — use recall_memory to look them up.)`);
  }
  const text = lines.join("\n");
  return { text, approxTokens: Math.ceil(text.length / 4), included, omitted };
}

function rankSkills(skills: SkillState[], msg: string, now: Date): SkillState[] {
  const score = (s: SkillState) => {
    let v = 0;
    const st = skillStatus(s, now);
    if (msg && (msg.includes(s.label.toLowerCase()) || msg.includes(s.skill.replace(/_/g, " ")))) v += 100;
    if (st === "misconception") v += 40;
    if (st === "fading") v += 25;
    if (st === "learning") v += 20;
    if (st === "claimed") v += 15;
    if (st === "exposed") v += 10;
    const ageDays = (now.getTime() - s.lastSeenAt.getTime()) / DAY_MS;
    v += Math.max(0, 15 - ageDays);
    return v;
  };
  return [...skills].sort((a, b) => score(b) - score(a));
}

function skillLine(s: SkillState, mem: MemorySnapshot, now: Date): string {
  const st = skillStatus(s, now);
  const recall = Math.round(predictedRecall(s, now) * 100);
  const bits: string[] = [];
  if (s.unaidedSuccesses) bits.push(`${s.unaidedSuccesses} unaided ✓`);
  if (s.aidedSuccesses) bits.push(`${s.aidedSuccesses} aided ✓`);
  if (s.failures) bits.push(`${s.failures} ✗`);
  if (s.explanations) bits.push(`explained ${s.explanations}× (last ${s.lastExplainedAt ? age(s.lastExplainedAt, now) : "?"})`);
  if (s.claimedLevel) bits.push(`claims "${s.claimedLevel}"${s.unaidedSuccesses ? "" : " (unverified)"}`);
  if (s.misconceptionActive && s.misconception) bits.push(`active misconception: ${s.misconception}`);
  const tried = mem.approaches.filter((a) => a.skill === s.skill && a.outcome !== "pending");
  const stuck = tried.filter((a) => a.outcome === "stuck" || a.outcome === "disengaged");
  const ok = tried.filter((a) => a.outcome === "progressed");
  const stuckStr = countBy(stuck.map((a) => a.approach))
    .map(([k, n]) => `stuck after ${k}${n > 1 ? ` ×${n}` : ""}`)
    .join(", ");
  const okStr = countBy(ok.map((a) => a.approach))
    .map(([k, n]) => `progressed after ${k}${n > 1 ? ` ×${n}` : ""}`)
    .join(", ");
  const tail = [stuckStr, okStr].filter(Boolean).join("; ");
  return `- ${s.label} [${st}] recall≈${recall}% — ${bits.join(", ") || "seen only"}; last ${age(s.lastSeenAt, now)}${tail ? `; ${tail}` : ""}`;
}

function countBy(xs: string[]): [string, number][] {
  const m = new Map<string, number>();
  for (const x of xs) m.set(x, (m.get(x) ?? 0) + 1);
  return [...m.entries()];
}

function charCount(lines: string[]) {
  return lines.reduce((n, l) => n + l.length + 1, 0);
}

export function age(d: Date, now: Date): string {
  const ms = now.getTime() - d.getTime();
  const m = Math.round(ms / 60_000);
  if (m < 2) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  if (h < 36) return `${h}h ago`;
  const days = Math.round(h / 24);
  if (days < 60) return `${days}d ago`;
  return `${Math.round(days / 30)}mo ago`;
}
