import { randomUUID } from "crypto";
import type { NextRequest } from "next/server";

export const LEARNER_COOKIE = "learner_id";

/** Identity is a random httpOnly cookie: no accounts, no telemetry. One cookie = one relationship. */
export function getLearnerId(req: NextRequest): { id: string; isNew: boolean } {
  const existing = req.cookies.get(LEARNER_COOKIE)?.value;
  if (existing && /^[a-zA-Z0-9-]{8,64}$/.test(existing)) return { id: existing, isNew: false };
  return { id: randomUUID(), isNew: true };
}

export function learnerCookieHeader(id: string): string {
  const oneYear = 60 * 60 * 24 * 365;
  return `${LEARNER_COOKIE}=${id}; Path=/; Max-Age=${oneYear}; HttpOnly; SameSite=Lax`;
}

export function withLearnerCookie(res: Response, id: string, isNew: boolean): Response {
  if (isNew) res.headers.append("set-cookie", learnerCookieHeader(id));
  return res;
}

export function newSessionId(): string {
  return randomUUID();
}
