import { db } from "@/db";
import { messages, sessions } from "@/db/schema";
import { getProvider } from "@/lib/llm";
import type { Content, LLMProvider, Part } from "@/lib/llm/types";
import { compileBrief } from "@/lib/memory/brief";
import { applyReflection, ensureLearner, loadMemory, type MemoryDelta, type ReflectionOutput } from "@/lib/memory/store";
import { and, asc, desc, eq, lt } from "drizzle-orm";
import { buildSystemPrompt, REFLECTION_SCHEMA, REFLECTION_SYSTEM } from "./prompt";
import { TOOLS, executeTool } from "./tools";
import { sanitizeReflection } from "./reflect";

export { sanitizeReflection };

/**
 * One conversational turn through the compatibility layer.
 *
 * mode:
 *  - "layer"      : compiled brief + memory tools + post-turn reflection (the product)
 *  - "transcript" : baseline — raw prior transcript (all sessions) inlined up to a budget, no reflection
 *  - "none"       : baseline — only the current conversation
 */
export type TurnMode = "layer" | "transcript" | "none";

export type TurnEvent =
  | { type: "text"; delta: string }
  | { type: "tool"; name: string; args: Record<string, unknown>; summary: string }
  | { type: "memory"; delta: MemoryDelta }
  | { type: "done"; messageId: number; trace: TurnTrace }
  | { type: "error"; message: string };

export type TurnTrace = {
  mode: TurnMode;
  provider: string;
  briefTokens: number;
  briefIncluded?: { skills: number; beliefs: number; approaches: number };
  historyTurns: number;
  promptTokens?: number;
  outputTokens?: number;
  tools: { name: string; args: Record<string, unknown>; summary: string }[];
  reflection?: ReflectionOutput;
  memoryDelta?: MemoryDelta;
  durationMs: number;
};

export type TurnResult = { text: string; messageId: number; trace: TurnTrace };

const MAX_TOOL_ROUNDS = 4;

export async function runTurn(opts: {
  learnerId: string;
  sessionId: string;
  userText: string;
  mode?: TurnMode;
  provider?: LLMProvider;
  now?: Date;
  onEvent?: (e: TurnEvent) => void;
  signal?: AbortSignal;
}): Promise<TurnResult> {
  const started = Date.now();
  const now = opts.now ?? new Date();
  const mode = opts.mode ?? "layer";
  const provider = opts.provider ?? getProvider();
  const emit = opts.onEvent ?? (() => {});
  const { learnerId, sessionId } = opts;

  await ensureLearner(learnerId);
  await db
    .insert(sessions)
    .values({ id: sessionId, learnerId, startedAt: now, lastActiveAt: now })
    .onConflictDoUpdate({ target: sessions.id, set: { lastActiveAt: now } });

  // ---- history of this conversation (before saving the new message)
  const historyRows = await db
    .select()
    .from(messages)
    .where(eq(messages.sessionId, sessionId))
    .orderBy(desc(messages.id))
    .limit(provider.profile.recentTurnWindow);
  historyRows.reverse();
  const previousTutorTurn = [...historyRows].reverse().find((m) => m.role === "assistant")?.content ?? "";

  // ---- memory → brief (or baseline context)
  let system: string;
  let briefTokens = 0;
  let briefIncluded: TurnTrace["briefIncluded"];
  const extraContents: Content[] = [];

  if (mode === "layer") {
    const mem = await loadMemory(learnerId);
    const brief = compileBrief(mem, { now, currentMessage: opts.userText, profile: provider.profile });
    briefTokens = brief.approxTokens;
    briefIncluded = brief.included;
    system = buildSystemPrompt(brief.text, provider.profile, now);
  } else if (mode === "transcript") {
    const budgetChars = provider.profile.briefBudgetTokens * 4;
    const prior = await db
      .select({ role: messages.role, content: messages.content, createdAt: messages.createdAt })
      .from(messages)
      .where(and(eq(messages.learnerId, learnerId), lt(messages.id, historyRows[0]?.id ?? 2_147_483_647)))
      .orderBy(desc(messages.id))
      .limit(200);
    const lines: string[] = [];
    let used = 0;
    for (const m of prior) {
      const line = `[${m.createdAt.toISOString().slice(0, 10)}] ${m.role === "user" ? "Learner" : "You"}: ${m.content}`;
      if (used + line.length > budgetChars) break;
      lines.unshift(line);
      used += line.length;
    }
    briefTokens = Math.ceil(used / 4);
    system = buildSystemPrompt(
      lines.length ? `# Earlier conversations (raw transcript, most recent last)\n${lines.join("\n")}` : "# Earlier conversations\n(none)",
      { ...provider.profile, supportsTools: false },
      now,
    );
  } else {
    system = buildSystemPrompt("# Learner brief\n(memory disabled)", { ...provider.profile, supportsTools: false }, now);
  }

  const contents: Content[] = [
    ...extraContents,
    ...historyRows.map<Content>((m) => ({ role: m.role === "user" ? "user" : "model", parts: [{ text: m.content }] })),
    { role: "user", parts: [{ text: opts.userText }] },
  ];

  const [userRow] = await db
    .insert(messages)
    .values({ learnerId, sessionId, role: "user", content: opts.userText, createdAt: now })
    .returning({ id: messages.id });

  // ---- generation with tool loop
  const trace: TurnTrace = {
    mode,
    provider: provider.id,
    briefTokens,
    briefIncluded,
    historyTurns: historyRows.length,
    tools: [],
    durationMs: 0,
  };
  const useTools = mode === "layer" && provider.profile.supportsTools;
  let fullText = "";
  const turnParts: Part[] = [];
  const working: Content[] = [...contents];

  for (let round = 0; round <= MAX_TOOL_ROUNDS; round++) {
    const result = await provider.generate(
      { system, contents: working, tools: useTools ? TOOLS : undefined, thinking: "low", signal: opts.signal },
      (delta) => {
        fullText += delta;
        emit({ type: "text", delta });
      },
    );
    trace.promptTokens = result.usage?.promptTokens ?? trace.promptTokens;
    trace.outputTokens = (trace.outputTokens ?? 0) + (result.usage?.outputTokens ?? 0);
    turnParts.push(...result.content.parts);

    if (!result.functionCalls.length || round === MAX_TOOL_ROUNDS) break;

    working.push(result.content);
    const responses: Part[] = [];
    for (const call of result.functionCalls) {
      const out = await executeTool(call.name, call.args, { learnerId, sessionId, now });
      const summary = typeof out.summary === "string" ? out.summary : JSON.stringify(out).slice(0, 200);
      trace.tools.push({ name: call.name, args: call.args, summary });
      emit({ type: "tool", name: call.name, args: call.args, summary });
      responses.push({ functionResponse: { name: call.name, response: out } });
    }
    working.push({ role: "user", parts: responses });
  }

  if (!fullText.trim()) {
    fullText = "I didn't manage to produce a reply — could you say that again?";
    emit({ type: "text", delta: fullText });
  }

  const [assistantRow] = await db
    .insert(messages)
    .values({ learnerId, sessionId, role: "assistant", content: fullText, parts: turnParts, createdAt: new Date(now.getTime() + 1) })
    .returning({ id: messages.id });

  // ---- reflection (layer mode only)
  if (mode === "layer") {
    try {
      const mem = await loadMemory(learnerId);
      const brief = compileBrief(mem, { now, currentMessage: opts.userText, profile: provider.profile });
      const reflection = await provider.generateJSON<ReflectionOutput>({
        system: REFLECTION_SYSTEM,
        schema: REFLECTION_SCHEMA,
        contents: [
          {
            role: "user",
            parts: [
              {
                text: `CURRENT BRIEF (for consistent skill/belief keys):\n${brief.text}\n\nEXCHANGE:\nPREVIOUS TUTOR TURN: ${previousTutorTurn || "(none)"}\nLEARNER: ${opts.userText}\nTUTOR: ${fullText}`,
              },
            ],
          },
        ],
        thinking: "low",
      });
      const cleaned = sanitizeReflection(reflection);
      const delta = await applyReflection(learnerId, sessionId, assistantRow.id, cleaned, now);
      trace.reflection = cleaned;
      trace.memoryDelta = delta;
      emit({ type: "memory", delta });
    } catch (err) {
      trace.reflection = undefined;
      console.error("reflection failed", err);
    }
  }

  trace.durationMs = Date.now() - started;
  await db.update(messages).set({ trace }).where(eq(messages.id, assistantRow.id));
  emit({ type: "done", messageId: assistantRow.id, trace });
  void userRow;
  return { text: fullText, messageId: assistantRow.id, trace };
}

export async function listConversation(sessionId: string) {
  return db.select().from(messages).where(eq(messages.sessionId, sessionId)).orderBy(asc(messages.id));
}
