import type { ReflectionOutput } from "@/lib/memory/store";

/** Pure validation of the model's structured reflection output. Anything malformed is dropped, never guessed. */
const EVIDENCE_KINDS = new Set(["demonstrated", "failed", "claimed", "explained", "misconception"]);
const FACT_KINDS = new Set(["preference", "background", "goal", "context", "tendency"]);
const OUTCOMES = new Set(["progressed", "stuck", "disengaged", "unclear"]);

export function sanitizeReflection(r: Partial<ReflectionOutput> | null | undefined): ReflectionOutput {
  const evidence = (Array.isArray(r?.evidence) ? r!.evidence : [])
    .filter((e) => e && typeof e === "object" && EVIDENCE_KINDS.has(String(e.kind)))
    .map((e) => ({
      skill: String(e.skill ?? e.label ?? "").slice(0, 64),
      label: String(e.label ?? e.skill ?? "").slice(0, 80),
      topic: String(e.topic ?? "general").slice(0, 40),
      kind: e.kind,
      aided: Boolean(e.aided),
      note: String(e.note ?? "").slice(0, 200),
    }))
    .filter((e) => e.skill || e.label);
  const facts = (Array.isArray(r?.facts) ? r!.facts : [])
    .filter((f) => f && typeof f === "object" && FACT_KINDS.has(String(f.kind)) && String(f.statement ?? "").trim())
    .map((f) => ({
      key: String(f.key ?? f.statement).slice(0, 64),
      statement: String(f.statement).slice(0, 200),
      kind: f.kind,
      stated: Boolean(f.stated),
      scope: String(f.scope ?? "general").slice(0, 40) || "general",
      temporary: Boolean(f.temporary),
    }));
  const corrections = (Array.isArray(r?.corrections) ? r!.corrections : [])
    .filter((c) => c && typeof c === "object" && String(c.key ?? "").trim())
    .map((c) => ({ key: String(c.key).slice(0, 64), note: String(c.note ?? "").slice(0, 200) }));
  const approach =
    r?.approach && typeof r.approach === "object" && String(r.approach.approach ?? "").trim()
      ? { approach: String(r.approach.approach).slice(0, 40), skill: String(r.approach.skill ?? "general").slice(0, 64) }
      : null;
  const previousApproachOutcome = OUTCOMES.has(String(r?.previousApproachOutcome)) ? (r!.previousApproachOutcome as ReflectionOutput["previousApproachOutcome"]) : null;
  const openLoop = typeof r?.openLoop === "string" && r.openLoop.trim() ? r.openLoop.slice(0, 300) : null;
  return { evidence, facts, corrections, approach, previousApproachOutcome, openLoop };
}

