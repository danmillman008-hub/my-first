import { db } from "@/db";
import { beliefs, observations } from "@/db/schema";
import type { ToolDeclaration } from "@/lib/llm/types";
import { age } from "@/lib/memory/brief";
import { isBeliefLive, newBelief, normalizeKey, predictedRecall, retireBelief, skillStatus, type BeliefKind } from "@/lib/memory/model";
import { loadMemory, searchEpisodes } from "@/lib/memory/store";
import { and, desc, eq, ilike, inArray, or } from "drizzle-orm";

export const TOOLS: ToolDeclaration[] = [
  {
    name: "recall_memory",
    description:
      "Search earlier conversations and detailed learner evidence. Use when the brief lacks something you need (what was covered, how they reacted, what they said about a topic).",
    parameters: {
      type: "object",
      properties: { query: { type: "string", description: "Keywords or a short question." } },
      required: ["query"],
    },
  },
  {
    name: "remember",
    description: "Store a durable fact the person explicitly stated or asked you to remember (preference, goal, background). Never store guesses.",
    parameters: {
      type: "object",
      properties: {
        statement: { type: "string", description: "One sentence about the person, third person." },
        kind: { type: "string", enum: ["preference", "background", "goal", "context"] },
        scope: { type: "string", description: "'general' or a topic this applies to." },
      },
      required: ["statement", "kind"],
    },
  },
  {
    name: "forget",
    description: "Retire a stored belief about the person that they say is wrong or no longer true.",
    parameters: {
      type: "object",
      properties: { what: { type: "string", description: "The statement or keywords identifying the belief." } },
      required: ["what"],
    },
  },
  {
    name: "skill_history",
    description: "Dated evidence timeline for one skill (attempts, explanations, approaches and outcomes).",
    parameters: {
      type: "object",
      properties: { skill: { type: "string" } },
      required: ["skill"],
    },
  },
];

export type ToolContext = { learnerId: string; sessionId: string; now: Date };

export async function executeTool(name: string, args: Record<string, unknown>, ctx: ToolContext): Promise<Record<string, unknown>> {
  switch (name) {
    case "recall_memory":
      return recallMemory(String(args.query ?? ""), ctx);
    case "remember":
      return remember(String(args.statement ?? ""), String(args.kind ?? "preference") as BeliefKind, args.scope ? String(args.scope) : "general", ctx);
    case "forget":
      return forget(String(args.what ?? ""), ctx);
    case "skill_history":
      return skillHistory(String(args.skill ?? ""), ctx);
    default:
      return { error: `unknown tool ${name}` };
  }
}

async function recallMemory(query: string, ctx: ToolContext) {
  const mem = await loadMemory(ctx.learnerId);
  const q = query.toLowerCase();
  const terms = q.split(/\W+/).filter((t) => t.length > 2);
  const hit = (s: string) => terms.some((t) => s.toLowerCase().includes(t));

  const skills = mem.skills
    .filter((s) => hit(s.label) || hit(s.skill) || hit(s.topic))
    .slice(0, 8)
    .map((s) => ({
      skill: s.label,
      status: skillStatus(s, ctx.now),
      predictedRecall: Math.round(predictedRecall(s, ctx.now) * 100) / 100,
      unaided: s.unaidedSuccesses,
      aided: s.aidedSuccesses,
      failures: s.failures,
      explained: s.explanations,
      claimed: s.claimedLevel,
      misconception: s.misconceptionActive ? s.misconception : null,
      lastSeen: age(s.lastSeenAt, ctx.now),
    }));
  const notes = mem.beliefs
    .filter((b) => isBeliefLive(b, ctx.now) && hit(b.statement))
    .slice(0, 8)
    .map((b) => ({ statement: b.statement, source: b.source, confidence: b.confidence, lastSeen: age(b.lastSeenAt, ctx.now) }));
  const episodes = (await searchEpisodes(ctx.learnerId, query, 6)).map((e) => ({
    when: age(e.createdAt, ctx.now),
    who: e.role === "user" ? "learner" : "you",
    said: e.content.length > 400 ? e.content.slice(0, 400) + "…" : e.content,
  }));
  const approaches = mem.approaches.filter((a) => hit(a.skill.replace(/_/g, " ")) || hit(a.approach)).slice(0, 10);
  const summary = `${skills.length} skill(s), ${notes.length} note(s), ${episodes.length} earlier message(s) matched "${query}".`;
  return { summary, skills, notes, approaches, episodes };
}

async function remember(statement: string, kind: BeliefKind, scope: string, ctx: ToolContext) {
  if (!statement.trim()) return { error: "empty statement" };
  const key = normalizeKey(`${kind}_${statement}`).slice(0, 64);
  const b = newBelief({ key, statement, kind, stated: true, scope, temporary: kind === "context" }, ctx.sessionId, ctx.now);
  b.confidence = 0.9;
  await db.insert(beliefs).values({ ...b, learnerId: ctx.learnerId });
  await db.insert(observations).values({ learnerId: ctx.learnerId, sessionId: ctx.sessionId, kind: "fact", payload: { key, statement, kind, stated: true, via: "tool" } });
  return { summary: `Stored: "${statement}"`, key };
}

async function forget(what: string, ctx: ToolContext) {
  const terms = what
    .toLowerCase()
    .split(/\W+/)
    .filter((t) => t.length > 3)
    .slice(0, 5);
  if (!terms.length) return { summary: "Nothing matched.", retired: [] };
  const rows = await db
    .select()
    .from(beliefs)
    .where(and(eq(beliefs.learnerId, ctx.learnerId), inArray(beliefs.status, ["active", "candidate", "contested"]), or(...terms.map((t) => ilike(beliefs.statement, `%${t}%`)))));
  const retired: string[] = [];
  for (const row of rows) {
    const r = retireBelief(
      {
        key: row.key,
        statement: row.statement,
        kind: row.kind as BeliefKind,
        source: row.source as "stated" | "inferred",
        status: row.status as "active",
        confidence: row.confidence,
        supportCount: row.supportCount,
        contradictionCount: row.contradictionCount,
        sessionIds: row.sessionIds ?? [],
        scope: row.scope,
        firstSeenAt: row.firstSeenAt,
        lastSeenAt: row.lastSeenAt,
        expiresAt: row.expiresAt,
        retiredAt: row.retiredAt,
        retiredReason: row.retiredReason,
        guardUntil: row.guardUntil,
      },
      `learner asked to forget: ${what}`,
      ctx.now,
    );
    await db.update(beliefs).set({ ...r }).where(eq(beliefs.id, row.id));
    retired.push(row.statement);
  }
  await db.insert(observations).values({ learnerId: ctx.learnerId, sessionId: ctx.sessionId, kind: "correction", payload: { what, retired, via: "tool" } });
  return { summary: retired.length ? `Retired: ${retired.join("; ")}` : "Nothing matched.", retired };
}

async function skillHistory(skill: string, ctx: ToolContext) {
  const key = normalizeKey(skill);
  const rows = await db
    .select()
    .from(observations)
    .where(and(eq(observations.learnerId, ctx.learnerId), eq(observations.kind, "evidence")))
    .orderBy(desc(observations.id))
    .limit(300);
  const timeline = rows
    .filter((r) => {
      const p = r.payload as { skill?: string; label?: string };
      return p.skill === key || (p.label ?? "").toLowerCase().includes(skill.toLowerCase());
    })
    .slice(0, 25)
    .map((r) => {
      const p = r.payload as { kind: string; aided?: boolean; note?: string };
      return { when: age(r.createdAt, ctx.now), kind: p.kind, aided: p.aided ?? false, note: p.note ?? "" };
    });
  return { summary: `${timeline.length} evidence event(s) for "${skill}".`, timeline };
}
