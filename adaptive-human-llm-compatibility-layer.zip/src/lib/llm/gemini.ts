import {
  LLMError,
  type Content,
  type GenerateRequest,
  type GenerateResult,
  type JSONRequest,
  type LLMProvider,
  type ModelProfile,
  type Part,
} from "./types";

const BASE = "https://generativelanguage.googleapis.com/v1beta";

const THINKING: Record<NonNullable<GenerateRequest["thinking"]>, string> = {
  minimal: "minimal",
  low: "low",
  medium: "medium",
  high: "high",
};

/**
 * Gemini via the REST `generateContent` / `streamGenerateContent` endpoints.
 * Uses fetch only — no SDK — so the surface we depend on is explicit and small.
 */
export class GeminiProvider implements LLMProvider {
  readonly id: string;
  readonly profile: ModelProfile;

  constructor(
    private readonly apiKey: string,
    model = process.env.GEMINI_MODEL ?? "gemini-3.6-flash",
  ) {
    this.id = model;
    this.profile = {
      name: model,
      contextWindowTokens: 1_048_576,
      supportsTools: true,
      supportsStructuredOutput: true,
      supportsThinking: /gemini-(2\.5|3)/.test(model),
      briefBudgetTokens: 2_500,
      recentTurnWindow: 30,
    };
  }

  private headers() {
    return { "content-type": "application/json", "x-goog-api-key": this.apiKey };
  }

  private body(req: GenerateRequest) {
    const generationConfig: Record<string, unknown> = {
      temperature: req.temperature ?? 0.7,
      maxOutputTokens: req.maxOutputTokens ?? 4096,
    };
    if (req.thinking && this.profile.supportsThinking) {
      generationConfig.thinkingConfig = { thinkingLevel: THINKING[req.thinking] };
    }
    return {
      systemInstruction: { parts: [{ text: req.system }] },
      contents: req.contents,
      tools: req.tools?.length ? [{ functionDeclarations: req.tools }] : undefined,
      generationConfig,
    };
  }

  async generate(req: GenerateRequest, onText?: (delta: string) => void): Promise<GenerateResult> {
    const url = `${BASE}/models/${this.id}:streamGenerateContent?alt=sse`;
    const res = await fetch(url, {
      method: "POST",
      headers: this.headers(),
      body: JSON.stringify(this.body(req)),
      signal: req.signal,
    });
    if (!res.ok || !res.body) {
      throw new LLMError(`Gemini ${res.status}`, res.status, await res.text().catch(() => ""));
    }

    const parts: Part[] = [];
    let text = "";
    let usage: GenerateResult["usage"];
    let finishReason: string | undefined;

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    const handleEvent = (data: string) => {
      let chunk: GeminiResponse;
      try {
        chunk = JSON.parse(data);
      } catch {
        return;
      }
      const cand = chunk.candidates?.[0];
      if (chunk.usageMetadata) {
        usage = {
          promptTokens: chunk.usageMetadata.promptTokenCount,
          outputTokens: chunk.usageMetadata.candidatesTokenCount,
          thoughtTokens: chunk.usageMetadata.thoughtsTokenCount,
        };
      }
      if (!cand) return;
      if (cand.finishReason) finishReason = cand.finishReason;
      for (const p of cand.content?.parts ?? []) {
        if ("text" in p && typeof p.text === "string") {
          if (p.thought) continue;
          // Merge consecutive text parts so history stays compact.
          const last = parts[parts.length - 1];
          if (last && "text" in last && !("functionCall" in last) && !p.thoughtSignature) {
            last.text += p.text;
          } else {
            parts.push({ text: p.text, ...(p.thoughtSignature ? { thoughtSignature: p.thoughtSignature } : {}) });
          }
          text += p.text;
          onText?.(p.text);
        } else if ("functionCall" in p && p.functionCall) {
          parts.push({
            functionCall: { name: p.functionCall.name, args: p.functionCall.args ?? {} },
            ...(p.thoughtSignature ? { thoughtSignature: p.thoughtSignature } : {}),
          });
        }
      }
    };

    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let idx: number;
      while ((idx = buffer.indexOf("\n\n")) >= 0) {
        const raw = buffer.slice(0, idx);
        buffer = buffer.slice(idx + 2);
        for (const line of raw.split("\n")) {
          if (line.startsWith("data:")) handleEvent(line.slice(5).trim());
        }
      }
    }
    if (buffer.trim().startsWith("data:")) handleEvent(buffer.trim().slice(5).trim());

    const functionCalls = parts
      .filter((p): p is Extract<Part, { functionCall: unknown }> => "functionCall" in p)
      .map((p) => p.functionCall);

    return {
      content: { role: "model", parts: parts.length ? parts : [{ text: "" }] },
      text,
      functionCalls,
      usage,
      finishReason,
    };
  }

  async generateJSON<T>(req: JSONRequest): Promise<T> {
    const url = `${BASE}/models/${this.id}:generateContent`;
    const generationConfig: Record<string, unknown> = {
      temperature: req.temperature ?? 0.2,
      responseMimeType: "application/json",
      responseSchema: req.schema,
      maxOutputTokens: 4096,
    };
    if (this.profile.supportsThinking) {
      generationConfig.thinkingConfig = { thinkingLevel: THINKING[req.thinking ?? "low"] };
    }
    const res = await fetch(url, {
      method: "POST",
      headers: this.headers(),
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: req.system }] },
        contents: req.contents,
        generationConfig,
      }),
    });
    if (!res.ok) throw new LLMError(`Gemini ${res.status}`, res.status, await res.text().catch(() => ""));
    const json = (await res.json()) as GeminiResponse;
    const text = (json.candidates?.[0]?.content?.parts ?? [])
      .filter((p): p is { text: string } => "text" in p && typeof p.text === "string" && !p.thought)
      .map((p) => p.text)
      .join("");
    try {
      return JSON.parse(text) as T;
    } catch {
      throw new LLMError("Gemini returned non-JSON structured output", 502, text.slice(0, 500));
    }
  }
}

type GeminiResponse = {
  candidates?: {
    content?: Content & { parts: (Part & { thought?: boolean })[] };
    finishReason?: string;
  }[];
  usageMetadata?: { promptTokenCount?: number; candidatesTokenCount?: number; thoughtsTokenCount?: number };
};
