import type { Content, GenerateRequest, GenerateResult, JSONRequest, LLMProvider, ModelProfile } from "./types";

/**
 * Deterministic offline model.
 *
 * It is NOT a language model. It is a scripted tutor policy that reads the compiled brief through the
 * same system prompt a real model would receive, so the memory layer, tool loop, reflection and lab
 * can be exercised without network access. Its "reflection" is a heuristic extractor over the same
 * transcript a real model would see. Results obtained with it measure the *layer*, not teaching quality.
 */
export class MockProvider implements LLMProvider {
  readonly id = "mock-scripted";
  readonly profile: ModelProfile = {
    name: "mock-scripted",
    contextWindowTokens: 32_000,
    supportsTools: true,
    supportsStructuredOutput: true,
    supportsThinking: false,
    briefBudgetTokens: 1_500,
    recentTurnWindow: 12,
  };

  async generate(req: GenerateRequest, onText?: (delta: string) => void): Promise<GenerateResult> {
    const lastUser = [...req.contents].reverse().find((c) => c.role === "user");
    const userText = partsText(lastUser);
    const brief = req.system;
    const prevToolResult = lastUser?.parts.find((p) => "functionResponse" in p);

    let text: string;
    if (prevToolResult) {
      text = "Thanks — I checked my notes. " + summarizeToolResult(prevToolResult);
    } else {
      text = scriptedTutor(userText, brief);
    }
    onText?.(text);
    return {
      content: { role: "model", parts: [{ text }] },
      text,
      functionCalls: [],
      usage: { promptTokens: Math.ceil((req.system.length + JSON.stringify(req.contents).length) / 4), outputTokens: Math.ceil(text.length / 4) },
      finishReason: "STOP",
    };
  }

  async generateJSON<T>(req: JSONRequest): Promise<T> {
    if (req.system.includes("TASK: REFLECTION")) {
      return heuristicReflection(req.contents) as unknown as T;
    }
    if (req.system.includes("TASK: TITLE")) {
      const t = partsText(req.contents[0]).slice(0, 40);
      return { title: t || "Conversation" } as unknown as T;
    }
    if (req.system.includes("TASK: JUDGE")) {
      return judgeHeuristic(req.contents) as unknown as T;
    }
    return {} as T;
  }
}

function partsText(c?: Content): string {
  return (c?.parts ?? []).map((p) => ("text" in p ? p.text : "")).join("\n");
}

function summarizeToolResult(p: Content["parts"][number]): string {
  if (!("functionResponse" in p)) return "";
  const r = p.functionResponse.response;
  return typeof r.summary === "string" ? r.summary : JSON.stringify(r).slice(0, 200);
}

// ---------- scripted tutor policy (reads the brief) ----------

const SKILL_RE = /(?:explain|teach me|what is|help me with|tell me about|go over|review)\s+(.+?)(?:\?|\.|$)/i;

export function scriptedTutor(userText: string, brief: string): string {
  const askMatch = userText.match(SKILL_RE);
  const preferred = readPreferredApproach(brief);

  if (/^my answer:/i.test(userText.trim())) {
    const ans = userText.replace(/^my answer:/i, "").trim();
    // The scripted check always expects the token "<skill>-key".
    if (/-key\b/i.test(ans)) return "Correct! That's exactly the key idea. Nice retrieval.";
    return "Not quite. The key idea is the <skill>-key relationship — let's revisit it briefly. [approach:worked_example]";
  }

  if (askMatch) {
    const label = askMatch[1].trim().replace(/\bagain\b/i, "").trim();
    const status = readSkillStatus(brief, label);
    if (readPreferredApproach(brief) === null && /first principles/i.test(brief)) {
      // corrected preference: first-principles explanation
    }
    if (status && status.demonstrated && status.recall >= 0.5) {
      return `You demonstrated ${label} recently (my notes show ~${Math.round(status.recall * 100)}% predicted recall), so rather than re-explain, a quick check: what is the key idea of ${label}? Reply "My answer: ${slug(label)}-key" if you remember. [approach:retrieval_check]`;
    }
    const approach = preferred ?? (status && status.stuckWith.includes("formal") ? "worked_example" : "formal");
    if (status && status.demonstrated) {
      // fading: refresh briefly, then retrieve
      return `It's been a while since you last used ${label}, so here's a quick refresher (${approach.replace(/_/g, " ")}): the key idea is ${slug(label)}-key. Now you: what is the key idea of ${label}? Reply "My answer: ${slug(label)}-key". [approach:${approach}]`;
    }
    const opener =
      approach === "worked_example"
        ? `Let's work through ${label} with a concrete example first.`
        : approach === "analogy"
          ? `Here's an analogy for ${label}.`
          : approach === "execution_trace"
            ? `Let's trace ${label} step by step.`
            : `Here's the formal idea behind ${label}.`;
    return `${opener} The key idea is ${slug(label)}-key. Quick check: what is the key idea of ${label}? Reply "My answer: ${slug(label)}-key". [approach:${approach}]`;
  }

  const claim = userText.match(/i (?:already )?know (.+?)(?: well| pretty well)?(?:\.|,|$)/i) ?? userText.match(/i'm (?:pretty )?comfortable with (.+?)(?:\.|$)/i);
  if (claim) {
    const label = claim[1].trim();
    return `Great — I'll take that as a starting point. Quick check so I don't re-teach it: what is the key idea of ${label}? Reply "My answer: ${slug(label)}-key". [approach:retrieval_check]`;
  }
  if (/i prefer|i learn best|works better for me/i.test(userText)) {
    return "Noted — I'll adapt to that.";
  }
  if (/that's not true|actually,? i don'?t|you're wrong about me|stop assuming/i.test(userText)) {
    return "Understood — I've dropped that assumption.";
  }
  return "Tell me what you'd like to work on, or ask me anything.";
}

export function slug(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 48);
}

function readPreferredApproach(brief: string): string | null {
  // Ignore lines that negate a preference (corrections) and retracting statements in raw transcripts.
  const positive = brief
    .split("\n")
    .filter((l) => !/Do NOT assume/i.test(l) && !/don'?t prefer|no longer prefer|was wrong about/i.test(l))
    .join("\n");
  const m = positive.match(/prefers?\s+(worked examples?|concrete examples?|analog(?:y|ies)|execution traces?|formal definitions?|(?:explanations? from )?first principles)/i);
  if (!m) return null;
  const v = m[1].toLowerCase();
  if (v.includes("first principles")) return "formal";
  if (v.startsWith("worked") || v.startsWith("concrete")) return "worked_example";
  if (v.startsWith("analog")) return "analogy";
  if (v.startsWith("execution")) return "execution_trace";
  return "formal";
}

function readSkillStatus(brief: string, label: string): { recall: number; demonstrated: boolean; stuckWith: string[] } | null {
  const line = brief.split("\n").find((l) => l.toLowerCase().includes(label.toLowerCase()) && /recall≈/.test(l));
  if (!line) return null;
  const rm = line.match(/recall≈(\d+)%/);
  const recall = rm ? Number(rm[1]) / 100 : 0;
  const demonstrated = /unaided ✓/.test(line);
  const stuckWith = [...line.matchAll(/stuck after ([a-z_]+)/g)].map((m) => m[1]);
  return { recall, demonstrated, stuckWith };
}

// ---------- heuristic reflection (offline substitute for the model's structured extraction) ----------

export type ReflectionShape = {
  evidence: { skill: string; label: string; topic: string; kind: string; aided: boolean; note: string }[];
  facts: { key: string; statement: string; kind: string; stated: boolean; scope: string; temporary: boolean }[];
  corrections: { key: string; note: string }[];
  approach: { approach: string; skill: string } | null;
  previousApproachOutcome: string | null;
  openLoop: string | null;
};

function heuristicReflection(contents: Content[]): ReflectionShape {
  const text = partsText(contents[contents.length - 1]);
  const user = (text.match(/LEARNER:\s*([\s\S]*?)\n(?:TUTOR:|$)/) ?? [])[1]?.trim() ?? "";
  const tutor = (text.match(/TUTOR:\s*([\s\S]*)$/) ?? [])[1]?.trim() ?? "";
  const prevTutor = (text.match(/PREVIOUS TUTOR TURN:\s*([\s\S]*?)\nLEARNER:/) ?? [])[1]?.trim() ?? "";
  const out: ReflectionShape = { evidence: [], facts: [], corrections: [], approach: null, previousApproachOutcome: null, openLoop: null };

  const skillFromCheck = (t: string) => (t.match(/key idea of (.+?)\?/i) ?? [])[1]?.trim();

  const claim = user.match(/i (?:already )?know (.+?)(?: well| pretty well)?(?:\.|,|$)/i) ?? user.match(/i'm (?:pretty )?comfortable with (.+?)(?:\.|$)/i);
  if (claim) out.evidence.push({ skill: slug(claim[1]), label: claim[1].trim(), topic: "general", kind: "claimed", aided: false, note: "self-report" });

  if (/^my answer:/i.test(user)) {
    const label = skillFromCheck(prevTutor) ?? "unknown_skill";
    const correct = /^correct/i.test(tutor);
    out.evidence.push({ skill: slug(label), label, topic: "general", kind: correct ? "demonstrated" : "failed", aided: false, note: "retrieval check" });
    out.previousApproachOutcome = correct ? "progressed" : "stuck";
  }

  const ask = user.match(SKILL_RE);
  const tag = tutor.match(/\[approach:([a-z_]+)\]/);
  if (ask && tag) {
    const label = ask[1].trim().replace(/\bagain\b/i, "").trim();
    if (tag[1] !== "retrieval_check") {
      out.evidence.push({ skill: slug(label), label, topic: "general", kind: "explained", aided: false, note: `explained via ${tag[1]}` });
    }
    out.approach = { approach: tag[1], skill: slug(label) };
    out.openLoop = `Asked the learner to answer a check on ${label}.`;
  }
  if (/i don'?t (?:really )?(?:understand|get) (.+?)(?:\.|$)/i.test(user)) {
    const label = user.match(/i don'?t (?:really )?(?:understand|get) (.+?)(?:\.|$)/i)![1].trim();
    out.evidence.push({ skill: slug(label), label, topic: "general", kind: "failed", aided: false, note: "expressed confusion" });
    if (prevTutor) out.previousApproachOutcome = "stuck";
  }

  const pref = user.match(/i (?:prefer|learn best (?:with|from)) (.+?)(?:\.|,| when|$)/i) ?? user.match(/(?:^|\. )((?:explanations? from )?[a-z' ]+?) works? better for me/i);
  if (pref && !/don'?t\s+prefer/i.test(user.slice(Math.max(0, (pref.index ?? 0) - 12), (pref.index ?? 0) + pref[0].length))) {
    out.facts.push({ key: `prefers_${slug(pref[1])}`, statement: `Prefers ${pref[1].trim()}`, kind: "preference", stated: true, scope: "general", temporary: false });
  }
  const bg = user.match(/i(?:'m| am) an? (.+?)(?:\.|,|$)/i);
  if (bg) out.facts.push({ key: `background_${slug(bg[1])}`, statement: `Is a ${bg[1].trim()}`, kind: "background", stated: true, scope: "general", temporary: false });
  if (/i'?m (?:really )?tired|it'?s late/i.test(user)) {
    out.facts.push({ key: "context_tired", statement: "Is tired right now", kind: "context", stated: true, scope: "general", temporary: true });
  }
  const corr = user.match(/(?:that's not true|actually,? i don'?t prefer|i no longer prefer|stop assuming i prefer|i never said i prefer) (.+?)(?:\.|—|,|;|$)/i);
  if (corr) out.corrections.push({ key: `prefers_${slug(corr[1])}`, note: "learner correction" });

  return out;
}

function judgeHeuristic(contents: Content[]): Record<string, unknown> {
  const text = partsText(contents[contents.length - 1]);
  return {
    redundantExplanation: /re-?explain/i.test(text) ? false : /Here's the formal idea|Let's work through/.test(text) && /ALREADY_DEMONSTRATED: yes/.test(text),
    respectsStatedPreference: !/PREFERENCE:/.test(text) || /Let's work through|analogy|trace/.test(text),
    notes: "heuristic judge",
  };
}
