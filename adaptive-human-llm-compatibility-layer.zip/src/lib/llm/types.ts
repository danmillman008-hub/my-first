/**
 * Provider-independent LLM contract.
 *
 * Deliberately thin: the app needs (1) multi-turn generation with tools + streaming text and
 * (2) schema-constrained JSON. Everything else stays provider-specific.
 *
 * `parts` are passed through opaquely so provider-specific fields (e.g. Gemini `thoughtSignature`)
 * survive a round trip without the app knowing about them.
 */

export type TextPart = { text: string; thought?: boolean; thoughtSignature?: string };
export type FunctionCallPart = {
  functionCall: { name: string; args: Record<string, unknown> };
  thoughtSignature?: string;
};
export type FunctionResponsePart = {
  functionResponse: { name: string; response: Record<string, unknown> };
};
export type Part = TextPart | FunctionCallPart | FunctionResponsePart;

export type Content = { role: "user" | "model"; parts: Part[] };

export type JSONSchema = Record<string, unknown>;

export type ToolDeclaration = {
  name: string;
  description: string;
  parameters: JSONSchema;
};

export type GenerateRequest = {
  system: string;
  contents: Content[];
  tools?: ToolDeclaration[];
  temperature?: number;
  /** Provider-specific reasoning budget hint. */
  thinking?: "minimal" | "low" | "medium" | "high";
  maxOutputTokens?: number;
  signal?: AbortSignal;
};

export type GenerateResult = {
  /** The model turn, with parts in provider-native shape (to be appended to history verbatim). */
  content: Content;
  text: string;
  functionCalls: { name: string; args: Record<string, unknown> }[];
  usage?: { promptTokens?: number; outputTokens?: number; thoughtTokens?: number };
  finishReason?: string;
};

export type JSONRequest = {
  system: string;
  contents: Content[];
  schema: JSONSchema;
  temperature?: number;
  thinking?: "minimal" | "low" | "medium" | "high";
};

/**
 * Capability profile of the *current* model. The compatibility layer reads this to decide how to
 * present memory (inline vs. tool-retrievable), how much to inline, and what to delegate.
 */
export type ModelProfile = {
  name: string;
  contextWindowTokens: number;
  supportsTools: boolean;
  supportsStructuredOutput: boolean;
  supportsThinking: boolean;
  /** Soft budget (tokens) the layer should spend on the compiled brief. */
  briefBudgetTokens: number;
  /** How many recent raw turns to keep verbatim before summarising. */
  recentTurnWindow: number;
};

export interface LLMProvider {
  readonly id: string;
  readonly profile: ModelProfile;
  generate(req: GenerateRequest, onText?: (delta: string) => void): Promise<GenerateResult>;
  generateJSON<T>(req: JSONRequest): Promise<T>;
}

export class LLMError extends Error {
  constructor(
    message: string,
    public readonly status?: number,
    public readonly body?: string,
  ) {
    super(message);
  }
}
