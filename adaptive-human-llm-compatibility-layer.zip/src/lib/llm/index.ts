import { GeminiProvider } from "./gemini";
import { MockProvider } from "./mock";
import type { LLMProvider } from "./types";

export * from "./types";

let cached: LLMProvider | null = null;

/**
 * Provider selection. `GEMINI_API_KEY` (or `GOOGLE_API_KEY`) → Gemini; otherwise the offline mock.
 * `LLM_PROVIDER=mock` forces the mock even when a key exists (used by tests / the lab).
 */
export function getProvider(): LLMProvider {
  if (cached) return cached;
  const key = process.env.GEMINI_API_KEY ?? process.env.GOOGLE_API_KEY;
  if (process.env.LLM_PROVIDER !== "mock" && key) {
    cached = new GeminiProvider(key);
  } else {
    cached = new MockProvider();
  }
  return cached;
}

export function providerStatus() {
  const p = getProvider();
  return {
    provider: p.id,
    live: !(p instanceof MockProvider),
    profile: p.profile,
  };
}

export { GeminiProvider, MockProvider };
