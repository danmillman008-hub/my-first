# Architecture

## One paragraph

The person chats with Gemini. Before every reply, a **context compiler** turns everything the layer has learned about this person into a short, provenance-labelled, budgeted *learner brief* that is placed in the system prompt as advice, not rules. The model answers freely and may call four small **memory tools** when it needs more. After the reply, a cheap **reflection** call extracts evidence from the exchange (what was demonstrated vs. claimed vs. explained, what the person said about themselves, which approach was used, how the previous approach landed), and **deterministic, tested rules** fold that evidence into a memory substrate in Postgres. The person can inspect, correct and erase all of it.

```
 person ──► Chat UI ──► POST /api/chat (NDJSON stream)
                            │
                            ▼
                     runTurn()  src/lib/agent/turn.ts
                            │
        ┌───────────────────┼─────────────────────────┐
        │                   │                         │
   loadMemory()      compileBrief()             buildSystemPrompt()
   (Postgres)        src/lib/memory/brief.ts    src/lib/agent/prompt.ts
        │                   │                         │
        └──────────► Gemini 3.6 Flash ◄───────────────┘
                     generateContent (stream)  + tools: recall_memory · remember · forget · skill_history
                            │
                            ▼  reply streamed to the person
                     reflection (structured JSON)  ──► sanitizeReflection() ──► applyReflection()
                                                                                  │
                     messages · observations · beliefs · skill_states · approach_ledger (Postgres)
```

## The boundary (capability map)

| Capability | Owner | Why |
| --- | --- | --- |
| Explain, choose approach, ask questions, set exercises, grade answers, detect confusion, adjust pace and register, follow topic changes | **Model** | Solved within a context window; app rules only constrain a stronger reasoner |
| Read the person's message, decide whether history is relevant right now | **Model** (brief is advisory) | "Current context wins over history" |
| Extract evidence from an exchange into structured form | **Model** (reflection call with schema) | Structured output beats regex perception (archive bug class eliminated) |
| Decide whether an extraction *becomes* memory, with what status, confidence, expiry, guard | **Layer** (pure functions, unit-tested) | Consolidation semantics must be deterministic and auditable |
| Distinguish claimed / demonstrated / aided / explained, count them, date them | **Layer** | Models conflate these across time |
| Time: decay of recall, age of beliefs, session gaps | **Layer** | Models have no clock |
| Attribution of "did that approach work?" to the *next* response | **Layer** | Same-turn reactions are performance, not learning |
| Correction handling with re-inference guard | **Layer** | Otherwise the model re-derives the retracted belief from old evidence |
| Budgeting what the model sees, adapting to the model's own capabilities | **Layer** (`ModelProfile`) | Two-sided adaptation |
| Inspect / correct / erase | **Person** (UI + API) | Autonomy and verifiability |
| Persistence, provenance, identity | **Layer** | Not a model capability |

Nothing in the app chooses a teaching action. There is no policy module.

## Files

| Path | Role |
| --- | --- |
| `src/lib/llm/types.ts` | Provider contract: `generate` (multi-turn, tools, streaming), `generateJSON` (schema), `ModelProfile` |
| `src/lib/llm/gemini.ts` | Gemini via REST `streamGenerateContent` / `generateContent`, function declarations, thinking level, thought-signature passthrough |
| `src/lib/llm/mock.ts` | Deterministic offline substitute (scripted policy that reads the brief + heuristic extractor) for tests/lab |
| `src/lib/memory/model.ts` | **Pure semantics**: skill evidence rules, half-life recall, belief lifecycle, approach stats |
| `src/lib/memory/store.ts` | Drizzle persistence; `applyReflection` applies the pure rules; search; erase |
| `src/lib/memory/brief.ts` | Context compiler (relevance ranking, budget, provenance labels) |
| `src/lib/agent/prompt.ts` | System prompt (compatibility contract) + reflection prompt & schema |
| `src/lib/agent/tools.ts` | Tool declarations and handlers |
| `src/lib/agent/reflect.ts` | Validation of reflection output (never guesses) |
| `src/lib/agent/turn.ts` | Orchestration; `mode: layer | transcript | none` for baselines |
| `src/app/api/*` | `chat` (stream), `sessions`, `memory` (inspect/erase), `memory/beliefs/:id` (correct), `status`, `health` |
| `src/components/*` | Chat UI, memory panel ("What it knows about you"), per-turn "why this turn" trace |
| `scripts/lab/run.ts` | Evaluation lab |
| `tests/*.test.ts` | Unit (pure) and behavioural (engine + DB) tests |

## Learner model specification

Stored per (learner, skill) in `skill_states`. A *skill* is whatever the reflection names (small and specific, e.g. "base case in recursion"); slugs are normalised and reused from the brief for consistency.

| Field | Meaning | Updated by |
| --- | --- | --- |
| `pKnown` ∈ [0, 0.98] | Probability the person can produce it unaided *now* if asked (before decay) | demonstrated ↑ (weighted by 1−recall, ×0.5 if aided), failed ↓ (×0.6), claimed → prior 0.35 only if nothing demonstrated, explained → ≤0.3 |
| `stabilityDays` | Half-life of recall | unaided success: ×(1.8+1.5·(1−p)) if spaced (≥1 day since last success), capped growth if massed; failure ×0.7; verified claim ⇒ ≥14 |
| `unaidedSuccesses / aidedSuccesses / failures / explanations` | Evidence counts by kind | reflection |
| `claimedLevel` | What they said, verbatim-ish; shown as *(unverified)* until an unaided success exists | claimed |
| `misconception`, `misconceptionActive` | Specific recurring wrong model | misconception; clears after 2 unaided successes |
| timestamps | last success / unaided success / failure / explanation, first/last seen | all |

Derived: `predictedRecall = pKnown · 2^(−Δt/stability)`; `status ∈ unseen · claimed · exposed · learning · demonstrated · fading · misconception` (fading requires *actual* decay below the 0.85 retention target).

Beliefs (`beliefs`): `key`, `statement`, `kind ∈ preference | background | goal | context | tendency`, `source ∈ stated | inferred`, `status ∈ candidate | active | contested | retired`, `confidence ≤ 0.92`, support/contradiction counts, `sessionIds`, `scope`, `expiresAt` (context: 6 h), `guardUntil` (14 days after a correction), `retiredReason`.

Approach ledger: `(approach, skill) → outcome ∈ pending | progressed | stuck | disengaged | unclear`; a pending entry is resolved by the reflection of the *next* learner turn. Aggregates are shown as statistics ("worked_example: progressed 3/4"), never converted into preferences.

## Memory semantics (rules that are deterministic and tested)

1. Stated facts become active beliefs at 0.8 confidence; inferred facts are candidates until supported in ≥2 sessions (or ≥3 times).
2. Confidence is capped at 0.92; read-time weight decays with a 60-day half-life for durable beliefs.
3. A correction retires immediately, keeps the row (audit), blocks inferred re-derivation for 14 days; only a fresh *stated* fact revives it. The brief lists recent retirements as "Do NOT assume".
4. Context beliefs expire after 6 hours and never become traits.
5. Claims never move a skill past `claimed`; explanations never past `exposed`.
6. Aided success counts half and does not grow stability; only unaided success can make a skill `demonstrated`.
7. Reflection output is validated field-by-field; anything malformed is dropped, never guessed.
8. Every write is traceable to a message (`observations.message_id`), and the per-turn trace is stored on the assistant message.

## Two-sided adaptation in code

`ModelProfile` (`contextWindowTokens`, `supportsTools`, `supportsStructuredOutput`, `supportsThinking`, `briefBudgetTokens`, `recentTurnWindow`) is read by `compileBrief` and `buildSystemPrompt`. A tool-less model gets no tool section and everything inlined up to budget; a bigger budget inlines more skills before pointing to `recall_memory`. Provider swap = one class implementing `LLMProvider`; the memory substrate and the UI are untouched.

## Evolvability

- Provider-independent: `src/lib/memory/*`, `src/lib/agent/{prompt,reflect,tools}.ts`, schema, UI.
- Provider-specific: `src/lib/llm/gemini.ts` only.
- Re-addable behind the same store without touching the model: pgvector retrieval, MCP exposure of `/api/memory`, multimodal evidence, provider-native memory as an *additional* source.
