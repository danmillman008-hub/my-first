# Evaluation

Three layers, kept distinct:

1. **Unit tests** — `npm test` (15): pure memory semantics, brief compiler, reflection validation.
2. **Behavioural tests** — `npm run test:behaviour` (6): the real engine + Postgres + offline model: claim→demonstration, correction + guard, next-turn attribution, context expiry, memory tools, baselines through the same path.
3. **Synthetic-learner lab** — `npm run lab` (offline) / `npm run lab:live` (Gemini): does the layer improve a *long-term* interaction versus baselines?

## Design of the lab (`scripts/lab/run.ts`)

Same `runTurn` code path, three conditions:

| condition | what the model receives about the past |
| --- | --- |
| `none` | nothing beyond the current conversation |
| `transcript` | raw prior transcripts from all sessions, most-recent-first, cut at the same token budget the layer gets ×4 (a generous "just paste the history" baseline) |
| `layer` | compiled brief + memory tools + reflection (the product) |

Synthetic learners have **hidden** state the tutor never sees: per-skill knowledge `k`, a forgetting half-life, whether they truly retained something, and a stated preference that one archetype later retracts. Four archetypes (novice, corrector, returning, knowledgeable — the last already knows two of four skills), four sessions at days 0/2/9/30, identical scripts across conditions. Only what the tutor *knows* differs.

Hidden dynamics (declared, not tuned to the layer): explanation `k += 0.3(1−k)`; correct unaided retrieval `k += 0.25(1−k)`, half-life ×2.5 if spaced; failed retrieval with feedback `k += 0.12(1−k)`; knowledgeable skills start at k=0.92 with a 90-day half-life; answers are correct with probability = hidden recall (so an ~8% slip rate exists even for mastered skills).

Metrics target the brief's list: personalisation (redundant re-explanation), memory usefulness & stale memory (preference respected / retracted preference violated), learner-model accuracy (MAE vs hidden recall), context efficiency (prompt chars, brief tokens), over-trusting memory (missed refresh), plus the synthetic learning outcome for completeness.

## Results — offline run (scripted policy reading the brief; measures the layer, not Gemini)

| condition | redundant re-explanations (learner still knew it) | retrieval prompts instead | missed refresh (learner had forgotten) | stated-preference respected (before correction) | stale-preference violations after correction | learner-model MAE | avg prompt chars | avg brief tokens | tool calls | hidden final k | hidden retention +60d | ms/turn |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| none | 21/21 | 0 | 0/25 | 0.00 | 0/24 | – | 3681 | 0 | 0 | 0.89 | 0.23 | 3 |
| transcript | 21/21 | 0 | 0/25 | 1.00 | 12/24 | – | 6647 | 722 | 0 | 0.89 | 0.23 | 3 |
| layer | 9/21 | 12 | 0/25 | 1.00 | 0/24 | 0.27 | 5256 | 257 | 0 | 0.89 | 0.23 | 8 |

Reading:

- **Redundant re-explanation** (the person still knew it, the tutor re-taught anyway): baselines 21/21, layer 9/21. The layer's remaining nine trace to the knowledgeable learner's random slips: one wrong answer lowers the model's estimate, and the offline policy then refreshes. With the mock, the `transcript` baseline cannot infer "already demonstrated" from raw text; a real model can, which is what the live lab measures.
- **Stale memory / over-adaptation**: after the learner retracts a preference, raw transcripts still led to 12/24 turns using it (the retraction is later in the text and eventually falls off the budget); the layer: 0/24, because the belief is retired with a guard and the brief says "Do NOT assume".
- **Stated preference respected** before retraction: transcript and layer both 1.00; `none` 0.
- **Learner-model accuracy**: MAE 0.27 against hidden recall with no calibration to the synthetic truth. Most error is on slipped skills; the archive's per-learner forgetting calibration (MAE 0.14) is a known next step.
- **Context efficiency**: the layer conveys the history in ≈260 tokens vs ≈720 for the transcript baseline (which also loses information at the cut), at a fixed ~1.6k-token system prompt overhead.
- **Missed refresh** (person had actually forgotten, tutor only quizzed): 0/25 in all conditions — the brief's `[fading]` status and low recall figure are respected by the policy.
- **Hidden learning outcome** is identical across conditions here because the offline policy always teaches when asked; it is reported to show the lab is not rigged toward the layer. It is not evidence about humans.

## Live run (Gemini)

`GEMINI_API_KEY=… npm run lab:live` runs the same script with Gemini as tutor, an LLM verbaliser for the learner (correctness still dictated by hidden state) and an LLM judge classifying each tutor turn (full explanation? posed a check? approach?). No key was available in the build sandbox, so **no live numbers are reported here**; the harness is complete and the offline numbers must not be read as claims about Gemini's teaching quality.

## What the lab does not show

- Human learning. Synthetic dynamics are declared, not validated.
- Whether Gemini follows the brief as well as the scripted policy does — that is what the live run is for.
- Long-tail retrieval quality (histories large enough to exceed the brief budget). Lexical `recall_memory` is tested functionally, not for ranking quality.
