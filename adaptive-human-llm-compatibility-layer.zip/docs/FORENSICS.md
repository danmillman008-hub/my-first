# Forensic analysis of previous attempts

## Sources recovered

| Source | Status | How |
| --- | --- | --- |
| Repository 1 — `danmillman008-hub/my-first` | **Recovered** (public, cloned) | It is an archive: 19 zip files = 17 distinct project generations + 1 unrelated game + duplicates |
| Repository 2 — `build-adaptive-learning-agent` | **Recovered from the archive** (`build-adaptive-learning-agent.zip`, 39 files, 3.7k TS lines, with its own `docs/ARCHIVE_FORENSICS.md`, `DECISIONS.md`, `EVALUATION.md`, `RESEARCH.md` and lab output) | The standalone GitHub repository required authentication and could not be cloned; the archived snapshot is treated as the evidence |
| Repository 3 — `Graphify-Labs/graphify` | Cloned; **not executed** | Python tool; `pip install` is blocked by PEP 668 in this sandbox. The cross-generation relationship analysis it would have produced was done directly with lexical scans over all 14 extracted generations (below). |

Retrieval gap: the live HEAD of Repository 2 could not be fetched. Nothing in this report depends on differences between the snapshot and HEAD.

## Cross-generation concept recurrence (14 generations scanned)

| Concept | Generations using it | What their own evidence said |
| --- | --- | --- |
| MCP server | 11/14 | Interop plumbing; never tied to a learning or personalisation result |
| Affect engine | 10/14 | No measured benefit; high risk of false inferences about the person |
| Half-life / forgetting model | 10/14 | Repeatedly useful; per-learner calibration reduced model error (MAE 0.14 vs 0.18) |
| Belief lifecycle (candidate/active/contested/retired) | 9/14 | Correction demonstrably works only with a re-derivation guard; validated in 3+ labs |
| Learner correction handling | 8/14 | Correction sentences were repeatedly mis-parsed as requests in early generations |
| Attribution rules (credit the right turn) | 7/14 | Source of most recurring bugs: crediting the wrong turn, grading against stale items |
| BKT | 6/14 | Replaced by half-life model in the newest generation (fewer guessed parameters) |
| Concept graph / Graphify corpus | 6/14 | Four attempts, heavy tooling, **no measured adaptation or learning benefit** |
| Wikipedia research | 6/14 | Cheap generality; correctly isolated from learner memory |
| Thompson/UCB bandit over explanation styles | 5/14 | **≈0 learning benefit** in two independent labs; optimised reactions ("that makes sense") not learning |
| Append-only evidence / provenance | 5/14 | Kept in every later generation; makes the model inspectable |
| **LLM tool-calling / function declarations** | **0/14** | never tried |
| **Embeddings / semantic retrieval** | **0/14** | never tried |
| Any LLM *deciding* pedagogy | 0/14 | Every generation: deterministic engine decides, LLM writes prose ("LLM optional, never decisive") |

## The decisive inherited result

`self-adapting-learning-agent-mission` and `build-adaptive-learning-agent` both ran hidden-ground-truth synthetic labs:

| condition | gain | retention | transfer | "understood" reactions |
| --- | --- | --- | --- | --- |
| full practice loop | 0.62–0.81 | 0.40–0.67 | 0.34–0.65 | 0.29 |
| explain-only chat tutor | 0.17–0.27 | 0.04–0.22 | 0.01–0.08 | **0.54** |
| no style bandit | ≈ full | ≈ full | ≈ full | 0.23 |

Two lessons survive:
1. **Reaction metrics ≠ learning.** The explain-only tutor *won* on "that makes sense" while producing almost no learning. Any evaluation of this project must not reward pleasant reactions.
2. **Style-selection machinery was worthless; evidence about the learner was not.** What produced learning was retrieval, spacing and feedback — behaviours a modern LLM can perform on its own *if it knows the learner's history*.

Caveat we carry forward honestly: those labs used synthetic learners whose dynamics were designed around retrieval/spacing, so the size of the practice-loop effect is partly circular. The qualitative ordering matches the human learning-science literature (see RESEARCH.md).

## What was wrong in the previous framing

Every generation answered "how much intelligence should the app own?" with **"all of it"** — perception by regex, grading by mechanical graders, policy by rules or bandits, composition by templates, with the LLM as an optional prose generator that "never decides". That was defensible for 2023-era models. It produced:

- rigid dialogue (learner forced into item/answer loops),
- brittle perception (correction sentences parsed as answers; "let's continue" parsed as requests),
- hard-coded subject packs contradicting generality,
- and thousands of lines of orchestration whose benefit was never demonstrated over a capable model with good context.

The newest snapshot (`synthesize-…`) even regressed to reaction-based benchmarks.

## What we kept, changed, removed

| Inherited element | Decision | Why |
| --- | --- | --- |
| Claimed ≠ demonstrated; aided ≠ unaided; spaced ≠ massed | **Kept** (pure functions in `src/lib/memory/model.ts`) | Validated repeatedly; exactly the distinctions an LLM cannot maintain across sessions |
| Belief lifecycle with provenance, confidence cap, cross-session requirement, correction + 14-day guard, temporary context expiry | **Kept** (simplified) | Correction only works with the guard; temporary states must not become traits |
| Half-life recall model | **Kept** | Inspectable ("recall≈41%"), few parameters, FSRS-compatible shape |
| Attribution: credit the previous approach on the *next* learner turn | **Kept** (approach ledger) | Same-turn credit measured "performance", not learning |
| Append-only observations with message provenance | **Kept** | Auditability |
| Deterministic perception (regex flags) | **Removed** → LLM structured reflection | Modern structured output is strictly better at reading natural language; the deterministic part now lives in *applying* the extraction, not producing it |
| Decision policy / activity controller | **Removed** → the model decides | Untested hypothesis in all 14 generations; the brief's central question |
| Style bandit, affect engine, concept graph, curated packs, MCP, Wikipedia research | **Removed** | No measured benefit, or not needed for the product question (all re-addable behind the same store) |
| Mechanical graders / item bank | **Removed** | The model grades open answers in context; the reflection records the outcome |
| Synthetic-learner lab with hidden state, ablation conditions, honest reporting | **Kept** (rebuilt around conversation rather than items) | The only kind of evaluation that measured the right thing |
