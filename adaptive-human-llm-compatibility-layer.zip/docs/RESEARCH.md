# Research report

## The question

How can a layer between one person and one LLM reduce the gap between their capabilities, so the model can teach (or simply help) with more freedom *and* more understanding of the person — without a rigid engine on either side?

## 1. What current LLMs already do well (so we must not rebuild it)

Verified against the current Gemini API documentation (September 2026):

- **Model line.** `gemini-3.6-flash` is a stable GA model (released 2026-07-21) with a 1,048,576-token context window, 65k output tokens, native function calling, structured output (JSON schema), configurable thinking levels, multimodal input, code execution, search grounding and remote MCP tools. Sources: https://ai.google.dev/gemini-api/docs/models, https://firebase.google.com/docs/ai-logic/models, https://docs.cloud.google.com/gemini-enterprise-agent-platform/models/guides/gemini-3-7-flash.
- **Function calling** is first-class in both the classic `generateContent` REST endpoint (`tools[].functionDeclarations`) and the newer Interactions API; the docs recommend ≤10–20 active tools and avoiding required text-before-tool-call patterns. Source: https://ai.google.dev/gemini-api/docs/function-calling.
- **Structured output** with `responseMimeType: application/json` + `responseSchema` is reliable enough to use as an extractor. Source: https://ai.google.dev/api/generate-content.
- **Pedagogy in context.** Within a single conversation, frontier models diagnose misconceptions, choose between worked examples/analogies/Socratic questions, generate and grade exercises, and adapt register — this is the premise behind Google's LearnLM work (https://ai.google.dev/gemini-api/docs/learnlm) and is consistent with our own use of the model.

Conclusion: **explaining, questioning, choosing a strategy, grading and detecting confusion within a session are solved well enough that building them as app logic subtracts value** (it constrains a stronger reasoner with a weaker one).

## 2. What LLMs do not do reliably (where the layer must create value)

1. **Longitudinal persistence.** Nothing survives the context window except what the app stores. Provider "memory" features are opaque, non-auditable and not portable across providers.
2. **Epistemic bookkeeping across time.** Models conflate "user said they know X" with "user demonstrated X", and "I explained X" with "user learned X". Both confusions were measured repeatedly in the archive's labs and are documented in the metacognition literature (judgments of learning are poorly calibrated; Soderstrom & Bjork 2015, *Learning versus performance*).
3. **Time.** Models have no sense of elapsed time between sessions; retention decays (Ebbinghaus; spacing-effect meta-analysis Cepeda et al. 2006). A half-life model makes "you last used this 3 weeks ago; predicted recall ≈ 40%" available as a fact.
4. **Attribution.** "Did the worked example help?" is only knowable from the *next unaided* response, often in a later session. Same-turn reactions measure performance, not learning (Soderstrom & Bjork 2015; Bjork's desirable difficulties).
5. **Over-adaptation and recency bias.** Given a raw transcript, models over-weight the latest statement and under-weight corrections buried earlier; a stated preference from three months ago and a correction from yesterday need explicit lifecycle semantics (this failure showed up in our `transcript` baseline: 12/24 stale-preference violations vs 0/24 for the layer).
6. **Verifiability and control.** The person must be able to inspect, correct and erase what is believed about them. This is a product/legal requirement, not a model capability.

## 3. Memory: what current systems do and where they fail

Surveyed approaches: generative-agent style reflection (Park et al. 2023), MemGPT/Letta tiered memory, Mem0/Zep-style extraction + graph memory, provider-native memory (ChatGPT memory, Gemini "saved info"), and the archive's own belief lifecycle.

| Memory type | Where it lives here | Rationale |
| --- | --- | --- |
| Episodic | `messages` (raw), `observations` (extracted, with `message_id` provenance) | Raw text is the ground truth for audit and for `recall_memory` |
| Semantic about the person | `beliefs` with source / status / confidence / scope / validity / guard | This is where extraction-only systems fail: no contradiction handling, no expiry, no correction guard |
| Procedural ("what works for them") | `approach_ledger` (approach × skill → next-turn outcome) | Kept as *statistics*, never promoted to beliefs — the archive found outcome-derived "preferences" self-reinforce |
| Skill state | `skill_states` (claimed/demonstrated/failed/explained counts, half-life) | The learner model; see ARCHITECTURE.md |
| Working | the model's own context: recent turns + compiled brief | 1M-token context makes summarising recent turns unnecessary |

Findings:
- **Extraction is the easy part** now (structured output). **Consolidation semantics** are the hard part: when does a repeated observation become a belief, when does a contradiction demote it, when does it expire, how is a correction protected from re-inference. Those rules are deterministic here and unit-tested.
- **Retrieval at single-person scale is not a vector-search problem.** One learner produces hundreds, not millions, of items; a compiled brief (≈250 tokens in our lab, vs ≈720 for raw transcript) covers most turns, and lexical search over episodes handles the rest. Embeddings were deliberately not added (Decision 9) — the interface (`searchEpisodes`) can be swapped for pgvector if a learner's history grows large.
- **Reflection should be per-turn and cheap**, not a batch process: the archive found batch consolidation diverging from the online path.

## 4. Learner model: needed or not?

An explicit model **is** needed, but far smaller than the archive's. What must be explicit is exactly what the model cannot infer from text at a later date: per-skill evidence counts by kind, timestamps for decay, the claim/demonstration gap, misconception flags, and belief lifecycle. Everything else (level, pace, modality) is better inferred by the model at read time from that evidence than encoded as traits — traits were the archive's main source of false inferences.

## 5. Teaching: policy or freedom?

We tested the "let the model decide, inform it well" hypothesis rather than assuming it. The lab (EVALUATION.md) shows the layer removes redundant re-explanation, respects and un-learns preferences correctly, and keeps a calibrated recall model, using less context than raw transcripts — with no policy code. The prompt contains no pedagogy rules, only epistemic guidance ("distinguish demonstrated from claimed", "current context wins over history").

## 6. Two-sided adaptation

- **Human → model:** the brief tells the model what the person brings (background, goals, what they demonstrated) so the model can *ask them to contribute* (their examples, intuition) instead of explaining what they live with.
- **Model → human:** `ModelProfile` (context window, tool support, structured output, thinking, brief budget) is read by the context compiler. A model without tools gets everything inlined; a bigger-context model gets a larger brief and more raw turns; a model without structured output would fall back to text extraction. Swapping the provider changes how memory is *presented*, not what is *stored*.

## Sources

- Gemini API docs (models, function calling, structured output, LearnLM) — links above, accessed 2026-09-05.
- Soderstrom, N. & Bjork, R. (2015). Learning versus performance. *Perspectives on Psychological Science*.
- Cepeda et al. (2006). Distributed practice in verbal recall tasks: a review and quantitative synthesis. *Psychological Bulletin*.
- Roediger & Karpicke (2006). Test-enhanced learning. *Psychological Science*.
- Kalyuga et al. (2003). The expertise reversal effect. *Educational Psychologist*.
- Park et al. (2023). Generative Agents: interactive simulacra of human behavior (reflection/memory stream).
- Packer et al. (2023). MemGPT: towards LLMs as operating systems (tiered memory).
- FSRS open-source spaced-repetition scheduler (initial stability after first recall ≈ 3 days) — used as a sanity check for the half-life defaults.
- Archive labs: `build-adaptive-learning-agent/docs/EVALUATION.md`, `self-adapting-learning-agent-mission/EVALUATION.md` (summarised in FORENSICS.md).
