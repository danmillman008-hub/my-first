/* eslint-disable no-console */
/**
 * Evaluation lab: does the compatibility layer measurably improve a long-term interaction?
 *
 * Same `runTurn` code path, three conditions:
 *   none        – model sees only the current conversation
 *   transcript  – model sees raw prior transcripts (budgeted), no reflection
 *   layer       – compiled brief + memory tools + reflection (the product)
 *
 * Synthetic learners have HIDDEN state (knowledge, forgetting, preferences). The tutor sees only text.
 * The learner's script is identical across conditions; only what the tutor knows differs.
 *
 * Offline (no GEMINI_API_KEY or LLM_PROVIDER=mock): tutor = scripted policy reading the brief,
 * judge = heuristic. This measures the LAYER'S mechanics (memory accuracy, correction, redundancy,
 * context cost) — not Gemini's teaching. Live (GEMINI_API_KEY + LAB_LIVE=1): tutor, learner
 * verbaliser and judge are Gemini.
 *
 * Usage: npx tsx scripts/lab/run.ts [--seeds 3] [--live]
 */
import "dotenv/config";
import { mkdirSync, writeFileSync } from "node:fs";
import { pool } from "../../src/db";
import { runTurn, type TurnMode } from "../../src/lib/agent/turn";
import { getProvider } from "../../src/lib/llm";
import { DAY_MS, predictedRecall } from "../../src/lib/memory/model";
import { eraseLearner, loadMemory } from "../../src/lib/memory/store";

const args = process.argv.slice(2);
const SEEDS = Number(args[args.indexOf("--seeds") + 1] || 2);
const LIVE = args.includes("--live") || process.env.LAB_LIVE === "1";
if (!LIVE) process.env.LLM_PROVIDER = "mock";

// ---------------- deterministic RNG ----------------
function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 2 ** 32;
  };
}

// ---------------- hidden learner ----------------
type HiddenSkill = { label: string; slug: string; k: number; stability: number; lastSuccess: number | null; demonstratedEver: boolean };
type Archetype = "novice" | "corrector" | "returning" | "knowledgeable";
type Learner = {
  id: string;
  archetype: Archetype;
  skills: HiddenSkill[];
  preference: string; // stated approach
  preferenceCorrectedAt: number | null; // session index
  rand: () => number;
  log: LearnerLog;
};
type LearnerLog = {
  explainTurns: { session: number; skill: string; demonstratedBefore: boolean; hiddenRecall: number; approach: string | null; fullExplanation: boolean; posedCheck: boolean }[];
  checks: { session: number; skill: string; correct: boolean }[];
  modelErrors: number[];
  promptChars: number[];
  briefTokens: number[];
  toolCalls: number;
  durationMs: number[];
};

const SKILL_LABELS = ["the base case in recursion", "closures in JavaScript", "TCP three-way handshake", "Bayes' theorem"];
const slugOf = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");

function makeLearner(seed: number, archetype: Archetype, cond: string): Learner {
  const rand = rng(seed * 7919 + archetype.length * 31);
  return {
    id: `lab-${cond}-${archetype}-${seed}`,
    archetype,
    skills: SKILL_LABELS.map((label, i) =>
      archetype === "knowledgeable" && i < 2
        ? { label, slug: slugOf(label), k: 0.92, stability: 90, lastSuccess: null, demonstratedEver: false }
        : { label, slug: slugOf(label), k: 0.05 + rand() * 0.1, stability: 4, lastSuccess: null, demonstratedEver: false },
    ),
    preference: "worked examples",
    preferenceCorrectedAt: archetype === "corrector" ? 2 : null,
    rand,
    log: { explainTurns: [], checks: [], modelErrors: [], promptChars: [], briefTokens: [], toolCalls: 0, durationMs: [] },
  };
}

const hiddenRecall = (s: HiddenSkill, t: number) => (s.lastSuccess === null ? s.k : s.k * Math.pow(2, -((t - s.lastSuccess) / DAY_MS) / s.stability));

function learnFromExplanation(s: HiddenSkill) {
  s.k += 0.3 * (1 - s.k);
}
function learnFromRetrieval(s: HiddenSkill, correct: boolean, t: number) {
  if (correct) {
    const spaced = s.lastSuccess === null || t - s.lastSuccess > DAY_MS;
    s.k += 0.25 * (1 - s.k);
    s.stability *= spaced ? 2.5 : 1.2;
    s.lastSuccess = t;
    s.demonstratedEver = true;
  } else {
    s.k += 0.12 * (1 - s.k); // feedback after a failed attempt still teaches a little
    s.stability = Math.max(1, s.stability * 0.8);
  }
}

// ---------------- judge: classify a tutor turn ----------------
type Judgement = { fullExplanation: boolean; posedCheck: boolean; approach: string | null };

async function judge(tutorText: string, skill: string): Promise<Judgement> {
  if (!LIVE) {
    const tag = tutorText.match(/\[approach:([a-z_]+)\]/)?.[1] ?? null;
    return { fullExplanation: tag !== null && tag !== "retrieval_check", posedCheck: /My answer:/.test(tutorText), approach: tag };
  }
  const p = getProvider();
  return p.generateJSON<Judgement>({
    system: `TASK: JUDGE\nClassify one tutor message about "${skill}". fullExplanation=true if it teaches/explains the concept substantively (more than a one-line reminder). posedCheck=true if it asks the learner to answer a question or attempt something. approach = dominant teaching approach: worked_example, execution_trace, analogy, socratic, formal, direct_answer, exercise, code_example, retrieval_check, other, or null if not teaching. JSON only.`,
    schema: {
      type: "object",
      properties: { fullExplanation: { type: "boolean" }, posedCheck: { type: "boolean" }, approach: { type: "string", nullable: true } },
      required: ["fullExplanation", "posedCheck", "approach"],
    },
    contents: [{ role: "user", parts: [{ text: tutorText }] }],
  });
}

// ---------------- learner verbaliser (live only) ----------------
async function verbaliseAnswer(skill: HiddenSkill, correct: boolean, tutorText: string): Promise<string> {
  if (!LIVE) return correct ? `My answer: ${skill.slug}-key` : `My answer: I'm not sure… something about ${skill.label}, but I can't say what.`;
  const p = getProvider();
  const r = await p.generateJSON<{ reply: string }>({
    system: `TASK: LEARNER\nYou role-play a learner answering a tutor about "${skill.label}". ${correct ? "You DO understand it: give a short correct answer in your own words (1–2 sentences)." : "You do NOT really understand it: give a short answer that is vague or contains a plausible mistake, or say you're not sure."} No meta commentary. JSON: {"reply": string}`,
    schema: { type: "object", properties: { reply: { type: "string" } }, required: ["reply"] },
    contents: [{ role: "user", parts: [{ text: `Tutor said:\n${tutorText}` }] }],
  });
  return r.reply;
}

// ---------------- one learner through the script ----------------
const SESSION_DAYS = [0, 2, 9, 30];

async function runLearner(L: Learner, mode: TurnMode) {
  const t0 = new Date("2026-09-01T09:00:00Z").getTime();
  await eraseLearner(L.id);
  let clock = t0;
  const step = () => new Date((clock += 90_000));

  for (let si = 0; si < SESSION_DAYS.length; si++) {
    const sessionId = `${L.id}-s${si}`;
    clock = t0 + SESSION_DAYS[si] * DAY_MS;
    const sessionStart = clock;

    // model accuracy at session start (layer only)
    if (mode === "layer" && si > 0) {
      const mem = await loadMemory(L.id);
      for (const hs of L.skills) {
        const st = mem.skills.find((s) => s.skill === hs.slug || s.label.toLowerCase().includes(hs.label.toLowerCase().slice(0, 12)));
        const predicted = st ? predictedRecall(st, new Date(sessionStart)) : 0;
        L.log.modelErrors.push(Math.abs(predicted - hiddenRecall(hs, sessionStart)));
      }
    }

    const say = async (text: string) => {
      const r = await runTurn({ learnerId: L.id, sessionId, userText: text, mode, now: step() });
      L.log.promptChars.push((r.trace.promptTokens ?? r.trace.briefTokens) * 4);
      L.log.briefTokens.push(r.trace.briefTokens);
      L.log.toolCalls += r.trace.tools.length;
      L.log.durationMs.push(r.trace.durationMs);
      return r.text;
    };

    if (si === 0) await say(`Hi! I'm a backend engineer. I prefer ${L.preference} when learning something new.`);
    if (L.preferenceCorrectedAt === si) await say(`One thing: actually, I don't prefer ${L.preference} — I was wrong about that. Explanations from first principles work better for me.`);

    const skillsThisSession = si === 0 ? L.skills.slice(0, 3) : si === 1 ? L.skills.slice(0, 4) : L.skills;
    for (const hs of skillsThisSession) {
      const ask =
        si === 0 && hs.k > 0.8 ? `I already know ${hs.label} well.` : si === 0 || !hs.demonstratedEver ? `Can you explain ${hs.label}?` : `Can we go over ${hs.label} again?`;
      const demonstratedBefore = hs.demonstratedEver;
      const tutor = await say(ask);
      const j = await judge(tutor, hs.label);
      L.log.explainTurns.push({ session: si, skill: hs.slug, demonstratedBefore, hiddenRecall: hiddenRecall(hs, clock), approach: j.approach, fullExplanation: j.fullExplanation, posedCheck: j.posedCheck });
      if (j.fullExplanation) learnFromExplanation(hs);
      if (j.posedCheck) {
        const correct = L.rand() < hiddenRecall(hs, clock);
        const answer = await verbaliseAnswer(hs, correct, tutor);
        await say(answer);
        learnFromRetrieval(hs, correct, clock);
        L.log.checks.push({ session: si, skill: hs.slug, correct });
      }
    }
  }
  const end = t0 + 60 * DAY_MS;
  return {
    finalK: mean(L.skills.map((s) => s.k)),
    retention60: mean(L.skills.map((s) => hiddenRecall(s, end))),
  };
}

const mean = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : NaN);
const fmt = (x: number, d = 2) => (Number.isNaN(x) ? "–" : x.toFixed(d));

// ---------------- aggregate ----------------
type Row = {
  condition: string;
  redundantReexplain: number;
  reexplainOpportunities: number;
  missedRefresh: number;
  refreshOpportunities: number;
  retrievalPrompts: number;
  prefRespectBefore: number;
  prefViolationsAfterCorrection: number;
  prefTurnsAfterCorrection: number;
  modelMAE: number;
  promptChars: number;
  briefTokens: number;
  toolCalls: number;
  finalK: number;
  retention60: number;
  msPerTurn: number;
};

async function main() {
  const conditions: TurnMode[] = ["none", "transcript", "layer"];
  const archetypes: Archetype[] = ["novice", "corrector", "returning", "knowledgeable"];
  const rows: Row[] = [];
  const prefApproach = "worked_example";

  console.log(`Lab: ${LIVE ? "LIVE (" + getProvider().id + ")" : "OFFLINE (mock policy)"} · seeds=${SEEDS}`);
  for (const cond of conditions) {
    const agg = { redundant: 0, opp: 0, retrieval: 0, refreshOpp: 0, missedRefresh: 0, prefOk: 0, prefTurns: 0, prefViol: 0, prefAfter: 0, mae: [] as number[], chars: [] as number[], brief: [] as number[], tools: 0, k: [] as number[], ret: [] as number[], ms: [] as number[] };
    for (let seed = 1; seed <= SEEDS; seed++) {
      for (const arch of archetypes) {
        const L = makeLearner(seed, arch, cond);
        const out = await runLearner(L, cond);
        for (const e of L.log.explainTurns) {
          if (e.demonstratedBefore && e.hiddenRecall >= 0.6) {
            // the learner still actually knows it: a full re-explanation is redundant
            agg.opp++;
            if (e.fullExplanation) agg.redundant++;
            if (e.posedCheck && !e.fullExplanation) agg.retrieval++;
          }
          if (e.demonstratedBefore && e.hiddenRecall < 0.3) {
            // the learner has actually forgotten it: a retrieval-only turn is a missed refresh
            agg.refreshOpp++;
            if (!e.fullExplanation) agg.missedRefresh++;
          }
          const corrected = L.preferenceCorrectedAt !== null && e.session >= L.preferenceCorrectedAt;
          if (e.fullExplanation && e.session > 0) {
            if (!corrected) {
              agg.prefTurns++;
              if (e.approach === prefApproach) agg.prefOk++;
            } else {
              agg.prefAfter++;
              if (e.approach === prefApproach) agg.prefViol++;
            }
          }
        }
        agg.mae.push(...L.log.modelErrors);
        agg.chars.push(...L.log.promptChars);
        agg.brief.push(...L.log.briefTokens);
        agg.tools += L.log.toolCalls;
        agg.k.push(out.finalK);
        agg.ret.push(out.retention60);
        agg.ms.push(...L.log.durationMs);
        process.stdout.write(".");
      }
    }
    rows.push({
      condition: cond,
      redundantReexplain: agg.redundant,
      reexplainOpportunities: agg.opp,
      missedRefresh: agg.missedRefresh,
      refreshOpportunities: agg.refreshOpp,
      retrievalPrompts: agg.retrieval,
      prefRespectBefore: agg.prefTurns ? agg.prefOk / agg.prefTurns : NaN,
      prefViolationsAfterCorrection: agg.prefViol,
      prefTurnsAfterCorrection: agg.prefAfter,
      modelMAE: mean(agg.mae),
      promptChars: mean(agg.chars),
      briefTokens: mean(agg.brief),
      toolCalls: agg.tools,
      finalK: mean(agg.k),
      retention60: mean(agg.ret),
      msPerTurn: mean(agg.ms),
    });
    console.log(` ${cond} done`);
  }

  const header = "| condition | redundant re-explanations (learner still knew it) | retrieval prompts instead | missed refresh (learner had forgotten) | stated-preference respected (before correction) | stale-preference violations after correction | learner-model MAE | avg prompt chars | avg brief tokens | tool calls | hidden final k | hidden retention +60d | ms/turn |";
  const sep = "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |";
  const body = rows
    .map(
      (r) =>
        `| ${r.condition} | ${r.redundantReexplain}/${r.reexplainOpportunities} | ${r.retrievalPrompts} | ${r.missedRefresh}/${r.refreshOpportunities} | ${fmt(r.prefRespectBefore)} | ${r.prefViolationsAfterCorrection}/${r.prefTurnsAfterCorrection} | ${fmt(r.modelMAE)} | ${fmt(r.promptChars, 0)} | ${fmt(r.briefTokens, 0)} | ${r.toolCalls} | ${fmt(r.finalK)} | ${fmt(r.retention60)} | ${fmt(r.msPerTurn, 0)} |`,
    )
    .join("\n");
  const md = `# Lab summary\n\nMode: **${LIVE ? "LIVE — " + getProvider().id : "OFFLINE — scripted mock policy (measures the layer, not Gemini)"}** · seeds: ${SEEDS} · archetypes: ${archetypes.join(", ")} · sessions at days ${SESSION_DAYS.join("/")} · generated ${new Date().toISOString()}\n\n${header}\n${sep}\n${body}\n\nMetric notes\n- *redundant re-explanations*: tutor gave a full explanation of a skill the learner had retrieved unaided before AND still actually knew (hidden recall ≥ 0.6). Lower is better; measures longitudinal personalisation / context efficiency.\n- *missed refresh*: learner had retrieved it before but had actually forgotten it (hidden recall < 0.3) and the tutor only quizzed instead of refreshing. Lower is better; guards against over-trusting memory.\n- *retrieval prompts instead*: on those same opportunities, the tutor asked for a retrieval attempt rather than re-explaining.\n- *stated-preference respected*: share of instructional turns (sessions ≥ 2) using the approach the learner stated in session 1.\n- *stale-preference violations*: instructional turns that still used the corrected preference after the learner retracted it (over-adaptation / stale memory; lower is better).\n- *learner-model MAE*: |predicted recall − hidden recall| at each session start (layer only; baselines have no model).\n- *hidden final k / retention*: synthetic learning dynamics — reported for completeness, NOT evidence about humans.\n`;
  mkdirSync("lab/out", { recursive: true });
  writeFileSync("lab/out/summary.md", md);
  writeFileSync("lab/out/summary.json", JSON.stringify({ live: LIVE, provider: getProvider().id, seeds: SEEDS, rows }, null, 2));
  console.log("\n" + md);
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
