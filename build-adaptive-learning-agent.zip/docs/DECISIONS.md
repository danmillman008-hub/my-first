# Decision log

Chronological, with the evidence that drove each decision. "Lab" = `scripts/lab`; "archive" = `docs/ARCHIVE_FORENSICS.md`.

| # | Decision | Alternatives considered | Evidence / reason |
| --- | --- | --- | --- |
| 1 | **Treat the archive as evidence, not a base.** Start from a fresh core; re-implement only mechanisms with a measured reason to exist. | Continue the `synthesize` snapshot | The snapshot's evaluation measured reactions, not learning; the one attempt that measured learning showed the style bandit contributes ≈0 to it (archive) |
| 2 | **Make the evidence loop the product.** Every activity after first exposure is a graded retrieval; the chat tutor is the baseline. | Conversation-first tutor with occasional quizzes | Testing/spacing/feedback evidence (RESEARCH); Bastani 2024; archive mission result; our lab: 0.62 vs 0.17 gain |
| 3 | **Domain-agnostic content contract** (`Skill`, `Item` with grader, variant, error tags) with sources LLM → Wikipedia → notes → scaffold. No curated packs. | Curated packs + research fallback (archive) | Generality requirement; packs are a hidden subject list; the loop never needs subject knowledge (lab runs on purely synthetic structures) |
| 4 | **Half-life memory model with per-learner calibration** instead of BKT. | BKT (archive), FSRS verbatim | Forgetting is first-class and inspectable ("half-life 3.2 d, due in 2 d"); fewer guessed parameters; calibration measurably reduces model error (MAE 0.14 vs 0.18) |
| 5 | **Aided ≠ unaided; massed ≠ spaced; novel ≠ familiar** are encoded in the state, not inferred later. | Single success counter | Lab bugs 2–4 (archive §"new bugs") showed that without these distinctions skills became "secure" without ever being retrieved unaided or in a new context |
| 6 | **Desired retention 0.85** as the review trigger. | 0.75 (first version) | Raising it increased reviews/turn 0.08→0.18 and retention; matches common FSRS/Anki practice. Not validated on humans |
| 7 | **Support form by rule, not bandit**: worked example while nothing is demonstrated → unaided retrieval after → worked example after three misses; stated preference overrides; hint-first when answer-seeking tendency is active. | Thompson/UCB bandit over support modes (built, kept as lab condition) | Lab: bandit ≤ rule on every learning metric, −0.23 gain for novices; archive: same qualitative result. Expertise-reversal literature supports the rule's shape |
| 8 | **Outcome statistics are not beliefs.** Per-arm success rates are shown as statistics; only *stated* preferences become beliefs, and they are contested by outcomes. | Infer "prefers X" from outcome correlations (first version) | Self-reinforcing loop and false actives for `example_averse` in the lab; epistemically it was an observation masquerading as an inference |
| 9 | **Beliefs: candidate/active/contested/retired with provenance, scope, expiry, supersession, 14-day re-derivation guard after correction.** | Flat key–value preferences | Correction demonstrably works only with the guard (adversarial); temporary context must not become a permanent trait |
| 10 | **Attribution rules**: grade against the posing turn by id; support credited by the first later unaided attempt; cross-session / mastery / age down-weights; stale items dropped at session boundaries. | Credit the immediate outcome | Performance ≠ learning (Soderstrom & Bjork); archive's stale-turn bugs; adversarial checks 3, 4, 11 |
| 11 | **Self-reports are claims** (prior + verification), never evidence; durable discrepancy → tendency belief. | Trust "I already know this" | JOL calibration literature; adversarial check 5 |
| 12 | **Answers before an attempt are non-retrievals**; repeated requests build a tendency; once active, hint first. | Always comply; never comply | Bastani 2024 (guard-railed help removes harm); lab: hint_seeker retention 0.08 → 0.35 after the rule |
| 13 | **Untagged repeated wrong text needs 3 occurrences** to count as a pattern; tagged/choice/LLM-labelled need 2. | 2 for everything | False "misconceptions" from generic wrong answers in the lab |
| 14 | **Nothing due ≠ all secure.** Extra retrieval on the weakest skill, or an honest "nothing is due" message. | Keep drilling; claim mastery | Wrong message in the first trace; over-drilling adds little (spacing) |
| 15 | **Interleave** away from a skill practised twice in a row when a comparable alternative exists. | Blocked practice | Literature medium; lab neutral; cheap |
| 16 | **Single mutable learner document + append-only evidence tables.** | Fully normalised belief/state tables (archive) | One learner per relationship; simpler store (≈100 lines), same inspectability; append-only tables keep provenance |
| 17 | **LLM optional, never decisive**: plans (validated), open-answer grading (separate channel), question answering (guarded not to reveal the open item). Only single-turn context is sent. | LLM-orchestrated agent | Privacy; reproducibility; Bastani; testability. Cost: without a key, explanations are only as good as Wikipedia or the learner's notes |
| 18 | **No MCP, no concept graph, no affect engine, no accounts.** | All present in some archive attempt | No measured benefit for the product question; complexity budget |
| 19 | **Synthetic learner with learning dynamics** (knowledge, half-life, misconceptions, transfer, expertise reversal, pretesting, savings) and delayed hidden assessment. | Affinity/reaction learner (archive) | Measures learning, not agreement; catches the personalisation-vs-learning confusion by construction |
| 20 | **Report the continuity confound rather than hide it** (`no_memory` retains more on fewer skills). | Change the metric to "taught skills only" | The confound is real product tension (breadth vs depth); the doc explains it and the UI exposes next-review estimates |

## Rejected during development

- Thompson support bandit as default (kept as `supportPolicy: "bandit"`).
- Outcome-derived preference beliefs.
- Review threshold 0.75.
- A dedicated "transfer" activity as a required stage — kept as a candidate, but practice already rotates contexts and the measurement is what matters.
- Treating any unseen item phrasing as a new context.

## Unresolved

- Retention at this turn budget is limited by breadth; a session-length-aware policy (fewer new skills when reviews are piling up) is the obvious next experiment.
- The prior half-life for learners who already know material is too short (model MAE 0.21 for `knowledgeable`); a claim-informed prior could help but risks trusting claims.
- Open-answer grading without a model relies on honest self-grading; it is recorded as a separate channel but its validity is unknown.
- The Wikipedia cloze generator picks salient long words, not always the pedagogically central term.
- No human data.
