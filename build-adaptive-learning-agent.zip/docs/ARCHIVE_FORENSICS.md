# Forensic analysis of the historical archive

Source: `https://github.com/danmillman008-hub/my-first.git` (accessible). The primary repository `synthesize-self-adapting-learning-agent` could **not** be fetched (authentication required in this sandbox). The archive contains `synthesize-self-adapting-learning-agent.zip`, which by name and content appears to be a **snapshot** of that project; it is treated as a snapshot, not as the current HEAD.

The archive holds 19 zips → 17 distinct attempts (two exact duplicates, one unrelated driving game). Sizes 1.6k–4.5k LOC each. All Next.js + Postgres except the game.

## Lineages

| Lineage | Attempts | Core idea | Verdict from their own evidence |
| --- | --- | --- | --- |
| Graph-native | `build-graph-native-ai-tutor`, `graph-native-adaptive-*` (×2), `build-adaptive-graph-ai-tutor` (×2) | Graphify corpus → concept graph → Bloom-level overlay | Four attempts, heavy tooling, **no measured adaptation or learning benefit** from the graph. Not carried forward. |
| Curriculum/affect | `build-self-adapting-learning-agent`, root README | Wikipedia research, RefD prerequisites, packs, affect engine, BKT + Thompson | The engines dominated the code; the README's evidence is a scripted demo. Recovered: research isolated from learner memory; "self-report is a prior, never evidence". |
| LMS | `edtech-platform-development-prompt` | Courses, profiles, dashboards | Opposite of one continuous relationship; negative evidence for manual profile management. |
| Belief-lifecycle + strategy bandit | `private-self-adapting-learning-agent` (1)–(4), `private-self-adapting-agent-mission`, `agentic-software-build-mission`, `adaptive-teaching-mcp-integration`, **`synthesize-…` (snapshot)** | Observations → beliefs (candidate/active/contested/retired), correction, domain scoping; UCB/Thompson over 7 explanation styles | The epistemics are the strongest inherited idea. The **bandit optimises reactions** ("understood" rate, best-style rate) — i.e. personalisation, not learning. |
| Learning-loop | `self-adapting-learning-agent-mission` | Adds a deterministic *activity* controller (review → misconception → verify → teach → check → apply → transfer) and, crucially, **measures hidden learning** | The only attempt whose lab reports gain / retention / transfer / misconceptions. Its results below are the most important inherited evidence. |

## The most important inherited result

From `self-adapting-learning-agent-mission/EVALUATION.md` (3 seeds × 18 archetypes × 9 conditions):

| condition | gain | retain | transfer | misc. left | best-style late | "understood" |
| --- | --- | --- | --- | --- | --- | --- |
| full loop | 0.81 | 0.67 | 0.65 | 0.11 | 0.56 | 0.29 |
| explain-only chat tutor | 0.27 | 0.22 | 0.08 | 0.51 | **0.75** | **0.54** |
| no bandit (fixed style) | 0.81 | 0.63 | 0.61 | 0.12 | 0.20 | 0.23 |
| no spacing | 0.80 | 0.62 | 0.60 | 0.12 | | |
| no remediation | 0.79 | 0.57 | 0.55 | 0.24 | | |

Reading: the practice loop is the dominant mechanism; the explanation-style bandit adds ≈nothing to learning while dominating the "understood"/best-style metrics; the explain-only tutor *wins* the reaction metrics while producing almost no learning. **This is a direct demonstration of the personalisation-vs-learning confusion the mission warns about.**

## What the newest snapshot did with that

The `synthesize` snapshot (the newest, and the likely current repository) went **back** to a reaction-based benchmark: its metrics are best-strategy rate, understood-rate, regret vs oracle; its own README says the lab "measures the adaptation machinery, not learning". Its synthetic learners have *strategy affinities* and no learning dynamics. It kept four curated domain packs (bash, python, …) with a Wikipedia fallback. So the most recent work regressed on the central distinction and still depended on predefined subjects.

## Ideas that survived repeated attempts (and whether we kept them)

| Idea | Attempts | Kept? | Why |
| --- | --- | --- | --- |
| Deterministic core, model only for prose | mission, synth, agentic | **Yes** | Testable, reproducible, private; matches the LLM-harm evidence |
| Belief lifecycle with provenance, correction, guard window | (3), (4), synth, mission | **Yes** (simplified) | Correction measured to work (0/3 recreated vs 2–3/3 without) in three separate labs and again here |
| Self-report as prior, never evidence | curriculum, mission, synth | **Yes** | Consistent with JOL calibration literature |
| Session inferred from time gap; first message not attributed | (3), synth, mission | **Yes** | Attribution failure otherwise |
| Domain-scoped preferences | (4), synth | **Yes** (scope = goal) | Leakage checks passed in all labs |
| 7-style explanation bandit | (3), (4), synth, mission | **No** (lab condition only) | No learning benefit in their lab or ours; optimises reactions |
| Concept graph as primary structure | graph lineage | **No** | Never showed a measured benefit in four attempts |
| Curated domain packs | curriculum, synth, mission | **No** | Hard-coded subjects contradict generality; replaced by a content contract + LLM/Wikipedia/notes/scaffold sources |
| Affect engine | curriculum | **No** (only transient context beliefs) | No measured benefit; high false-inference risk about the person |
| Wikipedia research isolated from learner memory | curriculum, synth, mission | **Yes** | Cheap generality for declarative topics; privacy-clean |
| Learning-loop controller with hidden-learning lab | mission | **Yes** (rebuilt) | The one evaluation that measured the right thing |
| MCP server | (4), mcp-integration, synth | **No** | Not needed for the product question; can be re-added over the same engine |

## Recurring bugs and misleading successes noted across attempts

- Correction sentences re-parsed as requests (attempt 4) → we never parse a correction as anything else (tested).
- Adaptation credited to the wrong turn / one turn late (attempts 3–4) → attempts reference the posing turn by id (tested).
- "Let's continue" read as a request (attempt 3) → resume is a request only when nothing is pending.
- Consolidation as a batch pass diverging from the online path (attempt 3) → single code path per turn.
- Reaction-volume inflating confidence (mission's explain-only had the highest false-active rate) → capped confidence, cross-session requirement, reactions never feed beliefs.
- Benchmarks whose synthetic learner has no learning dynamics produce "adaptation works" headlines with no bearing on learning (synth, 1–4) → our learner has knowledge, forgetting, misconceptions, transfer and expertise reversal, and the headline metrics are delayed and hidden.

## New bugs found in *this* project's development (all fixed, all now regression-tested or visible in the lab)

1. Interleaving could never trigger because consecutive duplicate skill ids were de-duplicated.
2. Support was re-chosen every practice turn, so aided attempts never yielded an unaided outcome and the support credit was overwritten before it could be attributed.
3. Massed same-session successes inflated the half-life to ~50 days; stability growth now depends on spacing and is capped until the first spaced success.
4. "Novel context" counted any unseen recall phrasing, so skills became `secure` without a transfer check; novelty now means an unseen apply/transfer context.
5. Nothing-due was reported as "all skills secure".
6. Any repeated untagged wrong text became a "misconception" after two occurrences; untagged patterns now need three.
7. A short question while an item was open was graded as an answer; a self-report was graded as an answer.
8. The answer-seeking tendency only accrued on unaided items, so with worked-example defaults it never formed.
9. Inferred "preference" beliefs from outcome correlations were self-reinforcing (default → success → belief → same default); outcome statistics are now statistics, and only *stated* preferences override the default.
10. "back to X" never matched because of a stray space in the regex.
