# Research synthesis — what the evidence says and what we did with it

Research served engineering decisions. Each row ends with the decision it drove. Confidence reflects the strength of the external evidence as we understand it, not the strength of our implementation.

## Learning science

| Finding | Evidence (representative) | Confidence | Decision in this system |
| --- | --- | --- | --- |
| **Retrieval practice** beats re-study for long-term retention (testing effect), including for meaningful material and transfer | Roediger & Karpicke 2006; Karpicke & Blunt 2011; Adesope, Trevisan & Sundararajan 2017 meta-analysis (g≈0.5–0.6); Dunlosky et al. 2013 rate practice testing "high utility" | High | Every activity after the first exposure is a retrieval attempt; the explain-only chat tutor is the *baseline*, not a mode |
| **Spacing** beats massing; longer gaps help delayed retention; expanding vs uniform schedules roughly equivalent | Cepeda et al. 2006 meta-analysis; Latimier, Peyre & Ramus 2021 (spaced retrieval g≈0.7) | High | Half-life memory model; review triggered at predicted recall < 0.85 (0.7 once secure); massed repetitions capped in stability growth; no expanding-interval machinery |
| Memory strength is well modelled by a **half-life that grows with successful spaced retrieval** and shrinks on lapse, with per-learner rate differences | Settles & Meeder 2016 (Duolingo half-life regression); FSRS (open-source spaced-repetition scheduler; stability/difficulty/retrievability) | Medium-High | `p = pKnown · 2^(−Δt/(S·scale))`; growth ∝ (1−p) ("desirable difficulty"), ×kind, ×help penalty; per-learner `forgettingScale` fitted from spaced outcomes |
| **Feedback** after an attempt matters; delayed corrective feedback still works; feedback should address the task, not the person | Hattie & Timperley 2007; Butler, Karpicke & Roediger 2007 | High | Every graded attempt gets the reference answer and (for tagged errors) a refutation; feedback text is about the item |
| **Pretesting / generation**: attempting before instruction improves learning from the subsequent explanation, even when the attempt fails | Richland, Kornell & Kao 2009; Kornell, Hays & Bjork 2009 | Medium | `retrieval_first` mode: pose a cold item, then explain; kept as a mode but not the default for novices (see next row) |
| **Worked examples** help novices; the benefit reverses as expertise grows (**expertise-reversal effect**) | Sweller, van Merriënboer & Paas; Kalyuga 2007 | Medium-High | Default support rule: worked example first while nothing is demonstrated on a skill; unaided retrieval as soon as anything is; worked example again after three misses |
| **Interleaving** related skills beats blocking for discrimination and delayed tests | Rohrer & Taylor 2007; Rohrer 2012 | Medium (domain-dependent) | Avoid the same skill three times in a row when a comparable alternative exists; ablated (neutral here) |
| **Misconceptions** are robust; refutation texts / confronting the specific belief outperform plain correct explanations | Tippett 2010 review; Chi 2008 | Medium | Error signatures per skill; persistent pattern → discriminating item + refutation; resolved only after subsequent correct attempts |
| **Transfer** is hard and improves with varied practice contexts; near transfer must be tested, not assumed | Barnett & Ceci 2002; Gick & Holyoak 1983 | Medium | Items carry a `variant` context; success in an unseen apply/transfer context is recorded separately; `secure` requires it |
| **Judgments of learning are poorly calibrated**; fluency and familiarity inflate confidence | Koriat & Bjork 2005; Bjork, Dunlosky & Kornell 2013 | High | Self-reports are claims (prior + verification), never evidence; claim/behaviour gaps become inspectable tendency beliefs; "makes sense" is recorded as a reaction only |
| Mastery learning / tutoring produce large gains; ITS effects ≈ human tutoring on average | Bloom 1984; VanLehn 2011; Kulik & Fletcher 2016 | High (effect exists), Medium (mechanism) | The product is a mastery loop: a skill is not "done" until demonstrated unaided, spaced and in a new context |

## LLMs and learning

| Finding | Evidence | Decision |
| --- | --- | --- |
| Unrestricted generative-AI help raised practice performance but **lowered** unassisted exam performance (−17% for a ChatGPT-like tutor); a guard-railed tutor (hints, no direct answers) removed the harm; students did not perceive the loss | Bastani et al. 2024, field RCT, ≈1000 students | The model is never the decision-maker; it composes prose, grades open answers and answers questions *without giving the open item's answer*. Answers before an attempt are recorded as non-retrievals; repeated answer-seeking triggers hint-first |
| Personalised, struggle-preserving AI help improved exam performance (~0.15 SD) at no extra time | Bastani & Chung (2025/26 reports) | Same guard: help escalates (hint → example → answer) and is attributed |
| LLM pedagogy quality varies and LLM self-assessment of correctness is unreliable | general 2023–2025 literature; our own position | Mechanical graders wherever possible; LLM grading only for open answers and recorded as a separate channel (`grading = llm`) the learner can dispute |

## Learner modelling and adaptive systems

| Finding | Evidence | Decision |
| --- | --- | --- |
| Knowledge tracing (BKT, later DKT) tracks per-skill mastery from correctness; forgetting must be added explicitly | Corbett & Anderson 1995; Piech et al. 2015 | A recency-weighted `pKnown` plus an explicit half-life instead of a 4-parameter BKT: fewer parameters to guess, forgetting first-class |
| Open learner models — showing the learner what the system believes — improve trust and can improve self-regulation | Bull & Kay 2010 | Model panel shows every skill's basis, recall, half-life, next check, trend; every belief with source, status, confidence, counts; every decision with reasons and alternatives |
| Strategy bandits over "how to explain" optimise satisfaction-like signals and are noisy at per-learner scale | archive attempts 3, 4, mission (docs/ARCHIVE_FORENSICS.md); our lab (bandit ≤ rule on every learning metric) | Support form is a rule + stated preference + attribution-checked statistics; the bandit remains as a lab condition only |
| Beliefs about people should be revisable, provenance-carrying and bi-temporal | knowledge-representation practice; archive attempts 3–4 | Belief lifecycle with valid/invalid timestamps, reasons, supersession |

## Evaluation methodology

| Principle | Source | Decision |
| --- | --- | --- |
| Measure learning with delayed and transfer tests, not immediate performance or engagement | Soderstrom & Bjork 2015 ("learning vs performance") | Lab metrics are hidden knowledge at +7/+30 days and held-out novel contexts; immediate correctness is deliberately not a headline metric |
| Synthetic learners isolate mechanisms but do not validate human effects | standard ITS simulation caveat (e.g. VanLehn et al. 1994 SimStudent lineage) | Every simulated claim is labelled as such; the README's status table separates simulated from demonstrated |
| Ablate one mechanism at a time within the same engine | — | 12 conditions, same code path, `Ablation` flags only |

## Open questions we could not settle

- Whether the desired-retention threshold (0.85) and stability growth constants transfer to humans; only calibration data from real spaced checks can answer this.
- How much explicit misconception remediation adds beyond refutation-in-feedback for real learners; the simulated effect was small.
- Whether an LLM-generated skill decomposition is pedagogically sound across domains; validated structurally only.
- The right granularity of a "skill" for procedural and motor goals the system cannot observe (e.g. "learn to juggle") — the scaffold degrades gracefully but cannot grade.
