# Evaluation

Three layers, kept distinct:

1. **Unit tests** (`npm test`, 10) — does the pure core behave as specified?
2. **Adversarial suite** (`npm run adversarial`, 32 checks) — does the *real engine* survive the failure modes found here and in the archive?
3. **Synthetic-learner lab** (`npm run lab`) — does the controller extract learning when retrieval, spacing, feedback, refutation and transfer matter, and does its model of the learner track hidden truth?

Nothing below is evidence about human learners. See "What the synthetic learner is and is not".

## The synthetic learner (`scripts/lab/sim.ts`)

Hidden state per skill: knowledge `k`, memory half-life `s` (days), misconception flag `m`, transfer generalisation `g`, set of contexts practised successfully. The tutor sees only text.

- Recall probability at time *t*: `k · 2^(−Δt/(s·f))`, *f* the learner's forgetting factor. Transfer items multiply by `g`; a hint/example before the attempt adds +0.25.
- Learning: reading a worked example gives `Δk = a·(1−k)` with *a* = 0.35 for novices (k < 0.3) and 0.06 otherwise (expertise reversal); an unaided successful retrieval gives `0.28·(1−k)·(1+(1−p))` spaced or `0.18·…` massed (desirable difficulty); a failed attempt followed by feedback gives 0.22 (novice, pretesting effect) / 0.12; an answer revealed before attempting gives 0.08.
- Memory: spaced success multiplies `s` by `1.7+1.6(1−p)`; massed success by 1.25; failure sets `s = max(1.5, 0.7·s)` (savings on relearning).
- Misconceptions override knowledge on apply/discriminate items 80% of the time; a refutation in feedback removes one with p = 0.45, a remediation turn with p = 0.6, plain correct answers with p = 0.1.
- Transfer: each new context practised successfully raises `g` by the archetype's transfer gain.
- Message behaviour: answers from hidden state (slip 6%, or 22% for `noisy`), "I don't know" 30% of failures, `hint_seeker` asks for the answer 60% of the time, `overconfident`/`corrector` make a scripted claim, `corrector` says "that's not true about me" about the top preference belief at session 2, `goal_switcher` switches topics at session 2 and returns at session 4, `long_gap` waits 21 days between sessions.
- 13 archetypes × 4 synthetic item structures (`factual` exact, `procedural` all-keywords, `quantitative` numeric, `discriminative` multiple choice). Structures rotate across seeds and archetypes.

Hidden assessment after the last session: mean `k` gain; mean recall at +7 and +30 days; transfer = recall × `g` at +7 d; fraction of initial misconceptions remaining; **model MAE** = mean |tutor-predicted recall − hidden recall| at +7 d.

## Results (`lab/out/summary.md`; 3 seeds × 13 archetypes × 12 conditions × 6 sessions × 10 turns = 28,080 turns, 15 s, deterministic per seed)

| condition | gain | retain +7d | retain +30d | transfer +7d | misc. left | model MAE | reviews/turn | remed./turn | false beliefs | corr. recreated | goal continuity |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **full** | 0.62 | 0.40 | 0.19 | 0.34 | 0.39 | 0.14 | 0.18 | 0.02 | 0.00 | 0/1 | 3/3 |
| explain_only (chat tutor) | 0.17 | 0.04 | 0.03 | 0.01 | 1.00 | 0.07 | 0 | 0 | 0.00 | 0/3 | 0/3 |
| bandit_support | 0.59 | 0.39 | 0.20 | 0.32 | 0.30 | 0.13 | 0.17 | 0.03 | 0.00 | 0/3 | 3/3 |
| no_spacing | 0.65 | 0.39 | 0.21 | 0.33 | 0.29 | 0.13 | 0.14 | 0.02 | 0.00 | 0/1 | 3/3 |
| no_remediation | 0.59 | 0.37 | 0.17 | 0.31 | 0.36 | 0.14 | 0.18 | 0 | 0.00 | 0/1 | 3/3 |
| no_transfer | 0.62 | 0.40 | 0.19 | 0.34 | 0.39 | 0.14 | 0.18 | 0.02 | 0.00 | 0/1 | 3/3 |
| fixed_worked_example | 0.62 | 0.41 | 0.20 | 0.35 | 0.38 | 0.14 | 0.18 | 0.02 | 0.00 | 0/3 | 3/3 |
| fixed_retrieval | 0.59 | 0.35 | 0.17 | 0.29 | 0.21 | 0.13 | 0.18 | 0.05 | 0.00 | 0/3 | 3/3 |
| no_memory | 0.36 | 0.39 | 0.34 | 0.32 | 0.63 | 0.37 | 0.10 | 0 | 0.00 | – | 3/3 |
| no_correction | 0.62 | 0.40 | 0.19 | 0.34 | 0.39 | 0.14 | 0.18 | 0.02 | 0.00 | 0/1 | 3/3 |
| no_interleave | 0.60 | 0.42 | 0.21 | 0.35 | 0.32 | 0.14 | 0.23 | 0.02 | 0.00 | 0/3 | 3/3 |
| no_calibration | 0.62 | 0.41 | 0.21 | 0.35 | 0.40 | 0.18 | 0.18 | 0.02 | 0.00 | 0/1 | 3/3 |

By synthetic item structure (full): factual gain 0.59 / retain 0.37 / transfer 0.31 · procedural 0.64 / 0.38 / 0.34 · quantitative 0.57 / 0.38 / 0.32 · discriminative 0.67 / 0.49 / 0.40. The mechanisms behave comparably across structures; this is evidence that the *loop* is structure-agnostic, not that the system handles real subjects equally well.

By archetype (full; gain / retain +7 d / transfer): novice 0.73/0.44/0.39 · knowledgeable 0.49/0.74/0.67 · fast_forgetter 0.62/0.24/0.21 · slow_forgetter 0.69/0.61/0.54 · misconception_prone 0.71/0.46/0.42 · low_transfer 0.68/0.47/**0.21** · overconfident 0.80/0.42/0.38 · example_averse 0.65/0.41/0.36 · hint_seeker 0.43/0.35/0.31 · noisy 0.61/0.37/0.32 · long_gap 0.50/0.25/0.21 · goal_switcher 0.53/0.21/0.17 · corrector 0.57/0.29/0.25.

Selected head-to-heads (gain, retain +7 d):

| archetype | full (rule) | fixed worked example | fixed retrieval | bandit |
| --- | --- | --- | --- | --- |
| novice | 0.73, 0.44 | 0.73, 0.44 | 0.59, 0.35 | 0.50, 0.29 |
| knowledgeable | 0.49, 0.74 | 0.49, 0.74 | 0.45, 0.65 | 0.49, 0.76 |
| example_averse | 0.65, 0.41 | 0.65, 0.41 | 0.56, 0.29 | 0.58, 0.29 |
| hint_seeker | 0.43, 0.35 | 0.47, 0.34 | 0.49, 0.36 | 0.53, 0.42 |

## Reading the results honestly

1. **The evidence loop is the dominant mechanism.** Explain-only reaches gain 0.17 / retention 0.04 / transfer 0.01 and removes no misconceptions; the loop reaches 0.62 / 0.40 / 0.34. This is the expected consequence of a hidden learner in which retrieval, spacing and feedback matter — the point is that the controller extracts it across every archetype, including `noisy`, `long_gap`, `overconfident` and `goal_switcher`. It replicates the archive's mission-attempt result in a new harness with a different hidden model.
2. **Support adaptation by a learned bandit does not beat a good rule.** The bandit is ≤ the rule on gain and retention for 11 of 13 archetypes and dramatically worse for novices (0.50 vs 0.73), because exploration on a signal this noisy (one later binary outcome per decision) costs more than it finds. Even for `example_averse`, where the rule's default is wrong by construction, the rule ties the fixed worked-example policy and beats the bandit: the rule hands over to unaided retrieval as soon as anything is demonstrated, which limits the damage of a wrong default. **Decision: rule by default, bandit kept as a lab condition.** The one place the bandit wins is `hint_seeker` (0.53 vs 0.43) — its exploration happens to include more hint-first turns for a learner who otherwise refuses to attempt; the hint-first-on-tendency rule captures part but not all of this.
3. **Continuity vs coverage — an honest confound.** `no_memory` (the learner model is wiped every session) has the *highest* 30-day retention (0.34 vs 0.19) and the *lowest* gain (0.36 vs 0.62). Without memory the tutor re-teaches the first skills every session, which is near-perfect spaced practice for those skills and nothing for the rest; with memory it moves on. Retention is averaged over all skills including never-taught ones, so the metric rewards depth on a few skills. Continuity's measured value is coverage (+0.26 gain) and model quality (MAE 0.14 vs 0.37); its cost is that the review scheduler at this turn budget cannot keep five skills as durable as a memoryless tutor keeps two. This is a genuine breadth/depth trade-off the product should expose (it does, via next-review estimates), not a bug — but it does mean **our scheduler is not yet strong enough to dominate on retention**.
4. **Spacing scheduler: small to neutral.** `no_spacing` (reviews chosen at random 15% of the time) matches `full` within noise on every learning metric. In a loop where almost every turn is a retrieval event, the scheduler only changes *which* skill is retrieved. It is kept because it is what makes "is it fading?" answerable in the product, its cost is ≈0, and the archive found the same.
5. **Remediation: small.** In the full cohort +0.03 gain / +0.03 retention; in a targeted 8-seed cohort (`misconception_prone, example_averse, novice`) +0.05 / +0.05. Residual misconceptions are within noise in both (refutation-in-feedback already removes most tagged errors). Kept: it is the only mechanism that names a persistent error to the learner.
6. **Transfer stage: neutral** — because ordinary practice already rotates through unseen apply contexts, transfer evidence accrues without a dedicated activity (transfers/turn 0.01). The *measurement* (new-context successes) is what matters and is present in every condition except `no_transfer`, where it simply is not collected.
7. **Interleaving, calibration: neutral on learning.** Calibration does what it claims for the model (MAE 0.14 vs 0.18); interleaving raises review rate slightly without a learning effect at this horizon.
8. **Correction.** The lab metric is weak this run (0/1: in two seeds the stated preference had already been *retired by contradicting outcomes* before session 2 — the evidence mechanism pre-empted the correction). The discriminating test is in the adversarial suite: with the mechanism the corrected belief is retired, kept as history, not re-parsed, and not recreated; without it, it survives.
9. **Memory hygiene.** Zero false active preference beliefs in every condition after removing outcome-derived "preferences"; live beliefs ≈1–2 per learner; 300 noisy turns leave ≤ 8 live beliefs; confidence capped.
10. **Model calibration.** Mean absolute error of predicted vs hidden recall at +7 d is 0.14 with memory (0.07 for explain-only, trivially: it predicts ≈0 and the learner knows ≈0). Worst for `knowledgeable`/`slow_forgetter` (0.21–0.22): the prior half-life is too short for learners who already know things; calibration narrows but does not close this in six sessions.

## Adversarial suite (32/32)

Correction attack (retired · provenance kept · not parsed as answer · acknowledged · not recreated · ablation control) · stale item across sessions never graded · every attempt references its posing tutor turn · self-report is a claim → `verify_claim`; demonstrated evidence overrides it · tagged repeated error → remediation names the misconception → resolves after correct answers · answer-seeking tendency → hint before answer → correction retires it · goal switch keeps old evidence, "back to X" reactivates · 90-day gap: new session, goal and states survive, tutor reviews · 300 noisy turns bounded · support outcomes reference the supporting turn/skill/support · temporary context expires · unknown goal → scaffold with honest message → notes become items · content cache carries no learner id · explain-only creates zero attempts · open-ended item → reference + self-grade recorded as its own channel.

## Unit tests (10)

Memory update rules (aided vs unaided, spaced vs massed cap, lapse), decay and per-learner scale, claim-as-prior and discrepancy, status thresholds incl. transfer requirement, calibration bounds, graders and error tags, perception (goals, corrections, requests, self-reports, self-grades, "back to", questions vs answers), belief lifecycle (thresholds, contest, retire, correction guard, supersession), content validation and scaffold.

## What the synthetic learner is and is not

It is a set of rules chosen to reflect the direction of published effects (testing, spacing, expertise reversal, pretesting, refutation, varied practice). Its constants are guesses. A tutor tuned to it would be over-fitted; we therefore did **not** tune the tutor's memory constants to match it beyond fixing clear bugs (massed inflation), and we report model MAE against it as a diagnostic, not a score. It cannot tell us about motivation, attention, language, or whether generated content is any good. Every number above is a statement about the controller under those rules.

## What a human study would need (not done)

Randomise learners between `full` and `explain_only` via `Ablation`; measure delayed (≥7 d) unaided recall and a novel-context task per skill; log the correction rate and whether corrected beliefs recur; compare the tutor's predicted recall against observed spaced outcomes (the calibration data is already recorded in `attempts.p_recall_before`). All of this is recorded by the current schema.

## Reproducing

```
npm test
npm run adversarial
npm run lab                                     # 3 seeds, all conditions → lab/out/summary.{json,md}
npx tsx scripts/lab/run.ts --seeds=8 --archetypes=misconception_prone,example_averse,novice --conditions=full,no_remediation,bandit_support,fixed_retrieval
npx tsx scripts/lab/debug.ts hint_seeker full discriminative 6
```
