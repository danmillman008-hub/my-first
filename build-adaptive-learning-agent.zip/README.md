# Private Self-Adapting Learning Agent

**One learner. One continuous relationship. A tutor that gets better at helping *you* learn, from evidence.**

You say what you want to learn in your own words — "I want to learn the basics of photosynthesis", "help me get better at Spanish subjunctive", "teach me TCP handshakes", or paste your own notes. The agent builds practice material, makes you *retrieve* rather than re-read, brings things back as its model predicts they are fading, varies the context so knowledge transfers, notices persistent misconceptions and confronts them, and keeps a private, inspectable, **correctable** model of you: what you can demonstrate (separately from what you say), how fast you forget, what you tend to do, and what it should do next.

This repository is the result of an autonomous investigation described in [docs/ARCHIVE_FORENSICS.md](docs/ARCHIVE_FORENSICS.md) (what 16 previous attempts got right and wrong), [docs/RESEARCH.md](docs/RESEARCH.md) (the learning-science and AI evidence used), [docs/DECISIONS.md](docs/DECISIONS.md) (what was built, rejected and why) and [docs/EVALUATION.md](docs/EVALUATION.md) (what the lab measured, honestly).

---

## The two problems, kept apart

| | Teaching adaptation | Learning outcome |
| --- | --- | --- |
| Question | What should the tutor do for *this* learner right now? | Is the learner actually more capable? |
| Evidence in this system | stated preferences, explicit requests, inferred tendencies, outcome statistics after each kind of support | graded attempts: unaided vs aided, spaced vs massed, familiar vs novel context, error signatures |
| Where it lives | `beliefs`, `supportCredits`/`arms`, decision reasons | `states` (per-skill memory model), `attempts` (append-only), `errors` |
| How the lab measures it | support match, false beliefs, correction recreation | hidden knowledge gain, retention at +7/+30 d, transfer, misconceptions left, model calibration |

The lab shows the two can move in opposite directions: an explain-only tutor produces near-zero learning while looking fine conversationally (see EVALUATION). Nothing in this system treats "that makes sense" as evidence of capability.

## Architecture

```
learner message
  → session      inferred from a 45-min gap; stale open items are never attributed to a new session
  → perceive     deterministic flags: goal · answer · self-report · request · correction · question · notes · context
  → grade        the item posed by the previous tutor turn, by id (mechanical graders; LLM or self-grade for open answers)
  → update       per-skill memory (pKnown + half-life), per-learner forgetting calibration, error patterns, beliefs
  → attribute    the earlier support decision is credited only by the FIRST LATER UNAIDED attempt on the same skill
  → decide       remediate ▸ verify claim ▸ review due (predicted recall < 0.85) ▸ transfer ▸ practice ▸ teach   (+ interleaving)
  → compose      templates; an optional model answers questions and grades open answers — it never decides
  → trace        observed · graded · attribution · model changes · decision + alternatives  (UI "Why this turn")
```

| Layer | Path | Responsibility |
| --- | --- | --- |
| Types / content contract | `src/lib/core/types.ts` | `Skill` + `Item` (prompt, reference, grader, variant, error tags). **No subject knowledge anywhere in the core.** |
| Memory model | `src/lib/core/memory.ts` | `p_recall = pKnown · 2^(−Δt / (stability · learnerScale))`; unaided/aided, spaced/massed, novel-context weighting; status `new → learning → review → secure`; claim-vs-behaviour discrepancy; per-learner calibration |
| Beliefs | `src/lib/core/beliefs.ts` | `candidate → active → contested → retired`, capped confidence, provenance edges, correction with supersession + 14-day re-derivation guard, read-time influence (recency, scope); Beta/Thompson support bandit (lab-only) |
| Perception + grading | `src/lib/core/perceive.ts` | natural-language flags (never classifies the person); graders `exact / keywords / numeric / choice / self`; error-tag matching |
| Engine | `src/lib/core/engine.ts` | the loop above; `turn()`, `load()`, `correct()` |
| Content | `src/lib/content/index.ts` | goal → plan: **LLM** (validated JSON) → **Wikipedia** (sections → cloze/free-recall/transfer items) → **learner notes** → **scaffold** (self-graded prompts that work for any goal). Cached by topic only. |
| Store | `src/lib/core/store.ts` (interface + in-memory), `src/lib/store/pg.ts` (Drizzle) | one mutable learner document + append-only `turns / observations / attempts / support_outcomes`; `content_cache` has no learner id |
| Provider | `src/lib/providers/llm.ts` | optional OpenAI-compatible `fetch` with timeouts; every failure falls back |
| HTTP / UI | `src/app/api/{chat,learner,health}`, `src/components/Tutor.tsx` | chat; model inspection, belief correction, export, erase |
| Lab | `scripts/lab/{sim,run,adversarial,debug}.ts` | hidden-ground-truth synthetic learners, ablations, adversarial regression suite |
| Tests | `tests/core.test.ts` | pure-core unit tests |

### What is general and what is not

The loop, the memory model, the belief layer, attribution, correction and the evaluation are subject-agnostic: they operate on skills and items. What *depends on a content source* is the quality of explanations and items:

- with a language model configured: generated skill decomposition, misconception-tagged items, open-answer grading, question answering;
- without one: Wikipedia-derived cloze / free-recall / transfer prompts for any topic it covers, learner-supplied notes turned into items, and — for anything else — a scaffold of self-graded retrieval prompts plus an honest statement that the tutor has no reference material.

The agent tells the learner which source it is using. It never pretends to know a subject it has no material for.

### Learner model: epistemics

- **Said vs demonstrated.** Self-reports set `basis = claimed` and a prior only when nothing has been demonstrated; they schedule a `verify_claim` item; they never override attempts. A durable gap between claims and performance becomes an inferred *tendency* belief (overestimates / underestimates), itself contestable.
- **Aided vs unaided.** A correct answer after a hint or worked example counts half as much as an unaided one; only unaided successes count towards `review`/`secure`.
- **Time.** Stability (half-life) only grows meaningfully from *spaced* successes (massed repetitions are capped at a 3-day half-life until one spaced success occurs). Predicted recall decays continuously; a per-learner forgetting scale is fitted from spaced outcomes (bounded 0.4–2.5).
- **Transfer.** Success on an apply/transfer item in a context the learner has not seen is recorded separately; `secure` requires at least one.
- **Beliefs** carry source (stated/inferred), status, confidence (capped 0.92), support/contradiction counts, sessions, scope (this goal / general), evidence edges, validity interval, invalidation reason and successor. Inferred beliefs need ≥2 supports across ≥2 sessions (or ≥3). Temporary context ("I'm tired") expires within hours.
- **Outcome statistics are not beliefs.** "After worked examples the next unaided attempt succeeded 4/6 times" is shown as a statistic, attributed by rule, and never promoted to a "preference" (an earlier version did, and it was self-reinforcing).

### Attribution rules (tested in `scripts/lab/adversarial.ts`)

1. An attempt is graded only against the item posed by the previous tutor turn, by id. The first message of a new session is never graded against a week-old item.
2. Support (worked example / hint / retrieval-first) is credited by the **first later unaided** attempt on the same skill — not by the immediate aided attempt (performance ≠ learning). Weight 0.6 across sessions, ×0.3 if the skill was already likely known, ×0.3 after 30 days.
3. A learner correction retires the belief immediately, keeps the evidence, resets the related support statistics, and blocks re-derivation from pre-correction evidence for 14 days. The correction sentence is never parsed as an answer or request.
4. Repeated *tagged* wrong answers (2×) or identical untagged wrong answers (3×) become an active error pattern → a discriminating item with the refutation; it resolves after two correct attempts.

## Running

```bash
npm install
# .env: DATABASE_URL=postgresql://...   (optional) OPENAI_API_KEY=..., OPENAI_BASE_URL=..., OPENAI_MODEL=...
npx drizzle-kit push
npm run dev
```

Without a model key the app runs fully offline apart from optional Wikipedia lookups (topic only, never learner data).

```bash
npm test               # 10 pure-core unit tests
npm run adversarial    # 32 regression checks against the real engine
npm run lab            # 3 seeds × 13 archetypes × 12 conditions, writes lab/out/summary.{json,md}
npm run debug novice full factual 4   # turn-by-turn trace of one synthetic learner
```

## Privacy

- Identity is a random `httpOnly` cookie; no accounts, no telemetry, no analytics.
- All learner data lives in the local Postgres database; **Export everything** and **Delete everything** are one click in the Privacy tab.
- If a model provider is configured, single turns are sent (topic, item, answer, question). The learner model — beliefs, states, history — is never sent.
- World knowledge (`content_cache`) is keyed by topic and carries no learner identifier.

## Status — what has and has not been shown

| Claim | Status |
| --- | --- |
| Core invariants: attribution, session boundaries, claim vs behaviour, correction (retire, guard, no recreation), belief caps, context expiry, scaffold for unknown goals, notes → items, cache isolation | **unit- and adversarially tested** |
| The evidence loop produces learning where retrieval, spacing, feedback and refutation matter: gain 0.62 vs 0.17, retention +7 d 0.40 vs 0.04, transfer 0.34 vs 0.01 against an explain-only tutor | **simulated, ablated** (synthetic learners; not humans) |
| Continuity (memory across sessions) improves coverage (gain 0.62 vs 0.36) and model quality (MAE 0.14 vs 0.37) | **simulated** — with an honest confound: a memoryless tutor re-drills the first skills and retains *those* better (see EVALUATION) |
| Rule-based support (worked example for novices → retrieval once demonstrated) ≥ a learned support bandit on every learning metric | **simulated, ablated** — replicates the archive's finding |
| Remediation of persistent misconceptions: +0.05 gain / +0.05 retention in a targeted cohort; residual-misconception effect within noise | **simulated, weak** |
| Spacing scheduler, interleaving, calibration, explicit transfer stage | **simulated: neutral to small** at this horizon (documented, kept because cheap and observable) |
| Any effect on real human learning, retention, transfer or satisfaction; quality of model-generated pedagogy; correctness of LLM grading | **not demonstrated** |

See [docs/EVALUATION.md](docs/EVALUATION.md) for the full tables and the limitations of the synthetic learner.
