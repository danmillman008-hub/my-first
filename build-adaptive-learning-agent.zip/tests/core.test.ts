import { test } from "node:test";
import assert from "node:assert/strict";
import { applyAttempt, applyClaim, calibrate, claimDiscrepancy, deriveStatus, newSkillState, pRecall } from "../src/lib/core/memory";
import { grade, perceive } from "../src/lib/core/perceive";
import { correctBelief, supportBelief, contradictBelief, beliefInfluence, mulberry32 } from "../src/lib/core/beliefs";
import { scaffoldPlan, validatePlan, sentences } from "../src/lib/content";
import type { Item, LearnerModel } from "../src/lib/core/types";

const now = new Date("2025-03-01T10:00:00Z");
const later = (days: number) => new Date(now.getTime() + days * 86_400_000);
const item = (over: Partial<Item> = {}): Item => ({ id: "i1", skillId: "s1", kind: "recall", prompt: "?", answer: "stdout", grader: { kind: "keywords", accept: ["stdout", "standard output"] }, hint: null, variant: "v1", errorTags: [{ match: ["stderr"], label: "confuses stderr with stdout", refutation: "stderr is separate" }], source: "llm", ...over });
const blankModel = (): LearnerModel => ({ id: "l", createdAt: now.toISOString(), lastSeenAt: null, currentSessionId: "s", sessionStartedAt: null, forgettingScale: 1, calibrationN: 0, goals: [], skills: [], items: [], states: {}, errors: [], beliefs: [], arms: {}, pending: null, supportCredits: {}, recentSkillIds: [], turnCount: 0 });

test("memory: unaided success raises pKnown, spaced success grows stability, failure shrinks it", () => {
  let s = newSkillState("s1");
  const r1 = applyAttempt(s, { correct: true, kind: "recall", helpGiven: false, isNovel: false, variant: "v1", support: null, pBefore: 0.1, now });
  s = r1.state;
  assert.ok(s.pKnown > 0.4 && s.basis === "demonstrated");
  assert.ok(s.stability <= 3, "no spaced success yet → half-life capped at 3 days");
  const r2 = applyAttempt(s, { correct: true, kind: "recall", helpGiven: false, isNovel: false, variant: "v1", support: null, pBefore: 0.5, now: later(3) });
  assert.ok(r2.state.stability > s.stability * 1.5, "spaced success grows stability substantially");
  assert.equal(r2.state.spacedSuccesses, 1);
  const r3 = applyAttempt(r2.state, { correct: false, kind: "recall", helpGiven: false, isNovel: false, variant: "v1", support: null, pBefore: 0.3, now: later(10) });
  assert.ok(r3.state.stability < r2.state.stability);
});

test("memory: aided success is weaker evidence than unaided", () => {
  const s = newSkillState("s1");
  const aided = applyAttempt(s, { correct: true, kind: "recall", helpGiven: true, isNovel: false, variant: "v", support: "worked_example_first", pBefore: 0.1, now }).state;
  const unaided = applyAttempt(s, { correct: true, kind: "recall", helpGiven: false, isNovel: false, variant: "v", support: null, pBefore: 0.1, now }).state;
  assert.ok(aided.pKnown < unaided.pKnown);
  assert.equal(aided.unaidedSuccesses, 0);
});

test("memory: predicted recall decays with time and is scaled per learner", () => {
  const s = applyAttempt(newSkillState("s1"), { correct: true, kind: "recall", helpGiven: false, isNovel: false, variant: "v", support: null, pBefore: 0.1, now }).state;
  const p0 = pRecall(s, now, 1);
  const p5 = pRecall(s, later(5), 1);
  const p5slow = pRecall(s, later(5), 2);
  assert.ok(p5 < p0 && p5slow > p5);
});

test("memory: a claim sets a prior only when nothing is demonstrated and never overrides behaviour", () => {
  const claimed = applyClaim(newSkillState("s1"), 0.9, now).state;
  assert.equal(claimed.basis, "claimed");
  assert.ok(claimed.pKnown <= 0.7);
  let s = newSkillState("s1");
  for (let i = 0; i < 3; i++) s = applyAttempt(s, { correct: false, kind: "recall", helpGiven: false, isNovel: false, variant: "v", support: null, pBefore: 0.1, now }).state;
  const after = applyClaim(s, 0.9, now).state;
  assert.equal(after.basis, "demonstrated");
  assert.equal(after.pKnown, s.pKnown);
  assert.ok((claimDiscrepancy(after) ?? 0) > 0.4, "durable overclaim is detected");
});

test("memory: status requires unaided, spaced and new-context evidence to become secure", () => {
  let s = newSkillState("s1");
  for (let d = 0; d < 6; d++) s = applyAttempt(s, { correct: true, kind: d === 5 ? "apply" : "recall", helpGiven: false, isNovel: d === 5, variant: `v${d}`, support: null, pBefore: 0.4, now: later(d * 2) }).state;
  assert.equal(deriveStatus(s), "secure");
  const noTransfer = { ...s, transferSuccesses: 0, status: "review" as const };
  assert.equal(deriveStatus(noTransfer), "review");
});

test("calibration moves the forgetting scale towards observed outcomes and stays bounded", () => {
  let c = { scale: 1, n: 0 };
  for (let i = 0; i < 20; i++) c = calibrate(c.scale, c.n, 0.3, true);
  assert.ok(c.scale > 1.3 && c.scale <= 2.5);
  for (let i = 0; i < 60; i++) c = calibrate(c.scale, c.n, 0.9, false);
  assert.ok(c.scale >= 0.4);
});

test("grading: keywords, numeric tolerance, choice letters, error tags, don't-know", () => {
  assert.equal(grade(item(), "it goes to standard output", false).correct, true);
  assert.equal(grade(item(), "the stdout stream", false).correct, true);
  const wrong = grade(item(), "I think it is stderr", false);
  assert.equal(wrong.correct, false);
  assert.equal(wrong.errorLabel, "confuses stderr with stdout");
  assert.equal(grade(item({ grader: { kind: "numeric", value: 3.14, tolerance: 0.01 } }), "about 3.141", false).correct, true);
  assert.equal(grade(item({ grader: { kind: "numeric", value: 3.14, tolerance: 0.01 } }), "3.2", false).correct, false);
  const choice = item({ grader: { kind: "choice", options: ["stdout", "stderr", "stdin"], correct: 0 } });
  assert.equal(grade(choice, "a", false).correct, true);
  assert.ok(grade(choice, "b)", false).errorSignature?.startsWith("tag:"), "a tagged distractor maps to its misconception");
  assert.equal(grade(choice, "c", false).errorSignature, "choice:2");
  assert.equal(grade(item(), "no idea", true).errorSignature, "dont_know");
  assert.equal(grade(item({ grader: { kind: "self" } }), "anything", false).needsSelfGrade, true);
});

test("perception: goals, corrections, requests, self-reports, answers", () => {
  const g = perceive("I'd like to learn how to make sourdough bread", { hasPending: false, awaitingSelfGrade: false, hasGoal: false });
  assert.equal(g.goal, "how to make sourdough bread");
  const free = perceive("sailing knots", { hasPending: false, awaitingSelfGrade: false, hasGoal: false });
  assert.equal(free.goal, "sailing knots");
  const c = perceive("That's not true about me, I don't prefer examples. Actually I like to try first", { hasPending: true, awaitingSelfGrade: false, hasGoal: true });
  assert.ok(c.correction && c.correction.replacement?.includes("try first"));
  assert.equal(c.isAnswer, false, "a correction is never parsed as an answer");
  const a = perceive("done", { hasPending: true, awaitingSelfGrade: false, hasGoal: true });
  assert.equal(a.isAnswer, true);
  const h = perceive("hint please?", { hasPending: true, awaitingSelfGrade: false, hasGoal: true });
  assert.equal(h.request, "hint");
  const sr = perceive("I'm a complete beginner", { hasPending: false, awaitingSelfGrade: false, hasGoal: true });
  assert.ok(sr.selfReport && sr.selfReport.level < 0.3);
  const sg = perceive("partly, I missed the second half", { hasPending: true, awaitingSelfGrade: true, hasGoal: true });
  assert.equal(sg.selfGrade, "partly");
  const back = perceive("back to sailing knots", { hasPending: false, awaitingSelfGrade: false, hasGoal: true });
  assert.equal(back.goal, "sailing knots");
  const q = perceive("Why does the dough need to rest before shaping?", { hasPending: true, awaitingSelfGrade: false, hasGoal: true });
  assert.equal(q.isQuestion, true);
  assert.equal(q.isAnswer, false);
});

test("beliefs: inferred needs cross-session support; contradiction contests then retires; correction retires and guards", () => {
  const m = blankModel();
  const rnd = mulberry32(1);
  supportBelief(m, { kind: "tendency", key: "t", statement: "x", source: "inferred", scope: null, observationId: "o1", sessionId: "s1", now, rnd });
  assert.equal(m.beliefs[0].status, "candidate");
  supportBelief(m, { kind: "tendency", key: "t", statement: "x", source: "inferred", scope: null, observationId: "o2", sessionId: "s2", now: later(1), rnd });
  assert.equal(m.beliefs[0].status, "active");
  assert.ok(m.beliefs[0].confidence <= 0.92);
  contradictBelief(m, "t", null, "o3", later(2));
  assert.equal(m.beliefs[0].status, "contested");
  contradictBelief(m, "t", null, "o4", later(3));
  assert.equal(m.beliefs[0].status, "retired");
  assert.equal(m.beliefs[0].invalidReason, "contradicted_by_evidence");
  // correction + guard
  const m2 = blankModel();
  supportBelief(m2, { kind: "preference", key: "p", statement: "likes examples", source: "inferred", scope: null, observationId: "a", sessionId: "s1", now, rnd });
  supportBelief(m2, { kind: "preference", key: "p", statement: "likes examples", source: "inferred", scope: null, observationId: "b", sessionId: "s2", now, rnd });
  correctBelief(m2, m2.beliefs[0].id, "corr", now, { statement: "prefers to try first", kind: "preference", key: "p2" });
  assert.equal(m2.beliefs[0].status, "retired");
  assert.equal(m2.beliefs[0].invalidReason, "learner_correction");
  assert.equal(m2.beliefs[0].supersededBy, m2.beliefs[1].id);
  assert.equal(beliefInfluence(m2.beliefs[0], now, null), 0);
  const ch = supportBelief(m2, { kind: "preference", key: "p", statement: "likes examples", source: "inferred", scope: null, observationId: "c", sessionId: "s3", now: later(1), rnd });
  assert.ok(ch[0].includes("guard"), "pre-guard evidence cannot recreate the corrected belief");
  assert.equal(m2.beliefs.filter((b) => b.key === "p").length, 1);
});

test("content: validation rejects malformed model output, scaffold works for any goal, sentences split", () => {
  let n = 0;
  const id = (p: string) => `${p}${n++}`;
  assert.equal(validatePlan({ skills: [{ name: "", items: [] }] }, "g", "g1", "llm", "x", id), null);
  const ok = validatePlan({ topic: "T", skills: [{ name: "A", explanation: "e", items: [{ prompt: "q", answer: "a", grader: { kind: "keywords", accept: ["a"] } }, { prompt: "bad", grader: { kind: "choice", options: ["x"], correct: 5 } }] }] }, "g", "g1", "llm", "x", id);
  assert.ok(ok && ok.items.length === 1);
  const sc = scaffoldPlan("underwater basket weaving", "g1", id);
  assert.ok(sc.items.length >= 4 && sc.items.every((i) => i.grader.kind === "self"));
  assert.ok(sentences("First sentence is here and long enough. Second one follows it nicely and is long. Short.").length === 2);
});
