// Benchmark + ablations. Usage:
//   npx tsx scripts/lab/run.ts --seeds=3 --sessions=6 --turns=10 --conditions=full,explain_only
// Writes lab/out/summary.json and lab/out/summary.md.

import { mkdirSync, writeFileSync } from "node:fs";
import { ARCHETYPES, CONDITIONS, DOMAIN_TYPES, mean, runLearner, type Report } from "./sim";

const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, "").split("=")).map(([k, v]) => [k, v ?? "true"]));
const seeds = Number(args.seeds ?? 2);
const sessions = Number(args.sessions ?? 6);
const turns = Number(args.turns ?? 10);
const nSkills = Number(args.skills ?? 5);
const conds = args.conditions ? CONDITIONS.filter((c) => args.conditions.split(",").includes(c.name)) : CONDITIONS;
const archs = args.archetypes ? ARCHETYPES.filter((a) => args.archetypes.split(",").includes(a.name)) : ARCHETYPES;

async function main() {
  const t0 = Date.now();
  const reports: Report[] = [];
  for (let seed = 1; seed <= seeds; seed++) {
    for (const cond of conds) {
      for (const arch of archs) {
        // each archetype rotates through domain types so every condition sees every structure
        const domain = DOMAIN_TYPES[(seed + ARCHETYPES.indexOf(arch)) % DOMAIN_TYPES.length];
        reports.push(await runLearner(arch, cond, domain, { sessions, turnsPerSession: turns, seed, nSkills }));
      }
    }
  }
  const secs = (Date.now() - t0) / 1000;
  const rows = conds.map((c) => {
    const rs = reports.filter((r) => r.condition === c.name);
    const corr = rs.filter((r) => r.correctionRecreated != null);
    const cont = rs.filter((r) => r.goalContinuity != null);
    const sm = rs.filter((r) => r.supportMatch != null);
    return {
      condition: c.name,
      n: rs.length,
      gain: mean(rs.map((r) => r.gain)),
      retain7: mean(rs.map((r) => r.retain7)),
      retain30: mean(rs.map((r) => r.retain30)),
      transfer7: mean(rs.map((r) => r.transfer7)),
      miscLeft: mean(rs.filter((r) => r.miscInitial > 0).map((r) => r.miscLeft)),
      calibrationMAE: mean(rs.map((r) => r.calibrationMAE)),
      supportMatch: sm.length ? mean(sm.map((r) => r.supportMatch!)) : null,
      itemsPerTurn: mean(rs.map((r) => r.itemsPosed / r.turns)),
      reviewsPerTurn: mean(rs.map((r) => r.reviews / r.turns)),
      transfersPerTurn: mean(rs.map((r) => r.transfers / r.turns)),
      remediationsPerTurn: mean(rs.map((r) => r.remediations / r.turns)),
      activeBeliefs: mean(rs.map((r) => r.activeBeliefs)),
      falseBeliefs: mean(rs.map((r) => r.falseBeliefs)),
      correctionRecreated: corr.length ? `${corr.filter((r) => r.correctionRecreated).length}/${corr.length}` : "–",
      goalContinuity: cont.length ? `${cont.filter((r) => r.goalContinuity).length}/${cont.length}` : "–",
      msPerTurn: mean(rs.map((r) => r.msPerTurn)),
    };
  });
  const byArch = archs.map((a) => {
    const rs = reports.filter((r) => r.archetype === a.name && r.condition === "full");
    return { archetype: a.name, gain: mean(rs.map((r) => r.gain)), retain7: mean(rs.map((r) => r.retain7)), transfer7: mean(rs.map((r) => r.transfer7)), miscLeft: mean(rs.filter((r) => r.miscInitial > 0).map((r) => r.miscLeft)), supportMatch: mean(rs.filter((r) => r.supportMatch != null).map((r) => r.supportMatch!)), calibrationMAE: mean(rs.map((r) => r.calibrationMAE)) };
  });
  const byDomain = DOMAIN_TYPES.map((d) => {
    const rs = reports.filter((r) => r.domain === d && r.condition === "full");
    return { domain: d, n: rs.length, gain: mean(rs.map((r) => r.gain)), retain7: mean(rs.map((r) => r.retain7)), transfer7: mean(rs.map((r) => r.transfer7)), miscLeft: mean(rs.filter((r) => r.miscInitial > 0).map((r) => r.miscLeft)) };
  });
  const f = (x: number | null) => (x == null ? "–" : x.toFixed(2));
  const md: string[] = [];
  md.push(`# Lab summary\n\n${seeds} seeds × ${archs.length} archetypes × ${conds.length} conditions × ${sessions} sessions × ${turns} turns = ${reports.reduce((a, r) => a + r.turns, 0)} turns in ${secs.toFixed(1)} s.\n`);
  md.push(`| condition | gain | retain +7d | retain +30d | transfer +7d | misc. left | model MAE | support match | items/turn | reviews/turn | transfers/turn | remed./turn | active beliefs | false beliefs | corr. recreated | goal continuity |`);
  md.push(`| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |`);
  for (const r of rows) md.push(`| ${r.condition} | ${f(r.gain)} | ${f(r.retain7)} | ${f(r.retain30)} | ${f(r.transfer7)} | ${f(r.miscLeft)} | ${f(r.calibrationMAE)} | ${f(r.supportMatch)} | ${f(r.itemsPerTurn)} | ${f(r.reviewsPerTurn)} | ${f(r.transfersPerTurn)} | ${f(r.remediationsPerTurn)} | ${f(r.activeBeliefs)} | ${f(r.falseBeliefs)} | ${r.correctionRecreated} | ${r.goalContinuity} |`);
  md.push(`\n## full condition by archetype\n\n| archetype | gain | retain +7d | transfer +7d | misc. left | support match | model MAE |\n| --- | --- | --- | --- | --- | --- | --- |`);
  for (const r of byArch) md.push(`| ${r.archetype} | ${f(r.gain)} | ${f(r.retain7)} | ${f(r.transfer7)} | ${f(r.miscLeft)} | ${f(r.supportMatch)} | ${f(r.calibrationMAE)} |`);
  md.push(`\n## full condition by synthetic item structure\n\n| structure | n | gain | retain +7d | transfer +7d | misc. left |\n| --- | --- | --- | --- | --- | --- |`);
  for (const r of byDomain) md.push(`| ${r.domain} | ${r.n} | ${f(r.gain)} | ${f(r.retain7)} | ${f(r.transfer7)} | ${f(r.miscLeft)} |`);
  mkdirSync("lab/out", { recursive: true });
  writeFileSync("lab/out/summary.json", JSON.stringify({ config: { seeds, sessions, turns, nSkills, conditions: conds.map((c) => c.name), archetypes: archs.map((a) => a.name), seconds: secs }, conditions: rows, byArchetype: byArch, byDomain, reports }, null, 2));
  writeFileSync("lab/out/summary.md", md.join("\n") + "\n");
  console.log(md.join("\n"));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
