// Adversarial regression suite against the real engine (in-memory store, no network).
// Each check is a failure mode found in this project or in the archive of previous attempts.
import { Engine } from "../../src/lib/core/engine";
import { InMemoryStore } from "../../src/lib/core/store";
import { topicKey } from "../../src/lib/content";
import { syntheticPlan } from "./sim";

let pass = 0, fail = 0;
function check(name: string, ok: boolean, detail = "") {
  if (ok) pass++; else fail++;
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail && !ok ? ` — ${detail}` : ""}`);
}

const DAY = 86_400_000;
async function setup(opts: { ablation?: ConstructorParameters<typeof Engine>[0]["ablation"] } = {}) {
  const store = new InMemoryStore();
  let n = 0;
  const id = (p: string) => `${p}_${n++}`;
  const { plan } = syntheticPlan("widget theory", "factual", 3, id);
  await store.content.put(`goal:${topicKey("widget theory")}`, plan);
  const engine = new Engine({ store, llm: null, fetchImpl: null, seed: 7, ablation: opts.ablation });
  let t = Date.UTC(2025, 2, 1, 9, 0, 0);
  const say = async (msg: string, advanceMs = 60_000) => {
    const r = await engine.turn("adv", msg, new Date(t));
    t += advanceMs;
    return r;
  };
  return { store, engine, say, skip: (ms: number) => { t += ms; }, now: () => t };
}

async function main() {
  // 1. Correction attack: belief retired, evidence kept, sentence not parsed as an answer, not recreated from old evidence, arms reset.
  {
    const { engine, say } = await setup();
    await say("I want to learn widget theory");
    await say("I learn best from worked examples");
    let m = await engine.load("adv");
    const pref = m.beliefs.find((b) => b.key === "preference:support:worked_example_first");
    check("stated preference becomes an active belief", !!pref && pref.status === "active");
    const before = m.pending?.itemId;
    const r = await say("That's not true about me. I don't learn best from worked examples.");
    m = await engine.load("adv");
    const retired = m.beliefs.find((b) => b.key === "preference:support:worked_example_first");
    check("correction retires the belief and keeps provenance", !!retired && retired.status === "retired" && retired.invalidReason === "learner_correction" && retired.evidence.some((e) => e.relation === "correction"));
    check("correction sentence is not graded as an answer", r.trace.graded === null && m.pending?.itemId === before);
    check("reply acknowledges the correction", /retired the assumption/i.test(r.reply));
    await say("key0");
    await say("key0");
    m = await engine.load("adv");
    check("corrected belief not recreated by later turns", !m.beliefs.some((b) => b.key === "preference:support:worked_example_first" && b.status !== "retired"));
  }
  // 2. Correction ablation: without the mechanism the belief survives.
  {
    const { engine, say } = await setup({ ablation: { noCorrection: true } });
    await say("I want to learn widget theory");
    await say("I learn best from worked examples");
    await say("That's not true about me.");
    const m = await engine.load("adv");
    check("ablation control: belief survives without the correction mechanism", m.beliefs.some((b) => b.key === "preference:support:worked_example_first" && b.status === "active"));
  }
  // 3. Stale pending item across a session boundary is never attributed.
  {
    const { engine, say, skip } = await setup();
    await say("I want to learn widget theory");
    const m1 = await engine.load("adv");
    check("an item is pending after the first turn", !!m1.pending);
    skip(3 * DAY);
    const r = await say("key0");
    check("first message of a new session is not graded against a stale item", r.trace.graded === null && r.trace.attribution.some((a) => a.includes("stale")));
  }
  // 4. Every graded attempt references the exact tutor turn that posed the item.
  {
    const { engine, say, store } = await setup();
    await say("I want to learn widget theory");
    for (let i = 0; i < 6; i++) await say(i % 2 ? "key0" : "I think mis0");
    const atts = await store.attempts("adv");
    const turns = await store.recentTurns("adv", 100);
    const ok = atts.every((a) => turns.some((tt) => tt.id === a.tutorTurnId && tt.role === "tutor" && tt.itemId === a.itemId));
    check("all attempts reference the posing tutor turn by id", ok && atts.length >= 5);
    void engine;
  }
  // 5. Self-report is a claim, not evidence; it schedules verification; behaviour wins.
  {
    const { engine, say } = await setup();
    await say("I want to learn widget theory");
    await say("skip");
    const r = await say("I already know all of this");
    const m = await engine.load("adv");
    const claimed = Object.values(m.states).filter((s) => s.basis === "claimed");
    check("claim sets basis=claimed on undemonstrated skills", claimed.length >= 1);
    check("tutor verifies the claim instead of trusting it", r.trace.decision.activity === "verify_claim" || m.pending?.purpose === "verify_claim");
    // fail the verification repeatedly → overestimation tendency appears, demonstrated basis wins
    for (let i = 0; i < 4; i++) await say("I think other9");
    const m2 = await engine.load("adv");
    const st = Object.values(m2.states).find((s) => s.claimedLevel != null && s.attempts >= 3);
    check("demonstrated evidence overrides the claim", !!st && st.basis === "demonstrated" && st.pKnown < 0.4);
  }
  // 6. Persistent misconception → remediation with refutation; resolves after correct answers.
  {
    const { engine, say } = await setup();
    await say("I want to learn widget theory");
    let remediated = false;
    for (let i = 0; i < 8 && !remediated; i++) {
      const r = await say("I think mis0");
      if (r.trace.decision.activity === "remediate") remediated = true;
    }
    const m = await engine.load("adv");
    check("tagged wrong answer repeated → remediation with the misconception named", remediated && m.errors.some((e) => e.label === "misconception 0" && e.status === "active"));
    for (let i = 0; i < 4; i++) await say("key0");
    const m2 = await engine.load("adv");
    check("error pattern resolves after correct answers", m2.errors.some((e) => e.label === "misconception 0" && e.status === "resolved"));
  }
  // 7. Crutch tendency: repeated "just tell me" → hint first instead of the answer; correction reverses it.
  {
    const { engine, say } = await setup();
    await say("I want to learn widget theory");
    let hinted = false;
    for (let i = 0; i < 8 && !hinted; i++) {
      const r = await say("just tell me the answer");
      if (r.trace.decision.activity === "help" && /nudge first/i.test(r.reply)) hinted = true;
      else await say("key0");
    }
    check("established answer-seeking tendency → hint before answer", hinted);
    const m = await engine.load("adv");
    const tend = m.beliefs.find((b) => b.key === "tendency:asks_before_attempting");
    check("tendency belief is inferred, active and inspectable", !!tend && tend.status === "active" && tend.source === "inferred");
    await say("key0");
    const r2 = await say("That's not true about me, I don't ask for answers before attempting.");
    const m2 = await engine.load("adv");
    check("correction retires the tendency", m2.beliefs.every((b) => b.key !== "tendency:asks_before_attempting" || b.status === "retired") && /retired/i.test(r2.reply));
  }
  // 8. Goal switch keeps the old goal's evidence and returns to it.
  {
    const { engine, say, store } = await setup();
    await say("I want to learn widget theory");
    await say("key0");
    await say("key0");
    let n = 900;
    const { plan } = syntheticPlan("gadget theory", "factual", 2, (p) => `${p}_${n++}`);
    await store.content.put(`goal:${topicKey("gadget theory")}`, plan);
    await say("Actually I want to learn gadget theory instead");
    let m = await engine.load("adv");
    check("new goal active, old goal paused, old skill states kept", m.goals.filter((g) => g.status === "active").length === 1 && m.goals.some((g) => g.status === "paused") && Object.values(m.states).some((s) => s.attempts > 0));
    await say("back to widget theory");
    m = await engine.load("adv");
    check("returning to the old goal reactivates it", m.goals.find((g) => g.text === "widget theory")?.status === "active");
  }
  // 9. Long gap: goal and states survive; a new session starts; predicted recall has decayed.
  {
    const { engine, say, skip } = await setup();
    await say("I want to learn widget theory");
    await say("key0");
    await say("key0");
    const before = await engine.load("adv");
    const sid = before.currentSessionId;
    skip(90 * DAY);
    const r = await say("continue");
    const m = await engine.load("adv");
    check("90-day gap: new session, goal survives, evidence kept", m.currentSessionId !== sid && m.goals[0].status === "active" && Object.values(m.states).some((s) => s.attempts > 0));
    check("after a long gap the tutor reviews rather than teaching new material blindly", ["review", "practice", "teach", "verify_claim"].includes(r.trace.decision.activity));
  }
  // 10. Noise: 300 random messages → bounded beliefs, no crash, observations linear.
  {
    const { engine, say, store } = await setup();
    await say("I want to learn widget theory");
    const junk = ["???", "lol", "key0", "I think mis1", "hint", "skip", "what", "asdf qwer", "I don't know", "explain", "example", "I'm tired", "that makes sense", "continue", "12", "b", "no"];
    for (let i = 0; i < 300; i++) await say(junk[(i * 7) % junk.length]);
    const m = await engine.load("adv");
    const obs = await store.observations("adv");
    check("300 noisy turns: ≤ 8 live beliefs, observations bounded, no crash", m.beliefs.filter((b) => b.status !== "retired").length <= 8 && obs.length <= 900);
    check("confidence never exceeds the cap", m.beliefs.every((b) => b.confidence <= 0.92));
  }
  // 11. Support attribution: credit goes only to the first later unaided attempt on the same skill.
  {
    const { engine, say, store } = await setup();
    await say("I want to learn widget theory");
    for (let i = 0; i < 12; i++) await say("key0");
    const outs = await store.supportOutcomes("adv");
    const turns = await store.recentTurns("adv", 200);
    const ok = outs.every((o) => {
      const tt = turns.find((x) => x.id === o.tutorTurnId);
      return tt && tt.role === "tutor" && tt.skillId === o.skillId && (tt.trace?.decision.support === o.support);
    });
    check("support outcomes reference the supporting turn, same skill, same support", outs.length > 0 && ok);
  }
  // 12. Temporary context expires and never becomes a permanent belief.
  {
    const { engine, say, skip } = await setup();
    await say("I want to learn widget theory");
    await say("I'm tired today");
    let m = await engine.load("adv");
    check("context belief recorded with expiry", m.beliefs.some((b) => b.kind === "context" && b.expiresAt));
    skip(2 * DAY);
    await say("continue");
    m = await engine.load("adv");
    check("context belief expired at the next session", m.beliefs.filter((b) => b.kind === "context").every((b) => b.status === "retired" && b.invalidReason === "expired"));
  }
  // 13. Unknown goal with no content source: scaffold still runs the loop and invites material.
  {
    const store = new InMemoryStore();
    const engine = new Engine({ store, llm: null, fetchImpl: null, seed: 3 });
    const r = await engine.turn("adv", "I want to learn competitive yo-yo tricks", new Date());
    const m = await engine.load("adv");
    check("unknown goal → scaffold plan, learner told honestly", m.goals[0].source === "scaffold" && /don't have reference material/i.test(r.reply) && !!m.pending);
    const notes = "The sleeper is the foundational trick: the yo-yo spins at the end of the string.\n\nA bind returns an unresponsive yo-yo by catching the string in the gap.\n\nString tension must be neutral or tricks will snag and the yo-yo will not sleep.";
    const r2 = await engine.turn("adv", `here are my notes: ${notes}`, new Date(Date.now() + 60_000));
    const m2 = await engine.load("adv");
    check("learner notes become skills and items", m2.skills.length > 1 && m2.items.some((i) => i.source === "learner") && /from your notes/i.test(r2.reply));
  }
  // 14. Research/content cache carries no learner information.
  {
    const { store } = await setup();
    const cached = JSON.stringify([...store.plans.values()]);
    check("content cache contains no learner id", !cached.includes("adv") && !cached.includes("learnerId"));
  }
  // 15. Explain-only ablation produces no evidence (it is the baseline, not a feature).
  {
    const { engine, say, store } = await setup({ ablation: { explainOnly: true } });
    await say("I want to learn widget theory");
    await say("that makes sense");
    await say("continue");
    const atts = await store.attempts("adv");
    check("explain-only creates zero attempts", atts.length === 0);
    void engine;
  }
  // 16. Self-graded items: reference revealed, self-grade recorded as its own channel.
  {
    const store = new InMemoryStore();
    const engine = new Engine({ store, llm: null, fetchImpl: null, seed: 3 });
    const t0 = Date.now();
    await engine.turn("adv", "I want to learn something obscure", new Date(t0));
    const r1 = await engine.turn("adv", "I think it is about three main ideas", new Date(t0 + 60_000));
    check("open-ended item reveals the reference and asks for a self-grade", r1.trace.decision.activity === "await_self_grade" && /got it/.test(r1.reply));
    await engine.turn("adv", "partly", new Date(t0 + 120_000));
    const atts = await store.attempts("adv");
    check("self-grade recorded as grading=self with score 0.5", atts.length === 1 && atts[0].grading === "self" && atts[0].score === 0.5);
  }

  console.log(`\n${pass} passed, ${fail} failed`);
  if (fail) process.exit(1);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
