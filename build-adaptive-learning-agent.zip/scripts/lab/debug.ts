// Turn-by-turn trace of one synthetic learner: npx tsx scripts/lab/debug.ts novice full
import { ARCHETYPES, CONDITIONS, runLearner } from "./sim";
import { Engine } from "../../src/lib/core/engine";
const origTurn = Engine.prototype.turn;
Engine.prototype.turn = async function (this: Engine, id: string, msg: string, now?: Date) {
  const r = await origTurn.call(this, id, msg, now);
  const d = r.trace.decision;
  const g = r.trace.graded;
  const sk = d.skillId ? r.model.skills.find((s) => s.id === d.skillId)?.name.replace(/^.* skill /, "S") : "-";
  console.log(`${now?.toISOString().slice(0, 16)} | L: ${msg.slice(0, 32).padEnd(32)} | graded=${g ? (g.correct ? "✓" : "✗") : " "} | ${d.activity.padEnd(13)} ${sk?.padEnd(3)} ${d.support ?? ""}`.padEnd(120) + `| ${d.reasons[0]?.slice(0, 90) ?? ""}`);
  return r;
};
const arch = ARCHETYPES.find((a) => a.name === (process.argv[2] ?? "novice"))!;
const cond = CONDITIONS.find((c) => c.name === (process.argv[3] ?? "full"))!;
runLearner(arch, cond, (process.argv[4] as "factual") ?? "factual", { sessions: Number(process.argv[5] ?? 4), turnsPerSession: 10, seed: 1, nSkills: 3 }).then((r) => console.log(JSON.stringify(r, null, 0)));
