// Synthetic-learner laboratory.
//
// A synthetic learner has HIDDEN state per skill: knowledge k, memory half-life
// s, a possible misconception m, and transfer generalisation g. It answers the
// items the tutor poses from that state and learns from what the tutor does
// (explanations, retrieval, feedback, refutation) according to rules drawn
// from the learning-science evidence (docs/RESEARCH.md). The tutor sees only
// text. Nothing here is proof about humans; it is a controlled test of whether
// the controller extracts learning when those mechanisms matter.

import { Engine } from "../../src/lib/core/engine";
import { InMemoryStore } from "../../src/lib/core/store";
import { mulberry32 } from "../../src/lib/core/beliefs";
import { pRecall } from "../../src/lib/core/memory";
import { topicKey } from "../../src/lib/content";
import type { Ablation, ContentPlan, Item, Skill, SupportMode } from "../../src/lib/core/types";

export interface Archetype {
  name: string;
  initK: (skillIdx: number, rnd: () => number) => number;
  forgetting: number; // multiplies half-life: <1 forgets faster
  misconceptionRate: number;
  transferGain: number; // g increase per new variant practised successfully
  exampleBenefitNovice: number; // Δk factor from reading a worked example when k < 0.3 (default 0.35)
  claimsAtStart: string | null; // self-report said at first turn
  hintSeeking: number; // p(asks for the answer before attempting)
  slip: number;
  gapDays: number;
  switchGoalAt: number | null; // session index
  correctAt: number | null; // session index at which the learner corrects the tutor's top inferred belief
  sessions?: number;
}

const base: Omit<Archetype, "name"> = { initK: () => 0.08, forgetting: 1, misconceptionRate: 0.3, transferGain: 0.25, exampleBenefitNovice: 0.35, claimsAtStart: null, hintSeeking: 0, slip: 0.06, gapDays: 3, switchGoalAt: null, correctAt: null };

export const ARCHETYPES: Archetype[] = [
  { ...base, name: "novice" },
  { ...base, name: "knowledgeable", initK: (i) => (i < 3 ? 0.7 : 0.1) },
  { ...base, name: "fast_forgetter", forgetting: 0.45 },
  { ...base, name: "slow_forgetter", forgetting: 2.2 },
  { ...base, name: "misconception_prone", misconceptionRate: 0.9 },
  { ...base, name: "low_transfer", transferGain: 0.07 },
  { ...base, name: "overconfident", claimsAtStart: "I already know the basics of this", initK: () => 0.1 },
  { ...base, name: "example_averse", exampleBenefitNovice: 0.1 },
  { ...base, name: "hint_seeker", hintSeeking: 0.6 },
  { ...base, name: "noisy", slip: 0.22 },
  { ...base, name: "long_gap", gapDays: 21 },
  { ...base, name: "goal_switcher", switchGoalAt: 2 },
  { ...base, name: "corrector", correctAt: 2, claimsAtStart: "I learn best from worked examples" },
];

export interface Condition { name: string; ablation: Ablation }
export const CONDITIONS: Condition[] = [
  { name: "full", ablation: {} },
  { name: "explain_only", ablation: { explainOnly: true } },
  { name: "bandit_support", ablation: { supportPolicy: "bandit" } },
  { name: "no_spacing", ablation: { noSpacing: true } },
  { name: "no_remediation", ablation: { noRemediation: true } },
  { name: "no_transfer", ablation: { noTransfer: true } },
  { name: "fixed_worked_example", ablation: { fixedSupport: "worked_example_first" } },
  { name: "fixed_retrieval", ablation: { fixedSupport: "retrieval_first" } },
  { name: "no_memory", ablation: { noMemory: true } },
  { name: "no_correction", ablation: { noCorrection: true } },
  { name: "no_interleave", ablation: { noInterleave: true } },
  { name: "no_calibration", ablation: { noCalibration: true } },
];

// ---------- synthetic domains: four item structures, no real subject ----------

export type DomainType = "factual" | "procedural" | "quantitative" | "discriminative";
export const DOMAIN_TYPES: DomainType[] = ["factual", "procedural", "quantitative", "discriminative"];

export function syntheticPlan(topic: string, type: DomainType, nSkills: number, id: (p: string) => string): { plan: ContentPlan; truth: Record<string, { correct: string; misconception: string; skillIdx: number }> } {
  const skills: Skill[] = [];
  const items: Item[] = [];
  const truth: Record<string, { correct: string; misconception: string; skillIdx: number }> = {};
  for (let i = 0; i < nSkills; i++) {
    const sk: Skill = { id: id("sk"), goalId: "g", name: `${topic} skill ${i + 1}`, description: `synthetic ${type} skill ${i + 1}`, explanation: `Explanation of ${topic} skill ${i + 1}.`, example: `Worked example for ${topic} skill ${i + 1}.`, prerequisites: i > 0 ? [skills[i - 1].id] : [], order: i };
    skills.push(sk);
    const correct = `key${i}`;
    const wrong = `mis${i}`;
    const variants: [string, Item["kind"]][] = [["r1", "recall"], ["r2", "recall"], ["r3", "recall"], ["a1", "apply"], ["a2", "apply"], ["t1", "transfer"], ["t2", "transfer"], ["d1", "discriminate"]];
    for (const [v, kind] of variants) {
      const it: Item = { id: id("it"), skillId: sk.id, kind, prompt: `[${type}] ${topic} skill ${i + 1} ${kind} (${v})`, answer: correct, hint: "hint", variant: v, source: "llm", errorTags: [{ match: [wrong], label: `misconception ${i}`, refutation: `refutation ${i}` }], grader: { kind: "exact", accept: [correct] } };
      if (type === "procedural") it.grader = { kind: "keywords", accept: [correct, `step${i}`], all: true };
      if (type === "quantitative") it.grader = { kind: "numeric", value: 10 + i, tolerance: 0.01 };
      if (type === "discriminative" || kind === "discriminate") it.grader = { kind: "choice", options: [correct, wrong, `other${i}`], correct: 0 };
      items.push(it);
      truth[it.id] = { correct, misconception: wrong, skillIdx: i };
    }
  }
  return { plan: { topic, source: "llm", provenance: "synthetic", skills, items }, truth };
}

// ---------- hidden learner state ----------

interface Hidden { k: number; s: number; last: number | null; m: boolean; g: number; variantsOk: Set<string>; k0: number; m0: boolean }

export interface Report {
  archetype: string; condition: string; seed: number; domain: DomainType;
  gain: number; retain7: number; retain30: number; transfer7: number; miscLeft: number; miscInitial: number;
  calibrationMAE: number; supportMatch: number | null; supportDecisions: number;
  turns: number; itemsPosed: number; reviews: number; transfers: number; remediations: number;
  activeBeliefs: number; falseBeliefs: number; correctionRecreated: boolean | null; goalContinuity: boolean | null;
  msPerTurn: number;
}

export interface RunCfg { sessions: number; turnsPerSession: number; seed: number; nSkills: number }

export async function runLearner(arch: Archetype, cond: Condition, domain: DomainType, cfg: RunCfg): Promise<Report> {
  const rnd = mulberry32(cfg.seed * 7919 + hash(arch.name + domain) * 31);
  const store = new InMemoryStore();
  let idc = 0;
  const id = (p: string) => `${p}_${(idc++).toString(36)}`;
  const topic = `${domain} topic ${arch.name}`;
  const { plan, truth } = syntheticPlan(topic, domain, cfg.nSkills, id);
  await store.content.put(`goal:${topicKey(topic)}`, plan);
  const topic2 = `${domain} second topic`;
  const p2 = syntheticPlan(topic2, domain, 3, id);
  await store.content.put(`goal:${topicKey(topic2)}`, p2.plan);
  Object.assign(truth, p2.truth);

  const engine = new Engine({ store, llm: null, fetchImpl: null, seed: cfg.seed * 101 + hash(arch.name), ablation: cond.ablation });
  const learnerId = `sim_${arch.name}`;
  let now = Date.UTC(2025, 0, 6, 9, 0, 0);
  const H = new Map<string, Hidden>(); // engine skill id -> hidden (keyed by skill name so rekeying doesn't matter)
  const hiddenFor = (skillName: string): Hidden => {
    let h = H.get(skillName);
    if (!h) {
      const idx = parseInt(skillName.match(/skill (\d+)/)?.[1] ?? "1", 10) - 1;
      const k = clamp(arch.initK(idx, rnd) + (rnd() - 0.5) * 0.06, 0.02, 0.95);
      const m = rnd() < arch.misconceptionRate;
      h = { k, s: k > 0.5 ? 8 : 1.5, last: k > 0.5 ? now - 2 * DAY : null, m, g: k > 0.5 ? 0.45 : 0.2, variantsOk: new Set(), k0: k, m0: m };
      H.set(skillName, h);
    }
    return h;
  };
  const recall = (h: Hidden, t: number) => (h.last == null ? h.k * 0.5 : h.k * Math.pow(2, -((t - h.last) / DAY) / (h.s * arch.forgetting)));

  let turns = 0, itemsPosed = 0, reviews = 0, transfers = 0, remediations = 0, supportMatch = 0, supportDecisions = 0;
  let correctedKey: string | null = null;
  let correctionRecreated: boolean | null = null;
  let goalContinuity: boolean | null = null;
  const t0 = Date.now();
  let lastReplyActivity: string | null = null;
  const sessions = arch.sessions ?? cfg.sessions;

  for (let sess = 0; sess < sessions; sess++) {
    if (sess > 0) now += arch.gapDays * DAY;
    for (let t = 0; t < cfg.turnsPerSession; t++) {
      // ---------------- learner composes a message ----------------
      let msg: string;
      const model = await engine.load(learnerId, new Date(now));
      const pend = model.pending;
      if (sess === 0 && t === 0) msg = `I want to learn ${topic}`;
      else if (arch.switchGoalAt === sess && t === 0) msg = `Let's do something else: I want to learn ${topic2}`;
      else if (arch.switchGoalAt != null && sess === arch.switchGoalAt + 2 && t === 0) msg = `back to ${topic}`;
      else if (t === 0) msg = "continue";
      else if (sess === 0 && t === 1 && arch.claimsAtStart) msg = arch.claimsAtStart;
      else if (arch.correctAt === sess && t === 1 && correctedKey == null) {
        const b = model.beliefs.filter((x) => x.kind === "preference" && x.status !== "retired").sort((a, b) => b.confidence - a.confidence)[0];
        if (b) {
          correctedKey = b.key;
          msg = `That's not true about me. ${b.statement}? No.`;
        } else msg = pend ? answerFor(pend.itemId) : "continue";
      } else if (pend && !pend.awaitingSelfGrade) {
        msg = !pend.helpGiven && rnd() < arch.hintSeeking ? "just tell me the answer" : answerFor(pend.itemId);
      } else if (pend?.awaitingSelfGrade) msg = "partly";
      else msg = "continue";

      function answerFor(itemId: string): string {
        const item = model.items.find((i) => i.id === itemId)!;
        const sk = model.skills.find((s) => s.id === item.skillId)!;
        const h = hiddenFor(sk.name);
        const tr = truth[item.id] ?? Object.values(truth).find((x) => x.correct === item.answer)!;
        let p = recall(h, now);
        if (item.kind === "transfer") p *= h.g;
        if (item.kind === "apply") p *= 0.9;
        if (pend!.helpGiven) p = Math.min(1, p + 0.25);
        // A misconception overrides knowledge on discriminating and applied items.
        if (h.m && (item.kind === "discriminate" || item.kind === "apply") && rnd() < 0.8) return wrongText(item, tr.misconception);
        const ok = rnd() < p * (1 - arch.slip);
        if (!ok) {
          if (h.m && rnd() < 0.5) return wrongText(item, tr.misconception);
          return rnd() < 0.3 ? "I don't know" : wrongText(item, `other${tr.skillIdx}v${Math.floor(rnd() * 6)}`);
        }
        return rightText(item, tr.correct, tr.skillIdx);
      }

      // ---------------- tutor turn ----------------
      const before = model.pending ? { itemId: model.pending.itemId, skillId: model.pending.skillId, helpGiven: model.pending.helpGiven, kind: model.items.find((i) => i.id === model.pending!.itemId)?.kind, variant: model.items.find((i) => i.id === model.pending!.itemId)?.variant } : null;
      const res = await engine.turn(learnerId, msg, new Date(now));
      turns++;
      const d = res.trace.decision;
      lastReplyActivity = d.activity;

      // ---------------- hidden learning dynamics ----------------
      if (res.trace.graded && before) {
        const sk = res.model.skills.find((s) => s.id === before.skillId)!;
        const h = hiddenFor(sk.name);
        const p = recall(h, now);
        const correct = res.trace.graded.correct;
        if (correct) {
          const gen = before.helpGiven ? 0.7 : 1;
          const massed = h.last != null && now - h.last < 0.5 * DAY;
          h.k = clamp(h.k + (massed ? 0.18 : 0.28) * gen * (1 - h.k) * (1 + (1 - p)), 0, 1);
          h.s = Math.min(400, Math.max(h.s, 1.5) * (massed ? 1.25 : 1.7 + 1.6 * (1 - p)));
          if (before.variant && !h.variantsOk.has(before.variant)) {
            h.variantsOk.add(before.variant);
            if (h.variantsOk.size > 1) h.g = Math.min(0.92, h.g + arch.transferGain);
          }
          if (h.m && rnd() < 0.1) h.m = false;
        } else {
          // Failure followed by corrective feedback. Pretesting effect for novices: the feedback lands better after an attempt.
          const revealed = res.trace.graded.errorSignature === "asked_for_answer";
          const rate = revealed ? 0.08 : h.k < 0.3 ? 0.22 : 0.12;
          h.k = clamp(h.k + rate * (1 - h.k), 0, 1);
          h.s = Math.max(1.5, h.s * 0.7); // relearning after a lapse is faster than first learning (savings)
          h.k *= 0.97;
          // refutation shown when the wrong answer was tagged
          if (h.m && res.trace.graded.errorSignature?.startsWith("tag:") && rnd() < 0.45) h.m = false;
        }
        h.last = now;
      }
      if (d.skillId) {
        const sk = res.model.skills.find((s) => s.id === d.skillId);
        if (sk) {
          const h = hiddenFor(sk.name);
          if ((d.activity === "teach" || d.activity === "practice") && d.support && d.reasons.some((x) => x.includes("posterior mean") || x.includes("expertise-reversal default") || x.includes("overrides the default"))) {
            supportDecisions++;
            const best: SupportMode = h.k < 0.3 ? (arch.exampleBenefitNovice >= 0.3 ? "worked_example_first" : "retrieval_first") : "retrieval_first";
            if (d.support === best) supportMatch++;
          }
          const exposed = d.support === "worked_example_first" || d.activity === "help" || d.activity === "remediate" || (cond.ablation.explainOnly && d.activity === "teach");
          if (exposed) {
            const novice = h.k < 0.3;
            const factor = novice ? arch.exampleBenefitNovice : 0.06;
            h.k = clamp(h.k + factor * (1 - h.k), 0, 1);
            if (h.last == null) { h.last = now; h.s = Math.max(h.s, 1.5); }
          }
          if (d.activity === "remediate" && h.m && rnd() < 0.6) h.m = false;
        }
      }
      if (res.model.pending && d.itemId) {
        itemsPosed++;
        if (d.activity === "review") reviews++;
        if (d.activity === "transfer") transfers++;
        if (d.activity === "remediate") remediations++;
      }
      now += 90_000; // 90 s per exchange
    }
    // correction recreation check (any later session)
    if (correctedKey && arch.correctAt != null && sess > arch.correctAt) {
      const m = await engine.load(learnerId, new Date(now));
      const re = m.beliefs.some((b) => b.key === correctedKey && b.status !== "retired" && b.source === "inferred");
      correctionRecreated = correctionRecreated || re;
    }
    if (arch.switchGoalAt != null && sess === arch.switchGoalAt + 2) {
      const m = await engine.load(learnerId, new Date(now));
      const g1 = m.goals.find((g) => g.text.includes(topic));
      goalContinuity = !!g1 && g1.status === "active" && m.skills.filter((s) => s.goalId === g1.id).some((s) => (m.states[s.id]?.attempts ?? 0) > 0);
    }
  }
  if (correctedKey && correctionRecreated == null) correctionRecreated = false;

  // ---------------- hidden final assessment ----------------
  const final = await engine.load(learnerId, new Date(now));
  const mainSkills = final.skills.filter((s) => s.name.startsWith(topic));
  const hs = mainSkills.map((s) => ({ s, h: hiddenFor(s.name) }));
  const at = (days: number) => now + days * DAY;
  const gain = mean(hs.map((x) => x.h.k - x.h.k0));
  const retain7 = mean(hs.map((x) => recall(x.h, at(7))));
  const retain30 = mean(hs.map((x) => recall(x.h, at(30))));
  const transfer7 = mean(hs.map((x) => recall(x.h, at(7)) * x.h.g));
  const miscInitial = hs.filter((x) => x.h.m0).length;
  const miscLeft = miscInitial ? hs.filter((x) => x.h.m).length / miscInitial : 0;
  const calibrationMAE = mean(hs.map((x) => Math.abs(pRecall(final.states[x.s.id] ?? { ...emptyState(x.s.id) }, new Date(at(7)), final.forgettingScale) - recall(x.h, at(7)))));
  const active = final.beliefs.filter((b) => b.status === "active" || b.status === "contested");
  const falseBeliefs = active.filter((b) => b.kind === "preference" && b.source === "inferred" && !prefIsTrue(b.key, arch)).length;
  return {
    archetype: arch.name, condition: cond.name, seed: cfg.seed, domain, gain, retain7, retain30, transfer7, miscLeft, miscInitial, calibrationMAE,
    supportMatch: supportDecisions ? supportMatch / supportDecisions : null, supportDecisions, turns, itemsPosed, reviews, transfers, remediations,
    activeBeliefs: active.length, falseBeliefs, correctionRecreated, goalContinuity, msPerTurn: (Date.now() - t0) / Math.max(1, turns),
  };
  void lastReplyActivity;
}

function prefIsTrue(key: string, arch: Archetype): boolean {
  // The hidden truth about support: novices benefit from worked examples unless example-averse.
  if (key.endsWith("worked_example_first")) return arch.exampleBenefitNovice >= 0.3;
  if (key.endsWith("retrieval_first")) return true;
  return true;
}

function rightText(item: Item, correct: string, idx: number): string {
  switch (item.grader.kind) {
    case "numeric": return String(item.grader.value);
    case "choice": return item.grader.options[item.grader.correct];
    case "keywords": return `${correct} and step${idx}`;
    default: return correct;
  }
}
function wrongText(item: Item, wrong: string): string {
  switch (item.grader.kind) {
    case "numeric": return wrong.startsWith("mis") ? String(item.grader.value + 1) : String(item.grader.value - 2 - (wrong.charCodeAt(wrong.length - 1) % 5));
    case "choice": return wrong.startsWith("mis") ? item.grader.options[1] : item.grader.options[2];
    default: return `I think ${wrong}`;
  }
}

function emptyState(skillId: string) {
  return { skillId, status: "new" as const, basis: "none" as const, pKnown: 0.15, stability: 0.5, lastSuccessAt: null, lastAttemptAt: null, attempts: 0, successes: 0, unaidedSuccesses: 0, lapses: 0, spacedSuccesses: 0, transferAttempts: 0, transferSuccesses: 0, variantsSeen: [], claimedLevel: null, claimedAt: null, taughtAt: null, lastSupport: null, recent: [] };
}

const DAY = 86_400_000;
export function mean(xs: number[]): number { return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0; }
function clamp(x: number, lo: number, hi: number) { return Math.min(hi, Math.max(lo, x)); }
export function hash(s: string): number { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }
