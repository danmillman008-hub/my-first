"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type Trace = {
  observed: string[];
  graded: { itemId: string; correct: boolean; score: number; grading: string; errorSignature: string | null } | null;
  attribution: string[];
  modelChanges: string[];
  decision: { activity: string; skillId: string | null; itemId: string | null; support: string | null; reasons: string[]; alternatives: string[] };
};
type Msg = { role: "learner" | "tutor"; content: string; trace?: Trace | null; id?: string };
type Belief = { id: string; kind: string; statement: string; source: string; status: string; confidence: number; support: number; contradiction: number; scope: string | null; evidence: { relation: string; at: string }[]; invalidReason: string | null; supersededBy: string | null; lastConfirmedAt: string };
type SkillView = { id: string; name: string; goal: string | null; goalStatus: string | null; status: string; basis: string; pKnown: number | null; pRecallNow: number | null; halfLifeDays: number | null; dueInDays: number | null; attempts: number; successes: number; unaidedSuccesses: number; spacedSuccesses: number; transfer: string; lapses: number; claimedLevel: number | null; trend: number | null; errors: { label: string; count: number; status: string }[] };
type Model = { learnerId: string; turnCount: number; forgettingScale: number; calibrationN: number; goals: { id: string; text: string; topic: string; status: string; source: string | null; provenance: string | null }[]; skills: SkillView[]; beliefs: Belief[]; supportStats: { context: string; stats: { support: string; successRate: number; n: number }[] }[] };

const STATUS_COLOR: Record<string, string> = { new: "bg-zinc-200 text-zinc-700", learning: "bg-amber-100 text-amber-800", review: "bg-sky-100 text-sky-800", secure: "bg-emerald-100 text-emerald-800" };
const BELIEF_COLOR: Record<string, string> = { candidate: "text-zinc-500", active: "text-emerald-700", contested: "text-amber-700", retired: "text-zinc-400 line-through" };

export default function Tutor() {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [model, setModel] = useState<Model | null>(null);
  const [tab, setTab] = useState<"model" | "why" | "privacy">("model");
  const [showRetired, setShowRetired] = useState(false);
  const [llm, setLlm] = useState<boolean | null>(null);
  const [lastTrace, setLastTrace] = useState<Trace | null>(null);
  const bottom = useRef<HTMLDivElement>(null);

  const refresh = useCallback(async () => {
    const r = await fetch("/api/learner");
    if (!r.ok) return;
    const d = await r.json();
    setModel(d.model);
    setLlm(d.llm);
    const turns = (d.turns ?? []) as { role: "learner" | "tutor"; content: string; trace: Trace | null; id: string }[];
    setMsgs(turns.map((t) => ({ role: t.role, content: t.content, trace: t.trace, id: t.id })));
    const lastTutor = [...turns].reverse().find((t) => t.role === "tutor");
    if (lastTutor?.trace) setLastTrace(lastTutor.trace);
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);
  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, busy]);

  async function send(text?: string) {
    const message = (text ?? input).trim();
    if (!message || busy) return;
    setInput("");
    setBusy(true);
    setMsgs((m) => [...m, { role: "learner", content: message }]);
    try {
      const r = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ message }) });
      const d = await r.json();
      if (!r.ok) {
        setMsgs((m) => [...m, { role: "tutor", content: d.error ?? "Something went wrong." }]);
      } else {
        setMsgs((m) => [...m, { role: "tutor", content: d.reply, trace: d.trace, id: d.turnId }]);
        setModel(d.model);
        setLlm(d.llm);
        setLastTrace(d.trace);
      }
    } finally {
      setBusy(false);
    }
  }

  async function correctBelief(b: Belief) {
    const replacement = window.prompt(`You're telling me this is wrong about you:\n\n"${b.statement}"\n\nOptionally, what is true instead? (leave empty to just retire it)`, "");
    if (replacement === null) return;
    const r = await fetch("/api/learner", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ beliefId: b.id, replacement }) });
    const d = await r.json();
    setModel(d.model);
    setMsgs((m) => [...m, { role: "tutor", content: `Model updated: ${d.changes.join("; ")}` }]);
  }

  async function erase() {
    if (!window.confirm("Delete everything this tutor knows about you? This cannot be undone.")) return;
    await fetch("/api/learner", { method: "DELETE" });
    setMsgs([]);
    setModel(null);
    setLastTrace(null);
    await refresh();
  }

  const activeGoal = model?.goals.find((g) => g.status === "active");
  const liveBeliefs = (model?.beliefs ?? []).filter((b) => showRetired || b.status !== "retired");

  return (
    <div className="grid h-screen grid-cols-1 md:grid-cols-[minmax(0,1fr)_420px]">
      {/* ---------------- conversation ---------------- */}
      <div className="flex min-h-0 flex-col border-r border-zinc-200">
        <header className="flex items-center justify-between border-b border-zinc-200 px-5 py-3">
          <div>
            <h1 className="text-base font-semibold tracking-tight">Your tutor</h1>
            <p className="text-xs text-zinc-500">{activeGoal ? `Working on: ${activeGoal.topic}` : "One learner, one continuous relationship. Tell it what you want to learn."}</p>
          </div>
          <div className="text-right text-[11px] text-zinc-500">
            {llm === false && <span title="Set OPENAI_API_KEY (or LLM_API_KEY) to enable generated content, open-answer grading and question answering.">offline mode · no language model configured</span>}
            {llm === true && <span>language model enabled</span>}
          </div>
        </header>
        <main className="min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {msgs.length === 0 && !busy && (
            <div className="mx-auto max-w-xl rounded-xl border border-zinc-200 bg-white p-5 text-sm text-zinc-700 shadow-sm">
              <p className="font-medium">What do you want to learn?</p>
              <p className="mt-1 text-zinc-500">Anything, in your own words. I&apos;ll build practice that makes you retrieve, come back to things as they fade, vary the context so it transfers, and keep a model of you that you can inspect and correct on the right.</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {["I want to learn the basics of photosynthesis", "Teach me how Bayes' theorem works", "Help me get better at Spanish subjunctive", "I want to understand TCP handshakes"].map((s) => (
                  <button key={s} onClick={() => send(s)} className="rounded-full border border-zinc-300 px-3 py-1 text-xs hover:bg-zinc-100">{s}</button>
                ))}
              </div>
            </div>
          )}
          {msgs.map((m, i) => (
            <div key={m.id ?? i} className={`flex ${m.role === "learner" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm ${m.role === "learner" ? "bg-zinc-900 text-white" : "bg-white text-zinc-800 ring-1 ring-zinc-200"}`}>
                {renderMd(m.content)}
                {m.role === "tutor" && m.trace && (
                  <button onClick={() => { setLastTrace(m.trace!); setTab("why"); }} className="mt-2 block text-[11px] text-zinc-400 hover:text-zinc-700">why this? · {m.trace.decision.activity}{m.trace.decision.support ? ` · ${m.trace.decision.support}` : ""}</button>
                )}
              </div>
            </div>
          ))}
          {busy && <div className="text-xs text-zinc-400">thinking…</div>}
          <div ref={bottom} />
        </main>
        <form onSubmit={(e) => { e.preventDefault(); void send(); }} className="flex gap-2 border-t border-zinc-200 p-3">
          <textarea value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void send(); } }} rows={2} placeholder='Answer, ask, or say what you want to learn… ("hint", "skip", "I don&apos;t know", "that&apos;s not true about me" all work)' className="flex-1 resize-none rounded-xl border border-zinc-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-zinc-400" />
          <button disabled={busy || !input.trim()} className="rounded-xl bg-zinc-900 px-4 text-sm font-medium text-white disabled:opacity-40">Send</button>
        </form>
      </div>

      {/* ---------------- inspector ---------------- */}
      <aside className="flex min-h-0 flex-col bg-zinc-50">
        <nav className="flex border-b border-zinc-200 text-sm">
          {(["model", "why", "privacy"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`flex-1 px-3 py-2.5 capitalize ${tab === t ? "border-b-2 border-zinc-900 font-medium" : "text-zinc-500"}`}>{t === "why" ? "Why this turn" : t === "model" ? "What I think about you" : "Privacy"}</button>
          ))}
        </nav>
        <div className="min-h-0 flex-1 overflow-y-auto p-4 text-sm">
          {tab === "model" && model && (
            <div className="space-y-5">
              <section>
                <h2 className="mb-1 text-xs font-semibold uppercase tracking-wide text-zinc-500">Goals</h2>
                {model.goals.length === 0 && <p className="text-zinc-500">None yet.</p>}
                <ul className="space-y-1">
                  {model.goals.map((g) => (
                    <li key={g.id} className="rounded-lg bg-white p-2 ring-1 ring-zinc-200">
                      <div className="flex items-center justify-between"><span className="font-medium">{g.topic}</span><span className="text-xs text-zinc-500">{g.status}</span></div>
                      <div className="text-xs text-zinc-500">said: “{g.text}” · content: {g.source ?? "—"}{g.provenance && g.source !== "scaffold" ? ` (${g.provenance})` : ""}</div>
                    </li>
                  ))}
                </ul>
              </section>
              <section>
                <h2 className="mb-1 text-xs font-semibold uppercase tracking-wide text-zinc-500">Skills — what you can demonstrate</h2>
                <p className="mb-2 text-[11px] text-zinc-500">Basis tells you where the estimate comes from: <b>demonstrated</b> (your attempts), <b>claimed</b> (you told me, not yet verified), or none. Predicted recall decays with time using a half-life fitted to you (forgetting scale {model.forgettingScale.toFixed(2)}, from {model.calibrationN} spaced checks).</p>
                <ul className="space-y-1.5">
                  {model.skills.filter((s) => s.goalStatus !== "done").map((s) => (
                    <li key={s.id} className="rounded-lg bg-white p-2 ring-1 ring-zinc-200">
                      <div className="flex items-start justify-between gap-2">
                        <span className="font-medium leading-tight">{s.name}</span>
                        <span className={`shrink-0 rounded-full px-2 py-0.5 text-[11px] ${STATUS_COLOR[s.status]}`}>{s.status}</span>
                      </div>
                      <div className="mt-1 grid grid-cols-2 gap-x-3 text-[11px] text-zinc-600">
                        <span>basis: {s.basis}{s.claimedLevel != null ? ` (claimed ${s.claimedLevel.toFixed(1)})` : ""}</span>
                        <span>recall now: {s.pRecallNow != null && s.basis !== "none" ? `${Math.round(s.pRecallNow * 100)}%` : "—"}</span>
                        <span>attempts: {s.successes}/{s.attempts} ({s.unaidedSuccesses} unaided, {s.spacedSuccesses} spaced)</span>
                        <span>new-context: {s.transfer}</span>
                        <span>half-life: {s.halfLifeDays != null && s.basis === "demonstrated" ? `${s.halfLifeDays.toFixed(1)}d` : "—"}</span>
                        <span>next check: {s.dueInDays != null ? (s.dueInDays < 0.5 ? "due" : `~${Math.round(s.dueInDays)}d`) : "—"}</span>
                        {s.trend != null && <span>trend: {s.trend > 0.1 ? "improving" : s.trend < -0.1 ? "slipping" : "flat"}</span>}
                        {s.lapses > 0 && <span>lapses: {s.lapses}</span>}
                      </div>
                      {s.errors.length > 0 && (
                        <ul className="mt-1 text-[11px]">
                          {s.errors.map((e, i) => <li key={i} className={e.status === "resolved" ? "text-zinc-400 line-through" : e.status === "active" ? "text-rose-700" : "text-amber-700"}>{e.status === "active" ? "persistent: " : e.status === "candidate" ? "seen once: " : ""}{e.label} ({e.count}×)</li>)}
                        </ul>
                      )}
                    </li>
                  ))}
                </ul>
              </section>
              <section>
                <div className="mb-1 flex items-center justify-between">
                  <h2 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Beliefs about you — correctable</h2>
                  <label className="text-[11px] text-zinc-500"><input type="checkbox" checked={showRetired} onChange={(e) => setShowRetired(e.target.checked)} className="mr-1" />show retired</label>
                </div>
                <p className="mb-2 text-[11px] text-zinc-500">Inferred beliefs need repeated, cross-session evidence before they influence anything; contradicting evidence contests them; your correction retires them immediately and blocks re-derivation from old evidence.</p>
                {liveBeliefs.length === 0 && <p className="text-zinc-500">Nothing yet beyond your stated goals.</p>}
                <ul className="space-y-1">
                  {liveBeliefs.map((b) => (
                    <li key={b.id} className="rounded-lg bg-white p-2 ring-1 ring-zinc-200">
                      <div className="flex items-start justify-between gap-2">
                        <span className={`leading-tight ${BELIEF_COLOR[b.status]}`}>{b.statement}</span>
                        {b.status !== "retired" && b.kind !== "goal" && <button onClick={() => correctBelief(b)} className="shrink-0 rounded border border-rose-200 px-1.5 py-0.5 text-[11px] text-rose-700 hover:bg-rose-50">that&apos;s wrong</button>}
                      </div>
                      <div className="text-[11px] text-zinc-500">{b.kind} · {b.source} · {b.status} · confidence {b.confidence.toFixed(2)} · {b.support} for / {b.contradiction} against · {b.scope ? "this goal only" : "general"}{b.invalidReason ? ` · retired: ${b.invalidReason.replace(/_/g, " ")}` : ""}</div>
                    </li>
                  ))}
                </ul>
              </section>
              {model.supportStats.length > 0 && (
                <section>
                  <h2 className="mb-1 text-xs font-semibold uppercase tracking-wide text-zinc-500">Support outcomes (observed, not believed)</h2>
                  <p className="mb-1 text-[11px] text-zinc-500">Rate at which the next <i>unaided</i> attempt succeeded after each kind of support. Attributed by rule: only the first later unaided attempt on the same skill counts, down-weighted across sessions or when the skill was already likely known.</p>
                  {model.supportStats.map((c) => (
                    <div key={c.context} className="text-[11px] text-zinc-600">{c.context}: {c.stats.map((s) => `${s.support.replace(/_/g, " ")} ${Math.round(s.successRate * 100)}% (n=${s.n})`).join(" · ")}</div>
                  ))}
                </section>
              )}
            </div>
          )}
          {tab === "why" && (
            lastTrace ? (
              <div className="space-y-4">
                <Section title="Observed in your message" items={lastTrace.observed} empty="Nothing specific." />
                {lastTrace.graded && <div><h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Graded</h3><p className="text-zinc-700">{lastTrace.graded.correct ? "correct" : "not correct"} · score {lastTrace.graded.score.toFixed(2)} · {lastTrace.graded.grading}-graded{lastTrace.graded.errorSignature ? ` · signature ${lastTrace.graded.errorSignature}` : ""}</p></div>}
                <Section title="Attribution" items={lastTrace.attribution} empty="No outcome attributed this turn." />
                <Section title="What changed in the model" items={lastTrace.modelChanges} empty="Nothing changed." />
                <div>
                  <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Decision</h3>
                  <p className="font-medium">{lastTrace.decision.activity}{lastTrace.decision.support ? ` · ${lastTrace.decision.support.replace(/_/g, " ")}` : ""}</p>
                  <ul className="mt-1 list-disc space-y-0.5 pl-4 text-zinc-700">{lastTrace.decision.reasons.map((r, i) => <li key={i}>{r}</li>)}</ul>
                  {lastTrace.decision.alternatives.length > 0 && <><p className="mt-2 text-[11px] font-semibold uppercase text-zinc-400">Also considered</p><ul className="list-disc space-y-0.5 pl-4 text-[12px] text-zinc-500">{lastTrace.decision.alternatives.map((a, i) => <li key={i}>{a}</li>)}</ul></>}
                </div>
              </div>
            ) : <p className="text-zinc-500">No tutor turn yet.</p>
          )}
          {tab === "privacy" && (
            <div className="space-y-3 text-zinc-700">
              <p>Your data is a private cookie id plus what you type. It lives only in this app&apos;s database. There is no telemetry and no account.</p>
              <p>{llm ? "A language model is configured: single turns (the current item, your answer, your question, the topic) are sent to it to generate content, grade open answers and answer questions. Your learner model — beliefs, skill states, history — is never sent." : "No language model is configured, so nothing leaves this machine except optional Wikipedia lookups for topics (which carry no information about you)."}</p>
              <p>Topic content is cached by topic only and never linked to you.</p>
              <div className="flex gap-2 pt-2">
                <a href="/api/learner?export=1" className="rounded-lg border border-zinc-300 px-3 py-1.5 text-xs hover:bg-white">Export everything (JSON)</a>
                <button onClick={erase} className="rounded-lg border border-rose-300 px-3 py-1.5 text-xs text-rose-700 hover:bg-rose-50">Delete everything</button>
              </div>
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}

function Section({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return (
    <div>
      <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">{title}</h3>
      {items.length ? <ul className="mt-1 list-disc space-y-0.5 pl-4 text-zinc-700">{items.map((x, i) => <li key={i}>{x}</li>)}</ul> : <p className="text-zinc-400">{empty}</p>}
    </div>
  );
}

/** Minimal markdown: **bold**, *italic*, > quote lines. */
function renderMd(text: string) {
  return text.split("\n").map((line, i) => {
    const quote = line.startsWith("> ");
    const body = (quote ? line.slice(2) : line).split(/(\*\*[^*]+\*\*|\*[^*]+\*)/g).map((seg, j) => {
      if (seg.startsWith("**")) return <strong key={j}>{seg.slice(2, -2)}</strong>;
      if (seg.startsWith("*") && seg.endsWith("*") && seg.length > 2) return <em key={j}>{seg.slice(1, -1)}</em>;
      return <span key={j}>{seg}</span>;
    });
    return quote ? <blockquote key={i} className="my-1 border-l-2 border-zinc-300 pl-2 text-zinc-600">{body}</blockquote> : <span key={i}>{body}{i < text.split("\n").length - 1 ? "\n" : ""}</span>;
  });
}
