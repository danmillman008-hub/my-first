// One engine instance per process; identity is a private random cookie (no accounts, no telemetry).
import { cookies } from "next/headers";
import { Engine } from "./core/engine";
import { PgStore } from "./store/pg";
import { createLLM } from "./providers/llm";
import { pRecall } from "./core/memory";
import type { LearnerModel } from "./core/types";

const g = globalThis as typeof globalThis & { __tutorEngine?: Engine };
export function engine(): Engine {
  if (!g.__tutorEngine) g.__tutorEngine = new Engine({ store: new PgStore(), llm: createLLM() });
  return g.__tutorEngine;
}

export const COOKIE = "learner_id";
export async function learnerId(): Promise<{ id: string; isNew: boolean }> {
  const jar = await cookies();
  const existing = jar.get(COOKIE)?.value;
  if (existing && /^[a-z0-9_-]{8,64}$/i.test(existing)) return { id: existing, isNew: false };
  const id = `l_${crypto.randomUUID().replace(/-/g, "").slice(0, 24)}`;
  return { id, isNew: true };
}

export function llmConfigured(): boolean {
  return Boolean(process.env.OPENAI_API_KEY || process.env.LLM_API_KEY);
}

/** Inspectable view of the learner model: what is believed, on what basis, and what is due. */
export function summarize(m: LearnerModel, now = new Date()) {
  const skills = m.skills.map((s) => {
    const st = m.states[s.id];
    const goal = m.goals.find((g) => g.id === s.goalId);
    const p = st ? pRecall(st, now, m.forgettingScale) : 0;
    const halfLife = st ? st.stability * m.forgettingScale : 0;
    const dueInDays = st?.lastSuccessAt ? Math.max(0, halfLife * 0.9 - (now.getTime() - new Date(st.lastSuccessAt).getTime()) / 86_400_000) : null;
    const recent = st?.recent ?? [];
    const early = recent.slice(0, Math.floor(recent.length / 2));
    const late = recent.slice(Math.floor(recent.length / 2));
    const trend = early.length && late.length ? avg(late) - avg(early) : null;
    return {
      id: s.id, name: s.name, goal: goal?.topic ?? null, goalStatus: goal?.status ?? null, status: st?.status ?? "new", basis: st?.basis ?? "none",
      pKnown: st?.pKnown ?? null, pRecallNow: st ? p : null, halfLifeDays: st ? halfLife : null, dueInDays,
      attempts: st?.attempts ?? 0, successes: st?.successes ?? 0, unaidedSuccesses: st?.unaidedSuccesses ?? 0, spacedSuccesses: st?.spacedSuccesses ?? 0,
      transfer: st ? `${st.transferSuccesses}/${st.transferAttempts}` : "0/0", lapses: st?.lapses ?? 0, claimedLevel: st?.claimedLevel ?? null, trend,
      errors: m.errors.filter((e) => e.skillId === s.id).map((e) => ({ label: e.label, count: e.count, status: e.status })),
    };
  });
  const arms = Object.entries(m.arms).map(([context, a]) => ({ context, stats: Object.entries(a).map(([support, s]) => ({ support, successRate: s.alpha / (s.alpha + s.beta), n: s.n })) }));
  return {
    learnerId: m.id, createdAt: m.createdAt, lastSeenAt: m.lastSeenAt, turnCount: m.turnCount,
    forgettingScale: m.forgettingScale, calibrationN: m.calibrationN,
    goals: m.goals, skills, beliefs: m.beliefs, errors: m.errors, supportStats: arms, pending: m.pending,
  };
}
function avg(xs: number[]) { return xs.reduce((a, b) => a + b, 0) / xs.length; }
