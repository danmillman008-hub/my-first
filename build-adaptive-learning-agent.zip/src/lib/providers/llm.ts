// Optional model provider. OpenAI-compatible chat completions over fetch.
// Every call has a timeout and every failure returns null so the core keeps
// working deterministically without it. Privacy: callers pass only what a
// single call needs (a topic, an item, a response) — never the learner model.

export interface LLM {
  json<T>(system: string, user: string, maxTokens?: number): Promise<T | null>;
  text(system: string, user: string, maxTokens?: number): Promise<string | null>;
  readonly name: string;
}

export function createLLM(env: NodeJS.ProcessEnv = process.env): LLM | null {
  const apiKey = env.OPENAI_API_KEY || env.LLM_API_KEY;
  if (!apiKey) return null;
  const baseUrl = (env.OPENAI_BASE_URL || env.LLM_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  const model = env.OPENAI_MODEL || env.LLM_MODEL || "gpt-4o-mini";
  const timeoutMs = Number(env.LLM_TIMEOUT_MS || 20000);

  async function call(system: string, user: string, maxTokens: number, jsonMode: boolean): Promise<string | null> {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(`${baseUrl}/chat/completions`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${apiKey}` },
        body: JSON.stringify({
          model,
          temperature: 0.3,
          max_tokens: maxTokens,
          ...(jsonMode ? { response_format: { type: "json_object" } } : {}),
          messages: [
            { role: "system", content: system },
            { role: "user", content: user },
          ],
        }),
        signal: ctrl.signal,
      });
      if (!res.ok) return null;
      const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      return data.choices?.[0]?.message?.content ?? null;
    } catch {
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  return {
    name: model,
    async json<T>(system: string, user: string, maxTokens = 2500): Promise<T | null> {
      const out = await call(system + "\nRespond with a single JSON object only.", user, maxTokens, true);
      if (!out) return null;
      try {
        const start = out.indexOf("{");
        const end = out.lastIndexOf("}");
        return JSON.parse(out.slice(start, end + 1)) as T;
      } catch {
        return null;
      }
    },
    async text(system: string, user: string, maxTokens = 600): Promise<string | null> {
      return call(system, user, maxTokens, false);
    },
  };
}
