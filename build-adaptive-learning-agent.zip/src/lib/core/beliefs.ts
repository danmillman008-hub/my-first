// Beliefs about the learner: revisable, provenance-carrying, correctable.
// A belief is a prior for decisions, never a verdict. Inferred beliefs need
// repeated, cross-session support to become active; contradiction contests
// before it retires; a learner correction retires immediately and blocks
// re-derivation from pre-correction evidence.

import type { Belief, BeliefKind, BeliefSource, ArmStats, SupportMode, LearnerModel } from "./types";
import { SUPPORT_MODES } from "./types";
import { clamp } from "./memory";

export const CONFIDENCE_CAP = 0.92;

export function newId(prefix: string, rnd: () => number = Math.random): string {
  const n = Math.floor(rnd() * 0xffffffff).toString(16).padStart(8, "0");
  const m = Math.floor(rnd() * 0xffffff).toString(16).padStart(6, "0");
  return `${prefix}_${n}${m}`;
}

function confidence(b: Pick<Belief, "support" | "contradiction" | "source">): number {
  const prior = b.source === "stated" ? 3 : 1;
  return clamp((b.support + prior) / (b.support + b.contradiction + prior + 1), 0.05, CONFIDENCE_CAP);
}

function deriveStatus(b: Belief): Belief["status"] {
  if (b.status === "retired") return "retired";
  if (b.contradiction >= Math.max(2, b.support)) return "retired";
  if (b.contradiction > 0 && b.contradiction >= b.support / 2) return "contested";
  if (b.source === "stated") return "active";
  if (b.support >= 3 || (b.support >= 2 && b.sessionIds.length >= 2)) return "active";
  return "candidate";
}

export interface SupportArgs {
  kind: BeliefKind;
  key: string;
  statement: string;
  source: BeliefSource;
  scope: string | null;
  observationId: string;
  sessionId: string;
  now: Date;
  expiresAt?: string | null;
  rnd?: () => number;
}

/** Add supporting evidence to a belief (creating it as a candidate if needed). Returns change descriptions. */
export function supportBelief(model: LearnerModel, a: SupportArgs): string[] {
  const changes: string[] = [];
  const iso = a.now.toISOString();
  let b = model.beliefs.find((x) => x.key === a.key && x.scope === a.scope && x.status !== "retired");
  if (!b) {
    // A corrected belief may only be re-derived from evidence recorded after the correction.
    const corrected = model.beliefs.find((x) => x.key === a.key && x.scope === a.scope && x.status === "retired" && x.invalidReason === "learner_correction");
    if (corrected && corrected.invalidAt && a.source === "inferred") {
      const guardUntil = new Date(corrected.invalidAt).getTime() + 14 * 86_400_000;
      if (a.now.getTime() < guardUntil) {
        changes.push(`ignored evidence for corrected belief "${a.key}" (guard window)`);
        return changes;
      }
    }
    b = {
      id: newId("bel", a.rnd),
      kind: a.kind,
      key: a.key,
      statement: a.statement,
      source: a.source,
      status: "candidate",
      confidence: 0,
      support: 0,
      contradiction: 0,
      sessionIds: [],
      scope: a.scope,
      evidence: [],
      validFrom: iso,
      invalidAt: null,
      invalidReason: null,
      supersededBy: null,
      lastConfirmedAt: iso,
      expiresAt: a.expiresAt ?? null,
    };
    model.beliefs.push(b);
    changes.push(`new ${a.kind} belief candidate: ${a.statement}`);
  }
  if (b.evidence.some((e) => e.observationId === a.observationId)) return changes;
  b.support += 1;
  if (!b.sessionIds.includes(a.sessionId)) b.sessionIds.push(a.sessionId);
  b.evidence.push({ observationId: a.observationId, relation: "supports", at: iso });
  b.lastConfirmedAt = iso;
  if (a.source === "stated") b.source = "stated";
  const before = b.status;
  b.confidence = confidence(b);
  b.status = deriveStatus(b);
  if (b.status !== before) changes.push(`belief "${b.statement}" ${before} → ${b.status} (support ${b.support}, contradiction ${b.contradiction})`);
  return changes;
}

export function contradictBelief(model: LearnerModel, key: string, scope: string | null, observationId: string, now: Date): string[] {
  const changes: string[] = [];
  for (const b of model.beliefs) {
    if (b.key !== key || b.status === "retired") continue;
    if (scope !== null && b.scope !== null && b.scope !== scope) continue;
    b.contradiction += 1;
    b.evidence.push({ observationId, relation: "contradicts", at: now.toISOString() });
    const before = b.status;
    b.confidence = confidence(b);
    b.status = deriveStatus(b);
    if (b.status === "retired") {
      b.invalidAt = now.toISOString();
      b.invalidReason = "contradicted_by_evidence";
    }
    if (b.status !== before) changes.push(`belief "${b.statement}" ${before} → ${b.status}`);
    else changes.push(`belief "${b.statement}" contradicted (${b.contradiction} vs ${b.support})`);
  }
  return changes;
}

/** Learner says a belief is wrong. Retires it, keeps history, optional replacement supersedes it. */
export function correctBelief(model: LearnerModel, beliefId: string, observationId: string, now: Date, replacement?: { statement: string; kind: BeliefKind; key: string } | null): string[] {
  const b = model.beliefs.find((x) => x.id === beliefId);
  if (!b || b.status === "retired") return [];
  const iso = now.toISOString();
  b.status = "retired";
  b.invalidAt = iso;
  b.invalidReason = "learner_correction";
  b.evidence.push({ observationId, relation: "correction", at: iso });
  const changes = [`retired belief "${b.statement}" by learner correction`];
  if (replacement) {
    const nb: Belief = {
      id: newId("bel"),
      kind: replacement.kind,
      key: replacement.key,
      statement: replacement.statement,
      source: "stated",
      status: "active",
      confidence: confidence({ support: 1, contradiction: 0, source: "stated" }),
      support: 1,
      contradiction: 0,
      sessionIds: model.currentSessionId ? [model.currentSessionId] : [],
      scope: b.scope,
      evidence: [{ observationId, relation: "supports", at: iso }],
      validFrom: iso,
      invalidAt: null,
      invalidReason: null,
      supersededBy: null,
      lastConfirmedAt: iso,
      expiresAt: null,
    };
    model.beliefs.push(nb);
    b.supersededBy = nb.id;
    changes.push(`superseded by "${nb.statement}"`);
  }
  return changes;
}

/** Read-time influence: confidence × status × recency (60-day half-life) × scope match. */
export function beliefInfluence(b: Belief, now: Date, scope: string | null): number {
  if (b.status === "retired" || b.status === "candidate") return 0;
  if (b.expiresAt && new Date(b.expiresAt).getTime() < now.getTime()) return 0;
  if (b.scope && scope && b.scope !== scope) return 0;
  const days = (now.getTime() - new Date(b.lastConfirmedAt).getTime()) / 86_400_000;
  const recency = Math.pow(0.5, Math.max(0, days) / 60);
  const status = b.status === "contested" ? 0.5 : 1;
  return b.confidence * status * Math.max(0.35, recency);
}

export function activeBeliefs(model: LearnerModel, now: Date): Belief[] {
  return model.beliefs.filter((b) => beliefInfluence(b, now, null) > 0 || (b.status !== "retired" && b.status !== "candidate"));
}

// ---------- support-mode adaptation (Beta posteriors with discounting) ----------

/** Priors encode the expertise-reversal effect: novices benefit from worked examples first, learners with some knowledge from retrieval first. */
export function defaultArms(context: string): Record<SupportMode, ArmStats> {
  if (context === "novice") {
    return { retrieval_first: { alpha: 1, beta: 1.5, n: 0 }, hint_first: { alpha: 1.2, beta: 1.2, n: 0 }, worked_example_first: { alpha: 2, beta: 1, n: 0 } };
  }
  return { retrieval_first: { alpha: 2, beta: 1, n: 0 }, hint_first: { alpha: 1.2, beta: 1.2, n: 0 }, worked_example_first: { alpha: 1, beta: 1.5, n: 0 } };
}

export function updateArm(model: LearnerModel, context: string, arm: SupportMode, reward: number, weight: number): void {
  if (!model.arms[context]) model.arms[context] = defaultArms(context);
  const gamma = 0.9;
  const a = model.arms[context][arm];
  // Per-arm discounting: recent outcomes matter more, so a learner who changes is followed.
  a.alpha = 1 + (a.alpha - 1) * gamma + weight * reward;
  a.beta = 1 + (a.beta - 1) * gamma + weight * (1 - reward);
  a.n += 1;
}

/** Thompson sample over arms, with belief-shifted priors. */
export function chooseSupport(model: LearnerModel, context: string, scope: string | null, now: Date, rnd: () => number, requested: SupportMode | null): { support: SupportMode; reasons: string[]; alternatives: string[] } {
  if (requested) return { support: requested, reasons: [`learner asked for it this turn`], alternatives: [] };
  if (!model.arms[context]) model.arms[context] = defaultArms(context);
  const arms = model.arms[context];
  const reasons: string[] = [];
  const samples: Record<SupportMode, number> = { retrieval_first: 0, hint_first: 0, worked_example_first: 0 };
  for (const m of SUPPORT_MODES) {
    let shift = 0;
    for (const b of model.beliefs) {
      if (b.kind !== "preference" || b.key !== `preference:support:${m}`) continue;
      const inf = beliefInfluence(b, now, scope);
      if (inf > 0) {
        shift += inf * 0.8;
        reasons.push(`belief "${b.statement}" (${b.status}, ${b.confidence.toFixed(2)}) shifts ${m}`);
      }
    }
    const a = arms[m].alpha + shift;
    const b = arms[m].beta;
    samples[m] = betaSample(a, b, rnd);
  }
  const ordered = [...SUPPORT_MODES].sort((x, y) => samples[y] - samples[x]);
  const best = ordered[0];
  const s = arms[best];
  reasons.push(`${best}: posterior mean ${(s.alpha / (s.alpha + s.beta)).toFixed(2)} from ${s.n} attributed outcomes in context "${context}"`);
  return { support: best, reasons, alternatives: ordered.slice(1).map((m) => `${m} (${(arms[m].alpha / (arms[m].alpha + arms[m].beta)).toFixed(2)})`) };
}

// Marsaglia–Tsang gamma sampling → Beta sample; deterministic given rnd.
function gammaSample(k: number, rnd: () => number): number {
  if (k < 1) return gammaSample(k + 1, rnd) * Math.pow(rnd(), 1 / k);
  const d = k - 1 / 3;
  const c = 1 / Math.sqrt(9 * d);
  for (;;) {
    let x: number, v: number;
    do {
      x = normal(rnd);
      v = 1 + c * x;
    } while (v <= 0);
    v = v * v * v;
    const u = rnd();
    if (u < 1 - 0.0331 * x ** 4) return d * v;
    if (Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
  }
}
function normal(rnd: () => number): number {
  const u = Math.max(1e-12, rnd());
  const v = rnd();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}
export function betaSample(a: number, b: number, rnd: () => number): number {
  const x = gammaSample(a, rnd);
  const y = gammaSample(b, rnd);
  return x / (x + y);
}

export function mulberry32(seed: number): () => number {
  let t = seed >>> 0;
  return () => {
    t = (t + 0x6d2b79f5) >>> 0;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r;
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}
