// Memory model for one skill of one learner.
//
// p_recall(now) = pKnown · 2^(-Δt / (stability · forgettingScale))
//
// pKnown is recency-weighted evidence of correct performance (what was
// demonstrated); stability is the half-life in days (how durable it is);
// forgettingScale is a per-learner calibration learned from review outcomes.
// Self-reports never enter pKnown: a claim only sets a prior when nothing has
// been demonstrated (basis = "claimed") and schedules a verification.

import type { SkillState, ItemKind, SupportMode } from "./types";

export const DAY_MS = 86_400_000;

export function newSkillState(skillId: string): SkillState {
  return {
    skillId,
    status: "new",
    basis: "none",
    pKnown: 0.15,
    stability: 0.5,
    lastSuccessAt: null,
    lastAttemptAt: null,
    attempts: 0,
    successes: 0,
    unaidedSuccesses: 0,
    lapses: 0,
    spacedSuccesses: 0,
    transferAttempts: 0,
    transferSuccesses: 0,
    variantsSeen: [],
    claimedLevel: null,
    claimedAt: null,
    taughtAt: null,
    lastSupport: null,
    recent: [],
  };
}

export function daysSince(iso: string | null, now: Date): number {
  if (!iso) return 0;
  return Math.max(0, (now.getTime() - new Date(iso).getTime()) / DAY_MS);
}

/** Predicted probability of recalling the skill right now. */
export function pRecall(state: SkillState, now: Date, forgettingScale = 1): number {
  if (state.basis === "none") return 0.05;
  const anchor = state.lastSuccessAt ?? state.lastAttemptAt;
  const dt = daysSince(anchor, now);
  const halfLife = Math.max(0.05, state.stability * forgettingScale);
  const decay = Math.pow(2, -dt / halfLife);
  const base = state.basis === "claimed" ? Math.min(0.6, state.pKnown) : state.pKnown;
  return clamp(base * decay, 0.01, 0.99);
}

export function clamp(x: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, x));
}

export interface AttemptEffect {
  correct: boolean;
  kind: ItemKind;
  helpGiven: boolean;
  isNovel: boolean;
  variant: string;
  support: SupportMode | null;
  pBefore: number;
  now: Date;
}

/** Pure update of a skill state after a graded attempt. Returns a new state and a description of the change. */
export function applyAttempt(prev: SkillState, e: AttemptEffect): { state: SkillState; changes: string[] } {
  const s: SkillState = { ...prev, recent: [...prev.recent], variantsSeen: [...prev.variantsSeen] };
  const changes: string[] = [];
  const gapDays = daysSince(prev.lastAttemptAt, e.now);
  s.attempts += 1;
  s.lastAttemptAt = e.now.toISOString();
  s.lastSupport = e.support;
  if (!s.variantsSeen.includes(e.variant)) s.variantsSeen.push(e.variant);
  s.recent.push(e.correct ? 1 : 0);
  if (s.recent.length > 10) s.recent.shift();
  if (e.isNovel) {
    s.transferAttempts += 1;
    if (e.correct) s.transferSuccesses += 1;
  }

  // Evidence weight: aided success is weaker evidence of capability than unaided;
  // novel-context success is stronger evidence than a repeated item.
  const weight = e.correct ? (e.helpGiven ? 0.5 : e.isNovel ? 1.2 : 1) : 1;
  const lr = 0.35 * Math.min(1.2, weight);
  const before = s.pKnown;
  s.pKnown = clamp(s.pKnown + lr * ((e.correct ? 1 : 0) - s.pKnown), 0.02, 0.98);
  if (s.basis !== "demonstrated") {
    s.basis = "demonstrated";
    changes.push(`basis → demonstrated (was ${prev.basis})`);
  }

  if (e.correct) {
    s.successes += 1;
    if (!e.helpGiven) s.unaidedSuccesses += 1;
    if (gapDays >= 1) s.spacedSuccesses += 1;
    // Desirable difficulty: the harder the retrieval (low predicted recall), the larger the stability gain.
    const difficultyBonus = 1 + 2.5 * (1 - e.pBefore);
    const kindBonus = e.kind === "transfer" ? 1.3 : e.kind === "apply" ? 1.15 : 1;
    const helpPenalty = e.helpGiven ? 0.6 : 1;
    // Spacing effect: repetitions within the same sitting add little durability; spaced successes add a lot.
    const spacingFactor = gapDays < 0.5 ? 0.12 : 1 + Math.min(1, Math.log2(1 + gapDays) / 3);
    const growth = 1 + 0.8 * difficultyBonus * kindBonus * helpPenalty * spacingFactor;
    const cap = s.spacedSuccesses === 0 ? 3 : 400; // until a spaced retrieval succeeds, half-life cannot exceed 3 days
    s.stability = clamp(Math.max(s.stability, 0.3) * growth, 0.3, cap);
    s.lastSuccessAt = e.now.toISOString();
  } else {
    if (prev.status === "review" || prev.status === "secure") s.lapses += 1;
    s.stability = clamp(s.stability * 0.45, 0.25, 400);
  }
  changes.push(`pKnown ${before.toFixed(2)} → ${s.pKnown.toFixed(2)}, stability ${prev.stability.toFixed(1)}d → ${s.stability.toFixed(1)}d`);

  const status = deriveStatus(s);
  if (status !== prev.status) {
    changes.push(`status ${prev.status} → ${status}`);
    s.status = status;
  }
  return { state: s, changes };
}

export function deriveStatus(s: SkillState): SkillState["status"] {
  if (s.attempts === 0 && !s.taughtAt) return "new";
  const lastTwo = s.recent.slice(-2);
  const recentOk = lastTwo.length === 2 && lastTwo.every((x) => x === 1);
  if (s.pKnown >= 0.8 && s.unaidedSuccesses >= 3 && s.spacedSuccesses >= 2 && s.stability >= 7 && recentOk && s.transferSuccesses >= 1) return "secure";
  if (s.status === "secure" && s.pKnown >= 0.6 && recentOk) return "secure";
  if (s.pKnown >= 0.7 && s.unaidedSuccesses >= 2 && recentOk) return "review";
  return "learning";
}

/** Self-report: sets a prior only if nothing has been demonstrated. Never overrides behaviour. */
export function applyClaim(prev: SkillState, level: number, now: Date): { state: SkillState; changes: string[] } {
  const s = { ...prev };
  const changes: string[] = [];
  s.claimedLevel = clamp(level, 0, 1);
  s.claimedAt = now.toISOString();
  if (prev.basis === "none") {
    s.basis = "claimed";
    s.pKnown = clamp(0.2 + 0.5 * level, 0.1, 0.7);
    s.stability = level >= 0.6 ? 3 : 1;
    changes.push(`claim → prior pKnown ${s.pKnown.toFixed(2)} (basis claimed, to be verified)`);
  } else {
    changes.push(`claim recorded (${level.toFixed(1)}); demonstrated evidence kept (pKnown ${prev.pKnown.toFixed(2)})`);
  }
  return { state: s, changes };
}

/** Durable gap between what is claimed and what is demonstrated. */
export function claimDiscrepancy(s: SkillState): number | null {
  if (s.claimedLevel == null || s.attempts < 3) return null;
  const gap = s.claimedLevel - s.pKnown;
  return Math.abs(gap) >= 0.4 ? gap : null;
}

/**
 * Per-learner forgetting calibration. Multiplicative update on the log-scale
 * from the difference between observed and predicted recall on spaced attempts.
 * scale > 1 → the learner forgets more slowly than the prior model assumed.
 */
export function calibrate(scale: number, n: number, predicted: number, observed: boolean): { scale: number; n: number } {
  const eta = 0.35 / Math.sqrt(1 + n);
  const err = (observed ? 1 : 0) - predicted;
  return { scale: clamp(scale * Math.exp(eta * err), 0.4, 2.5), n: n + 1 };
}

/** Review priority: lowest predicted recall first, with a small tie-break towards fragile memories. */
export function reviewPriority(state: SkillState, now: Date, scale: number): number {
  const p = pRecall(state, now, scale);
  return p - 0.02 * Math.log1p(state.stability);
}
