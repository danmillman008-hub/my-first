// Storage-agnostic types. The core never knows what subject is being learned:
// a "skill" is anything the learner wants to be able to do or recall, an
// "item" is any prompt with a way of judging the response.

// ---------- content contract (world knowledge, no learner information) ----------

export type Grader =
  | { kind: "exact"; accept: string[] }
  | { kind: "keywords"; accept: string[]; all?: boolean }
  | { kind: "numeric"; value: number; tolerance?: number }
  | { kind: "choice"; options: string[]; correct: number }
  | { kind: "self" }; // learner compares own answer with the reference

export type ItemKind = "recall" | "apply" | "transfer" | "discriminate";

export interface ErrorTag {
  match: string[]; // normalised tokens that identify a specific wrong answer
  label: string; // human-readable misconception label
  refutation: string; // why this is wrong, what is right
}

export interface Item {
  id: string;
  skillId: string;
  kind: ItemKind;
  prompt: string;
  answer: string; // reference answer shown as feedback
  grader: Grader;
  hint: string | null;
  variant: string; // context tag, used to detect novel-context (transfer) attempts
  errorTags: ErrorTag[];
  source: ContentSource;
}

export interface Skill {
  id: string;
  goalId: string;
  name: string;
  description: string;
  explanation: string; // teaching kernel
  example: string; // worked example
  prerequisites: string[]; // skill ids
  order: number;
}

export type ContentSource = "llm" | "wikipedia" | "learner" | "scaffold";

export interface ContentPlan {
  topic: string;
  source: ContentSource;
  provenance: string; // e.g. URL or "learner notes"
  skills: Skill[];
  items: Item[];
}

// ---------- learner model (private) ----------

export type SkillStatus = "new" | "learning" | "review" | "secure";
export type Basis = "none" | "claimed" | "demonstrated";

export interface SkillState {
  skillId: string;
  status: SkillStatus;
  basis: Basis;
  pKnown: number; // recency-weighted evidence of correct performance (no forgetting applied)
  stability: number; // memory half-life in days
  lastSuccessAt: string | null; // ISO
  lastAttemptAt: string | null;
  attempts: number;
  successes: number;
  unaidedSuccesses: number; // correct with no help before the attempt
  lapses: number;
  spacedSuccesses: number; // correct after ≥1 day gap
  transferAttempts: number;
  transferSuccesses: number;
  variantsSeen: string[];
  claimedLevel: number | null; // 0..1 self-report
  claimedAt: string | null;
  taughtAt: string | null;
  lastSupport: SupportMode | null;
  recent: number[]; // last outcomes (1/0), newest last
}

export type ErrorStatus = "candidate" | "active" | "resolved";
export interface ErrorPattern {
  id: string;
  skillId: string;
  signature: string;
  label: string;
  refutation: string | null;
  count: number;
  firstAt: string;
  lastAt: string;
  status: ErrorStatus;
  remediatedAt: string | null;
  correctSince: number; // correct attempts on the skill since last occurrence
}

export type BeliefKind = "goal" | "preference" | "tendency" | "context";
export type BeliefStatus = "candidate" | "active" | "contested" | "retired";
export type BeliefSource = "stated" | "inferred";

export interface Belief {
  id: string;
  kind: BeliefKind;
  key: string; // e.g. preference:support:worked_example_first
  statement: string;
  source: BeliefSource;
  status: BeliefStatus;
  confidence: number; // capped Beta mean
  support: number;
  contradiction: number;
  sessionIds: string[];
  scope: string | null; // goal id or null for general
  evidence: { observationId: string; relation: "supports" | "contradicts" | "correction"; at: string }[];
  validFrom: string;
  invalidAt: string | null;
  invalidReason: string | null;
  supersededBy: string | null;
  lastConfirmedAt: string;
  expiresAt: string | null; // temporary context beliefs
}

export type SupportMode = "retrieval_first" | "hint_first" | "worked_example_first";
export const SUPPORT_MODES: SupportMode[] = ["retrieval_first", "hint_first", "worked_example_first"];

export interface ArmStats {
  alpha: number;
  beta: number;
  n: number;
}

export interface Goal {
  id: string;
  text: string;
  topic: string;
  status: "active" | "paused" | "done";
  createdAt: string;
  updatedAt: string;
  source: ContentSource | null;
  provenance: string | null;
}

export interface PendingItem {
  itemId: string;
  skillId: string;
  tutorTurnId: string;
  posedAt: string;
  support: SupportMode | null; // support given before this attempt
  helpGiven: boolean; // any hint/example shown before answering
  awaitingSelfGrade: boolean;
  learnerResponse: string | null; // stored while awaiting self-grade
  isNovel: boolean;
  purpose: Activity;
  nudged: boolean; // a hint was given in place of a requested answer
}

export interface LearnerModel {
  id: string;
  createdAt: string;
  lastSeenAt: string | null;
  currentSessionId: string | null;
  sessionStartedAt: string | null;
  forgettingScale: number; // >1 forgets slower than the prior
  calibrationN: number;
  goals: Goal[];
  skills: Skill[];
  items: Item[];
  states: Record<string, SkillState>;
  errors: ErrorPattern[];
  beliefs: Belief[];
  arms: Record<string, Record<SupportMode, ArmStats>>; // context -> arm stats
  pending: PendingItem | null;
  supportCredits: Record<string, { turnId: string; support: SupportMode; sessionId: string; at: string; context: string }>; // per skill: support awaiting an unaided outcome
  recentSkillIds: string[]; // for interleaving
  turnCount: number;
}

// ---------- append-only evidence ----------

export type ObservationKind =
  | "goal"
  | "answer"
  | "self_grade"
  | "self_report"
  | "request"
  | "question"
  | "correction"
  | "material"
  | "reaction"
  | "statement";

export interface Observation {
  id: string;
  learnerId: string;
  sessionId: string;
  turnId: string;
  kind: ObservationKind;
  content: string;
  signals: Record<string, unknown>;
  dedupeKey: string | null;
  createdAt: string;
}

export interface Attempt {
  id: string;
  learnerId: string;
  sessionId: string;
  turnId: string; // learner turn
  tutorTurnId: string; // turn that posed the item
  itemId: string;
  skillId: string;
  kind: ItemKind;
  response: string;
  correct: boolean;
  score: number;
  grading: "auto" | "self" | "llm";
  pRecallBefore: number;
  helpGiven: boolean;
  isNovel: boolean;
  gapDays: number;
  errorSignature: string | null;
  createdAt: string;
}

export interface SupportOutcome {
  id: string;
  learnerId: string;
  tutorTurnId: string;
  skillId: string;
  context: string;
  support: SupportMode;
  reward: number;
  weight: number;
  reason: string;
  createdAt: string;
}

export type Activity =
  | "onboard"
  | "plan"
  | "teach"
  | "practice"
  | "review"
  | "transfer"
  | "remediate"
  | "verify_claim"
  | "answer_question"
  | "help"
  | "reveal"
  | "await_self_grade"
  | "wrap_up"
  | "clarify";

export interface Trace {
  observed: string[];
  graded: { itemId: string; correct: boolean; score: number; grading: string; errorSignature: string | null } | null;
  attribution: string[];
  modelChanges: string[];
  decision: { activity: Activity; skillId: string | null; itemId: string | null; support: SupportMode | null; reasons: string[]; alternatives: string[] };
}

export interface Turn {
  id: string;
  learnerId: string;
  sessionId: string;
  role: "learner" | "tutor";
  content: string;
  activity: Activity | null;
  skillId: string | null;
  itemId: string | null;
  trace: Trace | null;
  createdAt: string;
}

export interface TurnResult {
  reply: string;
  turn: Turn;
  trace: Trace;
  model: LearnerModel;
}

export interface Ablation {
  explainOnly?: boolean; // no items at all: the "chat tutor" baseline
  noSpacing?: boolean; // reviews not scheduled by predicted recall
  noRemediation?: boolean;
  noTransfer?: boolean;
  fixedSupport?: SupportMode; // no support adaptation
  noMemory?: boolean; // forget the learner between sessions
  noCorrection?: boolean;
  noInterleave?: boolean;
  noCalibration?: boolean;
  supportPolicy?: "rule" | "bandit"; // default rule; bandit kept for the lab (it lost, see docs/EVALUATION.md)
}

export const SESSION_GAP_MS = 45 * 60 * 1000;
