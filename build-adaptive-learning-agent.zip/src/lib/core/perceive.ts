// Deterministic perception. Turns a learner message into flags. It never
// classifies the person; it only reports what this message contains. A model
// provider may add structured signals but may not override these.

import type { Grader, Item, SupportMode } from "./types";

export interface Perception {
  goal: string | null; // a new learning goal expressed in natural language
  switchGoal: boolean;
  isQuestion: boolean;
  isAnswer: boolean;
  dontKnow: boolean;
  selfGrade: "got_it" | "partly" | "missed" | null;
  selfReport: { level: number; text: string } | null;
  request: "hint" | "reveal" | "explain" | "example" | "skip" | "practice" | "review" | "next" | "stop" | "resume" | "pause" | null;
  supportRequest: SupportMode | null;
  correction: { text: string; replacement: string | null } | null;
  reaction: "understood" | "confused" | null;
  material: string | null; // learner-supplied study material
  context: string | null; // temporary context, e.g. "only 5 minutes"
  raw: string;
}

const GOAL_RE = /\b(?:(?:go |switch |get )?back to(?! the open question)|return to|i(?:'d| would)? (?:want|like|need|wish) to (?:learn|understand|get better at|study|master|practi[cs]e|be able to|know)|teach me|help me (?:learn|understand|with|get better at)|learn(?:ing)? (?:about|how to)?|i(?:'m| am) (?:trying|studying) to|can you (?:teach|help) me (?:learn|understand|with)|let'?s (?:learn|study)|i want to be able to)\s+(.+)/i;
const SWITCH_RE = /\b(instead|switch to|something else|different topic|change (?:the )?topic|move on to|let'?s do)\b/i;
const QUESTION_START = /^(what|why|how|when|where|which|who|does|do|is|are|can|could|should|would|will|isn't|aren't|explain)\b/i;
const DONT_KNOW_RE = /^(i (?:don'?t|do not) (?:know|remember|recall)|no idea|not sure|dunno|idk|pass|blank|i forget|i forgot|no clue)\b/i;
const CORRECTION_RE = /\b(that'?s (?:not|un)true about me|(?:you'?re|you are) wrong about me|(?:that'?s|this is) (?:not|un)true|not true about me|stop assuming|you(?:'ve| have)? got (?:me|that) wrong|that'?s not (?:right|correct) about me|i (?:never|didn'?t) say (?:that|i))\b/i;
const CORRECTION_REPLACEMENT_RE = /\b(?:actually|in fact|the truth is|really|instead)[,:]?\s+(.+)$/i;

export function perceive(raw: string, ctx: { hasPending: boolean; awaitingSelfGrade: boolean; hasGoal: boolean }): Perception {
  const text = raw.trim();
  const lower = text.toLowerCase();
  const p: Perception = {
    goal: null, switchGoal: false, isQuestion: false, isAnswer: false, dontKnow: false, selfGrade: null, selfReport: null,
    request: null, supportRequest: null, correction: null, reaction: null, material: null, context: null, raw: text,
  };
  if (!text) return p;

  // Corrections are handled first and the sentence is never parsed as anything else.
  if (CORRECTION_RE.test(text)) {
    const m = text.match(CORRECTION_REPLACEMENT_RE);
    p.correction = { text, replacement: m ? m[1].trim() : null };
    return p;
  }

  if (ctx.awaitingSelfGrade) {
    if (/\b(got it|yes|correct|right|nailed|exactly|same|i did|matches|yep|yeah)\b/i.test(lower) && !/\bnot\b|\bn't\b|partly|partial/i.test(lower)) p.selfGrade = "got_it";
    else if (/\b(part|partly|partial|close|almost|half|mostly|kind of|sort of|some of)\b/i.test(lower)) p.selfGrade = "partly";
    else if (/\b(no|nope|missed|wrong|didn'?t|not really|nothing|blank|different|incorrect)\b/i.test(lower)) p.selfGrade = "missed";
  }

  // Study material: long text with several sentences or lines.
  const lines = text.split(/\n+/).filter((l) => l.trim());
  if ((text.length > 280 && lines.length >= 3) || /^(here (?:are|is) my notes|notes:|material:|study this)/i.test(text)) {
    p.material = text.replace(/^(here (?:are|is) my notes[:\s]*|notes:\s*|material:\s*|study this[:\s]*)/i, "");
  }

  const goalMatch = text.match(GOAL_RE);
  if (goalMatch && !ctx.awaitingSelfGrade) {
    p.goal = goalMatch[1].replace(/[.!?]+$/, "").trim();
    p.switchGoal = ctx.hasGoal && (SWITCH_RE.test(text) || true);
  } else if (!ctx.hasGoal && !ctx.hasPending && !p.material && text.length < 200 && !/\?$/.test(text) && !/^(hi|hello|hey|yo|thanks|thank you|ok|okay)\b/i.test(text)) {
    // No goal yet and this is not a question: treat the message as the goal in the learner's own words.
    p.goal = text.replace(/[.!?]+$/, "").trim();
  }

  // Requests
  if (/^(hint|a hint|give me a hint|any hints?|clue|nudge)\b|\bhint\b.*\?$/i.test(lower)) p.request = "hint";
  else if (/\b(just )?(tell|show|give) me the answer\b|\bwhat'?s the answer\b|\breveal\b|\bjust tell me\b/i.test(lower)) p.request = "reveal";
  else if (/\b(skip|next one|move on|another one|different one)\b/i.test(lower)) p.request = "skip";
  else if (/\b(explain|walk me through|break it down|go over|what does .* mean)\b/i.test(lower) && !ctx.awaitingSelfGrade) p.request = "explain";
  else if (/\b(example|show me|demonstrate|illustrate)\b/i.test(lower)) p.request = "example";
  else if (/\b(quiz me|test me|practi[cs]e|exercise|give me a (?:question|problem|task)|let'?s go|i'?m ready|ready)\b/i.test(lower)) p.request = "practice";
  else if (/\b(review|go back over|revisit|recap)\b/i.test(lower)) p.request = "review";
  else if (/\b(stop|that'?s enough|done for (?:today|now)|bye|goodbye|see you)\b/i.test(lower)) p.request = "stop";
  else if (/\b(pause|later|not now)\b/i.test(lower) && !ctx.hasPending) p.request = "pause";
  else if (/\b(continue|resume|carry on|where were we|pick up)\b/i.test(lower)) p.request = "resume";

  if (/\b(worked example|show me (?:how|an example) first|example first|walk me through (?:one|it) first)\b/i.test(lower)) p.supportRequest = "worked_example_first";
  else if (/\b(hints? first|give me hints|nudge me|don'?t tell me,? just hint)\b/i.test(lower)) p.supportRequest = "hint_first";
  else if (/\b(let me try(?: first)?|don'?t (?:help|tell me)|no hints|i(?:'ll| will) attempt|quiz me cold|test me first)\b/i.test(lower)) p.supportRequest = "retrieval_first";
  if (/\b(i (?:learn|do) (?:best|better) (?:from|with|by) (?:seeing )?(?:worked )?examples|show me examples first)\b/i.test(lower)) p.supportRequest = "worked_example_first";
  if (/\b(i (?:learn|do) (?:best|better) (?:by|when i) (?:trying|struggling|attempting)|i (?:prefer|like) to (?:try|attempt|struggle) first)\b/i.test(lower)) p.supportRequest = "retrieval_first";

  // Self-reports about capability
  const sr = lower.match(/\b(i (?:already )?know (?:this|that|it|all of this|these|the basics)|i'?m (?:an? )?(?:expert|advanced|experienced|fluent|comfortable|pretty good|good) (?:at|with|in)?|i'?ve (?:done|used|studied|worked with) (?:this|that|it)|i(?:'m| am) (?:a )?(?:total |complete )?(?:beginner|novice|new to this|rusty)|(?:this is|it'?s) (?:all )?new to me|never (?:seen|done|heard of) (?:this|that|it)|i'?m (?:weak|bad|terrible|struggling) (?:at|with)|i (?:don'?t|do not) (?:really )?(?:know|understand) (?:this|that|it|any of this))\b/);
  if (sr) {
    const t = sr[1];
    let level = 0.5;
    if (/expert|advanced|fluent|already know|i know (?:this|that|it|all|these|the basics)|comfortable|pretty good|good|done|used|studied|worked/.test(t)) level = 0.8;
    if (/beginner|novice|new to|never|weak|bad|terrible|struggling|don'?t|do not/.test(t)) level = 0.15;
    if (/rusty/.test(t)) level = 0.45;
    p.selfReport = { level, text: t };
  }

  // Reactions (conversational signals; weak evidence, recorded but never treated as capability)
  if (/\b(makes sense|i (?:get|understand|see) it|got it|that helps|clear now|i see)\b/i.test(lower) && !ctx.awaitingSelfGrade) p.reaction = "understood";
  if (/\b(confus(?:ed|ing)|don'?t (?:get|understand|follow)|lost|unclear|what\?|huh)\b/i.test(lower)) p.reaction = "confused";

  // Temporary context
  const c = lower.match(/\b(only (?:have )?\d+ ?(?:min|minutes)|on (?:the|my) (?:train|bus|phone|commute)|tired|exhausted|in a hurry|quick session|short on time|before (?:an|my) (?:exam|test|interview) (?:tomorrow|today|next week))\b/);
  if (c) p.context = c[1];

  p.isQuestion = /\?\s*$/.test(text) || (QUESTION_START.test(text) && text.split(/\s+/).length > 2 && !ctx.awaitingSelfGrade && !ctx.hasPending);
  p.dontKnow = DONT_KNOW_RE.test(lower);

  // An answer: a pending item, and the message is not a command/goal/question about something else.
  if (ctx.hasPending && !ctx.awaitingSelfGrade && !p.goal && !p.request && !p.material && !p.selfGrade && !p.selfReport) {
    if (p.dontKnow) p.isAnswer = true;
    else if (!p.isQuestion || (text.length <= 40 && !QUESTION_START.test(text))) p.isAnswer = true;
  }
  if (p.isAnswer) p.isQuestion = false;
  return p;
}

// ---------- grading ----------

export function normalise(s: string): string {
  return s.toLowerCase().replace(/[`"'“”‘’.,;:!?()[\]{}]/g, " ").replace(/\s+/g, " ").trim();
}

export interface Grade {
  correct: boolean;
  score: number; // 0..1
  errorSignature: string | null;
  errorLabel: string | null;
  refutation: string | null;
  needsSelfGrade: boolean;
}

function tokens(s: string): string[] {
  return normalise(s).split(" ").filter(Boolean);
}

function containsPhrase(hay: string, phrase: string): boolean {
  const h = ` ${normalise(hay)} `;
  const p = normalise(phrase);
  if (!p) return false;
  if (h.includes(` ${p} `)) return true;
  // light stemming: allow the answer to contain the phrase as a prefix of a word (pipe → pipes)
  const words = p.split(" ");
  const hw = tokens(hay);
  return words.every((w) => hw.some((x) => x === w || (w.length >= 4 && x.startsWith(w)) || (x.length >= 4 && w.startsWith(x) && Math.abs(x.length - w.length) <= 2)));
}

export function grade(item: Item, response: string, dontKnow: boolean): Grade {
  const g: Grader = item.grader;
  const base: Grade = { correct: false, score: 0, errorSignature: null, errorLabel: null, refutation: null, needsSelfGrade: false };
  if (dontKnow) return { ...base, errorSignature: "dont_know" };
  const tagged = matchErrorTag(item, response);
  switch (g.kind) {
    case "exact": {
      const r = normalise(response);
      const ok = g.accept.some((a) => normalise(a) === r || r === normalise(a).replace(/\s/g, ""));
      return finish(ok, ok ? 1 : 0);
    }
    case "keywords": {
      const hits = g.accept.filter((k) => containsPhrase(response, k));
      const ok = g.all ? hits.length === g.accept.length : hits.length > 0;
      return finish(ok, g.accept.length ? hits.length / g.accept.length : 0);
    }
    case "numeric": {
      const m = response.replace(/,/g, "").match(/-?\d+(?:\.\d+)?(?:e-?\d+)?/i);
      if (!m) return finish(false, 0);
      const v = parseFloat(m[0]);
      const tol = g.tolerance ?? Math.max(1e-9, Math.abs(g.value) * 0.01);
      const ok = Math.abs(v - g.value) <= tol;
      return finish(ok, ok ? 1 : 0, ok ? null : `num:${m[0]}`);
    }
    case "choice": {
      const idx = parseChoice(response, g.options);
      const ok = idx === g.correct;
      return finish(ok, ok ? 1 : 0, ok || idx == null ? null : `choice:${idx}`);
    }
    case "self":
      return { ...base, needsSelfGrade: true };
  }

  function finish(ok: boolean, score: number, sig?: string | null): Grade {
    if (ok) return { ...base, correct: true, score };
    if (tagged) return { ...base, score, errorSignature: `tag:${tagged.label}`, errorLabel: tagged.label, refutation: tagged.refutation };
    const signature = sig ?? `wrong:${tokens(response).slice(0, 3).join("_") || "empty"}`;
    return { ...base, score, errorSignature: signature };
  }
}

function matchErrorTag(item: Item, response: string) {
  for (const t of item.errorTags) {
    if (t.match.some((m) => containsPhrase(response, m))) return t;
  }
  // choice distractors may be tagged by option text
  if (item.grader.kind === "choice") {
    const idx = parseChoice(response, item.grader.options);
    if (idx != null && idx !== item.grader.correct) {
      const opt = item.grader.options[idx];
      const tag = item.errorTags.find((t) => t.match.some((m) => normalise(m) === normalise(opt)));
      if (tag) return tag;
    }
  }
  return null;
}

export function parseChoice(response: string, options: string[]): number | null {
  const r = normalise(response);
  const letter = r.match(/^\(?([a-d])\)?(?:\s|$)/);
  if (letter) return letter[1].charCodeAt(0) - 97;
  const num = r.match(/^\(?([1-4])\)?(?:\s|$)/);
  if (num) return parseInt(num[1], 10) - 1;
  let best: number | null = null;
  let bestLen = 0;
  options.forEach((o, i) => {
    const n = normalise(o);
    if (n && (r === n || r.includes(n) || (n.length > 12 && n.includes(r) && r.length > 6)) && n.length > bestLen) {
      best = i;
      bestLen = n.length;
    }
  });
  return best;
}

export function selfGradeToGrade(sg: "got_it" | "partly" | "missed"): Grade {
  return { correct: sg === "got_it", score: sg === "got_it" ? 1 : sg === "partly" ? 0.5 : 0, errorSignature: sg === "got_it" ? null : `self:${sg}`, errorLabel: null, refutation: null, needsSelfGrade: false };
}
