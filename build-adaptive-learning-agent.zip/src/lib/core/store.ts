// The only boundary that touches storage. The learner model is one private
// document (mutable, revisable); turns, observations, attempts and support
// outcomes are append-only evidence. World knowledge (content plans) is cached
// separately and never carries a learner id.

import type { Attempt, ContentPlan, LearnerModel, Observation, SupportOutcome, Turn } from "./types";
import type { ContentCache } from "../content";

export interface Store {
  loadModel(learnerId: string): Promise<LearnerModel | null>;
  saveModel(model: LearnerModel): Promise<void>;
  appendTurn(turn: Turn): Promise<void>;
  appendObservations(obs: Observation[]): Promise<void>;
  appendAttempts(attempts: Attempt[]): Promise<void>;
  appendSupportOutcomes(outcomes: SupportOutcome[]): Promise<void>;
  recentTurns(learnerId: string, limit: number): Promise<Turn[]>;
  attempts(learnerId: string): Promise<Attempt[]>;
  observations(learnerId: string, ids?: string[]): Promise<Observation[]>;
  supportOutcomes(learnerId: string): Promise<SupportOutcome[]>;
  erase(learnerId: string): Promise<void>;
  content: ContentCache;
}

export class InMemoryStore implements Store {
  models = new Map<string, LearnerModel>();
  turns: Turn[] = [];
  obs: Observation[] = [];
  atts: Attempt[] = [];
  outs: SupportOutcome[] = [];
  plans = new Map<string, ContentPlan>();

  content: ContentCache = {
    get: async (k) => this.plans.get(k) ?? null,
    put: async (k, p) => {
      this.plans.set(k, p);
    },
  };

  async loadModel(id: string) {
    const m = this.models.get(id);
    return m ? (JSON.parse(JSON.stringify(m)) as LearnerModel) : null;
  }
  async saveModel(m: LearnerModel) {
    this.models.set(m.id, JSON.parse(JSON.stringify(m)));
  }
  async appendTurn(t: Turn) {
    this.turns.push(t);
  }
  async appendObservations(o: Observation[]) {
    this.obs.push(...o);
  }
  async appendAttempts(a: Attempt[]) {
    this.atts.push(...a);
  }
  async appendSupportOutcomes(o: SupportOutcome[]) {
    this.outs.push(...o);
  }
  async recentTurns(id: string, limit: number) {
    return this.turns.filter((t) => t.learnerId === id).slice(-limit);
  }
  async attempts(id: string) {
    return this.atts.filter((a) => a.learnerId === id);
  }
  async observations(id: string, ids?: string[]) {
    return this.obs.filter((o) => o.learnerId === id && (!ids || ids.includes(o.id)));
  }
  async supportOutcomes(id: string) {
    return this.outs.filter((o) => o.learnerId === id);
  }
  async erase(id: string) {
    this.models.delete(id);
    this.turns = this.turns.filter((t) => t.learnerId !== id);
    this.obs = this.obs.filter((o) => o.learnerId !== id);
    this.atts = this.atts.filter((a) => a.learnerId !== id);
    this.outs = this.outs.filter((o) => o.learnerId !== id);
  }
}
