// The tutor loop. One learner, one continuous relationship.
//
//   learner message
//     → session      inferred from time; stale pending items are never attributed
//     → perceive     deterministic flags (goal / answer / request / self-report / correction ...)
//     → grade        the item posed by the previous tutor turn, by id
//     → update       skill memory state, error patterns, calibration, beliefs
//     → attribute    the previous *support* decision, credited only by later unaided success
//     → decide       remediate > verify claim > review due > transfer > practice > teach
//     → compose      templates (a model may answer questions; it never grades in place of evidence)
//     → trace        observed · graded · attribution · model changes · decision with alternatives

import type {
  Ablation, Activity, Attempt, Belief, Goal, Item, ItemKind, LearnerModel, Observation, ObservationKind, PendingItem, Skill, SkillState, SupportMode, SupportOutcome, Trace, Turn, TurnResult,
} from "./types";
import { SESSION_GAP_MS } from "./types";
import { applyAttempt, applyClaim, calibrate, claimDiscrepancy, daysSince, newSkillState, pRecall, reviewPriority } from "./memory";
import { beliefInfluence, chooseSupport, contradictBelief, correctBelief, mulberry32, newId, supportBelief, updateArm } from "./beliefs";
import { grade as gradeItem, perceive, selfGradeToGrade, type Grade, type Perception } from "./perceive";
import { buildPlan } from "../content";
import type { Store } from "./store";
import type { LLM } from "../providers/llm";

export interface EngineDeps {
  store: Store;
  llm?: LLM | null;
  fetchImpl?: typeof fetch | null;
  seed?: number;
  ablation?: Ablation;
}

interface Ctx {
  model: LearnerModel;
  now: Date;
  sessionId: string;
  learnerTurn: Turn;
  p: Perception;
  trace: Trace;
  obs: Observation[];
  attempts: Attempt[];
  outcomes: SupportOutcome[];
  newSession: boolean;
  parts: string[]; // reply fragments
}

export class Engine {
  private store: Store;
  private llm: LLM | null;
  private fetchImpl: typeof fetch | null;
  private rnd: () => number;
  ab: Ablation;

  constructor(deps: EngineDeps) {
    this.store = deps.store;
    this.llm = deps.llm ?? null;
    this.fetchImpl = deps.fetchImpl === undefined ? (typeof fetch === "function" ? fetch : null) : deps.fetchImpl;
    this.rnd = deps.seed != null ? mulberry32(deps.seed) : Math.random;
    this.ab = deps.ablation ?? {};
  }

  id = (prefix: string) => newId(prefix, this.rnd);

  // ------------------------------------------------------------------ public

  async load(learnerId: string, now = new Date()): Promise<LearnerModel> {
    const m = await this.store.loadModel(learnerId);
    return m ?? this.freshModel(learnerId, now);
  }

  async turn(learnerId: string, message: string, now = new Date()): Promise<TurnResult> {
    const model = await this.load(learnerId, now);
    const { sessionId, newSession } = this.session(model, now);
    const learnerTurn: Turn = { id: this.id("t"), learnerId, sessionId, role: "learner", content: message, activity: null, skillId: null, itemId: null, trace: null, createdAt: now.toISOString() };
    const trace: Trace = { observed: [], graded: null, attribution: [], modelChanges: [], decision: { activity: "clarify", skillId: null, itemId: null, support: null, reasons: [], alternatives: [] } };
    const ctx: Ctx = { model, now, sessionId, learnerTurn, p: perceive(message, { hasPending: !!model.pending, awaitingSelfGrade: !!model.pending?.awaitingSelfGrade, hasGoal: model.goals.some((g) => g.status === "active") }), trace, obs: [], attempts: [], outcomes: [], newSession, parts: [] };

    if (newSession) {
      trace.observed.push(`new session (gap ${model.lastSeenAt ? daysSince(model.lastSeenAt, now).toFixed(1) + "d" : "first visit"})`);
      if (model.pending) {
        trace.attribution.push(`pending item from a previous session dropped, not graded (stale)`);
        model.pending = null;
      }
      this.expireContext(ctx);
    }

    this.observe(ctx);
    if (ctx.p.correction) await this.handleCorrection(ctx);
    else {
      this.handleSelfReport(ctx);
      await this.gradeIfAnswer(ctx);
    }
    await this.decide(ctx);

    model.lastSeenAt = now.toISOString();
    model.turnCount += 1;
    const reply = ctx.parts.filter(Boolean).join("\n\n");
    const tutorTurn: Turn = { id: this.id("t"), learnerId, sessionId, role: "tutor", content: reply, activity: trace.decision.activity, skillId: trace.decision.skillId, itemId: trace.decision.itemId, trace, createdAt: new Date(now.getTime() + 1).toISOString() };
    if (model.pending && model.pending.tutorTurnId === "__next__") model.pending.tutorTurnId = tutorTurn.id;
    for (const c of Object.values(model.supportCredits)) if (c.turnId === "__next__") c.turnId = tutorTurn.id;

    await this.store.appendTurn(learnerTurn);
    await this.store.appendObservations(ctx.obs);
    await this.store.appendAttempts(ctx.attempts);
    await this.store.appendSupportOutcomes(ctx.outcomes);
    await this.store.appendTurn(tutorTurn);
    await this.store.saveModel(model);
    return { reply, turn: tutorTurn, trace, model };
  }

  /** Learner correction from the UI: retire a belief by id, optionally replacing it. */
  async correct(learnerId: string, beliefId: string, replacement: string | null, now = new Date()): Promise<{ changes: string[]; model: LearnerModel }> {
    const model = await this.load(learnerId, now);
    const { sessionId } = this.session(model, now);
    const obs: Observation = { id: this.id("o"), learnerId, sessionId, turnId: "ui", kind: "correction", content: replacement ? `belief ${beliefId} is wrong; actually: ${replacement}` : `belief ${beliefId} is wrong`, signals: { beliefId }, dedupeKey: null, createdAt: now.toISOString() };
    const b = model.beliefs.find((x) => x.id === beliefId);
    const changes = this.ab.noCorrection
      ? ["correction ignored (ablation)"]
      : correctBelief(model, beliefId, obs.id, now, replacement && b ? { statement: replacement, kind: b.kind, key: `${b.kind}:stated:${replacement.toLowerCase().slice(0, 40)}` } : null);
    if (b && b.kind === "preference" && !this.ab.noCorrection) {
      // A corrected support preference must also stop biasing the arm: reset that arm's evidence to its prior.
      const m = b.key.split(":")[2] as SupportMode | undefined;
      if (m) for (const c of Object.keys(model.arms)) if (model.arms[c][m]) model.arms[c][m] = { alpha: 1, beta: 1, n: 0 };
      changes.push(`support statistics for ${m} reset to prior`);
    }
    await this.store.appendObservations([obs]);
    await this.store.saveModel(model);
    return { changes, model };
  }

  // ------------------------------------------------------------- sessions

  private freshModel(id: string, now: Date): LearnerModel {
    return { id, createdAt: now.toISOString(), lastSeenAt: null, currentSessionId: null, sessionStartedAt: null, forgettingScale: 1, calibrationN: 0, goals: [], skills: [], items: [], states: {}, errors: [], beliefs: [], arms: {}, pending: null, supportCredits: {}, recentSkillIds: [], turnCount: 0 };
  }

  private session(model: LearnerModel, now: Date): { sessionId: string; newSession: boolean } {
    const gap = model.lastSeenAt ? now.getTime() - new Date(model.lastSeenAt).getTime() : Infinity;
    if (model.currentSessionId && gap < SESSION_GAP_MS) return { sessionId: model.currentSessionId, newSession: false };
    model.currentSessionId = this.id("s");
    model.sessionStartedAt = now.toISOString();
    if (this.ab.noMemory && model.turnCount > 0) {
      // Ablation: no continuity between sessions. Content stays, everything learned about the learner is dropped.
      model.states = {};
      model.beliefs = model.beliefs.filter((b) => b.kind === "goal");
      model.errors = [];
      model.arms = {};
      model.supportCredits = {};
      model.forgettingScale = 1;
      model.calibrationN = 0;
    }
    return { sessionId: model.currentSessionId, newSession: true };
  }

  private expireContext(ctx: Ctx) {
    for (const b of ctx.model.beliefs) {
      if (b.kind === "context" && b.status !== "retired" && (!b.expiresAt || new Date(b.expiresAt).getTime() <= ctx.now.getTime())) {
        b.status = "retired";
        b.invalidAt = ctx.now.toISOString();
        b.invalidReason = "expired";
        ctx.trace.modelChanges.push(`context "${b.statement}" expired`);
      }
    }
  }

  // ----------------------------------------------------------- observation

  private obs(ctx: Ctx, kind: ObservationKind, content: string, signals: Record<string, unknown> = {}): Observation {
    const dedupeKey = `${kind}:${content.toLowerCase().slice(0, 80)}`;
    const o: Observation = { id: this.id("o"), learnerId: ctx.model.id, sessionId: ctx.sessionId, turnId: ctx.learnerTurn.id, kind, content, signals, dedupeKey, createdAt: ctx.now.toISOString() };
    ctx.obs.push(o);
    return o;
  }

  private observe(ctx: Ctx) {
    const { p, trace } = ctx;
    if (p.goal) trace.observed.push(`goal expressed: "${p.goal}"`);
    if (p.isAnswer) trace.observed.push(p.dontKnow ? "answer: doesn't know" : "answer to the pending item");
    if (p.selfGrade) trace.observed.push(`self-grade: ${p.selfGrade}`);
    if (p.isQuestion) trace.observed.push("question");
    if (p.request) trace.observed.push(`request: ${p.request}`);
    if (p.supportRequest) trace.observed.push(`support requested: ${p.supportRequest}`);
    if (p.selfReport) trace.observed.push(`self-report: "${p.selfReport.text}" (~${p.selfReport.level})`);
    if (p.correction) trace.observed.push("correction about the learner model");
    if (p.material) trace.observed.push(`study material (${p.material.length} chars)`);
    if (p.reaction) trace.observed.push(`reaction: ${p.reaction} (conversational signal only)`);
    if (p.context) trace.observed.push(`context: ${p.context}`);
    if (p.reaction) this.obs(ctx, "reaction", p.reaction);
    if (p.isQuestion) this.obs(ctx, "question", p.raw);
    if (p.request || p.supportRequest) {
      const o = this.obs(ctx, "request", p.supportRequest ?? p.request ?? "", { request: p.request, support: p.supportRequest });
      if (p.supportRequest) {
        const goal = this.activeGoal(ctx.model);
        ctx.trace.modelChanges.push(...supportBelief(ctx.model, { kind: "preference", key: `preference:support:${p.supportRequest}`, statement: `prefers ${label(p.supportRequest)} when starting something new`, source: /learn (?:best|better)|prefer|like to/i.test(p.raw) ? "stated" : "inferred", scope: goal?.id ?? null, observationId: o.id, sessionId: ctx.sessionId, now: ctx.now, rnd: this.rnd }));
      }
    }
    if (p.context) {
      const o = this.obs(ctx, "statement", p.context);
      const expires = new Date(ctx.now.getTime() + 6 * 3600_000).toISOString();
      ctx.trace.modelChanges.push(...supportBelief(ctx.model, { kind: "context", key: `context:${p.context.replace(/\s+/g, "_")}`, statement: `right now: ${p.context}`, source: "stated", scope: null, observationId: o.id, sessionId: ctx.sessionId, now: ctx.now, expiresAt: expires, rnd: this.rnd }));
    }
  }

  // --------------------------------------------------------- corrections

  private async handleCorrection(ctx: Ctx) {
    const { model, p, trace } = ctx;
    const o = this.obs(ctx, "correction", p.raw);
    if (this.ab.noCorrection) {
      ctx.parts.push("Noted.");
      trace.decision.reasons.push("correction ignored (ablation)");
      return;
    }
    // Which belief? Prefer one named in the message, else the ones that influenced the most recent decision.
    const live = model.beliefs.filter((b) => b.status !== "retired" && b.kind !== "goal");
    const words = p.raw.toLowerCase().split(/\W+/).filter((w) => w.length > 3);
    let targets = live.filter((b) => words.some((w) => b.statement.toLowerCase().includes(w) && !["about", "that", "true", "wrong"].includes(w)));
    if (!targets.length) {
      const recent = await this.store.recentTurns(model.id, 6);
      const influenced = new Set<string>();
      for (const t of recent) for (const r of t.trace?.decision.reasons ?? []) for (const b of live) if (r.includes(b.statement)) influenced.add(b.id);
      targets = live.filter((b) => influenced.has(b.id));
    }
    if (!targets.length) targets = live.filter((b) => b.source === "inferred").sort((a, b) => b.lastConfirmedAt.localeCompare(a.lastConfirmedAt)).slice(0, 1);
    if (!targets.length) {
      ctx.parts.push("Thanks for telling me. I don't currently hold any inferred belief about you that I'm acting on — you can see everything I do assume in the model panel, and mark anything there as wrong.");
    } else {
      const replacement = p.correction!.replacement;
      for (const b of targets) {
        trace.modelChanges.push(...correctBelief(model, b.id, o.id, ctx.now, replacement ? { statement: replacement, kind: b.kind, key: `${b.kind}:stated:${replacement.toLowerCase().slice(0, 40)}` } : null));
        if (b.kind === "preference") {
          const m = b.key.split(":")[2] as SupportMode | undefined;
          if (m) for (const c of Object.keys(model.arms)) if (model.arms[c][m]) model.arms[c][m] = { alpha: 1, beta: 1, n: 0 };
        }
      }
      ctx.parts.push(`Understood — I've retired ${targets.length === 1 ? `the assumption "${targets[0].statement}"` : `${targets.length} assumptions`} and will stop acting on ${targets.length === 1 ? "it" : "them"}. ${replacement ? `I've recorded instead: "${replacement}".` : "If there's something true instead, tell me and I'll record that."}`);
    }
    trace.decision = { activity: "clarify", skillId: null, itemId: null, support: null, reasons: ["learner corrected the model; the sentence was not parsed as anything else"], alternatives: [] };
    if (model.pending && !model.pending.awaitingSelfGrade) {
      const it = this.item(model, model.pending.itemId);
      if (it) ctx.parts.push(`Whenever you're ready, the question is still open: ${it.prompt}`);
    }
  }

  // --------------------------------------------------------- self-reports

  private handleSelfReport(ctx: Ctx) {
    const { model, p, trace } = ctx;
    if (!p.selfReport) return;
    const o = this.obs(ctx, "self_report", p.selfReport.text, { level: p.selfReport.level });
    // Which skill? the pending one, else a skill named in the message, else the goal's first non-secure skill.
    const named = model.skills.filter((s) => s.goalId === this.activeGoal(model)?.id && p.raw.toLowerCase().includes(s.name.toLowerCase().split(":").pop()!.trim()));
    const skillIds = model.pending ? [model.pending.skillId] : named.length ? named.map((s) => s.id) : /all of this|the basics|this|these/i.test(p.selfReport.text) ? this.goalSkills(model).map((s) => s.id) : [];
    for (const id of skillIds) {
      const prev = this.state(model, id);
      const { state, changes } = applyClaim(prev, p.selfReport.level, ctx.now);
      model.states[id] = state;
      trace.modelChanges.push(...changes.map((c) => `${this.skillName(model, id)}: ${c}`));
    }
    if (skillIds.length) trace.attribution.push(`self-report applied to ${skillIds.length} skill(s) as a claim, not as evidence`);
    void o;
  }

  // ---------------------------------------------------------- grading

  private async gradeIfAnswer(ctx: Ctx) {
    const { model, p, trace } = ctx;
    const pend = model.pending;
    if (!pend) return;
    const item = this.item(model, pend.itemId);
    if (!item) {
      model.pending = null;
      return;
    }
    let g: Grade | null = null;
    let grading: Attempt["grading"] = "auto";
    let response = p.raw;
    if (pend.awaitingSelfGrade) {
      if (!p.selfGrade) return; // still waiting; decide() will re-ask
      g = selfGradeToGrade(p.selfGrade);
      grading = "self";
      response = pend.learnerResponse ?? "";
      this.obs(ctx, "self_grade", p.selfGrade);
    } else if (p.isAnswer) {
      {
        this.obs(ctx, "answer", p.raw, { itemId: item.id });
        g = gradeItem(item, p.raw, p.dontKnow);
        if (g.needsSelfGrade) {
          if (this.llm) {
            const verdict = await this.llm.json<{ correct?: boolean; score?: number; error?: string | null }>(
              "You grade a learner's answer against a reference. Be strict about the core idea, lenient about wording. JSON: {\"correct\": boolean, \"score\": 0..1, \"error\": short description of the misconception if wrong else null}",
              `Question: ${item.prompt}\nReference answer: ${item.answer}\nLearner answer: ${p.raw}`,
              200,
            );
            if (verdict && typeof verdict.correct === "boolean") {
              g = { correct: verdict.correct, score: typeof verdict.score === "number" ? Math.max(0, Math.min(1, verdict.score)) : verdict.correct ? 1 : 0, errorSignature: verdict.correct ? null : `llm:${(verdict.error ?? "wrong").toLowerCase().slice(0, 40)}`, errorLabel: verdict.error ?? null, refutation: null, needsSelfGrade: false };
              grading = "llm";
            }
          }
          if (g.needsSelfGrade) {
            // Reveal the reference and ask the learner to compare. The attempt is recorded next turn.
            pend.awaitingSelfGrade = true;
            pend.learnerResponse = p.raw;
            trace.decision = { activity: "await_self_grade", skillId: item.skillId, itemId: item.id, support: pend.support, reasons: ["open-ended item: learner compares their answer with the reference (self-grading is retrieval practice too, and it is recorded as a separate evidence channel)"], alternatives: [] };
            ctx.parts.push(`Here's the reference to compare against:\n\n> ${item.answer}\n\nHow did you do — **got it**, **partly**, or **missed**? Be honest; the model only helps you if it's fed the truth.`);
            return;
          }
        }
      }
    } else {
      return; // not an answer: question/request handled in decide()
    }

    // ---- record the attempt against the exact item posed, by id ----
    const st = this.state(model, item.skillId);
    const pBefore = pRecall(st, ctx.now, model.forgettingScale);
    const gapDays = daysSince(st.lastAttemptAt, ctx.now);
    const attempt: Attempt = { id: this.id("a"), learnerId: model.id, sessionId: ctx.sessionId, turnId: ctx.learnerTurn.id, tutorTurnId: pend.tutorTurnId, itemId: item.id, skillId: item.skillId, kind: item.kind, response, correct: g.correct, score: g.score, grading, pRecallBefore: pBefore, helpGiven: pend.helpGiven, isNovel: pend.isNovel, gapDays, errorSignature: g.errorSignature, createdAt: ctx.now.toISOString() };
    ctx.attempts.push(attempt);
    trace.graded = { itemId: item.id, correct: g.correct, score: g.score, grading, errorSignature: g.errorSignature };
    trace.attribution.push(`graded against item ${item.id} posed by turn ${pend.tutorTurnId}${pend.helpGiven ? " (help was given before this attempt)" : ""}${pend.isNovel ? " (novel context)" : ""}`);

    // ---- calibration on spaced attempts (before the update, against the prediction) ----
    if (gapDays >= 0.5 && st.basis === "demonstrated" && !this.ab.noCalibration) {
      const c = calibrate(model.forgettingScale, model.calibrationN, pBefore, g.correct);
      if (Math.abs(c.scale - model.forgettingScale) > 0.005) trace.modelChanges.push(`forgetting calibration ${model.forgettingScale.toFixed(2)} → ${c.scale.toFixed(2)} (predicted ${pBefore.toFixed(2)}, observed ${g.correct ? 1 : 0})`);
      model.forgettingScale = c.scale;
      model.calibrationN = c.n;
    }

    // ---- memory state ----
    const { state, changes } = applyAttempt(st, { correct: g.correct, kind: item.kind, helpGiven: pend.helpGiven, isNovel: pend.isNovel, variant: item.variant, support: pend.support, pBefore, now: ctx.now });
    model.states[item.skillId] = state;
    trace.modelChanges.push(...changes.map((c) => `${this.skillName(model, item.skillId)}: ${c}`));

    // ---- claim vs behaviour ----
    const gap = claimDiscrepancy(state);
    if (gap != null) {
      const key = gap > 0 ? "tendency:overestimates" : "tendency:underestimates";
      const o = this.obs(ctx, "statement", `claim/behaviour gap ${gap.toFixed(2)} on ${this.skillName(model, item.skillId)}`);
      trace.modelChanges.push(...supportBelief(model, { kind: "tendency", key, statement: gap > 0 ? "self-assessments tend to run ahead of demonstrated performance" : "self-assessments tend to run behind demonstrated performance", source: "inferred", scope: null, observationId: o.id, sessionId: ctx.sessionId, now: ctx.now, rnd: this.rnd }));
    } else if (state.claimedLevel != null && state.attempts >= 3) {
      const o = ctx.obs[ctx.obs.length - 1];
      trace.modelChanges.push(...contradictBelief(model, "tendency:overestimates", null, o.id, ctx.now), ...contradictBelief(model, "tendency:underestimates", null, o.id, ctx.now));
    }

    // ---- error patterns ----
    this.updateErrors(ctx, item, g);

    // ---- support attribution: credit the previous support decision on this skill by THIS unaided outcome ----
    this.attributeSupport(ctx, item, pend, g.correct, pBefore);

    // ---- feedback ----
    this.composeFeedback(ctx, item, g, pend, state);
    model.pending = null;
    model.recentSkillIds.push(item.skillId);
    if (model.recentSkillIds.length > 6) model.recentSkillIds.shift();
  }

  private updateErrors(ctx: Ctx, item: Item, g: Grade) {
    const { model, trace } = ctx;
    const iso = ctx.now.toISOString();
    if (g.correct) {
      for (const e of model.errors) {
        if (e.skillId !== item.skillId || e.status === "resolved") continue;
        e.correctSince += 1;
        if (e.correctSince >= 2 && (e.status === "active" ? e.remediatedAt : true)) {
          e.status = "resolved";
          trace.modelChanges.push(`error pattern "${e.label}" resolved (2 correct since)`);
        }
      }
      return;
    }
    if (!g.errorSignature || g.errorSignature === "dont_know" || g.errorSignature.startsWith("self:") || g.errorSignature === "asked_for_answer") return;
    let e = model.errors.find((x) => x.skillId === item.skillId && x.signature === g.errorSignature && x.status !== "resolved");
    if (!e) {
      e = { id: this.id("e"), skillId: item.skillId, signature: g.errorSignature, label: g.errorLabel ?? `recurring answer "${g.errorSignature.replace(/^(wrong|num|choice|llm):/, "")}"`, refutation: g.refutation, count: 0, firstAt: iso, lastAt: iso, status: "candidate", remediatedAt: null, correctSince: 0 };
      model.errors.push(e);
    }
    e.count += 1;
    e.lastAt = iso;
    e.correctSince = 0;
    const threshold = e.signature.startsWith("tag:") || e.signature.startsWith("llm:") || e.signature.startsWith("choice:") ? 2 : 3;
    if (e.count >= threshold && e.status === "candidate") {
      e.status = "active";
      trace.modelChanges.push(`persistent error pattern on ${this.skillName(model, item.skillId)}: "${e.label}" (${e.count}×) → will remediate`);
    } else trace.modelChanges.push(`error signature "${g.errorSignature}" on ${this.skillName(model, item.skillId)} (${e.count}×, ${e.status})`);
  }

  private attributeSupport(ctx: Ctx, item: Item, pend: PendingItem, correct: boolean, pBefore: number) {
    const { model, trace } = ctx;
    const credit = model.supportCredits[item.skillId];
    if (!credit) return;
    if (credit.turnId === pend.tutorTurnId) {
      trace.attribution.push(`immediate outcome after support "${credit.support}" not used as reward (performance ≠ learning); waiting for the next unaided attempt on this skill`);
      return;
    }
    if (pend.helpGiven) {
      trace.attribution.push(`aided attempt: support "${credit.support}" still awaiting an unaided attempt`);
      return;
    }
    // The support given earlier is credited by the first LATER unaided attempt on the same skill.
    let weight = credit.sessionId === ctx.sessionId ? 1 : 0.6;
    const reasons: string[] = [credit.sessionId === ctx.sessionId ? "same session" : "later session (spacing confound, down-weighted)"];
    if (pBefore > 0.85) {
      weight *= 0.3;
      reasons.push("skill was already likely known (mastery confound, down-weighted)");
    }
    if (daysSince(credit.at, ctx.now) > 30) {
      weight *= 0.3;
      reasons.push(">30 days later");
    }
    if (!this.ab.fixedSupport) updateArm(model, credit.context, credit.support, correct ? 1 : 0, weight); // kept for inspection even under the rule policy
    ctx.outcomes.push({ id: this.id("so"), learnerId: model.id, tutorTurnId: credit.turnId, skillId: item.skillId, context: credit.context, support: credit.support, reward: correct ? 1 : 0, weight, reason: reasons.join("; "), createdAt: ctx.now.toISOString() });
    trace.attribution.push(`support "${credit.support}" (turn ${credit.turnId}) credited with ${correct ? "success" : "failure"} at weight ${weight.toFixed(2)}: ${reasons.join("; ")}`);
    delete model.supportCredits[item.skillId];
    // Preference beliefs are supported/contradicted by what the support produced, under the same attribution rules.
    const goal = this.activeGoal(model);
    const o = ctx.obs.find((x) => x.kind === "answer" || x.kind === "self_grade") ?? ctx.obs[ctx.obs.length - 1];
    // Outcome statistics are observations, not beliefs (an inferred "preference" from them proved self-reinforcing in the lab).
    // A STATED preference, however, is checked against what follows it: successes support it, failures contest it.
    const stated = model.beliefs.find((b) => b.key === `preference:support:${credit.support}` && b.source === "stated" && b.status !== "retired");
    if (o && weight >= 0.5 && stated) {
      if (correct) trace.modelChanges.push(...supportBelief(model, { kind: "preference", key: stated.key, statement: stated.statement, source: "stated", scope: stated.scope, observationId: o.id, sessionId: ctx.sessionId, now: ctx.now, rnd: this.rnd }));
      else trace.modelChanges.push(...contradictBelief(model, stated.key, goal?.id ?? null, o.id, ctx.now));
    }
  }

  private composeFeedback(ctx: Ctx, item: Item, g: Grade, pend: PendingItem, state: SkillState) {
    const { model } = ctx;
    const name = this.skillName(model, item.skillId);
    const scale = model.forgettingScale;
    if (g.correct) {
      const days = Math.max(1, Math.round(state.stability * scale * 0.9));
      const spaced = pend.purpose === "review" ? " — and it held across the gap" : "";
      ctx.parts.push(`✅ Right${spaced}. ${item.grader.kind === "self" ? "" : `(Reference: ${item.answer})`} Memory for *${name}* is ${state.status === "secure" ? "secure" : state.status === "review" ? "in review" : "still forming"}; I'll check it again in about ${days} day${days === 1 ? "" : "s"}.`);
      return;
    }
    if (g.errorSignature === "dont_know") {
      ctx.parts.push(`No problem — not knowing and then seeing the answer is still a useful retrieval attempt.\n\n**Answer:** ${item.answer}`);
    } else if (g.errorSignature === "asked_for_answer") {
      ctx.parts.push(`Here it is — but note: answers seen before an attempt are much less likely to stick than answers retrieved after one, so next time I'll give you a hint first.\n\n**Answer:** ${item.answer}`);
    } else if (g.refutation) {
      ctx.parts.push(`Not quite — this looks like a common mix-up: **${g.errorLabel}**. ${g.refutation}\n\n**Answer:** ${item.answer}`);
    } else if (item.grader.kind === "self" && g.score === 0.5) {
      ctx.parts.push(`Partly there. Read the reference once more and notice which part you left out — that's the part we'll come back to.`);
    } else {
      ctx.parts.push(`Not quite.${pend.helpGiven ? "" : ""} **Answer:** ${item.answer}`);
    }
    const sk = this.skill(model, item.skillId);
    if (sk && pend.purpose === "teach" && !pend.helpGiven) ctx.parts.push(`Now the explanation — it should land better after the attempt:\n\n**${sk.name}.** ${sk.explanation}${sk.example ? `\n\nExample: ${sk.example}` : ""}`);
    else if (sk && !pend.helpGiven && item.grader.kind !== "self") ctx.parts.push(`Why: ${sk.explanation.split(/(?<=\.)\s/).slice(0, 2).join(" ")}`);
  }

  // ------------------------------------------------------------ decisions

  private async decide(ctx: Ctx) {
    const { model, p, trace } = ctx;
    if (trace.decision.activity === "await_self_grade" || p.correction) return;

    // Still awaiting a self-grade and the learner said something else.
    if (model.pending?.awaitingSelfGrade) {
      if (p.goal || p.request === "skip" || p.request === "stop") model.pending = null;
      else {
        trace.decision = { activity: "await_self_grade", skillId: model.pending.skillId, itemId: model.pending.itemId, support: null, reasons: ["still waiting for the self-grade"], alternatives: [] };
        ctx.parts.push("Before we move on: compared with the reference, was your answer **got it**, **partly**, or **missed**?");
        return;
      }
    }

    // Goals
    if (p.goal) {
      await this.startGoal(ctx, p.goal, p.material);
      return;
    }
    if (p.material) {
      const goal = this.activeGoal(model);
      await this.startGoal(ctx, goal ? goal.text : firstLine(p.material), p.material, goal ?? undefined);
      return;
    }
    if (p.request === "stop" || p.request === "pause") {
      if (p.request === "pause") for (const g of model.goals) if (g.status === "active") g.status = "paused";
      this.wrapUp(ctx);
      return;
    }
    if (p.request === "resume") {
      const paused = model.goals.filter((g) => g.status === "paused").sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];
      if (paused && !this.activeGoal(model)) {
        paused.status = "active";
        paused.updatedAt = ctx.now.toISOString();
        trace.modelChanges.push(`goal "${paused.text}" resumed`);
      }
    }
    const goal = this.activeGoal(model);
    if (!goal) {
      trace.decision = { activity: "onboard", skillId: null, itemId: null, support: null, reasons: ["no active goal"], alternatives: [] };
      ctx.parts.push(model.goals.length ? `Welcome back. Your goals so far: ${model.goals.map((g) => `"${g.text}" (${g.status})`).join(", ")}. Say "continue" to resume, or tell me something new you want to learn.` : `Hi. I'm a tutor built around one long relationship: I'll build a model of what you can actually do — from evidence, not just what either of us assumes — and use it to decide what you should attempt next.\n\nWhat do you want to learn? Say it however you like — a subject, a skill, a problem you're stuck on, or paste some notes.`);
      return;
    }

    // Pending item and a non-answer message (question, hint, explain, example, skip)
    if (model.pending) {
      const item = this.item(model, model.pending.itemId)!;
      if (p.request === "skip") {
        trace.attribution.push("item skipped; not graded");
        model.pending = null;
        model.recentSkillIds.push(item.skillId);
      } else if (p.request === "reveal") {
        await this.handleReveal(ctx, item);
        return;
      } else if (p.request === "hint" || p.request === "explain" || p.request === "example" || p.supportRequest) {
        await this.help(ctx, item, p.request ?? "hint");
        return;
      } else if (p.selfReport && !trace.graded) {
        model.pending.purpose = "verify_claim";
        trace.decision = { activity: "verify_claim", skillId: item.skillId, itemId: item.id, support: model.pending.support, reasons: ["self-report recorded as a claim; the open item now serves to verify it rather than assume"], alternatives: ["trust the claim and skip ahead (rejected: claims are priors, not evidence)"] };
        ctx.parts.push(`Noted — I've recorded that as what you believe about yourself, not as evidence yet. Rather than assume, let's verify with the open question: ${item.prompt}`);
        return;
      } else if (p.isQuestion) {
        await this.answerQuestion(ctx, item.skillId, item);
        return;
      } else if (!p.isAnswer && !trace.graded) {
        trace.decision = { activity: "clarify", skillId: item.skillId, itemId: item.id, support: null, reasons: ["message did not look like an answer, a question or a request; the item stays open"], alternatives: [] };
        ctx.parts.push(`I wasn't sure whether that was your answer. The open question is: ${item.prompt}\n\n(You can also say "hint", "skip", "I don't know", or ask me anything.)`);
        return;
      }
    } else if (p.isQuestion) {
      await this.answerQuestion(ctx, null, null);
      if (!this.ab.explainOnly) await this.next(ctx, goal, true);
      return;
    } else if (p.request === "explain" || p.request === "example") {
      const sk = this.currentSkill(ctx, goal);
      if (sk) {
        ctx.parts.push(`**${sk.name}.** ${sk.explanation}${p.request === "example" && sk.example ? `\n\nExample: ${sk.example}` : ""}`);
        trace.decision.reasons.push("explicit request for explanation honoured");
      }
    }
    await this.next(ctx, goal, false);
  }

  private async startGoal(ctx: Ctx, text: string, material: string | null | undefined, existing?: Goal) {
    const { model, trace } = ctx;
    const o = this.obs(ctx, material ? "material" : "goal", material ? `${text} (${material.length} chars)` : text);
    let goal = existing ?? null;
    if (!goal) {
      const same = model.goals.find((g) => g.text.toLowerCase() === text.toLowerCase());
      for (const g of model.goals) if (g.status === "active" && g !== same) g.status = "paused";
      if (same) {
        same.status = "active";
        same.updatedAt = ctx.now.toISOString();
        goal = same;
        trace.modelChanges.push(`goal "${text}" reactivated`);
      } else {
        goal = { id: this.id("g"), text, topic: text, status: "active", createdAt: ctx.now.toISOString(), updatedAt: ctx.now.toISOString(), source: null, provenance: null };
        model.goals.push(goal);
        trace.modelChanges.push(`new active goal "${text}"${model.goals.length > 1 ? " (previous goal paused, its evidence kept)" : ""}`);
        trace.modelChanges.push(...supportBelief(model, { kind: "goal", key: `goal:${goal.id}`, statement: `wants to: ${text}`, source: "stated", scope: goal.id, observationId: o.id, sessionId: ctx.sessionId, now: ctx.now, rnd: this.rnd }));
      }
    }
    model.pending = null;
    const hasContent = model.skills.some((s) => s.goalId === goal!.id);
    if (!hasContent || material) {
      const plan = await buildPlan(text, goal.id, { llm: this.llm, cache: this.store.content, fetchImpl: this.fetchImpl, idFactory: this.id }, material ?? null);
      if (material) {
        plan.skills.forEach((s, i) => (s.order = 100 + i));
      }
      if (!hasContent) {
        goal.source = plan.source;
        goal.provenance = plan.provenance;
        goal.topic = plan.topic;
      }
      model.skills.push(...plan.skills);
      model.items.push(...plan.items);
      trace.modelChanges.push(`content plan from ${plan.source}: ${plan.skills.length} skills, ${plan.items.length} items (${plan.provenance})`);
      const intro = plan.source === "scaffold"
        ? `I don't have reference material for **${plan.topic}** and no model or research source is configured, so I'll run the learning loop on your own knowledge and sources: I'll prompt you to retrieve, you compare with your material and grade honestly, and I track what sticks. Paste notes at any time and I'll turn them into practice.`
        : `Plan for **${plan.topic}** (${plan.source === "llm" ? "generated" : plan.source === "wikipedia" ? `from ${plan.provenance}` : "from your notes"}): ${plan.skills.map((s) => s.name.replace(/^.*?:\s*/, "")).join(" → ")}.\n\nI'll teach, then make you retrieve, come back to things as they start to fade, and vary the context so it transfers. Tell me at any point if you already know something — I'll verify rather than assume.`;
      ctx.parts.push(intro);
    } else {
      ctx.parts.push(`Back to **${goal.topic}**. ${this.progressLine(model, goal)}`);
    }
    if (this.ab.explainOnly) {
      const sk = this.goalSkills(model, goal)[0];
      if (sk) ctx.parts.push(`**${sk.name}.** ${sk.explanation}${sk.example ? `\n\nExample: ${sk.example}` : ""}`);
      trace.decision = { activity: "teach", skillId: sk?.id ?? null, itemId: null, support: null, reasons: ["explain-only ablation"], alternatives: [] };
      return;
    }
    await this.next(ctx, goal, false);
  }

  /** "Just tell me." Record the tendency; once established, nudge with a hint first; otherwise reveal and record a non-retrieval. */
  private async handleReveal(ctx: Ctx, item: Item) {
    const { model, trace } = ctx;
    const pend = model.pending!;
    const sk = this.skill(model, item.skillId)!;
    const o = this.obs(ctx, "request", "reveal before attempting");
    trace.modelChanges.push(...supportBelief(model, { kind: "tendency", key: "tendency:asks_before_attempting", statement: "tends to ask for the answer before attempting", source: "inferred", scope: null, observationId: o.id, sessionId: ctx.sessionId, now: ctx.now, rnd: this.rnd }));
    const crutch = model.beliefs.find((b) => b.key === "tendency:asks_before_attempting" && (b.status === "active" || b.status === "contested"));
    if (crutch && !pend.nudged) {
      pend.nudged = true;
      pend.helpGiven = true;
      trace.decision = { activity: "help", skillId: item.skillId, itemId: item.id, support: pend.support, reasons: [`belief "${crutch.statement}" (${crutch.status}, confidence ${crutch.confidence.toFixed(2)}) → a hint first instead of the answer; answers seen before an attempt are poorly retained`], alternatives: ["reveal the answer (will happen if asked again)"] };
      ctx.parts.push(`I'll give you a nudge first — you've been asking for answers early, and answers you retrieve yourself stick far better than ones you read.\n\nHint: ${item.hint ?? sk.explanation.split(/(?<=\.)\s/)[0]}\n\nTry: ${item.prompt}\n\n(If it's really not coming, say "just tell me" again and I will. And if I'm wrong about you, say so.)`);
      return;
    }
    const st = this.state(model, item.skillId);
    const pBefore = pRecall(st, ctx.now, model.forgettingScale);
    const { state, changes } = applyAttempt(st, { correct: false, kind: item.kind, helpGiven: true, isNovel: pend.isNovel, variant: item.variant, support: pend.support, pBefore, now: ctx.now });
    model.states[item.skillId] = state;
    trace.modelChanges.push(...changes.map((c) => `${sk.name}: ${c}`));
    ctx.attempts.push({ id: this.id("a"), learnerId: model.id, sessionId: ctx.sessionId, turnId: ctx.learnerTurn.id, tutorTurnId: pend.tutorTurnId, itemId: item.id, skillId: item.skillId, kind: item.kind, response: "(asked for the answer)", correct: false, score: 0, grading: "auto", pRecallBefore: pBefore, helpGiven: true, isNovel: pend.isNovel, gapDays: daysSince(st.lastAttemptAt, ctx.now), errorSignature: "asked_for_answer", createdAt: ctx.now.toISOString() });
    trace.graded = { itemId: item.id, correct: false, score: 0, grading: "auto", errorSignature: "asked_for_answer" };
    trace.attribution.push(`answer revealed on request: recorded as a non-retrieval against item ${item.id}`);
    trace.decision = { activity: "reveal", skillId: item.skillId, itemId: item.id, support: null, reasons: [crutch ? "learner asked again after the hint; revealing" : "learner asked for the answer; revealing, recorded as not retrieved"], alternatives: [] };
    ctx.parts.push(`**Answer:** ${item.answer}\n\n${sk.explanation}\n\n(Answers seen before an attempt are much less likely to stick, so I'll bring this one back soon.)`);
    model.pending = null;
    model.recentSkillIds.push(item.skillId);
    await this.next(ctx, this.activeGoal(model)!, true);
  }

  private async help(ctx: Ctx, item: Item, kind: string) {
    const { model, trace } = ctx;
    const pend = model.pending!;
    const sk = this.skill(model, item.skillId)!;
    pend.helpGiven = true;
    const text = kind === "example" && sk.example ? `Example: ${sk.example}` : kind === "explain" ? `**${sk.name}.** ${sk.explanation}` : item.hint ? `Hint: ${item.hint}` : `Hint: ${sk.explanation.split(/(?<=\.)\s/)[0]}`;
    trace.decision = { activity: "help", skillId: item.skillId, itemId: item.id, support: pend.support, reasons: [`learner asked for ${kind}; given, and the attempt will be recorded as aided`], alternatives: ["reveal the answer (rejected: answers before an attempt are poorly retained)"] };
    ctx.parts.push(`${text}\n\nNow try: ${item.prompt}`);
  }

  private async answerQuestion(ctx: Ctx, skillId: string | null, item: Item | null) {
    const { model, p, trace } = ctx;
    const goal = this.activeGoal(model);
    const sk = skillId ? this.skill(model, skillId) : this.currentSkill(ctx, goal!);
    let answer: string | null = null;
    if (this.llm) {
      answer = await this.llm.text(
        `You are a tutor answering a learner's question during practice on "${goal?.topic ?? "their topic"}". Answer briefly and concretely (max 120 words). ${item ? "Do NOT give away the answer to the open practice question; guide instead." : ""} If the question is unrelated to learning, answer in one sentence.`,
        `Skill context: ${sk?.name ?? "n/a"} — ${sk?.explanation ?? ""}\n${item ? `Open practice question: ${item.prompt}\n` : ""}Learner asks: ${p.raw}`,
      );
    }
    if (!answer) {
      answer = sk ? `Here's what I have on **${sk.name}**: ${sk.explanation}${sk.example ? `\n\nExample: ${sk.example}` : ""}${goal?.provenance && goal.source !== "scaffold" ? `\n\n(Source: ${goal.provenance}. No language model is configured, so I can only answer from this material.)` : "\n\n(No language model or reference source is configured, so I can't answer beyond your material — but I can still keep the practice loop going.)"}` : "I don't have material to answer that from yet.";
    }
    this.obs(ctx, "question", p.raw, { skillId: sk?.id ?? null });
    trace.decision = { activity: "answer_question", skillId: sk?.id ?? null, itemId: item?.id ?? null, support: null, reasons: ["learner asked a question; answered before continuing" + (item ? "; the open item stays open" : "")], alternatives: [] };
    ctx.parts.push(answer);
    if (item) ctx.parts.push(`Back to the open question when you're ready: ${item.prompt}`);
  }

  /** Choose and pose the next activity for the active goal. */
  private async next(ctx: Ctx, goal: Goal, brief: boolean) {
    const { model, p, trace } = ctx;
    if (this.ab.explainOnly) {
      const sk = this.currentSkill(ctx, goal);
      if (sk) {
        ctx.parts.push(`**${sk.name}.** ${sk.explanation}${sk.example ? `\n\nExample: ${sk.example}` : ""}\n\nLet me know if that makes sense or if you'd like another angle.`);
        model.recentSkillIds.push(sk.id);
        if (model.recentSkillIds.length > 6) model.recentSkillIds.shift();
      }
      trace.decision = { activity: "teach", skillId: sk?.id ?? null, itemId: null, support: null, reasons: ["explain-only ablation: no evidence is created"], alternatives: [] };
      return;
    }
    const skills = this.goalSkills(model, goal);
    if (!skills.length) {
      trace.decision = { activity: "clarify", skillId: null, itemId: null, support: null, reasons: ["goal has no content"], alternatives: [] };
      ctx.parts.push("I couldn't build practice material for this goal. Paste a few paragraphs of notes or a definition list and I'll turn it into practice.");
      return;
    }
    const now = ctx.now;
    const scale = model.forgettingScale;
    const reasons: string[] = [];
    const alternatives: string[] = [];
    const last = model.recentSkillIds.slice(-2);
    const st = (s: Skill) => this.state(model, s.id);
    type Cand = { activity: Activity; skill: Skill; kind: ItemKind[]; novel: boolean; score: number; why: string; error?: string };
    const cands: Cand[] = [];

    for (const s of skills) {
      const x = st(s);
      const err = model.errors.find((e) => e.skillId === s.id && e.status === "active" && (!e.remediatedAt || e.count > 2) && !this.ab.noRemediation);
      if (err) cands.push({ activity: "remediate", skill: s, kind: ["discriminate", "apply", "recall"], novel: false, score: 100 + err.count, why: `persistent error "${err.label}" (${err.count}×) needs a discriminating item`, error: err.id });
      if (x.basis === "claimed") cands.push({ activity: "verify_claim", skill: s, kind: ["recall", "apply"], novel: false, score: 90, why: `claimed level ${x.claimedLevel?.toFixed(1)} has not been demonstrated` });
      if (x.status === "review" || x.status === "secure") {
        const pr = pRecall(x, now, scale);
        const threshold = x.status === "secure" ? 0.7 : 0.85; // desired retention; reviews are triggered before recall is predicted to drop below it
        if (this.ab.noSpacing) {
          if (this.rnd() < 0.15) cands.push({ activity: "review", skill: s, kind: ["recall", "apply"], novel: false, score: 80, why: "review chosen at random (no spacing ablation)" });
        } else if (pr < threshold) cands.push({ activity: "review", skill: s, kind: ["recall", "apply"], novel: false, score: 80 + (1 - reviewPriority(x, now, scale)) * 10, why: `predicted recall ${pr.toFixed(2)} < ${threshold} after ${daysSince(x.lastSuccessAt, now).toFixed(1)}d (half-life ${(x.stability * scale).toFixed(1)}d)` });
        if (x.transferSuccesses === 0 && !this.ab.noTransfer && this.hasNovelItem(model, s.id, x)) cands.push({ activity: "transfer", skill: s, kind: ["transfer", "apply"], novel: true, score: 78, why: "recall is reliable; not yet shown in a new context" });
      }
      if (x.status === "learning") {
        const streakFail = x.recent.slice(-3).every((r) => r === 0) && x.recent.length >= 3;
        cands.push({ activity: "practice", skill: s, kind: x.pKnown > 0.5 ? ["apply", "recall", "discriminate"] : ["recall", "apply"], novel: false, score: 60 - (streakFail ? 15 : 0) + (1 - x.pKnown) * 5, why: `still forming (pKnown ${x.pKnown.toFixed(2)}, ${x.unaidedSuccesses} unaided successes)${streakFail ? "; three misses in a row → back to explanation" : ""}` });
      }
      if (x.status === "new") {
        const ready = s.prerequisites.every((pid) => { const ps = model.states[pid]; return ps && ps.status !== "new" && ps.pKnown >= 0.5; });
        cands.push({ activity: "teach", skill: s, kind: ["recall", "apply"], novel: false, score: ready ? 50 - s.order * 0.1 : 30 - s.order * 0.1, why: ready ? "next new skill in order" : "prerequisites not yet demonstrated" });
      }
    }
    if (!cands.length) {
      // Nothing is due. Extra retrieval on the least secure skill is still useful; if everything is fresh, say so honestly.
      const weakest = skills.map((s) => ({ s, x: st(s), pr: pRecall(st(s), now, scale) })).filter((w) => w.x.basis === "demonstrated").sort((a, b) => a.pr - b.pr)[0];
      const allSecure = skills.every((s) => st(s).status === "secure");
      if (weakest && weakest.pr < 0.9 && !allSecure) cands.push({ activity: "practice", skill: weakest.s, kind: ["apply", "discriminate", "recall"], novel: false, score: 10, why: `nothing is due; extra retrieval on the least secure skill (predicted recall ${weakest.pr.toFixed(2)})` });
      else {
        this.wrapUp(ctx, allSecure, true);
        return;
      }
    }
    if (p.request === "review") for (const c of cands) if (c.activity === "review") c.score += 50;
    if (p.request === "practice") for (const c of cands) if (c.activity === "practice" || c.activity === "teach") c.score += 20;
    cands.sort((a, b) => b.score - a.score);
    let chosen = cands[0];
    // Interleave: avoid the same skill three times in a row when a comparable alternative exists.
    if (!this.ab.noInterleave && last.length === 2 && last.every((id) => id === chosen.skill.id)) {
      const alt = cands.find((c) => c.skill.id !== chosen.skill.id && c.score >= chosen.score - 30);
      if (alt) {
        alternatives.push(`${chosen.activity} on ${chosen.skill.name} (deferred: interleaving)`);
        chosen = alt;
        reasons.push("interleaved away from a skill practised twice in a row");
      }
    }
    for (const c of cands.slice(0, 4)) if (c !== chosen) alternatives.push(`${c.activity} on ${c.skill.name} — ${c.why}`);
    reasons.unshift(chosen.why);

    // Support mode for practice/teach; reviews and transfer are always unaided (they are measurements).
    let support: SupportMode | null = null;
    let creditable = false;
    const state = st(chosen.skill);
    if (chosen.activity === "teach" || chosen.activity === "practice") {
      const context = contextOf(state);
      const streakFail = state.recent.length >= 3 && state.recent.slice(-3).every((r) => r === 0);
      if (context === "novice" || p.supportRequest) {
        // Only while the learner has little demonstrated knowledge is the *form of support* an open question.
        if (this.ab.fixedSupport && !p.supportRequest) support = this.ab.fixedSupport;
        else if (this.ab.supportPolicy === "bandit") {
          const r = chooseSupport(model, context, goal.id, now, this.rnd, p.supportRequest);
          support = r.support;
          reasons.push(...r.reasons);
          alternatives.push(...r.alternatives.map((a) => `support ${a}`));
          creditable = !p.supportRequest;
        } else {
          const r = this.ruleSupport(model, goal.id, now, p.supportRequest);
          support = r.support;
          reasons.push(...r.reasons);
          alternatives.push(...r.alternatives);
          creditable = r.creditable;
        }
        const tired = model.beliefs.find((b) => b.kind === "context" && b.status !== "retired" && b.expiresAt && new Date(b.expiresAt) > now);
        if (tired && support === "retrieval_first" && state.status === "new") {
          support = "hint_first";
          creditable = false;
          reasons.push(`context "${tired.statement}" → lighter load`);
        }
      } else {
        support = "retrieval_first";
        reasons.push("some knowledge already demonstrated → unaided retrieval (the strongest learning event and the cleanest evidence)");
      }
      if (streakFail && support === "retrieval_first") {
        support = "worked_example_first";
        creditable = false;
        reasons.push("three consecutive misses → show a worked example first (rule, not learned)");
      }
    }
    const item = this.pickItem(model, chosen.skill.id, chosen.kind, chosen.novel, chosen.activity);
    if (!item) {
      trace.decision = { activity: "clarify", skillId: chosen.skill.id, itemId: null, support: null, reasons: ["no item available"], alternatives };
      ctx.parts.push("I've run out of practice items for this. Paste more material and I'll make more.");
      return;
    }
    const isNovel = state.attempts > 0 && !state.variantsSeen.includes(item.variant) && (item.kind === "transfer" || item.kind === "apply");
    const helpGiven = support === "worked_example_first" || support === "hint_first" || chosen.activity === "remediate";
    model.pending = { itemId: item.id, skillId: chosen.skill.id, tutorTurnId: "__next__", posedAt: now.toISOString(), support, helpGiven, awaitingSelfGrade: false, learnerResponse: null, isNovel, purpose: chosen.activity, nudged: false };
    if (support && creditable) model.supportCredits[chosen.skill.id] = { turnId: "__next__", support, sessionId: ctx.sessionId, at: now.toISOString(), context: contextOf(state) };
    if (chosen.activity === "teach" && !state.taughtAt) {
      const ns = this.state(model, chosen.skill.id);
      ns.taughtAt = now.toISOString();
      ns.status = "learning";
      model.states[chosen.skill.id] = ns;
    }
    if (chosen.error) {
      const e = model.errors.find((x) => x.id === chosen.error)!;
      e.remediatedAt = now.toISOString();
    }
    trace.decision = { activity: chosen.activity, skillId: chosen.skill.id, itemId: item.id, support, reasons, alternatives };
    ctx.parts.push(this.compose(ctx, chosen.activity, chosen.skill, item, support, state, brief, chosen.error));
  }

  /**
   * Default support policy for learners with little demonstrated knowledge on a skill.
   * Expertise-reversal effect: worked example first for novices; retrieval once anything is demonstrated
   * (handled by the caller). A stated or well-supported preference overrides the default — and stays
   * attributable, so repeated failure after it contests the belief and the default returns.
   */
  private ruleSupport(model: LearnerModel, goalId: string, now: Date, requested: SupportMode | null): { support: SupportMode; reasons: string[]; alternatives: string[]; creditable: boolean } {
    if (requested) return { support: requested, reasons: ["learner asked for it this turn"], alternatives: [], creditable: false };
    let best: { m: SupportMode; inf: number; b: Belief } | null = null;
    for (const b of model.beliefs) {
      if (b.kind !== "preference" || !b.key.startsWith("preference:support:") || b.source !== "stated") continue;
      const inf = beliefInfluence(b, now, goalId);
      if (inf > 0.3 && (!best || inf > best.inf)) best = { m: b.key.split(":")[2] as SupportMode, inf, b };
    }
    const crutch = model.beliefs.find((b) => b.key === "tendency:asks_before_attempting" && (b.status === "active" || b.status === "contested"));
    if (best) return { support: best.m, reasons: [`belief "${best.b.statement}" (${best.b.source}, ${best.b.status}, confidence ${best.b.confidence.toFixed(2)}) overrides the default; outcomes after it are attributed to it`], alternatives: ["worked_example_first (default for a skill with nothing demonstrated yet)"], creditable: true };
    if (crutch) return { support: "hint_first", reasons: [`belief "${crutch.statement}" → hint up front to keep the attempt productive`], alternatives: ["worked_example_first (default)"], creditable: true };
    return { support: "worked_example_first", reasons: ["nothing demonstrated on this skill yet → worked example first (expertise-reversal default); retrieval takes over once something is demonstrated"], alternatives: ["retrieval_first (pretest; used once knowledge is demonstrated)", "hint_first"], creditable: true };
  }

  private compose(ctx: Ctx, activity: Activity, sk: Skill, item: Item, support: SupportMode | null, state: SkillState, brief: boolean, errorId?: string): string {
    const { model } = ctx;
    const name = sk.name.replace(/^.*?:\s*/, "");
    const answerHow = item.grader.kind === "choice" ? `\n${(item.grader.options as string[]).map((o, i) => `${String.fromCharCode(97 + i)}) ${o}`).join("\n")}` : "";
    const q = `${item.prompt}${answerHow}`;
    switch (activity) {
      case "teach": {
        const head = brief ? "" : `Next: **${name}**. `;
        if (support === "worked_example_first") return `${head}${sk.explanation}${sk.example ? `\n\nWorked example: ${sk.example}` : ""}\n\nNow you: ${q}`;
        if (support === "hint_first") return `${head}${sk.description ? sk.description + " " : ""}Let's start with a guided attempt.\n\n${q}\n\nHint: ${item.hint ?? sk.explanation.split(/(?<=\.)\s/)[0]}`;
        return `${head}Before I explain, try this from whatever you already know — a wrong guess still helps the explanation stick:\n\n${q}\n\n(Say "I don't know" if nothing comes to mind.)`;
      }
      case "practice": {
        if (support === "worked_example_first") {
          const justTaught = state.taughtAt && ctx.now.getTime() - new Date(state.taughtAt).getTime() < 15 * 60_000;
          if (justTaught && !sk.example) return `Re-read the explanation above if you need it, then: ${q}`;
          return `Let's look at one worked through first.\n\n${sk.example || sk.explanation}\n\nYour turn: ${q}`;
        }
        if (support === "hint_first") return `${q}\n\nHint: ${item.hint ?? sk.explanation.split(/(?<=\.)\s/)[0]}`;
        return `${q}`;
      }
      case "review": {
        const d = daysSince(state.lastSuccessAt, ctx.now);
        return `Quick check on *${name}* — you last got this right ${d < 1 ? "earlier today" : `${Math.round(d)} day${Math.round(d) === 1 ? "" : "s"} ago`}, and my model says it's starting to fade:\n\n${q}`;
      }
      case "transfer":
        return `Same idea, new situation — this is the check that tells us whether *${name}* transfers:\n\n${q}`;
      case "remediate": {
        const e = model.errors.find((x) => x.id === errorId);
        return `You've answered in a way that suggests **${e?.label ?? "a recurring mix-up"}** ${e ? `(${e.count} times)` : ""}. ${e?.refutation ?? sk.explanation}\n\nTo separate the two cleanly: ${q}`;
      }
      case "verify_claim":
        return `You said you know *${name}* — I'd rather verify than assume, so here's a quick one:\n\n${q}`;
      default:
        return q;
    }
  }

  private wrapUp(ctx: Ctx, allSecure = false, nothingDue = false) {
    const { model, trace } = ctx;
    const goal = this.activeGoal(model);
    const lines: string[] = [];
    if (goal) lines.push(allSecure ? `Everything under **${goal.topic}** is currently secure — demonstrated, spaced, and shown in a new context. I'll bring items back as they're predicted to fade.` : nothingDue ? `Nothing under **${goal.topic}** is due right now — everything you've practised is still predicted to be fresh, and more repetition today would add little. ${this.progressLine(model, goal)}` : `Pausing **${goal.topic}**. ${this.progressLine(model, goal)}`);
    const due = this.goalSkills(model, goal ?? undefined).map((s) => ({ s, st: this.state(model, s.id) })).filter((x) => x.st.basis === "demonstrated").map((x) => ({ name: x.s.name, days: Math.max(0, x.st.stability * model.forgettingScale * 0.9 - daysSince(x.st.lastSuccessAt, ctx.now)) })).sort((a, b) => a.days - b.days).slice(0, 3);
    if (due.length) lines.push(`Next reviews: ${due.map((d) => `${d.name.replace(/^.*?:\s*/, "")} in ~${Math.round(d.days)}d`).join(", ")}.`);
    if (!allSecure) lines.push(nothingDue ? `Paste new material or name a new goal whenever you like.` : `Come back any time — say "continue" or name something new to learn.`);
    ctx.parts.push(lines.join(" "));
    trace.decision = { activity: "wrap_up", skillId: null, itemId: null, support: null, reasons: [allSecure ? "all skills secure" : nothingDue ? "nothing due; no candidate activity" : "learner asked to stop/pause"], alternatives: [] };
  }

  // -------------------------------------------------------------- helpers

  private pickItem(model: LearnerModel, skillId: string, kinds: ItemKind[], novel: boolean, activity: Activity): Item | null {
    const st = this.state(model, skillId);
    const items = model.items.filter((i) => i.skillId === skillId && (!this.ab.noTransfer || i.kind !== "transfer") && (i.kind !== "transfer" || kinds.includes("transfer")));
    if (!items.length) return null;
    const recentIds = new Set<string>();
    const score = (i: Item) => {
      let s = 0;
      const k = kinds.indexOf(i.kind);
      s += k >= 0 ? (kinds.length - k) * 10 : 0;
      const unseen = !st.variantsSeen.includes(i.variant);
      if (novel && unseen) s += 25;
      if (unseen && activity !== "teach") s += 5;
      if (activity === "teach" && i.grader.kind !== "self") s += 3;
      if (recentIds.has(i.id)) s -= 50;
      s += this.rnd() * 2;
      return s;
    };
    return [...items].sort((a, b) => score(b) - score(a))[0];
  }

  private hasNovelItem(model: LearnerModel, skillId: string, st: SkillState): boolean {
    return model.items.some((i) => i.skillId === skillId && !st.variantsSeen.includes(i.variant) && (i.kind === "transfer" || i.kind === "apply"));
  }

  private currentSkill(ctx: Ctx, goal: Goal): Skill | null {
    const { model } = ctx;
    const pendingId = model.pending?.skillId ?? model.recentSkillIds[model.recentSkillIds.length - 1];
    const skills = this.goalSkills(model, goal);
    return skills.find((s) => s.id === pendingId) ?? skills.find((s) => this.state(model, s.id).status !== "secure") ?? skills[0] ?? null;
  }

  activeGoal(model: LearnerModel): Goal | null {
    return model.goals.find((g) => g.status === "active") ?? null;
  }
  goalSkills(model: LearnerModel, goal?: Goal): Skill[] {
    const g = goal ?? this.activeGoal(model);
    return g ? model.skills.filter((s) => s.goalId === g.id).sort((a, b) => a.order - b.order) : [];
  }
  state(model: LearnerModel, skillId: string): SkillState {
    return model.states[skillId] ?? (model.states[skillId] = newSkillState(skillId));
  }
  skill(model: LearnerModel, id: string): Skill | null {
    return model.skills.find((s) => s.id === id) ?? null;
  }
  item(model: LearnerModel, id: string): Item | null {
    return model.items.find((i) => i.id === id) ?? null;
  }
  skillName(model: LearnerModel, id: string): string {
    return this.skill(model, id)?.name ?? id;
  }
  progressLine(model: LearnerModel, goal: Goal): string {
    const sk = this.goalSkills(model, goal);
    const c = { new: 0, learning: 0, review: 0, secure: 0 };
    for (const s of sk) c[this.state(model, s.id).status] += 1;
    return `${sk.length} skills: ${c.secure} secure, ${c.review} in review, ${c.learning} forming, ${c.new} not started.`;
  }
}

export function contextOf(st: SkillState): string {
  return st.basis === "demonstrated" && st.pKnown >= 0.35 ? "learning" : "novice";
}

function label(m: SupportMode): string {
  return m === "worked_example_first" ? "a worked example first" : m === "hint_first" ? "a hint up front" : "trying before any help";
}

function firstLine(s: string): string {
  return s.split(/\n/)[0].slice(0, 80);
}
