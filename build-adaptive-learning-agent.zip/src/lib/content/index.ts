// Content layer: turns a learning goal (or learner-supplied material) into a
// ContentPlan — skills plus items that let the learner demonstrate them.
// Sources in order of quality: model → Wikipedia → learner notes → scaffold.
// This is world knowledge. It carries no learner information and is cached by
// topic only. The core loop works identically whichever source produced it.

import type { ContentPlan, ContentSource, Grader, Item, ItemKind, Skill } from "../core/types";
import type { LLM } from "../providers/llm";

export interface ContentCache {
  get(key: string): Promise<ContentPlan | null>;
  put(key: string, plan: ContentPlan): Promise<void>;
}

export interface ContentOptions {
  llm: LLM | null;
  cache: ContentCache | null;
  fetchImpl?: typeof fetch | null; // null disables network (lab, tests)
  idFactory: (prefix: string) => string;
}

export function topicKey(goal: string): string {
  return goal.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim().slice(0, 120);
}

export async function buildPlan(goalText: string, goalId: string, opts: ContentOptions, material?: string | null): Promise<ContentPlan> {
  const key = material ? `learner:${topicKey(goalText)}:${hashString(material)}` : `goal:${topicKey(goalText)}`;
  if (!material && opts.cache) {
    const cached = await opts.cache.get(key);
    if (cached) return rekey(cached, goalId, opts.idFactory);
  }
  let plan: ContentPlan | null = null;
  if (material) plan = planFromMaterial(goalText, material, goalId, opts.idFactory);
  if (!plan && opts.llm) plan = await planFromLLM(goalText, goalId, opts.llm, opts.idFactory);
  if (!plan && opts.fetchImpl) plan = await planFromWikipedia(goalText, goalId, opts.fetchImpl, opts.idFactory);
  if (!plan) plan = scaffoldPlan(goalText, goalId, opts.idFactory);
  if (!material && opts.cache && plan.source !== "scaffold") await opts.cache.put(key, plan).catch(() => undefined);
  return plan;
}

function rekey(plan: ContentPlan, goalId: string, id: (p: string) => string): ContentPlan {
  const map = new Map<string, string>();
  const skills = plan.skills.map((s) => {
    const nid = id("sk");
    map.set(s.id, nid);
    return { ...s, id: nid, goalId };
  });
  for (const s of skills) s.prerequisites = s.prerequisites.map((p) => map.get(p) ?? p).filter((p) => map.has(p) || skills.some((x) => x.id === p));
  const items = plan.items.map((it) => ({ ...it, id: id("it"), skillId: map.get(it.skillId) ?? it.skillId })).filter((it) => skills.some((s) => s.id === it.skillId));
  return { ...plan, skills, items };
}

// ---------- model-generated plans (validated) ----------

interface RawPlan {
  topic?: string;
  skills?: {
    name?: string; description?: string; explanation?: string; example?: string; prerequisites?: number[];
    items?: { kind?: string; prompt?: string; answer?: string; hint?: string; variant?: string; grader?: Record<string, unknown>; errorTags?: { match?: string[]; label?: string; refutation?: string }[] }[];
  }[];
}

const PLAN_SYSTEM = `You design a compact learning plan for one goal. Output JSON:
{"topic": string, "skills": [{"name": string, "description": string, "explanation": string (3-6 sentences teaching the core idea, no fluff), "example": string (one worked example), "prerequisites": number[] (indices of earlier skills), "items": [{"kind": "recall"|"apply"|"transfer"|"discriminate", "prompt": string, "answer": string, "hint": string, "variant": string (short context tag; transfer items use a context different from the others), "grader": {"kind":"keywords","accept":[...],"all":false} | {"kind":"exact","accept":[...]} | {"kind":"numeric","value":n,"tolerance":n} | {"kind":"choice","options":[...],"correct":i} | {"kind":"self"}, "errorTags": [{"match":[tokens],"label":"misconception name","refutation":"why wrong / what is right"}]}]}]}
Rules: 3-6 skills ordered from prerequisite to advanced. Each skill has 4-6 items: at least 2 recall, 1 apply, 1 transfer (novel context), and 1 discriminate item that targets a common misconception with errorTags. Prefer graders that can be checked mechanically; use "self" only for genuinely open answers. Keep prompts self-contained. Never include information about any person.`;

async function planFromLLM(goal: string, goalId: string, llm: LLM, id: (p: string) => string): Promise<ContentPlan | null> {
  const raw = await llm.json<RawPlan>(PLAN_SYSTEM, `Learning goal: ${goal}`);
  if (!raw) return null;
  return validatePlan(raw, goal, goalId, "llm", `model:${llm.name}`, id);
}

export function validatePlan(raw: RawPlan, goal: string, goalId: string, source: ContentSource, provenance: string, id: (p: string) => string): ContentPlan | null {
  if (!raw || !Array.isArray(raw.skills) || raw.skills.length === 0) return null;
  const skills: Skill[] = [];
  const items: Item[] = [];
  raw.skills.slice(0, 8).forEach((s, i) => {
    if (!s || typeof s.name !== "string" || !s.name.trim()) return;
    const sk: Skill = {
      id: id("sk"), goalId, name: s.name.trim().slice(0, 120), description: str(s.description, 400), explanation: str(s.explanation, 1500) || `${s.name}: ${str(s.description, 400)}`,
      example: str(s.example, 1000), prerequisites: [], order: i,
    };
    const prereqIdx = Array.isArray(s.prerequisites) ? s.prerequisites.filter((n) => Number.isInteger(n) && n >= 0 && n < i) : [];
    skills.push(sk);
    (sk as Skill & { _pre?: number[] })._pre = prereqIdx;
    for (const it of (s.items ?? []).slice(0, 8)) {
      const g = validateGrader(it?.grader);
      if (!it || typeof it.prompt !== "string" || !it.prompt.trim() || !g) continue;
      const kind: ItemKind = (["recall", "apply", "transfer", "discriminate"] as const).includes(it.kind as ItemKind) ? (it.kind as ItemKind) : "recall";
      items.push({
        id: id("it"), skillId: sk.id, kind, prompt: it.prompt.trim().slice(0, 1200), answer: str(it.answer, 1200) || "(see explanation)", grader: g,
        hint: str(it.hint, 400) || null, variant: str(it.variant, 60) || kind, source,
        errorTags: (Array.isArray(it.errorTags) ? it.errorTags : []).filter((t) => t && Array.isArray(t.match) && typeof t.label === "string").slice(0, 4)
          .map((t) => ({ match: t.match!.filter((m) => typeof m === "string").slice(0, 6), label: t.label!.slice(0, 120), refutation: str(t.refutation, 600) })),
      });
    }
  });
  for (const sk of skills) {
    const pre = (sk as Skill & { _pre?: number[] })._pre ?? [];
    sk.prerequisites = pre.map((n) => skills[n]?.id).filter((x): x is string => Boolean(x));
    delete (sk as Skill & { _pre?: number[] })._pre;
  }
  const withItems = skills.filter((s) => items.some((it) => it.skillId === s.id));
  if (withItems.length === 0) return null;
  return { topic: str(raw.topic, 120) || goal, source, provenance, skills: withItems, items: items.filter((it) => withItems.some((s) => s.id === it.skillId)) };
}

function str(v: unknown, max: number): string {
  return typeof v === "string" ? v.trim().slice(0, max) : "";
}

function validateGrader(g: unknown): Grader | null {
  if (!g || typeof g !== "object") return null;
  const o = g as Record<string, unknown>;
  switch (o.kind) {
    case "exact":
    case "keywords": {
      const accept = Array.isArray(o.accept) ? o.accept.filter((x): x is string => typeof x === "string" && x.trim().length > 0).map((x) => x.trim()) : [];
      if (!accept.length) return null;
      return o.kind === "exact" ? { kind: "exact", accept } : { kind: "keywords", accept, all: Boolean(o.all) };
    }
    case "numeric":
      return typeof o.value === "number" && Number.isFinite(o.value) ? { kind: "numeric", value: o.value, tolerance: typeof o.tolerance === "number" ? Math.abs(o.tolerance) : undefined } : null;
    case "choice": {
      const options = Array.isArray(o.options) ? o.options.filter((x): x is string => typeof x === "string") : [];
      const correct = typeof o.correct === "number" ? o.correct : -1;
      return options.length >= 2 && correct >= 0 && correct < options.length ? { kind: "choice", options, correct } : null;
    }
    case "self":
      return { kind: "self" };
    default:
      return null;
  }
}

// ---------- Wikipedia (offline fallback for unfamiliar goals) ----------

interface WikiSearch { query?: { search?: { title: string }[] } }
interface WikiSummary { title?: string; extract?: string; content_urls?: { desktop?: { page?: string } } }
interface WikiSections { remaining?: { sections?: { line?: string; toclevel?: number; text?: string }[] }; lead?: { sections?: { line?: string }[] } }

async function planFromWikipedia(goal: string, goalId: string, fetchImpl: typeof fetch, id: (p: string) => string): Promise<ContentPlan | null> {
  try {
    const q = goal.replace(/\b(the basics of|basics of|how to|about|fundamentals of)\b/gi, "").trim();
    const withTimeout = (url: string) => fetchImpl(url, { headers: { "user-agent": "private-learning-agent/1.0 (offline fallback)" }, signal: AbortSignal.timeout(6000) });
    const sr = (await (await withTimeout(`https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=3&srsearch=${encodeURIComponent(q)}`)).json()) as WikiSearch;
    const title = sr.query?.search?.[0]?.title;
    if (!title) return null;
    const summary = (await (await withTimeout(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`)).json()) as WikiSummary;
    const extract = summary.extract ?? "";
    if (extract.length < 80) return null;
    let sections: { line: string; text: string }[] = [];
    try {
      // Plain-text extract with "== Heading ==" markers (the mobile-sections REST endpoint is deprecated).
      const ex = (await (await withTimeout(`https://en.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&format=json&redirects=1&titles=${encodeURIComponent(title)}`)).json()) as { query?: { pages?: Record<string, { extract?: string }> } };
      const full = Object.values(ex.query?.pages ?? {})[0]?.extract ?? "";
      const parts = full.split(/\n(?==+ [^=]+ =+\n)/);
      sections = parts
        .map((part) => {
          const m = part.match(/^(=+) ([^=]+) \1\n([\s\S]*)$/);
          return m ? { level: m[1].length, line: m[2].trim(), text: m[3].replace(/\n=+ [^=]+ =+\n/g, "\n").replace(/\s+/g, " ").trim() } : null;
        })
        .filter((x): x is { level: number; line: string; text: string } => !!x && x.level === 2 && x.text.length > 300 && !/references|see also|external links|notes|further reading|bibliography|gallery|sources/i.test(x.line))
        .slice(0, 4)
        .map(({ line, text }) => ({ line, text }));
    } catch {
      sections = [];
    }
    const url = summary.content_urls?.desktop?.page ?? `https://en.wikipedia.org/wiki/${encodeURIComponent(title)}`;
    const skills: Skill[] = [];
    const items: Item[] = [];
    const lead = buildSkill(summary.title ?? title, extract, goalId, 0, id, "wikipedia");
    skills.push(lead.skill);
    items.push(...lead.items);
    sections.forEach((s, i) => {
      const built = buildSkill(`${summary.title ?? title}: ${s.line}`, s.text, goalId, i + 1, id, "wikipedia");
      if (built.items.length) {
        built.skill.prerequisites = [lead.skill.id];
        skills.push(built.skill);
        items.push(...built.items);
      }
    });
    return { topic: summary.title ?? title, source: "wikipedia", provenance: url, skills, items };
  } catch {
    return null;
  }
}

function stripHtml(html: string): string {
  return html.replace(/<style[\s\S]*?<\/style>/g, "").replace(/<sup[\s\S]*?<\/sup>/g, "").replace(/<[^>]+>/g, " ").replace(/&[a-z]+;/g, " ").replace(/\s+/g, " ").trim();
}

// ---------- learner-supplied material ----------

function planFromMaterial(goal: string, material: string, goalId: string, id: (p: string) => string): ContentPlan | null {
  const chunks = material.split(/\n{2,}|\n(?=[-*•\d]+[.)]?\s)/).map((c) => c.trim()).filter((c) => c.length > 40);
  const blocks = chunks.length >= 2 ? chunks : [material];
  const skills: Skill[] = [];
  const items: Item[] = [];
  blocks.slice(0, 8).forEach((b, i) => {
    const firstSentence = sentences(b)[0] ?? b;
    const name = firstSentence.length > 70 ? `${goal}: part ${i + 1}` : firstSentence.replace(/[.:]$/, "");
    const built = buildSkill(name, b, goalId, i, id, "learner");
    if (built.items.length) {
      skills.push(built.skill);
      items.push(...built.items);
    }
  });
  if (!skills.length) return null;
  return { topic: goal, source: "learner", provenance: "learner notes", skills, items };
}

// ---------- text → skill + items (shared by Wikipedia and notes) ----------

export function sentences(text: string): string[] {
  return text.replace(/\s+/g, " ").split(/(?<=[.!?])\s+(?=[A-Z0-9"“(])/).map((s) => s.trim()).filter((s) => s.length > 25 && s.length < 400);
}

const STOP = new Set("the a an of in on at to for from by with and or but is are was were be been being as that this these those it its their there which who whom whose what when where why how not no yes into onto over under than then also such can may might must shall should will would could do does did done has have had having more most many much some any each other another same different very only just".split(" "));

function buildSkill(name: string, text: string, goalId: string, order: number, id: (p: string) => string, source: ContentSource): { skill: Skill; items: Item[] } {
  const sents = sentences(text);
  const explanation = sents.slice(0, 5).join(" ") || text.slice(0, 600);
  const skill: Skill = { id: id("sk"), goalId, name, description: sents[0] ?? text.slice(0, 200), explanation, example: sents.slice(5, 8).join(" "), prerequisites: [], order };
  const items: Item[] = [];
  const used = new Set<string>();
  for (const s of sents) {
    if (items.length >= 5) break;
    const cloze = makeCloze(s, used);
    if (!cloze) continue;
    used.add(cloze.answer.toLowerCase());
    items.push({ id: id("it"), skillId: skill.id, kind: items.length === 0 ? "recall" : items.length === 3 ? "apply" : "recall", prompt: `Fill in the blank: ${cloze.prompt}`, answer: cloze.answer, grader: { kind: "keywords", accept: [cloze.answer] }, hint: `It starts with "${cloze.answer[0]}" and has ${cloze.answer.length} letters.`, variant: `cloze-${items.length}`, errorTags: [], source });
  }
  const shortName = name.replace(/^.*?:\s*/, "");
  items.push({ id: id("it"), skillId: skill.id, kind: "recall", prompt: `In your own words: what is ${shortName}, and why does it matter? Answer from memory, then compare with the reference.`, answer: explanation, grader: { kind: "self" }, hint: sents[0] ? `Start from: "${sents[0].slice(0, 80)}…"` : null, variant: "free-recall", errorTags: [], source });
  items.push({ id: id("it"), skillId: skill.id, kind: "transfer", prompt: `Give one concrete example or situation (not one mentioned in the material) where ${shortName} applies, and say what would go wrong without it.`, answer: `A good answer names a new situation and connects it to: ${sents[0] ?? explanation.slice(0, 200)}`, grader: { kind: "self" }, hint: "Think of a domain you already know well and look for the same pattern there.", variant: "own-example", errorTags: [], source });
  return { skill, items };
}

function makeCloze(sentence: string, used: Set<string>): { prompt: string; answer: string } | null {
  const words = sentence.split(/\s+/);
  let best: { w: string; i: number; score: number } | null = null;
  words.forEach((raw, i) => {
    const w = raw.replace(/^[("“]+|[)"”.,;:!?]+$/g, "");
    if (i === 0 || w.length < 5 || STOP.has(w.toLowerCase()) || used.has(w.toLowerCase()) || /\d/.test(w)) return;
    const score = w.length + (/^[A-Z]/.test(w) ? 3 : 0) + (i > words.length / 2 ? 1 : 0);
    if (!best || score > best.score) best = { w, i, score };
  });
  if (!best) return null;
  const b = best as { w: string; i: number; score: number };
  const prompt = words.map((raw, i) => (i === b.i ? raw.replace(b.w, "_____") : raw)).join(" ");
  return { prompt, answer: b.w };
}

// ---------- scaffold: last resort, works for any goal ----------

export function scaffoldPlan(goal: string, goalId: string, id: (p: string) => string): ContentPlan {
  const g = goal.replace(/[.!?]+$/, "");
  const skill: Skill = {
    id: id("sk"), goalId, name: g, order: 0, prerequisites: [],
    description: `Your goal in your own words: ${g}`,
    explanation: `I don't have reference material for "${g}" yet, so I can't explain it for you — but I can still run the part that produces learning: retrieval, feedback, spacing and transfer. Paste a few paragraphs of notes, a textbook section or a definition list and I'll turn it into practice; or answer the prompts from what you already know and grade yourself honestly against your own sources.`,
    example: "",
  };
  const mk = (kind: ItemKind, prompt: string, hint: string, variant: string): Item => ({ id: id("it"), skillId: skill.id, kind, prompt, answer: "Compare your answer with your own source material and grade yourself.", grader: { kind: "self" }, hint, variant, errorTags: [], source: "scaffold" });
  return {
    topic: g, source: "scaffold", provenance: "no reference material available",
    skills: [skill],
    items: [
      mk("recall", `From memory: what are the two or three most important ideas in "${g}"? List them before looking anything up.`, "Which idea would you need first if you had to use this tomorrow?", "core-ideas"),
      mk("recall", `Define the single most central term in "${g}" precisely, in one sentence.`, "A good definition says what category it belongs to and what makes it different.", "definition"),
      mk("apply", `Describe, step by step, how you would actually use "${g}" on a small concrete task of your choosing.`, "Pick the smallest task that still needs it.", "procedure"),
      mk("transfer", `Where else — in a different area of life or work — does the same underlying idea as "${g}" show up? Explain the parallel.`, "Look for the same structure, not the same words.", "analogy"),
      mk("discriminate", `What is "${g}" often confused with, and what is the key difference?`, "Think about the mistake a beginner would make.", "contrast"),
    ],
  };
}

export function hashString(s: string): string {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}
