// Postgres implementation of the Store boundary (Drizzle ORM).
import { and, asc, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { attempts, contentCache, learnerModels, observations, supportOutcomes, turns } from "@/db/schema";
import type { Store } from "../core/store";
import type { Attempt, ContentPlan, LearnerModel, Observation, SupportOutcome, Turn } from "../core/types";
import type { ContentCache } from "../content";

export class PgStore implements Store {
  content: ContentCache = {
    get: async (key) => {
      const rows = await db.select().from(contentCache).where(eq(contentCache.key, key)).limit(1);
      return rows[0] ? (rows[0].plan as ContentPlan) : null;
    },
    put: async (key, plan) => {
      await db.insert(contentCache).values({ key, plan, source: plan.source }).onConflictDoUpdate({ target: contentCache.key, set: { plan, source: plan.source } });
    },
  };

  async loadModel(learnerId: string): Promise<LearnerModel | null> {
    const rows = await db.select().from(learnerModels).where(eq(learnerModels.id, learnerId)).limit(1);
    return rows[0] ? (rows[0].model as LearnerModel) : null;
  }

  async saveModel(model: LearnerModel): Promise<void> {
    await db.insert(learnerModels).values({ id: model.id, model, updatedAt: new Date() }).onConflictDoUpdate({ target: learnerModels.id, set: { model, updatedAt: new Date() } });
  }

  async appendTurn(t: Turn): Promise<void> {
    await db.insert(turns).values({ ...t, createdAt: new Date(t.createdAt) });
  }

  async appendObservations(obs: Observation[]): Promise<void> {
    if (!obs.length) return;
    await db.insert(observations).values(obs.map((o) => ({ ...o, createdAt: new Date(o.createdAt) })));
  }

  async appendAttempts(rows: Attempt[]): Promise<void> {
    if (!rows.length) return;
    await db.insert(attempts).values(rows.map((a) => ({ ...a, createdAt: new Date(a.createdAt) })));
  }

  async appendSupportOutcomes(rows: SupportOutcome[]): Promise<void> {
    if (!rows.length) return;
    await db.insert(supportOutcomes).values(rows.map((o) => ({ ...o, createdAt: new Date(o.createdAt) })));
  }

  async recentTurns(learnerId: string, limit: number): Promise<Turn[]> {
    const rows = await db.select().from(turns).where(eq(turns.learnerId, learnerId)).orderBy(desc(turns.createdAt)).limit(limit);
    return rows.reverse().map(rowToTurn);
  }

  async attempts(learnerId: string): Promise<Attempt[]> {
    const rows = await db.select().from(attempts).where(eq(attempts.learnerId, learnerId)).orderBy(asc(attempts.createdAt));
    return rows.map((r) => ({ ...r, kind: r.kind as Attempt["kind"], grading: r.grading as Attempt["grading"], createdAt: r.createdAt.toISOString() }));
  }

  async observations(learnerId: string, ids?: string[]): Promise<Observation[]> {
    const where = ids?.length ? and(eq(observations.learnerId, learnerId), inArray(observations.id, ids)) : eq(observations.learnerId, learnerId);
    const rows = await db.select().from(observations).where(where).orderBy(asc(observations.createdAt));
    return rows.map((r) => ({ ...r, kind: r.kind as Observation["kind"], signals: (r.signals ?? {}) as Record<string, unknown>, createdAt: r.createdAt.toISOString() }));
  }

  async supportOutcomes(learnerId: string): Promise<SupportOutcome[]> {
    const rows = await db.select().from(supportOutcomes).where(eq(supportOutcomes.learnerId, learnerId)).orderBy(asc(supportOutcomes.createdAt));
    return rows.map((r) => ({ ...r, support: r.support as SupportOutcome["support"], createdAt: r.createdAt.toISOString() }));
  }

  async erase(learnerId: string): Promise<void> {
    await db.delete(attempts).where(eq(attempts.learnerId, learnerId));
    await db.delete(observations).where(eq(observations.learnerId, learnerId));
    await db.delete(supportOutcomes).where(eq(supportOutcomes.learnerId, learnerId));
    await db.delete(turns).where(eq(turns.learnerId, learnerId));
    await db.delete(learnerModels).where(eq(learnerModels.id, learnerId));
  }
}

function rowToTurn(r: typeof turns.$inferSelect): Turn {
  return { id: r.id, learnerId: r.learnerId, sessionId: r.sessionId, role: r.role as Turn["role"], content: r.content, activity: r.activity as Turn["activity"], skillId: r.skillId, itemId: r.itemId, trace: (r.trace as Turn["trace"]) ?? null, createdAt: r.createdAt.toISOString() };
}
