// Private learner data lives in a single local Postgres database.
// learner_models: one mutable, revisable document per learner (skills, states, beliefs, errors, goals).
// turns / observations / attempts / support_outcomes: append-only evidence with provenance.
// content_cache: world knowledge keyed by topic only — no learner id by design.
import { boolean, doublePrecision, index, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const learnerModels = pgTable("learner_models", {
  id: text("id").primaryKey(),
  model: jsonb("model").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const turns = pgTable(
  "turns",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id").notNull(),
    role: text("role").notNull(),
    content: text("content").notNull(),
    activity: text("activity"),
    skillId: text("skill_id"),
    itemId: text("item_id"),
    trace: jsonb("trace"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("turns_learner_idx").on(t.learnerId, t.createdAt)],
);

export const observations = pgTable(
  "observations",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id").notNull(),
    turnId: text("turn_id").notNull(),
    kind: text("kind").notNull(),
    content: text("content").notNull(),
    signals: jsonb("signals").notNull(),
    dedupeKey: text("dedupe_key"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("observations_learner_idx").on(t.learnerId, t.createdAt)],
);

export const attempts = pgTable(
  "attempts",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id").notNull(),
    turnId: text("turn_id").notNull(),
    tutorTurnId: text("tutor_turn_id").notNull(),
    itemId: text("item_id").notNull(),
    skillId: text("skill_id").notNull(),
    kind: text("kind").notNull(),
    response: text("response").notNull(),
    correct: boolean("correct").notNull(),
    score: doublePrecision("score").notNull(),
    grading: text("grading").notNull(),
    pRecallBefore: doublePrecision("p_recall_before").notNull(),
    helpGiven: boolean("help_given").notNull(),
    isNovel: boolean("is_novel").notNull(),
    gapDays: doublePrecision("gap_days").notNull(),
    errorSignature: text("error_signature"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("attempts_learner_idx").on(t.learnerId, t.createdAt), index("attempts_skill_idx").on(t.learnerId, t.skillId)],
);

export const supportOutcomes = pgTable(
  "support_outcomes",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    tutorTurnId: text("tutor_turn_id").notNull(),
    skillId: text("skill_id").notNull(),
    context: text("context").notNull(),
    support: text("support").notNull(),
    reward: doublePrecision("reward").notNull(),
    weight: doublePrecision("weight").notNull(),
    reason: text("reason").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("support_outcomes_learner_idx").on(t.learnerId, t.createdAt)],
);

export const contentCache = pgTable("content_cache", {
  key: text("key").primaryKey(),
  plan: jsonb("plan").notNull(),
  source: text("source").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
