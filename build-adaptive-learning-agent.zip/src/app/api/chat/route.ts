import { NextResponse } from "next/server";
import { COOKIE, engine, learnerId, llmConfigured, summarize } from "@/lib/runtime";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { message?: string };
  const message = typeof body.message === "string" ? body.message.slice(0, 8000) : "";
  const { id, isNew } = await learnerId();
  try {
    const result = await engine().turn(id, message);
    const res = NextResponse.json({ reply: result.reply, trace: result.trace, turnId: result.turn.id, model: summarize(result.model), llm: llmConfigured() });
    if (isNew) res.cookies.set(COOKIE, id, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 365 * 5 });
    return res;
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "The tutor hit an internal error; your model was not changed by this turn." }, { status: 500 });
  }
}
