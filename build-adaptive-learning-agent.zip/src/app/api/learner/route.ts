// GET: inspect the learner model + recent turns with traces. POST: correct a belief. DELETE: erase everything.
import { NextResponse } from "next/server";
import { COOKIE, engine, learnerId, llmConfigured, summarize } from "@/lib/runtime";
import { PgStore } from "@/lib/store/pg";

export const runtime = "nodejs";

export async function GET(req: Request) {
  const { id, isNew } = await learnerId();
  const url = new URL(req.url);
  const model = await engine().load(id);
  const store = new PgStore();
  const turns = isNew ? [] : await store.recentTurns(id, 40);
  const payload: Record<string, unknown> = { model: summarize(model), turns, llm: llmConfigured() };
  if (url.searchParams.get("export") === "1" && !isNew) {
    payload.attempts = await store.attempts(id);
    payload.observations = await store.observations(id);
    payload.supportOutcomes = await store.supportOutcomes(id);
    payload.rawModel = model;
  }
  const res = NextResponse.json(payload);
  if (isNew) res.cookies.set(COOKIE, id, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 365 * 5 });
  return res;
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { beliefId?: string; replacement?: string | null };
  if (!body.beliefId) return NextResponse.json({ error: "beliefId required" }, { status: 400 });
  const { id } = await learnerId();
  const r = await engine().correct(id, body.beliefId, body.replacement?.trim() || null);
  return NextResponse.json({ changes: r.changes, model: summarize(r.model) });
}

export async function DELETE() {
  const { id } = await learnerId();
  await new PgStore().erase(id);
  const res = NextResponse.json({ ok: true });
  res.cookies.set(COOKIE, "", { path: "/", maxAge: 0 });
  return res;
}
