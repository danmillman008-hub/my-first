import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Private self-adapting learning agent",
  description: "One learner, one continuous relationship. A tutor that builds an evidence-based, correctable model of you.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-zinc-100 text-zinc-900 antialiased">{children}</body>
    </html>
  );
}
