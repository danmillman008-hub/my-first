import { db } from "@/db";
import { sessions } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { DEFAULT_LEARNER_ID, ensureLearner, getOrCreateSession } from "@/lib/agent/tutor";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(sessions).where(eq(sessions.learnerId, DEFAULT_LEARNER_ID)).orderBy(desc(sessions.lastActiveAt)).limit(50);
  return Response.json({ sessions: rows });
}

export async function POST() {
  await ensureLearner(DEFAULT_LEARNER_ID);
  const s = await getOrCreateSession(DEFAULT_LEARNER_ID, null);
  return Response.json({ session: s });
}
