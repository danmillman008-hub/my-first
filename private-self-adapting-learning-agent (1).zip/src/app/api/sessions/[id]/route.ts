import { db } from "@/db";
import { messages, sessions } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
  if (!session) return Response.json({ error: "not found" }, { status: 404 });
  const rows = await db.select().from(messages).where(eq(messages.sessionId, id)).orderBy(asc(messages.createdAt));
  return Response.json({ session, messages: rows });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  await db.delete(messages).where(eq(messages.sessionId, id));
  await db.delete(sessions).where(eq(sessions.id, id));
  return Response.json({ ok: true });
}
