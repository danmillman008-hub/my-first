import { runTurn, DEFAULT_LEARNER_ID } from "@/lib/agent/tutor";
import { configFromRequest } from "@/lib/llm/request";
import { isConfigured } from "@/lib/llm/provider";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { sessionId?: string | null; content?: string; learnerId?: string };
  const content = (body.content ?? "").trim();
  if (!content) return Response.json({ error: "content required" }, { status: 400 });
  const cfg = configFromRequest(req);
  if (!isConfigured(cfg)) {
    return Response.json(
      { error: "No language model configured. Set OPENAI_API_KEY (and optionally OPENAI_BASE_URL / LLM_MODEL) on the server, or add a key in Settings." },
      { status: 428 },
    );
  }
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      let open = true;
      // Never let a disconnected client abort the memory work that follows the reply.
      const send = (obj: unknown) => {
        if (!open) return;
        try {
          controller.enqueue(encoder.encode(JSON.stringify(obj) + "\n"));
        } catch {
          open = false;
        }
      };
      try {
        for await (const ev of runTurn({ learnerId: body.learnerId ?? DEFAULT_LEARNER_ID, sessionId: body.sessionId ?? null, content, cfg })) {
          send(ev);
        }
      } catch (e) {
        console.error("[chat] turn failed", e);
        send({ type: "error", error: (e as Error).message });
        send({ type: "done" });
      } finally {
        if (open) {
          try {
            controller.close();
          } catch {
            /* already closed */
          }
        }
      }
    },
  });
  return new Response(stream, {
    headers: { "content-type": "application/x-ndjson; charset=utf-8", "cache-control": "no-cache", "x-accel-buffering": "no" },
  });
}
