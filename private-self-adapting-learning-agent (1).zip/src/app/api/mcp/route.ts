/**
 * MCP (Model Context Protocol) server — Streamable HTTP transport, stateless mode.
 * Lets external assistants read and extend this learner's accumulated model
 * without recreating the history. Connect any MCP client to POST /api/mcp.
 */
import { buildBrief } from "@/lib/memory/brief";
import { listNodes, listEdges, CLAIM_KINDS } from "@/lib/memory/graph";
import { addObservations } from "@/lib/memory/observations";
import { runTool } from "@/lib/agent/tools";
import { runTurn, DEFAULT_LEARNER_ID } from "@/lib/agent/tutor";
import { configFromRequest } from "@/lib/llm/request";
import { isConfigured } from "@/lib/llm/provider";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

const PROTOCOL_VERSION = "2025-06-18";

const TOOLS = [
  {
    name: "get_learner_brief",
    description: "The learner-memory brief the tutor itself reads: durable observations, concept estimates, what has worked, open hypotheses, recent evidence. Optionally focused on a topic.",
    inputSchema: { type: "object", properties: { topic: { type: "string" } } },
  },
  {
    name: "search_memory",
    description: "Search the learner's long-term memory nodes and past evidence for a query.",
    inputSchema: { type: "object", properties: { query: { type: "string" } }, required: ["query"] },
  },
  {
    name: "get_graph",
    description: "Return the learner graph (nodes with confidence/mastery/status and edges). Optionally filter by node kind, e.g. concept, pattern, preference, strategy, hypothesis.",
    inputSchema: { type: "object", properties: { kind: { type: "string" }, include_inactive: { type: "boolean" } } },
  },
  {
    name: "add_observation",
    description: "Add a piece of evidence about the learner observed by an external tool (e.g. 'completed exercise X with two syntax errors'). It flows through the same consolidation as native evidence.",
    inputSchema: {
      type: "object",
      properties: { content: { type: "string" }, kind: { type: "string" }, entities: { type: "array", items: { type: "string" } }, outcome: { type: "string", enum: ["success", "struggle", "confusion", "insight"] }, activity: { type: "string" } },
      required: ["content"],
    },
  },
  {
    name: "revise_belief",
    description: "Confirm, contradict or retire a claim in the learner model by its label, citing the reason. History is preserved.",
    inputSchema: { type: "object", properties: { label: { type: "string" }, action: { type: "string", enum: ["confirm", "contradict", "retire"] }, reason: { type: "string" } }, required: ["label", "action", "reason"] },
  },
  {
    name: "recommend_next",
    description: "Evidence-derived suggestions: shaky concepts worth revisiting, approaches that have worked, open hypotheses worth a cheap test.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "tutor_turn",
    description: "Send a learner message through the full adaptive tutor (memory brief, tools, observer, consolidation) and get the reply. Requires a configured language model on the server.",
    inputSchema: { type: "object", properties: { message: { type: "string" }, session_id: { type: "string" } }, required: ["message"] },
  },
];

type RpcReq = { jsonrpc: "2.0"; id?: string | number | null; method: string; params?: Record<string, unknown> };

export async function POST(req: Request) {
  let body: RpcReq | RpcReq[];
  try {
    body = await req.json();
  } catch {
    return rpcError(null, -32700, "Parse error");
  }
  const reqs = Array.isArray(body) ? body : [body];
  const responses: unknown[] = [];
  for (const r of reqs) {
    const res = await handle(r, req);
    if (res !== undefined) responses.push(res);
  }
  if (!responses.length) return new Response(null, { status: 202 });
  return Response.json(Array.isArray(body) ? responses : responses[0]);
}

export async function GET() {
  return Response.json(
    { name: "learning-agent-mcp", protocolVersion: PROTOCOL_VERSION, hint: "POST JSON-RPC 2.0 here (initialize, tools/list, tools/call)." },
    { status: 200 },
  );
}

export async function DELETE() {
  return new Response(null, { status: 200 });
}

async function handle(r: RpcReq, req: Request): Promise<unknown> {
  if (!r || r.jsonrpc !== "2.0" || typeof r.method !== "string") return rpcErrorObj(r?.id ?? null, -32600, "Invalid request");
  const id = r.id ?? null;
  const isNotification = r.id === undefined;
  try {
    switch (r.method) {
      case "initialize":
        return ok(id, {
          protocolVersion: PROTOCOL_VERSION,
          capabilities: { tools: { listChanged: false } },
          serverInfo: { name: "learning-agent", version: "1.0.0" },
          instructions: "Private self-adapting learning agent. Use get_learner_brief before helping this learner; add_observation to contribute evidence.",
        });
      case "notifications/initialized":
      case "notifications/cancelled":
        return undefined;
      case "ping":
        return ok(id, {});
      case "tools/list":
        return ok(id, { tools: TOOLS });
      case "tools/call": {
        const name = String(r.params?.name ?? "");
        const args = (r.params?.arguments ?? {}) as Record<string, unknown>;
        const text = await callTool(name, args, req);
        return ok(id, { content: [{ type: "text", text }] });
      }
      default:
        if (isNotification) return undefined;
        return rpcErrorObj(id, -32601, `Method not found: ${r.method}`);
    }
  } catch (e) {
    return rpcErrorObj(id, -32000, (e as Error).message);
  }
}

async function callTool(name: string, args: Record<string, unknown>, req: Request): Promise<string> {
  const learnerId = DEFAULT_LEARNER_ID;
  switch (name) {
    case "get_learner_brief": {
      const topic = String(args.topic ?? "");
      const b = await buildBrief(learnerId, topic, { entities: topic ? topic.split(/\s+/) : [] });
      return b.text;
    }
    case "search_memory":
      return (await runTool("recall", JSON.stringify({ query: args.query }), { learnerId, sessionId: "mcp" })).result;
    case "get_graph": {
      const [nodes, edges] = await Promise.all([listNodes(learnerId, { includeInactive: Boolean(args.include_inactive) }), listEdges(learnerId)]);
      const kind = args.kind ? String(args.kind) : null;
      const ns = nodes.filter((n) => !kind || n.kind === kind);
      const ids = new Set(ns.map((n) => n.id));
      return JSON.stringify(
        {
          nodes: ns.map((n) => ({ id: n.id, kind: n.kind, label: n.label, summary: n.summary, context: n.context, status: n.status, confidence: n.confidence, mastery: n.mastery, activation: n.activation, supports: n.supports, contradicts: n.contradicts, signals: n.signals, lastReinforced: n.lastReinforced })),
          edges: edges.filter((e) => ids.has(e.fromNode) && ids.has(e.toNode)).map((e) => ({ from: e.fromNode, to: e.toNode, relation: e.relation, weight: e.weight, supports: e.supports, contradicts: e.contradicts })),
        },
        null,
        1,
      );
    }
    case "add_observation": {
      const saved = await addObservations([
        {
          learnerId,
          sessionId: "mcp",
          source: "mcp",
          kind: String(args.kind ?? "external"),
          content: String(args.content ?? ""),
          entities: Array.isArray(args.entities) ? (args.entities as unknown[]).map(String) : [],
          outcome: args.outcome ? String(args.outcome) : null,
          activity: args.activity ? String(args.activity) : null,
          salience: 0.6,
        },
      ]);
      return saved.length ? `Recorded observation ${saved[0].id}. It will be consolidated with the next batch.` : "Nothing recorded.";
    }
    case "revise_belief":
      return (await runTool("revise_belief", JSON.stringify(args), { learnerId, sessionId: "mcp" })).result;
    case "recommend_next": {
      const [nodes, edges] = await Promise.all([listNodes(learnerId), listEdges(learnerId)]);
      const byId = new Map(nodes.map((n) => [n.id, n]));
      const shaky = nodes.filter((n) => n.kind === "concept" && n.mastery !== null && n.mastery < 0.45).sort((a, b) => b.activation - a.activation).slice(0, 6);
      const strong = nodes.filter((n) => n.kind === "concept" && (n.mastery ?? 0) >= 0.65).slice(0, 6);
      const works = edges.filter((e) => e.relation === "works_for").map((e) => `${byId.get(e.fromNode)?.label} → ${byId.get(e.toNode)?.label} (×${e.supports})`).slice(0, 8);
      const open = nodes.filter((n) => CLAIM_KINDS.has(n.kind) && n.kind !== "strategy" && n.kind !== "goal" && n.status === "active" && n.confidence < 0.4).slice(0, 5);
      const goals = nodes.filter((n) => n.kind === "goal" && n.status === "active").map((n) => n.label);
      return [
        goals.length ? `Stated goals: ${goals.join("; ")}` : "No explicit goals recorded.",
        shaky.length ? `Worth revisiting (struggled recently): ${shaky.map((n) => `${n.label} (~${Math.round((n.mastery ?? 0) * 100)}%)`).join(", ")}` : "No shaky concepts on record.",
        strong.length ? `Can build on: ${strong.map((n) => n.label).join(", ")}` : "",
        works.length ? `Approaches that have worked: ${works.join("; ")}` : "No strategy evidence yet.",
        open.length ? `Open hypotheses (cheap to test if relevant): ${open.map((n) => n.label).join("; ")}` : "",
        "Caveat: these are evidence-derived priors; today's behaviour outranks them.",
      ]
        .filter(Boolean)
        .join("\n");
    }
    case "tutor_turn": {
      const cfg = configFromRequest(req);
      if (!isConfigured(cfg)) return "No language model configured on the server (set OPENAI_API_KEY).";
      let text = "";
      let sessionId = args.session_id ? String(args.session_id) : null;
      for await (const ev of runTurn({ learnerId, sessionId, content: String(args.message ?? ""), cfg })) {
        if (ev.type === "token") text += ev.text;
        if (ev.type === "session") sessionId = ev.sessionId;
        if (ev.type === "error") text += `\n[error: ${ev.error}]`;
      }
      return `${text}\n\n[session_id: ${sessionId}]`;
    }
    default:
      throw new Error(`Unknown tool ${name}`);
  }
}

function ok(id: string | number | null, result: unknown) {
  return { jsonrpc: "2.0", id, result };
}
function rpcErrorObj(id: string | number | null, code: number, message: string) {
  return { jsonrpc: "2.0", id, error: { code, message } };
}
function rpcError(id: string | number | null, code: number, message: string) {
  return Response.json(rpcErrorObj(id, code, message), { status: 400 });
}
