import { listNodes, listEdges } from "@/lib/memory/graph";
import { recentObservations, unconsolidatedObservations } from "@/lib/memory/observations";
import { recentMemoryEvents } from "@/lib/memory/consolidate";
import { recentResearch } from "@/lib/agent/tools";
import { buildBrief } from "@/lib/memory/brief";
import { DEFAULT_LEARNER_ID } from "@/lib/agent/tutor";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const learnerId = url.searchParams.get("learner") ?? DEFAULT_LEARNER_ID;
  const withBrief = url.searchParams.get("brief") === "1";
  const [nodes, edges, observations, pending, events, research, brief] = await Promise.all([
    listNodes(learnerId, { includeInactive: true }),
    listEdges(learnerId),
    recentObservations(learnerId, 60),
    unconsolidatedObservations(learnerId, 200),
    recentMemoryEvents(learnerId, 40),
    recentResearch(learnerId, 8),
    withBrief ? buildBrief(learnerId, "") : Promise.resolve(null),
  ]);
  return Response.json({ nodes, edges, observations, pendingCount: pending.length, events, research, brief: brief?.text ?? null });
}
