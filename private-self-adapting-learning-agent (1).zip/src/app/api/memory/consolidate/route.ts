import { consolidate } from "@/lib/memory/consolidate";
import { configFromRequest } from "@/lib/llm/request";
import { isConfigured } from "@/lib/llm/provider";
import { DEFAULT_LEARNER_ID } from "@/lib/agent/tutor";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function POST(req: Request) {
  const cfg = configFromRequest(req);
  if (!isConfigured(cfg)) return Response.json({ error: "No language model configured" }, { status: 428 });
  const result = await consolidate(DEFAULT_LEARNER_ID, cfg, { force: true });
  return Response.json(result);
}
