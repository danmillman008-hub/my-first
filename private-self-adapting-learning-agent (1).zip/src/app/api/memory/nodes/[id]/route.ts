import { getNode, setNodeStatus, nodeEvidence } from "@/lib/memory/graph";
import { getObservationsByIds } from "@/lib/memory/observations";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const node = await getNode(id);
  if (!node) return Response.json({ error: "not found" }, { status: 404 });
  const links = await nodeEvidence(id);
  const obs = await getObservationsByIds(links.map((l) => l.observationId));
  const byId = new Map(obs.map((o) => [o.id, o]));
  return Response.json({ node, evidence: links.map((l) => ({ ...l, observation: byId.get(l.observationId) ?? null })) });
}

/** The learner can correct their own model: "that's not me" retires a claim; "that's right" keeps it. */
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = (await req.json().catch(() => ({}))) as { status?: string; reason?: string };
  const allowed = ["retired", "active"];
  if (!body.status || !allowed.includes(body.status)) return Response.json({ error: "status must be retired|active" }, { status: 400 });
  const updated = await setNodeStatus(id, body.status, body.reason || "learner override", "learner");
  if (!updated) return Response.json({ error: "not found" }, { status: 404 });
  return Response.json({ node: updated });
}
