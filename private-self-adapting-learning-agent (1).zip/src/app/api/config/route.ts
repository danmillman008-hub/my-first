import { resolveConfig, isConfigured } from "@/lib/llm/provider";
import { configFromRequest } from "@/lib/llm/request";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const env = resolveConfig();
  const effective = configFromRequest(req);
  return Response.json({
    envConfigured: isConfigured(env),
    configured: isConfigured(effective),
    provider: effective.provider,
    model: effective.model,
    baseUrl: effective.baseUrl,
  });
}
