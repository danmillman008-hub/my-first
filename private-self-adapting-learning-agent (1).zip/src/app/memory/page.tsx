import MemoryExplorer from "@/components/MemoryExplorer";

export const dynamic = "force-dynamic";

export default function MemoryPage() {
  return <MemoryExplorer />;
}
