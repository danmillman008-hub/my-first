import {
  pgTable,
  text,
  timestamp,
  integer,
  real,
  boolean,
  jsonb,
  index,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// Learners & conversation
// ---------------------------------------------------------------------------

export const learners = pgTable("learners", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    title: text("title").notNull().default("New conversation"),
    // A lightly-maintained running note of "where the conversation is" (topic, activity)
    summary: text("summary"),
    startedAt: timestamp("started_at", { withTimezone: true }).defaultNow().notNull(),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("sessions_learner_idx").on(t.learnerId, t.lastActiveAt)],
);

export const messages = pgTable(
  "messages",
  {
    id: text("id").primaryKey(),
    sessionId: text("session_id").notNull(),
    learnerId: text("learner_id").notNull(),
    role: text("role").notNull(), // user | assistant
    content: text("content").notNull(),
    // tool calls made, research performed, approach notes, etc.
    meta: jsonb("meta").$type<Record<string, unknown>>().default({}).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("messages_session_idx").on(t.sessionId, t.createdAt)],
);

// ---------------------------------------------------------------------------
// Short-term / working memory: the evidence stream.
// Rich, recent, lightly interpreted. Never deleted; only marked consolidated.
// `kind` is free text on purpose – categories are allowed to emerge.
// ---------------------------------------------------------------------------

export const observations = pgTable(
  "observations",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    sessionId: text("session_id"),
    messageId: text("message_id"),
    source: text("source").notNull().default("observer"), // observer | agent | learner | mcp | system
    kind: text("kind").notNull().default("note"), // free text
    content: text("content").notNull(), // what happened, in plain language
    entities: jsonb("entities").$type<string[]>().default([]).notNull(), // concepts/topics touched
    activity: text("activity"), // learning | debugging | building | chatting | reflecting | ...
    outcome: text("outcome"), // success | struggle | confusion | insight | ... | null
    strategy: text("strategy"), // what the tutor tried right before, if relevant
    interpretation: text("interpretation"), // tentative meaning, clearly separated from the fact
    salience: real("salience").notNull().default(0.5), // tentative, 0..1
    consolidatedAt: timestamp("consolidated_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("observations_learner_time_idx").on(t.learnerId, t.createdAt),
    index("observations_unconsolidated_idx").on(t.learnerId, t.consolidatedAt),
  ],
);

// ---------------------------------------------------------------------------
// Long-term memory: a graph that earns its structure.
// Numbers (confidence, activation, mastery) are computed from linked evidence,
// not asserted by the model.
// ---------------------------------------------------------------------------

export const nodes = pgTable(
  "nodes",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    kind: text("kind").notNull(), // concept | pattern | preference | strategy | goal | context | hypothesis | ... (free)
    label: text("label").notNull(),
    summary: text("summary").notNull().default(""),
    // context in which this holds, if it's context-specific (e.g. "while debugging")
    context: text("context"),
    status: text("status").notNull().default("active"), // active | dormant | contradicted | retired | merged
    supports: integer("supports").notNull().default(0),
    contradicts: integer("contradicts").notNull().default(0),
    distinctSessions: integer("distinct_sessions").notNull().default(0),
    confidence: real("confidence").notNull().default(0.2),
    // recency-weighted, evidence-based level (mainly used for concepts)
    mastery: real("mastery"),
    // per-kind signals: {confusion: n, success: n, curiosity: n, practical: n ...}
    signals: jsonb("signals").$type<Record<string, number>>().default({}).notNull(),
    data: jsonb("data").$type<Record<string, unknown>>().default({}).notNull(),
    firstSeen: timestamp("first_seen", { withTimezone: true }).defaultNow().notNull(),
    lastReinforced: timestamp("last_reinforced", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("nodes_learner_idx").on(t.learnerId, t.status),
    index("nodes_label_idx").on(t.learnerId, t.label),
  ],
);

export const edges = pgTable(
  "edges",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    fromNode: text("from_node").notNull(),
    toNode: text("to_node").notNull(),
    relation: text("relation").notNull(), // related_to | prerequisite_of | confused_with | works_for | fails_for | in_context | part_of | ...
    weight: real("weight").notNull().default(1),
    supports: integer("supports").notNull().default(0),
    contradicts: integer("contradicts").notNull().default(0),
    status: text("status").notNull().default("active"),
    data: jsonb("data").$type<Record<string, unknown>>().default({}).notNull(),
    lastReinforced: timestamp("last_reinforced", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("edges_learner_idx").on(t.learnerId, t.fromNode, t.toNode)],
);

// Which observations back which nodes/edges (history stays recoverable).
export const evidenceLinks = pgTable(
  "evidence_links",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    nodeId: text("node_id"),
    edgeId: text("edge_id"),
    observationId: text("observation_id").notNull(),
    polarity: text("polarity").notNull().default("supports"), // supports | contradicts
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("evidence_node_idx").on(t.nodeId),
    index("evidence_obs_idx").on(t.observationId),
  ],
);

// A journal of what the memory system did and why. Makes the model inspectable.
export const memoryEvents = pgTable(
  "memory_events",
  {
    id: text("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    type: text("type").notNull(), // node_created | reinforced | contradicted | revised | retired | merged | edge_created | consolidation_run | learner_override
    nodeId: text("node_id"),
    detail: text("detail").notNull(),
    data: jsonb("data").$type<Record<string, unknown>>().default({}).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("memory_events_learner_idx").on(t.learnerId, t.createdAt)],
);

// Cached research so domain structure the agent discovered is reusable.
export const researchNotes = pgTable("research_notes", {
  id: text("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  query: text("query").notNull(),
  summary: text("summary").notNull(),
  sources: jsonb("sources").$type<{ title: string; url: string }[]>().default([]).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
