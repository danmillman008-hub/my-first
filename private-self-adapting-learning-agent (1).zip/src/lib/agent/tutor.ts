import { db } from "@/db";
import { messages, sessions, learners } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { streamChat, completeJSON, type ChatMessage, type LLMConfig, type ToolCall } from "@/lib/llm/provider";
import { TOOL_SPECS, runTool } from "./tools";
import { buildBrief } from "@/lib/memory/brief";
import { addObservations, type NewObservation } from "@/lib/memory/observations";
import { consolidate, type ConsolidationResult } from "@/lib/memory/consolidate";
import { newId } from "@/lib/memory/math";

export const DEFAULT_LEARNER_ID = "me";

export type TurnEvent =
  | { type: "session"; sessionId: string; title: string }
  | { type: "token"; text: string }
  | { type: "tool"; name: string; status: "start" | "done"; summary?: string }
  | { type: "message"; messageId: string }
  | { type: "memory"; observations: number; consolidation: ConsolidationResult | null; summary?: string | null }
  | { type: "error"; error: string }
  | { type: "done" };

const PERSONA = `You are a private tutor and thinking partner for one person. You are talking with them right now. Over time you build an evidence-based understanding of how this particular person learns — but the conversation always comes first.

How you work
- Follow the learner's lead. They may learn, ask, wander, vent, debug, build, switch subjects, or drop a topic mid-way. All of that is fine; go with them without friction. A curriculum is a tool you may offer, never a cage.
- You decide freely, each turn, what is most useful: answer directly, explain, show a concrete example, ask one good question, propose a small exercise, ask them to write or predict something, inspect their work, research, or simply keep talking. Do not run a fixed routine (no "first a diagnostic, then a lesson, then a quiz").
- Learn from behaviour more than from self-report. A learner's code, explanation, mistake, or reaction to your last explanation tells you more than asking "how do you like to learn?". Never send questionnaires.
- Clarify when ambiguity matters, not merely because it exists. If a cheap question or a tiny task ("what do you think this prints?") would genuinely change what you do next, use it — at most one, woven naturally into the reply. Otherwise make a sensible assumption and move.
- Don't overload. Introduce a few things at a time unless the person is clearly moving fast. Match depth to the situation: terse while they debug, deeper when they are studying, precise when they ask for reference.
- Be honest about uncertainty. If you are unsure of a fact, the subject is unfamiliar or fast-moving, or the learner wants sources, use the research/read_url tools and cite what you used. Say when you don't know.
- When the learner produces work, read it closely and respond to what is actually there.

Memory
- Before this message you receive a MEMORY BRIEF: durable observations, concept estimates, what has worked, open hypotheses, and raw recent evidence. Treat it as a prior. The person in front of you always outranks the brief. If today's behaviour contradicts it, believe today, and if the contradiction is clear, call revise_belief. If an open hypothesis is confirmed by what they do, you may confirm it.
- Use memory naturally ("last time you got closures working with the counter example — let's build on that"), never clinically ("according to my model of you"). Do not narrate your pedagogy or label the learner.
- Use remember for things that will matter later and that an observer might miss: goals, constraints, corrections of your assumptions, things they built, strong reactions.
- Use recall when they refer to something from the past that isn't in the brief.

Style
- Warm, direct, concrete. Markdown with code blocks where useful. No filler, no praise inflation. End with at most one question, and only when it helps.`;

export interface TurnInput {
  learnerId?: string;
  sessionId?: string | null;
  content: string;
  cfg: LLMConfig;
}

export async function ensureLearner(learnerId: string) {
  const [l] = await db.select().from(learners).where(eq(learners.id, learnerId));
  if (!l) await db.insert(learners).values({ id: learnerId, name: learnerId === DEFAULT_LEARNER_ID ? "You" : learnerId });
}

export async function getOrCreateSession(learnerId: string, sessionId?: string | null) {
  if (sessionId) {
    const [s] = await db.select().from(sessions).where(and(eq(sessions.id, sessionId), eq(sessions.learnerId, learnerId)));
    if (s) return s;
  }
  const [s] = await db.insert(sessions).values({ id: newId("s"), learnerId }).returning();
  return s;
}

/**
 * One conversational turn. Yields streaming events; persists everything.
 */
export async function* runTurn(input: TurnInput): AsyncGenerator<TurnEvent> {
  const learnerId = input.learnerId ?? DEFAULT_LEARNER_ID;
  await ensureLearner(learnerId);
  const session = await getOrCreateSession(learnerId, input.sessionId);
  const content = input.content.trim();
  const isFirst = (await db.select({ id: messages.id }).from(messages).where(eq(messages.sessionId, session.id)).limit(1)).length === 0;
  const title = isFirst ? content.replace(/\s+/g, " ").slice(0, 60) + (content.length > 60 ? "…" : "") : session.title;
  if (isFirst) await db.update(sessions).set({ title }).where(eq(sessions.id, session.id));
  yield { type: "session", sessionId: session.id, title };

  const [userMsg] = await db
    .insert(messages)
    .values({ id: newId("m"), sessionId: session.id, learnerId, role: "user", content })
    .returning();

  // working memory: recent turns of this session
  const historyRows = await db
    .select()
    .from(messages)
    .where(eq(messages.sessionId, session.id))
    .orderBy(desc(messages.createdAt))
    .limit(30);
  const history = historyRows.reverse();

  const brief = await buildBrief(learnerId, content, {
    entities: keywordEntities(content),
    sessionSummary: session.summary,
    currentSessionId: session.id,
  });

  const now = new Date();
  const system = `${PERSONA}\n\nCurrent date: ${now.toISOString().slice(0, 10)}.\n\n===== MEMORY BRIEF =====\n${brief.text}\n===== END MEMORY BRIEF =====`;

  const convo: ChatMessage[] = [
    { role: "system", content: system },
    ...history.slice(0, -1).map((m) => ({ role: m.role as "user" | "assistant", content: m.content })),
    { role: "user", content },
  ];

  // ---- agent loop with tools
  let finalText = "";
  const toolLog: { name: string; summary: string }[] = [];
  const MAX_ROUNDS = 5;
  let errored = false;
  for (let round = 0; round < MAX_ROUNDS; round++) {
    let pendingCalls: ToolCall[] | null = null;
    let roundText = "";
    for await (const ev of streamChat(input.cfg, { messages: convo, tools: round < MAX_ROUNDS - 1 ? TOOL_SPECS : undefined, purpose: "tutor" })) {
      if (ev.type === "token" && ev.text) {
        roundText += ev.text;
        yield { type: "token", text: ev.text };
      } else if (ev.type === "tool_calls" && ev.toolCalls) {
        pendingCalls = ev.toolCalls;
      } else if (ev.type === "error") {
        errored = true;
        yield { type: "error", error: ev.error ?? "LLM error" };
      }
    }
    if (errored) break;
    finalText += roundText;
    if (!pendingCalls?.length) break;
    convo.push({ role: "assistant", content: roundText || null, tool_calls: pendingCalls });
    for (const call of pendingCalls) {
      yield { type: "tool", name: call.name, status: "start" };
      const { result, summary } = await runTool(call.name, call.arguments, { learnerId, sessionId: session.id, messageId: userMsg.id });
      toolLog.push({ name: call.name, summary });
      yield { type: "tool", name: call.name, status: "done", summary };
      convo.push({ role: "tool", tool_call_id: call.id, name: call.name, content: result });
    }
    if (roundText) {
      // model spoke before calling tools; keep a visual break for the continuation
      yield { type: "token", text: "\n\n" };
      finalText += "\n\n";
    }
  }

  if (errored || !finalText.trim()) {
    // Nothing trustworthy happened: keep the user's message, but don't fabricate a reply or evidence.
    if (!errored) yield { type: "error", error: "The model returned an empty response." };
    yield { type: "done" };
    return;
  }
  const [assistantMsg] = await db
    .insert(messages)
    .values({ id: newId("m"), sessionId: session.id, learnerId, role: "assistant", content: finalText, meta: { tools: toolLog } })
    .returning();
  yield { type: "message", messageId: assistantMsg.id };
  await db.update(sessions).set({ lastActiveAt: new Date() }).where(eq(sessions.id, session.id));

  // ---- observer pass: turn the exchange into evidence
  const prevAssistant = [...history].reverse().find((m) => m.role === "assistant");
  let obsCount = 0;
  let summary: string | null = session.summary ?? null;
  try {
    const observed = await observe(input.cfg, {
      previousAssistant: prevAssistant?.content ?? null,
      user: content,
      assistant: finalText,
      sessionSummary: session.summary,
      turnIndex: history.length,
    });
    if (observed) {
      const items: NewObservation[] = observed.observations.map((o) => ({
        learnerId,
        sessionId: session.id,
        messageId: userMsg.id,
        source: "observer",
        kind: o.kind,
        content: o.content,
        entities: o.entities,
        activity: o.activity ?? null,
        outcome: o.outcome ?? null,
        strategy: o.strategy ?? null,
        interpretation: o.interpretation ?? null,
        salience: o.salience,
      }));
      const saved = await addObservations(items);
      obsCount = saved.length;
      if (observed.session_summary) {
        summary = observed.session_summary;
        await db.update(sessions).set({ summary }).where(eq(sessions.id, session.id));
      }
    }
  } catch (e) {
    console.error("[observer] failed", e);
  }

  // ---- slow timescale: consolidate when enough evidence accumulated
  let consolidation: ConsolidationResult | null = null;
  try {
    consolidation = await consolidate(learnerId, input.cfg);
    if (!consolidation.ran) consolidation = null;
  } catch (e) {
    console.error("[consolidate] failed", e);
  }
  yield { type: "memory", observations: obsCount, consolidation, summary };
  yield { type: "done" };
}

// ---------------------------------------------------------------------------
// Observer
// ---------------------------------------------------------------------------

interface ObservedItem {
  content: string;
  kind: string;
  entities: string[];
  activity?: string | null;
  outcome?: string | null;
  strategy?: string | null;
  interpretation?: string | null;
  salience: number;
}
interface Observed {
  observations: ObservedItem[];
  session_summary?: string | null;
}

const OBSERVER_SYSTEM = `You watch one exchange between a learner and their tutor and write down evidence worth keeping. You are the learner's short-term memory: rich, specific, lightly interpreted.

Rules
- Record what happened, in plain language, as a fact about this exchange. Examples: "Asked why closures keep state after the outer function returns", "Wrote a correct for-loop but used = instead of == in the condition", "Said they are learning Bash for a devops job", "Said 'skip the theory, just show me'", "Switched from OOP to asking about git rebase", "Explained recursion back correctly in their own words after the tree example".
- Do NOT diagnose or generalise ("visual learner", "lacks confidence", "prefers examples"). If you can't resist a hunch, put it in "interpretation" — clearly separate, and only when it's grounded in this exchange.
- 0–4 observations per exchange. Skip pleasantries. One good observation beats three vague ones. Include things whose importance is unknown yet (a casual remark about their job, a tool they use, a frustration).
- kind: a short free-form tag — e.g. question, statement, mistake, success, confusion, insight, preference, goal, context, correction, topic_switch, request, code, reflection, frustration, curiosity. Invent one if needed.
- entities: 1–4 short concept/topic labels touched (e.g. "closures", "bash", "for loop", "git rebase"). Lower-case, canonical, no sentences.
- activity: what the learner is doing — learning, debugging, building, chatting, reflecting, planning, reviewing, exploring.
- outcome: ONLY when the learner demonstrated something: success (correct answer/working code/correct explanation), struggle (attempt with errors), confusion (said or showed they don't get it), insight ("oh, so it's like…" that is correct). Otherwise null. Self-reports like "I know this" are statements, not success.
- strategy: what the tutor did in its PREVIOUS message that the learner is now reacting to — e.g. concrete-example, analogy, formal-definition, exercise, socratic-question, step-by-step, direct-answer, code-review, visual-diagram, contrast-example. Set it ONLY on observations that describe the learner's reaction to that previous message, and only if a previous tutor message is given.
- salience 0–1: how likely this matters later (a stated goal ≈0.9; a specific mistake ≈0.6; a passing question ≈0.3).
- session_summary: one line — where the conversation is now (topic, activity, anything mid-flight).

Respond with JSON: {"observations":[{"content":"","kind":"","entities":[],"activity":"","outcome":null,"strategy":null,"interpretation":null,"salience":0.5}],"session_summary":""}`;

async function observe(
  cfg: LLMConfig,
  x: { previousAssistant: string | null; user: string; assistant: string; sessionSummary: string | null | undefined; turnIndex: number },
): Promise<Observed | null> {
  const user = [
    x.sessionSummary ? `Conversation so far: ${x.sessionSummary}` : "Start of conversation.",
    x.previousAssistant ? `PREVIOUS TUTOR MESSAGE (what the learner is reacting to):\n${x.previousAssistant.slice(0, 2500)}` : "PREVIOUS TUTOR MESSAGE: (none)",
    `LEARNER:\n${x.user.slice(0, 4000)}`,
    `TUTOR REPLY:\n${x.assistant.slice(0, 2500)}`,
  ].join("\n\n");
  const out = await completeJSON<Observed>(cfg, {
    purpose: "observe",
    messages: [
      { role: "system", content: OBSERVER_SYSTEM },
      { role: "user", content: user },
    ],
  });
  if (!out || !Array.isArray(out.observations)) return null;
  out.observations = out.observations
    .filter((o) => o && typeof o.content === "string" && o.content.trim())
    .slice(0, 5)
    .map((o) => ({
      content: o.content,
      kind: String(o.kind || "note"),
      entities: Array.isArray(o.entities) ? o.entities.map(String).slice(0, 4) : [],
      activity: o.activity ? String(o.activity) : null,
      outcome: o.outcome && ["success", "struggle", "confusion", "insight"].includes(String(o.outcome)) ? String(o.outcome) : null,
      strategy: x.previousAssistant && o.strategy ? String(o.strategy) : null,
      interpretation: o.interpretation ? String(o.interpretation) : null,
      salience: typeof o.salience === "number" ? o.salience : 0.5,
    }));
  return out;
}

const STOP = new Set(
  "the a an and or but if then else for to of in on at by with from about into over after before is are was were be been being do does did have has had i you we they it this that these those my your our me him her them what which who whom how why when where can could should would will just like want learn teach know understand dont don't really actually something things thing please help me something anything let lets let's ok okay yes no not so too very also again more less some any".split(" "),
);

export function keywordEntities(text: string): string[] {
  return [...new Set(
    text
      .toLowerCase()
      .replace(/[^a-z0-9+#.\- ]+/g, " ")
      .split(/\s+/)
      .filter((w) => w.length > 2 && !STOP.has(w)),
  )].slice(0, 12);
}
