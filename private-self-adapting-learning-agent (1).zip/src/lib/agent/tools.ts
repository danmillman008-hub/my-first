import { db } from "@/db";
import { researchNotes } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import type { ToolSpec } from "@/lib/llm/provider";
import { addObservations, retrieveObservations } from "@/lib/memory/observations";
import { listNodes, getNode, linkEvidence, setNodeStatus, CLAIM_KINDS } from "@/lib/memory/graph";
import { newId } from "@/lib/memory/math";

export const TOOL_SPECS: ToolSpec[] = [
  {
    name: "research",
    description:
      "Look up a subject on the web (encyclopedic + general search) when you are unsure of facts, need the structure of an unfamiliar subject, want current information, or the learner asks for sources. Returns titles, URLs and snippets. Don't use it for things you already know well.",
    parameters: {
      type: "object",
      properties: { query: { type: "string", description: "Search query" } },
      required: ["query"],
    },
  },
  {
    name: "read_url",
    description: "Fetch a web page (documentation, article, repository README, man page) as plain text so you can ground an explanation in it. Use after research, or when the learner shares a link.",
    parameters: {
      type: "object",
      properties: { url: { type: "string" } },
      required: ["url"],
    },
  },
  {
    name: "recall",
    description:
      "Search this learner's long-term memory and past evidence for something specific that is not in your brief (e.g. 'what did we do about recursion last month', 'have they mentioned their job'). Returns matching memories with dates.",
    parameters: {
      type: "object",
      properties: { query: { type: "string" } },
      required: ["query"],
    },
  },
  {
    name: "remember",
    description:
      "Store a specific observation about this learner that the automatic observer might miss and that will matter later (a stated goal, a constraint, a strong reaction, something they built, a correction of what you assumed). Describe what happened, not a diagnosis.",
    parameters: {
      type: "object",
      properties: {
        note: { type: "string", description: "What happened / what they said, in plain language" },
        entities: { type: "array", items: { type: "string" }, description: "Concepts or topics involved (short labels)" },
        kind: { type: "string", description: "Free-form tag, e.g. goal, preference, constraint, correction, achievement, context" },
      },
      required: ["note"],
    },
  },
  {
    name: "revise_belief",
    description:
      "Use when the learner's behaviour or words clearly contradict something in your memory brief, or confirm an open hypothesis. Pass the node label exactly as shown in the brief. 'contradict' lowers confidence and marks it if repeated; 'retire' removes it from active use (history is kept); 'confirm' strengthens it.",
    parameters: {
      type: "object",
      properties: {
        label: { type: "string", description: "Label of the memory node as shown in the brief" },
        action: { type: "string", enum: ["contradict", "confirm", "retire"] },
        reason: { type: "string", description: "What the learner did or said that justifies this" },
      },
      required: ["label", "action", "reason"],
    },
  },
];

export interface ToolContext {
  learnerId: string;
  sessionId: string;
  messageId?: string | null;
}

export async function runTool(name: string, rawArgs: string, ctx: ToolContext): Promise<{ result: string; summary: string }> {
  let args: Record<string, unknown> = {};
  try {
    args = rawArgs ? JSON.parse(rawArgs) : {};
  } catch {
    return { result: "Invalid JSON arguments", summary: `${name}: bad args` };
  }
  switch (name) {
    case "research":
      return research(String(args.query ?? ""), ctx);
    case "read_url":
      return readUrl(String(args.url ?? ""));
    case "recall":
      return recall(String(args.query ?? ""), ctx);
    case "remember":
      return remember(args, ctx);
    case "revise_belief":
      return reviseBelief(args, ctx);
    default:
      return { result: `Unknown tool ${name}`, summary: `unknown tool ${name}` };
  }
}

// ---------------------------------------------------------------------------

async function research(query: string, ctx: ToolContext) {
  if (!query) return { result: "Empty query", summary: "research: empty" };
  const results: { title: string; url: string; snippet: string }[] = [];
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), 9000);
  try {
    const [wiki, ddg] = await Promise.allSettled([wikipedia(query, ac.signal), duckduckgo(query, ac.signal)]);
    if (wiki.status === "fulfilled") results.push(...wiki.value);
    if (ddg.status === "fulfilled") results.push(...ddg.value);
  } finally {
    clearTimeout(timer);
  }
  const seen = new Set<string>();
  const dedup = results.filter((r) => (seen.has(r.url) ? false : (seen.add(r.url), true))).slice(0, 8);
  if (!dedup.length) return { result: "No results found (search may be unavailable). Rely on your own knowledge and say so.", summary: `research "${query}": no results` };
  const text = dedup.map((r, i) => `${i + 1}. ${r.title}\n   ${r.url}\n   ${r.snippet}`).join("\n");
  await db.insert(researchNotes).values({
    id: newId("rn"),
    learnerId: ctx.learnerId,
    query,
    summary: text.slice(0, 4000),
    sources: dedup.map((r) => ({ title: r.title, url: r.url })),
  });
  return { result: text, summary: `researched "${query}" (${dedup.length} sources)` };
}

async function wikipedia(query: string, signal: AbortSignal) {
  const url = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&srlimit=4&utf8=1`;
  const res = await fetch(url, { signal, headers: { "user-agent": "learning-agent/1.0 (private tutor)" } });
  if (!res.ok) return [];
  const data = (await res.json()) as { query?: { search?: { title: string; snippet: string }[] } };
  return (data.query?.search ?? []).map((s) => ({
    title: s.title,
    url: `https://en.wikipedia.org/wiki/${encodeURIComponent(s.title.replace(/ /g, "_"))}`,
    snippet: stripHtml(s.snippet),
  }));
}

async function duckduckgo(query: string, signal: AbortSignal) {
  const res = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`, {
    signal,
    headers: { "user-agent": "Mozilla/5.0 (X11; Linux x86_64) learning-agent/1.0" },
  });
  if (!res.ok) return [];
  const html = await res.text();
  const out: { title: string; url: string; snippet: string }[] = [];
  const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html)) && out.length < 6) {
    let href = m[1];
    const uddg = href.match(/uddg=([^&]+)/);
    if (uddg) href = decodeURIComponent(uddg[1]);
    out.push({ title: stripHtml(m[2]), url: href, snippet: stripHtml(m[3]) });
  }
  return out;
}

async function readUrl(url: string) {
  if (!/^https?:\/\//i.test(url)) return { result: "Only http(s) URLs are supported", summary: "read_url: invalid" };
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), 10000);
  try {
    const res = await fetch(url, { signal: ac.signal, headers: { "user-agent": "Mozilla/5.0 learning-agent/1.0", accept: "text/html,text/plain,application/json;q=0.9,*/*;q=0.5" } });
    const ctype = res.headers.get("content-type") ?? "";
    const raw = await res.text();
    const text = /html/.test(ctype) ? htmlToText(raw) : raw;
    return { result: text.slice(0, 7000) + (text.length > 7000 ? "\n…[truncated]" : ""), summary: `read ${new URL(url).hostname}` };
  } catch (e) {
    return { result: `Could not fetch: ${(e as Error).message}`, summary: `read_url failed` };
  } finally {
    clearTimeout(timer);
  }
}

async function recall(query: string, ctx: ToolContext) {
  const [obs, allNodes] = await Promise.all([retrieveObservations(ctx.learnerId, query, query.split(/\s+/), 10), listNodes(ctx.learnerId, { includeInactive: true })]);
  const q = query.toLowerCase();
  const nodeHits = allNodes.filter((n) => `${n.label} ${n.summary}`.toLowerCase().split(/\W+/).some((w) => w.length > 3 && q.includes(w))).slice(0, 8);
  const lines: string[] = [];
  if (nodeHits.length) lines.push("MEMORY NODES:\n" + nodeHits.map((n) => `- [${n.kind}, ${n.status}, ${Math.round(n.confidence * 100)}%] ${n.label}: ${n.summary}`).join("\n"));
  if (obs.length) lines.push("PAST EVIDENCE:\n" + obs.map((o) => `- ${o.createdAt.toISOString().slice(0, 10)} [${o.kind}] ${o.content}`).join("\n"));
  if (!lines.length) lines.push("Nothing relevant in memory.");
  return { result: lines.join("\n\n"), summary: `recalled "${query}" (${obs.length} memories)` };
}

async function remember(args: Record<string, unknown>, ctx: ToolContext) {
  const note = String(args.note ?? "").trim();
  if (!note) return { result: "Nothing to remember", summary: "remember: empty" };
  const entities = Array.isArray(args.entities) ? (args.entities as unknown[]).map(String) : [];
  await addObservations([
    {
      learnerId: ctx.learnerId,
      sessionId: ctx.sessionId,
      messageId: ctx.messageId ?? null,
      source: "agent",
      kind: String(args.kind ?? "note"),
      content: note,
      entities,
      salience: 0.8,
    },
  ]);
  return { result: "Remembered.", summary: `remembered: ${note.slice(0, 60)}` };
}

async function reviseBelief(args: Record<string, unknown>, ctx: ToolContext) {
  const label = String(args.label ?? "").trim();
  const action = String(args.action ?? "");
  const reason = String(args.reason ?? "").trim();
  const all = await listNodes(ctx.learnerId, { includeInactive: true });
  const norm = label.toLowerCase();
  const target =
    all.find((n) => n.label.toLowerCase() === norm) ??
    all.filter((n) => CLAIM_KINDS.has(n.kind)).find((n) => n.label.toLowerCase().includes(norm) || norm.includes(n.label.toLowerCase()));
  if (!target) return { result: `No memory node matching "${label}".`, summary: `revise_belief: not found` };
  const [obs] = await addObservations([
    {
      learnerId: ctx.learnerId,
      sessionId: ctx.sessionId,
      messageId: ctx.messageId ?? null,
      source: "agent",
      kind: action === "confirm" ? "confirmation" : "correction",
      content: `${action === "confirm" ? "Confirmed" : "Contradicted"} belief "${target.label}": ${reason}`,
      entities: [],
      salience: 0.9,
    },
  ]);
  const fresh = await getNode(target.id);
  if (!fresh) return { result: "Node vanished", summary: "revise_belief: missing" };
  if (action === "retire") {
    await linkEvidence(fresh, [obs], "contradicts", reason);
    await setNodeStatus(fresh.id, "retired", reason, "agent");
    return { result: `Retired "${fresh.label}". History kept.`, summary: `retired belief: ${fresh.label}` };
  }
  const updated = await linkEvidence(fresh, [obs], action === "confirm" ? "supports" : "contradicts", reason);
  return {
    result: `${action === "confirm" ? "Confirmed" : "Contradicted"} "${fresh.label}" → confidence ${Math.round(updated.confidence * 100)}%, status ${updated.status}.`,
    summary: `${action === "confirm" ? "confirmed" : "questioned"} belief: ${fresh.label}`,
  };
}

// ---------------------------------------------------------------------------

function stripHtml(s: string) {
  return s
    .replace(/<[^>]+>/g, "")
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, "&")
    .replace(/&#x27;|&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function htmlToText(html: string) {
  return stripHtml(
    html
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<nav[\s\S]*?<\/nav>/gi, " ")
      .replace(/<(br|p|div|li|h[1-6]|tr|pre)[^>]*>/gi, "\n")
      .replace(/<\/(p|div|li|h[1-6]|tr|pre)>/gi, "\n"),
  ).replace(/\n\s*\n+/g, "\n");
}

export async function recentResearch(learnerId: string, limit = 10) {
  return db.select().from(researchNotes).where(eq(researchNotes.learnerId, learnerId)).orderBy(desc(researchNotes.createdAt)).limit(limit);
}
