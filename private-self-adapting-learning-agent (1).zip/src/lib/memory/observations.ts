import { db } from "@/db";
import { observations } from "@/db/schema";
import { and, desc, eq, isNull, sql } from "drizzle-orm";
import { newId, normalizeLabel, DAY_MS } from "./math";

export type Observation = typeof observations.$inferSelect;

export interface NewObservation {
  learnerId: string;
  sessionId?: string | null;
  messageId?: string | null;
  source?: string;
  kind?: string;
  content: string;
  entities?: string[];
  activity?: string | null;
  outcome?: string | null;
  strategy?: string | null;
  interpretation?: string | null;
  salience?: number;
}

export async function addObservations(items: NewObservation[]): Promise<Observation[]> {
  if (!items.length) return [];
  const rows = items
    .filter((i) => i.content && i.content.trim().length > 0)
    .map((i) => ({
      id: newId("obs"),
      learnerId: i.learnerId,
      sessionId: i.sessionId ?? null,
      messageId: i.messageId ?? null,
      source: i.source ?? "observer",
      kind: (i.kind || "note").toLowerCase().slice(0, 40),
      content: i.content.trim().slice(0, 1200),
      entities: uniq((i.entities ?? []).map(normalizeLabel).filter(Boolean)).slice(0, 8),
      activity: i.activity ?? null,
      outcome: i.outcome ?? null,
      strategy: i.strategy ? normalizeLabel(i.strategy) : null,
      interpretation: i.interpretation ?? null,
      salience: Math.max(0, Math.min(1, i.salience ?? 0.5)),
    }));
  if (!rows.length) return [];
  return db.insert(observations).values(rows).returning();
}

export async function recentObservations(learnerId: string, limit = 20, sinceMs?: number) {
  const conds = [eq(observations.learnerId, learnerId)];
  if (sinceMs) conds.push(sql`${observations.createdAt} > now() - make_interval(secs => ${sinceMs / 1000})`);
  return db
    .select()
    .from(observations)
    .where(and(...conds))
    .orderBy(desc(observations.createdAt))
    .limit(limit);
}

export async function unconsolidatedObservations(learnerId: string, limit = 60) {
  return db
    .select()
    .from(observations)
    .where(and(eq(observations.learnerId, learnerId), isNull(observations.consolidatedAt)))
    .orderBy(observations.createdAt)
    .limit(limit);
}

export async function markConsolidated(ids: string[]) {
  if (!ids.length) return;
  await db
    .update(observations)
    .set({ consolidatedAt: new Date() })
    .where(sql`${observations.id} in (${sql.join(ids.map((i) => sql`${i}`), sql`, `)})`);
}

export async function getObservationsByIds(ids: string[]) {
  if (!ids.length) return [];
  return db
    .select()
    .from(observations)
    .where(sql`${observations.id} in (${sql.join(ids.map((i) => sql`${i}`), sql`, `)})`);
}

/**
 * Retrieval in the spirit of Generative Agents: score = relevance + recency + salience.
 * Relevance is lexical (Postgres full text + entity overlap) so it works with any
 * provider and is fully testable offline.
 */
export async function retrieveObservations(
  learnerId: string,
  query: string,
  entities: string[] = [],
  limit = 12,
): Promise<(Observation & { score: number })[]> {
  const q = query.replace(/[^\p{L}\p{N}\s]/gu, " ").trim().slice(0, 400);
  const ents = uniq(entities.map(normalizeLabel).filter(Boolean));
  const entityArray = ents.length ? sql`ARRAY[${sql.join(ents.map((e) => sql`${e}::text`), sql`, `)}]` : sql`ARRAY[]::text[]`;
  type Row = { id: string; rank: number; ent_overlap: number };
  const result = await db.execute<Row>(sql`
    select o.id,
      coalesce(ts_rank_cd(to_tsvector('english', o.content || ' ' || coalesce(o.interpretation,'') || ' ' || array_to_string(array(select jsonb_array_elements_text(o.entities)), ' ')), plainto_tsquery('english', ${q})), 0) as rank,
      (select count(*) from jsonb_array_elements_text(o.entities) e where e = any(${entityArray}))::int as ent_overlap
    from observations o
    where o.learner_id = ${learnerId}
      and (
        plainto_tsquery('english', ${q}) @@ to_tsvector('english', o.content || ' ' || coalesce(o.interpretation,''))
        or exists (select 1 from jsonb_array_elements_text(o.entities) e where e = any(${entityArray}))
      )
    order by rank desc, o.created_at desc
    limit 80
  `);
  const list: Row[] = result.rows;
  if (!list?.length) return [];
  const full = await getObservationsByIds(list.map((r) => r.id));
  const byId = new Map(full.map((o) => [o.id, o]));
  const now = Date.now();
  const scored = list
    .map((r) => {
      const o = byId.get(r.id)!;
      const ageDays = (now - o.createdAt.getTime()) / DAY_MS;
      const recency = Math.exp(-ageDays / 14);
      const relevance = Math.min(1, Number(r.rank) * 4) * 0.6 + Math.min(1, Number(r.ent_overlap) / 2) * 0.4;
      const score = relevance * 1.0 + recency * 0.5 + o.salience * 0.4;
      return Object.assign({}, o, { score });
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
  return scored;
}

/** Count of the learner's distinct sessions that produced these observations. */
export function distinctSessionCount(obs: { sessionId: string | null }[]): number {
  return new Set(obs.map((o) => o.sessionId ?? "none")).size;
}

export function uniq<T>(xs: T[]): T[] {
  return [...new Set(xs)];
}
