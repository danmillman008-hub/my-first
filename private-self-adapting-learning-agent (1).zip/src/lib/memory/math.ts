/**
 * The numbers in the learner model are *derived from evidence* here, in code.
 * The language model decides what an observation is evidence *of*; it never
 * asserts a confidence directly. This keeps weak observations from becoming
 * confident claims (see "false psychological certainty").
 */

export const DAY_MS = 86_400_000;

/**
 * ACT-R style base-level activation: B = ln( sum_j t_j^-d ), t_j = age in days.
 * Mapped through a logistic to 0..1 so it is easy to reason about.
 * Frequently and recently reinforced things stay active; unused things fade.
 * Nothing is deleted when it fades – it becomes "dormant" but recoverable.
 */
export function activation(evidenceTimes: Date[], now = new Date(), d = 0.35): number {
  if (!evidenceTimes.length) return 0;
  let sum = 0;
  for (const t of evidenceTimes) {
    const ageDays = Math.max((now.getTime() - t.getTime()) / DAY_MS, 0.01);
    sum += Math.pow(ageDays, -d);
  }
  const b = Math.log(sum);
  // Calibrated in simulation: one fresh item ≈ 0.96, one item after 3 weeks ≈ 0.48,
  // after 3 months ≈ 0.33, after 6 months ≈ 0.27; repeated evidence keeps it high.
  return 1 / (1 + Math.exp(-(b + 1.0) * 1.2));
}

/**
 * Confidence in a claim about the learner (pattern / preference / hypothesis).
 *   - Beta-style estimate from supporting vs contradicting evidence.
 *   - Discounted when evidence comes from too few distinct sessions
 *     (a single conversation can be a mood, not a trait).
 *   - Recent contradictions weigh more than old support.
 */
export function claimConfidence(args: {
  supports: number;
  contradicts: number;
  distinctSessions: number;
  recentContradiction?: boolean;
  stated?: boolean;
}): number {
  const { supports, contradicts, distinctSessions } = args;
  const beta = (supports + 1) / (supports + contradicts + 2); // prior 0.5
  const breadth = Math.min(1, (distinctSessions + 0.5) / 3); // needs ~3 sessions to fully count
  const quantity = 1 - Math.exp(-supports / 2.5); // 1 obs -> 0.33, 3 -> 0.7, 6 -> 0.91
  // Things the learner *stated* (goals, context) start more credible than things we inferred.
  const floor = args.stated ? 0.55 : 0.35;
  let c = beta * (floor + (1 - floor) * breadth * quantity);
  if (args.recentContradiction) c *= 0.7;
  return clamp(c, 0.02, 0.97);
}

/** Mastery update from a single outcome, exponential recency weighting. */
export function updateMastery(prev: number | null, outcome: "success" | "struggle" | "confusion" | "insight" | string): number {
  const p = prev ?? 0.3;
  const target =
    outcome === "success" ? 1 : outcome === "insight" ? 0.85 : outcome === "struggle" ? 0.15 : outcome === "confusion" ? 0.1 : p;
  if (target === p) return p;
  const k = 0.3;
  return clamp(p + k * (target - p), 0, 1);
}

export function clamp(x: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, x));
}

export function newId(prefix = ""): string {
  const rnd = (globalThis.crypto ?? require("crypto")).randomUUID().replace(/-/g, "").slice(0, 20);
  return prefix ? `${prefix}_${rnd}` : rnd;
}

export function normalizeLabel(s: string): string {
  return s
    .toLowerCase()
    .replace(/[`"'()]/g, "")
    .replace(/[^a-z0-9+#.\- ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Cheap token-set similarity for label de-duplication. */
export function labelSimilarity(a: string, b: string): number {
  const A = new Set(normalizeLabel(a).split(" ").filter(Boolean));
  const B = new Set(normalizeLabel(b).split(" ").filter(Boolean));
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const x of A) if (B.has(x)) inter++;
  const jacc = inter / (A.size + B.size - inter);
  const na = normalizeLabel(a);
  const nb = normalizeLabel(b);
  if (na === nb) return 1;
  // containment counts only when the shorter label is substantial (avoid "bash" ⊂ "learning bash for a job")
  const shorter = na.length < nb.length ? na : nb;
  const longer = na.length < nb.length ? nb : na;
  if (longer.includes(shorter) && (shorter.split(" ").length >= 2 || shorter.length / longer.length >= 0.6)) return Math.max(jacc, 0.85);
  return jacc;
}
