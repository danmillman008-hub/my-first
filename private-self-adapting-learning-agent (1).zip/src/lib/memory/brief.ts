import { listNodes, listEdges, CLAIM_KINDS, STATED_KINDS, type NodeWithActivation, type Edge } from "./graph";
import { recentObservations, retrieveObservations, type Observation } from "./observations";
import { DAY_MS } from "./math";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export interface MemoryBrief {
  text: string;
  nodesUsed: number;
  observationsUsed: number;
}

/**
 * Compose the learner-memory brief the tutor reads before responding.
 * Deliberately framed as priors + raw recent evidence, not a verdict.
 */
export async function buildBrief(
  learnerId: string,
  query: string,
  opts: { entities?: string[]; sessionSummary?: string | null; currentSessionId?: string | null } = {},
): Promise<MemoryBrief> {
  const [allNodes, allEdges, recent, relevant, pastSessions] = await Promise.all([
    listNodes(learnerId),
    listEdges(learnerId),
    recentObservations(learnerId, 14, 3 * DAY_MS),
    retrieveObservations(learnerId, query, opts.entities ?? [], 10),
    db.select().from(sessions).where(eq(sessions.learnerId, learnerId)).orderBy(desc(sessions.lastActiveAt)).limit(5),
  ]);
  const previous = pastSessions.filter((s) => s.id !== opts.currentSessionId && (s.summary || s.title)).slice(0, 3);
  const now = Date.now();
  const byId = new Map(allNodes.map((n) => [n.id, n]));

  const stated = allNodes.filter((n) => STATED_KINDS.has(n.kind) && n.status === "active").slice(0, 8);
  const claims = allNodes
    .filter((n) => CLAIM_KINDS.has(n.kind) && n.kind !== "strategy" && !STATED_KINDS.has(n.kind) && n.status === "active")
    .sort((a, b) => b.confidence * (0.5 + b.activation) - a.confidence * (0.5 + a.activation));
  const solid = claims.filter((n) => n.confidence >= 0.4).slice(0, 12);
  const open = claims.filter((n) => n.confidence < 0.4).slice(0, 6);
  const contradicted = allNodes.filter((n) => n.status === "contradicted").slice(0, 5);
  const dormant = allNodes.filter((n) => n.status === "dormant" && CLAIM_KINDS.has(n.kind) && n.kind !== "strategy").slice(0, 4);

  const concepts = allNodes.filter((n) => n.kind === "concept" && n.status !== "merged");
  const conceptLine = (c: NodeWithActivation) => {
    const sig = Object.entries(c.signals ?? {})
      .filter(([k]) => ["success", "struggle", "confusion", "insight", "question", "curiosity", "practical", "mistake"].includes(k))
      .map(([k, v]) => `${k}×${v}`)
      .join(", ");
    const age = Math.round((now - c.lastReinforced.getTime()) / DAY_MS);
    return `${c.label}${c.mastery !== null ? ` (est. ${Math.round(c.mastery * 100)}%)` : ""}${sig ? ` [${sig}]` : ""}${age > 0 ? ` ~${age}d ago` : ""}`;
  };
  const demonstrated = concepts.filter((c) => (c.mastery ?? 0) >= 0.65);
  const shaky = concepts.filter((c) => c.mastery !== null && c.mastery < 0.4);
  const encountered = concepts
    .filter((c) => !demonstrated.includes(c) && !shaky.includes(c))
    .sort((a, b) => b.activation - a.activation)
    .slice(0, 12);

  // what works / fails: strategy edges
  const strategyLines: string[] = [];
  for (const e of allEdges) {
    if (e.relation !== "works_for" && e.relation !== "fails_for") continue;
    const s = byId.get(e.fromNode);
    const c = byId.get(e.toNode);
    if (!s || !c) continue;
    strategyLines.push(`${s.label} ${e.relation === "works_for" ? "helped" : "did not help"} with ${c.label}${e.data?.activity ? ` (while ${e.data.activity})` : ""} ×${e.supports}`);
  }
  const strategies = allNodes.filter((n) => n.kind === "strategy" && n.status !== "merged" && n.supports + n.contradicts > 0);

  const structure = allEdges
    .filter((e) => ["prerequisite_of", "confused_with", "part_of", "applies_to"].includes(e.relation))
    .map((e) => {
      const a = byId.get(e.fromNode);
      const b = byId.get(e.toNode);
      return a && b ? `${a.label} —${e.relation}→ ${b.label}` : null;
    })
    .filter(Boolean)
    .slice(0, 12) as string[];

  const seen = new Set<string>();
  const evidence: Observation[] = [];
  for (const o of [...relevant, ...recent]) {
    if (seen.has(o.id)) continue;
    seen.add(o.id);
    evidence.push(o);
  }
  evidence.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  const evidenceLines = evidence.slice(0, 18).map((o) => `- ${relTime(o.createdAt, now)} [${o.kind}${o.activity ? `/${o.activity}` : ""}${o.outcome ? `, ${o.outcome}` : ""}] ${o.content}`);

  const sections: string[] = [];
  const totalEvidence = allNodes.reduce((s, n) => s + n.supports, 0);
  if (!allNodes.length && !evidence.length) {
    sections.push("This is a new learner. You know nothing about them yet beyond this conversation. Find out what matters by working with them, not by interviewing them.");
  } else {
    sections.push(`Memory holds ${allNodes.length} nodes built from ${totalEvidence} pieces of evidence. Everything below is a prior, not a fact about today: the person in front of you may behave differently. If they do, believe the person.`);
  }
  if (stated.length) sections.push(`WHAT THE LEARNER HAS TOLD YOU (goals, situation)\n${stated.map((n) => `- [${n.kind}] ${n.label}${n.summary ? ` — ${n.summary}` : ""} (${relTime(n.lastReinforced, now)})`).join("\n")}`);
  if (solid.length) sections.push(`WHAT SEEMS DURABLE ABOUT THIS LEARNER (confidence · evidence · sessions)\n${solid.map(claimLine).join("\n")}`);
  if (open.length) sections.push(`OPEN HYPOTHESES (weak; may be cheaply tested if — and only if — the answer would change what you do next)\n${open.map(claimLine).join("\n")}`);
  if (contradicted.length) sections.push(`PREVIOUS BELIEFS NOW CONTRADICTED BY EVIDENCE (do not act on these)\n${contradicted.map(claimLine).join("\n")}`);
  if (dormant.length) sections.push(`FADED (old, unconfirmed — mention only if it resurfaces)\n${dormant.map((n) => `- ${n.label}`).join("\n")}`);
  if (demonstrated.length || shaky.length || encountered.length) {
    const parts: string[] = [];
    if (demonstrated.length) parts.push(`Demonstrated: ${demonstrated.map(conceptLine).join("; ")}`);
    if (shaky.length) parts.push(`Shaky / struggled: ${shaky.map(conceptLine).join("; ")}`);
    if (encountered.length) parts.push(`Encountered: ${encountered.map(conceptLine).join("; ")}`);
    sections.push(`CONCEPT STATE (estimates from observed outcomes; signals show *why* something recurs — confusion vs success vs curiosity)\n${parts.join("\n")}`);
  }
  if (structure.length) sections.push(`SUBJECT STRUCTURE DISCOVERED SO FAR\n${structure.join("\n")}`);
  if (strategyLines.length || strategies.length) {
    const lines = strategyLines.slice(0, 12);
    for (const s of strategies) lines.push(`overall: ${s.label} → helped ×${s.supports}, did not help ×${s.contradicts}`);
    sections.push(`WHAT HAS WORKED / NOT WORKED FOR THIS PERSON (learned from their reactions)\n${lines.join("\n")}`);
  }
  if (previous.length) sections.push(`PREVIOUS CONVERSATIONS (most recent first)\n${previous.map((s) => `- ${relTime(s.lastActiveAt, now)}: ${s.summary || s.title}`).join("\n")}`);
  if (opts.sessionSummary) sections.push(`THIS CONVERSATION SO FAR: ${opts.sessionSummary}`);
  if (evidenceLines.length) sections.push(`RECENT & RELEVANT RAW EVIDENCE (lightly interpreted; newest first)\n${evidenceLines.join("\n")}`);

  return { text: sections.join("\n\n"), nodesUsed: solid.length + open.length + concepts.length, observationsUsed: evidence.length };
}

function claimLine(n: NodeWithActivation): string {
  return `- [${n.kind}${n.context ? ` · while ${n.context}` : ""}] ${n.label}${n.summary ? ` — ${n.summary}` : ""} (${Math.round(n.confidence * 100)}% · ${n.supports}↑${n.contradicts ? ` ${n.contradicts}↓` : ""} · ${n.distinctSessions} session${n.distinctSessions === 1 ? "" : "s"})`;
}

export function relTime(d: Date, now = Date.now()): string {
  const m = Math.round((now - d.getTime()) / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h ago`;
  const days = Math.round(h / 24);
  return `${days}d ago`;
}

export type { Edge };
