import { db } from "@/db";
import { nodes, edges, evidenceLinks, memoryEvents } from "@/db/schema";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { activation, claimConfidence, labelSimilarity, newId, normalizeLabel, updateMastery, clamp } from "./math";
import type { Observation } from "./observations";

export type Node = typeof nodes.$inferSelect;
export type Edge = typeof edges.$inferSelect;
export type NodeWithActivation = Node & { activation: number };

/** Kinds that are claims *about the person* and therefore need cautious confidence. */
export const CLAIM_KINDS = new Set(["pattern", "preference", "hypothesis", "strategy", "trait", "context", "goal"]);
/** Kinds that are (mostly) things the learner told us, rather than things we inferred. */
export const STATED_KINDS = new Set(["goal", "context"]);

// ---------------------------------------------------------------------------
// Lookup
// ---------------------------------------------------------------------------

export async function listNodes(learnerId: string, opts: { includeInactive?: boolean } = {}): Promise<NodeWithActivation[]> {
  const rows = await db
    .select()
    .from(nodes)
    .where(
      opts.includeInactive
        ? eq(nodes.learnerId, learnerId)
        : and(eq(nodes.learnerId, learnerId), inArray(nodes.status, ["active", "dormant", "contradicted"])),
    )
    .orderBy(desc(nodes.lastReinforced));
  return withActivation(rows);
}

export async function listEdges(learnerId: string): Promise<Edge[]> {
  return db.select().from(edges).where(and(eq(edges.learnerId, learnerId), eq(edges.status, "active")));
}

export async function getNode(id: string) {
  const [n] = await db.select().from(nodes).where(eq(nodes.id, id));
  return n ?? null;
}

async function withActivation(rows: Node[]): Promise<NodeWithActivation[]> {
  if (!rows.length) return [];
  const ids = rows.map((r) => r.id);
  const links = await db
    .select({ nodeId: evidenceLinks.nodeId, createdAt: evidenceLinks.createdAt })
    .from(evidenceLinks)
    .where(inArray(evidenceLinks.nodeId, ids));
  const times = new Map<string, Date[]>();
  for (const l of links) {
    if (!l.nodeId) continue;
    const arr = times.get(l.nodeId) ?? [];
    arr.push(l.createdAt);
    times.set(l.nodeId, arr);
  }
  const now = new Date();
  return rows.map((r) => {
    const t = times.get(r.id) ?? [r.lastReinforced];
    return { ...r, activation: activation(t, now) };
  });
}

/**
 * Find a near-duplicate label within the same node *family*
 * (concepts only match concepts; claims about the person only match claims).
 */
export function findSimilarNode(list: Node[], label: string, kind?: string): Node | null {
  let best: Node | null = null;
  let bestScore = 0;
  const wantConcept = kind === "concept";
  for (const n of list) {
    if (kind && (n.kind === "concept") !== wantConcept) continue;
    if (kind && !wantConcept && kind !== n.kind && !(CLAIM_KINDS.has(kind) && CLAIM_KINDS.has(n.kind))) continue;
    if (n.status === "merged" || n.status === "retired") continue;
    const s = labelSimilarity(n.label, label);
    if (s > bestScore) {
      bestScore = s;
      best = n;
    }
  }
  return bestScore >= 0.75 ? best : null;
}

// ---------------------------------------------------------------------------
// Mutation with guardrails
// ---------------------------------------------------------------------------

export interface EnsureNodeArgs {
  learnerId: string;
  kind: string;
  label: string;
  summary?: string;
  context?: string | null;
  data?: Record<string, unknown>;
}

/** Create a node or return an existing near-duplicate. */
export async function ensureNode(args: EnsureNodeArgs, existing?: Node[]): Promise<{ node: Node; created: boolean }> {
  const pool = existing ?? (await db.select().from(nodes).where(eq(nodes.learnerId, args.learnerId)));
  const label = args.label.trim().slice(0, 80);
  const kind = args.kind.toLowerCase().trim().slice(0, 30);
  const dup = findSimilarNode(pool, label, kind);
  if (dup) {
    // Revive if dormant/retired, keep history.
    if (dup.status !== "active" && dup.status !== "contradicted") {
      await db.update(nodes).set({ status: "active", updatedAt: new Date() }).where(eq(nodes.id, dup.id));
      await journal(args.learnerId, "revived", dup.id, `Revived ${dup.kind} "${dup.label}" (new evidence after dormancy)`);
    }
    return { node: dup, created: false };
  }
  const isClaim = CLAIM_KINDS.has(kind);
  const [node] = await db
    .insert(nodes)
    .values({
      id: newId("n"),
      learnerId: args.learnerId,
      kind,
      label,
      summary: (args.summary ?? "").slice(0, 600),
      context: args.context ?? null,
      confidence: isClaim ? 0.15 : 0.5,
      mastery: kind === "concept" ? null : null,
      data: args.data ?? {},
    })
    .returning();
  pool.push(node);
  await journal(args.learnerId, "node_created", node.id, `New ${kind}: "${label}"${args.context ? ` (context: ${args.context})` : ""}`);
  return { node, created: true };
}

/**
 * Attach observations to a node as evidence and recompute derived numbers.
 * This is the *only* way confidence, mastery, signals change.
 */
export async function linkEvidence(
  node: Node,
  obs: Observation[],
  polarity: "supports" | "contradicts",
  note?: string,
): Promise<Node> {
  if (!obs.length) return node;
  // avoid double-linking same observation to same node
  const already = await db
    .select({ observationId: evidenceLinks.observationId })
    .from(evidenceLinks)
    .where(and(eq(evidenceLinks.nodeId, node.id), inArray(evidenceLinks.observationId, obs.map((o) => o.id))));
  const seen = new Set(already.map((a) => a.observationId));
  // One conversational event should count once: if another observation from the same
  // message already backs this node with the same polarity, don't double count.
  const priorLinks = await db
    .select({ observationId: evidenceLinks.observationId, polarity: evidenceLinks.polarity })
    .from(evidenceLinks)
    .where(eq(evidenceLinks.nodeId, node.id));
  const priorObsIds = priorLinks.filter((l) => l.polarity === polarity).map((l) => l.observationId);
  const priorMsgIds = new Set<string>();
  if (priorObsIds.length) {
    const rows = await db.execute<{ message_id: string | null }>(
      sql`select message_id from observations where id in (${sql.join(priorObsIds.map((i) => sql`${i}`), sql`, `)})`,
    );
    for (const r of rows.rows) if (r.message_id) priorMsgIds.add(r.message_id);
  }
  const fresh: Observation[] = [];
  for (const o of obs) {
    if (seen.has(o.id)) continue;
    if (o.messageId && priorMsgIds.has(o.messageId)) continue;
    if (o.messageId) priorMsgIds.add(o.messageId);
    fresh.push(o);
  }
  if (!fresh.length) return node;

  await db.insert(evidenceLinks).values(
    fresh.map((o) => ({
      id: newId("ev"),
      learnerId: node.learnerId,
      nodeId: node.id,
      observationId: o.id,
      polarity,
      note: note ?? null,
    })),
  );

  // recompute from the full evidence set
  const all = await db
    .select({ polarity: evidenceLinks.polarity, createdAt: evidenceLinks.createdAt, observationId: evidenceLinks.observationId })
    .from(evidenceLinks)
    .where(eq(evidenceLinks.nodeId, node.id));
  const supports = all.filter((a) => a.polarity === "supports").length;
  const contradicts = all.filter((a) => a.polarity === "contradicts").length;
  const sessionIds = new Set<string>();
  const obsById = new Map(obs.map((o) => [o.id, o]));
  // distinct sessions: count from newly linked + previously stored count approximation
  for (const o of fresh) sessionIds.add(o.sessionId ?? "none");
  const prevSessions = new Set<string>((node.data?.sessions as string[] | undefined) ?? []);
  for (const s of sessionIds) prevSessions.add(s);
  const distinctSessions = prevSessions.size;

  const recentContradiction = polarity === "contradicts";
  const isClaim = CLAIM_KINDS.has(node.kind);
  let confidence = node.confidence;
  if (isClaim) {
    confidence = claimConfidence({ supports, contradicts, distinctSessions, recentContradiction, stated: STATED_KINDS.has(node.kind) });
  } else {
    confidence = clamp(0.4 + 0.1 * Math.log1p(supports), 0.4, 0.95);
  }

  // signals & mastery (mainly concepts): derived from outcome/kind of supporting observations
  const signals = { ...(node.signals ?? {}) };
  let mastery = node.mastery;
  const activities = { ...((node.data?.activities as Record<string, number> | undefined) ?? {}) };
  for (const o of fresh) {
    const oo = obsById.get(o.id)!;
    const key = oo.outcome || oo.kind;
    if (key) signals[key] = (signals[key] ?? 0) + 1;
    if (oo.activity) activities[oo.activity] = (activities[oo.activity] ?? 0) + 1;
    if (node.kind === "concept" && oo.outcome && ["success", "struggle", "confusion", "insight"].includes(oo.outcome)) {
      mastery = updateMastery(mastery, oo.outcome);
    }
  }

  let status = node.status;
  if (isClaim) {
    if (contradicts >= 2 && contradicts >= supports) status = "contradicted";
    else if (status === "contradicted" && supports > contradicts + 1) status = "active";
    else if (status === "dormant") status = "active";
  } else if (status === "dormant") status = "active";

  // A hypothesis that keeps being confirmed across sessions graduates into a durable claim.
  let kind = node.kind;
  if (kind === "hypothesis" && supports >= 3 && distinctSessions >= 2 && confidence > 0.5 && status === "active") {
    kind = guessGraduatedKind(node);
    await journal(node.learnerId, "graduated", node.id, `Hypothesis "${node.label}" earned enough evidence (${supports} across ${distinctSessions} sessions) to become a ${kind}`);
  }

  const [updated] = await db
    .update(nodes)
    .set({
      kind,
      supports,
      contradicts,
      distinctSessions,
      confidence,
      mastery,
      signals,
      status,
      lastReinforced: polarity === "supports" ? new Date() : node.lastReinforced,
      updatedAt: new Date(),
      data: { ...(node.data ?? {}), sessions: [...prevSessions].slice(-50), activities },
      ...(node.kind === "strategy" && Object.keys(activities).length
        ? { context: Object.entries(activities).sort((a, b) => b[1] - a[1])[0][0] }
        : {}),
    })
    .where(eq(nodes.id, node.id))
    .returning();

  await journal(
    node.learnerId,
    polarity === "supports" ? "reinforced" : "contradicted",
    node.id,
    `${polarity === "supports" ? "Reinforced" : "Contradicted"} ${node.kind} "${node.label}" with ${fresh.length} observation(s) → confidence ${confidence.toFixed(2)}${status !== node.status ? `, status ${node.status} → ${status}` : ""}${note ? ` — ${note}` : ""}`,
    { observationIds: fresh.map((o) => o.id) },
  );
  return updated;
}

function guessGraduatedKind(n: Node): string {
  const t = `${n.label} ${n.summary}`.toLowerCase();
  if (/prefer|likes|wants|enjoys|dislikes|hates|asks for|terse|detailed/.test(t)) return "preference";
  if (/goal|wants to build|aims/.test(t)) return "goal";
  return "pattern";
}

export async function reviseNode(nodeId: string, patch: { summary?: string; context?: string | null; label?: string }, reason: string) {
  const n = await getNode(nodeId);
  if (!n) return null;
  // A revision is how a contradicted belief gets *resolved* (usually narrowed to a context),
  // so it returns to active use with its new, more careful summary.
  const resolves = n.status === "contradicted";
  const [updated] = await db
    .update(nodes)
    .set({
      ...(patch.summary !== undefined ? { summary: patch.summary.slice(0, 600) } : {}),
      ...(patch.context !== undefined ? { context: patch.context } : {}),
      ...(patch.label !== undefined ? { label: patch.label.slice(0, 80) } : {}),
      ...(resolves ? { status: "active", data: { ...(n.data ?? {}), revisedFromContradiction: true } } : {}),
      updatedAt: new Date(),
    })
    .where(eq(nodes.id, nodeId))
    .returning();
  await journal(n.learnerId, "revised", n.id, `Revised ${n.kind} "${n.label}"${resolves ? " (resolving contradiction)" : ""}: ${reason}`);
  return updated;
}

export async function setNodeStatus(nodeId: string, status: string, reason: string, source = "system") {
  const n = await getNode(nodeId);
  if (!n) return null;
  const [updated] = await db
    .update(nodes)
    .set({
      status,
      updatedAt: new Date(),
      ...(status === "retired" ? { confidence: Math.min(n.confidence, 0.1) } : {}),
    })
    .where(eq(nodes.id, nodeId))
    .returning();
  await journal(n.learnerId, source === "learner" ? "learner_override" : status, n.id, `${n.kind} "${n.label}" → ${status}: ${reason}`);
  return updated;
}

export async function mergeNodes(keepId: string, removeId: string, reason: string) {
  const keep = await getNode(keepId);
  const remove = await getNode(removeId);
  if (!keep || !remove || keep.id === remove.id) return;
  await db.update(evidenceLinks).set({ nodeId: keep.id }).where(eq(evidenceLinks.nodeId, remove.id));
  await db.update(edges).set({ fromNode: keep.id }).where(eq(edges.fromNode, remove.id));
  await db.update(edges).set({ toNode: keep.id }).where(eq(edges.toNode, remove.id));
  await db
    .update(nodes)
    .set({
      supports: keep.supports + remove.supports,
      contradicts: keep.contradicts + remove.contradicts,
      status: "active",
      updatedAt: new Date(),
    })
    .where(eq(nodes.id, keep.id));
  await db.update(nodes).set({ status: "merged", data: { ...remove.data, mergedInto: keep.id }, updatedAt: new Date() }).where(eq(nodes.id, remove.id));
  await journal(keep.learnerId, "merged", keep.id, `Merged "${remove.label}" into "${keep.label}": ${reason}`);
}

export async function ensureEdge(args: {
  learnerId: string;
  fromNode: string;
  toNode: string;
  relation: string;
  polarity?: "supports" | "contradicts";
  observationIds?: string[];
  weightDelta?: number;
  data?: Record<string, unknown>;
}): Promise<Edge | null> {
  if (args.fromNode === args.toNode) return null;
  const relation = args.relation.toLowerCase().trim().slice(0, 40);
  const symmetric = relation === "related_to" || relation === "confused_with";
  const existing = await db
    .select()
    .from(edges)
    .where(
      and(
        eq(edges.learnerId, args.learnerId),
        eq(edges.relation, relation),
        symmetric
          ? sql`((${edges.fromNode} = ${args.fromNode} and ${edges.toNode} = ${args.toNode}) or (${edges.fromNode} = ${args.toNode} and ${edges.toNode} = ${args.fromNode}))`
          : and(eq(edges.fromNode, args.fromNode), eq(edges.toNode, args.toNode)),
      ),
    );
  const polarity = args.polarity ?? "supports";
  const delta = args.weightDelta ?? 1;
  let edge: Edge;
  if (existing[0]) {
    const e = existing[0];
    const supports = e.supports + (polarity === "supports" ? 1 : 0);
    const contradicts = e.contradicts + (polarity === "contradicts" ? 1 : 0);
    const [u] = await db
      .update(edges)
      .set({
        weight: polarity === "supports" ? e.weight + delta : Math.max(0.1, e.weight - delta),
        supports,
        contradicts,
        status: contradicts >= 2 && contradicts > supports ? "contradicted" : "active",
        lastReinforced: new Date(),
        data: { ...e.data, ...(args.data ?? {}) },
      })
      .where(eq(edges.id, e.id))
      .returning();
    edge = u;
  } else {
    const [c] = await db
      .insert(edges)
      .values({
        id: newId("e"),
        learnerId: args.learnerId,
        fromNode: args.fromNode,
        toNode: args.toNode,
        relation,
        weight: polarity === "supports" ? delta : 0.5,
        supports: polarity === "supports" ? 1 : 0,
        contradicts: polarity === "contradicts" ? 1 : 0,
        data: args.data ?? {},
      })
      .returning();
    edge = c;
    await journal(args.learnerId, "edge_created", args.fromNode, `Edge ${relation} (${args.fromNode} → ${args.toNode})`, { edgeId: c.id });
  }
  if (args.observationIds?.length) {
    await db.insert(evidenceLinks).values(
      args.observationIds.map((oid) => ({
        id: newId("ev"),
        learnerId: args.learnerId,
        edgeId: edge.id,
        observationId: oid,
        polarity,
      })),
    );
  }
  return edge;
}

/** Nodes whose activation fell below threshold become dormant (recoverable). */
export async function applyDormancy(learnerId: string) {
  const all = await listNodes(learnerId);
  let changed = 0;
  for (const n of all) {
    const daysSince = (Date.now() - n.lastReinforced.getTime()) / 86_400_000;
    const stated = STATED_KINDS.has(n.kind);
    if (n.status === "active" && n.activation < 0.28 && n.supports <= 2 && daysSince > (stated ? 180 : 60)) {
      await db.update(nodes).set({ status: "dormant", updatedAt: new Date() }).where(eq(nodes.id, n.id));
      changed++;
    }
  }
  if (changed) await journal(learnerId, "decay", null, `${changed} weakly-supported node(s) faded to dormant (still recoverable)`);
  return changed;
}

export async function journal(learnerId: string, type: string, nodeId: string | null, detail: string, data: Record<string, unknown> = {}) {
  await db.insert(memoryEvents).values({ id: newId("me"), learnerId, type, nodeId, detail: detail.slice(0, 800), data });
}

export async function nodeEvidence(nodeId: string) {
  return db
    .select()
    .from(evidenceLinks)
    .where(eq(evidenceLinks.nodeId, nodeId))
    .orderBy(desc(evidenceLinks.createdAt))
    .limit(50);
}

export { normalizeLabel };
