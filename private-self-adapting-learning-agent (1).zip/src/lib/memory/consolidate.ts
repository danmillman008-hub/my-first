import { db } from "@/db";
import { nodes, memoryEvents } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { completeJSON, type LLMConfig } from "@/lib/llm/provider";
import {
  ensureNode,
  ensureEdge,
  linkEvidence,
  reviseNode,
  mergeNodes,
  applyDormancy,
  journal,
  CLAIM_KINDS,
  type Node,
} from "./graph";
import { unconsolidatedObservations, markConsolidated, type Observation } from "./observations";
import { normalizeLabel } from "./math";

export const CONSOLIDATION_THRESHOLD = 8;

interface ConsolidationOp {
  op: "create_node" | "link_evidence" | "revise_node" | "create_edge" | "merge_nodes";
  kind?: string;
  label?: string;
  summary?: string;
  context?: string | null;
  node_id?: string;
  evidence?: string[];
  polarity?: "supports" | "contradicts";
  note?: string;
  reason?: string;
  from?: string;
  to?: string;
  relation?: string;
  keep?: string;
  remove?: string;
}

export interface ConsolidationResult {
  ran: boolean;
  observations: number;
  created: string[];
  reinforced: string[];
  contradicted: string[];
  revised: string[];
  notes: string[];
}

/**
 * Run consolidation if enough new evidence accumulated (or forced).
 */
export async function consolidate(
  learnerId: string,
  cfg: LLMConfig,
  opts: { force?: boolean } = {},
): Promise<ConsolidationResult> {
  const result: ConsolidationResult = { ran: false, observations: 0, created: [], reinforced: [], contradicted: [], revised: [], notes: [] };
  const pending = await unconsolidatedObservations(learnerId, 60);
  if (!pending.length) return result;
  // "Sleep" consolidation: a small batch left over from an earlier conversation is consolidated
  // once it has gone quiet for a while, so long-term memory doesn't lag a session behind.
  const newest = pending[pending.length - 1].createdAt.getTime();
  const stale = pending.length >= 2 && Date.now() - newest > 2 * 60 * 60 * 1000;
  if (!opts.force && !stale && pending.length < CONSOLIDATION_THRESHOLD) return result;
  result.ran = true;
  result.observations = pending.length;

  const pool: Node[] = await db.select().from(nodes).where(eq(nodes.learnerId, learnerId));
  const obsById = new Map(pending.map((o) => [o.id, o]));

  // ---- 1. Deterministic structure: concepts, co-occurrence, strategy outcomes
  const conceptTouched = new Map<string, Node>();
  for (const o of pending) {
    const ents = (o.entities ?? []).slice(0, 6);
    const nodesHere: Node[] = [];
    for (const ent of ents) {
      if (ent.length < 2) continue;
      const { node, created } = await ensureNode({ learnerId, kind: "concept", label: ent }, pool);
      if (created) result.created.push(`concept:${node.label}`);
      const updated = await linkEvidence(node, [o], "supports");
      replaceInPool(pool, updated);
      nodesHere.push(updated);
      conceptTouched.set(updated.id, updated);
    }
    // co-occurrence → related_to (emergent structure; weight grows with repetition)
    for (let i = 0; i < nodesHere.length; i++)
      for (let j = i + 1; j < nodesHere.length; j++)
        await ensureEdge({ learnerId, fromNode: nodesHere[i].id, toNode: nodesHere[j].id, relation: "related_to", observationIds: [o.id], weightDelta: 0.5 });

    // strategy → outcome evidence ("what works for this learner")
    if (o.strategy && o.outcome) {
      const { node: strat, created } = await ensureNode(
        { learnerId, kind: "strategy", label: o.strategy, summary: `Teaching approach: ${o.strategy}`, context: o.activity ?? null },
        pool,
      );
      if (created) result.created.push(`strategy:${strat.label}`);
      const positive = o.outcome === "success" || o.outcome === "insight";
      const negative = o.outcome === "confusion" || o.outcome === "struggle";
      if (positive || negative) {
        const updated = await linkEvidence(strat, [o], positive ? "supports" : "contradicts", `${o.outcome} while ${o.activity ?? "working"}`);
        replaceInPool(pool, updated);
        for (const c of nodesHere) {
          await ensureEdge({
            learnerId,
            fromNode: strat.id,
            toNode: c.id,
            relation: positive ? "works_for" : "fails_for",
            observationIds: [o.id],
            data: { activity: o.activity ?? null },
          });
        }
        result.reinforced.push(`${positive ? "works" : "fails"}:${strat.label}`);
      }
    }
  }

  // ---- 2. Interpretive consolidation via the model (patterns, preferences, contradictions)
  const claims = pool.filter((n) => CLAIM_KINDS.has(n.kind) && n.status !== "merged" && n.status !== "retired");
  const ops = await proposeOperations(cfg, pending, claims, [...conceptTouched.values()]);

  for (const op of ops) {
    try {
      if (op.op === "create_node" && op.label && op.kind) {
        const kind = op.kind.toLowerCase();
        if (kind === "concept") continue; // concepts are handled deterministically
        const ev = (op.evidence ?? []).map((id) => obsById.get(id)).filter(Boolean) as Observation[];
        // Guardrail: claims about the person need evidence; a single observation makes a *hypothesis*, not a pattern.
        if (CLAIM_KINDS.has(kind) && ev.length === 0) {
          result.notes.push(`Skipped "${op.label}": no evidence cited`);
          continue;
        }
        const effectiveKind = CLAIM_KINDS.has(kind) && ev.length < 2 && kind !== "goal" ? "hypothesis" : kind;
        const { node, created } = await ensureNode(
          { learnerId, kind: effectiveKind, label: op.label, summary: op.summary ?? "", context: op.context ?? null },
          pool,
        );
        const updated = await linkEvidence(node, ev, op.polarity === "contradicts" ? "contradicts" : "supports", op.note);
        replaceInPool(pool, updated);
        (created ? result.created : result.reinforced).push(`${effectiveKind}:${node.label}`);
      } else if (op.op === "link_evidence" && op.node_id) {
        const node = pool.find((n) => n.id === op.node_id);
        if (!node) continue;
        const ev = (op.evidence ?? []).map((id) => obsById.get(id)).filter(Boolean) as Observation[];
        if (!ev.length) continue;
        const polarity = op.polarity === "contradicts" ? "contradicts" : "supports";
        const updated = await linkEvidence(node, ev, polarity, op.note);
        replaceInPool(pool, updated);
        (polarity === "supports" ? result.reinforced : result.contradicted).push(`${node.kind}:${node.label}`);
      } else if (op.op === "revise_node" && op.node_id) {
        const node = pool.find((n) => n.id === op.node_id);
        if (!node) continue;
        const u = await reviseNode(node.id, { summary: op.summary, context: op.context }, op.reason ?? "consolidation");
        if (u) {
          replaceInPool(pool, u);
          result.revised.push(`${node.kind}:${node.label}`);
        }
      } else if (op.op === "create_edge" && op.from && op.to && op.relation) {
        const a = resolveNodeRef(pool, op.from);
        const b = resolveNodeRef(pool, op.to);
        if (!a || !b) continue;
        const ev = (op.evidence ?? []).filter((id) => obsById.has(id));
        await ensureEdge({ learnerId, fromNode: a.id, toNode: b.id, relation: op.relation, observationIds: ev, polarity: op.polarity });
      } else if (op.op === "merge_nodes" && op.keep && op.remove) {
        const a = resolveNodeRef(pool, op.keep);
        const b = resolveNodeRef(pool, op.remove);
        if (!a || !b || !CLAIM_KINDS.has(a.kind)) continue;
        await mergeNodes(a.id, b.id, op.reason ?? "duplicate");
      }
    } catch (e) {
      result.notes.push(`op failed: ${(e as Error).message}`);
    }
  }

  await markConsolidated(pending.map((o) => o.id));
  const faded = await applyDormancy(learnerId);
  if (faded) result.notes.push(`${faded} node(s) faded to dormant`);
  await journal(learnerId, "consolidation_run", null, `Consolidated ${pending.length} observations: +${result.created.length} nodes, ${result.reinforced.length} reinforcements, ${result.contradicted.length} contradictions, ${result.revised.length} revisions`, {
    created: result.created,
    contradicted: result.contradicted,
  });
  return result;
}

function replaceInPool(pool: Node[], n: Node) {
  const i = pool.findIndex((p) => p.id === n.id);
  if (i >= 0) pool[i] = n;
  else pool.push(n);
}

function resolveNodeRef(pool: Node[], ref: string): Node | null {
  const byId = pool.find((n) => n.id === ref);
  if (byId) return byId;
  const norm = normalizeLabel(ref);
  return pool.find((n) => normalizeLabel(n.label) === norm && n.status !== "merged") ?? null;
}

async function proposeOperations(cfg: LLMConfig, pending: Observation[], claims: Node[], concepts: Node[]): Promise<ConsolidationOp[]> {
  const obsText = pending
    .map(
      (o) =>
        `- id=${o.id} [${o.kind}${o.activity ? `, while ${o.activity}` : ""}${o.outcome ? `, outcome=${o.outcome}` : ""}${o.strategy ? `, after tutor used ${o.strategy}` : ""}] session=${(o.sessionId ?? "?").slice(-6)} ${o.createdAt.toISOString().slice(0, 16)}\n  ${o.content}${o.interpretation ? `\n  (tentative: ${o.interpretation})` : ""}${o.entities?.length ? `\n  entities: ${o.entities.join(", ")}` : ""}`,
    )
    .join("\n");
  const claimText = claims.length
    ? claims
        .map(
          (n) =>
            `- id=${n.id} [${n.kind}, status=${n.status}, confidence=${n.confidence.toFixed(2)}, support=${n.supports}, contra=${n.contradicts}, sessions=${n.distinctSessions}${n.context ? `, context=${n.context}` : ""}] "${n.label}": ${n.summary}`,
        )
        .join("\n")
    : "(none yet)";
  const conceptText = concepts.map((c) => `- id=${c.id} "${c.label}" mastery=${c.mastery === null ? "?" : c.mastery.toFixed(2)}`).join("\n");

  const system = `You are the memory consolidation process of a private, adaptive tutoring agent. You turn recent raw evidence about ONE learner into durable, revisable long-term memory.

Principles (important):
- Long-term memory is a prior, not a verdict. Prefer linking evidence to existing claims (support or contradiction) over creating new ones.
- Only propose a NEW claim (pattern / preference / goal / context) when the evidence shows repetition or a clearly stated fact. One-off signals may be proposed as kind "hypothesis" — cheap to hold, cheap to discard.
- Repeated mention of a concept is NOT automatically importance: it can be difficulty, confusion, curiosity, real-world use, or enthusiasm. Say which, and only if the evidence shows it.
- Claims may be context-specific (e.g. "prefers terse answers *while debugging*"). Use the context field instead of flattening into a global trait.
- When new evidence conflicts with an existing claim, link it with polarity "contradicts" and, if the claim should be narrowed, revise its summary. Never delete history.
- Do not psychoanalyse. Describe behaviour and stated preferences, in the learner's terms. No confidence numbers — the system computes them from evidence.
- Every create_node / link_evidence must cite observation ids from the evidence list.
- Concepts are handled automatically; you may add structural edges between concept ids: prerequisite_of, confused_with, part_of, applies_to.
- Merge only near-duplicate claims.

Respond with JSON: {"operations":[...]} where each operation is one of:
{"op":"create_node","kind":"pattern|preference|goal|context|hypothesis|strategy","label":"short label","summary":"one or two sentences","context":"optional context or null","evidence":["obs id",...]}
{"op":"link_evidence","node_id":"existing id","polarity":"supports|contradicts","evidence":["obs id",...],"note":"why"}
{"op":"revise_node","node_id":"existing id","summary":"new summary","context":"optional","reason":"why"}
{"op":"create_edge","from":"node id","to":"node id","relation":"prerequisite_of|confused_with|part_of|applies_to|related_to","evidence":["obs id"]}
{"op":"merge_nodes","keep":"node id","remove":"node id","reason":"why"}
Return {"operations":[]} if nothing durable emerges. Fewer, well-evidenced operations beat many speculative ones.`;

  const user = `EXISTING CLAIMS ABOUT THE LEARNER:\n${claimText}\n\nCONCEPTS TOUCHED IN THIS BATCH:\n${conceptText || "(none)"}\n\nNEW EVIDENCE (chronological):\n${obsText}\n\nProduce the consolidation operations as JSON.`;

  const out = await completeJSON<{ operations?: ConsolidationOp[] }>(cfg, {
    purpose: "consolidate",
    messages: [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
  });
  return Array.isArray(out?.operations) ? out!.operations.slice(0, 25) : [];
}

export async function recentMemoryEvents(learnerId: string, limit = 30) {
  return db.select().from(memoryEvents).where(eq(memoryEvents.learnerId, learnerId)).orderBy(desc(memoryEvents.createdAt)).limit(limit);
}
