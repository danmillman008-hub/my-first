import { resolveConfig, type LLMConfig } from "./provider";

/** Env config wins; otherwise a browser-held key may be passed per request (never stored server-side). */
export function configFromRequest(req: Request): LLMConfig {
  const h = req.headers;
  return resolveConfig({
    apiKey: h.get("x-llm-key"),
    baseUrl: h.get("x-llm-base-url"),
    model: h.get("x-llm-model"),
  });
}
