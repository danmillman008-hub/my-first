/**
 * Minimal, provider-agnostic LLM client.
 *
 * Talks to any OpenAI-compatible /chat/completions endpoint (OpenAI, OpenRouter,
 * Groq, Together, Ollama, LM Studio, vLLM ...). Configuration comes from the
 * environment, optionally overridden per-request (private, browser-held key).
 *
 * A deterministic `mock` provider exists so the memory pipeline can be
 * exercised end-to-end in a sandbox without any key.
 */

export type ChatRole = "system" | "user" | "assistant" | "tool";

export interface ToolCall {
  id: string;
  name: string;
  arguments: string; // raw JSON string
}

export interface ChatMessage {
  role: ChatRole;
  content: string | null;
  name?: string;
  tool_call_id?: string;
  tool_calls?: ToolCall[];
}

export interface ToolSpec {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
}

export interface LLMConfig {
  provider: "openai-compatible" | "mock";
  apiKey?: string;
  baseUrl: string;
  model: string;
  /** Cheaper model for background passes (observer/consolidation). */
  fastModel: string;
}

export interface StreamEvent {
  type: "token" | "tool_calls" | "done" | "error";
  text?: string;
  toolCalls?: ToolCall[];
  error?: string;
}

export interface RequestOverrides {
  apiKey?: string | null;
  baseUrl?: string | null;
  model?: string | null;
}

export function resolveConfig(overrides: RequestOverrides = {}): LLMConfig {
  const envProvider = process.env.LLM_PROVIDER;
  const apiKey = overrides.apiKey || process.env.OPENAI_API_KEY || process.env.LLM_API_KEY || undefined;
  const baseUrl = (overrides.baseUrl || process.env.OPENAI_BASE_URL || process.env.LLM_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  const model = overrides.model || process.env.LLM_MODEL || "gpt-4.1-mini";
  const fastModel = process.env.LLM_FAST_MODEL || model;
  if (envProvider === "mock") {
    return { provider: "mock", baseUrl, model: "mock", fastModel: "mock" };
  }
  return { provider: "openai-compatible", apiKey, baseUrl, model, fastModel };
}

export function isConfigured(cfg: LLMConfig): boolean {
  if (cfg.provider === "mock") return true;
  // Local servers (ollama etc.) often need no key.
  if (cfg.apiKey) return true;
  return /localhost|127\.0\.0\.1/.test(cfg.baseUrl);
}

// ---------------------------------------------------------------------------
// Mock hooks (used by the simulation harness). Kept out of the app hot path.
// ---------------------------------------------------------------------------

export type MockHandler = (args: {
  messages: ChatMessage[];
  tools?: ToolSpec[];
  json?: boolean;
  purpose?: string;
}) => Promise<{ content: string; toolCalls?: ToolCall[] }>;

let mockHandler: MockHandler | null = null;
export function setMockHandler(h: MockHandler | null) {
  mockHandler = h;
}

/** Default mock for local UI development without a key (LLM_PROVIDER=mock). */
const defaultMock: MockHandler = async ({ messages, purpose }) => {
  const lastUser = [...messages].reverse().find((m) => m.role === "user")?.content ?? "";
  if (purpose === "observe") {
    return { content: JSON.stringify({ observations: [{ content: `Said: ${lastUser.split("LEARNER:\n")[1]?.split("\n\nTUTOR")[0]?.slice(0, 160) ?? lastUser.slice(0, 160)}`, kind: "statement", entities: [], salience: 0.3 }], session_summary: "mock session" }) };
  }
  if (purpose === "consolidate") return { content: JSON.stringify({ operations: [] }) };
  return { content: `**Mock tutor** (no model configured). You said: "${lastUser.slice(0, 200)}"\n\nSet OPENAI_API_KEY to talk to a real model.` };
};

// ---------------------------------------------------------------------------
// Streaming chat completion with tool call accumulation
// ---------------------------------------------------------------------------

export async function* streamChat(
  cfg: LLMConfig,
  params: {
    messages: ChatMessage[];
    tools?: ToolSpec[];
    temperature?: number;
    model?: string;
    purpose?: string;
    maxTokens?: number;
  },
): AsyncGenerator<StreamEvent> {
  if (cfg.provider === "mock") {
    const res = await (mockHandler ?? defaultMock)({ messages: params.messages, tools: params.tools, purpose: params.purpose });
    if (res.toolCalls?.length) {
      yield { type: "tool_calls", toolCalls: res.toolCalls };
    } else {
      // emit in a few chunks to exercise streaming paths
      const parts = res.content.match(new RegExp("[\\s\\S]{1,40}", "g")) ?? [res.content];
      for (const p of parts) yield { type: "token", text: p };
    }
    yield { type: "done" };
    return;
  }

  const body: Record<string, unknown> = {
    model: params.model || cfg.model,
    messages: params.messages.map(toWire),
    stream: true,
    temperature: params.temperature ?? 0.7,
  };
  if (params.maxTokens) body.max_tokens = params.maxTokens;
  if (params.tools?.length) {
    body.tools = params.tools.map((t) => ({
      type: "function",
      function: { name: t.name, description: t.description, parameters: t.parameters },
    }));
    body.tool_choice = "auto";
  }

  const res = await fetch(`${cfg.baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...(cfg.apiKey ? { authorization: `Bearer ${cfg.apiKey}` } : {}),
    },
    body: JSON.stringify(body),
  });

  if (!res.ok || !res.body) {
    const text = await res.text().catch(() => "");
    yield { type: "error", error: `LLM request failed (${res.status}): ${text.slice(0, 500)}` };
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  const toolAcc = new Map<number, ToolCall>();

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const raw of lines) {
      const line = raw.trim();
      if (!line.startsWith("data:")) continue;
      const data = line.slice(5).trim();
      if (data === "[DONE]") continue;
      let json: unknown;
      try {
        json = JSON.parse(data);
      } catch {
        continue;
      }
      const j = json as {
        choices?: { delta?: { content?: string; tool_calls?: { index: number; id?: string; function?: { name?: string; arguments?: string } }[] } }[];
        error?: { message?: string };
      };
      if (j.error) {
        yield { type: "error", error: j.error.message || "LLM error" };
        return;
      }
      const delta = j.choices?.[0]?.delta;
      if (!delta) continue;
      if (delta.content) yield { type: "token", text: delta.content };
      if (delta.tool_calls) {
        for (const tc of delta.tool_calls) {
          const cur = toolAcc.get(tc.index) ?? { id: "", name: "", arguments: "" };
          if (tc.id) cur.id = tc.id;
          if (tc.function?.name) cur.name += tc.function.name;
          if (tc.function?.arguments) cur.arguments += tc.function.arguments;
          toolAcc.set(tc.index, cur);
        }
      }
    }
  }
  if (toolAcc.size) {
    const calls = [...toolAcc.entries()].sort((a, b) => a[0] - b[0]).map(([, c]) => c);
    yield { type: "tool_calls", toolCalls: calls };
  }
  yield { type: "done" };
}

function toWire(m: ChatMessage) {
  const out: Record<string, unknown> = { role: m.role, content: m.content ?? "" };
  if (m.tool_call_id) out.tool_call_id = m.tool_call_id;
  if (m.name) out.name = m.name;
  if (m.tool_calls?.length) {
    out.tool_calls = m.tool_calls.map((t) => ({
      id: t.id,
      type: "function",
      function: { name: t.name, arguments: t.arguments },
    }));
    if (!m.content) out.content = null;
  }
  return out;
}

// ---------------------------------------------------------------------------
// Non-streaming JSON completion (background passes)
// ---------------------------------------------------------------------------

export async function completeJSON<T>(
  cfg: LLMConfig,
  params: { messages: ChatMessage[]; purpose: string; temperature?: number; model?: string },
): Promise<T | null> {
  if (cfg.provider === "mock") {
    const res = await (mockHandler ?? defaultMock)({ messages: params.messages, json: true, purpose: params.purpose });
    return extractJSON<T>(res.content);
  }
  const body = {
    model: params.model || cfg.fastModel,
    messages: params.messages.map(toWire),
    temperature: params.temperature ?? 0.2,
    response_format: { type: "json_object" },
  };
  let res = await fetch(`${cfg.baseUrl}/chat/completions`, {
    method: "POST",
    headers: { "content-type": "application/json", ...(cfg.apiKey ? { authorization: `Bearer ${cfg.apiKey}` } : {}) },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    // Some providers reject response_format; retry without it.
    const { response_format: _rf, ...plain } = body;
    void _rf;
    res = await fetch(`${cfg.baseUrl}/chat/completions`, {
      method: "POST",
      headers: { "content-type": "application/json", ...(cfg.apiKey ? { authorization: `Bearer ${cfg.apiKey}` } : {}) },
      body: JSON.stringify(plain),
    });
    if (!res.ok) {
      console.error("[llm] json completion failed", res.status, (await res.text()).slice(0, 300));
      return null;
    }
  }
  const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const content = data.choices?.[0]?.message?.content ?? "";
  return extractJSON<T>(content);
}

export function extractJSON<T>(text: string): T | null {
  if (!text) return null;
  try {
    return JSON.parse(text) as T;
  } catch {
    /* fallthrough */
  }
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) {
    try {
      return JSON.parse(fence[1]) as T;
    } catch {
      /* fallthrough */
    }
  }
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start >= 0 && end > start) {
    try {
      return JSON.parse(text.slice(start, end + 1)) as T;
    } catch {
      return null;
    }
  }
  return null;
}
