"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useMemory, ClaimRow, ConceptChip, Section, Empty, CLAIM_KINDS, kindColor, rel, type MemNode, type MemEdge } from "./MemoryPanel";
import { apiFetch } from "./llmSettings";

export default function MemoryExplorer() {
  const [tick, setTick] = useState(0);
  const { data, reload } = useMemory(tick, true);
  const [selected, setSelected] = useState<string | null>(null);
  const [tab, setTab] = useState<"model" | "evidence" | "journal" | "brief">("model");

  if (!data) return <div className="p-8 text-sm text-stone-400">Loading…</div>;
  const live = data.nodes.filter((n) => n.status !== "merged");
  const claims = live.filter((n) => CLAIM_KINDS.includes(n.kind));
  const active = claims.filter((n) => n.status === "active").sort((a, b) => b.confidence - a.confidence);
  const questioned = claims.filter((n) => n.status === "contradicted" || n.status === "retired");
  const dormant = claims.filter((n) => n.status === "dormant");
  const concepts = live.filter((n) => n.kind === "concept").sort((a, b) => b.activation - a.activation);
  const strategies = live.filter((n) => n.kind === "strategy");
  const byId = new Map(live.map((n) => [n.id, n]));

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900">
      <header className="flex items-center justify-between border-b border-stone-200 bg-white px-5 py-3">
        <div>
          <Link href="/" className="text-xs text-stone-500 hover:underline">
            ← back to conversation
          </Link>
          <h1 className="text-lg font-semibold tracking-tight">What the agent has learned about you</h1>
          <p className="text-xs text-stone-500">Everything here is derived from evidence in your conversations. Nothing is a verdict; you can retire anything that isn’t you.</p>
        </div>
        <nav className="flex gap-1 text-sm">
          {(["model", "evidence", "journal", "brief"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`rounded-md px-3 py-1.5 ${tab === t ? "bg-stone-900 text-white" : "hover:bg-stone-100"}`}>
              {t}
            </button>
          ))}
        </nav>
      </header>

      {tab === "model" && (
        <div className="grid gap-6 p-5 lg:grid-cols-[1fr_1fr]">
          <div>
            <Section title={`Durable observations (${active.length})`}>
              {active.length ? active.map((n) => <ClaimRow key={n.id} n={n} onClick={() => setSelected(n.id)} />) : <Empty>Nothing yet. Patterns must repeat across sessions before they count as durable.</Empty>}
            </Section>
            {!!questioned.length && (
              <Section title={`Challenged or retired (${questioned.length})`}>
                {questioned.map((n) => (
                  <div key={n.id} className="opacity-60">
                    <ClaimRow n={n} onClick={() => setSelected(n.id)} />
                  </div>
                ))}
              </Section>
            )}
            {!!dormant.length && (
              <Section title={`Faded (${dormant.length})`}>
                {dormant.map((n) => (
                  <div key={n.id} className="opacity-50">
                    <ClaimRow n={n} onClick={() => setSelected(n.id)} />
                  </div>
                ))}
              </Section>
            )}
            <Section title={`What has worked for you (${strategies.length} approaches)`}>
              {strategies.length ? (
                strategies
                  .sort((a, b) => b.supports + b.contradicts - (a.supports + a.contradicts))
                  .map((s) => {
                    const works = data.edges.filter((e) => e.fromNode === s.id && e.relation === "works_for").map((e) => byId.get(e.toNode)?.label).filter(Boolean);
                    const fails = data.edges.filter((e) => e.fromNode === s.id && e.relation === "fails_for").map((e) => byId.get(e.toNode)?.label).filter(Boolean);
                    return (
                      <div key={s.id} className="mb-2 rounded-md border border-stone-200 bg-white p-2 text-[12px]">
                        <div className="flex items-center gap-2">
                          <span className={`rounded px-1 text-[10px] uppercase ${kindColor("strategy")}`}>approach</span>
                          <b>{s.label}</b>
                          <span className="text-stone-400">
                            helped ×{s.supports}
                            {s.contradicts ? ` · didn’t ×${s.contradicts}` : ""}
                            {s.context ? ` · mostly while ${s.context}` : ""}
                          </span>
                        </div>
                        {!!works.length && <div className="text-emerald-800">✓ {[...new Set(works)].join(", ")}</div>}
                        {!!fails.length && <div className="text-amber-800">✗ {[...new Set(fails)].join(", ")}</div>}
                      </div>
                    );
                  })
              ) : (
                <Empty>The agent learns which explanations land by watching your reactions.</Empty>
              )}
            </Section>
          </div>
          <div>
            <Section title={`Concept map (${concepts.length})`}>
              <Graph nodes={concepts} edges={data.edges} onSelect={setSelected} selected={selected} />
              <div className="mt-2 flex flex-wrap gap-1">
                {concepts.map((c) => (
                  <ConceptChip key={c.id} c={c} onClick={() => setSelected(c.id)} />
                ))}
              </div>
              <p className="mt-2 text-[11px] text-stone-400">Green: demonstrated · amber: struggled · faded: not touched recently. Links grow when concepts appear together in your conversations.</p>
            </Section>
          </div>
        </div>
      )}

      {tab === "evidence" && (
        <div className="p-5">
          <p className="mb-3 text-xs text-stone-500">
            Short-term memory: the raw, lightly interpreted evidence stream. {data.pendingCount} item(s) not yet consolidated into long-term memory.
          </p>
          <div className="space-y-2">
            {data.observations.map((o) => (
              <div key={o.id} className="rounded-md border border-stone-200 bg-white p-2.5 text-[13px]">
                <div className="mb-0.5 flex flex-wrap items-center gap-1.5 text-[10px] text-stone-500">
                  <span className="rounded bg-stone-100 px-1">{o.kind}</span>
                  {o.activity && <span>while {o.activity}</span>}
                  {o.outcome && <span className="rounded bg-emerald-50 px-1 text-emerald-800">{o.outcome}</span>}
                  {o.strategy && <span className="rounded bg-pink-50 px-1 text-pink-800">after {o.strategy}</span>}
                  <span>source: {o.source}</span>
                  <span>salience {Math.round(o.salience * 100)}%</span>
                  <span>{o.consolidatedAt ? "consolidated" : "pending"}</span>
                  <span className="ml-auto">{rel(o.createdAt)} ago</span>
                </div>
                {o.content}
                {o.interpretation && <div className="mt-1 text-[12px] italic text-stone-500">tentative: {o.interpretation}</div>}
                {!!o.entities?.length && <div className="mt-1 text-[11px] text-stone-400">{o.entities.join(" · ")}</div>}
              </div>
            ))}
            {!data.observations.length && <Empty>No evidence yet.</Empty>}
          </div>
        </div>
      )}

      {tab === "journal" && (
        <div className="p-5">
          <p className="mb-3 text-xs text-stone-500">What the memory system did and why: creations, reinforcements, contradictions, revisions, fading.</p>
          <div className="space-y-1">
            {data.events.map((e) => (
              <div key={e.id} className="flex gap-3 border-b border-stone-100 py-1.5 text-[12px]">
                <span className="w-14 shrink-0 text-stone-400">{rel(e.createdAt)}</span>
                <span className={`w-28 shrink-0 rounded px-1 text-[10px] uppercase ${eventColor(e.type)}`}>{e.type}</span>
                <span>{e.detail}</span>
              </div>
            ))}
            {!data.events.length && <Empty>Nothing yet.</Empty>}
          </div>
          {!!data.research.length && (
            <Section title="Research the agent did">
              {data.research.map((r) => (
                <div key={r.id} className="mb-1 text-[12px]">
                  🔎 <b>{r.query}</b> — {r.sources.slice(0, 3).map((s, i) => (
                    <a key={i} href={s.url} target="_blank" rel="noreferrer" className="mr-2 underline">
                      {s.title}
                    </a>
                  ))}
                </div>
              ))}
            </Section>
          )}
        </div>
      )}

      {tab === "brief" && (
        <div className="p-5">
          <p className="mb-3 text-xs text-stone-500">This is the exact memory brief the tutor reads before every reply (for a neutral query). It is framed as a prior — the conversation always outranks it.</p>
          <pre className="whitespace-pre-wrap rounded-lg border border-stone-200 bg-white p-4 text-[12px] leading-relaxed">{data.brief}</pre>
        </div>
      )}

      {selected && (
        <NodeDrawer
          id={selected}
          onClose={() => setSelected(null)}
          onChanged={() => {
            setTick((t) => t + 1);
            reload();
          }}
        />
      )}
    </div>
  );
}

function eventColor(t: string) {
  if (t === "contradicted" || t === "retired" || t === "learner_override") return "bg-rose-100 text-rose-800";
  if (t === "node_created" || t === "edge_created" || t === "graduated") return "bg-emerald-100 text-emerald-800";
  if (t === "revised" || t === "merged" || t === "revived") return "bg-sky-100 text-sky-800";
  if (t === "decay") return "bg-stone-200 text-stone-600";
  return "bg-stone-100 text-stone-600";
}

// ---------------------------------------------------------------------------
// Node drawer: evidence behind a node + learner override
// ---------------------------------------------------------------------------

function NodeDrawer({ id, onClose, onChanged }: { id: string; onClose: () => void; onChanged: () => void }) {
  const [data, setData] = useState<{ node: MemNode; evidence: { polarity: string; note: string | null; createdAt: string; observation: { content: string; kind: string; createdAt: string } | null }[] } | null>(null);
  useEffect(() => {
    fetch(`/api/memory/nodes/${id}`)
      .then((r) => r.json())
      .then(setData);
  }, [id]);
  async function setStatus(status: "retired" | "active") {
    await apiFetch(`/api/memory/nodes/${id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ status, reason: status === "retired" ? "learner said this is not accurate" : "learner reinstated" }) });
    onChanged();
    onClose();
  }
  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-black/20" onClick={onClose}>
      <div className="h-full w-full max-w-md overflow-y-auto bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
        {!data ? (
          <div className="text-sm text-stone-400">Loading…</div>
        ) : (
          <>
            <div className="flex items-center gap-2">
              <span className={`rounded px-1 text-[10px] uppercase ${kindColor(data.node.kind)}`}>{data.node.kind}</span>
              <span className="text-[10px] uppercase text-stone-400">{data.node.status}</span>
            </div>
            <h2 className="mt-1 text-base font-semibold">{data.node.label}</h2>
            {data.node.summary && <p className="mt-1 text-sm text-stone-700">{data.node.summary}</p>}
            {data.node.context && <p className="mt-1 text-xs text-stone-500">Context: while {data.node.context}</p>}
            <dl className="mt-3 grid grid-cols-3 gap-2 text-[11px] text-stone-500">
              <div>
                <dt>confidence</dt>
                <dd className="text-sm text-stone-900">{Math.round(data.node.confidence * 100)}%</dd>
              </div>
              {data.node.mastery !== null && (
                <div>
                  <dt>est. mastery</dt>
                  <dd className="text-sm text-stone-900">{Math.round(data.node.mastery * 100)}%</dd>
                </div>
              )}
              <div>
                <dt>evidence</dt>
                <dd className="text-sm text-stone-900">
                  {data.node.supports}↑ {data.node.contradicts}↓
                </dd>
              </div>
              <div>
                <dt>sessions</dt>
                <dd className="text-sm text-stone-900">{data.node.distinctSessions}</dd>
              </div>
              <div>
                <dt>first seen</dt>
                <dd className="text-sm text-stone-900">{rel(data.node.firstSeen)} ago</dd>
              </div>
              <div>
                <dt>last reinforced</dt>
                <dd className="text-sm text-stone-900">{rel(data.node.lastReinforced)} ago</dd>
              </div>
            </dl>
            {!!Object.keys(data.node.signals ?? {}).length && (
              <div className="mt-2 text-[11px] text-stone-500">
                signals:{" "}
                {Object.entries(data.node.signals)
                  .map(([k, v]) => `${k}×${v}`)
                  .join(", ")}
              </div>
            )}
            {CLAIM_KINDS.includes(data.node.kind) && (
              <div className="mt-4 flex gap-2">
                {data.node.status !== "retired" ? (
                  <button onClick={() => setStatus("retired")} className="rounded-md border border-rose-300 bg-rose-50 px-3 py-1.5 text-xs text-rose-800">
                    That’s not me — retire this
                  </button>
                ) : (
                  <button onClick={() => setStatus("active")} className="rounded-md border border-stone-300 px-3 py-1.5 text-xs">
                    Reinstate
                  </button>
                )}
              </div>
            )}
            <h3 className="mt-5 text-[11px] font-semibold uppercase tracking-wide text-stone-400">Evidence ({data.evidence.length})</h3>
            <div className="mt-1 space-y-1.5">
              {data.evidence.map((e, i) => (
                <div key={i} className={`rounded-md border-l-2 pl-2 text-[12px] ${e.polarity === "contradicts" ? "border-rose-300" : "border-emerald-300"}`}>
                  <span className="mr-1 text-[10px] text-stone-400">{e.polarity === "contradicts" ? "against" : "for"} · {rel(e.createdAt)} ago</span>
                  {e.observation?.content ?? "(observation)"}
                  {e.note && <div className="text-[11px] italic text-stone-500">{e.note}</div>}
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Tiny force-directed layout (no deps)
// ---------------------------------------------------------------------------

function Graph({ nodes, edges, onSelect, selected }: { nodes: MemNode[]; edges: MemEdge[]; onSelect: (id: string) => void; selected: string | null }) {
  const W = 520;
  const H = 360;
  const layout = useMemo(() => {
    const ns = nodes.slice(0, 60);
    const idx = new Map(ns.map((n, i) => [n.id, i]));
    const es = edges.filter((e) => idx.has(e.fromNode) && idx.has(e.toNode) && e.relation !== "works_for" && e.relation !== "fails_for");
    const pos = ns.map((_, i) => ({ x: W / 2 + Math.cos((i / ns.length) * Math.PI * 2) * 120, y: H / 2 + Math.sin((i / ns.length) * Math.PI * 2) * 100, vx: 0, vy: 0 }));
    for (let it = 0; it < 200; it++) {
      for (let i = 0; i < ns.length; i++)
        for (let j = i + 1; j < ns.length; j++) {
          const dx = pos[j].x - pos[i].x;
          const dy = pos[j].y - pos[i].y;
          const d2 = Math.max(dx * dx + dy * dy, 25);
          const f = 1800 / d2;
          const d = Math.sqrt(d2);
          pos[i].vx -= (dx / d) * f;
          pos[i].vy -= (dy / d) * f;
          pos[j].vx += (dx / d) * f;
          pos[j].vy += (dy / d) * f;
        }
      for (const e of es) {
        const a = pos[idx.get(e.fromNode)!];
        const b = pos[idx.get(e.toNode)!];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const d = Math.sqrt(dx * dx + dy * dy) || 1;
        const f = (d - 70) * 0.02 * Math.min(2, e.weight);
        a.vx += (dx / d) * f;
        a.vy += (dy / d) * f;
        b.vx -= (dx / d) * f;
        b.vy -= (dy / d) * f;
      }
      for (const p of pos) {
        p.vx += (W / 2 - p.x) * 0.005;
        p.vy += (H / 2 - p.y) * 0.005;
        p.x = Math.max(20, Math.min(W - 20, p.x + p.vx * 0.5));
        p.y = Math.max(14, Math.min(H - 14, p.y + p.vy * 0.5));
        p.vx *= 0.6;
        p.vy *= 0.6;
      }
    }
    return { ns, es, pos, idx };
  }, [nodes, edges]);

  if (!nodes.length) return <div className="rounded-lg border border-dashed border-stone-300 p-8 text-center text-xs text-stone-400">The concept map grows as you talk.</div>;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full rounded-lg border border-stone-200 bg-white">
      {layout.es.map((e) => {
        const a = layout.pos[layout.idx.get(e.fromNode)!];
        const b = layout.pos[layout.idx.get(e.toNode)!];
        const structural = e.relation !== "related_to";
        return <line key={e.id} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={structural ? "#7c3aed" : "#d6d3d1"} strokeWidth={Math.min(4, 0.6 + e.weight * 0.6)} strokeDasharray={structural ? "4 3" : undefined} opacity={0.8} />;
      })}
      {layout.ns.map((n, i) => {
        const p = layout.pos[i];
        const r = 5 + Math.min(10, n.supports * 1.2);
        const fill = n.mastery === null ? "#a8a29e" : n.mastery >= 0.65 ? "#10b981" : n.mastery < 0.4 ? "#f59e0b" : "#78716c";
        return (
          <g key={n.id} onClick={() => onSelect(n.id)} className="cursor-pointer">
            <circle cx={p.x} cy={p.y} r={r} fill={fill} opacity={0.35 + 0.65 * n.activation} stroke={selected === n.id ? "#111" : "white"} strokeWidth={selected === n.id ? 2 : 1} />
            <text x={p.x} y={p.y - r - 3} textAnchor="middle" fontSize={9} fill="#44403c">
              {n.label.length > 18 ? n.label.slice(0, 17) + "…" : n.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
