"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { apiFetch } from "./llmSettings";

export interface MemNode {
  id: string;
  kind: string;
  label: string;
  summary: string;
  context: string | null;
  status: string;
  supports: number;
  contradicts: number;
  distinctSessions: number;
  confidence: number;
  mastery: number | null;
  activation: number;
  signals: Record<string, number>;
  lastReinforced: string;
  firstSeen: string;
}
export interface MemEdge {
  id: string;
  fromNode: string;
  toNode: string;
  relation: string;
  weight: number;
  supports: number;
  contradicts: number;
  data: Record<string, unknown>;
}
export interface MemObservation {
  id: string;
  kind: string;
  content: string;
  entities: string[];
  activity: string | null;
  outcome: string | null;
  strategy: string | null;
  interpretation: string | null;
  salience: number;
  source: string;
  consolidatedAt: string | null;
  createdAt: string;
}
export interface MemEvent {
  id: string;
  type: string;
  detail: string;
  createdAt: string;
}
export interface MemoryData {
  nodes: MemNode[];
  edges: MemEdge[];
  observations: MemObservation[];
  pendingCount: number;
  events: MemEvent[];
  research: { id: string; query: string; sources: { title: string; url: string }[]; createdAt: string }[];
  brief: string | null;
}

export function useMemory(refreshKey: number, withBrief = false) {
  const [data, setData] = useState<MemoryData | null>(null);
  const [loading, setLoading] = useState(false);
  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch(`/api/memory${withBrief ? "?brief=1" : ""}`);
      setData(await r.json());
    } finally {
      setLoading(false);
    }
  }, [withBrief]);
  useEffect(() => {
    reload();
  }, [reload, refreshKey]);
  return { data, loading, reload };
}

export const CLAIM_KINDS = ["pattern", "preference", "hypothesis", "trait", "context", "goal"];

export function rel(d: string) {
  const m = Math.round((Date.now() - new Date(d).getTime()) / 60000);
  if (m < 1) return "now";
  if (m < 60) return `${m}m`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.round(h / 24)}d`;
}

export default function MemoryPanel({ refreshKey, compact }: { refreshKey: number; compact?: boolean }) {
  const { data, reload } = useMemory(refreshKey);
  const [consolidating, setConsolidating] = useState(false);
  if (!data) return <div className="p-4 text-xs text-stone-400">Loading memory…</div>;

  const claims = data.nodes.filter((n) => CLAIM_KINDS.includes(n.kind) && n.status === "active").sort((a, b) => b.confidence - a.confidence);
  const concepts = data.nodes.filter((n) => n.kind === "concept" && n.status === "active").sort((a, b) => b.activation - a.activation);
  const recentObs = data.observations.slice(0, compact ? 8 : 30);

  async function consolidateNow() {
    setConsolidating(true);
    try {
      await apiFetch("/api/memory/consolidate", { method: "POST" });
      await reload();
    } finally {
      setConsolidating(false);
    }
  }

  return (
    <div className="p-4 text-sm">
      <div className="flex items-center justify-between">
        <h2 className="text-xs font-semibold uppercase tracking-wide text-stone-500">Memory</h2>
        <Link href="/memory" className="text-[11px] text-stone-500 underline">
          inspect
        </Link>
      </div>
      <div className="mt-1 text-[11px] text-stone-400">
        {data.nodes.filter((n) => n.status !== "merged").length} nodes · {data.observations.length}+ observations
        {data.pendingCount > 0 && (
          <>
            {" "}
            · {data.pendingCount} awaiting consolidation{" "}
            <button onClick={consolidateNow} disabled={consolidating} className="underline">
              {consolidating ? "…" : "consolidate"}
            </button>
          </>
        )}
      </div>

      <Section title="About you (durable)">
        {claims.length ? (
          claims.slice(0, compact ? 6 : 50).map((n) => <ClaimRow key={n.id} n={n} />)
        ) : (
          <Empty>Nothing durable yet — patterns need to repeat before they’re believed.</Empty>
        )}
      </Section>

      <Section title="Concepts">
        {concepts.length ? (
          <div className="flex flex-wrap gap-1">
            {concepts.slice(0, compact ? 14 : 80).map((c) => (
              <ConceptChip key={c.id} c={c} />
            ))}
          </div>
        ) : (
          <Empty>No concepts touched yet.</Empty>
        )}
      </Section>

      <Section title="Recent evidence (short-term)">
        {recentObs.length ? (
          recentObs.map((o) => (
            <div key={o.id} className="mb-1.5 border-l-2 border-stone-200 pl-2 text-[12px] leading-snug text-stone-700">
              <span className="mr-1 rounded bg-stone-100 px-1 text-[10px] text-stone-500">{o.kind}</span>
              {o.content}
              <span className="ml-1 text-[10px] text-stone-400">{rel(o.createdAt)}</span>
            </div>
          ))
        ) : (
          <Empty>Evidence appears here as you talk.</Empty>
        )}
      </Section>
    </div>
  );
}

export function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-4">
      <h3 className="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-stone-400">{title}</h3>
      {children}
    </div>
  );
}
export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="text-[12px] text-stone-400">{children}</div>;
}

export function ClaimRow({ n, onClick }: { n: MemNode; onClick?: () => void }) {
  const pct = Math.round(n.confidence * 100);
  return (
    <button onClick={onClick} className={`mb-1.5 block w-full text-left ${onClick ? "rounded-md hover:bg-stone-50" : "cursor-default"}`}>
      <div className="flex items-center gap-2">
        <span className={`rounded px-1 text-[10px] uppercase ${kindColor(n.kind)}`}>{n.kind}</span>
        <span className="truncate text-[13px]">{n.label}</span>
      </div>
      <div className="mt-0.5 flex items-center gap-2 text-[10px] text-stone-400">
        <div className="h-1 w-16 overflow-hidden rounded bg-stone-100">
          <div className="h-full bg-stone-700" style={{ width: `${pct}%` }} />
        </div>
        {pct}% · {n.supports}↑{n.contradicts ? ` ${n.contradicts}↓` : ""} · {n.distinctSessions}s{n.context ? ` · while ${n.context}` : ""}
      </div>
    </button>
  );
}

export function ConceptChip({ c, onClick }: { c: MemNode; onClick?: () => void }) {
  const m = c.mastery;
  const tone = m === null ? "border-stone-200 bg-white text-stone-600" : m >= 0.65 ? "border-emerald-300 bg-emerald-50 text-emerald-900" : m < 0.4 ? "border-amber-300 bg-amber-50 text-amber-900" : "border-stone-300 bg-stone-50 text-stone-700";
  return (
    <button onClick={onClick} className={`rounded-full border px-2 py-0.5 text-[11px] ${tone}`} style={{ opacity: 0.55 + 0.45 * c.activation }} title={`activation ${c.activation.toFixed(2)}`}>
      {c.label}
      {m !== null && <span className="ml-1 opacity-70">{Math.round(m * 100)}%</span>}
    </button>
  );
}

export function kindColor(kind: string) {
  return (
    {
      goal: "bg-violet-100 text-violet-800",
      preference: "bg-sky-100 text-sky-800",
      pattern: "bg-emerald-100 text-emerald-800",
      hypothesis: "bg-amber-100 text-amber-800",
      context: "bg-stone-200 text-stone-700",
      strategy: "bg-pink-100 text-pink-800",
      concept: "bg-stone-100 text-stone-600",
    }[kind] ?? "bg-stone-100 text-stone-600"
  );
}
