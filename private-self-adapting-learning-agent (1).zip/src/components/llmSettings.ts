"use client";

/** Browser-held model settings (private: never stored server-side, sent per request as headers). */
export interface LLMSettings {
  apiKey: string;
  baseUrl: string;
  model: string;
}

const KEY = "learning-agent.llm";

export function loadSettings(): LLMSettings {
  if (typeof window === "undefined") return { apiKey: "", baseUrl: "", model: "" };
  try {
    return { apiKey: "", baseUrl: "", model: "", ...(JSON.parse(localStorage.getItem(KEY) ?? "{}") as Partial<LLMSettings>) };
  } catch {
    return { apiKey: "", baseUrl: "", model: "" };
  }
}

export function saveSettings(s: LLMSettings) {
  localStorage.setItem(KEY, JSON.stringify(s));
}

export function llmHeaders(): Record<string, string> {
  const s = loadSettings();
  const h: Record<string, string> = {};
  if (s.apiKey) h["x-llm-key"] = s.apiKey;
  if (s.baseUrl) h["x-llm-base-url"] = s.baseUrl;
  if (s.model) h["x-llm-model"] = s.model;
  return h;
}

export async function apiFetch(input: string, init: RequestInit = {}) {
  return fetch(input, { ...init, headers: { ...(init.headers as Record<string, string> | undefined), ...llmHeaders() } });
}
