"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { apiFetch, loadSettings, saveSettings, type LLMSettings } from "./llmSettings";
import MemoryPanel from "./MemoryPanel";

interface Msg {
  id: string;
  role: "user" | "assistant";
  content: string;
  tools?: { name: string; summary?: string; status: "start" | "done" }[];
  memory?: { observations: number; consolidated?: string | null };
  error?: string;
}
interface Session {
  id: string;
  title: string;
  summary: string | null;
  lastActiveAt: string;
}

export default function ChatApp() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [config, setConfig] = useState<{ configured: boolean; envConfigured: boolean; model: string } | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [memoryTick, setMemoryTick] = useState(0);
  const [showMemory, setShowMemory] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);

  const refreshConfig = useCallback(async () => {
    const r = await apiFetch("/api/config");
    setConfig(await r.json());
  }, []);
  const refreshSessions = useCallback(async () => {
    const r = await fetch("/api/sessions");
    const j = await r.json();
    setSessions(j.sessions ?? []);
  }, []);

  useEffect(() => {
    refreshConfig();
    refreshSessions();
  }, [refreshConfig, refreshSessions]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs]);

  async function openSession(id: string) {
    setSessionId(id);
    const r = await fetch(`/api/sessions/${id}`);
    const j = await r.json();
    setMsgs(
      (j.messages ?? []).map((m: { id: string; role: "user" | "assistant"; content: string; meta?: { tools?: { name: string; summary: string }[] } }) => ({
        id: m.id,
        role: m.role,
        content: m.content,
        tools: m.meta?.tools?.map((t) => ({ ...t, status: "done" as const })),
      })),
    );
  }

  function newSession() {
    setSessionId(null);
    setMsgs([]);
    taRef.current?.focus();
  }

  async function send(text?: string) {
    const content = (text ?? input).trim();
    if (!content || busy) return;
    if (!config?.configured) {
      setShowSettings(true);
      return;
    }
    setInput("");
    setBusy(true);
    const userMsg: Msg = { id: `tmp_${Date.now()}`, role: "user", content };
    const asstId = `tmp_a_${Date.now()}`;
    setMsgs((m) => [...m, userMsg, { id: asstId, role: "assistant", content: "", tools: [] }]);

    const patch = (fn: (a: Msg) => Msg) => setMsgs((m) => m.map((x) => (x.id === asstId ? fn(x) : x)));

    try {
      const res = await apiFetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ sessionId, content }),
      });
      if (!res.ok || !res.body) {
        const j = await res.json().catch(() => ({ error: `Request failed (${res.status})` }));
        patch((a) => ({ ...a, error: j.error ?? "Request failed" }));
        setBusy(false);
        return;
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      let newSessionCreated = false;
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.trim()) continue;
          let ev: Record<string, unknown>;
          try {
            ev = JSON.parse(line);
          } catch {
            continue;
          }
          switch (ev.type) {
            case "session":
              if (!sessionId) {
                setSessionId(ev.sessionId as string);
                newSessionCreated = true;
              }
              break;
            case "token":
              patch((a) => ({ ...a, content: a.content + (ev.text as string) }));
              break;
            case "message":
              // Reply is complete; memory work continues in the background.
              setBusy(false);
              refreshSessions();
              break;
            case "tool":
              patch((a) => {
                const tools = [...(a.tools ?? [])];
                if (ev.status === "start") tools.push({ name: ev.name as string, status: "start" });
                else {
                  const i = tools.map((t) => t.name + t.status).lastIndexOf((ev.name as string) + "start");
                  if (i >= 0) tools[i] = { name: ev.name as string, status: "done", summary: ev.summary as string };
                  else tools.push({ name: ev.name as string, status: "done", summary: ev.summary as string });
                }
                return { ...a, tools };
              });
              break;
            case "memory": {
              const c = ev.consolidation as { created: string[]; contradicted: string[]; revised: string[]; observations: number } | null;
              patch((a) => ({
                ...a,
                memory: {
                  observations: ev.observations as number,
                  consolidated: c ? `consolidated ${c.observations} observations${c.created.length ? ` · ${c.created.length} new` : ""}${c.contradicted.length ? ` · ${c.contradicted.length} challenged` : ""}${c.revised.length ? ` · ${c.revised.length} revised` : ""}` : null,
                },
              }));
              setMemoryTick((t) => t + 1);
              break;
            }
            case "error":
              patch((a) => ({ ...a, error: ev.error as string }));
              break;
          }
        }
      }
      if (newSessionCreated) refreshSessions();
    } catch (e) {
      patch((a) => ({ ...a, error: (e as Error).message }));
    } finally {
      setBusy(false);
    }
  }

  const starters = ["I want to learn Bash.", "Teach me object-oriented programming.", "Why does 0.1 + 0.2 != 0.3?", "Here's my code, can you look at it?"];

  return (
    <div className="flex h-screen bg-stone-50 text-stone-900">
      {/* Sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col border-r border-stone-200 bg-white md:flex">
        <div className="flex items-center justify-between px-4 py-4">
          <div>
            <div className="text-sm font-semibold tracking-tight">Learning Agent</div>
            <div className="text-[11px] text-stone-500">private · self-adapting</div>
          </div>
          <button onClick={newSession} className="rounded-md bg-stone-900 px-2.5 py-1 text-xs font-medium text-white hover:bg-stone-700">
            New
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-2 pb-2">
          {sessions.map((s) => (
            <button
              key={s.id}
              onClick={() => openSession(s.id)}
              className={`mb-1 w-full rounded-md px-3 py-2 text-left text-sm hover:bg-stone-100 ${s.id === sessionId ? "bg-stone-100 font-medium" : ""}`}
            >
              <div className="truncate">{s.title}</div>
              {s.summary && <div className="truncate text-[11px] text-stone-500">{s.summary}</div>}
            </button>
          ))}
          {!sessions.length && <div className="px-3 py-6 text-xs text-stone-400">No conversations yet.</div>}
        </div>
        <div className="border-t border-stone-200 p-3 text-xs">
          <Link href="/memory" className="block rounded-md px-2 py-1.5 hover:bg-stone-100">
            🧠 What it knows about me
          </Link>
          <button onClick={() => setShowSettings(true)} className="block w-full rounded-md px-2 py-1.5 text-left hover:bg-stone-100">
            ⚙️ Model settings {config && <span className={`ml-1 inline-block h-2 w-2 rounded-full ${config.configured ? "bg-emerald-500" : "bg-amber-500"}`} />}
          </button>
        </div>
      </aside>

      {/* Chat */}
      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-stone-200 bg-white/70 px-4 py-2 backdrop-blur md:hidden">
          <button onClick={newSession} className="text-sm font-medium">
            + New
          </button>
          <Link href="/memory" className="text-sm">
            🧠 Memory
          </Link>
          <button onClick={() => setShowSettings(true)} className="text-sm">
            ⚙️
          </button>
        </header>
        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-3xl px-4 py-6">
            {!msgs.length && (
              <div className="mt-16 text-center">
                <h1 className="text-2xl font-semibold tracking-tight">What do you want to get into?</h1>
                <p className="mx-auto mt-2 max-w-md text-sm text-stone-500">
                  Talk naturally. Learn something, ask why, paste code, change your mind, wander off-topic. The agent adapts and quietly builds an
                  evidence-based memory of how you learn — which you can inspect and correct at any time.
                </p>
                <div className="mt-6 flex flex-wrap justify-center gap-2">
                  {starters.map((s) => (
                    <button key={s} onClick={() => send(s)} className="rounded-full border border-stone-300 bg-white px-3 py-1.5 text-sm hover:bg-stone-100">
                      {s}
                    </button>
                  ))}
                </div>
                {config && !config.configured && (
                  <div className="mx-auto mt-8 max-w-md rounded-lg border border-amber-300 bg-amber-50 p-3 text-left text-sm text-amber-900">
                    No language model is configured. Set <code>OPENAI_API_KEY</code> on the server (optionally <code>OPENAI_BASE_URL</code>, <code>LLM_MODEL</code>), or{" "}
                    <button onClick={() => setShowSettings(true)} className="underline">
                      add a key in your browser
                    </button>{" "}
                    — it stays on this device.
                  </div>
                )}
              </div>
            )}
            {msgs.map((m) => (
              <MessageView key={m.id} m={m} />
            ))}
            <div ref={bottomRef} />
          </div>
        </div>
        <div className="border-t border-stone-200 bg-white p-3">
          <div className="mx-auto flex max-w-3xl items-end gap-2">
            <textarea
              ref={taRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
              rows={Math.min(8, Math.max(1, input.split("\n").length))}
              placeholder="Say anything… (Enter to send, Shift+Enter for newline)"
              className="flex-1 resize-none rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm outline-none focus:border-stone-500"
            />
            <button onClick={() => send()} disabled={busy || !input.trim()} className="rounded-xl bg-stone-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-40">
              {busy ? "…" : "Send"}
            </button>
            <button onClick={() => setShowMemory((v) => !v)} title="Toggle memory panel" className="hidden rounded-xl border border-stone-300 px-3 py-2 text-sm lg:block">
              🧠
            </button>
          </div>
        </div>
      </main>

      {/* Memory side panel */}
      {showMemory && (
        <aside className="hidden w-80 shrink-0 overflow-y-auto border-l border-stone-200 bg-white lg:block">
          <MemoryPanel refreshKey={memoryTick} compact />
        </aside>
      )}

      {showSettings && (
        <SettingsDialog
          envConfigured={config?.envConfigured ?? false}
          onClose={() => {
            setShowSettings(false);
            refreshConfig();
          }}
        />
      )}
    </div>
  );
}

function MessageView({ m }: { m: Msg }) {
  if (m.role === "user") {
    return (
      <div className="mb-5 flex justify-end">
        <div className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-br-sm bg-stone-900 px-4 py-2.5 text-sm text-white">{m.content}</div>
      </div>
    );
  }
  return (
    <div className="mb-6">
      {!!m.tools?.length && (
        <div className="mb-1.5 flex flex-wrap gap-1.5">
          {m.tools.map((t, i) => (
            <span key={i} className={`rounded-full border px-2 py-0.5 text-[11px] ${t.status === "start" ? "animate-pulse border-sky-300 bg-sky-50 text-sky-800" : "border-stone-200 bg-stone-50 text-stone-600"}`}>
              {toolIcon(t.name)} {t.summary ?? `${t.name}…`}
            </span>
          ))}
        </div>
      )}
      <div className="prose prose-stone prose-sm max-w-none prose-pre:rounded-lg prose-pre:bg-stone-900 prose-pre:text-stone-100 prose-code:before:content-none prose-code:after:content-none">
        {m.content ? <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown> : !m.error && <span className="inline-block h-4 w-2 animate-pulse bg-stone-400" />}
      </div>
      {m.error && <div className="mt-2 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-800">{m.error}</div>}
      {m.memory && (m.memory.observations > 0 || m.memory.consolidated) && (
        <div className="mt-2 text-[11px] text-stone-400">
          memory: {m.memory.observations > 0 ? `noted ${m.memory.observations} observation${m.memory.observations === 1 ? "" : "s"}` : "nothing new"}
          {m.memory.consolidated ? ` · ${m.memory.consolidated}` : ""}
        </div>
      )}
    </div>
  );
}

function toolIcon(name: string) {
  return { research: "🔎", read_url: "📄", recall: "🧠", remember: "📌", revise_belief: "✏️" }[name] ?? "🛠";
}

function SettingsDialog({ onClose, envConfigured }: { onClose: () => void; envConfigured: boolean }) {
  const [s, setS] = useState<LLMSettings>(() => loadSettings());
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-xl bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <h2 className="text-base font-semibold">Model settings</h2>
        <p className="mt-1 text-xs text-stone-500">
          {envConfigured
            ? "A model is configured on the server. You can override it here for this browser only."
            : "No server-side key found. Enter one here; it is stored only in this browser and sent with your requests."}{" "}
          Works with any OpenAI-compatible endpoint (OpenAI, OpenRouter, Groq, Ollama…).
        </p>
        <label className="mt-4 block text-xs font-medium">API key</label>
        <input type="password" value={s.apiKey} onChange={(e) => setS({ ...s, apiKey: e.target.value })} className="mt-1 w-full rounded-md border border-stone-300 px-2 py-1.5 text-sm" placeholder="sk-…" />
        <label className="mt-3 block text-xs font-medium">Base URL (optional)</label>
        <input value={s.baseUrl} onChange={(e) => setS({ ...s, baseUrl: e.target.value })} className="mt-1 w-full rounded-md border border-stone-300 px-2 py-1.5 text-sm" placeholder="https://api.openai.com/v1" />
        <label className="mt-3 block text-xs font-medium">Model (optional)</label>
        <input value={s.model} onChange={(e) => setS({ ...s, model: e.target.value })} className="mt-1 w-full rounded-md border border-stone-300 px-2 py-1.5 text-sm" placeholder="gpt-4.1-mini" />
        <div className="mt-5 flex justify-end gap-2">
          <button
            onClick={() => {
              saveSettings({ apiKey: "", baseUrl: "", model: "" });
              onClose();
            }}
            className="rounded-md px-3 py-1.5 text-sm text-stone-600 hover:bg-stone-100"
          >
            Clear
          </button>
          <button
            onClick={() => {
              saveSettings(s);
              onClose();
            }}
            className="rounded-md bg-stone-900 px-3 py-1.5 text-sm text-white"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
