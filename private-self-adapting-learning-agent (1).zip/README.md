# Private Self-Adapting Learning Agent

Talk naturally to one tutor. Learn something, ask why, paste code, wander off-topic, change your mind. The agent decides freely what is useful each turn, and quietly builds a **persistent, inspectable, evidence-based memory of how you learn** — a memory you can read and correct.

> A free agent interacting naturally with a persistent, evolving memory of the learner.

## Running

```bash
npm install
npx drizzle-kit push          # creates tables in DATABASE_URL
npm run dev
```

Model configuration (any OpenAI-compatible endpoint):

| Variable | Default | Notes |
|---|---|---|
| `OPENAI_API_KEY` | – | or paste a key in **Settings** in the UI; it stays in your browser and is sent per request |
| `OPENAI_BASE_URL` | `https://api.openai.com/v1` | OpenRouter, Groq, Ollama (`http://localhost:11434/v1`), vLLM… |
| `LLM_MODEL` | `gpt-4.1-mini` | tutor model |
| `LLM_FAST_MODEL` | = `LLM_MODEL` | observer / consolidation model |
| `LLM_PROVIDER` | – | `mock` = offline stub (for UI dev / tests) |

## How it works

```
message ─► Tutor agent (one LLM, tools) ─► reply (streamed)
             ▲ reads MEMORY BRIEF               │
             │                                  ▼
             │                            Observer pass
             │                     rich, lightly-tagged evidence
             │                                  ▼
             │                        observations  (short-term)
             │                                  ▼  every ~8 items / when stale
             │                          Consolidation (LLM + code)
             │                                  ▼
             └────────────── nodes + edges + evidence links (long-term graph)
```

### The agent (`src/lib/agent/tutor.ts`)
One persona, no modes. Each turn it may answer, explain, ask one question, set a small task, inspect the learner's code, or use a tool:
`research` (Wikipedia + DuckDuckGo), `read_url`, `recall` (search memory), `remember` (store a specific observation), `revise_belief` (confirm / contradict / retire something in the brief when the person in front of it disagrees with the memory).

### Short-term memory (`observations`)
After each exchange an observer writes 0–4 plain-language facts about what happened — questions, mistakes, successes, casual remarks, topic switches — with a free-form `kind`, touched `entities`, the `activity` (learning / debugging / building…), an `outcome` only when something was *demonstrated*, and the tutor `strategy` the learner was reacting to. Interpretations are stored separately and marked tentative. Nothing is deleted.

### Long-term memory (`nodes`, `edges`, `evidence_links`)
Consolidation runs when enough evidence accumulates (or a leftover batch has gone quiet):

* **Code, deterministically:** concept nodes for entities; `related_to` edges that strengthen with co-occurrence; `strategy —works_for / fails_for→ concept` edges from strategy+outcome pairs; per-concept mastery from observed outcomes; signal counts (confusion × success × curiosity…) so a frequently-mentioned concept is *not* automatically "important".
* **The model, interpretively:** proposes patterns / preferences / goals / context-specific claims, links new evidence as *supports* or *contradicts*, revises summaries, merges duplicates. Every operation must cite observation ids.
* **Guardrails in code:** a claim about the person with a single observation is only a *hypothesis*; confidence is computed from support/contradiction counts and breadth across sessions (`claimConfidence`); one conversational event counts once; hypotheses **graduate** after ≥3 confirmations across ≥2 sessions; repeated contradiction demotes; a *revision* (usually narrowing to a context) resolves a contradiction; ACT-R-style activation lets untouched nodes fade to *dormant* — recoverable, never lost.

### The brief (`src/lib/memory/brief.ts`)
What the tutor reads: things the learner *told* it, durable claims with confidence and evidence counts, open hypotheses ("test only if the answer changes what you do"), contradicted beliefs (do not act on), concept state with signals, what has worked/not worked, previous conversations, and raw recent + relevant evidence. It is framed as a prior: *the person in front of you outranks the brief*.

### Inspect & correct
`/memory` shows the model, the evidence stream, the journal of memory operations, and the exact brief. Any claim can be retired ("that's not me") — history is kept.

### MCP
`POST /api/mcp` is a Streamable-HTTP MCP server (stateless JSON-RPC): `get_learner_brief`, `search_memory`, `get_graph`, `add_observation`, `revise_belief`, `recommend_next`, `tutor_turn`. External assistants can read the learner model and contribute evidence that flows through the same consolidation.

## The laboratory

`scripts/simulate.ts` drives synthetic learners through the real pipeline with a scripted mock LLM and backdated sessions, printing the brief the tutor would see at each session start and the final graph:

```bash
npx tsx --tsconfig tsconfig.json scripts/simulate.ts               # scenario A: Bash learner, topic switch, context-specific preference
SCENARIO=b npx tsx --tsconfig tsconfig.json scripts/simulate.ts    # scenario B: hypothesis graduation, then repeated contradiction
LLM_PROVIDER=openai npx tsx --tsconfig tsconfig.json scripts/simulate.ts   # same scripts against a real model
```

Findings that changed the implementation: decay was initially far too aggressive (a stated goal faded in two weeks); stated goals were being rendered as hypotheses; a contradiction was double-counted when both the agent and the observer recorded it; label de-duplication swallowed "learning bash for a devops job" into the concept "bash". All fixed and re-verified in simulation.
