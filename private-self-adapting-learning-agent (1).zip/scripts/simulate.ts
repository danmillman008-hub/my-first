/**
 * Laboratory: run synthetic learners through the real pipeline
 * (agent loop → observer → consolidation → graph → brief) with a mock LLM,
 * backdating time between sessions to exercise decay and multi-session logic.
 *
 *   npx tsx scripts/simulate.ts            # mock provider (no key needed)
 *   LLM_PROVIDER=openai npx tsx scripts/simulate.ts   # real model if OPENAI_API_KEY is set
 */
import "dotenv/config";
process.env.LLM_PROVIDER = process.env.LLM_PROVIDER === "openai" ? "" : "mock";

import { setMockHandler, resolveConfig, type ChatMessage, type ToolCall } from "@/lib/llm/provider";
import { runTurn } from "@/lib/agent/tutor";
import { buildBrief } from "@/lib/memory/brief";
import { listNodes, listEdges } from "@/lib/memory/graph";
import { consolidate, recentMemoryEvents } from "@/lib/memory/consolidate";
import { retrieveObservations } from "@/lib/memory/observations";
import { pool } from "@/db";

type Step = {
  user: string;
  tutor: string;
  toolCalls?: ToolCall[];
  observations: { content: string; kind: string; entities: string[]; activity?: string; outcome?: string | null; strategy?: string | null; salience?: number; interpretation?: string | null }[];
  summary?: string;
};
type Session = { daysAgo: number; steps: Step[] };

const LEARNER = process.env.SIM_LEARNER ?? `sim_${Date.now().toString(36)}`;

// ---------------------------------------------------------------------------
// A synthetic learner: wants Bash for a devops job, says "skip theory" early,
// struggles with test brackets, succeeds after contrast examples, switches to
// git mid-session, and weeks later asks for theory first (contradicting the
// early "skip theory" signal) while studying pipes.
// ---------------------------------------------------------------------------
const SCENARIO: Session[] = [
  {
    daysAgo: 21,
    steps: [
      {
        user: "I want to learn Bash. I just started a devops job and I'm lost in the terminal.",
        tutor: "Great — let's start where you are. What's the last thing you had to do in the terminal that felt confusing?",
        toolCalls: [{ id: "c1", name: "remember", arguments: JSON.stringify({ note: "Started a devops job; learning Bash because they feel lost in the terminal", entities: ["bash", "devops"], kind: "goal" }) }],
        observations: [
          { content: "Said they want to learn Bash because they just started a devops job and feel lost in the terminal", kind: "goal", entities: ["bash", "devops", "terminal"], activity: "planning", salience: 0.9 },
        ],
        summary: "Starting Bash; devops job context",
      },
      {
        user: "Honestly just show me examples, skip the theory. I had to loop over files yesterday and gave up.",
        tutor: "Fair. Here's a loop over files:\n```bash\nfor f in *.log; do echo \"$f\"; done\n```\nTry changing it to print the line count of each file.",
        observations: [
          { content: "Said 'just show me examples, skip the theory'", kind: "preference", entities: ["bash"], activity: "learning", salience: 0.7 },
          { content: "Tried to loop over files yesterday at work and gave up", kind: "context", entities: ["for loop", "bash"], activity: "learning", salience: 0.6 },
        ],
      },
      {
        user: "for f in *.log; do wc -l $f; done  -- it printed the filename too, is that right?",
        tutor: "Yes — `wc -l file` prints count and name. Use `wc -l < \"$f\"` to get just the number. Also quote `\"$f\"`: filenames with spaces will bite you otherwise.",
        observations: [
          { content: "Adapted the file loop example correctly to run wc -l on each file; noticed the output included the filename and asked whether that was right", kind: "success", entities: ["for loop", "wc", "bash"], activity: "learning", outcome: "success", strategy: "concrete-example", salience: 0.6 },
          { content: "Left $f unquoted in the loop body", kind: "mistake", entities: ["quoting", "bash"], activity: "learning", outcome: "struggle", salience: 0.5 },
        ],
      },
      {
        user: "ok. now what does [ -f $f ] do vs [[ -f $f ]]? I see both in our scripts",
        tutor: "Both test 'is a regular file'. `[` is a command (POSIX); `[[` is bash syntax: no word-splitting, supports `&&`, `=~`. In bash scripts prefer `[[ ]]`.",
        observations: [
          { content: "Asked the difference between [ -f ] and [[ -f ]] because both appear in their work scripts", kind: "question", entities: ["test brackets", "bash", "conditionals"], activity: "learning", salience: 0.5 },
        ],
      },
      {
        user: "I don't really get it. When would [ break and [[ not?",
        tutor: "Concrete contrast:\n```bash\nf=\"my file.txt\"\n[ -f $f ]    # error: too many arguments\n[[ -f $f ]]  # works: no word splitting\n```\nRun both.",
        observations: [
          { content: "Said 'I don't really get it' about [ vs [[ after the explanation of POSIX command vs bash syntax", kind: "confusion", entities: ["test brackets", "bash"], activity: "learning", outcome: "confusion", strategy: "formal-definition", salience: 0.6 },
        ],
      },
      {
        user: "oh! ok so [[ is safer with spaces because it doesn't split. got it. that example made it click",
        tutor: "Exactly. Word splitting is the root of most quoting bugs — you'll see it again.",
        observations: [
          { content: "After the side-by-side example with a filename containing a space, correctly explained that [[ is safer because it does not word-split; said 'that example made it click'", kind: "insight", entities: ["test brackets", "word splitting", "bash"], activity: "learning", outcome: "insight", strategy: "contrast-example", salience: 0.7, interpretation: "The formal explanation did not land; the concrete contrast did" },
        ],
      },
      {
        user: "random q: what does git rebase actually do? my lead keeps saying rebase before pushing",
        tutor: "Rebase replays your commits on top of another base. Before pushing: `git fetch && git rebase origin/main` so your commits sit on the latest main.",
        observations: [
          { content: "Switched topic from Bash to git rebase, prompted by their lead telling them to rebase before pushing", kind: "topic_switch", entities: ["git rebase", "git"], activity: "exploring", salience: 0.5 },
        ],
        summary: "Bash basics done (loops, [[ ]]); jumped to git rebase",
      },
      {
        user: "cool thanks, gotta go",
        tutor: "See you. Next time bring a real script from work if you can.",
        observations: [],
      },
    ],
  },
  {
    daysAgo: 13,
    steps: [
      {
        user: "back. I wrote this: for f in $(ls *.log); do echo $f; done  — my lead said don't parse ls. why?",
        tutor: "Because `ls` output is text split on whitespace — filenames with spaces or newlines break. Use the glob directly: `for f in *.log`. You already did this right last time!",
        observations: [
          { content: "Brought a real script from work that parses ls in a for loop; lead had told them not to and they asked why", kind: "code", entities: ["for loop", "word splitting", "bash"], activity: "reviewing", outcome: "struggle", salience: 0.6 },
        ],
      },
      {
        user: "right, word splitting again. same reason as the [[ thing. ok what about arrays, how do I loop an array?",
        tutor: "```bash\narr=(a \"b c\" d)\nfor x in \"${arr[@]}\"; do echo \"$x\"; done\n```\nThe quotes around `${arr[@]}` matter — same word-splitting story.",
        observations: [
          { content: "Connected 'don't parse ls' to word splitting on their own, referencing the earlier [[ example", kind: "insight", entities: ["word splitting", "bash"], activity: "learning", outcome: "insight", strategy: "direct-answer", salience: 0.7 },
          { content: "Asked how to loop over an array", kind: "question", entities: ["arrays", "for loop", "bash"], activity: "learning", salience: 0.4 },
        ],
      },
      {
        user: "just give me the one-liner, I'm in the middle of fixing a deploy script and it's failing on a path with spaces",
        tutor: "`for x in \"${arr[@]}\"; do cp \"$x\" \"$dest/\"; done` — quote every expansion.",
        observations: [
          { content: "While fixing a failing deploy script, asked for 'just the one-liner' rather than explanation", kind: "preference", entities: ["bash", "arrays"], activity: "debugging", salience: 0.6 },
        ],
      },
      {
        user: "worked. the path had a space, quoting fixed it.",
        tutor: "Nice — that's the third time word splitting showed up. You now recognise it on sight.",
        observations: [
          { content: "Fixed the deploy script by quoting the expansion; confirmed the path contained a space", kind: "success", entities: ["quoting", "word splitting", "bash"], activity: "debugging", outcome: "success", strategy: "direct-answer", salience: 0.6 },
        ],
        summary: "Debugged deploy script (quoting); arrays",
      },
    ],
  },
  {
    daysAgo: 1,
    steps: [
      {
        user: "I want to properly understand pipes and redirection. Can you explain the theory first this time — file descriptors and all — before examples? I keep cargo-culting 2>&1.",
        tutor: "Yes. Every process has numbered file descriptors: 0 stdin, 1 stdout, 2 stderr. `>` rewires fd 1 to a file; `2>&1` makes fd 2 point where fd 1 currently points — so order matters…",
        toolCalls: [
          {
            id: "c2",
            name: "revise_belief",
            arguments: JSON.stringify({ label: "skip the theory", action: "contradict", reason: "Learner explicitly asked for the theory of file descriptors before examples while studying pipes" }),
          },
        ],
        observations: [
          { content: "Asked to have the theory of pipes and file descriptors explained first, before examples, because they 'keep cargo-culting 2>&1'", kind: "correction", entities: ["pipes", "redirection", "file descriptors", "bash"], activity: "learning", salience: 0.8, interpretation: "Contradicts the earlier 'skip the theory' — when studying deliberately they want the model first" },
        ],
      },
      {
        user: "so `cmd 2>&1 > file` sends stderr to the terminal and stdout to the file, because 2 copied where 1 pointed *before* 1 was redirected?",
        tutor: "Exactly right. That's the subtle bit most people never get.",
        observations: [
          { content: "Correctly predicted the behaviour of `cmd 2>&1 > file` from the fd-duplication model, explaining the ordering", kind: "success", entities: ["redirection", "file descriptors", "bash"], activity: "learning", outcome: "success", strategy: "formal-definition", salience: 0.8 },
        ],
        summary: "Pipes/redirection theory; fd duplication understood",
      },
    ],
  },
];

// Scenario B: a learner who repeatedly asks to build things (hypothesis → graduated
// preference), then later pushes back and wants theory (contradiction of a durable claim).
const build = (n: number, daysAgo: number): Session => ({
  daysAgo,
  steps: [
    {
      user: n === 1 ? "Teach me Python classes. I learn best by building something, not reading." : n === 2 ? "Back for more OOP. Can you give me something to build again? That worked." : "Inheritance next — let me try building it first before you explain.",
      tutor: "Let's build. Write a class `Account` with deposit/withdraw and a balance check.",
      observations: [
        { content: n === 1 ? "Said they learn best by building something rather than reading" : n === 2 ? "Asked for something to build again, said that approach worked last time" : "Asked to try building inheritance first before any explanation", kind: "preference", entities: ["python", "classes", "oop"], activity: "learning", salience: 0.7 },
      ],
      summary: `OOP session ${n}: building exercises`,
    },
    {
      user: "class Account:\n    def __init__(self, b=0): self.balance = b\n    def deposit(self, x): self.balance += x\n    def withdraw(self, x):\n        if x > self.balance: raise ValueError('insufficient')\n        self.balance -= x",
      tutor: "That's correct and idiomatic. One thought: what should happen on a negative deposit?",
      observations: [
        { content: "Wrote a correct Account class with a guard in withdraw after being given the exercise", kind: "code", entities: ["python", "classes", "exceptions"], activity: "building", outcome: "success", strategy: "exercise", salience: 0.6 },
      ],
    },
  ],
});
const SCENARIO_B: Session[] = [
  build(1, 30),
  build(2, 20),
  build(3, 10),
  {
    daysAgo: 1,
    steps: [
      {
        user: "Honestly I'm burnt out on projects. Just explain the theory of decorators to me properly, no exercise.",
        tutor: "Understood — pure explanation. A decorator is a callable that takes a function and returns a function…",
        observations: [
          { content: "Said they are burnt out on projects and asked for a pure theoretical explanation of decorators with no exercise", kind: "correction", entities: ["python", "decorators"], activity: "learning", salience: 0.8, interpretation: "Runs against the standing 'learns by building' preference — possibly fatigue rather than a changed preference" },
        ],
        summary: "Decorators, explanation only",
      },
      {
        user: "yeah keep it explanatory today, seriously no exercises. so a decorator with arguments is a function returning a decorator?",
        tutor: "Exactly — three layers: factory → decorator → wrapper.",
        observations: [
          { content: "Insisted again on explanation only with no exercises; correctly inferred that a decorator with arguments is a function returning a decorator", kind: "correction", entities: ["python", "decorators"], activity: "learning", outcome: "success", strategy: "formal-definition", salience: 0.7 },
        ],
      },
    ],
  },
];

// ---------------------------------------------------------------------------
// Mock LLM: scripted tutor + observer, rule-based consolidator.
// ---------------------------------------------------------------------------
let current: Step | null = null;
let toolsDone = false;

setMockHandler(async ({ messages, purpose }) => {
  if (purpose === "tutor") {
    if (current?.toolCalls?.length && !toolsDone) {
      toolsDone = true;
      return { content: "", toolCalls: current.toolCalls };
    }
    return { content: current?.tutor ?? "..." };
  }
  if (purpose === "observe") {
    return { content: JSON.stringify({ observations: current?.observations ?? [], session_summary: current?.summary ?? null }) };
  }
  if (purpose === "consolidate") {
    return { content: JSON.stringify({ operations: ruleBasedConsolidator(messages) }) };
  }
  return { content: "{}" };
});

const SIG = (s: string) => s.toLowerCase().split(/\W+/).filter((w) => w.length > 3 && !["said", "they", "that", "this", "with", "just", "about", "asked", "their", "them"].includes(w));

function ruleBasedConsolidator(messages: ChatMessage[]) {
  const text = messages[1]?.content ?? "";
  const claims = [...text.matchAll(/- id=(n_\w+) \[(\w+),[^\]]*\] "([^"]+)": ([^\n]*)/g)].map((m) => ({ id: m[1], kind: m[2], label: m[3], summary: m[4] }));
  const obs = [...text.matchAll(/- id=(obs_\w+) \[(\w+)[^\]]*\][^\n]*\n\s+([^\n]+)/g)].map((m) => ({ id: m[1], kind: m[2], content: m[3] }));
  const ops: Record<string, unknown>[] = [];
  const created: { label: string; words: string[] }[] = [];
  for (const o of obs) {
    if (o.kind === "goal") {
      const label = "learning bash for a devops job";
      const ex = claims.find((c) => c.kind === "goal") ?? created.find((c) => c.label === label);
      if (ex && "id" in ex) ops.push({ op: "link_evidence", node_id: ex.id, polarity: "supports", evidence: [o.id] });
      else if (!ex) {
        ops.push({ op: "create_node", kind: "goal", label, summary: o.content, evidence: [o.id] });
        created.push({ label, words: SIG(label) });
      }
    } else if (o.kind === "preference") {
      const debugging = /one-liner|middle of fixing|deploy/.test(o.content);
      const building = /build/i.test(o.content);
      const label = building ? "learns by building things" : debugging ? "wants terse answers while debugging" : "skip the theory, show examples";
      const ex = claims.find((c) => SIG(c.label).filter((w) => SIG(label).includes(w)).length >= 2);
      if (ex) ops.push({ op: "link_evidence", node_id: ex.id, polarity: "supports", evidence: [o.id], note: "restated" });
      else ops.push({ op: "create_node", kind: "preference", label, summary: o.content, context: debugging ? "debugging" : null, evidence: [o.id] });
    } else if (o.kind === "correction") {
      const ex = claims.find((c) => /theory/.test(c.label)) ?? claims.find((c) => /building/.test(c.label));
      if (ex && /building/.test(ex.label)) {
        ops.push({ op: "link_evidence", node_id: ex.id, polarity: "contradicts", evidence: [o.id], note: "asked for explanation only, no exercises (said burnt out)" });
      } else if (ex) {
        ops.push({ op: "link_evidence", node_id: ex.id, polarity: "contradicts", evidence: [o.id], note: "asked for theory first while studying pipes" });
        ops.push({ op: "revise_node", node_id: ex.id, summary: "Early on asked to skip theory and see examples; later, when studying deliberately, asked for the theory first. Looks context-dependent: examples when getting unstuck, model-first when studying.", context: "getting unstuck / quick tasks", reason: "new contradicting evidence" });
      }
    } else if (o.kind === "insight" && /word splitting/.test(o.content)) {
      const label = "recognises word-splitting bugs after concrete examples";
      const ex = claims.find((c) => /word-splitting/.test(c.label));
      if (ex) ops.push({ op: "link_evidence", node_id: ex.id, polarity: "supports", evidence: [o.id] });
      else ops.push({ op: "create_node", kind: "pattern", label, summary: "Understanding of word splitting transfers across situations once seen concretely.", evidence: [o.id] });
    }
  }
  return ops;
}

// ---------------------------------------------------------------------------

async function backdate(days: number) {
  const iv = `${days} days`;
  const tables: [string, string[]][] = [
    ["observations", ["created_at", "consolidated_at"]],
    ["evidence_links", ["created_at"]],
    ["nodes", ["first_seen", "last_reinforced", "created_at", "updated_at"]],
    ["edges", ["last_reinforced", "created_at"]],
    ["messages", ["created_at"]],
    ["memory_events", ["created_at"]],
    ["sessions", ["started_at", "last_active_at"]],
  ];
  for (const [t, cols] of tables) {
    const set = cols.map((c) => `${c} = ${c} - interval '${iv}'`).join(", ");
    await pool.query(`update ${t} set ${set} where learner_id = $1 and ${cols[0]} > now() - interval '1 hour'`, [LEARNER]);
  }
}

async function main() {
  const cfg = resolveConfig();
  for (const t of ["observations", "evidence_links", "nodes", "edges", "messages", "memory_events", "sessions", "research_notes"]) await pool.query(`delete from ${t} where learner_id like 'sim_%'`);
  await pool.query(`delete from learners where id like 'sim_%'`);
  console.log(`\n=== SIMULATION learner=${LEARNER} provider=${cfg.provider} ===`);
  const scenario = process.env.SCENARIO === "b" ? SCENARIO_B : SCENARIO;
  for (const [si, session] of scenario.entries()) {
    console.log(`\n\n################ SESSION ${si + 1} (t = -${session.daysAgo}d) ################`);
    const briefBefore = await buildBrief(LEARNER, session.steps[0].user);
    console.log(`--- brief the tutor sees at session start ---\n${briefBefore.text}\n---`);
    let sessionId: string | null = null;
    for (const step of session.steps) {
      current = step;
      toolsDone = false;
      let reply = "";
      const tools: string[] = [];
      for await (const ev of runTurn({ learnerId: LEARNER, sessionId, content: step.user, cfg })) {
        if (ev.type === "session") sessionId = ev.sessionId;
        if (ev.type === "token") reply += ev.text;
        if (ev.type === "tool" && ev.status === "done") tools.push(`${ev.name}: ${ev.summary}`);
        if (ev.type === "memory") console.log(`   [memory] +${ev.observations} obs${ev.consolidation ? ` | consolidated ${ev.consolidation.observations}: created=${ev.consolidation.created.join(",")} contradicted=${ev.consolidation.contradicted.join(",")} notes=${ev.consolidation.notes.join(";")}` : ""}`);
        if (ev.type === "error") console.log("   [error]", ev.error);
      }
      console.log(`U: ${step.user.slice(0, 90)}\nA: ${reply.slice(0, 90).replace(/\n/g, " ")}${tools.length ? `\n   tools: ${tools.join(" | ")}` : ""}`);
    }
    const r = await consolidate(LEARNER, cfg, { force: true });
    console.log(`   [end-of-session consolidation] ran=${r.ran} created=${r.created.join(",")} contradicted=${r.contradicted.join(",")} revised=${r.revised.join(",")} notes=${r.notes.join(";")}`);
    await backdate(session.daysAgo);
  }

  console.log("\n\n################ FINAL STATE ################");
  const nodes = await listNodes(LEARNER, { includeInactive: true });
  const edges = await listEdges(LEARNER);
  const byId = new Map(nodes.map((n) => [n.id, n]));
  for (const n of nodes.sort((a, b) => a.kind.localeCompare(b.kind) || b.confidence - a.confidence)) {
    console.log(
      `${n.kind.padEnd(10)} ${n.status.padEnd(12)} conf=${n.confidence.toFixed(2)} act=${n.activation.toFixed(2)} ${n.mastery !== null ? `mastery=${n.mastery.toFixed(2)} ` : ""}↑${n.supports} ↓${n.contradicts} s=${n.distinctSessions} ${n.context ? `ctx=${n.context} ` : ""}| ${n.label}${n.summary && n.kind !== "concept" ? ` — ${n.summary.slice(0, 90)}` : ""}`,
    );
  }
  console.log("\n--- edges (non related_to) ---");
  for (const e of edges.filter((e) => e.relation !== "related_to")) console.log(`${byId.get(e.fromNode)?.label} —${e.relation}→ ${byId.get(e.toNode)?.label} (w=${e.weight}, ↑${e.supports} ↓${e.contradicts})`);
  console.log("\n--- strongest related_to ---");
  for (const e of edges.filter((e) => e.relation === "related_to").sort((a, b) => b.weight - a.weight).slice(0, 8)) console.log(`${byId.get(e.fromNode)?.label} ~ ${byId.get(e.toNode)?.label} (w=${e.weight})`);

  console.log("\n--- retrieval test: 'why does quoting matter' ---");
  for (const o of await retrieveObservations(LEARNER, "why does quoting matter with spaces", ["quoting", "word splitting"], 5)) console.log(`  ${o.score.toFixed(2)} ${o.createdAt.toISOString().slice(0, 10)} ${o.content.slice(0, 100)}`);

  console.log("\n--- brief now (a new session about python) ---");
  console.log((await buildBrief(LEARNER, "I want to learn python decorators")).text);

  console.log("\n--- memory journal (latest 15) ---");
  for (const e of (await recentMemoryEvents(LEARNER, 15)).reverse()) console.log(`  ${e.type.padEnd(16)} ${e.detail.slice(0, 120)}`);

  if (process.env.KEEP !== "1") {
    for (const t of ["observations", "evidence_links", "nodes", "edges", "messages", "memory_events", "sessions", "research_notes", "learners"]) {
      await pool.query(`delete from ${t} where ${t === "learners" ? "id" : "learner_id"} = $1`, [LEARNER]);
    }
  }
  await pool.end();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
