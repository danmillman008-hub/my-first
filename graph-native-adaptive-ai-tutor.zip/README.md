# Graph Tutor — graph-native adaptive tutor with MCP

A private tutor whose behaviour (depth, length, explanation style, tone, what to
reinforce, what to suggest next) is read off a personal knowledge graph that
grows from your conversation. No syllabus, no quizzes, one chat window.

## Layout

```
src/db/schema.ts        graph_nodes / graph_edges (Graphify graph.json shape + weight/mastery/dormant),
                        interactions, learner_state
src/graph/store.ts      graph substrate: query_graph / get_node / get_neighbors / shortest_path,
                        upsert, graph.json import/export
src/graph/dynamics.ts   strengthen (+ one-hop propagation), time decay, dormancy, reactivation
src/tutor/affect.ts     turn signals -> affect vector (confusion/curiosity/fatigue/frustration/confidence)
src/tutor/extract.ts    concept + edge extraction into the graph (LLM or heuristic; EXTRACTED/INFERRED/AMBIGUOUS)
src/tutor/policy.ts     graph state + learner state -> response policy (depth, verbosity, style, tone, scaffold, next paths)
src/tutor/respond.ts    one turn: decay -> extract -> affect -> prefs -> strengthen -> policy -> generate -> record
src/tutor/llm.ts        Anthropic / OpenAI-compatible provider shim (optional)
src/mcp/server.ts       thin MCP adapter (tools / resources / prompt)
src/app/api/mcp/route.ts  MCP Streamable HTTP endpoint (official SDK transport, stateless)
scripts/mcp-stdio.ts    MCP stdio entrypoint
src/app/chat.tsx        the chat UI (+ tiny optional state panel)
```

## Run

```bash
npm install
# .env: DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
npm run db:push          # creates tables
npm run dev              # http://localhost:3000
```

Optional LLM (server-side only). Without a key the tutor still runs the full
graph/policy loop and composes replies from graph state ("offline" mode):

```
ANTHROPIC_API_KEY=...   [ANTHROPIC_MODEL=claude-sonnet-4-20250514]
# or
OPENAI_API_KEY=...      [OPENAI_MODEL=gpt-4o-mini] [OPENAI_BASE_URL=https://api.openai.com/v1]
```

## MCP

Streamable HTTP (single endpoint, POST; GET/DELETE -> 405 because the server is stateless):

```json
{ "mcpServers": { "graph-tutor": { "type": "streamable-http", "url": "http://localhost:3000/api/mcp" } } }
```

stdio (shares the same PostgreSQL graph):

```json
{ "mcpServers": { "graph-tutor": { "type": "stdio", "command": "npx", "args": ["tsx", "scripts/mcp-stdio.ts"], "cwd": "/path/to/repo" } } }
```

| Kind | Name | Notes |
| --- | --- | --- |
| tool (read) | `query_graph`, `get_node`, `get_neighbors`, `shortest_path` | same names as Graphify's MCP server |
| tool (read) | `get_policy` | derive policy for concept ids without recording a turn |
| tool (write) | `tutor_turn` | run a learner message through the tutor |
| tool (write) | `record_feedback` | +1/-1 on last assistant turn |
| tool (write) | `decay_graph` | force a decay pass |
| tool (write) | `import_graph_json` | merge a Graphify `graph.json` |
| resource | `graph://graph.json` | full export, Graphify shape |
| resource | `learner://state` | affect, preferences, active/dormant branches |
| resource template | `graph://node/{id}` | node + edges |
| prompt | `explain(concept)` | tutor prompt conditioned on current policy |

`GET /api/graph` returns the same `graph.json` export over plain HTTP.

## How adaptation works (no rules engine)

- Every user turn is analysed for signals (confusion, curiosity, fatigue,
  frustration, confidence, follow-up, correction, wants-more/less, length).
  The learner's affect vector is an EMA of these; the policy blends EMA with the
  current turn so sharp cues act immediately.
- Concepts mentioned are upserted into the graph; edges come from the LLM
  (INFERRED), co-mention (EXTRACTED `co_occurs`) and conversational adjacency
  (AMBIGUOUS `related_to`).
- Touched nodes gain `weight`, neighbours get a damped share (propagation).
  A decay pass (max once/hour, idle-time based half-life ≈ 5 days) fades
  weights; nodes under a threshold become `dormant`. Touching a dormant node
  reactivates it and the policy tells the generator to reconnect rather than restart.
- The style used in the previous answer is credited/blamed by the next turn's
  signals — globally and per concept (`style_prefs`), so "analogies work for
  probability but not for syntax" is learnable.
- Policy = f(learner prefs, target mastery, affect, weak prerequisites, edge
  weights). It selects depth, verbosity, style, tone, scaffolding and next paths,
  and is rendered into instructions for the generator (or the offline composer).
