import { recordFeedback } from "@/tutor/respond";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as { sessionId?: string; value?: number } | null;
  if (body?.value !== 1 && body?.value !== -1) return Response.json({ error: "value must be 1 or -1" }, { status: 400 });
  await recordFeedback((body.sessionId ?? "default").slice(0, 64), body.value);
  return Response.json({ ok: true });
}
