import { learnerSummary } from "@/tutor/respond";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json(await learnerSummary());
}
