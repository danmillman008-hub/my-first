import { WebStandardStreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js";
import { createMcpServer } from "@/mcp/server";

/**
 * MCP Streamable HTTP transport — single endpoint (/api/mcp), per the current
 * MCP transport spec (2025-03-26+ "Streamable HTTP", not the deprecated
 * HTTP+SSE pair). Uses the official SDK transport in stateless mode, which is
 * the correct mode for Next.js's per-request route handlers:
 *  - POST: client -> server JSON-RPC; responses are returned as JSON
 *    (the client's Accept header must list application/json and text/event-stream).
 *  - GET / DELETE: no server-initiated stream or session exists in stateless
 *    mode, so we answer 405 Method Not Allowed as the spec permits.
 */

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(req: Request): Promise<Response> {
  const server = createMcpServer();
  const transport = new WebStandardStreamableHTTPServerTransport({
    sessionIdGenerator: undefined, // stateless
    enableJsonResponse: true,
  });
  await server.connect(transport);
  try {
    return await transport.handleRequest(req);
  } finally {
    void server.close().catch(() => {});
  }
}

function methodNotAllowed() {
  return new Response(
    JSON.stringify({ jsonrpc: "2.0", error: { code: -32000, message: "Method not allowed. This stateless Streamable HTTP endpoint accepts POST only." }, id: null }),
    { status: 405, headers: { "content-type": "application/json", allow: "POST" } },
  );
}

export const GET = methodNotAllowed;
export const DELETE = methodNotAllowed;
