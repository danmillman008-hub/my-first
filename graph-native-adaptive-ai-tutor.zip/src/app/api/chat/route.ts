import { runTurn } from "@/tutor/respond";
import { db } from "@/db";
import { interactions } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as { sessionId?: string; message?: string } | null;
  const message = body?.message?.trim();
  if (!message) return Response.json({ error: "message required" }, { status: 400 });
  const sessionId = (body?.sessionId ?? "default").slice(0, 64);
  try {
    const result = await runTurn(sessionId, message);
    return Response.json(result);
  } catch (err) {
    console.error("[chat]", err);
    return Response.json({ error: "tutor failed" }, { status: 500 });
  }
}

/** Conversation history for a session (used to restore the chat on reload). */
export async function GET(req: Request) {
  const sessionId = (new URL(req.url).searchParams.get("sessionId") ?? "default").slice(0, 64);
  const rows = await db.select().from(interactions).where(eq(interactions.sessionId, sessionId)).orderBy(asc(interactions.createdAt)).limit(200);
  return Response.json(rows.map((r) => ({ id: r.id, role: r.role, content: r.content, concepts: r.concepts, policy: r.policy })));
}
