import { exportGraphJson } from "@/graph/store";

export const dynamic = "force-dynamic";

/** Plain graph.json export (same shape Graphify writes to graphify-out/graph.json). */
export async function GET() {
  return Response.json(await exportGraphJson());
}
