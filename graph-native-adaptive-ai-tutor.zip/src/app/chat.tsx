"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type Msg = { id: string; role: "user" | "assistant"; content: string; policy?: { style?: string; tone?: string; depth?: number } };
type Summary = {
  provider: string;
  nodes: number;
  dormantCount: number;
  affect: Record<string, number>;
  preferences: { depth: number; verbosity: number; topStyle: string };
  active: { id: string; label: string; weight: number; mastery: number }[];
  dormant: { id: string; label: string }[];
};

function sessionId() {
  if (typeof window === "undefined") return "default";
  let id = localStorage.getItem("tutor-session");
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem("tutor-session", id);
  }
  return id;
}

export default function Chat() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [showPanel, setShowPanel] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);
  const sid = useRef("default");

  const refreshSummary = useCallback(async () => {
    const r = await fetch("/api/state").then((r) => r.json()).catch(() => null);
    if (r) setSummary(r);
  }, []);

  useEffect(() => {
    sid.current = sessionId();
    fetch(`/api/chat?sessionId=${sid.current}`)
      .then((r) => r.json())
      .then((rows: Msg[]) => setMessages(rows.map((r) => ({ ...r, id: String(r.id) }))))
      .catch(() => {});
    refreshSummary();
  }, [refreshSummary]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, busy]);

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    setBusy(true);
    setMessages((m) => [...m, { id: `u${Date.now()}`, role: "user", content: text }]);
    try {
      const res = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ sessionId: sid.current, message: text }) });
      const data = await res.json();
      setMessages((m) => [...m, { id: `a${Date.now()}`, role: "assistant", content: data.reply ?? data.error ?? "…", policy: data.policy }]);
      refreshSummary();
    } catch {
      setMessages((m) => [...m, { id: `e${Date.now()}`, role: "assistant", content: "Something went wrong. Try again." }]);
    } finally {
      setBusy(false);
    }
  }

  async function feedback(value: 1 | -1) {
    await fetch("/api/feedback", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ sessionId: sid.current, value }) });
    refreshSummary();
  }

  const lastAssistantId = [...messages].reverse().find((m) => m.role === "assistant")?.id;

  return (
    <div className="mx-auto flex h-screen max-w-5xl gap-4 p-4">
      <section className="flex min-w-0 flex-1 flex-col rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
        <header className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
          <div>
            <h1 className="text-sm font-semibold text-slate-900">Tutor</h1>
            <p className="text-xs text-slate-500">Adapts from your graph, not a syllabus.</p>
          </div>
          <button onClick={() => setShowPanel((s) => !s)} className="text-xs text-slate-500 hover:text-slate-900">
            {showPanel ? "hide state" : "show state"}
          </button>
        </header>

        <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
          {messages.length === 0 && (
            <p className="mt-12 text-center text-sm text-slate-400">Ask about anything you want to understand. The graph starts empty and grows from this conversation.</p>
          )}
          {messages.map((m) => (
            <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] whitespace-pre-wrap rounded-2xl px-4 py-2 text-sm leading-relaxed ${m.role === "user" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-900"}`}>
                {m.content}
                {m.role === "assistant" && m.policy?.style && (
                  <div className="mt-1 flex items-center gap-2 text-[10px] text-slate-400">
                    <span>
                      {m.policy.style} · {m.policy.tone} · depth {Math.round((m.policy.depth ?? 0) * 100)}%
                    </span>
                    {m.id === lastAssistantId && (
                      <span className="ml-auto flex gap-1">
                        <button onClick={() => feedback(1)} className="hover:text-slate-700" title="helpful">👍</button>
                        <button onClick={() => feedback(-1)} className="hover:text-slate-700" title="not helpful">👎</button>
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
          {busy && <div className="text-xs text-slate-400">thinking…</div>}
          <div ref={bottomRef} />
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            send();
          }}
          className="flex gap-2 border-t border-slate-100 p-3"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask something…"
            className="flex-1 rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-slate-400"
            autoFocus
          />
          <button type="submit" disabled={busy || !input.trim()} className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-40">
            Send
          </button>
        </form>
      </section>

      {showPanel && summary && (
        <aside className="hidden w-64 shrink-0 space-y-4 overflow-y-auto rounded-2xl bg-white p-4 text-xs shadow-sm ring-1 ring-slate-200 md:block">
          <div>
            <p className="font-semibold text-slate-900">Graph</p>
            <p className="text-slate-500">
              {summary.nodes} concepts · {summary.dormantCount} dormant · {summary.provider}
            </p>
          </div>
          <div>
            <p className="font-semibold text-slate-900">Preferences</p>
            <Bar label="depth" v={summary.preferences.depth} />
            <Bar label="length" v={summary.preferences.verbosity} />
            <p className="text-slate-500">style: {summary.preferences.topStyle}</p>
          </div>
          <div>
            <p className="font-semibold text-slate-900">Affect</p>
            {Object.entries(summary.affect).map(([k, v]) => (
              <Bar key={k} label={k} v={v} />
            ))}
          </div>
          {summary.active.length > 0 && (
            <div>
              <p className="font-semibold text-slate-900">Active branches</p>
              {summary.active.map((n) => (
                <div key={n.id} className="flex justify-between text-slate-600">
                  <span className="truncate">{n.label}</span>
                  <span className="text-slate-400">{Math.round(n.mastery * 100)}%</span>
                </div>
              ))}
            </div>
          )}
          {summary.dormant.length > 0 && (
            <div>
              <p className="font-semibold text-slate-900">Dormant</p>
              {summary.dormant.map((n) => (
                <div key={n.id} className="truncate text-slate-400">
                  {n.label}
                </div>
              ))}
            </div>
          )}
        </aside>
      )}
    </div>
  );
}

function Bar({ label, v }: { label: string; v: number }) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-20 text-slate-500">{label}</span>
      <div className="h-1.5 flex-1 rounded bg-slate-100">
        <div className="h-1.5 rounded bg-slate-700" style={{ width: `${Math.round(v * 100)}%` }} />
      </div>
    </div>
  );
}
