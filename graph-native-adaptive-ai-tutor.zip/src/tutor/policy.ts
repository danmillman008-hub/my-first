import type { GraphNode, LearnerState } from "@/db/schema";
import { getNeighbors, getNodes } from "@/graph/store";
import { dominantAffect, type Affect, type TurnSignals } from "./affect";

/**
 * Response policy derived from graph state. No hand-written curriculum:
 * depth/verbosity/style/tone are read off node weights, mastery, per-concept
 * style preferences, learner-level preferences and the affect vector.
 */

export const STYLES = ["analogy", "example", "formal", "stepwise", "visual", "socratic"] as const;
export type Style = (typeof STYLES)[number];

export type Policy = {
  depth: number; // 0..1 (0 = intuition only, 1 = rigorous)
  verbosity: number; // 0..1 (0 = 2-3 sentences, 1 = long)
  style: Style;
  tone: "reassuring" | "energising" | "concise" | "neutral" | "patient";
  mastery: number; // avg mastery of target concepts
  scaffold: { id: string; label: string; mastery: number }[]; // weak prerequisites to touch first
  nextPaths: { id: string; label: string; reason: string }[]; // recommended continuations
  reactivated: string[];
  affect: keyof Affect | "neutral";
  offline: boolean;
};

function clamp01(x: number) {
  return Math.max(0, Math.min(1, x));
}

export function updatePreferences(prefs: LearnerState["preferences"], t: TurnSignals, lastStyle?: string): LearnerState["preferences"] {
  const p = { depth: prefs.depth, verbosity: prefs.verbosity, style: { ...prefs.style } };
  // depth/verbosity: explicit asks move fast; implicit signals move slowly
  if (t.wantsMore) (p.depth = clamp01(p.depth + 0.15)), (p.verbosity = clamp01(p.verbosity + 0.1));
  if (t.wantsLess) (p.depth = clamp01(p.depth - 0.15)), (p.verbosity = clamp01(p.verbosity - 0.15));
  if (t.confusion > 0.5) p.depth = clamp01(p.depth - 0.05);
  if (t.curiosity > 0.5) p.depth = clamp01(p.depth + 0.04);
  if (t.fatigue > 0.5) p.verbosity = clamp01(p.verbosity - 0.08);
  // long user messages correlate with tolerance for long answers
  p.verbosity = clamp01(p.verbosity * 0.92 + clamp01(t.msgLength / 60) * 0.08);
  // style credit assignment: if last answer used style S and user now signals understanding -> S up; confusion -> S down
  if (lastStyle) {
    const cur = p.style[lastStyle] ?? 0.5;
    const outcome = t.understood || t.curiosity > 0.5 ? 1 : t.confusion > 0.5 || t.correction ? 0 : 0.5;
    p.style[lastStyle] = clamp01(cur * 0.8 + outcome * 0.2);
  }
  return p;
}

function pickStyle(globalStyle: Record<string, number>, nodes: GraphNode[], affect: Affect, lastStyle?: string, turn?: TurnSignals): Style {
  const score = new Map<Style, number>();
  for (const s of STYLES) {
    let v = globalStyle[s] ?? 0.5;
    // per-concept preferences (propagated through the graph by dynamics.strengthen)
    const local = nodes.map((n) => n.stylePrefs[s]).filter((x): x is number => typeof x === "number");
    if (local.length) v = v * 0.5 + (local.reduce((a, b) => a + b, 0) / local.length) * 0.5;
    score.set(s, v);
  }
  // affect-conditioned priors
  if (affect.confusion > 0.45) (score.set("analogy", score.get("analogy")! + 0.15), score.set("stepwise", score.get("stepwise")! + 0.15), score.set("formal", score.get("formal")! - 0.2));
  if (affect.curiosity > 0.5) score.set("socratic", score.get("socratic")! + 0.1);
  if (affect.fatigue > 0.45) (score.set("example", score.get("example")! + 0.1), score.set("socratic", score.get("socratic")! - 0.2));
  if (affect.frustration > 0.45) (score.set("socratic", score.get("socratic")! - 0.3), score.set("stepwise", score.get("stepwise")! + 0.1));
  // if last style produced confusion, explore a different one (small epsilon-greedy)
  if (lastStyle && turn && (turn.confusion > 0.5 || turn.correction)) score.set(lastStyle as Style, (score.get(lastStyle as Style) ?? 0.5) - 0.25);
  const ranked = [...score.entries()].sort((a, b) => b[1] - a[1]);
  return Math.random() < 0.1 && ranked[1] ? ranked[1][0] : ranked[0][0];
}

export async function derivePolicy(
  conceptIds: string[],
  learner: LearnerState,
  turn: TurnSignals,
  extras: { reactivated: string[]; lastStyle?: string; offline: boolean },
): Promise<Policy> {
  const nodes = await getNodes(conceptIds);
  // persistent (EMA) affect blended with this turn's raw signal so sharp cues act immediately
  const affect: Affect = {
    confusion: learner.affect.confusion * 0.6 + turn.confusion * 0.4,
    curiosity: learner.affect.curiosity * 0.6 + turn.curiosity * 0.4,
    fatigue: learner.affect.fatigue * 0.6 + turn.fatigue * 0.4,
    frustration: learner.affect.frustration * 0.6 + turn.frustration * 0.4,
    confidence: learner.affect.confidence * 0.6 + turn.confidence * 0.4,
  };
  const mastery = nodes.length ? nodes.reduce((a, n) => a + n.mastery, 0) / nodes.length : 0.2;

  // depth: learner preference, pulled up by mastery and curiosity, down by confusion/fatigue
  let depth = learner.preferences.depth * 0.6 + mastery * 0.3 + affect.curiosity * 0.1;
  depth -= affect.confusion * 0.25 + affect.fatigue * 0.15;
  if (turn.wantsMore) depth += 0.2;
  if (turn.wantsLess) depth -= 0.25;

  let verbosity = learner.preferences.verbosity;
  verbosity -= affect.fatigue * 0.3 + affect.frustration * 0.15;
  if (turn.followUp) verbosity -= 0.15; // short question -> short answer
  if (turn.wantsMore) verbosity += 0.15;
  if (turn.wantsLess) verbosity -= 0.25;

  const dom = dominantAffect(affect);
  const tone: Policy["tone"] =
    dom === "confusion" ? "patient" : dom === "frustration" ? "reassuring" : dom === "curiosity" ? "energising" : dom === "fatigue" ? "concise" : "neutral";

  // prerequisite scaffolding: weak incoming prerequisite_of neighbours
  const scaffold: Policy["scaffold"] = [];
  const nextPaths: Policy["nextPaths"] = [];
  const seen = new Set(conceptIds);
  for (const id of conceptIds) {
    for (const { node, edge, direction } of await getNeighbors(id)) {
      if (seen.has(node.id)) continue;
      seen.add(node.id);
      if (edge.relation === "prerequisite_of" && direction === "in" && node.mastery < 0.45) scaffold.push({ id: node.id, label: node.label, mastery: node.mastery });
      // successors / related, ranked by prior success (weight*confidence) and unfamiliarity
      const isSuccessor = edge.relation === "prerequisite_of" && direction === "out";
      const gain = (1 - node.mastery) * edge.confidenceScore * (0.5 + edge.weight);
      if ((isSuccessor && mastery > 0.35) || (edge.relation !== "prerequisite_of" && gain > 0.3))
        nextPaths.push({ id: node.id, label: node.label, reason: isSuccessor ? "builds on current concept" : node.dormant ? "dormant branch, worth revisiting" : "related, previously useful" });
    }
  }
  scaffold.sort((a, b) => a.mastery - b.mastery);
  if (affect.fatigue > 0.5) nextPaths.length = Math.min(nextPaths.length, 1);

  return {
    depth: clamp01(depth),
    verbosity: clamp01(verbosity),
    style: pickStyle(learner.preferences.style, nodes, affect, extras.lastStyle, turn),
    tone,
    mastery,
    scaffold: scaffold.slice(0, 2),
    nextPaths: nextPaths.slice(0, 3),
    reactivated: extras.reactivated,
    affect: dom,
    offline: extras.offline,
  };
}

/** Turn policy into concrete instructions for the generator. */
export function policyToInstructions(p: Policy, concepts: GraphNode[]): string {
  const depthWords = p.depth < 0.33 ? "intuition-first, no jargon, no formalism" : p.depth < 0.66 ? "balanced: intuition, then one precise statement" : "rigorous: definitions, mechanics, edge cases; assume comfort with formal notation";
  const lenWords = p.verbosity < 0.33 ? "2-4 sentences max" : p.verbosity < 0.66 ? "one short paragraph, optionally a 3-item list" : "thorough, multiple short sections";
  const styleWords: Record<Style, string> = {
    analogy: "lead with a concrete real-world analogy, then map it back precisely",
    example: "lead with a worked example, then generalise",
    formal: "lead with the precise definition, then illustrate",
    stepwise: "numbered steps, one idea per step",
    visual: "describe a mental picture / diagram in words",
    socratic: "briefly explain, then end with ONE guiding question that moves the learner forward",
  };
  const toneWords: Record<Policy["tone"], string> = {
    patient: "learner seems confused: slow down, re-anchor to what they already know, avoid introducing new terms",
    reassuring: "learner seems frustrated: acknowledge briefly, be direct, no hedging, no quizzes",
    energising: "learner is curious: match their energy, offer one intriguing connection",
    concise: "learner seems fatigued: be brief, no tangents, no follow-up questions",
    neutral: "",
  };
  const lines = [
    `Depth: ${depthWords}.`,
    `Length: ${lenWords}.`,
    `Style: ${styleWords[p.style]}.`,
    toneWords[p.tone] ? `Tone: ${toneWords[p.tone]}.` : "",
    concepts.length ? `Target concepts (mastery): ${concepts.map((c) => `${c.label} (${Math.round(c.mastery * 100)}%)`).join(", ")}.` : "",
    p.scaffold.length ? `Weak prerequisites to briefly reinforce first: ${p.scaffold.map((s) => s.label).join(", ")}.` : "",
    p.reactivated.length ? `The learner is returning to a dormant topic (${p.reactivated.join(", ")}): briefly reconnect to it, don't restart from zero.` : "",
    p.nextPaths.length && p.tone !== "concise" ? `If natural, end with one optional pointer toward: ${p.nextPaths[0].label}.` : "",
  ];
  return lines.filter(Boolean).join("\n");
}
