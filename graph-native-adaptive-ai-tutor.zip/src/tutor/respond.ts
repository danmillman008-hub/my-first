import { db } from "@/db";
import { graphNodes, interactions, learnerState, type GraphNode } from "@/db/schema";
import { decayIfDue, ensureLearner, strengthen } from "@/graph/dynamics";
import { getNeighbors, getNodes } from "@/graph/store";
import { and, desc, eq, sql } from "drizzle-orm";
import { analyzeTurn, blendAffect, type TurnSignals } from "./affect";
import { extractConcepts } from "./extract";
import { complete, llmProvider, type ChatMsg } from "./llm";
import { derivePolicy, policyToInstructions, updatePreferences, type Policy } from "./policy";

export type TurnResult = {
  reply: string;
  concepts: { id: string; label: string; mastery: number; weight: number }[];
  policy: Policy;
  signals: TurnSignals;
  offline: boolean;
};

async function recentHistory(sessionId: string, n = 12) {
  const rows = await db.select().from(interactions).where(eq(interactions.sessionId, sessionId)).orderBy(desc(interactions.createdAt)).limit(n);
  return rows.reverse();
}

/** Graph-only fallback generator used when no LLM key is configured. */
async function offlineReply(message: string, concepts: GraphNode[], policy: Policy): Promise<string> {
  if (concepts.length === 0) {
    return "I don't have a model of that concept yet. Tell me what you're trying to understand (a topic name helps) and I'll start building your map around it.";
  }
  const c = concepts[0];
  const nbrs = await getNeighbors(c.id);
  const related = nbrs.filter((n) => n.edge.relation !== "prerequisite_of").slice(0, 3).map((n) => n.node.label);
  const prereqs = nbrs.filter((n) => n.edge.relation === "prerequisite_of" && n.direction === "in").map((n) => n.node.label);
  const parts: string[] = [];
  parts.push(
    policy.tone === "patient"
      ? `Let's slow down on **${c.label}**.`
      : policy.tone === "energising"
        ? `Good question — **${c.label}** is a rich one.`
        : `On **${c.label}**:`,
  );
  parts.push(c.summary ?? `I've seen you touch this ${c.touches} time(s); my estimate of your mastery is ${Math.round(c.mastery * 100)}%.`);
  if (policy.scaffold.length) parts.push(`Before going deeper, it helps to be solid on ${policy.scaffold.map((s) => s.label).join(" and ")}.`);
  else if (prereqs.length && policy.depth > 0.5) parts.push(`This builds on ${prereqs.join(", ")}.`);
  if (policy.verbosity > 0.4 && related.length) parts.push(`It connects to ${related.join(", ")}.`);
  if (policy.reactivated.length) parts.push(`(Welcome back to this branch — it had gone quiet.)`);
  if (policy.style === "socratic" && policy.tone !== "concise") parts.push(`What do you already know about ${c.label} that we can build from?`);
  parts.push(`_No LLM key configured (set ANTHROPIC_API_KEY or OPENAI_API_KEY) — this reply is composed from graph state only: depth ${policy.depth.toFixed(2)}, style ${policy.style}, tone ${policy.tone}._`);
  return parts.join(" ");
}

export async function runTurn(sessionId: string, message: string): Promise<TurnResult> {
  await decayIfDue();
  const learner = await ensureLearner();
  const history = await recentHistory(sessionId);

  // 1) affect signals from this turn
  const signals = analyzeTurn(message, history);

  // 2) concepts -> graph
  const lastUser = [...history].reverse().find((h) => h.role === "user");
  const lastAssistant = [...history].reverse().find((h) => h.role === "assistant");
  const recentConceptIds = lastUser?.concepts ?? [];
  const extraction = await extractConcepts(message, recentConceptIds);
  const conceptIds = extraction.concepts;
  // a follow-up only counts as a follow-up if it stays on topic
  if (signals.followUp && extraction.isNewTopic) signals.followUp = 0;

  // 3) learner model update (affect EMA + preferences with style credit assignment)
  const lastStyle = (lastAssistant?.policy as Policy | undefined)?.style;
  const affect = blendAffect(learner.affect, signals);
  const preferences = updatePreferences(learner.preferences, signals, lastStyle);
  await db.update(learnerState).set({ affect, preferences, updatedAt: new Date() }).where(eq(learnerState.id, "default"));
  const updatedLearner = { ...learner, affect, preferences };

  // 4) credit assignment onto the previous turn's concepts, then strengthen current ones
  const outcome = signals.understood ? 0.6 : signals.correction || signals.confusion > 0.5 ? -0.4 : signals.curiosity > 0.5 ? 0.3 : 0.1;
  if (recentConceptIds.length && lastStyle) await strengthen(recentConceptIds, { success: outcome, styleUsed: lastStyle, propagate: 0.2 });
  const { reactivated } = await strengthen(conceptIds, { success: 0, propagate: 0.35 });

  // 5) policy from graph state
  const offline = llmProvider() === null;
  const policy = await derivePolicy(conceptIds, updatedLearner, signals, { reactivated, lastStyle, offline });
  const concepts = await getNodes(conceptIds);

  // 6) generate
  let reply: string | null = null;
  if (!offline) {
    const system = `You are a private adaptive tutor. You adapt to a learner model derived from a knowledge graph of their past interactions. Follow the policy exactly; never mention the policy, mastery numbers, or that you are adapting. Never quiz unless the style says socratic (then exactly one question). Use markdown sparingly.\n\nPOLICY\n${policyToInstructions(policy, concepts)}`;
    const msgs: ChatMsg[] = [...history.slice(-8).map((h) => ({ role: h.role as "user" | "assistant", content: h.content })), { role: "user", content: message }];
    reply = await complete(system, msgs, { maxTokens: policy.verbosity < 0.33 ? 250 : policy.verbosity < 0.66 ? 550 : 1000 });
  }
  if (!reply) reply = await offlineReply(message, concepts, policy);

  // 7) record
  await db.insert(interactions).values([
    { sessionId, role: "user", content: message, concepts: conceptIds, signals: signals as unknown as Record<string, number>, policy: {} },
    { sessionId, role: "assistant", content: reply, concepts: conceptIds, signals: {}, policy: policy as unknown as Record<string, unknown> },
  ]);

  return {
    reply,
    concepts: concepts.map((c) => ({ id: c.id, label: c.label, mastery: c.mastery, weight: c.weight })),
    policy,
    signals,
    offline,
  };
}

/** Explicit feedback on the last assistant message (optional thumbs). */
export async function recordFeedback(sessionId: string, value: -1 | 1): Promise<void> {
  const [last] = await db
    .select()
    .from(interactions)
    .where(and(eq(interactions.sessionId, sessionId), eq(interactions.role, "assistant")))
    .orderBy(desc(interactions.createdAt))
    .limit(1);
  if (!last) return;
  await db.update(interactions).set({ feedback: value }).where(eq(interactions.id, last.id));
  const style = (last.policy as Policy | undefined)?.style;
  await strengthen(last.concepts, { success: value * 0.5, styleUsed: style, propagate: 0.2 });
  const learner = await ensureLearner();
  if (style) {
    const s = { ...learner.preferences.style };
    s[style] = Math.max(0, Math.min(1, (s[style] ?? 0.5) + value * 0.1));
    await db.update(learnerState).set({ preferences: { ...learner.preferences, style: s } }).where(eq(learnerState.id, "default"));
  }
}

/** Compact summary for the tiny UI panel and the MCP `learner://state` resource. */
export async function learnerSummary() {
  const learner = await ensureLearner();
  const [counts] = await db
    .select({
      nodes: sql<number>`count(*)::int`,
      dormant: sql<number>`count(*) filter (where ${graphNodes.dormant})::int`,
    })
    .from(graphNodes);
  const active = await db.select().from(graphNodes).where(eq(graphNodes.dormant, false)).orderBy(desc(graphNodes.weight)).limit(6);
  const dormant = await db.select().from(graphNodes).where(eq(graphNodes.dormant, true)).orderBy(desc(graphNodes.mastery)).limit(4);
  const topStyle = Object.entries(learner.preferences.style).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "unlearned";
  return {
    provider: llmProvider() ?? "offline",
    nodes: counts?.nodes ?? 0,
    dormantCount: counts?.dormant ?? 0,
    affect: learner.affect,
    preferences: { depth: learner.preferences.depth, verbosity: learner.preferences.verbosity, topStyle, style: learner.preferences.style },
    active: active.map((n) => ({ id: n.id, label: n.label, weight: n.weight, mastery: n.mastery })),
    dormant: dormant.map((n) => ({ id: n.id, label: n.label, mastery: n.mastery })),
  };
}
