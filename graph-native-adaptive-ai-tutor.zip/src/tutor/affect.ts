import type { Interaction } from "@/db/schema";

/**
 * Lightweight affect model. Not emotion recognition — a signal layer built from
 * lexical cues + interaction shape (follow-ups, corrections, message length).
 * Output is a per-turn signal vector; the learner's affect vector is an EMA of it.
 */

export type Affect = { confusion: number; curiosity: number; fatigue: number; frustration: number; confidence: number };

export type TurnSignals = Affect & {
  followUp: number; // 0/1: message continues the previous topic with a short question
  correction: number; // 0/1: user is correcting the tutor
  msgLength: number; // words
  wantsMore: number; // 0/1: asks for more detail / deeper
  wantsLess: number; // 0/1: asks for simpler / shorter
  understood: number; // 0/1: signals comprehension
};

const CONFUSION = /\b(confus|don'?t (get|understand|follow)|lost|what do you mean|huh|unclear|not sure i|makes no sense|still don'?t|\?\?+)/i;
const CURIOSITY = /\b(interesting|cool|wow|fascinating|curious|what about|what if|why does|how come|tell me more|love this|neat)\b/i;
const FATIGUE = /\b(tired|bored|boring|enough|too long|tl;?dr|later|skip|move on|whatever|meh|ok\.?$)/i;
const FRUSTRATION = /\b(ugh|annoying|frustrat|again\?|you already|wrong|that'?s not|no,? (i|that)|stop|useless|argh)/i;
const CONFIDENT = /\b(got it|makes sense|i see|understood|clear now|ah+|right,? so|so basically|that means)\b/i;
const CORRECTION = /\b(actually|no,|that'?s (wrong|incorrect|not right)|you said|i meant|not what i asked|correction)\b/i;
const MORE = /\b(more detail|deeper|elaborate|expand|go on|in depth|why exactly|prove|derive|show me the math|rigorous)\b/i;
const LESS = /\b(simpler|simplify|shorter|eli5|like i'?m (5|five)|briefly|in short|summar|too much|plain english|tldr)\b/i;
const HEDGE = /\b(i think|maybe|probably|kind of|sort of|i guess|not sure|might be)\b/i;

function hit(re: RegExp, text: string) {
  return re.test(text) ? 1 : 0;
}

export function analyzeTurn(message: string, recent: Interaction[]): TurnSignals {
  const text = message.trim();
  const words = text.split(/\s+/).filter(Boolean).length;
  const qMarks = (text.match(/\?/g) ?? []).length;
  const lastUser = [...recent].reverse().find((i) => i.role === "user");
  const lastAssistant = [...recent].reverse().find((i) => i.role === "assistant");

  const correction = hit(CORRECTION, text);
  const shortQuestion = words <= 12 && qMarks > 0 ? 1 : 0;
  // follow-up: short question right after an assistant answer (topic continuity is resolved later by concept overlap)
  const followUp = lastAssistant && shortQuestion ? 1 : 0;
  // repeated follow-ups in a row raise confusion
  const recentUserMsgs = recent.filter((i) => i.role === "user").slice(-4);
  const streak = recentUserMsgs.filter((i) => (i.signals?.followUp ?? 0) > 0).length;

  const confusion = Math.min(1, 0.7 * hit(CONFUSION, text) + 0.25 * followUp + 0.15 * streak + 0.2 * hit(HEDGE, text) + (qMarks >= 2 ? 0.15 : 0));
  const curiosity = Math.min(1, 0.7 * hit(CURIOSITY, text) + (words > 25 && qMarks > 0 ? 0.2 : 0) + 0.15 * hit(MORE, text));
  const fatigue = Math.min(1, 0.7 * hit(FATIGUE, text) + (words <= 3 && qMarks === 0 ? 0.3 : 0) + 0.3 * hit(LESS, text));
  const frustration = Math.min(1, 0.7 * hit(FRUSTRATION, text) + 0.4 * correction + (lastUser && lastUser.content.trim().toLowerCase() === text.toLowerCase() ? 0.5 : 0));
  const confidence = Math.min(1, 0.8 * hit(CONFIDENT, text) + (words > 20 && qMarks === 0 && !CONFUSION.test(text) ? 0.2 : 0));

  return {
    confusion,
    curiosity,
    fatigue,
    frustration,
    confidence,
    followUp,
    correction,
    msgLength: words,
    wantsMore: hit(MORE, text),
    wantsLess: hit(LESS, text),
    understood: hit(CONFIDENT, text),
  };
}

/** Exponential moving average of the learner affect vector. */
export function blendAffect(prev: Affect, turn: TurnSignals, alpha = 0.35): Affect {
  const k: (keyof Affect)[] = ["confusion", "curiosity", "fatigue", "frustration", "confidence"];
  const out = { ...prev };
  for (const key of k) out[key] = Math.round((prev[key] * (1 - alpha) + turn[key] * alpha) * 1000) / 1000;
  return out;
}

export function dominantAffect(a: Affect): keyof Affect | "neutral" {
  const entries = (Object.entries(a) as [keyof Affect, number][]).sort((x, y) => y[1] - x[1]);
  return entries[0][1] >= 0.4 ? entries[0][0] : "neutral";
}
