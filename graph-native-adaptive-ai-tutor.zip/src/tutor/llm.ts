/**
 * Minimal LLM provider shim. Reads keys server-side only.
 *  - ANTHROPIC_API_KEY  -> Anthropic Messages API
 *  - OPENAI_API_KEY     -> OpenAI-compatible chat completions (OPENAI_BASE_URL optional)
 *  - neither            -> null (callers fall back to graph-only behaviour)
 */

export type ChatMsg = { role: "user" | "assistant"; content: string };

export function llmProvider(): "anthropic" | "openai" | null {
  if (process.env.ANTHROPIC_API_KEY) return "anthropic";
  if (process.env.OPENAI_API_KEY) return "openai";
  return null;
}

export async function complete(system: string, messages: ChatMsg[], opts: { maxTokens?: number; json?: boolean } = {}): Promise<string | null> {
  const provider = llmProvider();
  const maxTokens = opts.maxTokens ?? 700;
  try {
    if (provider === "anthropic") {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": process.env.ANTHROPIC_API_KEY!,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: process.env.ANTHROPIC_MODEL ?? "claude-sonnet-4-20250514",
          max_tokens: maxTokens,
          system,
          messages,
        }),
      });
      if (!res.ok) throw new Error(`anthropic ${res.status}`);
      const data = (await res.json()) as { content: { type: string; text?: string }[] };
      return data.content.map((c) => c.text ?? "").join("");
    }
    if (provider === "openai") {
      const base = (process.env.OPENAI_BASE_URL ?? "https://api.openai.com/v1").replace(/\/$/, "");
      const res = await fetch(`${base}/chat/completions`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL ?? "gpt-4o-mini",
          max_tokens: maxTokens,
          messages: [{ role: "system", content: system }, ...messages],
          ...(opts.json ? { response_format: { type: "json_object" } } : {}),
        }),
      });
      if (!res.ok) throw new Error(`openai ${res.status}`);
      const data = (await res.json()) as { choices: { message: { content: string } }[] };
      return data.choices[0]?.message?.content ?? "";
    }
  } catch (err) {
    console.error("[llm] provider error, falling back:", err);
  }
  return null;
}
