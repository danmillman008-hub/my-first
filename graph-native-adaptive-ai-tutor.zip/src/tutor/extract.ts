import { queryGraph, slugify, upsertEdge, upsertNode, type Relation } from "@/graph/store";
import { complete, llmProvider } from "./llm";

/**
 * Concept extraction from a user turn. Writes straight into the graph substrate.
 *  - With an LLM: concepts + prerequisite/related edges (confidence INFERRED, scored by the model).
 *  - Without: match against existing nodes (EXTRACTED, 1.0) + capitalised/technical
 *    noun-phrase heuristics (AMBIGUOUS, 0.4). Co-mentioned concepts get co_occurs edges.
 */

export type Extraction = {
  concepts: string[]; // node ids, primary first
  isNewTopic: boolean;
};

const STOP = new Set(
  "the a an and or but if then so of to in on at for with about from by as is are was were be been being do does did can could would should will what why how when where which who whom this that these those it its i me my you your we our they them their explain tell show give help please again more less like just really very also thing things stuff way".split(" "),
);

const FILLER_START = /^(?:what|how|why|can|could|do|does|is|are|an?|the|it|this|that|these|those|they|you|me|about|of)\s+/i;
const FILLER_END = /\s+(?:is|are|work|works|mean|means|in|for|again|please|really|actually)$/i;
const SENTIMENT = new Set("interesting cool wow nice great thanks thank okay ok yes no sure right hmm hm ah oh yeah yep nope please sorry back".split(" "));

function cleanPhrase(p: string): string {
  let s = p.trim().replace(/\s+/g, " ");
  for (let i = 0; i < 4; i++) s = s.replace(FILLER_START, "").replace(FILLER_END, "");
  return s.trim();
}

function heuristicPhrases(text: string): string[] {
  const out = new Set<string>();
  // "explain X", "what is X", "how does X work", "back to X"
  const m = text.match(
    /\b(?:explain|what (?:is|are)|what about|how (?:does|do)|define|understand|learn(?:ing)? about|teach me|back to|tell me about)\s+(?:the\s+|a\s+|an\s+)?([a-z][a-z0-9\- ]{2,40}?)(?:\?|\.|,|!|$| work| mean| in | again| please)/i,
  );
  if (m) {
    const p = cleanPhrase(m[1]);
    if (p.length >= 3 && !SENTIMENT.has(p.toLowerCase()) && !STOP.has(p.toLowerCase())) out.add(p);
  }
  // Capitalised multiword terms / acronyms (single capitalised words at sentence start are ignored)
  for (const hit of text.matchAll(/(^|[.!?]\s+|\s)([A-Z][a-zA-Z0-9]+(?:\s+[A-Z][a-zA-Z0-9]+){0,2}|[A-Z]{2,6})\b/g)) {
    const c = hit[2];
    const atSentenceStart = hit[1] !== " ";
    const isAcronym = /^[A-Z]{2,6}$/.test(c);
    const multiword = c.includes(" ");
    if (atSentenceStart && !isAcronym && !multiword) continue;
    if (!STOP.has(c.toLowerCase()) && !SENTIMENT.has(c.toLowerCase()) && c.length > 2) out.add(c);
  }
  // longer lowercase technical-looking tokens (fallback for single-noun questions)
  if (out.size === 0) {
    const toks = text.toLowerCase().split(/[^a-z0-9\-]+/).filter((t) => t.length > 5 && !STOP.has(t));
    toks.slice(0, 2).forEach((t) => out.add(t));
  }
  return [...out].map((s) => s.replace(/\s+/g, " ").trim()).filter((s) => s.length >= 3 && !STOP.has(s.toLowerCase())).slice(0, 4);
}

export async function extractConcepts(message: string, recentConceptIds: string[]): Promise<Extraction> {
  // 1) always: match against the existing graph (EXTRACTED)
  const existing = await queryGraph(message, 4);
  const found = new Map<string, { label: string; conf: "EXTRACTED" | "INFERRED" | "AMBIGUOUS"; score: number }>();
  for (const n of existing) {
    const t = message.toLowerCase();
    if (t.includes(n.label.toLowerCase())) found.set(n.id, { label: n.label, conf: "EXTRACTED", score: 1 });
  }

  type LlmEdge = { source: string; target: string; relation: Relation; confidence: number };
  let llmEdges: LlmEdge[] = [];
  let summaries: Record<string, string> = {};

  // 2) LLM extraction when available
  if (llmProvider()) {
    const raw = await complete(
      `Extract the learning concepts a tutor should model from the user's message. Return ONLY JSON:
{"concepts":[{"label":"short canonical name","summary":"one sentence","confidence":0-1}],
 "edges":[{"source":"label","target":"label","relation":"prerequisite_of|related_to|part_of","confidence":0-1}]}
Rules: 1-4 concepts, primary first. Use canonical textbook names. prerequisite_of means source must be understood before target. Do not invent concepts absent from the message unless they are a direct prerequisite. Recently discussed concept ids: ${recentConceptIds.join(", ") || "none"}.`,
      [{ role: "user", content: message }],
      { maxTokens: 400, json: true },
    );
    if (raw) {
      try {
        const j = JSON.parse(raw.replace(/^```json\s*|```$/g, "")) as {
          concepts?: { label: string; summary?: string; confidence?: number }[];
          edges?: { source: string; target: string; relation: string; confidence?: number }[];
        };
        for (const c of j.concepts ?? []) {
          if (!c.label) continue;
          const id = slugify(c.label);
          if (!found.has(id)) found.set(id, { label: c.label, conf: "INFERRED", score: c.confidence ?? 0.7 });
          if (c.summary) summaries[id] = c.summary;
        }
        llmEdges = (j.edges ?? [])
          .filter((e) => e.source && e.target && ["prerequisite_of", "related_to", "part_of"].includes(e.relation))
          .map((e) => ({ source: slugify(e.source), target: slugify(e.target), relation: e.relation as Relation, confidence: e.confidence ?? 0.6 }));
      } catch {
        /* ignore malformed output; heuristics below still run */
      }
    }
  }

  // 3) heuristic fallback (AMBIGUOUS) when nothing else surfaced
  if (found.size === 0) {
    for (const p of heuristicPhrases(message)) {
      const id = slugify(p);
      if (id) found.set(id, { label: p, conf: "AMBIGUOUS", score: 0.4 });
    }
  }

  // 4) persist nodes
  const ids: string[] = [];
  for (const [id, f] of found) {
    await upsertNode({ id, label: f.label, summary: summaries[id] ?? null });
    ids.push(id);
  }
  summaries = {};

  // 5) persist edges: model-proposed + co-occurrence among mentioned + continuity with previous turn
  for (const e of llmEdges) {
    if (!ids.includes(e.source) && !ids.includes(e.target)) continue;
    await upsertNode({ id: e.source, label: e.source.replace(/-/g, " ") });
    await upsertNode({ id: e.target, label: e.target.replace(/-/g, " ") });
    if (e.source !== e.target) await upsertEdge({ ...e, confidence: "INFERRED", confidenceScore: e.confidence, evidence: message.slice(0, 200) });
  }
  for (let i = 0; i < ids.length; i++)
    for (let j = i + 1; j < ids.length; j++)
      await upsertEdge({ source: ids[i], target: ids[j], relation: "co_occurs", confidence: "EXTRACTED", confidenceScore: 1, evidence: message.slice(0, 200) });
  const overlap = ids.some((id) => recentConceptIds.includes(id));
  if (!overlap && ids.length && recentConceptIds.length) {
    // conversational adjacency: weak related_to edge from last topic to new topic
    await upsertEdge({ source: recentConceptIds[0], target: ids[0], relation: "related_to", confidence: "AMBIGUOUS", confidenceScore: 0.3, evidence: "conversational adjacency" });
  }

  return { concepts: ids, isNewTopic: !overlap };
}
