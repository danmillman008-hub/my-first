import { McpServer, ResourceTemplate } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { decayIfDue, ensureLearner } from "@/graph/dynamics";
import { exportGraphJson, getNeighbors, getNode, getNodes, importGraphJson, queryGraph, shortestPath } from "@/graph/store";
import { analyzeTurn } from "@/tutor/affect";
import { llmProvider } from "@/tutor/llm";
import { derivePolicy, policyToInstructions } from "@/tutor/policy";
import { learnerSummary, recordFeedback, runTurn } from "@/tutor/respond";

/**
 * Thin MCP adapter. No domain logic lives here — every handler delegates to
 * the graph substrate (src/graph) or the tutor layer (src/tutor).
 * Tool names for graph reads match Graphify's MCP server (query_graph, get_node,
 * get_neighbors, shortest_path) so existing Graphify clients/skills keep working.
 */

const json = (v: unknown) => ({ content: [{ type: "text" as const, text: JSON.stringify(v, null, 2) }] });

export function createMcpServer(): McpServer {
  const server = new McpServer({ name: "graph-tutor", version: "0.1.0" });

  // ---- Graphify-compatible read tools --------------------------------------
  server.registerTool(
    "query_graph",
    {
      title: "Query graph",
      description: "Keyword search over concept nodes (label/summary). Returns nodes with adaptive fields (weight, mastery, dormant).",
      inputSchema: { query: z.string().min(1), limit: z.number().int().min(1).max(50).optional() },
      annotations: { readOnlyHint: true },
    },
    async ({ query, limit }) => json(await queryGraph(query, limit ?? 12)),
  );

  server.registerTool(
    "get_node",
    { title: "Get node", description: "Fetch a single concept node by id.", inputSchema: { id: z.string() }, annotations: { readOnlyHint: true } },
    async ({ id }) => {
      const n = await getNode(id);
      return n ? json(n) : { content: [{ type: "text", text: `node not found: ${id}` }], isError: true };
    },
  );

  server.registerTool(
    "get_neighbors",
    {
      title: "Get neighbors",
      description: "Edges + neighbouring nodes of a concept. Optionally filter by relation (prerequisite_of|related_to|part_of|co_occurs) and direction.",
      inputSchema: { id: z.string(), relation: z.string().optional(), direction: z.enum(["in", "out", "both"]).optional() },
      annotations: { readOnlyHint: true },
    },
    async ({ id, relation, direction }) => json(await getNeighbors(id, { relation, direction })),
  );

  server.registerTool(
    "shortest_path",
    { title: "Shortest path", description: "Unweighted shortest path between two concept ids.", inputSchema: { from: z.string(), to: z.string() }, annotations: { readOnlyHint: true } },
    async ({ from, to }) => json({ path: await shortestPath(from, to) }),
  );

  server.registerTool(
    "get_policy",
    {
      title: "Get response policy",
      description: "Derive the current adaptive response policy (depth, verbosity, style, tone, scaffolding, next paths) for a set of concept ids without recording an interaction.",
      inputSchema: { concept_ids: z.array(z.string()).min(1), message: z.string().optional() },
      annotations: { readOnlyHint: true },
    },
    async ({ concept_ids, message }) => {
      const learner = await ensureLearner();
      const turn = analyzeTurn(message ?? "", []);
      const policy = await derivePolicy(concept_ids, learner, turn, { reactivated: [], offline: llmProvider() === null });
      return json({ policy, instructions: policyToInstructions(policy, await getNodes(concept_ids)) });
    },
  );

  // ---- Safe mutations ------------------------------------------------------
  server.registerTool(
    "tutor_turn",
    {
      title: "Tutor turn",
      description: "Send a learner message through the adaptive tutor. Updates the graph (concepts, edges, weights, mastery, affect, preferences) and returns the reply plus the policy that produced it.",
      inputSchema: { message: z.string().min(1), session_id: z.string().optional() },
      annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false },
    },
    async ({ message, session_id }) => json(await runTurn(session_id ?? "mcp", message)),
  );

  server.registerTool(
    "record_feedback",
    {
      title: "Record feedback",
      description: "Attach explicit +1/-1 feedback to the last assistant turn of a session; reinforces or weakens the concepts and style used.",
      inputSchema: { session_id: z.string(), value: z.union([z.literal(1), z.literal(-1)]) },
      annotations: { destructiveHint: false },
    },
    async ({ session_id, value }) => {
      await recordFeedback(session_id, value);
      return json({ ok: true });
    },
  );

  server.registerTool(
    "decay_graph",
    { title: "Run decay", description: "Force a decay pass: weights fade by idle time, weak branches become dormant.", inputSchema: {}, annotations: { destructiveHint: false, idempotentHint: true } },
    async () => json(await decayIfDue(true)),
  );

  server.registerTool(
    "import_graph_json",
    {
      title: "Import graph.json",
      description: "Merge a Graphify-format graph.json ({nodes, edges}) into the learner graph. Existing adaptive fields are preserved.",
      inputSchema: { graph: z.object({ nodes: z.array(z.any()).optional(), edges: z.array(z.any()).optional() }) },
      annotations: { destructiveHint: false },
    },
    async ({ graph }) => json(await importGraphJson(graph)),
  );

  // ---- Read-only resources -------------------------------------------------
  server.registerResource(
    "graph",
    "graph://graph.json",
    { title: "Learner graph (graph.json)", description: "Full graph export in Graphify graph.json shape.", mimeType: "application/json" },
    async (uri) => ({ contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify(await exportGraphJson()) }] }),
  );

  server.registerResource(
    "learner-state",
    "learner://state",
    { title: "Learner state", description: "Affect vector, preferences, active and dormant branches.", mimeType: "application/json" },
    async (uri) => ({ contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify(await learnerSummary()) }] }),
  );

  server.registerResource(
    "node",
    new ResourceTemplate("graph://node/{id}", { list: undefined }),
    { title: "Concept node", description: "A single concept node with its edges.", mimeType: "application/json" },
    async (uri, { id }) => {
      const nodeId = String(id);
      const node = await getNode(nodeId);
      const neighbors = node ? await getNeighbors(nodeId) : [];
      return { contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify({ node, neighbors }) }] };
    },
  );

  // ---- Prompt ----------------------------------------------------------------
  server.registerPrompt(
    "explain",
    {
      title: "Explain with learner policy",
      description: "Builds a tutor prompt for a concept, conditioned on the learner's current graph-derived policy.",
      argsSchema: { concept: z.string() },
    },
    async ({ concept }) => {
      const matches = await queryGraph(concept, 3);
      const ids = matches.map((m) => m.id);
      const learner = await ensureLearner();
      const policy = await derivePolicy(ids, learner, analyzeTurn(concept, []), { reactivated: [], offline: llmProvider() === null });
      const instructions = policyToInstructions(policy, matches);
      return {
        messages: [
          { role: "user", content: { type: "text", text: `You are a private adaptive tutor. Follow this policy exactly and never mention it:\n${instructions}\n\nExplain: ${concept}` } },
        ],
      };
    },
  );

  return server;
}
