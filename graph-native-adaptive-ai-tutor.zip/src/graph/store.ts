import { db } from "@/db";
import { graphEdges, graphNodes, type GraphEdge, type GraphNode } from "@/db/schema";
import { and, eq, ilike, inArray, or, sql } from "drizzle-orm";

/**
 * Graph substrate — Graphify-compatible node/edge model with the same
 * query/traversal primitives Graphify's MCP server exposes
 * (query_graph, get_node, get_neighbors, shortest_path) plus graph.json I/O.
 * Nothing in here knows about tutoring, affect, or policy.
 */

export type Confidence = "EXTRACTED" | "INFERRED" | "AMBIGUOUS";
export type Relation = "prerequisite_of" | "related_to" | "part_of" | "co_occurs";

export function slugify(label: string): string {
  return label
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export async function getNode(id: string): Promise<GraphNode | null> {
  const [n] = await db.select().from(graphNodes).where(eq(graphNodes.id, id)).limit(1);
  return n ?? null;
}

export async function getNodes(ids: string[]): Promise<GraphNode[]> {
  if (ids.length === 0) return [];
  return db.select().from(graphNodes).where(inArray(graphNodes.id, ids));
}

export async function allNodes(): Promise<GraphNode[]> {
  return db.select().from(graphNodes);
}

export async function allEdges(): Promise<GraphEdge[]> {
  return db.select().from(graphEdges);
}

export async function upsertNode(input: {
  id?: string;
  label: string;
  type?: string;
  summary?: string | null;
  sourceFile?: string | null;
  community?: number | null;
}): Promise<GraphNode> {
  const id = input.id ?? slugify(input.label);
  const [n] = await db
    .insert(graphNodes)
    .values({
      id,
      label: input.label,
      type: input.type ?? "concept",
      summary: input.summary ?? null,
      sourceFile: input.sourceFile ?? null,
      community: input.community ?? null,
    })
    .onConflictDoUpdate({
      target: graphNodes.id,
      set: {
        label: sql`coalesce(excluded.label, ${graphNodes.label})`,
        summary: sql`coalesce(excluded.summary, ${graphNodes.summary})`,
      },
    })
    .returning();
  return n;
}

export async function upsertEdge(input: {
  source: string;
  target: string;
  relation: Relation | string;
  confidence?: Confidence;
  confidenceScore?: number;
  evidence?: string | null;
}): Promise<GraphEdge> {
  if (input.source === input.target) throw new Error("self-edge");
  const [e] = await db
    .insert(graphEdges)
    .values({
      source: input.source,
      target: input.target,
      relation: input.relation,
      confidence: input.confidence ?? "INFERRED",
      confidenceScore: input.confidenceScore ?? (input.confidence === "EXTRACTED" ? 1 : 0.5),
      evidence: input.evidence ?? null,
    })
    .onConflictDoUpdate({
      target: [graphEdges.source, graphEdges.target, graphEdges.relation],
      set: {
        // keep the strongest evidence we've seen
        confidenceScore: sql`greatest(${graphEdges.confidenceScore}, excluded.confidence_score)`,
        evidence: sql`coalesce(excluded.evidence, ${graphEdges.evidence})`,
        lastTouchedAt: sql`now()`,
      },
    })
    .returning();
  return e;
}

/** Keyword query over labels/summaries (Graphify's query_graph is keyword-based too). */
export async function queryGraph(query: string, limit = 12): Promise<GraphNode[]> {
  const terms = query
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((t) => t.length > 2)
    .slice(0, 8);
  if (terms.length === 0) return [];
  const rows = await db
    .select()
    .from(graphNodes)
    .where(or(...terms.flatMap((t) => [ilike(graphNodes.label, `%${t}%`), ilike(graphNodes.summary, `%${t}%`)])))
    .limit(200);
  // score: term hits in label weigh more than in summary; tie-break by weight
  const scored = rows.map((n) => {
    const label = n.label.toLowerCase();
    const summary = (n.summary ?? "").toLowerCase();
    let s = 0;
    for (const t of terms) {
      if (label === t) s += 5;
      else if (label.includes(t)) s += 2;
      if (summary.includes(t)) s += 0.5;
    }
    return { n, s: s + n.weight * 0.5 };
  });
  return scored
    .sort((a, b) => b.s - a.s)
    .slice(0, limit)
    .map((x) => x.n);
}

export async function getNeighbors(
  id: string,
  opts: { relation?: string; direction?: "in" | "out" | "both" } = {},
): Promise<{ node: GraphNode; edge: GraphEdge; direction: "in" | "out" }[]> {
  const dir = opts.direction ?? "both";
  const conds = [];
  if (dir === "out" || dir === "both") conds.push(eq(graphEdges.source, id));
  if (dir === "in" || dir === "both") conds.push(eq(graphEdges.target, id));
  let where = or(...conds);
  if (opts.relation) where = and(where, eq(graphEdges.relation, opts.relation));
  const edges = await db.select().from(graphEdges).where(where);
  const otherIds = edges.map((e) => (e.source === id ? e.target : e.source));
  const nodes = await getNodes([...new Set(otherIds)]);
  const byId = new Map(nodes.map((n) => [n.id, n]));
  return edges
    .map((edge) => {
      const direction: "in" | "out" = edge.source === id ? "out" : "in";
      const node = byId.get(direction === "out" ? edge.target : edge.source);
      return node ? { node, edge, direction } : null;
    })
    .filter((x): x is { node: GraphNode; edge: GraphEdge; direction: "in" | "out" } => x !== null);
}

/** Unweighted BFS shortest path (undirected), like Graphify's shortest_path. */
export async function shortestPath(from: string, to: string): Promise<string[] | null> {
  if (from === to) return [from];
  const edges = await allEdges();
  const adj = new Map<string, string[]>();
  for (const e of edges) {
    if (!adj.has(e.source)) adj.set(e.source, []);
    if (!adj.has(e.target)) adj.set(e.target, []);
    adj.get(e.source)!.push(e.target);
    adj.get(e.target)!.push(e.source);
  }
  const prev = new Map<string, string | null>([[from, null]]);
  const queue = [from];
  while (queue.length) {
    const cur = queue.shift()!;
    if (cur === to) break;
    for (const nx of adj.get(cur) ?? []) {
      if (!prev.has(nx)) {
        prev.set(nx, cur);
        queue.push(nx);
      }
    }
  }
  if (!prev.has(to)) return null;
  const path: string[] = [];
  for (let c: string | null = to; c !== null; c = prev.get(c) ?? null) path.unshift(c);
  return path;
}

/** Export in Graphify graph.json shape (adaptive fields go under `meta`). */
export async function exportGraphJson() {
  const [nodes, edges] = await Promise.all([allNodes(), allEdges()]);
  return {
    nodes: nodes.map((n) => ({
      id: n.id,
      label: n.label,
      type: n.type,
      source_file: n.sourceFile,
      community: n.community,
      meta: {
        summary: n.summary,
        weight: n.weight,
        mastery: n.mastery,
        dormant: n.dormant,
        touches: n.touches,
        last_touched_at: n.lastTouchedAt,
        style_prefs: n.stylePrefs,
      },
    })),
    edges: edges.map((e) => ({
      source: e.source,
      target: e.target,
      relation: e.relation,
      confidence: e.confidence,
      confidence_score: e.confidenceScore,
      evidence: e.evidence,
      meta: { weight: e.weight, last_touched_at: e.lastTouchedAt },
    })),
  };
}

/** Import a Graphify graph.json (nodes/edges) into the substrate. */
export async function importGraphJson(json: {
  nodes?: { id: string; label?: string; type?: string; source_file?: string | null; community?: number | null }[];
  edges?: { source: string; target: string; relation?: string; confidence?: string; confidence_score?: number; evidence?: string | null }[];
}): Promise<{ nodes: number; edges: number }> {
  let nodes = 0;
  let edges = 0;
  for (const n of json.nodes ?? []) {
    await upsertNode({ id: n.id, label: n.label ?? n.id, type: n.type, sourceFile: n.source_file ?? null, community: n.community ?? null });
    nodes++;
  }
  for (const e of json.edges ?? []) {
    if (e.source === e.target) continue;
    await upsertEdge({
      source: e.source,
      target: e.target,
      relation: e.relation ?? "related_to",
      confidence: (e.confidence as Confidence) ?? "EXTRACTED",
      confidenceScore: e.confidence_score,
      evidence: e.evidence ?? null,
    });
    edges++;
  }
  return { nodes, edges };
}
