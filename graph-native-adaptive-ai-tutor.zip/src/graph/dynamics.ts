import { db } from "@/db";
import { graphEdges, graphNodes, learnerState } from "@/db/schema";
import { eq, inArray, sql } from "drizzle-orm";
import { getNeighbors } from "./store";

/**
 * Graph dynamics: the graph is not static.
 *  - strengthen(): touched nodes/edges gain weight; neighbours receive a
 *    damped share (preference propagation).
 *  - decay(): every node/edge loses weight as a function of elapsed time;
 *    weak branches are marked dormant. Dormant branches are reactivated the
 *    moment they are touched again (see strengthen), so nothing is ever lost.
 */

const HALF_LIFE_HOURS = 24 * 5; // weight halves after ~5 idle days
const DORMANT_BELOW = 0.12;
const MIN_WEIGHT = 0.02;

function clamp01(x: number) {
  return Math.max(0, Math.min(1, x));
}

export async function ensureLearner() {
  const [row] = await db.select().from(learnerState).where(eq(learnerState.id, "default")).limit(1);
  if (row) return row;
  const [created] = await db.insert(learnerState).values({ id: "default" }).returning();
  return created;
}

/** Time-based decay, applied at most once per hour (cheap, idempotent). */
export async function decayIfDue(force = false): Promise<{ applied: boolean; dormant: number }> {
  const learner = await ensureLearner();
  const hours = (Date.now() - new Date(learner.lastDecayAt).getTime()) / 36e5;
  if (!force && hours < 1) return { applied: false, dormant: 0 };
  // multiplicative decay per node based on its own idle time
  await db.execute(sql`
    update graph_nodes set
      weight = greatest(${MIN_WEIGHT}, weight * power(0.5, extract(epoch from (now() - last_touched_at)) / 3600.0 / ${HALF_LIFE_HOURS})),
      mastery = greatest(0, mastery - 0.002 * least(extract(epoch from (now() - last_touched_at)) / 86400.0, 30))
  `);
  await db.execute(sql`
    update graph_edges set
      weight = greatest(${MIN_WEIGHT}, weight * power(0.5, extract(epoch from (now() - last_touched_at)) / 3600.0 / ${HALF_LIFE_HOURS}))
  `);
  const res = await db
    .update(graphNodes)
    .set({ dormant: true })
    .where(sql`${graphNodes.weight} < ${DORMANT_BELOW} and ${graphNodes.dormant} = false`)
    .returning({ id: graphNodes.id });
  await db.update(learnerState).set({ lastDecayAt: new Date(), updatedAt: new Date() }).where(eq(learnerState.id, "default"));
  return { applied: true, dormant: res.length };
}

/**
 * Strengthen touched concepts and propagate a damped share to neighbours.
 * `success` in [-1, 1] nudges mastery (negative = user was confused/corrected).
 * `styleUsed` records which explanation style was applied so per-concept
 * style preference can be learned from outcomes.
 */
export async function strengthen(
  conceptIds: string[],
  opts: { success?: number; styleUsed?: string; propagate?: number } = {},
): Promise<{ reactivated: string[] }> {
  if (conceptIds.length === 0) return { reactivated: [] };
  const success = opts.success ?? 0;
  const propagate = opts.propagate ?? 0.35;
  const reactivated: string[] = [];

  const nodes = await db.select().from(graphNodes).where(inArray(graphNodes.id, conceptIds));
  for (const n of nodes) {
    if (n.dormant) reactivated.push(n.id);
    const prefs = { ...n.stylePrefs };
    if (opts.styleUsed) prefs[opts.styleUsed] = clamp01((prefs[opts.styleUsed] ?? 0.5) * 0.7 + (0.5 + success / 2) * 0.3);
    await db
      .update(graphNodes)
      .set({
        weight: clamp01(n.weight + 0.15 * (1 - n.weight)),
        mastery: clamp01(n.mastery + 0.08 * success * (success > 0 ? 1 - n.mastery : n.mastery + 0.2)),
        dormant: false,
        touches: n.touches + 1,
        lastTouchedAt: new Date(),
        stylePrefs: prefs,
      })
      .where(eq(graphNodes.id, n.id));
  }

  // edges among touched set get reinforced (co-activation)
  await db
    .update(graphEdges)
    .set({ weight: sql`least(1, ${graphEdges.weight} + 0.1)`, lastTouchedAt: new Date() })
    .where(sql`${graphEdges.source} in ${conceptIds} and ${graphEdges.target} in ${conceptIds}`);

  // one-hop propagation (damped) — preference/activation spreads to nearby concepts
  if (propagate > 0) {
    const touched = new Set(conceptIds);
    const share = new Map<string, number>();
    for (const id of conceptIds) {
      for (const { node, edge } of await getNeighbors(id)) {
        if (touched.has(node.id)) continue;
        share.set(node.id, Math.max(share.get(node.id) ?? 0, propagate * edge.confidenceScore * 0.15));
      }
    }
    for (const [id, delta] of share) {
      await db
        .update(graphNodes)
        .set({ weight: sql`least(1, ${graphNodes.weight} + ${delta})`, lastTouchedAt: new Date() })
        .where(eq(graphNodes.id, id));
    }
  }
  return { reactivated };
}
