import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/**
 * Graph substrate. Shape mirrors Graphify's graph.json:
 *   nodes: { id, label, type, source_file, community }
 *   edges: { source, target, relation, confidence, confidence_score, evidence }
 * The adaptive layer only adds a few numeric columns (weight/mastery/dormant)
 * so the same nodes/edges double as the personalized user model.
 */
export const graphNodes = pgTable("graph_nodes", {
  id: text("id").primaryKey(), // slug, e.g. "linear-algebra/eigenvalues"
  label: text("label").notNull(),
  type: text("type").notNull().default("concept"), // concept | subconcept | style | ...
  summary: text("summary"),
  sourceFile: text("source_file"),
  community: integer("community"),
  // --- adaptive layer ---
  weight: real("weight").notNull().default(0.5), // branch strength / activation, decays over time
  mastery: real("mastery").notNull().default(0.2), // 0..1 estimate
  dormant: boolean("dormant").notNull().default(false),
  touches: integer("touches").notNull().default(0),
  lastTouchedAt: timestamp("last_touched_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  // per-concept explanation preference signal: { analogy: 0.6, formal: 0.2, ... }
  stylePrefs: jsonb("style_prefs").$type<Record<string, number>>().notNull().default({}),
});

export const graphEdges = pgTable(
  "graph_edges",
  {
    id: serial("id").primaryKey(),
    source: text("source").notNull(),
    target: text("target").notNull(),
    relation: text("relation").notNull(), // prerequisite_of | related_to | part_of | co_occurs
    confidence: text("confidence").notNull().default("INFERRED"), // EXTRACTED | INFERRED | AMBIGUOUS
    confidenceScore: real("confidence_score").notNull().default(0.5),
    evidence: text("evidence"),
    weight: real("weight").notNull().default(0.5), // usage strength, decays
    lastTouchedAt: timestamp("last_touched_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("graph_edges_src_tgt_rel").on(t.source, t.target, t.relation),
    index("graph_edges_target_idx").on(t.target),
  ],
);

export const interactions = pgTable(
  "interactions",
  {
    id: serial("id").primaryKey(),
    sessionId: text("session_id").notNull(),
    role: text("role").notNull(), // user | assistant
    content: text("content").notNull(),
    concepts: jsonb("concepts").$type<string[]>().notNull().default([]),
    signals: jsonb("signals").$type<Record<string, number>>().notNull().default({}),
    policy: jsonb("policy").$type<Record<string, unknown>>().notNull().default({}),
    feedback: integer("feedback"), // -1 | 0 | 1 (explicit thumbs, optional)
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("interactions_session_idx").on(t.sessionId, t.createdAt)],
);

/** Single-user learner model. One row, id = "default". */
export const learnerState = pgTable("learner_state", {
  id: text("id").primaryKey(),
  // EMA-smoothed global preferences (per-concept overrides live on nodes.stylePrefs)
  preferences: jsonb("preferences")
    .$type<{ depth: number; verbosity: number; style: Record<string, number> }>()
    .notNull()
    .default({ depth: 0.5, verbosity: 0.5, style: {} }),
  // EMA-smoothed affect vector 0..1
  affect: jsonb("affect")
    .$type<{ confusion: number; curiosity: number; fatigue: number; frustration: number; confidence: number }>()
    .notNull()
    .default({ confusion: 0.2, curiosity: 0.5, fatigue: 0.1, frustration: 0.1, confidence: 0.5 }),
  lastDecayAt: timestamp("last_decay_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type GraphNode = typeof graphNodes.$inferSelect;
export type GraphEdge = typeof graphEdges.$inferSelect;
export type Interaction = typeof interactions.$inferSelect;
export type LearnerState = typeof learnerState.$inferSelect;
