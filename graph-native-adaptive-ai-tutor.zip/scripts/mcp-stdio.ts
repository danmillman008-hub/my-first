/**
 * MCP stdio transport entrypoint.
 *   npm run mcp:stdio
 * Client config example:
 *   { "mcpServers": { "graph-tutor": { "type": "stdio", "command": "npx", "args": ["tsx", "scripts/mcp-stdio.ts"], "cwd": "<repo>" } } }
 * Shares the same PostgreSQL graph as the web app (DATABASE_URL from .env).
 */
import "dotenv/config";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { createMcpServer } from "../src/mcp/server";

async function main() {
  const server = createMcpServer();
  const transport = new StdioServerTransport();
  await server.connect(transport);
  // keep stdout clean for JSON-RPC; log to stderr only
  console.error("[graph-tutor] MCP stdio server ready");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
