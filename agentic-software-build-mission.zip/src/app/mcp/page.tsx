import Link from "next/link";
import { headers } from "next/headers";

export const dynamic = "force-dynamic";

const TOOLS: [string, string][] = [
  ["get_learner_state", "Mastery, uncertainty, dormancy status, preferences, affect, recommendations"],
  ["get_concept_graph", "Concepts + typed edges (prerequisite / related / part_of)"],
  ["get_concept", "Explanations in every style, diagnostic questions, learner state on that concept"],
  ["get_recommendations", "Ranked next concepts with reasons"],
  ["record_evidence", "Push externally observed evidence (quiz result, confusion, confirmation) into the model"],
  ["tutor_turn", "Delegate a full adaptive tutoring turn to the core; returns reply + decision + rationale"],
  ["get_interaction_history", "Interaction log and policy decisions"],
  ["add_concept", "Extend the concept graph"],
];

export default async function McpPage() {
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  const proto = h.get("x-forwarded-proto") ?? "http";
  const url = `${proto}://${host}/api/mcp`;
  const curl = `curl -s ${url} \\
  -H 'content-type: application/json' -H 'accept: application/json, text/event-stream' \\
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"get_recommendations","arguments":{"learnerId":"default"}}}'`;
  return (
    <main className="mx-auto max-w-3xl p-6">
      <Link href="/" className="text-sm text-indigo-600">← back to tutor</Link>
      <h1 className="mt-2 text-2xl font-semibold text-slate-900">MCP access layer</h1>
      <p className="mt-2 text-sm text-slate-600">
        External assistants connect over <strong>MCP Streamable HTTP</strong> (spec 2025-06-18, stateless, JSON responses). The pedagogy stays in the core; MCP only exposes standardized tools.
      </p>
      <div className="mt-4 rounded-xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
        <div className="text-xs uppercase tracking-wide text-slate-500">Endpoint</div>
        <code className="text-sm">{url}</code>
        <p className="mt-2 text-xs text-slate-500">Set <code>MCP_ACCESS_TOKEN</code> to require <code>Authorization: Bearer …</code>.</p>
      </div>
      <h2 className="mt-6 text-lg font-semibold text-slate-900">Tools</h2>
      <ul className="mt-2 space-y-1.5 text-sm">
        {TOOLS.map(([n, d]) => (
          <li key={n} className="rounded-lg bg-white px-3 py-2 ring-1 ring-slate-200">
            <code className="font-semibold text-indigo-700">{n}</code> <span className="text-slate-600">— {d}</span>
          </li>
        ))}
      </ul>
      <h2 className="mt-6 text-lg font-semibold text-slate-900">Try it</h2>
      <pre className="mt-2 overflow-x-auto rounded-xl bg-slate-900 p-4 text-xs text-slate-100">{curl}</pre>
      <h2 className="mt-6 text-lg font-semibold text-slate-900">Claude Desktop / mcp-remote</h2>
      <pre className="mt-2 overflow-x-auto rounded-xl bg-slate-900 p-4 text-xs text-slate-100">{JSON.stringify({ mcpServers: { "adaptive-tutor": { command: "npx", args: ["-y", "mcp-remote", url] } } }, null, 2)}</pre>
    </main>
  );
}
