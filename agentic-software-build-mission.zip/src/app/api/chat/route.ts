import { handleMessage } from "@/lib/tutor/engine";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { learnerId?: string; sessionId?: string; message?: string; latencyMs?: number | null };
    const message = (body.message ?? "").trim();
    if (!message) return Response.json({ error: "message is required" }, { status: 400 });
    const learnerId = (body.learnerId ?? "default").slice(0, 64);
    const sessionId = (body.sessionId ?? `s-${learnerId}`).slice(0, 64);
    const result = await handleMessage({ learnerId, sessionId, text: message, latencyMs: body.latencyMs ?? null });
    return Response.json(result);
  } catch (e) {
    console.error(e);
    return Response.json({ error: e instanceof Error ? e.message : "internal error" }, { status: 500 });
  }
}
