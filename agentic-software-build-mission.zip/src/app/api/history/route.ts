import { recentDecisions, recentInteractions } from "@/lib/tutor/store";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const learnerId = (url.searchParams.get("learnerId") ?? "default").slice(0, 64);
  const sessionId = url.searchParams.get("sessionId") ?? undefined;
  const [interactions, decisions] = await Promise.all([recentInteractions(learnerId, 100, sessionId), recentDecisions(learnerId, 30)]);
  return Response.json({ interactions, decisions });
}
