import { getSnapshot } from "@/lib/tutor/engine";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const learnerId = (url.searchParams.get("learnerId") ?? "default").slice(0, 64);
  return Response.json(await getSnapshot(learnerId));
}
