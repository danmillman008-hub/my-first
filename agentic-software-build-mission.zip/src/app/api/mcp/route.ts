import { WebStandardStreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js";
import { createMcpServer } from "@/lib/mcp/server";

export const dynamic = "force-dynamic";

/**
 * MCP Streamable HTTP endpoint (spec 2025-06-18), stateless mode:
 * a fresh transport + server per request (required by the SDK to avoid JSON-RPC id collisions).
 * Optional bearer-token protection via MCP_ACCESS_TOKEN.
 */
export async function POST(req: Request) {
  const token = process.env.MCP_ACCESS_TOKEN;
  if (token) {
    const auth = req.headers.get("authorization") ?? "";
    if (auth !== `Bearer ${token}`) {
      return Response.json({ jsonrpc: "2.0", error: { code: -32001, message: "Unauthorized" }, id: null }, { status: 401 });
    }
  }
  const transport = new WebStandardStreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
  const server = createMcpServer();
  await server.connect(transport);
  try {
    return await transport.handleRequest(req);
  } finally {
    // close after the response has been produced
    void transport.close().catch(() => {});
  }
}

const notAllowed = () => Response.json({ jsonrpc: "2.0", error: { code: -32000, message: "Method not allowed (stateless server)" }, id: null }, { status: 405 });
export const GET = notAllowed;
export const DELETE = notAllowed;
