import { resetLearner } from "@/lib/tutor/store";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { learnerId?: string };
  const learnerId = (body.learnerId ?? "default").slice(0, 64);
  await resetLearner(learnerId);
  return Response.json({ ok: true });
}
