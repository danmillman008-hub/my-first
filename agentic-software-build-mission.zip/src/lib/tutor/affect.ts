import type { AffectVector } from "./types";

/**
 * Approximate affect model.
 *
 * We do not claim emotion detection. We accumulate *evidence* from
 *  - lexical cues in the learner's messages,
 *  - behavioural cues (answer correctness streaks, latency, repetition, session length),
 * into a smoothed vector, and let the policy react when the evidence is strong.
 *
 * Grounded in affective-computing-in-education findings that confusion / frustration /
 * boredom / engagement are the learning-relevant states (D'Mello & Graesser).
 */

export const NEUTRAL_AFFECT: AffectVector = {
  confusion: 0.1,
  frustration: 0.05,
  boredom: 0.05,
  engagement: 0.5,
  confidence: 0.4,
  fatigue: 0.05,
  excitement: 0.2,
};

const LEXICON: { re: RegExp; delta: Partial<AffectVector> }[] = [
  { re: /\b(confus|don'?t (get|understand|follow)|not sure|lost|huh|what\?|unclear|no idea|makes no sense)/i, delta: { confusion: 0.45, confidence: -0.2 } },
  { re: /\?\?+|\bwhat do you mean\b|\bwait\b/i, delta: { confusion: 0.25 } },
  { re: /\b(frustrat|annoy|ugh|argh|hate|stupid|give up|this sucks|useless|again\?!?)/i, delta: { frustration: 0.5, engagement: -0.15 } },
  { re: /!{2,}|[A-Z]{5,}/, delta: { frustration: 0.15, excitement: 0.1 } },
  { re: /\b(bor(ed|ing)|already know|too easy|obvious|yawn|trivial|skip)/i, delta: { boredom: 0.45, engagement: -0.15 } },
  { re: /\b(tired|exhaust|sleepy|long day|break|enough for today|brain is fried)/i, delta: { fatigue: 0.5, engagement: -0.1 } },
  { re: /\b(cool|awesome|interesting|love|nice|fascinating|wow|great)\b|:\)|😀|🙂|👍/i, delta: { excitement: 0.35, engagement: 0.2 } },
  { re: /\b(got it|makes sense|i see|understood|clear now|ah+|oh+ okay|that helps|thanks)\b/i, delta: { confidence: 0.25, confusion: -0.3, engagement: 0.1 } },
  { re: /\b(easy|i think|i know|sure|definitely|pretty sure)\b/i, delta: { confidence: 0.15 } },
  { re: /\b(why|how come|what if|could you also|tell me more)\b/i, delta: { engagement: 0.2, excitement: 0.1 } },
];

export function lexicalAffect(text: string): Partial<AffectVector> {
  const out: Partial<AffectVector> = {};
  for (const { re, delta } of LEXICON) {
    if (re.test(text)) {
      for (const [k, v] of Object.entries(delta)) {
        const key = k as keyof AffectVector;
        out[key] = (out[key] ?? 0) + (v as number);
      }
    }
  }
  // very short low-effort replies ("k", "ok", "idk") hint at disengagement / fatigue
  const trimmed = text.trim();
  if (/^(k|ok|okay|idk|meh|sure|fine|whatever)\.?$/i.test(trimmed)) {
    out.boredom = (out.boredom ?? 0) + 0.15;
    out.engagement = (out.engagement ?? 0) - 0.1;
  }
  return out;
}

export type BehaviourSignals = {
  answerCorrect?: boolean | null;
  incorrectStreak?: number;
  correctStreak?: number;
  latencyMs?: number | null;
  repeatedConcept?: boolean; // learner asked about the same concept again
  sessionTurns?: number;
  sessionMinutes?: number;
};

export function behaviouralAffect(b: BehaviourSignals): Partial<AffectVector> {
  const out: Partial<AffectVector> = {};
  const add = (k: keyof AffectVector, v: number) => (out[k] = (out[k] ?? 0) + v);
  if (b.answerCorrect === true) {
    add("confidence", 0.2);
    add("engagement", 0.1);
    if ((b.correctStreak ?? 0) >= 3) add("boredom", 0.2);
  } else if (b.answerCorrect === false) {
    add("confusion", 0.2);
    add("confidence", -0.15);
    if ((b.incorrectStreak ?? 0) >= 2) add("frustration", 0.3);
  }
  if (b.latencyMs != null) {
    if (b.latencyMs > 90_000) add("confusion", 0.1);
    if (b.latencyMs > 240_000) add("fatigue", 0.1);
    if (b.latencyMs < 4_000 && b.answerCorrect === false) add("frustration", 0.1); // rapid wrong guessing
  }
  if (b.repeatedConcept) {
    add("confusion", 0.15);
  }
  if ((b.sessionTurns ?? 0) > 25 || (b.sessionMinutes ?? 0) > 40) add("fatigue", 0.15);
  return out;
}

/** Exponential smoothing toward neutral plus evidence deltas. */
export function updateAffect(prev: AffectVector, ...deltas: Partial<AffectVector>[]): AffectVector {
  const decay = 0.75; // how much of the previous state carries over each turn
  const next = { ...prev };
  for (const k of Object.keys(NEUTRAL_AFFECT) as (keyof AffectVector)[]) {
    let v = NEUTRAL_AFFECT[k] + (prev[k] - NEUTRAL_AFFECT[k]) * decay;
    for (const d of deltas) v += d[k] ?? 0;
    next[k] = Math.max(0, Math.min(1, v));
  }
  return next;
}

export function dominantAffect(a: AffectVector): { key: keyof AffectVector; value: number } {
  let best: keyof AffectVector = "engagement";
  for (const k of Object.keys(a) as (keyof AffectVector)[]) {
    if (a[k] > a[best]) best = k;
  }
  return { key: best, value: a[best] };
}
