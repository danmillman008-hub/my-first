import { priorityMultiplier } from "./dormancy";
import { defaultConceptState, readiness, uncertainty } from "./mastery";
import { chooseStyle } from "./preferences";
import type { ConceptEdge, ConceptNode, ConceptState, LearnerModel, MessageAnalysis, PolicyDecision, Recommendation, Style } from "./types";

export type Graph = { concepts: Map<string, ConceptNode>; edges: ConceptEdge[] };

export type SessionContext = {
  currentConceptId: string | null; // the learner's current goal concept
  lastExplainedConceptId: string | null;
  lastExplainedStyle: Style | null;
  turnCount: number;
  breakSuggestedRecently: boolean;
  explainCountForConcept: number; // how many times we've explained the current concept this session
  graded: { conceptId: string; correct: boolean; wasPrereqCheck: boolean } | null;
};

/** "Observed weak" = low mastery backed by *direct negative* evidence (not merely a low prior or inferred evidence). */
export const observedWeak = (s: ConceptState, threshold = 0.45): boolean => s.pKnown < threshold && (s.incorrect > 0 || s.confusionEvents > 0 || (s.evidence > 0 && s.correct === 0 && s.pKnown < 0.25));

const stateOf = (model: LearnerModel, graph: Graph, id: string): ConceptState =>
  model.concepts.get(id) ?? defaultConceptState(id, graph.concepts.get(id)?.difficulty ?? 0.5);

/**
 * Recommend what to work on next.
 * Score = readiness × (1 − mastery) × ZPD fit × dormancy multiplier × recency/interest.
 */
export function recommendNext(model: LearnerModel, graph: Graph, opts: { exclude?: string[]; limit?: number } = {}): Recommendation[] {
  const out: Recommendation[] = [];
  const pace = model.pace;
  for (const c of graph.concepts.values()) {
    if (opts.exclude?.includes(c.id)) continue;
    const s = stateOf(model, graph, c.id);
    const r = readiness(c.id, graph.edges, (id) => stateOf(model, graph, id));
    const need = 1 - s.pKnown;
    if (need < 0.15) continue; // effectively mastered
    // ZPD: prefer concepts whose prerequisites are ready; faster pace tolerates lower readiness
    const readyFactor = Math.pow(r.score, 2.2 - pace);
    const unc = uncertainty(s); // exploring unknown concepts is informative
    const interest = 1 + Math.min(1, s.activation) * 0.4;
    const bored = model.affect.boredom > 0.5 ? 1 + c.difficulty * 0.6 : 1;
    const score = readyFactor * (0.6 * need + 0.4 * unc) * priorityMultiplier(s.status) * interest * bored;
    const reasons: string[] = [];
    if (r.weakest && r.weakest.pKnown < 0.5) reasons.push(`prerequisite "${graph.concepts.get(r.weakest.id)?.name}" still weak`);
    else if (r.score > 0.75) reasons.push("prerequisites are in good shape");
    if (s.evidence === 0) reasons.push("not yet explored");
    else if (s.pKnown < 0.5) reasons.push("mastery still low");
    if (s.status !== "active") reasons.push(`branch is ${s.status} (de-prioritised)`);
    if (s.activation > 0.8) reasons.push("recently active");
    out.push({ conceptId: c.id, name: c.name, reason: reasons.join("; ") || "next logical step", score, pKnown: s.pKnown, status: s.status });
  }
  out.sort((a, b) => b.score - a.score);
  return out.slice(0, opts.limit ?? 5);
}

function styleFor(model: LearnerModel, action: PolicyDecision["action"], ctx: SessionContext, rnd?: () => number): { style: Style; note: string } {
  const bias: Partial<Record<Style, number>> = {};
  const exclude: Style[] = [];
  const a = model.affect;
  switch (action) {
    case "simplify":
      bias.analogy = 0.2; bias.example = 0.2; bias.concise = 0.1; bias.formal = -0.4;
      if (ctx.lastExplainedStyle) exclude.push(ctx.lastExplainedStyle);
      break;
    case "deepen":
      bias.formal = 0.3; bias.detailed = 0.3; bias.concise = -0.3;
      break;
    case "give_example":
      return { style: "example", note: "example style forced by the request" };
    case "switch_strategy":
      if (ctx.lastExplainedStyle) exclude.push(ctx.lastExplainedStyle);
      bias.steps = 0.15; bias.example = 0.15; bias.analogy = 0.1;
      break;
    case "revisit_prerequisite":
      bias.steps = 0.1; bias.example = 0.1;
      break;
    default:
      break;
  }
  if (a.fatigue > 0.5) { bias.concise = (bias.concise ?? 0) + 0.25; bias.detailed = (bias.detailed ?? 0) - 0.2; }
  if (a.confusion > 0.5) { bias.example = (bias.example ?? 0) + 0.15; bias.steps = (bias.steps ?? 0) + 0.15; bias.formal = (bias.formal ?? 0) - 0.2; }
  if (a.engagement > 0.7 && a.confusion < 0.3) bias.detailed = (bias.detailed ?? 0) + 0.1;
  const { style } = chooseStyle(model.preferences, { exclude, bias, rnd });
  const arm = model.preferences.get(style);
  const note = arm && arm.trials > 0
    ? `style "${style}" chosen (posterior success ${(arm.alpha / (arm.alpha + arm.beta)).toFixed(2)} over ${arm.trials} trials)`
    : `style "${style}" chosen (exploring — little preference data yet)`;
  return { style, note };
}

export function decide(
  model: LearnerModel,
  graph: Graph,
  analysis: MessageAnalysis,
  ctx: SessionContext,
  rnd?: () => number,
): PolicyDecision {
  const a = model.affect;
  const rationale: string[] = [];
  const st = (id: string) => stateOf(model, graph, id);
  const name = (id: string | null) => (id ? graph.concepts.get(id)?.name ?? id : "—");
  const done = (d: Omit<PolicyDecision, "rationale">): PolicyDecision => ({ ...d, rationale });
  const withStyle = (action: PolicyDecision["action"], conceptId: string, followUp = false): PolicyDecision => {
    const { style, note } = styleFor(model, action, ctx, rnd);
    rationale.push(note);
    return done({ action, conceptId, style, followUpQuestion: followUp });
  };
  const shouldFollowUp = (id: string) => {
    const s = st(id);
    return (s.evidence < 3 || s.pKnown < 0.7) && a.fatigue < 0.6 && a.frustration < 0.6;
  };

  // 0) Graded answer takes priority: react to the evidence we just received
  if (ctx.graded) {
    const { conceptId, correct, wasPrereqCheck } = ctx.graded;
    const s = st(conceptId);
    rationale.push(`answer on "${name(conceptId)}" was ${correct ? "correct" : "incorrect"} → mastery now ${(s.pKnown * 100).toFixed(0)}%`);
    if (correct) {
      if (wasPrereqCheck && ctx.currentConceptId && ctx.currentConceptId !== conceptId) {
        rationale.push(`prerequisite check passed → proceed to the goal concept "${name(ctx.currentConceptId)}"`);
        return withStyle("explain", ctx.currentConceptId, shouldFollowUp(ctx.currentConceptId));
      }
      if (s.pKnown >= 0.8 || (a.boredom > 0.5 && s.pKnown > 0.6)) {
        rationale.push(s.pKnown >= 0.8 ? "mastery threshold reached" : "learner appears bored and mastery is decent → move forward");
        const next = recommendNext(model, graph, { exclude: [conceptId], limit: 1 })[0];
        if (next) {
          rationale.push(`next recommended: "${next.name}" (${next.reason})`);
          return withStyle("advance", next.conceptId, shouldFollowUp(next.conceptId));
        }
      }
      rationale.push("mastery not yet secure → ask one more check question");
      return done({ action: "diagnostic_question", conceptId, style: null });
    }
    // incorrect
    const r = readiness(conceptId, graph.edges, st);
    if (r.weakest && observedWeak(st(r.weakest.id))) {
      rationale.push(`weak prerequisite "${name(r.weakest.id)}" (${(r.weakest.pKnown * 100).toFixed(0)}%) likely explains the error → step back`);
      return withStyle("revisit_prerequisite", r.weakest.id, true);
    }
    if (wasPrereqCheck) {
      rationale.push("prerequisite check failed → teach the prerequisite before the goal concept");
      return withStyle("revisit_prerequisite", conceptId, true);
    }
    if (ctx.lastExplainedConceptId === conceptId && ctx.lastExplainedStyle) {
      rationale.push(`the "${ctx.lastExplainedStyle}" explanation did not land → switch explanatory strategy`);
      return withStyle("switch_strategy", conceptId, true);
    }
    rationale.push("no explanation given yet for this concept → explain it simply");
    return withStyle("simplify", conceptId, true);
  }

  // 1) Affect guards
  if (a.fatigue > 0.5 && !ctx.breakSuggestedRecently) {
    rationale.push(`fatigue signal high (${a.fatigue.toFixed(2)}) → suggest a break, keep it short`);
    return done({ action: "suggest_break", conceptId: ctx.currentConceptId, style: "concise" });
  }
  const focus = analysis.conceptIds[0] ?? ctx.currentConceptId ?? ctx.lastExplainedConceptId;

  if (a.frustration > 0.6 && focus) {
    rationale.push(`frustration high (${a.frustration.toFixed(2)}) → acknowledge, slow down and simplify "${name(focus)}"`);
    return withStyle("slow_down", focus, false);
  }

  // 2) Explicit intents
  switch (analysis.intent) {
    case "confusion": {
      if (!focus) break;
      const s = st(focus);
      const r = readiness(focus, graph.edges, st);
      rationale.push(`confusion expressed about "${name(focus)}" (confusion level ${a.confusion.toFixed(2)})`);
      if (s.confusionEvents >= 2 && r.weakest && observedWeak(st(r.weakest.id), 0.5)) {
        rationale.push(`repeated confusion and weak prerequisite "${name(r.weakest.id)}" → revisit the prerequisite`);
        return withStyle("revisit_prerequisite", r.weakest.id, true);
      }
      if (ctx.lastExplainedConceptId === focus && ctx.lastExplainedStyle) {
        rationale.push(`the "${ctx.lastExplainedStyle}" style did not work → try a different strategy`);
        return withStyle("switch_strategy", focus, true);
      }
      return withStyle("simplify", focus, true);
    }
    case "ask_simpler":
      if (!focus) break;
      rationale.push("learner asked for a simpler explanation");
      return withStyle("simplify", focus, shouldFollowUp(focus));
    case "ask_example":
      if (!focus) break;
      rationale.push("learner asked for an example");
      return withStyle("give_example", focus, shouldFollowUp(focus));
    case "ask_deeper":
      if (!focus) break;
      rationale.push("learner asked to go deeper");
      return withStyle("deepen", focus, false);
    case "ask_quiz":
      if (!focus) break;
      rationale.push("learner asked to be tested");
      return done({ action: "diagnostic_question", conceptId: focus, style: null });
    case "confirm": {
      const target = ctx.lastExplainedConceptId ?? ctx.currentConceptId;
      if (!target) break;
      const s = st(target);
      rationale.push(`learner confirmed understanding of "${name(target)}" (weak positive evidence; mastery ${(s.pKnown * 100).toFixed(0)}%)`);
      if (s.pKnown < 0.8 || s.evidence < 2) {
        rationale.push("verify with a quick diagnostic question before moving on");
        return done({ action: "diagnostic_question", conceptId: target, style: null });
      }
      const next = recommendNext(model, graph, { exclude: [target], limit: 1 })[0];
      if (next) {
        rationale.push(`mastery is solid → advance to "${next.name}" (${next.reason})`);
        return withStyle("advance", next.conceptId, shouldFollowUp(next.conceptId));
      }
      break;
    }
    case "ask_concept": {
      const target = analysis.conceptIds[0];
      if (!target) break;
      const s = st(target);
      const r = readiness(target, graph.edges, st);
      const c = graph.concepts.get(target)!;
      rationale.push(`learner asked about "${c.name}" (mastery ${(s.pKnown * 100).toFixed(0)}%, readiness ${(r.score * 100).toFixed(0)}%)`);
      if (r.weakest && observedWeak(st(r.weakest.id), 0.4)) {
        rationale.push(`observed weak prerequisite "${name(r.weakest.id)}" → revisit it first`);
        return withStyle("revisit_prerequisite", r.weakest.id, true);
      }
      if (r.weakest && st(r.weakest.id).evidence === 0 && c.difficulty >= 0.55 && model.pace < 0.8) {
        rationale.push(`prerequisite "${name(r.weakest.id)}" has never been observed and the target is hard → quick prerequisite check first`);
        return done({ action: "diagnostic_question", conceptId: r.weakest.id, style: null });
      }
      if (s.pKnown > 0.85 && s.evidence >= 2) {
        rationale.push("learner already shows high mastery → go deeper rather than repeat basics");
        return withStyle("deepen", target, false);
      }
      const repeated = ctx.lastExplainedConceptId === target;
      if (repeated) rationale.push("same concept asked again → change strategy");
      return withStyle(repeated ? "switch_strategy" : "explain", target, shouldFollowUp(target));
    }
    default:
      break;
  }

  // 3) Boredom on the current concept → move forward
  if (a.boredom > 0.55 && ctx.currentConceptId && st(ctx.currentConceptId).pKnown > 0.6) {
    rationale.push(`boredom high (${a.boredom.toFixed(2)}) and mastery decent → advance to something more challenging`);
    const next = recommendNext(model, graph, { exclude: [ctx.currentConceptId], limit: 1 })[0];
    if (next) return withStyle("advance", next.conceptId, true);
  }

  // 4) Default: advance along the graph — but never re-explain what was just explained
  const bored = a.boredom > 0.5;
  const top = recommendNext(model, graph, { limit: 2 });
  let next = top[0];
  if (next && next.conceptId === ctx.lastExplainedConceptId) {
    if (bored && top[1]) {
      rationale.push(`boredom high (${a.boredom.toFixed(2)}) and "${next.name}" was just explained → skip ahead to "${top[1].name}"`);
      next = top[1];
    } else {
      rationale.push(`"${next.name}" was just explained → check understanding instead of repeating it`);
      return done({ action: "diagnostic_question", conceptId: next.conceptId, style: null });
    }
  }
  if (next) {
    rationale.push(analysis.intent === "greeting" ? "session start → propose the best next concept" : `no specific request → recommend "${next.name}" (${next.reason})`);
    return withStyle("advance", next.conceptId, shouldFollowUp(next.conceptId));
  }
  rationale.push("everything mastered → encourage");
  return done({ action: "encourage", conceptId: null, style: null });
}
