import type { AffectVector, ConceptContent, ConceptQuestion } from "@/db/schema";

export const STYLES = ["concise", "detailed", "example", "analogy", "formal", "steps"] as const;
export type Style = (typeof STYLES)[number];

export const AFFECT_KEYS = [
  "confusion",
  "frustration",
  "boredom",
  "engagement",
  "confidence",
  "fatigue",
  "excitement",
] as const;

export type { AffectVector };

export type ConceptNode = {
  id: string;
  domain: string;
  name: string;
  description: string;
  aliases: string[];
  difficulty: number;
  content: ConceptContent;
  questions: ConceptQuestion[];
};

export type ConceptEdge = {
  fromId: string;
  toId: string;
  type: "prerequisite" | "related" | "part_of";
  weight: number;
};

export type ConceptState = {
  conceptId: string;
  pKnown: number;
  evidence: number;
  correct: number;
  incorrect: number;
  confusionEvents: number;
  activation: number;
  status: "active" | "dormant" | "archived";
  lastStyle: string | null;
  lastInteractionAt: Date | null;
  lastMasteryUpdateAt: Date | null;
};

export type PreferenceArm = {
  arm: Style;
  alpha: number;
  beta: number;
  trials: number;
};

export type LearnerModel = {
  learnerId: string;
  concepts: Map<string, ConceptState>;
  preferences: Map<Style, PreferenceArm>;
  affect: AffectVector;
  pace: number;
};

export type Intent =
  | "answer" // answering a pending diagnostic question
  | "confirm" // "got it", "makes sense"
  | "confusion" // "I don't get it", "huh?"
  | "ask_example" // "can you give an example"
  | "ask_deeper" // "why", "more detail", "go deeper"
  | "ask_simpler" // "simpler", "eli5"
  | "ask_quiz" // "test me"
  | "ask_next" // "what's next", "move on"
  | "ask_concept" // asks about a concept
  | "greeting"
  | "chat"; // other

export type MessageAnalysis = {
  intent: Intent;
  conceptIds: string[]; // detected concept mentions, most specific first
  affectSignals: Partial<AffectVector>;
  answerIndex: number | null; // if the message is an answer to an MC question
  length: number;
  latencyMs: number | null;
};

export type PolicyAction =
  | "explain" // explain a concept using chosen style
  | "simplify" // re-explain simpler
  | "deepen" // go into more depth
  | "give_example" // provide a worked example
  | "diagnostic_question" // ask a small check question
  | "revisit_prerequisite" // step back to a weak prerequisite
  | "switch_strategy" // change explanation style
  | "slow_down" // reduce pace, smaller step
  | "advance" // move to the next concept
  | "encourage" // affective support
  | "suggest_break" // fatigue detected
  | "grade_answer"; // respond to an answer

export type PolicyDecision = {
  action: PolicyAction;
  conceptId: string | null;
  style: Style | null;
  rationale: string[];
  followUpQuestion?: boolean; // attach a diagnostic question after explanation
};

export type Recommendation = {
  conceptId: string;
  name: string;
  reason: string;
  score: number;
  pKnown: number;
  status: string;
};
