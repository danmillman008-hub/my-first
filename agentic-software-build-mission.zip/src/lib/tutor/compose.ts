import type { ConceptQuestion } from "@/db/schema";
import type { ConceptNode, LearnerModel, PolicyDecision, Style } from "./types";

export type ComposeInput = {
  decision: PolicyDecision;
  concept: ConceptNode | null;
  goalConcept: ConceptNode | null; // when checking a prerequisite on the way to a goal
  question: ConceptQuestion | null;
  graded: { concept: ConceptNode; correct: boolean; correctText: string; hint?: string } | null;
  model: LearnerModel;
  learnerName: string;
  userMessage: string;
};

const LETTERS = "ABCDEFGH";

export function formatQuestion(q: ConceptQuestion): string {
  return `**Quick check:** ${q.prompt}\n` + q.options.map((o, i) => `${LETTERS[i]}) ${o}`).join("\n") + `\n_(reply with a letter)_`;
}

const STYLE_LEAD: Record<Style, string> = {
  concise: "In short:",
  detailed: "Let me walk through it properly.",
  example: "Let's make it concrete with an example.",
  analogy: "Here's an analogy that usually helps.",
  formal: "Formally:",
  steps: "Here's a step-by-step recipe.",
};

function explanation(c: ConceptNode, style: Style): string {
  const body = c.content[style] ?? c.content.concise ?? c.description;
  return `${STYLE_LEAD[style]} ${body}`;
}

function affectPreamble(model: LearnerModel): string {
  const a = model.affect;
  if (a.frustration > 0.6) return "This one trips a lot of people up — nothing wrong with you. Let's slow right down. ";
  if (a.confusion > 0.6) return "Okay, let's come at it from a different angle. ";
  if (a.boredom > 0.55) return "Sounds like you're ready for something meatier. ";
  if (a.excitement > 0.6) return "Love the energy — let's keep going. ";
  return "";
}

export function composeTemplate(input: ComposeInput): string {
  const { decision, concept, question, graded, model, goalConcept } = input;
  const parts: string[] = [];

  if (graded) {
    if (graded.correct) {
      parts.push(`✅ Correct — **${graded.correctText}**.`);
    } else {
      parts.push(`❌ Not quite. The answer was **${graded.correctText}**.${graded.hint ? ` Hint for next time: ${graded.hint}` : ""}`);
    }
  }

  const style = decision.style ?? "concise";
  switch (decision.action) {
    case "explain":
      if (concept) parts.push(`${affectPreamble(model)}**${concept.name}**\n\n${explanation(concept, style)}`);
      break;
    case "advance":
      if (concept) parts.push(`${affectPreamble(model)}Let's move to **${concept.name}** — ${concept.description}\n\n${explanation(concept, style)}`);
      break;
    case "simplify":
    case "slow_down":
      if (concept) parts.push(`${affectPreamble(model)}Let's simplify **${concept.name}**.\n\n${explanation(concept, style)}`);
      break;
    case "switch_strategy":
      if (concept) parts.push(`${affectPreamble(model)}Let me try explaining **${concept.name}** differently.\n\n${explanation(concept, style)}`);
      break;
    case "deepen":
      if (concept) parts.push(`Going deeper on **${concept.name}**.\n\n${explanation(concept, style)}`);
      break;
    case "give_example":
      if (concept) parts.push(`${explanation(concept, "example")}`);
      break;
    case "revisit_prerequisite":
      if (concept)
        parts.push(
          `${affectPreamble(model)}Before going further, let's shore up a prerequisite: **${concept.name}**${goalConcept ? ` (it underpins ${goalConcept.name})` : ""}.\n\n${explanation(concept, style)}`,
        );
      break;
    case "diagnostic_question":
      if (concept && goalConcept && goalConcept.id !== concept.id) {
        parts.push(`Before we dive into **${goalConcept.name}**, a quick check on a prerequisite (**${concept.name}**) so I pitch it right.`);
      } else if (concept && !graded) {
        parts.push(`Let's check your understanding of **${concept.name}**.`);
      }
      break;
    case "encourage":
      parts.push("You've covered everything in this domain with solid mastery — great work. Ask me anything you'd like to revisit, or ask to be tested.");
      break;
    case "suggest_break":
      parts.push("You've been at this a while and your replies suggest you're getting tired. A 5–10 minute break will do more for retention than pushing on. I'll keep your place — when you're back, just say *continue*.");
      break;
    case "grade_answer":
      break;
  }

  if (question && decision.action !== "suggest_break") {
    parts.push(formatQuestion(question));
  }
  if (parts.length === 0) {
    parts.push("Tell me which topic you'd like to explore (e.g. *conditional probability*), ask *what's next*, or say *test me*.");
  }
  return parts.join("\n\n");
}

/**
 * Optional LLM rendering. The adaptive decision is made by the core; the LLM only rephrases
 * the template content under strict constraints. Falls back to the template on any failure.
 */
export async function composeResponse(input: ComposeInput): Promise<{ text: string; renderer: "template" | "llm" }> {
  const template = composeTemplate(input);
  const key = process.env.OPENAI_API_KEY;
  if (!key || input.decision.action === "suggest_break") return { text: template, renderer: "template" };
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12_000);
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
      signal: controller.signal,
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL ?? "gpt-4o-mini",
        temperature: 0.4,
        messages: [
          {
            role: "system",
            content:
              "You are a private tutor. Rewrite the DRAFT so it flows naturally for the learner while preserving every fact, formula, the requested explanation style, and any quiz question verbatim (keep the lettered options exactly). Do not add new concepts. Keep length similar. Learner affect: " +
              JSON.stringify(input.model.affect) +
              ". Decision: " +
              input.decision.action +
              (input.decision.style ? " / style " + input.decision.style : ""),
          },
          { role: "user", content: `Learner said: ${input.userMessage}\n\nDRAFT:\n${template}` },
        ],
      }),
    });
    clearTimeout(timer);
    if (!res.ok) return { text: template, renderer: "template" };
    const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const text = json.choices?.[0]?.message?.content?.trim();
    return text ? { text, renderer: "llm" } : { text: template, renderer: "template" };
  } catch {
    return { text: template, renderer: "template" };
  }
}
