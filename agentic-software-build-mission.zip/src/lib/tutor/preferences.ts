import { STYLES, type PreferenceArm, type Style } from "./types";

/**
 * Preference model = Bernoulli bandit over explanation styles.
 * Each style has a Beta(alpha, beta) posterior on "this style leads to understanding".
 * Reward evidence: correct follow-up answer / explicit confirmation → success;
 * confusion / wrong answer right after an explanation → failure.
 *
 * Selection uses Thompson sampling (exploration while data is scarce, exploitation later).
 * A deterministic seed can be passed for tests.
 */

export function defaultPreferences(): Map<Style, PreferenceArm> {
  const m = new Map<Style, PreferenceArm>();
  for (const s of STYLES) m.set(s, { arm: s, alpha: 1, beta: 1, trials: 0 });
  return m;
}

export function recordOutcome(arm: PreferenceArm, success: boolean, weight = 1): PreferenceArm {
  return {
    ...arm,
    alpha: arm.alpha + (success ? weight : 0),
    beta: arm.beta + (success ? 0 : weight),
    trials: arm.trials + 1,
  };
}

export function armMean(arm: PreferenceArm): number {
  return arm.alpha / (arm.alpha + arm.beta);
}

// Marsaglia–Tsang gamma sampler → Beta sample
function sampleGamma(shape: number, rnd: () => number): number {
  if (shape < 1) return sampleGamma(shape + 1, rnd) * Math.pow(rnd(), 1 / shape);
  const d = shape - 1 / 3;
  const c = 1 / Math.sqrt(9 * d);
  for (;;) {
    let x: number;
    let v: number;
    do {
      // Box–Muller normal
      const u1 = Math.max(rnd(), 1e-12);
      const u2 = rnd();
      x = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
      v = 1 + c * x;
    } while (v <= 0);
    v = v * v * v;
    const u = rnd();
    if (u < 1 - 0.0331 * x ** 4) return d * v;
    if (Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
  }
}

export function sampleBeta(alpha: number, beta: number, rnd: () => number = Math.random): number {
  const a = sampleGamma(alpha, rnd);
  const b = sampleGamma(beta, rnd);
  return a / (a + b);
}

/**
 * Choose a style. `exclude` lets the policy force a switch away from a style that just failed.
 * `bias` adds context-dependent prior shifts (e.g. confusion → favour example/steps).
 */
export function chooseStyle(
  prefs: Map<Style, PreferenceArm>,
  opts: { exclude?: Style[]; bias?: Partial<Record<Style, number>>; rnd?: () => number } = {},
): { style: Style; scores: Record<string, number> } {
  const rnd = opts.rnd ?? Math.random;
  const scores: Record<string, number> = {};
  let best: Style | null = null;
  for (const s of STYLES) {
    if (opts.exclude?.includes(s)) continue;
    const arm = prefs.get(s) ?? { arm: s, alpha: 1, beta: 1, trials: 0 };
    const sample = sampleBeta(arm.alpha, arm.beta, rnd) + (opts.bias?.[s] ?? 0);
    scores[s] = sample;
    if (best === null || sample > scores[best]) best = s;
  }
  return { style: best ?? "concise", scores };
}

export function rankedPreferences(prefs: Map<Style, PreferenceArm>): { style: Style; mean: number; trials: number }[] {
  return [...prefs.values()]
    .map((a) => ({ style: a.arm, mean: armMean(a), trials: a.trials }))
    .sort((a, b) => b.mean - a.mean);
}
