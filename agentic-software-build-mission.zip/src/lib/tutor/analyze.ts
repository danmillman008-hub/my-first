import { lexicalAffect } from "./affect";
import type { ConceptNode, Intent, MessageAnalysis } from "./types";

const norm = (s: string) => s.toLowerCase().replace(/[’']/g, "'").replace(/\s+/g, " ").trim();

/** Detect concept mentions; longer alias matches rank first (more specific). */
export function detectConcepts(text: string, concepts: ConceptNode[]): string[] {
  const t = " " + norm(text).replace(/[^a-z0-9|()' \-]/g, " ") + " ";
  const hits: { id: string; len: number }[] = [];
  for (const c of concepts) {
    const terms = [c.name, ...c.aliases].map(norm);
    let best = 0;
    for (const term of terms) {
      if (term.length < 3) continue;
      const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const re = new RegExp(`(^|[^a-z0-9])${escaped}(s|es)?($|[^a-z0-9])`, "i");
      if (re.test(t)) best = Math.max(best, term.length);
    }
    if (best > 0) hits.push({ id: c.id, len: best });
  }
  hits.sort((a, b) => b.len - a.len);
  return hits.map((h) => h.id);
}

export function parseAnswer(text: string, optionCount: number, options: string[]): number | null {
  const t = norm(text).replace(/[.!?)]+$/g, "");
  // letter answers: a / b) / "B"
  const letter = t.match(/^\(?([a-h])\)?$/);
  if (letter) {
    const idx = letter[1].charCodeAt(0) - 97;
    return idx < optionCount ? idx : null;
  }
  // number answers: 1..n (1-indexed)
  const num = t.match(/^\(?(\d{1,2})\)?$/);
  if (num) {
    const n = parseInt(num[1], 10);
    if (n >= 1 && n <= optionCount) return n - 1;
  }
  // "option b", "answer is c", "i think a"
  const phrased = t.match(/\b(?:option|answer(?: is)?|choose|pick|go with|it'?s|i think|i'd say)\s+\(?([a-h])\)?\b/);
  if (phrased) {
    const idx = phrased[1].charCodeAt(0) - 97;
    return idx < optionCount ? idx : null;
  }
  // literal option text
  const exact = options.findIndex((o) => norm(o) === t);
  if (exact >= 0) return exact;
  const contains = options.map((o, i) => ({ i, o: norm(o) })).filter((x) => x.o.length >= 2 && t.includes(x.o));
  if (contains.length === 1) return contains[0].i;
  return null;
}

export function analyzeMessage(
  text: string,
  concepts: ConceptNode[],
  ctx: { pendingOptions?: string[] | null; latencyMs?: number | null },
): MessageAnalysis {
  const t = norm(text);
  const conceptIds = detectConcepts(text, concepts);
  const affectSignals = lexicalAffect(text);

  let answerIndex: number | null = null;
  if (ctx.pendingOptions && ctx.pendingOptions.length > 0) {
    answerIndex = parseAnswer(text, ctx.pendingOptions.length, ctx.pendingOptions);
  }

  let intent: Intent = "chat";
  if (answerIndex !== null) intent = "answer";
  else if (/\b(quiz|test me|check my understanding|ask me|question me|practice)\b/.test(t)) intent = "ask_quiz";
  else if (/\b(example|for instance|show me|concrete|instance)\b/.test(t)) intent = "ask_example";
  else if (/\b(simpl|eli5|easier|plain english|dumb it down|slower|basic)/.test(t)) intent = "ask_simpler";
  else if (/\b(deeper|more detail|rigorous|formal|proof|why does|why is|in depth|elaborate|more about)\b/.test(t)) intent = "ask_deeper";
  else if (/\b(next|move on|continue|what should i learn|what now|keep going|let'?s go|ready|start)\b/.test(t)) intent = "ask_next";
  else if (/\b(confus|don'?t (get|understand|follow)|not sure|lost|huh|unclear|no idea|makes no sense|what do you mean)\b|\?\?+/.test(t))
    intent = "confusion";
  else if (/\b(got it|makes sense|i see|understood|clear now|that helps|ok(ay)? thanks|thank you|perfect|ah+ ok|yes)\b/.test(t) && t.length < 80)
    intent = "confirm";
  else if (/^(hi|hello|hey|yo|good (morning|afternoon|evening))\b/.test(t)) intent = "greeting";
  else if (conceptIds.length > 0 || /\?$/.test(t) || /\b(what|how|explain|teach|tell me|learn)\b/.test(t)) intent = "ask_concept";

  return {
    intent,
    conceptIds,
    affectSignals,
    answerIndex,
    length: text.length,
    latencyMs: ctx.latencyMs ?? null,
  };
}
