import type { ConceptState, ConceptEdge } from "./types";

/**
 * Bayesian Knowledge Tracing (BKT) with forgetting and graded evidence.
 *
 * Latent variable: L = learner knows concept. We maintain P(L).
 * Observation model: guess g = P(correct | not L), slip s = P(incorrect | L).
 * Learning transition t = P(L_next | not L) after an opportunity.
 * Forgetting: P(L) decays toward a floor with a half-life that grows with evidence
 * (a spaced-repetition prior: well-practised concepts decay slowly).
 */

export type EvidenceKind =
  | "quiz_correct"
  | "quiz_incorrect"
  | "confirmation" // "got it" — weak positive
  | "confusion" // "I don't understand" — weak negative
  | "self_report_known" // "I already know this"
  | "self_report_unknown" // "never heard of it"
  | "prereq_inferred_positive"; // success on a dependent concept

type ObsParams = { correct: boolean; guess: number; slip: number; transit: number };

export function evidenceParams(kind: EvidenceKind, difficulty = 0.5): ObsParams {
  switch (kind) {
    case "quiz_correct":
      // harder questions are less guessable → stronger positive evidence
      return { correct: true, guess: 0.3 - 0.15 * difficulty, slip: 0.1, transit: 0.12 };
    case "quiz_incorrect":
      // harder questions produce more slips → weaker negative evidence
      return { correct: false, guess: 0.3 - 0.15 * difficulty, slip: 0.1 + 0.15 * difficulty, transit: 0.08 };
    case "confirmation":
      return { correct: true, guess: 0.55, slip: 0.2, transit: 0.1 };
    case "confusion":
      return { correct: false, guess: 0.45, slip: 0.3, transit: 0.02 };
    case "self_report_known":
      return { correct: true, guess: 0.35, slip: 0.1, transit: 0.05 };
    case "self_report_unknown":
      return { correct: false, guess: 0.3, slip: 0.4, transit: 0 };
    case "prereq_inferred_positive":
      return { correct: true, guess: 0.7, slip: 0.1, transit: 0.03 };
  }
}

export function bktPosterior(pL: number, p: ObsParams): number {
  const { guess: g, slip: s, correct } = p;
  const post = correct
    ? (pL * (1 - s)) / (pL * (1 - s) + (1 - pL) * g)
    : (pL * s) / (pL * s + (1 - pL) * (1 - g));
  const learned = post + (1 - post) * p.transit;
  return clamp01(learned);
}

export function clamp01(x: number): number {
  if (Number.isNaN(x)) return 0;
  return Math.max(0.001, Math.min(0.999, x));
}

/** Half-life in days grows with accumulated evidence (spacing effect). */
export function halfLifeDays(state: Pick<ConceptState, "correct" | "evidence">): number {
  return 5 * Math.pow(1.6, Math.max(0, state.correct)) * (1 + 0.1 * state.evidence);
}

/** Apply forgetting between the last mastery update and `now`. */
export function applyForgetting(state: ConceptState, now: Date = new Date()): number {
  if (!state.lastMasteryUpdateAt || state.evidence === 0) return state.pKnown;
  const days = Math.max(0, (now.getTime() - state.lastMasteryUpdateAt.getTime()) / 86_400_000);
  if (days < 0.01) return state.pKnown;
  const hl = halfLifeDays(state);
  const floor = 0.1; // you never fully forget once learned
  const retained = floor + (state.pKnown - floor) * Math.pow(0.5, days / hl);
  return clamp01(Math.min(state.pKnown, retained));
}

export function observe(
  state: ConceptState,
  kind: EvidenceKind,
  opts: { difficulty?: number; now?: Date } = {},
): ConceptState {
  const now = opts.now ?? new Date();
  const prior = applyForgetting(state, now);
  const params = evidenceParams(kind, opts.difficulty ?? 0.5);
  const pKnown = bktPosterior(prior, params);
  const isQuiz = kind === "quiz_correct" || kind === "quiz_incorrect";
  return {
    ...state,
    pKnown,
    evidence: state.evidence + 1,
    correct: state.correct + (isQuiz && params.correct ? 1 : 0),
    incorrect: state.incorrect + (isQuiz && !params.correct ? 1 : 0),
    confusionEvents: state.confusionEvents + (kind === "confusion" ? 1 : 0),
    lastMasteryUpdateAt: now,
  };
}

/** 0 = certain, 1 = no information. Shrinks with evidence. */
export function uncertainty(state: Pick<ConceptState, "evidence">): number {
  return 1 / (1 + 0.6 * state.evidence);
}

export type MasteryLevel = "unobserved" | "novice" | "developing" | "proficient" | "mastered";

export function masteryLevel(state: Pick<ConceptState, "pKnown" | "evidence">): MasteryLevel {
  if (state.evidence === 0) return "unobserved";
  if (state.pKnown < 0.35) return "novice";
  if (state.pKnown < 0.65) return "developing";
  if (state.pKnown < 0.88) return "proficient";
  return "mastered";
}

export function defaultConceptState(conceptId: string, difficulty = 0.5): ConceptState {
  return {
    conceptId,
    pKnown: clamp01(0.3 - 0.2 * difficulty), // harder concepts start with lower prior
    evidence: 0,
    correct: 0,
    incorrect: 0,
    confusionEvents: 0,
    activation: 0,
    status: "active",
    lastStyle: null,
    lastInteractionAt: null,
    lastMasteryUpdateAt: null,
  };
}

// ---------- Graph-aware reasoning ----------

export function prerequisitesOf(conceptId: string, edges: ConceptEdge[]): { id: string; weight: number }[] {
  return edges
    .filter((e) => e.type === "prerequisite" && e.toId === conceptId)
    .map((e) => ({ id: e.fromId, weight: e.weight }));
}

export function dependentsOf(conceptId: string, edges: ConceptEdge[]): string[] {
  return edges.filter((e) => e.type === "prerequisite" && e.fromId === conceptId).map((e) => e.toId);
}

/**
 * Readiness of a concept = weighted mean mastery of its prerequisites (1 if none).
 * Used to decide whether to advance or step back.
 */
export function readiness(
  conceptId: string,
  edges: ConceptEdge[],
  getState: (id: string) => ConceptState,
): { score: number; weakest: { id: string; pKnown: number } | null } {
  const prereqs = prerequisitesOf(conceptId, edges);
  if (prereqs.length === 0) return { score: 1, weakest: null };
  let total = 0;
  let wsum = 0;
  let weakest: { id: string; pKnown: number } | null = null;
  for (const p of prereqs) {
    const s = getState(p.id);
    total += s.pKnown * p.weight;
    wsum += p.weight;
    if (!weakest || s.pKnown < weakest.pKnown) weakest = { id: p.id, pKnown: s.pKnown };
  }
  return { score: wsum > 0 ? total / wsum : 1, weakest };
}

/** Topological depth (longest prerequisite chain) for layout / ordering. */
export function conceptDepths(conceptIds: string[], edges: ConceptEdge[]): Map<string, number> {
  const depth = new Map<string, number>();
  const memo = (id: string, seen: Set<string>): number => {
    if (depth.has(id)) return depth.get(id)!;
    if (seen.has(id)) return 0;
    seen.add(id);
    const pre = prerequisitesOf(id, edges);
    const d = pre.length === 0 ? 0 : 1 + Math.max(...pre.map((p) => memo(p.id, seen)));
    depth.set(id, d);
    return d;
  };
  for (const id of conceptIds) memo(id, new Set());
  return depth;
}
