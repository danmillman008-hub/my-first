import type { ConceptState } from "./types";

/**
 * Dormant-branch handling.
 *
 * Each learner/concept pair has an `activation` value (ACT-R style base-level activation
 * approximation): it is boosted on every interaction and decays exponentially with time.
 *
 *  - active   : recently touched or never touched (fresh concepts remain eligible)
 *  - dormant  : touched before but activation decayed under a threshold → de-prioritised in
 *               recommendations, never auto-selected for advancement; re-activates on interaction
 *  - archived : dormant for a long time → hidden from default recommendations. Mastery + history
 *               are preserved, and the branch is revived automatically if the learner returns.
 */

export const ACTIVATION_HALF_LIFE_DAYS = 3;
export const DORMANT_THRESHOLD = 0.25;
export const ARCHIVE_AFTER_DAYS = 21;

export function decayedActivation(state: Pick<ConceptState, "activation" | "lastInteractionAt">, now = new Date()): number {
  if (!state.lastInteractionAt) return state.activation;
  const days = Math.max(0, (now.getTime() - state.lastInteractionAt.getTime()) / 86_400_000);
  return state.activation * Math.pow(0.5, days / ACTIVATION_HALF_LIFE_DAYS);
}

export function touch(state: ConceptState, boost = 1, now = new Date()): ConceptState {
  const current = decayedActivation(state, now);
  return {
    ...state,
    activation: Math.min(5, current + boost),
    lastInteractionAt: now,
    status: "active",
  };
}

export function reclassify(state: ConceptState, now = new Date()): ConceptState {
  if (!state.lastInteractionAt) return state; // never touched: stays "active" (eligible)
  const act = decayedActivation(state, now);
  const days = (now.getTime() - state.lastInteractionAt.getTime()) / 86_400_000;
  let status: ConceptState["status"] = "active";
  if (act < DORMANT_THRESHOLD) status = "dormant";
  if (status === "dormant" && days > ARCHIVE_AFTER_DAYS) status = "archived";
  return { ...state, status };
}

/** Multiplier for recommendation scores. Dormant branches are weakened, not destroyed. */
export function priorityMultiplier(status: ConceptState["status"]): number {
  switch (status) {
    case "active":
      return 1;
    case "dormant":
      return 0.5;
    case "archived":
      return 0.15;
  }
}
