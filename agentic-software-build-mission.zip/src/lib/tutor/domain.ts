import type { ConceptEdge, ConceptNode } from "./types";

type Seed = Omit<ConceptNode, "domain">;
const D = "Probability & Statistics";

const C: Seed[] = [
  {
    id: "sample-spaces",
    name: "Sample spaces & events",
    description: "The set of all possible outcomes of an experiment, and subsets of it called events.",
    aliases: ["sample space", "event", "events", "outcome", "outcomes"],
    difficulty: 0.15,
    content: {
      concise: "A sample space Ω is the set of every possible outcome of an experiment. An event is any subset of Ω.",
      detailed:
        "Before you can talk about probability you need to be precise about what can happen. The sample space Ω lists every distinct outcome exactly once. An event is a collection of outcomes you care about — 'rolling an even number' is the event {2,4,6}. Events can be combined with union (A or B), intersection (A and B) and complement (not A), which is why set notation is used.",
      example:
        "Roll one die. Ω = {1,2,3,4,5,6}. The event 'even' is E = {2,4,6}; 'greater than 4' is G = {5,6}. E ∩ G = {6}, E ∪ G = {2,4,5,6}, and the complement of E is {1,3,5}.",
      analogy:
        "Think of Ω as a bag containing one ticket for every possible outcome. An event is just a rule that picks some tickets out of the bag — 'all red tickets', 'tickets numbered above 4'.",
      formal:
        "An experiment has outcome space Ω. An event A ⊆ Ω. The event algebra is closed under complement (Aᶜ = Ω∖A), finite union and intersection. Ω is the certain event and ∅ the impossible event.",
      steps:
        "1) Write down every possible outcome of the experiment → that list is Ω. 2) Describe the thing you care about in words. 3) Select the outcomes from Ω that satisfy it → that subset is your event. 4) Combine events with ∪, ∩, complement as needed.",
    },
    questions: [
      { id: "q1", prompt: "Flip two coins. How many outcomes are in the sample space?", options: ["2", "3", "4", "6"], answer: 2, difficulty: 0.2, hint: "List them: HH, HT, TH, TT." },
      { id: "q2", prompt: "Roll a die. Which set is the event 'odd AND greater than 2'?", options: ["{1,3,5}", "{3,5}", "{3,4,5,6}", "{5}"], answer: 1, difficulty: 0.3 },
    ],
  },
  {
    id: "counting",
    name: "Counting principles",
    description: "Multiplication rule, permutations and combinations for counting outcomes.",
    aliases: ["permutation", "permutations", "combination", "combinations", "choose", "factorial", "multiplication rule"],
    difficulty: 0.35,
    content: {
      concise: "If a task has k steps with n₁, n₂, … choices, there are n₁·n₂·… ways. Ordered selections of r from n: n!/(n−r)!. Unordered: C(n,r)=n!/(r!(n−r)!).",
      detailed:
        "Many probabilities reduce to counting. The multiplication rule says independent choices multiply. A permutation counts ordered arrangements (a podium: gold/silver/bronze matter). A combination counts unordered groups (a committee: who is in it matters, order does not). The r! in the denominator of C(n,r) removes the orderings you over-counted.",
      example:
        "How many 3-person committees from 5 people? Ordered would be 5·4·3 = 60, but each committee was counted 3! = 6 times, so C(5,3) = 60/6 = 10. A 3-place podium from 5 runners, in contrast, really is 60.",
      analogy:
        "A permutation is a lock combination — 1-2-3 and 3-2-1 open different locks. A combination is a fruit salad — apple+banana is the same salad as banana+apple.",
      formal: "P(n,r) = n!/(n−r)!.  C(n,r) = (n choose r) = n!/(r!(n−r)!).  Σᵣ C(n,r) = 2ⁿ.  Multiplication principle: |A×B| = |A|·|B|.",
      steps:
        "1) Ask: does order matter? 2) If yes → permutation n!/(n−r)!. 3) If no → combination n!/(r!(n−r)!). 4) If the task has independent stages, multiply the counts of each stage.",
    },
    questions: [
      { id: "q1", prompt: "How many ways can you choose 2 toppings from 4 (order irrelevant)?", options: ["4", "6", "8", "12"], answer: 1, difficulty: 0.3, hint: "C(4,2)." },
      { id: "q2", prompt: "A password is 3 letters from A–Z, repeats allowed. How many passwords?", options: ["26·25·24", "3²⁶", "26³", "C(26,3)"], answer: 2, difficulty: 0.4 },
    ],
  },
  {
    id: "probability-axioms",
    name: "Probability basics & axioms",
    description: "Assigning numbers to events: non-negativity, total probability 1, additivity, complement rule.",
    aliases: ["probability", "axioms", "complement rule", "addition rule", "basic probability"],
    difficulty: 0.3,
    content: {
      concise: "P(A) ∈ [0,1], P(Ω)=1, and for disjoint events P(A∪B)=P(A)+P(B). Hence P(Aᶜ)=1−P(A) and P(A∪B)=P(A)+P(B)−P(A∩B).",
      detailed:
        "Kolmogorov's three axioms are all you need: probabilities are non-negative, the whole sample space has probability 1, and probabilities of mutually exclusive events add. Everything else — the complement rule, the general addition rule with the overlap subtracted — follows from those. For equally likely outcomes, P(A) = |A|/|Ω|, which is why counting matters.",
      example:
        "Draw one card. P(heart) = 13/52, P(king) = 4/52, P(heart ∩ king) = 1/52. So P(heart or king) = 13/52 + 4/52 − 1/52 = 16/52. P(not a heart) = 1 − 13/52 = 39/52.",
      analogy:
        "Probability is like spreading 1 kg of sand over the sample space. Each event is a region; its probability is the sand sitting on it. Disjoint regions' sand adds up, and the whole floor holds exactly 1 kg.",
      formal:
        "(Ω, F, P) with P: F→[0,1]; P(Ω)=1; countable additivity: P(⋃Aᵢ)=ΣP(Aᵢ) for pairwise disjoint Aᵢ. Consequences: P(∅)=0, monotonicity, inclusion–exclusion.",
      steps:
        "1) Identify Ω and check whether outcomes are equally likely. 2) Count |A| and |Ω|, or add sub-event probabilities. 3) For 'A or B' subtract the overlap P(A∩B). 4) For 'not A' use 1−P(A).",
    },
    questions: [
      { id: "q1", prompt: "P(A)=0.4, P(B)=0.5, P(A∩B)=0.2. What is P(A∪B)?", options: ["0.9", "0.7", "0.2", "0.1"], answer: 1, difficulty: 0.35, hint: "Subtract the overlap." },
      { id: "q2", prompt: "The probability of rain is 0.3. Probability of no rain?", options: ["0.3", "0.6", "0.7", "1.3"], answer: 2, difficulty: 0.15 },
    ],
  },
  {
    id: "conditional-probability",
    name: "Conditional probability",
    description: "Probability of A given B has occurred: P(A|B) = P(A∩B)/P(B).",
    aliases: ["conditional", "given", "P(A|B)", "conditioning"],
    difficulty: 0.5,
    content: {
      concise: "P(A|B) = P(A∩B)/P(B): restrict the world to B and renormalise. Multiplication rule: P(A∩B)=P(A|B)P(B).",
      detailed:
        "Conditioning means new information shrinks your sample space. Once you know B happened, the only outcomes that matter are those inside B, so the probability of A becomes the share of B that also lies in A. Dividing by P(B) rescales so probabilities inside B again sum to 1. Beware: P(A|B) and P(B|A) are generally different.",
      example:
        "Roll a die; you are told the result is even (B={2,4,6}). What is the chance it is a 2? P(2|even) = P({2})/P(even) = (1/6)/(1/2) = 1/3 — the world shrank from 6 outcomes to 3.",
      analogy:
        "It's like zooming a map. Given B, you crop the map to region B and re-scale it to full size; the probability of A is how much of the cropped map A covers.",
      formal: "For P(B)>0, P(A|B) := P(A∩B)/P(B). Chain rule: P(A₁∩…∩Aₙ)=P(A₁)P(A₂|A₁)…P(Aₙ|A₁…Aₙ₋₁). Law of total probability: P(A)=ΣP(A|Bᵢ)P(Bᵢ) for a partition {Bᵢ}.",
      steps:
        "1) Identify the conditioning event B (the 'given' part). 2) Find P(A∩B), the overlap. 3) Find P(B). 4) Divide: P(A|B)=P(A∩B)/P(B). 5) Sanity-check the answer is between 0 and 1.",
    },
    questions: [
      { id: "q1", prompt: "P(A∩B)=0.12, P(B)=0.4. P(A|B) = ?", options: ["0.048", "0.3", "0.52", "0.12"], answer: 1, difficulty: 0.4 },
      { id: "q2", prompt: "Two cards drawn without replacement. P(second is an ace | first is an ace)?", options: ["4/52", "3/52", "3/51", "4/51"], answer: 2, difficulty: 0.55, hint: "After one ace is gone, 3 aces remain among 51 cards." },
    ],
  },
  {
    id: "independence",
    name: "Independence",
    description: "Events A and B are independent when knowing B does not change P(A): P(A∩B)=P(A)P(B).",
    aliases: ["independent", "independent events", "dependent"],
    difficulty: 0.45,
    content: {
      concise: "A and B are independent iff P(A∩B)=P(A)·P(B), equivalently P(A|B)=P(A).",
      detailed:
        "Independence is a statement about information: learning B tells you nothing about A. It is not the same as being mutually exclusive — disjoint events with positive probability are strongly dependent (if one happens the other can't). Independence of many events requires the product rule to hold for every sub-collection, not just pairs.",
      example:
        "Flip a fair coin twice. P(first H)=1/2, P(second H)=1/2, P(both H)=1/4 = 1/2·1/2 → independent. Now draw two cards without replacement: P(second ace | first ace)=3/51 ≠ 4/52 → dependent.",
      analogy:
        "Two independent events are like two strangers' commutes: knowing one was late says nothing about the other. Two dependent events are like colleagues sharing a car.",
      formal: "A ⊥ B ⇔ P(A∩B)=P(A)P(B). Mutual independence of {Aᵢ}: P(⋂_{i∈S}Aᵢ)=∏_{i∈S}P(Aᵢ) for all finite S. Pairwise independence does not imply mutual independence.",
      steps: "1) Compute P(A), P(B), P(A∩B). 2) Multiply P(A)·P(B). 3) If equal to P(A∩B), the events are independent; otherwise dependent. 4) Don't confuse with 'disjoint'.",
    },
    questions: [
      { id: "q1", prompt: "P(A)=0.5, P(B)=0.4, P(A∩B)=0.2. Are A and B independent?", options: ["Yes", "No", "Cannot tell"], answer: 0, difficulty: 0.35 },
      { id: "q2", prompt: "A and B are disjoint with P(A)=0.3, P(B)=0.2. Are they independent?", options: ["Yes, always", "No", "Only if P(A)=P(B)"], answer: 1, difficulty: 0.55, hint: "P(A∩B)=0 but P(A)P(B)=0.06." },
    ],
  },
  {
    id: "bayes-theorem",
    name: "Bayes' theorem",
    description: "Reversing a conditional: P(A|B) = P(B|A)P(A)/P(B).",
    aliases: ["bayes", "bayes rule", "bayesian", "posterior", "prior", "likelihood", "base rate"],
    difficulty: 0.6,
    content: {
      concise: "P(A|B) = P(B|A)·P(A) / P(B), where P(B) = P(B|A)P(A) + P(B|Aᶜ)P(Aᶜ). Posterior ∝ likelihood × prior.",
      detailed:
        "Bayes' theorem lets you flip a conditional you know (how likely is the evidence if the hypothesis is true) into the one you want (how likely is the hypothesis given the evidence). The prior P(A) is your belief before evidence; the likelihood P(B|A) says how expected the evidence is; the denominator P(B) is the total probability of the evidence under all hypotheses. Ignoring the prior — the base-rate fallacy — is the most common mistake.",
      example:
        "A disease affects 1% of people. A test detects it 95% of the time and false-alarms 5% of the time. P(disease | positive) = 0.95·0.01 / (0.95·0.01 + 0.05·0.99) = 0.0095/0.059 ≈ 0.16. Even with a positive test you are probably healthy — because the disease is rare.",
      analogy:
        "Imagine 1000 people: 10 sick, 990 healthy. The test flags ~9.5 of the sick and ~49.5 of the healthy. Of the ~59 flagged, only ~9.5 are actually sick → about 16%. Bayes is just this headcount written as a formula.",
      formal: "P(Aᵢ|B) = P(B|Aᵢ)P(Aᵢ) / Σⱼ P(B|Aⱼ)P(Aⱼ) for a partition {Aⱼ}. Odds form: posterior odds = prior odds × likelihood ratio.",
      steps:
        "1) Write the prior P(A). 2) Write the likelihood P(B|A) and the false-positive rate P(B|Aᶜ). 3) Compute the evidence P(B)=P(B|A)P(A)+P(B|Aᶜ)P(Aᶜ). 4) Divide: P(A|B)=P(B|A)P(A)/P(B). 5) Sanity-check against a natural-frequency headcount.",
    },
    questions: [
      { id: "q1", prompt: "Prior P(A)=0.2, P(B|A)=0.5, P(B|Aᶜ)=0.25. What is P(A|B)?", options: ["0.1", "0.2", "0.33", "0.5"], answer: 2, difficulty: 0.6, hint: "P(B)=0.1+0.2=0.3." },
      { id: "q2", prompt: "Which quantity does the base-rate fallacy ignore?", options: ["The likelihood", "The prior", "The complement", "The sample space"], answer: 1, difficulty: 0.4 },
    ],
  },
  {
    id: "random-variables",
    name: "Random variables",
    description: "A function from outcomes to numbers; its distribution (PMF/PDF/CDF).",
    aliases: ["random variable", "pmf", "pdf", "cdf", "distribution", "discrete", "continuous"],
    difficulty: 0.5,
    content: {
      concise: "A random variable X assigns a number to each outcome. Discrete X has a PMF p(x)=P(X=x); continuous X has a PDF f with P(a≤X≤b)=∫ₐᵇf. Both have a CDF F(x)=P(X≤x).",
      detailed:
        "A random variable is not random and not a variable — it is a fixed function from the sample space to the real line. Randomness enters through which outcome occurs. Its distribution summarises P(X∈·). For discrete X the PMF lists point probabilities that sum to 1; for continuous X, individual points have probability 0 and only the density's area matters. The CDF works for both and is always non-decreasing from 0 to 1.",
      example:
        "Flip two coins and let X = number of heads. X maps HH→2, HT→1, TH→1, TT→0. PMF: p(0)=1/4, p(1)=1/2, p(2)=1/4. CDF: F(0)=1/4, F(1)=3/4, F(2)=1.",
      analogy:
        "A random variable is a scoreboard rule: the game (experiment) plays out, and the rule converts what happened into a number. The distribution is the histogram you'd get after playing millions of games.",
      formal: "X: Ω→ℝ measurable. Discrete: pₓ(x)=P(X=x), Σpₓ=1. Continuous: P(X∈B)=∫_B fₓ, ∫fₓ=1. CDF Fₓ(x)=P(X≤x); fₓ=F'ₓ where differentiable.",
      steps:
        "1) Decide what number you attach to each outcome → that's X. 2) Group outcomes by their X value. 3) Add the probabilities in each group → PMF (discrete) or model a density (continuous). 4) Check the total is 1. 5) Cumulate to get the CDF if needed.",
    },
    questions: [
      { id: "q1", prompt: "For a continuous random variable, what is P(X = 2.5) exactly?", options: ["f(2.5)", "F(2.5)", "0", "Undefined"], answer: 2, difficulty: 0.5 },
      { id: "q2", prompt: "X = number of heads in 2 fair flips. P(X ≥ 1) = ?", options: ["1/4", "1/2", "3/4", "1"], answer: 2, difficulty: 0.3 },
    ],
  },
  {
    id: "expectation",
    name: "Expected value",
    description: "The probability-weighted average of a random variable; linearity of expectation.",
    aliases: ["expected value", "expectation", "mean", "average", "E[X]", "linearity"],
    difficulty: 0.45,
    content: {
      concise: "E[X] = Σ x·p(x) (or ∫x f(x)dx). It is linear: E[aX+bY]=aE[X]+bE[Y], always — even when X and Y are dependent.",
      detailed:
        "The expectation is the long-run average value of X: each possible value weighted by how likely it is. It need not be a value X can actually take. The most powerful property is linearity, which lets you compute expectations of complicated sums by breaking them into simple indicator variables without worrying about dependence.",
      example:
        "A die roll: E[X] = (1+2+3+4+5+6)/6 = 3.5. A game pays $10 with prob 0.1 and costs $2 otherwise: E = 10·0.1 + (−2)·0.9 = 1 − 1.8 = −$0.80 per play.",
      analogy:
        "E[X] is the balance point of the distribution: put weights p(x) at positions x on a seesaw and E[X] is where it balances.",
      formal: "E[X]=Σₓ x pₓ(x) for discrete X, ∫x fₓ(x)dx for continuous X, when absolutely convergent. LOTUS: E[g(X)]=Σ g(x)pₓ(x). Linearity: E[ΣaᵢXᵢ]=ΣaᵢE[Xᵢ].",
      steps: "1) List each value x of X. 2) Multiply each by its probability p(x). 3) Add them up. 4) For sums of variables, use linearity instead of the joint distribution.",
    },
    questions: [
      { id: "q1", prompt: "X = 1 with prob 0.3, X = 5 with prob 0.7. E[X] = ?", options: ["3", "3.8", "4.2", "6"], answer: 1, difficulty: 0.3 },
      { id: "q2", prompt: "E[X]=2, E[Y]=3, X and Y dependent. E[X+Y] = ?", options: ["5", "6", "Cannot compute without the joint distribution", "Depends on covariance"], answer: 0, difficulty: 0.5, hint: "Linearity does not need independence." },
    ],
  },
  {
    id: "variance",
    name: "Variance & standard deviation",
    description: "Spread of a random variable around its mean; Var(X)=E[(X−μ)²].",
    aliases: ["variance", "standard deviation", "std", "spread", "Var(X)"],
    difficulty: 0.5,
    content: {
      concise: "Var(X)=E[(X−μ)²]=E[X²]−μ². SD = √Var. Var(aX+b)=a²Var(X). For independent X,Y: Var(X+Y)=Var(X)+Var(Y).",
      detailed:
        "Variance measures how far X typically lands from its mean, using squared distances so that positive and negative deviations don't cancel. Because it is in squared units, the standard deviation (its square root) is used for interpretation. Adding a constant shifts everything and leaves spread unchanged; scaling by a multiplies variance by a². Variances add only for uncorrelated variables.",
      example:
        "Die roll: μ=3.5, E[X²]=(1+4+9+16+25+36)/6=91/6≈15.17. Var=15.17−12.25≈2.92, SD≈1.71. If you double every face, variance becomes 4·2.92≈11.67.",
      analogy: "If expectation is where the seesaw balances, variance is how far out the weights sit — a wide seesaw with weights at the ends has high variance even if it balances at the same point.",
      formal: "Var(X)=E[(X−E X)²]=E[X²]−(E X)². Var(aX+b)=a²Var(X). Var(X+Y)=Var X+Var Y+2Cov(X,Y).",
      steps: "1) Compute μ=E[X]. 2) Compute E[X²]=Σx²p(x). 3) Var=E[X²]−μ². 4) SD=√Var. 5) For linear transforms, apply a² to the variance and ignore the shift b.",
    },
    questions: [
      { id: "q1", prompt: "Var(X)=4. What is Var(3X+7)?", options: ["12", "19", "36", "43"], answer: 2, difficulty: 0.45 },
      { id: "q2", prompt: "E[X]=2, E[X²]=13. Var(X) = ?", options: ["9", "11", "13", "15"], answer: 0, difficulty: 0.35 },
    ],
  },
  {
    id: "binomial-distribution",
    name: "Binomial distribution",
    description: "Number of successes in n independent Bernoulli(p) trials.",
    aliases: ["binomial", "bernoulli", "trials", "successes"],
    difficulty: 0.55,
    content: {
      concise: "X~Bin(n,p): P(X=k)=C(n,k)pᵏ(1−p)ⁿ⁻ᵏ, E[X]=np, Var(X)=np(1−p). Requires fixed n, independent trials, constant p.",
      detailed:
        "Run the same yes/no experiment n times independently with success probability p each time and count the successes. Any particular sequence with k successes has probability pᵏ(1−p)ⁿ⁻ᵏ, and there are C(n,k) such sequences — that is where the binomial coefficient comes from. Its mean and variance follow from linearity because X is a sum of n independent Bernoulli indicators.",
      example:
        "Flip a fair coin 4 times; P(exactly 2 heads) = C(4,2)(1/2)²(1/2)² = 6/16 = 0.375. Expected heads = 4·0.5 = 2.",
      analogy: "It's a tally counter attached to a biased coin: n flips, count the heads. The binomial formula tells you how often each tally value shows up.",
      formal: "X=ΣᵢBᵢ, Bᵢ iid Bernoulli(p). pₓ(k)=C(n,k)pᵏ(1−p)ⁿ⁻ᵏ, k=0..n. E X=np, Var X=np(1−p). Bin(n,p)≈N(np,np(1−p)) for large n (de Moivre–Laplace).",
      steps: "1) Check: fixed n, independent trials, same p. 2) Identify k. 3) Count arrangements C(n,k). 4) Multiply by pᵏ(1−p)ⁿ⁻ᵏ. 5) For mean/variance use np and np(1−p).",
    },
    questions: [
      { id: "q1", prompt: "X~Bin(10, 0.3). E[X] = ?", options: ["0.3", "3", "7", "2.1"], answer: 1, difficulty: 0.3 },
      { id: "q2", prompt: "P(exactly 1 head in 3 fair flips) = ?", options: ["1/8", "3/8", "1/2", "1/3"], answer: 1, difficulty: 0.45, hint: "C(3,1)·(1/2)³." },
    ],
  },
  {
    id: "normal-distribution",
    name: "Normal distribution",
    description: "The bell curve N(μ,σ²); z-scores and the 68–95–99.7 rule.",
    aliases: ["normal", "gaussian", "bell curve", "z-score", "standard normal", "68-95-99.7"],
    difficulty: 0.55,
    content: {
      concise: "X~N(μ,σ²) has a symmetric bell-shaped density. Z=(X−μ)/σ ~N(0,1). About 68% lies within 1σ, 95% within 2σ, 99.7% within 3σ.",
      detailed:
        "The normal distribution is determined entirely by its mean and variance. Standardising with a z-score expresses any value as 'how many standard deviations from the mean', which lets one table serve every normal distribution. Its central role comes from the central limit theorem: sums and averages of many small effects are approximately normal regardless of their individual distributions.",
      example:
        "Heights ~N(170, 10²) cm. A 190 cm person has z = (190−170)/10 = 2, so they are taller than roughly 97.5% of people (95% lie within ±2σ, half of the remaining 5% is above).",
      analogy: "The bell curve is what you get from dropping thousands of balls through a Galton board: each ball takes many small random left/right bumps, and the pile forms a bell.",
      formal: "f(x)=(1/(σ√(2π)))·exp(−(x−μ)²/(2σ²)). If X~N(μ,σ²) then aX+b~N(aμ+b,a²σ²). Sums of independent normals are normal.",
      steps: "1) Identify μ and σ. 2) Convert x to z=(x−μ)/σ. 3) Use the empirical rule or a z-table for P(Z≤z). 4) For 'between' questions subtract two CDF values. 5) Use symmetry: P(Z>z)=P(Z<−z).",
    },
    questions: [
      { id: "q1", prompt: "X~N(50, 5²). What is the z-score of 60?", options: ["1", "2", "10", "0.5"], answer: 1, difficulty: 0.3 },
      { id: "q2", prompt: "Approximately what fraction of a normal distribution lies within 1 SD of the mean?", options: ["50%", "68%", "95%", "99.7%"], answer: 1, difficulty: 0.25 },
    ],
  },
  {
    id: "law-of-large-numbers",
    name: "Law of large numbers",
    description: "Sample averages converge to the expected value as n grows.",
    aliases: ["lln", "large numbers", "sample mean converges", "long run average"],
    difficulty: 0.5,
    content: {
      concise: "If X₁,X₂,… are iid with mean μ, the sample mean X̄ₙ → μ as n→∞. Averages stabilise; individual outcomes don't.",
      detailed:
        "The LLN is the bridge between the abstract expectation and what you observe: averaging many independent draws gets you arbitrarily close to E[X]. It says nothing about any single draw, and it does not imply a 'due' correction after a run of bad luck (the gambler's fallacy) — the average gets swamped, the sum does not get corrected.",
      example:
        "Flip a fair coin. After 10 flips you may see 70% heads; after 10,000 you'll almost surely be within a percent of 50%. The proportion converges; the absolute excess of heads over tails can still grow.",
      analogy: "One raindrop tells you nothing about a storm, but a bucket left out all night measures the rainfall accurately. Averaging drowns out the noise.",
      formal: "Weak LLN: X̄ₙ →ᵖ μ (for all ε, P(|X̄ₙ−μ|>ε)→0). Strong LLN: X̄ₙ → μ almost surely. Requires E|X|<∞; Var finite gives Var(X̄ₙ)=σ²/n → 0 (Chebyshev proof).",
      steps: "1) Confirm the draws are independent with the same distribution. 2) Identify μ=E[X]. 3) Conclude that for large n the observed average ≈ μ. 4) Remember: this is about averages, not individual outcomes.",
    },
    questions: [
      { id: "q1", prompt: "After 5 heads in a row with a fair coin, the probability of tails next is:", options: ["greater than 0.5", "exactly 0.5", "less than 0.5"], answer: 1, difficulty: 0.35 },
      { id: "q2", prompt: "Var(X)=σ². Var of the sample mean of n iid copies?", options: ["σ²", "σ²/n", "nσ²", "σ/√n"], answer: 1, difficulty: 0.5 },
    ],
  },
  {
    id: "central-limit-theorem",
    name: "Central limit theorem",
    description: "Standardised sums/averages of iid variables become approximately normal.",
    aliases: ["clt", "central limit", "sampling distribution of the mean", "standard error"],
    difficulty: 0.7,
    content: {
      concise: "For iid Xᵢ with mean μ and variance σ², (X̄ₙ−μ)/(σ/√n) → N(0,1). Averages are approximately normal for large n regardless of the parent distribution.",
      detailed:
        "The LLN says where the sample mean goes; the CLT says how it fluctuates around that limit: approximately normally, with standard error σ/√n. This is why the normal distribution appears everywhere and why confidence intervals and z/t-tests work. The approximation improves with n and is worse for heavily skewed parents; a rule of thumb is n≈30, but it's only a rule of thumb.",
      example:
        "Roll a die 100 times: μ=3.5, σ≈1.71, so the average is ≈ N(3.5, (0.171)²). Getting an average above 3.85 (z≈2) happens only ~2.5% of the time — even though a single die roll is far from normal.",
      analogy: "Mix many different-coloured paints — whatever colours you start with, if each contributes a small amount you end up with the same muddy brown. Add many small random effects and you get the same bell shape.",
      formal: "√n(X̄ₙ−μ)/σ →ᵈ N(0,1). Equivalently ΣXᵢ ≈ N(nμ, nσ²). Lindeberg–Lévy requires iid with finite variance; Lyapunov/Lindeberg conditions relax identical distribution.",
      steps: "1) Identify μ and σ of a single observation. 2) Compute the standard error σ/√n. 3) Standardise the sample mean: z=(x̄−μ)/(σ/√n). 4) Use the normal table. 5) Check n is large enough for the parent's skew.",
    },
    questions: [
      { id: "q1", prompt: "σ=12, n=36. Standard error of the sample mean?", options: ["12", "2", "0.33", "6"], answer: 1, difficulty: 0.45 },
      { id: "q2", prompt: "The CLT applies to the distribution of:", options: ["a single observation", "the sample mean", "the sample variance only", "the population"], answer: 1, difficulty: 0.4 },
    ],
  },
  {
    id: "hypothesis-testing",
    name: "Hypothesis testing",
    description: "Null/alternative hypotheses, p-values, significance level, type I/II errors.",
    aliases: ["hypothesis test", "p-value", "p value", "null hypothesis", "significance", "type i error", "type ii error"],
    difficulty: 0.75,
    content: {
      concise: "Assume H₀; compute how surprising the data would be under H₀ (the p-value); reject H₀ if p < α. Type I error = false rejection (rate α); type II = failing to reject a false H₀.",
      detailed:
        "A hypothesis test is a proof by contradiction with probabilities. You tentatively assume the null hypothesis, derive the sampling distribution of a test statistic (often via the CLT), and ask how extreme the observed statistic is. The p-value is P(data at least this extreme | H₀) — it is NOT the probability H₀ is true. α fixes the false-alarm rate you tolerate; power = 1 − P(type II error) depends on effect size and n.",
      example:
        "A coin is flipped 100 times and shows 62 heads. Under H₀: p=0.5, heads ≈ N(50, 5²), z=(62−50)/5=2.4, two-sided p≈0.016. At α=0.05 we reject fairness; at α=0.01 we would not.",
      analogy: "It is a courtroom: H₀ is 'innocent', evidence must be strong enough (p<α) to convict. A type I error convicts an innocent; a type II error acquits a guilty person. 'Not guilty' is not 'proven innocent'.",
      formal: "Test statistic T with known distribution under H₀. p = P_{H₀}(T ≥ t_obs) (or two-sided). Reject iff p<α ⇔ t_obs in rejection region. P(type I)=α. Power(θ)=P_θ(reject).",
      steps: "1) State H₀ and H₁. 2) Choose α. 3) Compute the test statistic and its null distribution. 4) Compute the p-value. 5) Reject H₀ if p<α; otherwise fail to reject. 6) Interpret in context, noting the error you might be making.",
    },
    questions: [
      { id: "q1", prompt: "A p-value of 0.03 means:", options: ["P(H₀ is true)=0.03", "P(data this extreme | H₀)=0.03", "P(H₁ is true)=0.97", "3% of the data is extreme"], answer: 1, difficulty: 0.6 },
      { id: "q2", prompt: "Rejecting a true null hypothesis is a:", options: ["Type I error", "Type II error", "Power", "p-value"], answer: 0, difficulty: 0.4 },
    ],
  },
];

export const SEED_CONCEPTS: ConceptNode[] = C.map((c) => ({ ...c, domain: D }));

const P = (from: string, to: string, weight = 1): ConceptEdge => ({ fromId: from, toId: to, type: "prerequisite", weight });
const R = (a: string, b: string, weight = 0.5): ConceptEdge => ({ fromId: a, toId: b, type: "related", weight });

export const SEED_EDGES: ConceptEdge[] = [
  P("sample-spaces", "probability-axioms"),
  P("counting", "probability-axioms", 0.6),
  P("probability-axioms", "conditional-probability"),
  P("conditional-probability", "independence"),
  P("conditional-probability", "bayes-theorem"),
  P("probability-axioms", "random-variables"),
  P("random-variables", "expectation"),
  P("expectation", "variance"),
  P("random-variables", "binomial-distribution"),
  P("independence", "binomial-distribution", 0.8),
  P("counting", "binomial-distribution", 0.5),
  P("variance", "normal-distribution"),
  P("expectation", "law-of-large-numbers"),
  P("variance", "law-of-large-numbers", 0.6),
  P("normal-distribution", "central-limit-theorem"),
  P("law-of-large-numbers", "central-limit-theorem"),
  P("central-limit-theorem", "hypothesis-testing"),
  P("conditional-probability", "hypothesis-testing", 0.6),
  R("independence", "bayes-theorem"),
  R("binomial-distribution", "normal-distribution"),
  R("bayes-theorem", "hypothesis-testing"),
];
