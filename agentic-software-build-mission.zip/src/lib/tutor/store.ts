import { db } from "@/db";
import {
  concepts,
  conceptEdges,
  decisions,
  interactions,
  learnerAffect,
  learnerConceptState,
  learnerPreferences,
  learners,
  sessions,
  type AffectVector,
  type PendingQuestion,
} from "@/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { NEUTRAL_AFFECT } from "./affect";
import { SEED_CONCEPTS, SEED_EDGES } from "./domain";
import { defaultPreferences } from "./preferences";
import type { Graph } from "./policy";
import { STYLES, type ConceptEdge, type ConceptNode, type ConceptState, type LearnerModel, type PolicyDecision, type PreferenceArm, type Style } from "./types";

// ---------- Seeding ----------
let seedPromise: Promise<void> | null = null;
export function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = (async () => {
      const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(concepts);
      if (n > 0) return;
      await db.insert(concepts).values(SEED_CONCEPTS).onConflictDoNothing();
      await db.insert(conceptEdges).values(SEED_EDGES).onConflictDoNothing();
    })().catch((e) => {
      seedPromise = null;
      throw e;
    });
  }
  return seedPromise;
}

// ---------- Graph ----------
export async function loadGraph(): Promise<Graph> {
  await ensureSeeded();
  const rows = await db.select().from(concepts);
  const edges = await db.select().from(conceptEdges);
  const map = new Map<string, ConceptNode>();
  for (const r of rows) {
    map.set(r.id, { id: r.id, domain: r.domain, name: r.name, description: r.description, aliases: r.aliases, difficulty: r.difficulty, content: r.content, questions: r.questions });
  }
  return { concepts: map, edges: edges.map((e) => ({ fromId: e.fromId, toId: e.toId, type: e.type as ConceptEdge["type"], weight: e.weight })) };
}

export async function addConcept(node: ConceptNode, edges: ConceptEdge[]): Promise<void> {
  await ensureSeeded();
  await db
    .insert(concepts)
    .values(node)
    .onConflictDoUpdate({ target: concepts.id, set: { name: node.name, description: node.description, aliases: node.aliases, difficulty: node.difficulty, content: node.content, questions: node.questions } });
  if (edges.length) await db.insert(conceptEdges).values(edges).onConflictDoNothing();
}

// ---------- Learner model ----------
export async function ensureLearner(id: string, name?: string): Promise<void> {
  await db.insert(learners).values({ id, name: name ?? "Learner" }).onConflictDoNothing();
}

export async function getLearnerName(id: string): Promise<string> {
  const [l] = await db.select().from(learners).where(eq(learners.id, id));
  return l?.name ?? "Learner";
}

export async function loadModel(learnerId: string): Promise<LearnerModel> {
  await ensureLearner(learnerId);
  const [states, prefs, affectRows] = await Promise.all([
    db.select().from(learnerConceptState).where(eq(learnerConceptState.learnerId, learnerId)),
    db.select().from(learnerPreferences).where(and(eq(learnerPreferences.learnerId, learnerId), eq(learnerPreferences.dimension, "style"))),
    db.select().from(learnerAffect).where(eq(learnerAffect.learnerId, learnerId)),
  ]);
  const conceptMap = new Map<string, ConceptState>();
  for (const s of states) {
    conceptMap.set(s.conceptId, {
      conceptId: s.conceptId,
      pKnown: s.pKnown,
      evidence: s.evidence,
      correct: s.correct,
      incorrect: s.incorrect,
      confusionEvents: s.confusionEvents,
      activation: s.activation,
      status: s.status as ConceptState["status"],
      lastStyle: s.lastStyle,
      lastInteractionAt: s.lastInteractionAt,
      lastMasteryUpdateAt: s.lastMasteryUpdateAt,
    });
  }
  const prefMap = defaultPreferences();
  for (const p of prefs) {
    if ((STYLES as readonly string[]).includes(p.arm)) prefMap.set(p.arm as Style, { arm: p.arm as Style, alpha: p.alpha, beta: p.beta, trials: p.trials });
  }
  const affect = affectRows[0]?.state ?? { ...NEUTRAL_AFFECT };
  return { learnerId, concepts: conceptMap, preferences: prefMap, affect, pace: affectRows[0]?.pace ?? 0.5 };
}

export async function saveConceptStates(learnerId: string, states: ConceptState[]): Promise<void> {
  for (const s of states) {
    await db
      .insert(learnerConceptState)
      .values({ learnerId, ...s, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: [learnerConceptState.learnerId, learnerConceptState.conceptId],
        set: {
          pKnown: s.pKnown,
          evidence: s.evidence,
          correct: s.correct,
          incorrect: s.incorrect,
          confusionEvents: s.confusionEvents,
          activation: s.activation,
          status: s.status,
          lastStyle: s.lastStyle,
          lastInteractionAt: s.lastInteractionAt,
          lastMasteryUpdateAt: s.lastMasteryUpdateAt,
          updatedAt: new Date(),
        },
      });
  }
}

export async function savePreferences(learnerId: string, arms: PreferenceArm[]): Promise<void> {
  for (const a of arms) {
    await db
      .insert(learnerPreferences)
      .values({ learnerId, dimension: "style", arm: a.arm, alpha: a.alpha, beta: a.beta, trials: a.trials, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: [learnerPreferences.learnerId, learnerPreferences.dimension, learnerPreferences.arm],
        set: { alpha: a.alpha, beta: a.beta, trials: a.trials, updatedAt: new Date() },
      });
  }
}

export async function saveAffect(learnerId: string, state: AffectVector, pace: number): Promise<void> {
  await db
    .insert(learnerAffect)
    .values({ learnerId, state, pace, updatedAt: new Date() })
    .onConflictDoUpdate({ target: learnerAffect.learnerId, set: { state, pace, updatedAt: new Date() } });
}

// ---------- Sessions ----------
export type SessionRow = typeof sessions.$inferSelect;

export async function getOrCreateSession(sessionId: string, learnerId: string): Promise<SessionRow> {
  await ensureLearner(learnerId);
  const [existing] = await db.select().from(sessions).where(eq(sessions.id, sessionId));
  if (existing) return existing;
  const [created] = await db.insert(sessions).values({ id: sessionId, learnerId }).returning();
  return created;
}

export async function updateSession(
  sessionId: string,
  patch: Partial<{ currentConceptId: string | null; pendingQuestion: PendingQuestion | null; lastExplainedConceptId: string | null; lastExplainedStyle: string | null; turnCount: number }>,
): Promise<void> {
  await db.update(sessions).set({ ...patch, lastActiveAt: new Date() }).where(eq(sessions.id, sessionId));
}

// ---------- Interactions & decisions ----------
export async function addInteraction(row: {
  sessionId: string;
  learnerId: string;
  role: "user" | "tutor" | "external";
  kind: string;
  content: string;
  conceptId?: string | null;
  style?: string | null;
  meta?: Record<string, unknown>;
}): Promise<number> {
  const [r] = await db.insert(interactions).values({ ...row, meta: row.meta ?? {} }).returning({ id: interactions.id });
  return r.id;
}

export async function addDecision(row: { sessionId: string; learnerId: string; decision: PolicyDecision; snapshot: Record<string, unknown> }): Promise<void> {
  await db.insert(decisions).values({
    sessionId: row.sessionId,
    learnerId: row.learnerId,
    action: row.decision.action,
    conceptId: row.decision.conceptId,
    style: row.decision.style,
    rationale: row.decision.rationale,
    stateSnapshot: row.snapshot,
  });
}

export async function recentInteractions(learnerId: string, limit = 50, sessionId?: string) {
  const where = sessionId ? and(eq(interactions.learnerId, learnerId), eq(interactions.sessionId, sessionId)) : eq(interactions.learnerId, learnerId);
  const rows = await db.select().from(interactions).where(where).orderBy(desc(interactions.createdAt), desc(interactions.id)).limit(limit);
  return rows.reverse();
}

export async function recentDecisions(learnerId: string, limit = 20) {
  return db.select().from(decisions).where(eq(decisions.learnerId, learnerId)).orderBy(desc(decisions.createdAt), desc(decisions.id)).limit(limit);
}

export async function sessionInteractionCounts(sessionId: string): Promise<{ explainsByConcept: Map<string, number>; lastBreakTurn: number | null }> {
  const rows = await db
    .select({ conceptId: interactions.conceptId, kind: interactions.kind, id: interactions.id })
    .from(interactions)
    .where(and(eq(interactions.sessionId, sessionId), eq(interactions.role, "tutor")));
  const explainsByConcept = new Map<string, number>();
  let lastBreakTurn: number | null = null;
  rows.forEach((r, i) => {
    if (r.conceptId && ["explain", "simplify", "switch_strategy", "advance", "revisit_prerequisite"].includes(r.kind)) {
      explainsByConcept.set(r.conceptId, (explainsByConcept.get(r.conceptId) ?? 0) + 1);
    }
    if (r.kind === "suggest_break") lastBreakTurn = i;
  });
  return { explainsByConcept, lastBreakTurn };
}

export async function resetLearner(learnerId: string): Promise<void> {
  await db.delete(learners).where(eq(learners.id, learnerId)); // cascades
  await ensureLearner(learnerId);
}
