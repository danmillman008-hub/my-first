import type { ConceptQuestion, PendingQuestion } from "@/db/schema";
import { behaviouralAffect, dominantAffect, updateAffect } from "./affect";
import { analyzeMessage } from "./analyze";
import { composeResponse } from "./compose";
import { decayedActivation, reclassify, touch } from "./dormancy";
import { applyForgetting, defaultConceptState, masteryLevel, observe, prerequisitesOf, readiness, uncertainty, type EvidenceKind } from "./mastery";
import { decide, recommendNext, type Graph, type SessionContext } from "./policy";
import { rankedPreferences, recordOutcome } from "./preferences";
import * as store from "./store";
import { STYLES, type ConceptState, type LearnerModel, type PolicyDecision, type Style } from "./types";

const EXPLAIN_ACTIONS = new Set(["explain", "simplify", "switch_strategy", "deepen", "give_example", "revisit_prerequisite", "advance", "slow_down"]);

function getState(model: LearnerModel, graph: Graph, id: string): ConceptState {
  let s = model.concepts.get(id);
  if (!s) {
    s = defaultConceptState(id, graph.concepts.get(id)?.difficulty ?? 0.5);
    model.concepts.set(id, s);
  }
  return s;
}

function pickQuestion(graph: Graph, conceptId: string, askedIds: string[]): ConceptQuestion | null {
  const qs = graph.concepts.get(conceptId)?.questions ?? [];
  if (qs.length === 0) return null;
  const counts = qs.map((q) => askedIds.filter((id) => id === `${conceptId}:${q.id}`).length);
  const min = Math.min(...counts);
  return qs[counts.indexOf(min)];
}

export type TurnResult = {
  reply: string;
  renderer: "template" | "llm";
  decision: PolicyDecision;
  analysis: { intent: string; conceptIds: string[]; answerIndex: number | null };
  graded: { conceptId: string; correct: boolean; pKnown: number } | null;
  snapshot: Awaited<ReturnType<typeof getSnapshot>>;
};

export async function handleMessage(input: { learnerId: string; sessionId: string; text: string; latencyMs?: number | null; rnd?: () => number }): Promise<TurnResult> {
  const now = new Date();
  const { learnerId, sessionId } = input;
  const text = input.text.trim().slice(0, 4000);
  const [graph, model, session, learnerName, history] = await Promise.all([
    store.loadGraph(),
    store.loadModel(learnerId),
    store.getOrCreateSession(sessionId, learnerId),
    store.getLearnerName(learnerId),
    store.recentInteractions(learnerId, 30, sessionId),
  ]);
  const touched = new Set<string>();
  const touchedPrefs = new Set<Style>();
  const st = (id: string) => getState(model, graph, id);
  const mark = (id: string) => touched.add(id);

  // apply forgetting to every known state before reasoning (mastery is time-aware)
  for (const s of model.concepts.values()) {
    const decayed = applyForgetting(s, now);
    if (Math.abs(decayed - s.pKnown) > 1e-6) {
      s.pKnown = decayed;
      mark(s.conceptId);
    }
  }

  const pending = session.pendingQuestion ?? null;
  const pendingQ = pending ? graph.concepts.get(pending.conceptId)?.questions.find((q) => q.id === pending.questionId) ?? null : null;
  const analysis = analyzeMessage(text, [...graph.concepts.values()], { pendingOptions: pendingQ?.options ?? null, latencyMs: input.latencyMs ?? null });

  const lastExplainedConceptId = session.lastExplainedConceptId;
  const lastExplainedStyle = (session.lastExplainedStyle as Style | null) ?? null;
  const focus = analysis.conceptIds[0] ?? pending?.conceptId ?? session.currentConceptId ?? lastExplainedConceptId ?? null;

  // ---------- 1. evidence → learner state ----------
  let graded: SessionContext["graded"] = null;
  let gradedInfo: { concept: NonNullable<ReturnType<Graph["concepts"]["get"]>>; correct: boolean; correctText: string; hint?: string } | null = null;
  let answerCorrect: boolean | null = null;
  let nextPending: PendingQuestion | null = pending;
  const prefOutcome = (style: Style | null, success: boolean, weight: number) => {
    if (!style) return;
    const arm = model.preferences.get(style);
    if (!arm) return;
    model.preferences.set(style, recordOutcome(arm, success, weight));
    touchedPrefs.add(style);
  };

  if (pending && pendingQ && analysis.answerIndex !== null) {
    const correct = analysis.answerIndex === pendingQ.answer;
    answerCorrect = correct;
    const before = st(pending.conceptId);
    const after = observe(before, correct ? "quiz_correct" : "quiz_incorrect", { difficulty: pendingQ.difficulty, now });
    model.concepts.set(pending.conceptId, touch(after, 1, now));
    mark(pending.conceptId);
    if (correct) {
      // success implies prerequisites are (weakly) in place
      for (const p of prerequisitesOf(pending.conceptId, graph.edges)) {
        model.concepts.set(p.id, observe(st(p.id), "prereq_inferred_positive", { now }));
        mark(p.id);
      }
    }
    // the style used to explain this concept gets credit/blame
    if (pending.styleUsed && (STYLES as readonly string[]).includes(pending.styleUsed)) prefOutcome(pending.styleUsed as Style, correct, 1);
    const wasPrereqCheck = !!session.currentConceptId && session.currentConceptId !== pending.conceptId;
    graded = { conceptId: pending.conceptId, correct, wasPrereqCheck };
    gradedInfo = { concept: graph.concepts.get(pending.conceptId)!, correct, correctText: pendingQ.options[pendingQ.answer], hint: pendingQ.hint };
    nextPending = null;
  } else if (pending && analysis.intent !== "chat") {
    // learner moved on without answering → drop the pending question
    nextPending = null;
  }

  if (!graded) {
    switch (analysis.intent) {
      case "confirm":
        if (lastExplainedConceptId) {
          model.concepts.set(lastExplainedConceptId, touch(observe(st(lastExplainedConceptId), "confirmation", { now }), 0.5, now));
          mark(lastExplainedConceptId);
          prefOutcome(lastExplainedStyle, true, 0.5);
        }
        break;
      case "confusion":
        if (focus) {
          model.concepts.set(focus, touch(observe(st(focus), "confusion", { now }), 0.7, now));
          mark(focus);
          if (focus === lastExplainedConceptId) prefOutcome(lastExplainedStyle, false, 0.7);
        }
        break;
      case "ask_simpler":
        if (focus === lastExplainedConceptId) prefOutcome(lastExplainedStyle, false, 0.5);
        break;
      case "ask_deeper":
        if (focus === lastExplainedConceptId) prefOutcome(lastExplainedStyle, true, 0.3);
        break;
      default:
        break;
    }
    const selfReportTarget = analysis.conceptIds[0] ?? focus;
    if (/\b(already know|i know this|i'?ve done this|familiar with)\b/i.test(text) && selfReportTarget) {
      model.concepts.set(selfReportTarget, observe(st(selfReportTarget), "self_report_known", { now }));
      mark(selfReportTarget);
    }
  }
  for (const id of analysis.conceptIds) {
    model.concepts.set(id, touch(st(id), 0.6, now));
    mark(id);
  }

  // ---------- 2. affect ----------
  const recentUser = history.filter((h) => h.role === "user");
  let incorrectStreak = 0;
  let correctStreak = 0;
  for (let i = recentUser.length - 1; i >= 0; i--) {
    const g = (recentUser[i].meta as { graded?: { correct: boolean } }).graded;
    if (!g) continue;
    if (g.correct && incorrectStreak === 0) correctStreak++;
    else if (!g.correct && correctStreak === 0) incorrectStreak++;
    else break;
  }
  if (answerCorrect === true) { correctStreak++; incorrectStreak = 0; }
  if (answerCorrect === false) { incorrectStreak++; correctStreak = 0; }
  const sessionMinutes = (now.getTime() - session.startedAt.getTime()) / 60_000;
  const behaviour = behaviouralAffect({
    answerCorrect,
    correctStreak,
    incorrectStreak,
    latencyMs: input.latencyMs ?? null,
    repeatedConcept: analysis.intent === "ask_concept" && !!analysis.conceptIds[0] && analysis.conceptIds[0] === lastExplainedConceptId,
    sessionTurns: session.turnCount + 1,
    sessionMinutes,
  });
  model.affect = updateAffect(model.affect, analysis.affectSignals, behaviour);
  // pace preference drifts with explicit signals
  if (analysis.intent === "ask_next" || model.affect.boredom > 0.55) model.pace = Math.min(1, model.pace + 0.05);
  if (analysis.intent === "ask_simpler" || analysis.intent === "confusion" || model.affect.frustration > 0.5) model.pace = Math.max(0, model.pace - 0.05);

  // ---------- 3. dormancy housekeeping ----------
  for (const s of model.concepts.values()) {
    const re = reclassify(s, now);
    if (re.status !== s.status) {
      model.concepts.set(s.conceptId, re);
      mark(s.conceptId);
    }
  }

  // ---------- 4. policy ----------
  const counts = await store.sessionInteractionCounts(sessionId);
  const ctx: SessionContext = {
    currentConceptId: session.currentConceptId,
    lastExplainedConceptId,
    lastExplainedStyle,
    turnCount: session.turnCount + 1,
    breakSuggestedRecently: counts.lastBreakTurn !== null && history.length - counts.lastBreakTurn < 12,
    explainCountForConcept: session.currentConceptId ? counts.explainsByConcept.get(session.currentConceptId) ?? 0 : 0,
    graded,
  };
  const decision = decide(model, graph, analysis, ctx, input.rnd);

  // ---------- 5. execute decision ----------
  let currentConceptId = session.currentConceptId;
  let newLastExplained = lastExplainedConceptId;
  let newLastStyle: string | null = lastExplainedStyle;
  let question: ConceptQuestion | null = null;
  const askedIds = history.filter((h) => h.role === "tutor" && (h.meta as { questionKey?: string }).questionKey).map((h) => (h.meta as { questionKey: string }).questionKey);

  if (decision.conceptId) {
    const c = decision.conceptId;
    if (decision.action === "diagnostic_question") {
      // prerequisite check on the way to a goal: keep the goal as current concept
      const goal = analysis.intent === "ask_concept" && analysis.conceptIds[0] && analysis.conceptIds[0] !== c ? analysis.conceptIds[0] : null;
      if (goal) currentConceptId = goal;
      else if (!currentConceptId || (graded && graded.conceptId === c)) currentConceptId = c;
      else if (analysis.intent === "ask_quiz" || analysis.intent === "confirm") currentConceptId = c;
    } else if (decision.action === "revisit_prerequisite") {
      // the learner's goal stays the concept they asked about; we explain the prerequisite on the way
      const asked = analysis.intent === "ask_concept" ? analysis.conceptIds[0] : null;
      if (asked && asked !== c) currentConceptId = asked;
      else if (!currentConceptId) currentConceptId = c;
    } else if (EXPLAIN_ACTIONS.has(decision.action)) {
      currentConceptId = c;
    }
    if (EXPLAIN_ACTIONS.has(decision.action)) {
      newLastExplained = c;
      newLastStyle = decision.style;
      const s = st(c);
      model.concepts.set(c, touch({ ...s, lastStyle: decision.style }, 1, now));
      mark(c);
    }
    if (decision.action === "diagnostic_question" || decision.followUpQuestion) {
      question = pickQuestion(graph, c, askedIds);
      if (question) {
        nextPending = { conceptId: c, questionId: question.id, askedAt: now.toISOString(), styleUsed: EXPLAIN_ACTIONS.has(decision.action) ? decision.style : newLastExplained === c ? newLastStyle : null };
        model.concepts.set(c, touch(st(c), 0.5, now));
        mark(c);
      }
    }
  }
  const goalConcept = currentConceptId && currentConceptId !== decision.conceptId ? graph.concepts.get(currentConceptId) ?? null : null;

  // ---------- 6. compose ----------
  const { text: reply, renderer } = await composeResponse({
    decision,
    concept: decision.conceptId ? graph.concepts.get(decision.conceptId) ?? null : null,
    goalConcept,
    question,
    graded: gradedInfo,
    model,
    learnerName,
    userMessage: text,
  });

  // ---------- 7. persist ----------
  await store.addInteraction({
    sessionId,
    learnerId,
    role: "user",
    kind: analysis.intent,
    content: text,
    conceptId: focus,
    meta: { conceptIds: analysis.conceptIds, affectSignals: analysis.affectSignals, graded: graded ? { conceptId: graded.conceptId, correct: graded.correct } : undefined, latencyMs: input.latencyMs ?? null },
  });
  await store.addInteraction({
    sessionId,
    learnerId,
    role: "tutor",
    kind: decision.action,
    content: reply,
    conceptId: decision.conceptId,
    style: decision.style,
    meta: { rationale: decision.rationale, questionKey: question && decision.conceptId ? `${decision.conceptId}:${question.id}` : undefined, renderer },
  });
  await store.addDecision({
    sessionId,
    learnerId,
    decision,
    snapshot: { affect: model.affect, pace: model.pace, focus, mastery: decision.conceptId ? st(decision.conceptId).pKnown : null },
  });
  await Promise.all([
    store.saveConceptStates(learnerId, [...touched].map((id) => st(id))),
    store.savePreferences(learnerId, [...touchedPrefs].map((s) => model.preferences.get(s)!)),
    store.saveAffect(learnerId, model.affect, model.pace),
    store.updateSession(sessionId, { currentConceptId, pendingQuestion: nextPending, lastExplainedConceptId: newLastExplained, lastExplainedStyle: newLastStyle, turnCount: session.turnCount + 1 }),
  ]);

  const snapshot = await getSnapshot(learnerId, { graph, model });
  return {
    reply,
    renderer,
    decision,
    analysis: { intent: analysis.intent, conceptIds: analysis.conceptIds, answerIndex: analysis.answerIndex },
    graded: graded ? { conceptId: graded.conceptId, correct: graded.correct, pKnown: st(graded.conceptId).pKnown } : null,
    snapshot,
  };
}

// ---------- Snapshot (used by UI, REST and MCP) ----------
export async function getSnapshot(learnerId: string, pre?: { graph: Graph; model: LearnerModel }) {
  const graph = pre?.graph ?? (await store.loadGraph());
  const model = pre?.model ?? (await store.loadModel(learnerId));
  const now = new Date();
  const conceptsOut = [...graph.concepts.values()].map((c) => {
    const raw = model.concepts.get(c.id) ?? defaultConceptState(c.id, c.difficulty);
    const s = reclassify({ ...raw, pKnown: applyForgetting(raw, now) }, now);
    const r = readiness(c.id, graph.edges, (id) => model.concepts.get(id) ?? defaultConceptState(id, graph.concepts.get(id)?.difficulty ?? 0.5));
    return {
      id: c.id,
      name: c.name,
      difficulty: c.difficulty,
      pKnown: Number(s.pKnown.toFixed(3)),
      uncertainty: Number(uncertainty(s).toFixed(3)),
      level: masteryLevel(s),
      evidence: s.evidence,
      correct: s.correct,
      incorrect: s.incorrect,
      confusionEvents: s.confusionEvents,
      activation: Number(decayedActivation(s, now).toFixed(3)),
      status: s.status,
      readiness: Number(r.score.toFixed(3)),
      lastStyle: s.lastStyle,
      lastInteractionAt: s.lastInteractionAt?.toISOString() ?? null,
    };
  });
  const recs = recommendNext(model, graph, { limit: 5 });
  return {
    learnerId,
    affect: Object.fromEntries(Object.entries(model.affect).map(([k, v]) => [k, Number(v.toFixed(3))])) as LearnerModel["affect"],
    dominantAffect: dominantAffect(model.affect),
    pace: Number(model.pace.toFixed(3)),
    preferences: rankedPreferences(model.preferences).map((p) => ({ ...p, mean: Number(p.mean.toFixed(3)) })),
    concepts: conceptsOut,
    edges: graph.edges,
    recommendations: recs.map((r) => ({ ...r, score: Number(r.score.toFixed(3)), pKnown: Number(r.pKnown.toFixed(3)) })),
  };
}

/** External evidence entry point (used by MCP `record_evidence`). */
export async function recordEvidence(input: { learnerId: string; conceptId: string; kind: EvidenceKind; style?: Style | null; note?: string }): Promise<{ pKnown: number; level: string }> {
  const [graph, model] = await Promise.all([store.loadGraph(), store.loadModel(input.learnerId)]);
  if (!graph.concepts.has(input.conceptId)) throw new Error(`Unknown concept: ${input.conceptId}`);
  const now = new Date();
  const c = graph.concepts.get(input.conceptId)!;
  const next = touch(observe(getState(model, graph, input.conceptId), input.kind, { difficulty: c.difficulty, now }), 1, now);
  next.lastStyle = input.style ?? next.lastStyle;
  const saves: Promise<unknown>[] = [store.saveConceptStates(input.learnerId, [next])];
  if (input.style && (STYLES as readonly string[]).includes(input.style)) {
    const positive = input.kind === "quiz_correct" || input.kind === "confirmation" || input.kind === "self_report_known";
    const arm = recordOutcome(model.preferences.get(input.style)!, positive, input.kind.startsWith("quiz") ? 1 : 0.5);
    saves.push(store.savePreferences(input.learnerId, [arm]));
  }
  const session = await store.getOrCreateSession(`external-${input.learnerId}`, input.learnerId);
  saves.push(store.addInteraction({ sessionId: session.id, learnerId: input.learnerId, role: "external", kind: input.kind, content: input.note ?? `external evidence: ${input.kind}`, conceptId: input.conceptId, style: input.style ?? null }));
  await Promise.all(saves);
  return { pKnown: next.pKnown, level: masteryLevel(next) };
}
