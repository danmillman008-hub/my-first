import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { getSnapshot, handleMessage, recordEvidence } from "@/lib/tutor/engine";
import * as store from "@/lib/tutor/store";
import { STYLES, type ConceptEdge } from "@/lib/tutor/types";

/**
 * MCP = standardized access layer. Every tool delegates to the adaptive core (engine/store);
 * no pedagogical decisions live here. Stateless: a fresh server is built per HTTP request.
 */

const json = (data: unknown) => ({ content: [{ type: "text" as const, text: JSON.stringify(data, null, 2) }], structuredContent: data as Record<string, unknown> });
const EVIDENCE_KINDS = ["quiz_correct", "quiz_incorrect", "confirmation", "confusion", "self_report_known", "self_report_unknown"] as const;

export function createMcpServer(): McpServer {
  const server = new McpServer({ name: "adaptive-tutor", version: "1.0.0" }, { instructions: "Tools for reading and updating a private adaptive learner model (concept graph, mastery, preferences, affect) and for delegating tutoring turns to the adaptive core." });

  server.registerTool(
    "get_learner_state",
    {
      title: "Get learner state",
      description: "Full learner model: per-concept mastery (BKT probability, uncertainty, level, dormancy status), explanation-style preferences, affect vector, pace and next-step recommendations.",
      inputSchema: { learnerId: z.string().default("default").describe("Learner identifier") },
    },
    async ({ learnerId }) => {
      const s = await getSnapshot(learnerId);
      return json({ learnerId: s.learnerId, affect: s.affect, dominantAffect: s.dominantAffect, pace: s.pace, preferences: s.preferences, recommendations: s.recommendations, concepts: s.concepts.map(({ id, name, pKnown, uncertainty, level, evidence, status, readiness, activation }) => ({ id, name, pKnown, uncertainty, level, evidence, status, readiness, activation })) });
    },
  );

  server.registerTool(
    "get_concept_graph",
    {
      title: "Get concept graph",
      description: "Concepts (id, name, description, difficulty, aliases) and typed edges (prerequisite | related | part_of).",
      inputSchema: {},
    },
    async () => {
      const g = await store.loadGraph();
      return json({ concepts: [...g.concepts.values()].map(({ id, name, description, difficulty, aliases, domain }) => ({ id, name, description, difficulty, aliases, domain })), edges: g.edges });
    },
  );

  server.registerTool(
    "get_concept",
    {
      title: "Get concept content",
      description: "Explanations of a concept in every style (concise, detailed, example, analogy, formal, steps) plus diagnostic questions with answer keys and the learner's current state on it.",
      inputSchema: { conceptId: z.string(), learnerId: z.string().default("default") },
    },
    async ({ conceptId, learnerId }) => {
      const [g, s] = await Promise.all([store.loadGraph(), getSnapshot(learnerId)]);
      const c = g.concepts.get(conceptId);
      if (!c) return { content: [{ type: "text" as const, text: `Unknown concept: ${conceptId}` }], isError: true };
      const prereqs = g.edges.filter((e) => e.type === "prerequisite" && e.toId === conceptId).map((e) => e.fromId);
      return json({ ...c, prerequisites: prereqs, learnerState: s.concepts.find((x) => x.id === conceptId) ?? null, recommendedStyle: s.preferences[0]?.style ?? "concise" });
    },
  );

  server.registerTool(
    "get_recommendations",
    {
      title: "Get recommendations",
      description: "Ranked next concepts to study for a learner, with reasons (readiness, mastery gap, dormancy).",
      inputSchema: { learnerId: z.string().default("default"), limit: z.number().int().min(1).max(20).default(5) },
    },
    async ({ learnerId, limit }) => {
      const s = await getSnapshot(learnerId);
      return json({ recommendations: s.recommendations.slice(0, limit), preferredStyles: s.preferences.slice(0, 3), affect: s.dominantAffect });
    },
  );

  server.registerTool(
    "record_evidence",
    {
      title: "Record learning evidence",
      description: "Record evidence about a learner on a concept observed outside the tutor UI (e.g. an external assistant quizzed them). Updates BKT mastery and, if a style is given, the style preference model.",
      inputSchema: {
        learnerId: z.string().default("default"),
        conceptId: z.string(),
        kind: z.enum(EVIDENCE_KINDS),
        style: z.enum(STYLES).optional().describe("Explanation style that preceded this evidence"),
        note: z.string().max(500).optional(),
      },
    },
    async (args) => {
      const r = await recordEvidence({ learnerId: args.learnerId, conceptId: args.conceptId, kind: args.kind, style: args.style ?? null, note: args.note });
      return json({ ok: true, conceptId: args.conceptId, ...r });
    },
  );

  server.registerTool(
    "tutor_turn",
    {
      title: "Run an adaptive tutoring turn",
      description: "Send a learner message through the adaptive core. Returns the tutor's personalized reply, the policy decision and rationale, and the updated learner state. Use this to delegate pedagogy to the core.",
      inputSchema: { learnerId: z.string().default("default"), sessionId: z.string().default("mcp-session"), message: z.string().min(1).max(4000) },
    },
    async ({ learnerId, sessionId, message }) => {
      const r = await handleMessage({ learnerId, sessionId, text: message });
      return json({ reply: r.reply, decision: r.decision, analysis: r.analysis, graded: r.graded, affect: r.snapshot.affect, recommendations: r.snapshot.recommendations.slice(0, 3) });
    },
  );

  server.registerTool(
    "get_interaction_history",
    {
      title: "Get interaction history",
      description: "Recent interactions (user, tutor, external) and policy decisions with rationale for a learner.",
      inputSchema: { learnerId: z.string().default("default"), limit: z.number().int().min(1).max(200).default(30) },
    },
    async ({ learnerId, limit }) => {
      const [hist, decs] = await Promise.all([store.recentInteractions(learnerId, limit), store.recentDecisions(learnerId, Math.min(limit, 50))]);
      return json({
        interactions: hist.map((h) => ({ id: h.id, role: h.role, kind: h.kind, conceptId: h.conceptId, style: h.style, content: h.content.slice(0, 400), createdAt: h.createdAt })),
        decisions: decs.map((d) => ({ id: d.id, action: d.action, conceptId: d.conceptId, style: d.style, rationale: d.rationale, createdAt: d.createdAt })),
      });
    },
  );

  server.registerTool(
    "add_concept",
    {
      title: "Add or update a concept",
      description: "Extend the concept graph with a new concept (content per style, diagnostic questions) and its prerequisite/related edges.",
      inputSchema: {
        id: z.string().regex(/^[a-z0-9-]+$/),
        name: z.string(),
        description: z.string(),
        domain: z.string().default("Custom"),
        difficulty: z.number().min(0).max(1).default(0.5),
        aliases: z.array(z.string()).default([]),
        content: z.record(z.string(), z.string()).default({}),
        questions: z.array(z.object({ id: z.string(), prompt: z.string(), options: z.array(z.string()).min(2), answer: z.number().int().min(0), difficulty: z.number().min(0).max(1).default(0.5), hint: z.string().optional() })).default([]),
        prerequisites: z.array(z.string()).default([]),
        related: z.array(z.string()).default([]),
      },
    },
    async (a) => {
      const edges: ConceptEdge[] = [
        ...a.prerequisites.map((p) => ({ fromId: p, toId: a.id, type: "prerequisite" as const, weight: 1 })),
        ...a.related.map((r) => ({ fromId: a.id, toId: r, type: "related" as const, weight: 0.5 })),
      ];
      await store.addConcept({ id: a.id, name: a.name, description: a.description, domain: a.domain, difficulty: a.difficulty, aliases: a.aliases, content: a.content, questions: a.questions }, edges);
      return json({ ok: true, id: a.id, edges: edges.length });
    },
  );

  server.registerResource("concept-graph", "tutor://graph", { title: "Concept graph", description: "The full concept graph as JSON", mimeType: "application/json" }, async (uri) => {
    const g = await store.loadGraph();
    return { contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify({ concepts: [...g.concepts.values()].map(({ id, name, description, difficulty }) => ({ id, name, description, difficulty })), edges: g.edges }) }] };
  });

  return server;
}
