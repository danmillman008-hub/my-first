"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type Snapshot = {
  learnerId: string;
  affect: Record<string, number>;
  dominantAffect: { key: string; value: number };
  pace: number;
  preferences: { style: string; mean: number; trials: number }[];
  concepts: { id: string; name: string; difficulty: number; pKnown: number; uncertainty: number; level: string; evidence: number; correct: number; incorrect: number; confusionEvents: number; activation: number; status: string; readiness: number; lastStyle: string | null }[];
  edges: { fromId: string; toId: string; type: string; weight: number }[];
  recommendations: { conceptId: string; name: string; reason: string; score: number; pKnown: number; status: string }[];
};
type Decision = { action: string; conceptId: string | null; style: string | null; rationale: string[]; followUpQuestion?: boolean };
type Msg = { role: "user" | "tutor"; content: string; decision?: Decision; renderer?: string; graded?: { conceptId: string; correct: boolean; pKnown: number } | null };

function uid(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

function renderRich(text: string) {
  return text.split("\n").map((line, i) => {
    const parts = line.split(/(\*\*[^*]+\*\*|_\([^_]+\)_)/g).map((p, j) => {
      if (p.startsWith("**") && p.endsWith("**")) return <strong key={j}>{p.slice(2, -2)}</strong>;
      if (p.startsWith("_(") && p.endsWith(")_")) return <em key={j} className="opacity-70">{p.slice(1, -1)}</em>;
      return <span key={j}>{p}</span>;
    });
    return (
      <p key={i} className={line.trim() === "" ? "h-2" : "leading-relaxed"}>
        {parts}
      </p>
    );
  });
}

const LEVEL_COLOR: Record<string, string> = { unobserved: "#cbd5e1", novice: "#f87171", developing: "#fbbf24", proficient: "#60a5fa", mastered: "#34d399" };
const ACTION_LABEL: Record<string, string> = {
  explain: "Explain", simplify: "Simplify", deepen: "Go deeper", give_example: "Give example", diagnostic_question: "Diagnostic question", revisit_prerequisite: "Revisit prerequisite",
  switch_strategy: "Switch strategy", slow_down: "Slow down", advance: "Advance", encourage: "Encourage", suggest_break: "Suggest break", grade_answer: "Grade answer",
};

export default function TutorApp() {
  const [learnerId, setLearnerId] = useState<string>("");
  const [sessionId, setSessionId] = useState<string>("");
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [tab, setTab] = useState<"model" | "graph" | "why">("model");
  const lastReplyAt = useRef<number | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let lid = localStorage.getItem("tutor.learnerId");
    if (!lid) {
      lid = uid("learner");
      localStorage.setItem("tutor.learnerId", lid);
    }
    setLearnerId(lid);
    // restore the most recent UI session (conversation + pending question) from the interaction history
    (async () => {
      try {
        const r = await fetch(`/api/history?learnerId=${encodeURIComponent(lid)}`);
        const data = (await r.json()) as { interactions: { sessionId: string; role: string; kind: string; content: string; conceptId: string | null; style: string | null; meta: { rationale?: string[] } }[] };
        const ui = data.interactions.filter((i) => !i.sessionId.startsWith("external-") && !i.sessionId.startsWith("mcp"));
        const last = ui[ui.length - 1];
        if (!last) {
          setSessionId(uid("s"));
          return;
        }
        setSessionId(last.sessionId);
        setMessages(
          ui
            .filter((i) => i.sessionId === last.sessionId)
            .map((i) => (i.role === "user" ? { role: "user", content: i.content } : { role: "tutor", content: i.content, decision: { action: i.kind, conceptId: i.conceptId, style: i.style, rationale: i.meta?.rationale ?? [] } })),
        );
        lastReplyAt.current = Date.now();
      } catch {
        setSessionId(uid("s"));
      }
    })();
  }, []);

  const refresh = useCallback(async (lid: string) => {
    const r = await fetch(`/api/state?learnerId=${encodeURIComponent(lid)}`);
    if (r.ok) setSnap(await r.json());
  }, []);

  useEffect(() => {
    if (learnerId) void refresh(learnerId);
  }, [learnerId, refresh]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = useCallback(
    async (text: string) => {
      const t = text.trim();
      if (!t || busy || !learnerId) return;
      setBusy(true);
      setInput("");
      setMessages((m) => [...m, { role: "user", content: t }]);
      const latencyMs = lastReplyAt.current ? Date.now() - lastReplyAt.current : null;
      try {
        const r = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ learnerId, sessionId, message: t, latencyMs }) });
        const data = await r.json();
        if (!r.ok) throw new Error(data.error ?? "request failed");
        setMessages((m) => [...m, { role: "tutor", content: data.reply, decision: data.decision, renderer: data.renderer, graded: data.graded }]);
        setSnap(data.snapshot);
        lastReplyAt.current = Date.now();
      } catch (e) {
        setMessages((m) => [...m, { role: "tutor", content: `Something went wrong: ${e instanceof Error ? e.message : String(e)}` }]);
      } finally {
        setBusy(false);
      }
    },
    [busy, learnerId, sessionId],
  );

  const reset = async () => {
    if (!confirm("Reset this learner's entire model and history?")) return;
    await fetch("/api/reset", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ learnerId }) });
    setMessages([]);
    setSessionId(uid("s"));
    lastReplyAt.current = null;
    await refresh(learnerId);
  };

  const lastDecision = [...messages].reverse().find((m) => m.decision)?.decision ?? null;

  return (
    <div className="mx-auto grid min-h-screen max-w-[1400px] grid-cols-1 gap-4 p-4 lg:grid-cols-[1fr_440px]">
      {/* ---------------- Chat ---------------- */}
      <section className="flex min-h-[80vh] flex-col rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
        <header className="flex items-center justify-between border-b border-slate-200 px-5 py-3">
          <div>
            <h1 className="text-lg font-semibold text-slate-900">Private Adaptive Tutor</h1>
            <p className="text-xs text-slate-500">Probability & Statistics · learner <code className="rounded bg-slate-100 px-1">{learnerId || "…"}</code></p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <a href="/mcp" className="rounded-lg border border-slate-200 px-2 py-1 text-slate-600 hover:bg-slate-50">MCP</a>
            <button onClick={reset} className="rounded-lg border border-rose-200 px-2 py-1 text-rose-600 hover:bg-rose-50">Reset learner</button>
          </div>
        </header>
        <div className="flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {messages.length === 0 && (
            <div className="rounded-xl border border-dashed border-slate-300 p-5 text-sm text-slate-600">
              <p className="font-medium text-slate-800">Hi — I adapt to how you learn.</p>
              <p className="mt-1">Ask about any topic (e.g. <em>“explain Bayes&apos; theorem”</em>), say <em>“what&apos;s next?”</em> to let me choose based on your model, or <em>“test me”</em>. Tell me when you&apos;re confused, bored, or want an example — I use that as evidence.</p>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div className={m.role === "user" ? "max-w-[85%] rounded-2xl rounded-br-sm bg-indigo-600 px-4 py-2.5 text-sm text-white" : "max-w-[90%] rounded-2xl rounded-bl-sm bg-slate-100 px-4 py-3 text-sm text-slate-900"}>
                {renderRich(m.content)}
                {m.decision && (
                  <div className="mt-2 flex flex-wrap gap-1.5 border-t border-slate-200 pt-2 text-[10px] uppercase tracking-wide text-slate-500">
                    <span className="rounded bg-indigo-100 px-1.5 py-0.5 text-indigo-700">{ACTION_LABEL[m.decision.action] ?? m.decision.action}</span>
                    {m.decision.style && <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-emerald-700">style: {m.decision.style}</span>}
                    {m.decision.conceptId && <span className="rounded bg-slate-200 px-1.5 py-0.5">{m.decision.conceptId}</span>}
                    {m.graded && <span className={`rounded px-1.5 py-0.5 ${m.graded.correct ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"}`}>mastery → {(m.graded.pKnown * 100).toFixed(0)}%</span>}
                  </div>
                )}
              </div>
            </div>
          ))}
          {busy && <div className="text-xs text-slate-400">thinking…</div>}
          <div ref={bottomRef} />
        </div>
        <div className="border-t border-slate-200 px-5 py-3">
          <div className="mb-2 flex flex-wrap gap-1.5">
            {["What's next?", "Test me", "Simpler please", "Give me an example", "Go deeper", "Got it", "I'm confused"].map((q) => (
              <button key={q} onClick={() => send(q)} disabled={busy} className="rounded-full border border-slate-200 px-2.5 py-1 text-xs text-slate-600 hover:bg-slate-50 disabled:opacity-50">
                {q}
              </button>
            ))}
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void send(input);
            }}
            className="flex gap-2"
          >
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask, answer (A/B/C…), or tell me how it's going" className="flex-1 rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-indigo-500" />
            <button disabled={busy || !input.trim()} className="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50">Send</button>
          </form>
        </div>
      </section>

      {/* ---------------- Learner model ---------------- */}
      <aside className="flex flex-col gap-3">
        <div className="flex gap-1 rounded-xl bg-white p-1 shadow-sm ring-1 ring-slate-200">
          {(["model", "graph", "why"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`flex-1 rounded-lg px-3 py-1.5 text-sm ${tab === t ? "bg-indigo-600 text-white" : "text-slate-600 hover:bg-slate-50"}`}>
              {t === "model" ? "Learner model" : t === "graph" ? "Concept graph" : "Why this?"}
            </button>
          ))}
        </div>
        {!snap && <div className="rounded-xl bg-white p-4 text-sm text-slate-500 shadow-sm ring-1 ring-slate-200">Loading learner model…</div>}
        {snap && tab === "model" && <ModelPanel snap={snap} />}
        {snap && tab === "graph" && <GraphPanel snap={snap} onPick={(name) => send(`Explain ${name}`)} />}
        {snap && tab === "why" && <WhyPanel snap={snap} decision={lastDecision} />}
      </aside>
    </div>
  );
}

function Bar({ value, color = "#6366f1", label, right }: { value: number; color?: string; label: string; right?: string }) {
  return (
    <div className="text-xs">
      <div className="flex justify-between text-slate-600">
        <span>{label}</span>
        <span className="tabular-nums">{right ?? `${Math.round(value * 100)}%`}</span>
      </div>
      <div className="mt-0.5 h-1.5 w-full rounded bg-slate-100">
        <div className="h-1.5 rounded" style={{ width: `${Math.max(2, Math.min(100, value * 100))}%`, background: color }} />
      </div>
    </div>
  );
}

function ModelPanel({ snap }: { snap: Snapshot }) {
  const affectColor: Record<string, string> = { confusion: "#f59e0b", frustration: "#ef4444", boredom: "#94a3b8", engagement: "#6366f1", confidence: "#10b981", fatigue: "#8b5cf6", excitement: "#ec4899" };
  return (
    <div className="space-y-3">
      <Card title="Affect estimate" subtitle={`dominant: ${snap.dominantAffect.key} · pace ${(snap.pace * 100).toFixed(0)}%`}>
        <div className="grid grid-cols-2 gap-x-4 gap-y-2">
          {Object.entries(snap.affect).map(([k, v]) => (
            <Bar key={k} label={k} value={v} color={affectColor[k]} />
          ))}
        </div>
      </Card>
      <Card title="Explanation-style preferences" subtitle="Beta posterior mean · trials">
        <div className="space-y-2">
          {snap.preferences.map((p) => (
            <Bar key={p.style} label={p.style} value={p.mean} color="#10b981" right={`${(p.mean * 100).toFixed(0)}% · n=${p.trials}`} />
          ))}
        </div>
      </Card>
      <Card title="Mastery (BKT)" subtitle="probability known · ±uncertainty · status">
        <div className="space-y-2">
          {snap.concepts.map((c) => (
            <div key={c.id} className="text-xs">
              <div className="flex items-center justify-between gap-2 text-slate-700">
                <span className="truncate">
                  {c.name}
                  {c.status !== "active" && <span className="ml-1 rounded bg-slate-200 px-1 text-[10px] uppercase text-slate-600">{c.status}</span>}
                </span>
                <span className="shrink-0 tabular-nums text-slate-500">
                  {(c.pKnown * 100).toFixed(0)}% <span className="opacity-60">±{(c.uncertainty * 50).toFixed(0)}</span> · {c.level}
                </span>
              </div>
              <div className="mt-0.5 h-1.5 w-full rounded bg-slate-100">
                <div className="h-1.5 rounded" style={{ width: `${c.pKnown * 100}%`, background: LEVEL_COLOR[c.level], opacity: c.status === "active" ? 1 : 0.5 }} />
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function GraphPanel({ snap, onPick }: { snap: Snapshot; onPick: (name: string) => void }) {
  const layout = useMemo(() => {
    const depth = new Map<string, number>();
    const pre = (id: string) => snap.edges.filter((e) => e.type === "prerequisite" && e.toId === id).map((e) => e.fromId);
    const d = (id: string, seen: Set<string>): number => {
      if (depth.has(id)) return depth.get(id)!;
      if (seen.has(id)) return 0;
      seen.add(id);
      const p = pre(id);
      const v = p.length ? 1 + Math.max(...p.map((x) => d(x, seen))) : 0;
      depth.set(id, v);
      return v;
    };
    snap.concepts.forEach((c) => d(c.id, new Set()));
    const byDepth = new Map<number, string[]>();
    for (const c of snap.concepts) {
      const k = depth.get(c.id) ?? 0;
      byDepth.set(k, [...(byDepth.get(k) ?? []), c.id]);
    }
    const W = 420;
    const rowH = 78;
    const pos = new Map<string, { x: number; y: number }>();
    const maxDepth = Math.max(...byDepth.keys());
    for (const [k, ids] of byDepth) {
      ids.forEach((id, i) => pos.set(id, { x: ((i + 1) * W) / (ids.length + 1), y: 40 + k * rowH }));
    }
    return { pos, H: 80 + maxDepth * rowH, W };
  }, [snap]);
  const byId = new Map(snap.concepts.map((c) => [c.id, c]));
  return (
    <Card title="Concept graph" subtitle="arrows = prerequisite · dashed = related · fill = mastery · ring = readiness · click a node">
      <svg viewBox={`0 0 ${layout.W} ${layout.H}`} className="w-full">
        <defs>
          <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#94a3b8" />
          </marker>
        </defs>
        {snap.edges.map((e, i) => {
          const a = layout.pos.get(e.fromId);
          const b = layout.pos.get(e.toId);
          if (!a || !b) return null;
          return <line key={i} x1={a.x} y1={a.y + 16} x2={b.x} y2={b.y - 18} stroke="#94a3b8" strokeWidth={e.type === "prerequisite" ? 1.5 * e.weight + 0.5 : 1} strokeDasharray={e.type === "related" ? "4 3" : undefined} markerEnd={e.type === "prerequisite" ? "url(#arrow)" : undefined} opacity={0.7} />;
        })}
        {snap.concepts.map((c) => {
          const p = layout.pos.get(c.id)!;
          const r = 16;
          const circ = 2 * Math.PI * (r + 4);
          return (
            <g key={c.id} transform={`translate(${p.x},${p.y})`} className="cursor-pointer" onClick={() => onPick(c.name)}>
              <circle r={r + 4} fill="none" stroke="#e2e8f0" strokeWidth={3} />
              <circle r={r + 4} fill="none" stroke="#6366f1" strokeWidth={3} strokeDasharray={`${circ * c.readiness} ${circ}`} transform="rotate(-90)" opacity={0.8} />
              <circle r={r} fill={LEVEL_COLOR[c.level]} opacity={c.status === "active" ? 0.95 : 0.4} stroke="#fff" strokeWidth={2} />
              <text y={4} textAnchor="middle" fontSize={10} fill="#0f172a" fontWeight={600}>
                {Math.round(c.pKnown * 100)}
              </text>
              <text y={r + 15} textAnchor="middle" fontSize={8.5} fill="#334155">
                {c.name.length > 22 ? c.name.slice(0, 21) + "…" : c.name}
              </text>
            </g>
          );
        })}
      </svg>
      <div className="mt-2 flex flex-wrap gap-2 text-[10px] text-slate-500">
        {Object.entries(LEVEL_COLOR).map(([k, v]) => (
          <span key={k} className="flex items-center gap-1">
            <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: v }} /> {k}
          </span>
        ))}
      </div>
      <p className="mt-2 text-[11px] text-slate-500">{snap.concepts.filter((c) => c.status !== "active").length} dormant/archived branch(es). {byId.size} concepts.</p>
    </Card>
  );
}

function WhyPanel({ snap, decision }: { snap: Snapshot; decision: Decision | null }) {
  return (
    <div className="space-y-3">
      <Card title="Last policy decision" subtitle="transparent adaptive reasoning">
        {!decision && <p className="text-xs text-slate-500">Send a message to see how the tutor decides.</p>}
        {decision && (
          <div className="text-xs">
            <div className="mb-2 flex flex-wrap gap-1.5">
              <span className="rounded bg-indigo-100 px-1.5 py-0.5 font-medium text-indigo-700">{ACTION_LABEL[decision.action] ?? decision.action}</span>
              {decision.conceptId && <span className="rounded bg-slate-100 px-1.5 py-0.5">{decision.conceptId}</span>}
              {decision.style && <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-emerald-700">{decision.style}</span>}
              {decision.followUpQuestion && <span className="rounded bg-amber-100 px-1.5 py-0.5 text-amber-700">+ check question</span>}
            </div>
            <ol className="list-decimal space-y-1 pl-4 text-slate-700">
              {decision.rationale.map((r, i) => (
                <li key={i}>{r}</li>
              ))}
            </ol>
          </div>
        )}
      </Card>
      <Card title="Recommended next" subtitle="readiness × mastery gap × dormancy">
        <ol className="space-y-1.5 text-xs">
          {snap.recommendations.map((r, i) => (
            <li key={r.conceptId} className="flex items-start gap-2">
              <span className="mt-0.5 rounded bg-slate-100 px-1.5 text-[10px] font-semibold text-slate-600">{i + 1}</span>
              <div>
                <div className="font-medium text-slate-800">
                  {r.name} <span className="font-normal text-slate-400">score {r.score.toFixed(2)}</span>
                </div>
                <div className="text-slate-500">{r.reason}</div>
              </div>
            </li>
          ))}
        </ol>
      </Card>
    </div>
  );
}

function Card({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
      <h2 className="text-sm font-semibold text-slate-900">{title}</h2>
      {subtitle && <p className="mb-2 text-[11px] text-slate-500">{subtitle}</p>}
      {children}
    </div>
  );
}
