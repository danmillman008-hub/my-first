import {
  pgTable,
  text,
  integer,
  real,
  timestamp,
  jsonb,
  serial,
  primaryKey,
  index,
} from "drizzle-orm/pg-core";

// ---------- Learners ----------
export const learners = pgTable("learners", {
  id: text("id").primaryKey(),
  name: text("name").notNull().default("Learner"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ---------- Concept graph ----------
export type ConceptContent = Record<string, string>; // style -> explanation text
export type ConceptQuestion = {
  id: string;
  prompt: string;
  options: string[];
  answer: number; // index into options
  difficulty: number; // 0..1
  hint?: string;
};

export const concepts = pgTable("concepts", {
  id: text("id").primaryKey(), // slug
  domain: text("domain").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  aliases: jsonb("aliases").$type<string[]>().notNull().default([]),
  difficulty: real("difficulty").notNull().default(0.5),
  content: jsonb("content").$type<ConceptContent>().notNull().default({}),
  questions: jsonb("questions").$type<ConceptQuestion[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const conceptEdges = pgTable(
  "concept_edges",
  {
    id: serial("id").primaryKey(),
    fromId: text("from_id")
      .notNull()
      .references(() => concepts.id, { onDelete: "cascade" }),
    toId: text("to_id")
      .notNull()
      .references(() => concepts.id, { onDelete: "cascade" }),
    // prerequisite: from must be known before to
    // related: bidirectional association
    // part_of: from is a sub-concept of to
    type: text("type").notNull(),
    weight: real("weight").notNull().default(1),
  },
  (t) => [index("concept_edges_from_idx").on(t.fromId), index("concept_edges_to_idx").on(t.toId)],
);

// ---------- Learner <-> concept state (mastery, activation, dormancy) ----------
export const learnerConceptState = pgTable(
  "learner_concept_state",
  {
    learnerId: text("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    conceptId: text("concept_id")
      .notNull()
      .references(() => concepts.id, { onDelete: "cascade" }),
    pKnown: real("p_known").notNull().default(0.2), // BKT latent mastery probability
    evidence: integer("evidence").notNull().default(0), // number of observations
    correct: integer("correct").notNull().default(0),
    incorrect: integer("incorrect").notNull().default(0),
    confusionEvents: integer("confusion_events").notNull().default(0),
    activation: real("activation").notNull().default(0), // recency/frequency-weighted interest
    status: text("status").notNull().default("active"), // active | dormant | archived
    lastStyle: text("last_style"),
    lastInteractionAt: timestamp("last_interaction_at", { withTimezone: true }),
    lastMasteryUpdateAt: timestamp("last_mastery_update_at", { withTimezone: true }),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.learnerId, t.conceptId] })],
);

// ---------- Preference model (Beta posteriors per explanation style + pace) ----------
export const learnerPreferences = pgTable(
  "learner_preferences",
  {
    learnerId: text("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    dimension: text("dimension").notNull(), // e.g. "style"
    arm: text("arm").notNull(), // e.g. "concise" | "detailed" | "example" | "analogy" | "formal" | "steps"
    alpha: real("alpha").notNull().default(1),
    beta: real("beta").notNull().default(1),
    trials: integer("trials").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.learnerId, t.dimension, t.arm] })],
);

// ---------- Affect state ----------
export type AffectVector = {
  confusion: number;
  frustration: number;
  boredom: number;
  engagement: number;
  confidence: number;
  fatigue: number;
  excitement: number;
};

export const learnerAffect = pgTable("learner_affect", {
  learnerId: text("learner_id")
    .primaryKey()
    .references(() => learners.id, { onDelete: "cascade" }),
  state: jsonb("state").$type<AffectVector>().notNull(),
  pace: real("pace").notNull().default(0.5), // 0 slow .. 1 fast preferred progression
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// ---------- Sessions ----------
export type PendingQuestion = {
  conceptId: string;
  questionId: string;
  askedAt: string;
  styleUsed: string | null;
};

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  learnerId: text("learner_id")
    .notNull()
    .references(() => learners.id, { onDelete: "cascade" }),
  currentConceptId: text("current_concept_id"),
  pendingQuestion: jsonb("pending_question").$type<PendingQuestion | null>(),
  lastExplainedConceptId: text("last_explained_concept_id"),
  lastExplainedStyle: text("last_explained_style"),
  turnCount: integer("turn_count").notNull().default(0),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  lastActiveAt: timestamp("last_active_at", { withTimezone: true }).notNull().defaultNow(),
});

// ---------- Interaction history ----------
export const interactions = pgTable(
  "interactions",
  {
    id: serial("id").primaryKey(),
    sessionId: text("session_id")
      .notNull()
      .references(() => sessions.id, { onDelete: "cascade" }),
    learnerId: text("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    role: text("role").notNull(), // user | tutor | external
    kind: text("kind").notNull(), // question | answer | confirmation | confusion | request | explanation | quiz | feedback | ...
    content: text("content").notNull(),
    conceptId: text("concept_id"),
    style: text("style"),
    meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("interactions_learner_idx").on(t.learnerId), index("interactions_session_idx").on(t.sessionId)],
);

// ---------- Policy decisions (auditable adaptive reasoning) ----------
export const decisions = pgTable(
  "decisions",
  {
    id: serial("id").primaryKey(),
    sessionId: text("session_id")
      .notNull()
      .references(() => sessions.id, { onDelete: "cascade" }),
    learnerId: text("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    action: text("action").notNull(),
    conceptId: text("concept_id"),
    style: text("style"),
    rationale: jsonb("rationale").$type<string[]>().notNull().default([]),
    stateSnapshot: jsonb("state_snapshot").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("decisions_learner_idx").on(t.learnerId)],
);
