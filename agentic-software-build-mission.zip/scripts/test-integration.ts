/* End-to-end engine test against the real database. Run: npx tsx scripts/test-integration.ts */
import "dotenv/config";
import assert from "node:assert/strict";
import { getSnapshot, handleMessage, recordEvidence } from "../src/lib/tutor/engine";
import * as store from "../src/lib/tutor/store";
import { pool } from "../src/db";

const learnerId = `it-${Date.now()}`;
const sessionId = `${learnerId}-s1`;
const LETTERS = "ABCDEFGH";
let step = 0;
const log = (title: string, r: Awaited<ReturnType<typeof handleMessage>>) => {
  step++;
  console.log(`\n[${step}] ${title}\n    → ${r.decision.action} / ${r.decision.conceptId} / ${r.decision.style ?? "-"}\n    rationale: ${r.decision.rationale.join(" | ")}\n    reply: ${r.reply.replace(/\n/g, " ").slice(0, 160)}…`);
};
// deterministic PRNG so Thompson sampling is reproducible across runs
let seed = Number(process.env.SEED ?? 7);
const rnd = () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const say = (text: string, latencyMs?: number) => handleMessage({ learnerId, sessionId, text, latencyMs, rnd });

async function pendingAnswer(correct: boolean): Promise<string> {
  const [s] = await pool.query("select pending_question from sessions where id=$1", [sessionId]).then((r) => r.rows);
  const pq = s.pending_question as { conceptId: string; questionId: string } | null;
  assert.ok(pq, "expected a pending question");
  const g = await store.loadGraph();
  const q = g.concepts.get(pq.conceptId)!.questions.find((x) => x.id === pq.questionId)!;
  const idx = correct ? q.answer : (q.answer + 1) % q.options.length;
  return LETTERS[idx];
}

async function main() {
  await store.ensureSeeded();
  const graph = await store.loadGraph();
  assert.ok(graph.concepts.size >= 14, "seeded 14+ concepts");
  assert.ok(graph.edges.length >= 20, "seeded edges");

  // 1. Ask about a hard concept with unobserved prerequisite → prerequisite check
  let r = await say("Can you explain Bayes' theorem?");
  log("ask hard concept", r);
  assert.equal(r.analysis.intent, "ask_concept");
  assert.equal(r.decision.action, "diagnostic_question");
  assert.equal(r.decision.conceptId, "conditional-probability");
  assert.match(r.reply, /Quick check/);

  // 2. Answer the prerequisite check correctly → explain the goal (Bayes) + follow-up question
  r = await say(await pendingAnswer(true), 15_000);
  log("answer prereq correctly", r);
  assert.ok(r.graded?.correct);
  assert.equal(r.decision.action, "explain");
  assert.equal(r.decision.conceptId, "bayes-theorem");
  assert.ok(r.decision.style);
  const bayesStyle1 = r.decision.style!;
  let snap = await getSnapshot(learnerId);
  const cp = snap.concepts.find((c) => c.id === "conditional-probability")!;
  assert.ok(cp.pKnown > 0.3 && cp.evidence === 1, `conditional-probability evidence persisted: ${JSON.stringify(cp)}`);
  // prerequisite propagation: axioms should have received weak positive evidence
  assert.equal(snap.concepts.find((c) => c.id === "probability-axioms")!.evidence, 1);

  // 3. Answer Bayes question wrongly → style gets blamed, strategy switches
  r = await say(await pendingAnswer(false), 8_000);
  log("answer Bayes wrongly", r);
  assert.equal(r.graded?.correct, false);
  assert.equal(r.decision.action, "switch_strategy");
  assert.notEqual(r.decision.style, bayesStyle1);
  snap = await getSnapshot(learnerId);
  const blamed = snap.preferences.find((p) => p.style === bayesStyle1)!;
  assert.equal(blamed.trials, 1);
  assert.ok(blamed.mean < 0.5, "failed style posterior below 0.5");
  const bayesStyle2 = r.decision.style!;

  // 4. Learner expresses confusion → confusion affect rises, another switch or prerequisite revisit
  r = await say("I'm confused, I don't get it");
  log("confusion", r);
  assert.equal(r.analysis.intent, "confusion");
  assert.ok(["switch_strategy", "simplify", "revisit_prerequisite"].includes(r.decision.action));
  if (r.decision.action === "switch_strategy") assert.notEqual(r.decision.style, bayesStyle2);
  assert.ok(r.snapshot.affect.confusion > 0.4, `confusion=${r.snapshot.affect.confusion}`);
  assert.ok(r.snapshot.concepts.find((c) => c.id === "bayes-theorem")!.confusionEvents >= 1);

  // 5. Learner asks for an example → example style forced
  r = await say("Can you give me an example?");
  log("ask example", r);
  assert.equal(r.decision.action, "give_example");
  assert.equal(r.decision.style, "example");

  // 6. Confirms understanding → confirmation evidence + verification question; the "example" style gets credit
  const exampleBefore = (await getSnapshot(learnerId)).preferences.find((p) => p.style === "example")!;
  r = await say("Ah got it, that makes sense now, thanks!");
  log("confirm", r);
  assert.equal(r.analysis.intent, "confirm");
  assert.equal(r.decision.action, "diagnostic_question");
  assert.ok(r.snapshot.affect.confusion < 0.5, "confusion should ease after confirmation");
  const exampleArm = r.snapshot.preferences.find((p) => p.style === "example")!;
  assert.equal(exampleArm.trials, exampleBefore.trials + 1);
  assert.ok(exampleArm.mean > exampleBefore.mean, `example style credited: ${exampleBefore.mean} → ${exampleArm.mean}`);

  // 7. Answer correctly twice → mastery climbs, eventually advance
  r = await say(await pendingAnswer(true), 20_000);
  log("answer correctly #1", r);
  assert.ok(r.graded?.correct);
  let bayes = r.snapshot.concepts.find((c) => c.id === "bayes-theorem")!;
  const pBefore = bayes.pKnown;
  if (r.decision.action === "diagnostic_question") {
    r = await say(await pendingAnswer(true), 12_000);
    log("answer correctly #2", r);
    bayes = r.snapshot.concepts.find((c) => c.id === "bayes-theorem")!;
    assert.ok(bayes.pKnown > pBefore);
  }
  assert.ok(["advance", "diagnostic_question"].includes(r.decision.action));

  // 8. Boredom signal → policy moves toward harder material
  r = await say("this is boring, too easy, I already know this");
  log("boredom", r);
  assert.ok(r.snapshot.affect.boredom > 0.4, `boredom=${r.snapshot.affect.boredom}`);
  assert.ok(["advance", "diagnostic_question", "deepen"].includes(r.decision.action));

  // 9. What's next → graph-aware recommendation (never a mastered concept, prefers ready ones)
  r = await say("what's next?");
  log("what's next", r);
  assert.ok(["advance", "diagnostic_question"].includes(r.decision.action));
  const rec = r.snapshot.concepts.find((c) => c.id === r.decision.conceptId)!;
  assert.ok(rec.pKnown < 0.85);

  // 10. Fatigue → break suggestion
  r = await say("I'm exhausted, long day, brain is fried");
  log("fatigue", r);
  assert.equal(r.decision.action, "suggest_break");

  // 11. External evidence via the MCP entry point updates the same model
  const before = (await getSnapshot(learnerId)).concepts.find((c) => c.id === "variance")!;
  const ev = await recordEvidence({ learnerId, conceptId: "variance", kind: "quiz_correct", style: "steps", note: "external quiz" });
  const after = (await getSnapshot(learnerId)).concepts.find((c) => c.id === "variance")!;
  assert.ok(after.pKnown > before.pKnown && after.evidence === before.evidence + 1, `external evidence applied ${ev.pKnown}`);

  // 12. Persistence: history, decisions and a fresh model load reflect everything
  const hist = await store.recentInteractions(learnerId, 100);
  const decs = await store.recentDecisions(learnerId, 50);
  assert.ok(hist.filter((h) => h.role === "user").length >= 10);
  assert.ok(hist.some((h) => h.role === "external"));
  assert.equal(decs.length, hist.filter((h) => h.role === "tutor").length);
  const reloaded = await store.loadModel(learnerId);
  assert.ok(reloaded.concepts.get("bayes-theorem")!.evidence >= 3);
  assert.ok([...reloaded.preferences.values()].some((p) => p.trials > 0));

  // 13. Dormancy: simulate time passing on a touched concept, then verify status downgrade in snapshot
  await pool.query("update learner_concept_state set last_interaction_at = now() - interval '12 days' where learner_id=$1 and concept_id='conditional-probability'", [learnerId]);
  snap = await getSnapshot(learnerId);
  assert.equal(snap.concepts.find((c) => c.id === "conditional-probability")!.status, "dormant");
  await pool.query("update learner_concept_state set last_interaction_at = now() - interval '40 days' where learner_id=$1 and concept_id='conditional-probability'", [learnerId]);
  snap = await getSnapshot(learnerId);
  assert.equal(snap.concepts.find((c) => c.id === "conditional-probability")!.status, "archived");
  // revival on interaction
  r = await say("remind me about conditional probability");
  log("revive archived branch", r);
  assert.equal((await getSnapshot(learnerId)).concepts.find((c) => c.id === "conditional-probability")!.status, "active");

  console.log(`\nIntegration scenario passed (${step} turns). Learner ${learnerId}`);
  await store.resetLearner(learnerId);
  await pool.query("delete from learners where id=$1", [learnerId]);
}

main()
  .then(() => pool.end())
  .catch(async (e) => {
    console.error("\nINTEGRATION FAILURE:", e);
    await pool.end();
    process.exit(1);
  });
