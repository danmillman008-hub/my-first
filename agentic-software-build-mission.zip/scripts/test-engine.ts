/* Unit tests for the pure adaptive core. Run: npx tsx scripts/test-engine.ts */
import assert from "node:assert/strict";
import { NEUTRAL_AFFECT, lexicalAffect, updateAffect, behaviouralAffect } from "../src/lib/tutor/affect";
import { analyzeMessage, detectConcepts, parseAnswer } from "../src/lib/tutor/analyze";
import { SEED_CONCEPTS, SEED_EDGES } from "../src/lib/tutor/domain";
import { reclassify, touch, decayedActivation } from "../src/lib/tutor/dormancy";
import { applyForgetting, defaultConceptState, masteryLevel, observe, readiness, uncertainty } from "../src/lib/tutor/mastery";
import { decide, recommendNext, type Graph, type SessionContext } from "../src/lib/tutor/policy";
import { chooseStyle, defaultPreferences, recordOutcome } from "../src/lib/tutor/preferences";
import type { ConceptState, LearnerModel, MessageAnalysis } from "../src/lib/tutor/types";

let passed = 0;
const failures: string[] = [];
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (e) {
    failures.push(name);
    console.log(`  ✗ ${name}\n      ${e instanceof Error ? e.message : e}`);
  }
}
// deterministic PRNG (mulberry32)
function rng(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const graph: Graph = { concepts: new Map(SEED_CONCEPTS.map((c) => [c.id, c])), edges: SEED_EDGES };
const day = 86_400_000;
const T0 = new Date("2026-01-01T00:00:00Z");

function freshModel(): LearnerModel {
  return { learnerId: "t", concepts: new Map(), preferences: defaultPreferences(), affect: { ...NEUTRAL_AFFECT }, pace: 0.5 };
}
function analysis(partial: Partial<MessageAnalysis>): MessageAnalysis {
  return { intent: "chat", conceptIds: [], affectSignals: {}, answerIndex: null, length: 10, latencyMs: null, ...partial };
}
function ctx(partial: Partial<SessionContext> = {}): SessionContext {
  return { currentConceptId: null, lastExplainedConceptId: null, lastExplainedStyle: null, turnCount: 1, breakSuggestedRecently: false, explainCountForConcept: 0, graded: null, ...partial };
}

console.log("\nMastery (BKT)");
test("correct answer raises P(known); incorrect lowers it", () => {
  const s0 = defaultConceptState("x", 0.5);
  const up = observe(s0, "quiz_correct", { now: T0 });
  const down = observe(s0, "quiz_incorrect", { now: T0 });
  assert.ok(up.pKnown > s0.pKnown, `${up.pKnown} > ${s0.pKnown}`);
  assert.ok(down.pKnown < s0.pKnown, `${down.pKnown} < ${s0.pKnown}`);
});
test("harder questions give stronger positive evidence", () => {
  const s0 = defaultConceptState("x", 0.5);
  const easy = observe(s0, "quiz_correct", { difficulty: 0.1, now: T0 });
  const hard = observe(s0, "quiz_correct", { difficulty: 0.9, now: T0 });
  assert.ok(hard.pKnown > easy.pKnown);
});
test("sequence of correct answers reaches mastered; uncertainty shrinks", () => {
  let s = defaultConceptState("x", 0.5);
  const u0 = uncertainty(s);
  for (let i = 0; i < 4; i++) s = observe(s, "quiz_correct", { now: new Date(T0.getTime() + i * 60_000) });
  assert.equal(masteryLevel(s), "mastered", `pKnown=${s.pKnown}`);
  assert.ok(uncertainty(s) < u0);
});
test("soft evidence (confirmation/confusion) moves mastery less than quiz evidence", () => {
  const s0 = defaultConceptState("x", 0.5);
  const q = observe(s0, "quiz_correct", { now: T0 }).pKnown - s0.pKnown;
  const c = observe(s0, "confirmation", { now: T0 }).pKnown - s0.pKnown;
  assert.ok(c > 0 && c < q, `confirm Δ=${c} quiz Δ=${q}`);
  assert.ok(observe(s0, "confusion", { now: T0 }).pKnown < s0.pKnown);
});
test("forgetting decays mastery over time but not below floor; more practice → slower decay", () => {
  let s = defaultConceptState("x", 0.5);
  s = observe(s, "quiz_correct", { now: T0 });
  s = observe(s, "quiz_correct", { now: T0 });
  const later = applyForgetting(s, new Date(T0.getTime() + 30 * day));
  assert.ok(later < s.pKnown && later >= 0.1, `${later}`);
  let practised = s;
  for (let i = 0; i < 4; i++) practised = observe(practised, "quiz_correct", { now: T0 });
  const ratioPractised = applyForgetting(practised, new Date(T0.getTime() + 30 * day)) / practised.pKnown;
  const ratioNovice = later / s.pKnown;
  assert.ok(ratioPractised > ratioNovice);
});
test("readiness reflects prerequisite mastery", () => {
  const states = new Map<string, ConceptState>();
  const get = (id: string) => states.get(id) ?? defaultConceptState(id);
  const low = readiness("bayes-theorem", SEED_EDGES, get).score;
  let cp = defaultConceptState("conditional-probability");
  for (let i = 0; i < 3; i++) cp = observe(cp, "quiz_correct", { now: T0 });
  states.set("conditional-probability", cp);
  const high = readiness("bayes-theorem", SEED_EDGES, get);
  assert.ok(high.score > low);
  assert.equal(readiness("sample-spaces", SEED_EDGES, get).score, 1);
});

console.log("\nAffect");
test("lexical cues raise the matching affect dimension", () => {
  assert.ok((lexicalAffect("I don't get it, this is confusing")?.confusion ?? 0) > 0.3);
  assert.ok((lexicalAffect("ugh this is so frustrating!!")?.frustration ?? 0) > 0.3);
  assert.ok((lexicalAffect("this is boring, I already know this")?.boredom ?? 0) > 0.3);
  assert.ok((lexicalAffect("I'm tired, long day")?.fatigue ?? 0) > 0.3);
});
test("affect smooths back toward neutral without new evidence", () => {
  let a = updateAffect(NEUTRAL_AFFECT, { frustration: 0.8 });
  const peak = a.frustration;
  for (let i = 0; i < 6; i++) a = updateAffect(a);
  assert.ok(a.frustration < peak && a.frustration < 0.2);
});
test("behavioural cues: incorrect streak → frustration, correct streak → boredom risk", () => {
  assert.ok((behaviouralAffect({ answerCorrect: false, incorrectStreak: 3 }).frustration ?? 0) > 0.2);
  assert.ok((behaviouralAffect({ answerCorrect: true, correctStreak: 4 }).boredom ?? 0) > 0.1);
});

console.log("\nPreferences (Thompson sampling)");
test("style with repeated success dominates selection; failed style is avoided", () => {
  let prefs = defaultPreferences();
  for (let i = 0; i < 8; i++) {
    prefs.set("example", recordOutcome(prefs.get("example")!, true));
    prefs.set("formal", recordOutcome(prefs.get("formal")!, false));
  }
  const r = rng(42);
  const counts: Record<string, number> = {};
  for (let i = 0; i < 300; i++) {
    const { style } = chooseStyle(prefs, { rnd: r });
    counts[style] = (counts[style] ?? 0) + 1;
  }
  assert.ok((counts.example ?? 0) > 150, JSON.stringify(counts));
  assert.ok((counts.formal ?? 0) < 10, JSON.stringify(counts));
  prefs = defaultPreferences();
  for (let i = 0; i < 50; i++) assert.notEqual(chooseStyle(prefs, { exclude: ["concise"], rnd: r }).style, "concise");
});

console.log("\nMessage analysis");
test("detects concepts by name and alias, most specific first", () => {
  assert.deepEqual(detectConcepts("can you explain bayes rule?", SEED_CONCEPTS)[0], "bayes-theorem");
  assert.ok(detectConcepts("what is the central limit theorem", SEED_CONCEPTS).includes("central-limit-theorem"));
  assert.equal(detectConcepts("what's a p-value", SEED_CONCEPTS)[0], "hypothesis-testing");
  assert.equal(detectConcepts("hello there", SEED_CONCEPTS).length, 0);
});
test("parses answers as letters, numbers, phrases and option text", () => {
  const opts = ["0.9", "0.7", "0.2", "0.1"];
  assert.equal(parseAnswer("B", 4, opts), 1);
  assert.equal(parseAnswer("b)", 4, opts), 1);
  assert.equal(parseAnswer("3", 4, opts), 2);
  assert.equal(parseAnswer("I think it's c", 4, opts), 2);
  assert.equal(parseAnswer("0.7", 4, opts), 1);
  assert.equal(parseAnswer("explain variance", 4, opts), null);
});
test("classifies intents", () => {
  const a = (t: string, opts?: string[]) => analyzeMessage(t, SEED_CONCEPTS, { pendingOptions: opts ?? null }).intent;
  assert.equal(a("I don't understand this at all"), "confusion");
  assert.equal(a("got it, makes sense"), "confirm");
  assert.equal(a("can you give me an example"), "ask_example");
  assert.equal(a("simpler please"), "ask_simpler");
  assert.equal(a("go deeper, more detail"), "ask_deeper");
  assert.equal(a("test me"), "ask_quiz");
  assert.equal(a("what's next?"), "ask_next");
  assert.equal(a("explain expected value"), "ask_concept");
  assert.equal(a("A", ["x", "y"]), "answer");
});

console.log("\nDormancy");
test("touched concept is active; decays to dormant, then archived; history preserved", () => {
  let s = touch(defaultConceptState("x"), 1, T0);
  s = observe(s, "quiz_correct", { now: T0 });
  assert.equal(reclassify(s, T0).status, "active");
  const d10 = reclassify(s, new Date(T0.getTime() + 10 * day));
  assert.equal(d10.status, "dormant");
  assert.ok(decayedActivation(s, new Date(T0.getTime() + 10 * day)) < 0.25);
  const d30 = reclassify(s, new Date(T0.getTime() + 30 * day));
  assert.equal(d30.status, "archived");
  assert.equal(d30.correct, 1); // evidence retained
  assert.equal(touch(d30, 1, new Date(T0.getTime() + 31 * day)).status, "active"); // revival
  assert.equal(reclassify(defaultConceptState("never"), new Date(T0.getTime() + 100 * day)).status, "active");
});

console.log("\nPolicy engine");
test("recommendNext starts with root concepts (no prerequisites) and skips mastered ones", () => {
  const m = freshModel();
  const recs = recommendNext(m, graph, { limit: 3 });
  assert.ok(["sample-spaces", "counting"].includes(recs[0].conceptId), recs[0].conceptId);
  let s = defaultConceptState("sample-spaces");
  for (let i = 0; i < 5; i++) s = observe(s, "quiz_correct", { now: T0 });
  m.concepts.set("sample-spaces", s);
  assert.ok(!recommendNext(m, graph, { limit: 14 }).some((r) => r.conceptId === "sample-spaces"));
});
test("dormant branches are de-prioritised relative to equivalent active ones", () => {
  const m = freshModel();
  const active = touch(defaultConceptState("sample-spaces", 0.15), 1, T0);
  const dormant = { ...touch(defaultConceptState("counting", 0.15), 1, T0), status: "dormant" as const, activation: 0.01 };
  m.concepts.set("sample-spaces", active);
  m.concepts.set("counting", dormant);
  const recs = recommendNext(m, graph, { limit: 5 });
  const a = recs.find((r) => r.conceptId === "sample-spaces")!;
  const d = recs.find((r) => r.conceptId === "counting")!;
  assert.ok(a.score > d.score, `${a.score} > ${d.score}`);
});
test("incorrect answer + observed weak prerequisite → revisit_prerequisite", () => {
  const m = freshModel();
  m.concepts.set("conditional-probability", observe(observe(defaultConceptState("conditional-probability"), "quiz_incorrect", { now: T0 }), "quiz_incorrect", { now: T0 }));
  m.concepts.set("bayes-theorem", observe(defaultConceptState("bayes-theorem", 0.6), "quiz_incorrect", { now: T0 }));
  const d = decide(m, graph, analysis({ intent: "answer", answerIndex: 0 }), ctx({ currentConceptId: "bayes-theorem", graded: { conceptId: "bayes-theorem", correct: false, wasPrereqCheck: false } }), rng(1));
  assert.equal(d.action, "revisit_prerequisite");
  assert.equal(d.conceptId, "conditional-probability");
});
test("incorrect answer after an explanation → switch_strategy away from the failed style", () => {
  const m = freshModel();
  const decisions = new Set<string>();
  for (let i = 0; i < 20; i++) {
    const d = decide(m, graph, analysis({ intent: "answer", answerIndex: 0 }), ctx({ currentConceptId: "expectation", lastExplainedConceptId: "expectation", lastExplainedStyle: "formal", graded: { conceptId: "expectation", correct: false, wasPrereqCheck: false } }), rng(i));
    assert.equal(d.action, "switch_strategy");
    assert.notEqual(d.style, "formal");
    decisions.add(d.style!);
  }
  assert.ok(decisions.size > 1, "should explore multiple alternative styles");
});
test("correct answer with high mastery → advance to a recommended concept", () => {
  const m = freshModel();
  let s = defaultConceptState("sample-spaces", 0.15);
  for (let i = 0; i < 4; i++) s = observe(s, "quiz_correct", { now: T0 });
  m.concepts.set("sample-spaces", s);
  const d = decide(m, graph, analysis({ intent: "answer", answerIndex: 2 }), ctx({ currentConceptId: "sample-spaces", graded: { conceptId: "sample-spaces", correct: true, wasPrereqCheck: false } }), rng(3));
  assert.equal(d.action, "advance");
  assert.notEqual(d.conceptId, "sample-spaces");
});
test("correct answer with mid mastery → another diagnostic question", () => {
  const m = freshModel();
  m.concepts.set("variance", observe(defaultConceptState("variance"), "quiz_correct", { now: T0 }));
  const d = decide(m, graph, analysis({ intent: "answer", answerIndex: 2 }), ctx({ currentConceptId: "variance", graded: { conceptId: "variance", correct: true, wasPrereqCheck: false } }));
  assert.equal(d.action, "diagnostic_question");
});
test("asking about a hard concept with unobserved prerequisite → prerequisite check first", () => {
  const m = freshModel();
  const d = decide(m, graph, analysis({ intent: "ask_concept", conceptIds: ["bayes-theorem"] }), ctx(), rng(5));
  assert.equal(d.action, "diagnostic_question");
  assert.equal(d.conceptId, "conditional-probability");
});
test("passing the prerequisite check → explain the goal concept", () => {
  const m = freshModel();
  const d = decide(m, graph, analysis({ intent: "answer", answerIndex: 1 }), ctx({ currentConceptId: "bayes-theorem", graded: { conceptId: "conditional-probability", correct: true, wasPrereqCheck: true } }), rng(7));
  assert.equal(d.action, "explain");
  assert.equal(d.conceptId, "bayes-theorem");
});
test("confusion after explanation → switch strategy; repeated confusion + weak prereq → revisit prerequisite", () => {
  const m = freshModel();
  m.affect = { ...m.affect, confusion: 0.6 };
  const d1 = decide(m, graph, analysis({ intent: "confusion" }), ctx({ currentConceptId: "independence", lastExplainedConceptId: "independence", lastExplainedStyle: "concise" }), rng(9));
  assert.equal(d1.action, "switch_strategy");
  assert.notEqual(d1.style, "concise");
  let ind = defaultConceptState("independence");
  ind = observe(observe(ind, "confusion", { now: T0 }), "confusion", { now: T0 });
  m.concepts.set("independence", ind);
  m.concepts.set("conditional-probability", observe(defaultConceptState("conditional-probability"), "quiz_incorrect", { now: T0 }));
  const d2 = decide(m, graph, analysis({ intent: "confusion" }), ctx({ currentConceptId: "independence", lastExplainedConceptId: "independence", lastExplainedStyle: "steps" }), rng(9));
  assert.equal(d2.action, "revisit_prerequisite");
  assert.equal(d2.conceptId, "conditional-probability");
});
test("high fatigue → suggest a break (once); high frustration → slow down", () => {
  const m = freshModel();
  m.affect = { ...m.affect, fatigue: 0.8 };
  assert.equal(decide(m, graph, analysis({ intent: "chat" }), ctx({ currentConceptId: "variance" })).action, "suggest_break");
  assert.notEqual(decide(m, graph, analysis({ intent: "chat" }), ctx({ currentConceptId: "variance", breakSuggestedRecently: true })).action, "suggest_break");
  const f = freshModel();
  f.affect = { ...f.affect, frustration: 0.75 };
  const d = decide(f, graph, analysis({ intent: "ask_concept", conceptIds: ["variance"] }), ctx(), rng(2));
  assert.equal(d.action, "slow_down");
  assert.notEqual(d.style, "formal");
});
test("boredom with decent mastery → advance; learner asking about a mastered concept → deepen", () => {
  const m = freshModel();
  m.affect = { ...m.affect, boredom: 0.7 };
  let s = defaultConceptState("counting");
  for (let i = 0; i < 2; i++) s = observe(s, "quiz_correct", { now: T0 });
  m.concepts.set("counting", s);
  assert.equal(decide(m, graph, analysis({ intent: "chat" }), ctx({ currentConceptId: "counting" }), rng(4)).action, "advance");
  let mastered = defaultConceptState("counting");
  for (let i = 0; i < 5; i++) mastered = observe(mastered, "quiz_correct", { now: T0 });
  const m2 = freshModel();
  m2.concepts.set("counting", mastered);
  assert.equal(decide(m2, graph, analysis({ intent: "ask_concept", conceptIds: ["counting"] }), ctx(), rng(4)).action, "deepen");
});
test("learned style preference propagates into decisions", () => {
  const m = freshModel();
  for (let i = 0; i < 12; i++) {
    m.preferences.set("analogy", recordOutcome(m.preferences.get("analogy")!, true));
    for (const s of ["concise", "detailed", "formal", "steps", "example"] as const) m.preferences.set(s, recordOutcome(m.preferences.get(s)!, false));
  }
  const r = rng(11);
  let analogy = 0;
  for (let i = 0; i < 40; i++) if (decide(m, graph, analysis({ intent: "ask_concept", conceptIds: ["sample-spaces"] }), ctx(), r).style === "analogy") analogy++;
  assert.ok(analogy >= 32, `analogy chosen ${analogy}/40`);
});

console.log(`\n${passed} passed, ${failures.length} failed`);
if (failures.length) {
  console.log("Failures:", failures);
  process.exit(1);
}
