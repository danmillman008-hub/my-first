#!/usr/bin/env bash
# MCP Streamable HTTP protocol test. Usage: scripts/test-mcp.sh [base_url]
set -euo pipefail
BASE="${1:-http://127.0.0.1:3000}"
URL="$BASE/api/mcp"
H=(-H 'content-type: application/json' -H 'accept: application/json, text/event-stream' -H 'mcp-protocol-version: 2025-06-18')
fail() { echo "✗ $1"; exit 1; }
ok() { echo "✓ $1"; }
LID="mcp-test-$$"

rpc() { curl -sS "${H[@]}" "$URL" -d "$1"; }

# 1. initialize
R=$(rpc '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"test","version":"0"}}}')
echo "$R" | grep -q '"protocolVersion"' || fail "initialize: $R"
echo "$R" | grep -q '"tools"' || fail "initialize capabilities missing tools: $R"
ok "initialize → $(echo "$R" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{const j=JSON.parse(d);console.log(j.result.serverInfo.name, j.result.protocolVersion)})')"

# 2. notifications/initialized should be accepted (202)
CODE=$(curl -sS -o /dev/null -w '%{http_code}' "${H[@]}" "$URL" -d '{"jsonrpc":"2.0","method":"notifications/initialized"}')
[ "$CODE" = "202" ] || fail "initialized notification returned $CODE"
ok "notifications/initialized → 202"

# 3. tools/list
R=$(rpc '{"jsonrpc":"2.0","id":2,"method":"tools/list"}')
for t in get_learner_state get_concept_graph get_concept get_recommendations record_evidence tutor_turn get_interaction_history add_concept; do
  echo "$R" | grep -q "\"name\":\"$t\"" || fail "tools/list missing $t"
done
ok "tools/list → 8 tools present"

# 4. resources/list + read
R=$(rpc '{"jsonrpc":"2.0","id":3,"method":"resources/list"}')
echo "$R" | grep -q 'tutor://graph' || fail "resources/list: $R"
R=$(rpc '{"jsonrpc":"2.0","id":4,"method":"resources/read","params":{"uri":"tutor://graph"}}')
echo "$R" | grep -q 'prerequisite' || fail "resources/read: $R"
ok "resources/list + resources/read"

# 5. get_concept_graph
R=$(rpc '{"jsonrpc":"2.0","id":5,"method":"tools/call","params":{"name":"get_concept_graph","arguments":{}}}')
N=$(echo "$R" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{const j=JSON.parse(d);console.log(j.result.structuredContent.concepts.length)})')
[ "$N" -ge 14 ] || fail "expected >=14 concepts, got $N"
ok "get_concept_graph → $N concepts"

# 6. tutor_turn drives the adaptive core
R=$(rpc "{\"jsonrpc\":\"2.0\",\"id\":6,\"method\":\"tools/call\",\"params\":{\"name\":\"tutor_turn\",\"arguments\":{\"learnerId\":\"$LID\",\"sessionId\":\"$LID-s\",\"message\":\"explain expected value\"}}}")
ACTION=$(echo "$R" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{const j=JSON.parse(d);console.log(j.result.structuredContent.decision.action)})')
[ -n "$ACTION" ] || fail "tutor_turn: $R"
ok "tutor_turn → decision=$ACTION"

# 7. record_evidence updates mastery
R=$(rpc "{\"jsonrpc\":\"2.0\",\"id\":7,\"method\":\"tools/call\",\"params\":{\"name\":\"record_evidence\",\"arguments\":{\"learnerId\":\"$LID\",\"conceptId\":\"variance\",\"kind\":\"quiz_correct\",\"style\":\"steps\"}}}")
P=$(echo "$R" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{const j=JSON.parse(d);console.log(j.result.structuredContent.pKnown)})')
node -e "process.exit(Number('$P') > 0.3 ? 0 : 1)" || fail "record_evidence pKnown=$P"
ok "record_evidence → variance pKnown=$P"

# 8. get_learner_state reflects both
R=$(rpc "{\"jsonrpc\":\"2.0\",\"id\":8,\"method\":\"tools/call\",\"params\":{\"name\":\"get_learner_state\",\"arguments\":{\"learnerId\":\"$LID\"}}}")
echo "$R" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{const s=JSON.parse(d).result.structuredContent;const v=s.concepts.find(c=>c.id==="variance");if(!(v.evidence>=1&&s.preferences.length===6&&s.recommendations.length>0))process.exit(1);console.log("  variance:",v.level,v.pKnown,"| top rec:",s.recommendations[0].name,"| affect:",s.dominantAffect.key)})' || fail "get_learner_state inconsistent"
ok "get_learner_state consistent"

# 9. history
R=$(rpc "{\"jsonrpc\":\"2.0\",\"id\":9,\"method\":\"tools/call\",\"params\":{\"name\":\"get_interaction_history\",\"arguments\":{\"learnerId\":\"$LID\"}}}")
echo "$R" | grep -q '"role":"external"' || fail "history missing external interaction"
ok "get_interaction_history includes external evidence"

# 10. add_concept extends graph
R=$(rpc '{"jsonrpc":"2.0","id":10,"method":"tools/call","params":{"name":"add_concept","arguments":{"id":"covariance","name":"Covariance","description":"Joint variability of two random variables.","difficulty":0.6,"prerequisites":["variance","expectation"],"content":{"concise":"Cov(X,Y)=E[(X−μx)(Y−μy)]=E[XY]−E[X]E[Y]."},"questions":[{"id":"q1","prompt":"If X and Y are independent, Cov(X,Y)=?","options":["0","1","Var(X)"],"answer":0,"difficulty":0.4}]}}}')
echo "$R" | grep -q '"ok":true' || fail "add_concept: $R"
R=$(rpc '{"jsonrpc":"2.0","id":11,"method":"tools/call","params":{"name":"get_concept","arguments":{"conceptId":"covariance"}}}')
echo "$R" | grep -q '"prerequisites":\["variance","expectation"\]' || fail "get_concept covariance: $R"
ok "add_concept + get_concept (graph extended at runtime)"

# 11. error handling: unknown tool → JSON-RPC error / isError
R=$(rpc '{"jsonrpc":"2.0","id":12,"method":"tools/call","params":{"name":"nope","arguments":{}}}')
echo "$R" | grep -qi 'error' || fail "unknown tool should error: $R"
ok "unknown tool → error"

# 12. GET is 405 in stateless mode
CODE=$(curl -sS -o /dev/null -w '%{http_code}' "$URL")
[ "$CODE" = "405" ] || fail "GET returned $CODE"
ok "GET → 405 (stateless)"

echo "MCP protocol tests passed against $URL"
# cleanup test artifacts when a local database is reachable
if command -v psql >/dev/null 2>&1 && [ -n "${DATABASE_URL:-}" ]; then
  psql "$DATABASE_URL" -q -c "delete from concepts where id='covariance'; delete from learners where id='$LID';" >/dev/null 2>&1 || true
fi
