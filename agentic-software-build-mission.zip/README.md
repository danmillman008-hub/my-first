# Private Adaptive Tutor

A graph-based adaptive tutor with a **living learner model** — mastery, concept structure, explanation-style preferences, affect, interaction history — an **adaptive policy engine** that decides every response, and an **MCP access layer** so external assistants can read/update the model or delegate tutoring turns.

Stack: Next.js (App Router) · PostgreSQL via Drizzle · `@modelcontextprotocol/sdk` (Streamable HTTP, stateless).

## The adaptive loop (implemented and tested)

```
user message
  → analyze      intent, concept mentions, answer parsing, lexical affect cues        (analyze.ts, affect.ts)
  → evidence     BKT mastery update (+ prerequisite propagation), style credit/blame,
                 affect smoothing, activation/dormancy                               (mastery.ts, preferences.ts, dormancy.ts)
  → policy       graph-aware decision + rationale                                    (policy.ts)
  → execute      pick diagnostic question, track goal concept / pending question     (engine.ts)
  → compose      styled explanation from concept content (optional LLM rephrasing)   (compose.ts)
  → persist      interactions, decisions, learner state                              (store.ts)
```

## Models

| Layer | Approach | Why |
|---|---|---|
| **Concept graph** | Postgres tables `concepts` / `concept_edges` (prerequisite, related, part_of; weighted). Seeded with a 14-concept Probability & Statistics graph; extensible at runtime via MCP `add_concept`. | Prerequisite structure is what lets the tutor *reason* (readiness, step back, ZPD ordering) — the core finding of the KG-in-education literature. |
| **Mastery** | Bayesian Knowledge Tracing per concept (guess/slip/transit modulated by question difficulty and evidence type), spaced-repetition-style forgetting (half-life grows with practice), explicit uncertainty from evidence count, weak positive propagation to prerequisites on success. | Well-established, interpretable, works with sparse data; probabilities instead of known/unknown. |
| **Preferences** | Bernoulli bandit over 6 explanation styles (concise, detailed, example, analogy, formal, steps) with Beta posteriors + Thompson sampling. Rewards: correct follow-up answer / confirmation; penalties: wrong answer / confusion right after an explanation. Plus a scalar pace. | Preferences *emerge* from outcomes; Thompson sampling explores early and exploits once data exists. |
| **Affect** | 7-dim vector (confusion, frustration, boredom, engagement, confidence, fatigue, excitement) from lexical cues + behavioural cues (streaks, latency, repetition, session length), exponentially smoothed toward neutral. | Approximate by design; states chosen from affective-computing-in-education work (D'Mello & Graesser). The policy reacts only when evidence is strong. |
| **Dormancy** | ACT-R-like activation boosted on interaction, exponential decay (3-day half-life). `active → dormant (<0.25) → archived (>21 days)`. Dormant/archived branches get 0.5×/0.15× recommendation priority; mastery + history retained; revived on any interaction. | Weakens inactive branches without destroying information. |
| **Policy** | Deterministic, auditable rule engine over (learner state × graph × message): grade → advance / re-check / switch strategy / revisit prerequisite; confusion → switch style or step back; explicit asks (simpler / example / deeper / quiz / next); fatigue → break; frustration → slow down; boredom → skip ahead; unobserved prerequisite on a hard target → prerequisite check first. Every decision carries a rationale shown in the UI ("Why this?"). | Transparent and testable; the LLM (if configured) only rephrases, never decides. |

## MCP

`POST /api/mcp` — MCP Streamable HTTP (spec 2025-06-18), stateless mode via the official SDK's `WebStandardStreamableHTTPServerTransport` (fresh transport per request, JSON responses). Optional `MCP_ACCESS_TOKEN` bearer auth.

Tools: `get_learner_state`, `get_concept_graph`, `get_concept`, `get_recommendations`, `record_evidence`, `tutor_turn`, `get_interaction_history`, `add_concept`. Resource: `tutor://graph`. See `/mcp` in the app for a curl example and an `mcp-remote` config.

## Tests (all executed)

```bash
npx tsx scripts/test-engine.ts        # 26 unit tests: BKT, forgetting, affect, bandit, analyzer, dormancy, policy
npx tsx scripts/test-integration.ts   # 12-turn scenario through the real engine + Postgres, plus external evidence & dormancy
bash scripts/test-mcp.sh http://127.0.0.1:3000   # MCP protocol: initialize, tools/list, resources, tool calls, errors
```

## Optional

- `OPENAI_API_KEY` (+ `OPENAI_MODEL`): the composer asks the LLM to rephrase the template reply under strict constraints; on any failure it falls back to the template.
- `MCP_ACCESS_TOKEN`: protects the MCP endpoint.
