#!/usr/bin/env node
/**
 * stdio -> HTTP bridge for the Adaptive Teaching MCP server.
 *
 * Use this when an assistant only supports stdio MCP servers. It reads
 * newline-delimited JSON-RPC messages from stdin, forwards each one to the
 * HTTP endpoint, and writes the response back to stdout.
 *
 *   MCP_URL=http://localhost:3000/api/mcp node scripts/mcp-stdio-bridge.mjs
 *
 * Optional: MCP_AUTH_TOKEN=... (sent as a Bearer token)
 */
import { createInterface } from "node:readline";

const url = process.env.MCP_URL ?? "http://localhost:3000/api/mcp";
const token = process.env.MCP_AUTH_TOKEN;

const rl = createInterface({ input: process.stdin, crlfDelay: Infinity });
let chain = Promise.resolve();

rl.on("line", (line) => {
  const trimmed = line.trim();
  if (!trimmed) return;
  chain = chain.then(() => forward(trimmed)).catch((err) => {
    process.stderr.write(`[mcp-bridge] ${err?.message ?? err}\n`);
  });
});

async function forward(raw) {
  let id = null;
  try {
    const parsed = JSON.parse(raw);
    id = parsed?.id ?? null;
  } catch {
    // let the server produce the parse error
  }

  let res;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json, text/event-stream",
        ...(token ? { authorization: `Bearer ${token}` } : {}),
      },
      body: raw,
    });
  } catch (err) {
    if (id !== null) {
      write({ jsonrpc: "2.0", id, error: { code: -32000, message: `Cannot reach ${url}: ${err.message}` } });
    }
    return;
  }

  if (res.status === 202 || res.status === 204) return; // notification, no reply
  const text = await res.text();
  if (!text) return;

  const ct = res.headers.get("content-type") ?? "";
  if (ct.includes("text/event-stream")) {
    for (const block of text.split("\n\n")) {
      const data = block
        .split("\n")
        .filter((l) => l.startsWith("data:"))
        .map((l) => l.slice(5).trim())
        .join("\n");
      if (data) process.stdout.write(data + "\n");
    }
    return;
  }
  process.stdout.write(text.replace(/\n/g, " ") + "\n");
}

function write(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
}
