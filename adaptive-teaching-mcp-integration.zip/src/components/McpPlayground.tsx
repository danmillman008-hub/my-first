"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface ToolDef {
  name: string;
  description: string;
  inputSchema: { properties: Record<string, { type?: string; description?: string; enum?: string[] }>; required?: string[] };
  annotations?: { readOnlyHint?: boolean };
}

const PRESETS: Record<string, string> = {
  get_snapshot: '{ "learnerId": "default", "signalLimit": 5 }',
  get_summary: '{ "learnerId": "default" }',
  query_graph: '{ "learnerId": "default", "nodeType": "question", "limit": 5 }',
  update_estimate: '{ "learnerId": "default", "concept": "fractions", "evidence": 0.2, "weight": 0.8 }',
  branch_if: '{ "learnerId": "default", "concept": "fractions", "apply": false }',
  get_tip: '{ "learnerId": "default" }',
};

export default function McpPlayground() {
  const router = useRouter();
  const [tools, setTools] = useState<ToolDef[]>([]);
  const [selected, setSelected] = useState("get_summary");
  const [args, setArgs] = useState(PRESETS.get_summary);
  const [request, setRequest] = useState<string>("");
  const [response, setResponse] = useState<string>("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/mcp", {
      method: "POST",
      headers: { "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/list" }),
    })
      .then((r) => r.json())
      .then((d) => setTools(d.result?.tools ?? []))
      .catch(() => undefined);
  }, []);

  function pick(name: string) {
    setSelected(name);
    setArgs(PRESETS[name] ?? "{}");
    setResponse("");
  }

  async function call() {
    let parsed: unknown;
    try {
      parsed = JSON.parse(args || "{}");
    } catch {
      setResponse("Arguments are not valid JSON.");
      return;
    }
    const body = { jsonrpc: "2.0", id: Date.now(), method: "tools/call", params: { name: selected, arguments: parsed } };
    setRequest(JSON.stringify(body, null, 2));
    setBusy(true);
    try {
      const res = await fetch("/api/mcp", {
        method: "POST",
        headers: { "content-type": "application/json", accept: "application/json" },
        body: JSON.stringify(body),
      });
      const text = await res.text();
      try {
        setResponse(JSON.stringify(JSON.parse(text), null, 2));
      } catch {
        setResponse(text);
      }
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  const current = tools.find((t) => t.name === selected);

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 px-5 py-3">
        <h2 className="text-sm font-semibold text-slate-900">MCP playground</h2>
        <p className="text-xs text-slate-500">
          Sends real JSON-RPC 2.0 requests to <code className="rounded bg-slate-100 px-1">/api/mcp</code> — exactly what
          Gemini CLI / Claude Code / Cursor do.
        </p>
      </div>
      <div className="grid gap-4 p-5 lg:grid-cols-[220px_1fr]">
        <div className="space-y-1">
          {tools.length === 0 && <p className="text-xs text-slate-400">Loading tools/list…</p>}
          {tools.map((t) => (
            <button
              key={t.name}
              onClick={() => pick(t.name)}
              className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-xs font-medium ${
                selected === t.name ? "bg-indigo-600 text-white" : "text-slate-700 hover:bg-slate-50"
              }`}
            >
              <span className="font-mono">{t.name}</span>
              <span
                className={`ml-2 rounded px-1.5 py-0.5 text-[10px] ${
                  selected === t.name
                    ? "bg-white/20"
                    : t.annotations?.readOnlyHint
                      ? "bg-emerald-50 text-emerald-700"
                      : "bg-amber-50 text-amber-700"
                }`}
              >
                {t.annotations?.readOnlyHint ? "read" : "write"}
              </span>
            </button>
          ))}
        </div>

        <div className="space-y-3">
          {current && (
            <div className="rounded-xl bg-slate-50 px-4 py-3 text-xs text-slate-700">
              <p className="mb-2">{current.description}</p>
              <div className="flex flex-wrap gap-1.5">
                {Object.entries(current.inputSchema.properties).map(([k, v]) => (
                  <span key={k} className="rounded border border-slate-200 bg-white px-1.5 py-0.5 font-mono text-[10px]">
                    {k}
                    {current.inputSchema.required?.includes(k) ? "*" : ""}: {v.type ?? "any"}
                  </span>
                ))}
              </div>
            </div>
          )}
          <label className="block text-xs font-medium text-slate-600">
            arguments (JSON)
            <textarea
              value={args}
              onChange={(e) => setArgs(e.target.value)}
              rows={3}
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 font-mono text-xs outline-none focus:border-indigo-400"
            />
          </label>
          <button
            onClick={call}
            disabled={busy}
            className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 disabled:opacity-50"
          >
            {busy ? "Calling…" : `tools/call → ${selected}`}
          </button>

          {request && (
            <details className="text-xs">
              <summary className="cursor-pointer font-medium text-slate-600">request</summary>
              <pre className="mt-1 max-h-48 overflow-auto rounded-xl bg-slate-900 p-3 text-[11px] text-slate-100">{request}</pre>
            </details>
          )}
          {response && (
            <div className="text-xs">
              <div className="mb-1 font-medium text-slate-600">response</div>
              <pre className="max-h-80 overflow-auto rounded-xl bg-slate-900 p-3 text-[11px] text-emerald-100">{response}</pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
