"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

interface Msg {
  id: number | string;
  role: string;
  content: string;
}

interface StepInfo {
  concept: string | null;
  evidence: number | null;
  signals: { kind: string; concept: string | null }[];
  estimateUpdate: { estimate: { mastery: number; confidence: number }; delta: number } | null;
  branchDecision: { shouldBranch: boolean; applied: boolean; reason: string } | null;
  mergedBack: boolean;
}

export default function ChatPanel({ learnerId }: { learnerId: string }) {
  const router = useRouter();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [last, setLast] = useState<StepInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch(`/api/session?learnerId=${encodeURIComponent(learnerId)}`)
      .then((r) => r.json())
      .then((d) => setMessages((d.messages ?? []) as Msg[]))
      .catch(() => undefined);
  }, [learnerId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function send(text?: string) {
    const content = (text ?? input).trim();
    if (!content || busy) return;
    setBusy(true);
    setError(null);
    setInput("");
    setMessages((m) => [...m, { id: `l-${Date.now()}`, role: "learner", content }]);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ learnerId, message: content }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Request failed");
      setMessages((m) => [...m, { id: `t-${Date.now()}`, role: "tutor", content: data.reply }]);
      setLast(data as StepInfo);
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  async function newSession() {
    await fetch("/api/session", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ learnerId }),
    });
    setMessages([]);
    setLast(null);
    router.refresh();
  }

  const quick = ["Let's learn fractions", "3/4", "I don't understand decimals", "0.75", "20% of 50 is 10"];

  return (
    <div className="flex h-full flex-col rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3">
        <div>
          <h2 className="text-sm font-semibold text-slate-900">Tutor chat</h2>
          <p className="text-xs text-slate-500">Each message runs one adaptive-loop step.</p>
        </div>
        <button
          onClick={newSession}
          className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50"
        >
          New session
        </button>
      </div>

      <div className="flex-1 space-y-3 overflow-y-auto px-5 py-4" style={{ minHeight: 320, maxHeight: 440 }}>
        {messages.length === 0 && (
          <p className="text-sm text-slate-400">
            Say hi to the tutor. Try “Let&apos;s learn fractions” and then answer the question it asks.
          </p>
        )}
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.role === "learner" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm leading-relaxed ${
                m.role === "learner" ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-800"
              }`}
            >
              {m.content}
            </div>
          </div>
        ))}
        {busy && <div className="text-xs text-slate-400">tutor is thinking…</div>}
        <div ref={bottomRef} />
      </div>

      {last && (
        <div className="mx-5 mb-3 rounded-xl border border-indigo-100 bg-indigo-50/60 px-4 py-3 text-xs text-slate-700">
          <div className="mb-1 font-semibold text-indigo-900">Last step trace</div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
            <span>concept: <b>{last.concept ?? "—"}</b></span>
            <span>evidence: <b>{last.evidence === null ? "—" : last.evidence.toFixed(2)}</b></span>
            <span>
              signals: <b>{last.signals.length ? last.signals.map((s) => s.kind).join(", ") : "none"}</b>
            </span>
            <span>
              mastery:{" "}
              <b>
                {last.estimateUpdate
                  ? `${last.estimateUpdate.estimate.mastery.toFixed(2)} (${last.estimateUpdate.delta >= 0 ? "+" : ""}${last.estimateUpdate.delta.toFixed(2)})`
                  : "—"}
              </b>
            </span>
            <span className="col-span-2">
              branch:{" "}
              <b>
                {last.mergedBack
                  ? "merged back to main"
                  : last.branchDecision
                    ? `${last.branchDecision.applied ? "opened" : last.branchDecision.shouldBranch ? "already active" : "no"} — ${last.branchDecision.reason}`
                    : "—"}
              </b>
            </span>
          </div>
        </div>
      )}

      {error && <div className="mx-5 mb-2 text-xs text-red-600">{error}</div>}

      <div className="border-t border-slate-100 px-5 py-3">
        <div className="mb-2 flex flex-wrap gap-1.5">
          {quick.map((q) => (
            <button
              key={q}
              onClick={() => send(q)}
              disabled={busy}
              className="rounded-full border border-slate-200 px-2.5 py-1 text-[11px] text-slate-600 hover:bg-slate-50 disabled:opacity-50"
            >
              {q}
            </button>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            send();
          }}
          className="flex gap-2"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your answer or question…"
            className="flex-1 rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400"
          />
          <button
            type="submit"
            disabled={busy || !input.trim()}
            className="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
}
