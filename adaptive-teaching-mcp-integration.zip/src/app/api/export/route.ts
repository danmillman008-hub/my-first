import { ensureLearner, getEdges, getNodes, getBranches } from "@/lib/middleware/graph-engine";
import { getSnapshot } from "@/lib/middleware/signal-extractor";
import { getSummary } from "@/lib/middleware/learner-summary";
import { validateLearnerKey, ValidationError } from "@/lib/middleware/validator";

export const dynamic = "force-dynamic";

/** GET /api/export?learnerId=default -> full JSON export of the learner's graph & model */
export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const key = validateLearnerKey(url.searchParams.get("learnerId"));
    const learner = await ensureLearner(key);
    const [snapshot, summary, branchList, nodeList, edgeList] = await Promise.all([
      getSnapshot(learner.id, { signalLimit: 200 }),
      getSummary(learner.id),
      getBranches(learner.id),
      getNodes({ learnerId: learner.id, limit: 500 }),
      getEdges({ learnerId: learner.id, limit: 500 }),
    ]);
    const payload = {
      exportedAt: new Date().toISOString(),
      learner,
      summary,
      snapshot,
      graph: { branches: branchList, nodes: nodeList, edges: edgeList },
    };
    return new Response(JSON.stringify(payload, null, 2), {
      headers: {
        "content-type": "application/json",
        "content-disposition": `attachment; filename="learner-${key}-export.json"`,
      },
    });
  } catch (err) {
    if (err instanceof ValidationError) return Response.json({ error: err.message }, { status: 400 });
    console.error("[export]", err);
    return Response.json({ error: "Internal error" }, { status: 500 });
  }
}
