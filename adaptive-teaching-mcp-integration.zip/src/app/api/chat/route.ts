import { runAdaptiveStep } from "@/lib/middleware/adaptive-loop";
import { ValidationError } from "@/lib/middleware/validator";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as {
      learnerId?: string;
      message?: string;
      sessionId?: number;
    };
    const result = await runAdaptiveStep({
      learnerKey: body.learnerId ?? "default",
      message: body.message ?? "",
      sessionId: body.sessionId,
    });
    return Response.json(result);
  } catch (err) {
    if (err instanceof ValidationError) {
      return Response.json({ error: err.message }, { status: 400 });
    }
    console.error("[chat]", err);
    return Response.json({ error: "Internal error" }, { status: 500 });
  }
}
