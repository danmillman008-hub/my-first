/**
 * MCP Streamable HTTP endpoint (stateless mode).
 *
 *   POST   /api/mcp   JSON-RPC 2.0 request / notification / batch
 *   GET    /api/mcp   Discovery manifest (plain JSON). Server-initiated SSE
 *                     streams are not used, so clients asking for
 *                     text/event-stream get 405 as the spec allows.
 *   DELETE /api/mcp   Session termination (no-op; server is stateless)
 *   OPTIONS/api/mcp   CORS preflight
 */
import { handleRawJsonRpc, getServerManifest, LATEST_PROTOCOL_VERSION } from "@/lib/mcp/server";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const CORS_HEADERS: Record<string, string> = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, POST, DELETE, OPTIONS",
  "access-control-allow-headers":
    "content-type, accept, authorization, mcp-session-id, mcp-protocol-version, last-event-id",
  "access-control-expose-headers": "mcp-session-id, mcp-protocol-version",
};

function baseHeaders(extra: Record<string, string> = {}): Record<string, string> {
  return { ...CORS_HEADERS, "mcp-protocol-version": LATEST_PROTOCOL_VERSION, ...extra };
}

function checkAuth(req: Request): Response | null {
  const token = process.env.MCP_AUTH_TOKEN;
  if (!token) return null;
  const header = req.headers.get("authorization") ?? "";
  const provided = header.toLowerCase().startsWith("bearer ") ? header.slice(7).trim() : "";
  if (provided === token) return null;
  return new Response(JSON.stringify({ jsonrpc: "2.0", id: null, error: { code: -32001, message: "Unauthorized" } }), {
    status: 401,
    headers: baseHeaders({ "content-type": "application/json", "www-authenticate": "Bearer" }),
  });
}

export async function POST(req: Request) {
  const denied = checkAuth(req);
  if (denied) return denied;

  const raw = await req.text();
  const response = await handleRawJsonRpc(raw);

  // Notifications / responses only -> 202 Accepted with empty body (per spec).
  if (response === null) {
    return new Response(null, { status: 202, headers: baseHeaders() });
  }

  const accept = req.headers.get("accept") ?? "";
  const wantsSseOnly = accept.includes("text/event-stream") && !accept.includes("application/json");

  // Some clients only accept SSE; wrap the single JSON response in one event.
  if (wantsSseOnly) {
    const payload = Array.isArray(response) ? response : [response];
    const body = payload.map((r, i) => `id: ${Date.now()}-${i}\nevent: message\ndata: ${JSON.stringify(r)}\n\n`).join("");
    return new Response(body, {
      status: 200,
      headers: baseHeaders({ "content-type": "text/event-stream", "cache-control": "no-cache, no-transform" }),
    });
  }

  return new Response(JSON.stringify(response), {
    status: 200,
    headers: baseHeaders({ "content-type": "application/json" }),
  });
}

export async function GET(req: Request) {
  const denied = checkAuth(req);
  if (denied) return denied;

  const accept = req.headers.get("accept") ?? "";
  if (accept.includes("text/event-stream") && !accept.includes("application/json")) {
    // No server-initiated messages in stateless mode.
    return new Response(null, { status: 405, headers: baseHeaders({ allow: "POST, DELETE, OPTIONS" }) });
  }
  return new Response(JSON.stringify(getServerManifest(), null, 2), {
    status: 200,
    headers: baseHeaders({ "content-type": "application/json" }),
  });
}

export async function DELETE(req: Request) {
  const denied = checkAuth(req);
  if (denied) return denied;
  // Stateless server: nothing to tear down.
  return new Response(null, { status: 200, headers: baseHeaders() });
}

export async function OPTIONS() {
  return new Response(null, { status: 204, headers: baseHeaders() });
}
