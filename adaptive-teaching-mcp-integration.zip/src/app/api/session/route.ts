import { endSession, getOrCreateOpenSession, getSessionMessages, startSession } from "@/lib/middleware/adaptive-loop";
import { ensureLearner } from "@/lib/middleware/graph-engine";
import { validateLearnerKey, ValidationError } from "@/lib/middleware/validator";

export const dynamic = "force-dynamic";

/** GET /api/session?learnerId=default -> current open session + its messages */
export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const learner = await ensureLearner(validateLearnerKey(url.searchParams.get("learnerId")));
    const session = await getOrCreateOpenSession(learner.id);
    const history = await getSessionMessages(session.id);
    return Response.json({ learnerId: learner.id, session, messages: history });
  } catch (err) {
    if (err instanceof ValidationError) return Response.json({ error: err.message }, { status: 400 });
    console.error("[session:get]", err);
    return Response.json({ error: "Internal error" }, { status: 500 });
  }
}

/** POST /api/session { learnerId } -> start a new session */
export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as { learnerId?: string };
    const result = await startSession(body.learnerId ?? "default");
    return Response.json(result, { status: 201 });
  } catch (err) {
    if (err instanceof ValidationError) return Response.json({ error: err.message }, { status: 400 });
    console.error("[session:post]", err);
    return Response.json({ error: "Internal error" }, { status: 500 });
  }
}

/** DELETE /api/session { sessionId } -> end a session */
export async function DELETE(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as { sessionId?: number };
    if (!body.sessionId) return Response.json({ error: "sessionId is required" }, { status: 400 });
    const session = await endSession(body.sessionId);
    if (!session) return Response.json({ error: "Session not found" }, { status: 404 });
    return Response.json({ session });
  } catch (err) {
    console.error("[session:delete]", err);
    return Response.json({ error: "Internal error" }, { status: 500 });
  }
}
