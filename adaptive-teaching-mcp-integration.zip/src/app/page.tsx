import ChatPanel from "@/components/ChatPanel";
import McpPlayground from "@/components/McpPlayground";
import { createInProcessClient } from "@/lib/mcp/client";
import type { LearnerSummary } from "@/lib/middleware/learner-summary";
import type { LearnerSnapshot } from "@/lib/middleware/signal-extractor";

export const dynamic = "force-dynamic";

const STATUS_STYLE: Record<string, string> = {
  mastered: "bg-emerald-100 text-emerald-800",
  developing: "bg-sky-100 text-sky-800",
  weak: "bg-rose-100 text-rose-800",
  unseen: "bg-slate-100 text-slate-500",
};

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ learner?: string }>;
}) {
  const { learner } = await searchParams;
  const learnerKey = learner?.trim() || "default";

  // Consume our own MCP layer in-process: same code path external assistants hit.
  const mcp = createInProcessClient();
  const [summaryRes, snapshotRes] = await Promise.all([
    mcp.callTool("get_summary", { learnerId: learnerKey }),
    mcp.callTool("get_snapshot", { learnerId: learnerKey, signalLimit: 8 }),
  ]);
  const summary = summaryRes.structuredContent as unknown as LearnerSummary;
  const snapshot = snapshotRes.structuredContent as unknown as LearnerSnapshot;

  return (
    <main className="mx-auto max-w-7xl px-6 py-10">
      <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.12em] text-indigo-600">Adaptive Teaching</p>
          <h1 className="mt-1 text-3xl font-semibold text-slate-950">Learner model + MCP layer</h1>
          <p className="mt-2 max-w-2xl text-sm text-slate-600">
            The tutor observes signals, updates mastery estimates and branches the learning graph. The same state is
            exposed to external assistants through an MCP server at{" "}
            <code className="rounded bg-slate-200 px-1.5 py-0.5 text-xs">/api/mcp</code>.
          </p>
        </div>
        <form className="flex items-center gap-2 text-sm">
          <label className="text-slate-600">learner</label>
          <input
            name="learner"
            defaultValue={learnerKey}
            className="w-40 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-sm outline-none focus:border-indigo-400"
          />
          <button className="rounded-lg bg-slate-900 px-3 py-1.5 text-sm font-medium text-white">Switch</button>
          <a
            href={`/api/export?learnerId=${encodeURIComponent(learnerKey)}`}
            className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-50"
          >
            Export JSON
          </a>
        </form>
      </header>

      <section className="mb-6 grid gap-4 md:grid-cols-4">
        <Stat label="Overall mastery" value={`${Math.round(summary.overallMastery * 100)}%`} />
        <Stat label="Model confidence" value={`${Math.round(summary.overallConfidence * 100)}%`} />
        <Stat label="Active branch" value={summary.activeBranch.name} sub={summary.activeBranch.reason ?? undefined} />
        <Stat
          label="Graph"
          value={`${snapshot.counts.nodes} nodes · ${snapshot.counts.edges} edges`}
          sub={`${snapshot.counts.branches} branches · ${snapshot.counts.signals} signals`}
        />
      </section>

      <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
        <ChatPanel learnerId={learnerKey} />

        <div className="space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="text-sm font-semibold text-slate-900">Learning summary</h2>
            <p className="mt-1 text-sm text-slate-600">{summary.headline}</p>
            {summary.nextRecommendation && (
              <div className="mt-3 rounded-xl border border-indigo-100 bg-indigo-50/70 px-4 py-3 text-sm">
                <span className="font-semibold text-indigo-900">
                  Next: {summary.nextRecommendation.action} → {summary.nextRecommendation.title}
                </span>
                <p className="mt-0.5 text-xs text-indigo-800/80">{summary.nextRecommendation.rationale}</p>
              </div>
            )}
            <ul className="mt-4 space-y-2">
              {summary.concepts.map((c) => (
                <li key={c.concept} className="text-sm">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-slate-800">{c.title}</span>
                    <span className="flex items-center gap-2 text-xs text-slate-500">
                      <span>{c.attempts} obs</span>
                      <span className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${STATUS_STYLE[c.status]}`}>
                        {c.status}
                      </span>
                    </span>
                  </div>
                  <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full bg-indigo-500"
                      style={{ width: `${Math.round(c.mastery * 100)}%`, opacity: 0.35 + c.confidence * 0.65 }}
                    />
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="text-sm font-semibold text-slate-900">Tip node</h2>
            <p className="mt-1 text-xs text-slate-500">
              #{snapshot.tip.id} · {snapshot.tip.type}
              {snapshot.tip.concept ? ` · ${snapshot.tip.concept}` : ""}
            </p>
            <p className="mt-2 text-sm text-slate-700">{snapshot.tip.content}</p>

            <h3 className="mt-4 text-xs font-semibold uppercase tracking-wide text-slate-500">Recent signals</h3>
            {snapshot.recentSignals.length === 0 ? (
              <p className="mt-1 text-xs text-slate-400">None yet.</p>
            ) : (
              <ul className="mt-1 space-y-1">
                {snapshot.recentSignals.map((s) => (
                  <li key={s.id} className="flex items-center justify-between text-xs text-slate-600">
                    <span>
                      <span className="font-mono text-slate-800">{s.kind}</span>
                      {s.concept ? <span className="text-slate-400"> · {s.concept}</span> : null}
                    </span>
                    <span className="text-slate-400">{s.evidence}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>

      <div className="mt-6">
        <McpPlayground />
      </div>

      <footer className="mt-8 text-xs text-slate-400">
        MCP endpoint: <code>POST /api/mcp</code> · methods: initialize, tools/list, tools/call · see README_MCP.md
      </footer>
    </main>
  );
}

function Stat({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white px-5 py-4 shadow-sm">
      <p className="text-xs uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-1 truncate text-lg font-semibold text-slate-900">{value}</p>
      {sub && <p className="truncate text-xs text-slate-500">{sub}</p>}
    </div>
  );
}
