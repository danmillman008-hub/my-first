/**
 * MCP tool registry for the Adaptive Teaching system.
 *
 * Every tool is a thin adapter: it validates arguments, resolves the learner
 * key to an internal id, and delegates to the *existing* middleware functions.
 * No adaptive logic lives here.
 */
import { getSnapshot } from "@/lib/middleware/signal-extractor";
import { getSummary } from "@/lib/middleware/learner-summary";
import {
  getNodes,
  getEdges,
  getTip,
  branchIfThreshold,
  ensureLearner,
  getBranches,
  NODE_TYPES,
  EDGE_TYPES,
  DEFAULT_BRANCH_THRESHOLD,
} from "@/lib/middleware/graph-engine";
import { updateEstimate } from "@/lib/middleware/learner-model";
import { CONCEPT_IDS } from "@/lib/middleware/curriculum";
import {
  validateConcept,
  validateLearnerKey,
  validateLimit,
  validateOptionalInt,
  validateUnit,
  ValidationError,
} from "@/lib/middleware/validator";

/* ------------------------------------------------------------------ */
/* Types (subset of the MCP schema)                                    */
/* ------------------------------------------------------------------ */

export interface JsonSchema {
  type: "object";
  properties: Record<string, unknown>;
  required?: string[];
  additionalProperties?: boolean;
}

export interface ToolAnnotations {
  title?: string;
  readOnlyHint?: boolean;
  destructiveHint?: boolean;
  idempotentHint?: boolean;
  openWorldHint?: boolean;
}

export interface McpToolDefinition {
  name: string;
  title?: string;
  description: string;
  inputSchema: JsonSchema;
  annotations?: ToolAnnotations;
}

export interface McpTool extends McpToolDefinition {
  handler: (args: Record<string, unknown>) => Promise<unknown>;
}

export interface McpToolResult {
  content: Array<{ type: "text"; text: string }>;
  structuredContent?: Record<string, unknown>;
  isError?: boolean;
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

const learnerIdProp = {
  type: "string",
  description:
    'External learner identifier (any stable string, e.g. a username). Defaults to "default". The learner is created on first use.',
} as const;

async function resolveLearner(args: Record<string, unknown>): Promise<number> {
  const key = validateLearnerKey(args.learnerId ?? args.learner_id);
  const learner = await ensureLearner(key);
  return learner.id;
}

/* ------------------------------------------------------------------ */
/* Tool definitions                                                    */
/* ------------------------------------------------------------------ */

export const tools: McpTool[] = [
  {
    name: "get_snapshot",
    title: "Get learner snapshot",
    description:
      "Return a compact snapshot of the learner's current state: active branch, tip node, all branches, mastery estimates per concept, recent signals and graph counts. Read-only.",
    inputSchema: {
      type: "object",
      properties: {
        learnerId: learnerIdProp,
        signalLimit: { type: "integer", minimum: 1, maximum: 200, description: "How many recent signals to include (default 15)." },
      },
      additionalProperties: false,
    },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
    handler: async (args) => {
      const learnerId = await resolveLearner(args);
      return getSnapshot(learnerId, { signalLimit: validateLimit(args.signalLimit, 15, 200) });
    },
  },
  {
    name: "get_summary",
    title: "Get learning summary",
    description:
      "Return a human-friendly learning summary: overall mastery, per-concept status (mastered / developing / weak / unseen), weak concepts, and the recommended next action (remediate / practice / introduce / review). Read-only.",
    inputSchema: {
      type: "object",
      properties: { learnerId: learnerIdProp },
      additionalProperties: false,
    },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
    handler: async (args) => {
      const learnerId = await resolveLearner(args);
      return getSummary(learnerId);
    },
  },
  {
    name: "query_graph",
    title: "Query learning graph",
    description:
      "Query the learner's concept graph. Filter nodes by type/concept/branch and edges by type/endpoints. Returns branches, nodes and edges (newest first). Read-only.",
    inputSchema: {
      type: "object",
      properties: {
        learnerId: learnerIdProp,
        nodeType: { type: "string", enum: [...NODE_TYPES], description: "Only return nodes of this type." },
        edgeType: { type: "string", enum: [...EDGE_TYPES], description: "Only return edges of this type." },
        concept: { type: "string", enum: [...CONCEPT_IDS], description: "Only return nodes about this concept." },
        branchId: { type: "integer", description: "Only return nodes on this branch." },
        fromNodeId: { type: "integer", description: "Only return edges starting at this node." },
        toNodeId: { type: "integer", description: "Only return edges ending at this node." },
        include: {
          type: "array",
          items: { type: "string", enum: ["nodes", "edges", "branches"] },
          description: 'Which collections to return. Default: ["nodes","edges","branches"].',
        },
        limit: { type: "integer", minimum: 1, maximum: 500, description: "Max rows per collection (default 50)." },
      },
      additionalProperties: false,
    },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
    handler: async (args) => {
      const learnerId = await resolveLearner(args);
      const include = new Set(
        Array.isArray(args.include) && args.include.length
          ? (args.include as string[])
          : ["nodes", "edges", "branches"],
      );
      const limit = validateLimit(args.limit, 50, 500);
      const concept = args.concept ? validateConcept(args.concept) : undefined;

      const [nodeList, edgeList, branchList] = await Promise.all([
        include.has("nodes")
          ? getNodes({
              learnerId,
              type: args.nodeType as string | undefined,
              concept,
              branchId: validateOptionalInt(args.branchId, "branchId"),
              limit,
            })
          : Promise.resolve([]),
        include.has("edges")
          ? getEdges({
              learnerId,
              type: args.edgeType as string | undefined,
              fromNodeId: validateOptionalInt(args.fromNodeId, "fromNodeId"),
              toNodeId: validateOptionalInt(args.toNodeId, "toNodeId"),
              limit,
            })
          : Promise.resolve([]),
        include.has("branches") ? getBranches(learnerId) : Promise.resolve([]),
      ]);

      return {
        learnerId,
        counts: { nodes: nodeList.length, edges: edgeList.length, branches: branchList.length },
        ...(include.has("branches") ? { branches: branchList } : {}),
        ...(include.has("nodes") ? { nodes: nodeList } : {}),
        ...(include.has("edges") ? { edges: edgeList } : {}),
      };
    },
  },
  {
    name: "update_estimate",
    title: "Update mastery estimate",
    description:
      "Update the learner's mastery estimate for a concept through the learner model. Provide `evidence` (0 = failed, 1 = perfect) for an incremental Bayesian-style update, or `mastery` to set an absolute value. Returns previous and new estimate.",
    inputSchema: {
      type: "object",
      properties: {
        learnerId: learnerIdProp,
        concept: { type: "string", enum: [...CONCEPT_IDS], description: "Concept identifier." },
        evidence: { type: "number", minimum: 0, maximum: 1, description: "Observed performance for this interaction (0..1)." },
        weight: { type: "number", minimum: 0, maximum: 1, description: "Trust in this observation (0..1, default 0.5)." },
        mastery: { type: "number", minimum: 0, maximum: 1, description: "Absolute override of mastery (0..1). If set, `evidence` is ignored." },
      },
      required: ["concept"],
      additionalProperties: false,
    },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false },
    handler: async (args) => {
      const learnerId = await resolveLearner(args);
      const concept = validateConcept(args.concept);
      if (args.evidence === undefined && args.mastery === undefined) {
        throw new ValidationError("Provide either `evidence` (0..1) or `mastery` (0..1).");
      }
      return updateEstimate({
        learnerId,
        concept,
        evidence: args.evidence === undefined ? 0 : validateUnit(args.evidence, "evidence"),
        weight: args.weight === undefined ? undefined : validateUnit(args.weight, "weight"),
        mastery: args.mastery === undefined ? undefined : validateUnit(args.mastery, "mastery"),
      });
    },
  },
  {
    name: "branch_if",
    title: "Evaluate / apply branching",
    description:
      `Check whether the learner should branch into a remediation path for a concept (mastery below threshold, default ${DEFAULT_BRANCH_THRESHOLD}, with enough confidence). With apply=false it is a dry-run; with apply=true (default) the branch is created in the graph when warranted.`,
    inputSchema: {
      type: "object",
      properties: {
        learnerId: learnerIdProp,
        concept: { type: "string", enum: [...CONCEPT_IDS], description: "Concept to evaluate." },
        threshold: { type: "number", minimum: 0, maximum: 1, description: `Mastery threshold (default ${DEFAULT_BRANCH_THRESHOLD}).` },
        apply: { type: "boolean", description: "Create the branch if warranted (default true). Set false for a dry-run." },
      },
      required: ["concept"],
      additionalProperties: false,
    },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false },
    handler: async (args) => {
      const learnerId = await resolveLearner(args);
      return branchIfThreshold({
        learnerId,
        concept: validateConcept(args.concept),
        threshold: args.threshold === undefined ? undefined : validateUnit(args.threshold, "threshold"),
        apply: args.apply === undefined ? true : Boolean(args.apply),
      });
    },
  },
  {
    name: "get_tip",
    title: "Get current tip node",
    description:
      "Return the current tip (most recent node) of the learner's active branch, or of a specific branch when branchId is given. Read-only.",
    inputSchema: {
      type: "object",
      properties: {
        learnerId: learnerIdProp,
        branchId: { type: "integer", description: "Branch to inspect (defaults to the active branch)." },
      },
      additionalProperties: false,
    },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
    handler: async (args) => {
      const learnerId = await resolveLearner(args);
      const tip = await getTip(learnerId, validateOptionalInt(args.branchId, "branchId"));
      return { learnerId, tip };
    },
  },
];

export const toolMap = new Map(tools.map((t) => [t.name, t]));

/** Public tool descriptors (without handlers) as returned by tools/list. */
export function listToolDefinitions(): McpToolDefinition[] {
  return tools.map(({ name, title, description, inputSchema, annotations }) => ({
    name,
    title,
    description,
    inputSchema,
    annotations,
  }));
}
