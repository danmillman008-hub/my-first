/**
 * Small MCP client for internal testing.
 *
 * Two modes:
 *  - `createInProcessClient()` calls the server dispatcher directly (no HTTP),
 *    handy inside server components / route handlers / tests.
 *  - `createHttpClient(url)` speaks JSON-RPC over HTTP to a running endpoint,
 *    exactly like an external assistant would.
 */
import type { JsonRpcResponse } from "./server";
import type { McpToolDefinition, McpToolResult } from "./tools";

export interface McpClient {
  initialize(): Promise<Record<string, unknown>>;
  listTools(): Promise<McpToolDefinition[]>;
  callTool(name: string, args?: Record<string, unknown>): Promise<McpToolResult>;
  /** Raw JSON-RPC call. */
  request<T = unknown>(method: string, params?: unknown): Promise<T>;
}

type Sender = (message: unknown) => Promise<JsonRpcResponse | JsonRpcResponse[] | null>;

let nextId = 1;

function buildClient(send: Sender): McpClient {
  async function request<T>(method: string, params?: unknown): Promise<T> {
    const id = nextId++;
    const res = await send({ jsonrpc: "2.0", id, method, params });
    const single = Array.isArray(res) ? res.find((r) => r.id === id) : res;
    if (!single) throw new Error(`No response for ${method}`);
    if ("error" in single) {
      throw new Error(`${method} failed (${single.error.code}): ${single.error.message}`);
    }
    return single.result as T;
  }

  return {
    request,
    async initialize() {
      const result = await request<Record<string, unknown>>("initialize", {
        protocolVersion: "2025-06-18",
        capabilities: {},
        clientInfo: { name: "adaptive-teaching-internal-client", version: "1.0.0" },
      });
      await send({ jsonrpc: "2.0", method: "notifications/initialized" });
      return result;
    },
    async listTools() {
      const result = await request<{ tools: McpToolDefinition[] }>("tools/list");
      return result.tools;
    },
    async callTool(name, args = {}) {
      return request<McpToolResult>("tools/call", { name, arguments: args });
    },
  };
}

/** Client that talks to the dispatcher in the same process (no network). */
export function createInProcessClient(): McpClient {
  return buildClient(async (message) => {
    const { handleJsonRpc } = await import("./server");
    return handleJsonRpc(message);
  });
}

/** Client that talks to an HTTP MCP endpoint (e.g. http://localhost:3000/api/mcp). */
export function createHttpClient(url: string, opts: { token?: string } = {}): McpClient {
  return buildClient(async (message) => {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json, text/event-stream",
        ...(opts.token ? { authorization: `Bearer ${opts.token}` } : {}),
      },
      body: JSON.stringify(message),
    });
    if (res.status === 202) return null;
    if (!res.ok) throw new Error(`MCP HTTP ${res.status}: ${await res.text()}`);
    return (await res.json()) as JsonRpcResponse | JsonRpcResponse[];
  });
}
