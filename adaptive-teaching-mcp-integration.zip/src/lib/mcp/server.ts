/**
 * Minimal, dependency-free MCP server (JSON-RPC 2.0) for the Adaptive
 * Teaching system.
 *
 * Transport-agnostic: `handleJsonRpc` takes a parsed JSON-RPC message (or
 * batch) and returns the response(s). `src/app/api/mcp/route.ts` binds it to
 * HTTP (MCP "Streamable HTTP" transport, stateless mode) and
 * `scripts/mcp-stdio-bridge.mjs` bridges stdio clients to that endpoint.
 */
import { ValidationError } from "@/lib/middleware/validator";
import { listToolDefinitions, toolMap, type McpToolResult } from "./tools";

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

export const SERVER_INFO = {
  name: "adaptive-teaching-mcp",
  title: "Adaptive Teaching MCP",
  version: "1.0.0",
} as const;

export const SUPPORTED_PROTOCOL_VERSIONS = ["2025-06-18", "2025-03-26", "2024-11-05"] as const;
export const LATEST_PROTOCOL_VERSION = SUPPORTED_PROTOCOL_VERSIONS[0];

export const SERVER_INSTRUCTIONS = [
  "This server exposes a learner model and a branching concept graph for an adaptive tutoring system.",
  "Read state with get_snapshot / get_summary / get_tip / query_graph.",
  "Mutate state with update_estimate (mastery evidence) and branch_if (remediation branching).",
  'All tools accept an optional `learnerId` string (defaults to "default").',
  "Known concepts: fractions, decimals, percentages, ratios, algebra-basics.",
].join(" ");

/* JSON-RPC error codes */
export const PARSE_ERROR = -32700;
export const INVALID_REQUEST = -32600;
export const METHOD_NOT_FOUND = -32601;
export const INVALID_PARAMS = -32602;
export const INTERNAL_ERROR = -32603;

/* ------------------------------------------------------------------ */
/* JSON-RPC types                                                      */
/* ------------------------------------------------------------------ */

export type JsonRpcId = string | number | null;

export interface JsonRpcRequest {
  jsonrpc: "2.0";
  id?: JsonRpcId;
  method: string;
  params?: unknown;
}

export interface JsonRpcSuccess {
  jsonrpc: "2.0";
  id: JsonRpcId;
  result: unknown;
}

export interface JsonRpcFailure {
  jsonrpc: "2.0";
  id: JsonRpcId;
  error: { code: number; message: string; data?: unknown };
}

export type JsonRpcResponse = JsonRpcSuccess | JsonRpcFailure;

export class JsonRpcError extends Error {
  constructor(
    public readonly code: number,
    message: string,
    public readonly data?: unknown,
  ) {
    super(message);
    this.name = "JsonRpcError";
  }
}

function ok(id: JsonRpcId, result: unknown): JsonRpcSuccess {
  return { jsonrpc: "2.0", id, result };
}

function fail(id: JsonRpcId, code: number, message: string, data?: unknown): JsonRpcFailure {
  return { jsonrpc: "2.0", id, error: data === undefined ? { code, message } : { code, message, data } };
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

/* ------------------------------------------------------------------ */
/* Method handlers                                                     */
/* ------------------------------------------------------------------ */

function handleInitialize(params: unknown) {
  const requested = isRecord(params) && typeof params.protocolVersion === "string" ? params.protocolVersion : undefined;
  const protocolVersion =
    requested && (SUPPORTED_PROTOCOL_VERSIONS as readonly string[]).includes(requested)
      ? requested
      : LATEST_PROTOCOL_VERSION;

  return {
    protocolVersion,
    capabilities: {
      tools: { listChanged: false },
      resources: { subscribe: false, listChanged: false },
      prompts: { listChanged: false },
    },
    serverInfo: SERVER_INFO,
    instructions: SERVER_INSTRUCTIONS,
  };
}

function toToolResult(value: unknown): McpToolResult {
  const structured = isRecord(value) ? value : { value };
  return {
    content: [{ type: "text", text: JSON.stringify(value, null, 2) }],
    structuredContent: structured,
  };
}

function toolErrorResult(message: string): McpToolResult {
  return { content: [{ type: "text", text: message }], isError: true };
}

/** Execute a registered tool. Exported so internal code (client.ts, UI) can call tools directly. */
export async function callTool(name: string, args: unknown): Promise<McpToolResult> {
  const tool = toolMap.get(name);
  if (!tool) {
    throw new JsonRpcError(INVALID_PARAMS, `Unknown tool: ${name}`, { availableTools: [...toolMap.keys()] });
  }
  if (args !== undefined && !isRecord(args)) {
    throw new JsonRpcError(INVALID_PARAMS, "tool arguments must be an object");
  }
  try {
    const value = await tool.handler(args ?? {});
    return toToolResult(value);
  } catch (err) {
    // Domain/validation problems are reported as tool errors (isError: true),
    // so the LLM can see and self-correct - per MCP spec.
    if (err instanceof ValidationError) return toolErrorResult(`Validation error: ${err.message}`);
    console.error(`[mcp] tool ${name} failed`, err);
    return toolErrorResult(`Tool "${name}" failed: ${err instanceof Error ? err.message : String(err)}`);
  }
}

async function dispatch(method: string, params: unknown): Promise<unknown> {
  switch (method) {
    case "initialize":
      return handleInitialize(params);
    case "ping":
      return {};
    case "tools/list":
      return { tools: listToolDefinitions() };
    case "tools/call": {
      if (!isRecord(params) || typeof params.name !== "string") {
        throw new JsonRpcError(INVALID_PARAMS, "tools/call requires params.name");
      }
      return callTool(params.name, params.arguments);
    }
    case "resources/list":
      return { resources: [] };
    case "resources/templates/list":
      return { resourceTemplates: [] };
    case "prompts/list":
      return { prompts: [] };
    case "logging/setLevel":
      return {};
    case "completion/complete":
      return { completion: { values: [], hasMore: false } };
    default:
      throw new JsonRpcError(METHOD_NOT_FOUND, `Method not found: ${method}`);
  }
}

/* ------------------------------------------------------------------ */
/* Public entrypoint                                                   */
/* ------------------------------------------------------------------ */

/**
 * Handle a single JSON-RPC message. Returns `null` for notifications
 * (messages without an id), which must not receive a response.
 */
export async function handleMessage(message: unknown): Promise<JsonRpcResponse | null> {
  if (!isRecord(message) || message.jsonrpc !== "2.0" || typeof message.method !== "string") {
    const id = isRecord(message) && (typeof message.id === "string" || typeof message.id === "number") ? message.id : null;
    return fail(id, INVALID_REQUEST, "Invalid JSON-RPC 2.0 request");
  }

  const req = message as unknown as JsonRpcRequest;
  const isNotification = req.id === undefined;

  // Notifications (e.g. notifications/initialized, notifications/cancelled) -> no response.
  if (isNotification || req.method.startsWith("notifications/")) {
    return null;
  }

  const id = req.id as JsonRpcId;
  try {
    const result = await dispatch(req.method, req.params);
    return ok(id, result);
  } catch (err) {
    if (err instanceof JsonRpcError) return fail(id, err.code, err.message, err.data);
    if (err instanceof ValidationError) return fail(id, INVALID_PARAMS, err.message);
    console.error("[mcp] internal error", err);
    return fail(id, INTERNAL_ERROR, err instanceof Error ? err.message : "Internal error");
  }
}

/**
 * Handle a parsed request body: a single message or a batch (array).
 * Returns the response payload, or `null` when nothing should be sent
 * (pure notification / response-only batch).
 */
export async function handleJsonRpc(body: unknown): Promise<JsonRpcResponse | JsonRpcResponse[] | null> {
  if (Array.isArray(body)) {
    if (body.length === 0) return fail(null, INVALID_REQUEST, "Empty batch");
    const results = await Promise.all(body.map((m) => handleMessage(m)));
    const responses = results.filter((r): r is JsonRpcResponse => r !== null);
    return responses.length ? responses : null;
  }
  return handleMessage(body);
}

/** Convenience: parse raw text then handle. Produces a parse error response on invalid JSON. */
export async function handleRawJsonRpc(raw: string): Promise<JsonRpcResponse | JsonRpcResponse[] | null> {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return fail(null, PARSE_ERROR, "Parse error: invalid JSON");
  }
  return handleJsonRpc(parsed);
}

/** Server manifest (useful for GET /api/mcp discovery and the README). */
export function getServerManifest() {
  return {
    ...SERVER_INFO,
    protocolVersions: SUPPORTED_PROTOCOL_VERSIONS,
    transport: "streamable-http (stateless)",
    methods: ["initialize", "ping", "tools/list", "tools/call", "resources/list", "prompts/list"],
    tools: listToolDefinitions().map((t) => ({ name: t.name, description: t.description })),
  };
}
