import { and, desc, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { messages, sessions, type Message, type Session } from "@/db/schema";
import { getConcept } from "./curriculum";
import {
  appendNode,
  branchIfThreshold,
  ensureLearner,
  getActiveBranch,
  getTip,
  mergeBackIfRecovered,
  type BranchDecision,
} from "./graph-engine";
import { updateEstimate, type UpdateEstimateResult } from "./learner-model";
import { getSummary } from "./learner-summary";
import { extractSignals, recordSignals, signalsToEvidence, type ExtractedSignal } from "./signal-extractor";
import { validateLearnerKey, validateMessage } from "./validator";

/* ------------------------------------------------------------------ */
/* Sessions                                                            */
/* ------------------------------------------------------------------ */

export async function startSession(learnerKey: string): Promise<{ session: Session; learnerId: number }> {
  const learner = await ensureLearner(validateLearnerKey(learnerKey));
  const [session] = await db.insert(sessions).values({ learnerId: learner.id }).returning();
  return { session, learnerId: learner.id };
}

export async function getOrCreateOpenSession(learnerId: number): Promise<Session> {
  const [open] = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.learnerId, learnerId), isNull(sessions.endedAt)))
    .orderBy(desc(sessions.id))
    .limit(1);
  if (open) return open;
  const [created] = await db.insert(sessions).values({ learnerId }).returning();
  return created;
}

export async function endSession(sessionId: number): Promise<Session | undefined> {
  const [row] = await db.update(sessions).set({ endedAt: new Date() }).where(eq(sessions.id, sessionId)).returning();
  return row;
}

export async function getSessionMessages(sessionId: number, limit = 100): Promise<Message[]> {
  const rows = await db.select().from(messages).where(eq(messages.sessionId, sessionId)).orderBy(desc(messages.id)).limit(limit);
  return rows.reverse();
}

/* ------------------------------------------------------------------ */
/* Adaptive step                                                       */
/* ------------------------------------------------------------------ */

export interface AdaptiveStepInput {
  learnerKey: string;
  message: string;
  sessionId?: number;
}

export interface AdaptiveStepResult {
  learnerId: number;
  sessionId: number;
  concept: string | null;
  signals: ExtractedSignal[];
  evidence: number | null;
  estimateUpdate: UpdateEstimateResult | null;
  branchDecision: BranchDecision | null;
  mergedBack: boolean;
  reply: string;
  tip: { id: number; type: string; concept: string | null; content: string };
  nextAction: string | null;
}

/**
 * One turn of the adaptive teaching loop:
 *   observe (extract signals) -> update learner model -> decide (branch?)
 *   -> act (append node + tutor reply).
 */
export async function runAdaptiveStep(input: AdaptiveStepInput): Promise<AdaptiveStepResult> {
  const learnerKey = validateLearnerKey(input.learnerKey);
  const text = validateMessage(input.message);

  const learner = await ensureLearner(learnerKey);
  const session = input.sessionId
    ? ((await db.select().from(sessions).where(eq(sessions.id, input.sessionId)).limit(1))[0] ??
      (await getOrCreateOpenSession(learner.id)))
    : await getOrCreateOpenSession(learner.id);

  await db.insert(messages).values({ sessionId: session.id, learnerId: learner.id, role: "learner", content: text });

  // 1. Observe -------------------------------------------------------
  const previousTip = await getTip(learner.id);
  const pendingConcept = previousTip.type === "question" ? previousTip.concept : null;
  const sigs = extractSignals(text, pendingConcept);
  const concept = sigs.find((s) => s.concept)?.concept ?? pendingConcept ?? null;
  const evidence = signalsToEvidence(sigs.filter((s) => !concept || s.concept === concept || s.concept === null));

  // 2. Update learner model -----------------------------------------
  let estimateUpdate: UpdateEstimateResult | null = null;
  if (concept && evidence !== null) {
    const hasGrade = sigs.some((s) => s.kind === "correct" || s.kind === "incorrect");
    estimateUpdate = await updateEstimate({
      learnerId: learner.id,
      concept,
      evidence,
      weight: hasGrade ? 0.8 : 0.4,
    });
  }

  // 3. Decide --------------------------------------------------------
  let branchDecision: BranchDecision | null = null;
  let mergedBack = false;
  if (concept) {
    mergedBack = await mergeBackIfRecovered(learner.id, concept);
    if (!mergedBack) branchDecision = await branchIfThreshold({ learnerId: learner.id, concept });
  }

  // 4. Act -----------------------------------------------------------
  const summary = await getSummary(learner.id);
  const next = summary.nextRecommendation;
  const activeBranch = await getActiveBranch(learner.id);
  const inRemediation = activeBranch.name.startsWith("remediate:");

  const targetConcept = inRemediation ? activeBranch.name.slice("remediate:".length) : (next?.concept ?? concept);
  const def = targetConcept ? getConcept(targetConcept) : undefined;

  const parts: string[] = [];
  const graded = sigs.find((s) => s.kind === "correct" || s.kind === "incorrect");
  if (graded?.kind === "correct") parts.push(`Correct! Nice work on ${getConcept(graded.concept!)?.title ?? graded.concept}.`);
  if (graded?.kind === "incorrect") parts.push(`Not quite. Let's look at ${getConcept(graded.concept!)?.title ?? graded.concept} again.`);
  if (sigs.some((s) => s.kind === "confusion")) parts.push("No problem - I'll slow down and explain it differently.");
  if (branchDecision?.applied) parts.push(`I've opened a focused review path for ${def?.title ?? targetConcept}.`);
  if (mergedBack) parts.push("Great recovery - back to the main path!");

  const shouldExplain =
    !!def &&
    (graded?.kind === "incorrect" ||
      sigs.some((s) => s.kind === "confusion" || s.kind === "question") ||
      branchDecision?.applied ||
      next?.action === "introduce" ||
      next?.action === "remediate");

  const nodeContents: { type: "explanation" | "question"; content: string }[] = [];
  if (def && shouldExplain) {
    parts.push(def.explanation);
    nodeContents.push({ type: "explanation", content: def.explanation });
  }
  if (def) {
    parts.push(`Try this: ${def.question}`);
    nodeContents.push({ type: "question", content: def.question });
  }
  if (!def) parts.push("Tell me which topic you'd like to work on: fractions, decimals, percentages, ratios or algebra.");

  const reply = parts.join(" ");

  for (const n of nodeContents) {
    await appendNode({ learnerId: learner.id, type: n.type, concept: targetConcept, content: n.content });
  }
  const tip = await getTip(learner.id);

  await recordSignals(learner.id, sigs, { sessionId: session.id, nodeId: tip.id });
  await db.insert(messages).values({ sessionId: session.id, learnerId: learner.id, role: "tutor", content: reply });

  return {
    learnerId: learner.id,
    sessionId: session.id,
    concept,
    signals: sigs,
    evidence,
    estimateUpdate,
    branchDecision,
    mergedBack,
    reply,
    tip: { id: tip.id, type: tip.type, concept: tip.concept, content: tip.content },
    nextAction: next ? `${next.action}:${next.concept}` : null,
  };
}
