/**
 * Static concept catalog used by the adaptive system.
 * Each concept lists its prerequisites and keyword hints used by the
 * signal extractor to detect which concept a learner is talking about.
 */
export interface ConceptDef {
  id: string;
  title: string;
  prerequisites: string[];
  keywords: string[];
  explanation: string;
  question: string;
  answerHints: string[];
}

export const CURRICULUM: ConceptDef[] = [
  {
    id: "fractions",
    title: "Fractions",
    prerequisites: [],
    keywords: ["fraction", "numerator", "denominator", "half", "quarter", "1/2", "3/4", "کسر"],
    explanation:
      "A fraction expresses a part of a whole: the numerator (top) counts parts, the denominator (bottom) says how many equal parts make the whole.",
    question: "What is 1/2 + 1/4?",
    answerHints: ["3/4", "0.75", "three quarters"],
  },
  {
    id: "decimals",
    title: "Decimals",
    prerequisites: ["fractions"],
    keywords: ["decimal", "point", "0.5", "tenth", "hundredth", "اعشار"],
    explanation:
      "Decimals are fractions whose denominator is a power of ten. 0.5 means 5/10, and 0.25 means 25/100.",
    question: "Write 3/4 as a decimal.",
    answerHints: ["0.75", ".75"],
  },
  {
    id: "percentages",
    title: "Percentages",
    prerequisites: ["decimals"],
    keywords: ["percent", "%", "percentage", "درصد"],
    explanation:
      "A percentage is a fraction out of 100. 25% means 25/100, which is the same as 0.25 or 1/4.",
    question: "What is 20% of 50?",
    answerHints: ["10", "ten"],
  },
  {
    id: "ratios",
    title: "Ratios & Proportions",
    prerequisites: ["fractions"],
    keywords: ["ratio", "proportion", "per", "rate", "نسبت"],
    explanation:
      "A ratio compares two quantities. If a recipe uses 2 cups of flour for every 1 cup of sugar, the ratio is 2:1.",
    question: "If the ratio of cats to dogs is 3:2 and there are 6 cats, how many dogs are there?",
    answerHints: ["4", "four"],
  },
  {
    id: "algebra-basics",
    title: "Algebra Basics",
    prerequisites: ["percentages", "ratios"],
    keywords: ["algebra", "variable", "equation", "solve for", "x =", "unknown", "معادله"],
    explanation:
      "Algebra uses symbols (like x) to stand for unknown numbers. To solve an equation, isolate the variable by doing the same operation to both sides.",
    question: "Solve for x: 2x + 3 = 11",
    answerHints: ["4", "x = 4", "x=4"],
  },
];

export const CONCEPT_IDS = CURRICULUM.map((c) => c.id);

export function getConcept(id: string): ConceptDef | undefined {
  return CURRICULUM.find((c) => c.id === id);
}
