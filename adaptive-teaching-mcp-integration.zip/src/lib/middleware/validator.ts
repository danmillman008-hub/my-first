import { CONCEPT_IDS } from "./curriculum";

/**
 * Input validation for the adaptive system. All validators throw
 * `ValidationError` with a human-readable message so callers (HTTP routes,
 * MCP tools) can surface them safely.
 */
export class ValidationError extends Error {
  readonly code = "VALIDATION_ERROR";
  constructor(message: string) {
    super(message);
    this.name = "ValidationError";
  }
}

export function validateLearnerKey(value: unknown): string {
  if (value === undefined || value === null || value === "") return "default";
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  if (typeof value !== "string") throw new ValidationError("learnerId must be a string");
  const trimmed = value.trim();
  if (trimmed.length === 0 || trimmed.length > 128) {
    throw new ValidationError("learnerId must be 1-128 characters");
  }
  return trimmed;
}

export function validateConcept(value: unknown): string {
  if (typeof value !== "string" || value.trim().length === 0) {
    throw new ValidationError("concept is required");
  }
  const concept = value.trim().toLowerCase();
  if (!CONCEPT_IDS.includes(concept)) {
    throw new ValidationError(`Unknown concept "${value}". Known concepts: ${CONCEPT_IDS.join(", ")}`);
  }
  return concept;
}

export function validateUnit(value: unknown, field: string, fallback?: number): number {
  if (value === undefined || value === null) {
    if (fallback !== undefined) return fallback;
    throw new ValidationError(`${field} is required`);
  }
  const num = typeof value === "string" ? Number(value) : value;
  if (typeof num !== "number" || !Number.isFinite(num) || num < 0 || num > 1) {
    throw new ValidationError(`${field} must be a number between 0 and 1`);
  }
  return num;
}

export function validateMessage(value: unknown): string {
  if (typeof value !== "string") throw new ValidationError("message must be a string");
  const trimmed = value.trim();
  if (trimmed.length === 0) throw new ValidationError("message cannot be empty");
  if (trimmed.length > 4000) throw new ValidationError("message is too long (max 4000 chars)");
  return trimmed;
}

export function validateOptionalInt(value: unknown, field: string): number | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  const num = typeof value === "string" ? Number(value) : value;
  if (typeof num !== "number" || !Number.isInteger(num) || num < 0) {
    throw new ValidationError(`${field} must be a non-negative integer`);
  }
  return num;
}

export function validateLimit(value: unknown, fallback = 50, max = 500): number {
  const parsed = validateOptionalInt(value, "limit");
  if (parsed === undefined) return fallback;
  return Math.min(Math.max(parsed, 1), max);
}

export function validateEnum<T extends string>(
  value: unknown,
  allowed: readonly T[],
  field: string,
): T | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  if (typeof value !== "string" || !allowed.includes(value as T)) {
    throw new ValidationError(`${field} must be one of: ${allowed.join(", ")}`);
  }
  return value as T;
}
