import { and, asc, desc, eq, inArray, SQL } from "drizzle-orm";
import { db } from "@/db";
import {
  branches,
  edges,
  learners,
  nodes,
  type Branch,
  type GraphEdge,
  type GraphNode,
  type Learner,
} from "@/db/schema";
import { getEstimate } from "./learner-model";
import { validateLimit, validateOptionalInt, validateEnum } from "./validator";

export const NODE_TYPES = [
  "root",
  "explanation",
  "question",
  "assessment",
  "remediation",
  "reflection",
] as const;
export const EDGE_TYPES = ["next", "branch", "remediates", "prerequisite"] as const;

export type NodeType = (typeof NODE_TYPES)[number];
export type EdgeType = (typeof EDGE_TYPES)[number];

export const DEFAULT_BRANCH_THRESHOLD = 0.4;
export const MIN_CONFIDENCE_FOR_BRANCH = 0.3;

/* ------------------------------------------------------------------ */
/* Learner bootstrap                                                   */
/* ------------------------------------------------------------------ */

/** Find or create a learner by external key and guarantee a root node + main branch. */
export async function ensureLearner(externalId: string, name?: string): Promise<Learner> {
  const [existing] = await db.select().from(learners).where(eq(learners.externalId, externalId)).limit(1);
  const learner =
    existing ??
    (
      await db
        .insert(learners)
        .values({ externalId, name: name ?? externalId })
        .onConflictDoNothing()
        .returning()
    )[0] ??
    (await db.select().from(learners).where(eq(learners.externalId, externalId)).limit(1))[0];

  await ensureRoot(learner.id);
  return learner;
}

export async function ensureRoot(learnerId: number): Promise<{ branch: Branch; root: GraphNode }> {
  let [branch] = await db
    .select()
    .from(branches)
    .where(and(eq(branches.learnerId, learnerId), eq(branches.name, "main")))
    .limit(1);

  if (!branch) {
    [branch] = await db
      .insert(branches)
      .values({ learnerId, name: "main", reason: "initial learning path", isActive: true })
      .returning();
  }

  let [root] = await db
    .select()
    .from(nodes)
    .where(and(eq(nodes.learnerId, learnerId), eq(nodes.type, "root")))
    .limit(1);

  if (!root) {
    [root] = await db
      .insert(nodes)
      .values({
        learnerId,
        branchId: branch.id,
        type: "root",
        content: "Learning journey start",
      })
      .returning();
  }
  return { branch, root };
}

/* ------------------------------------------------------------------ */
/* Branches                                                            */
/* ------------------------------------------------------------------ */

export async function getActiveBranch(learnerId: number): Promise<Branch> {
  const [active] = await db
    .select()
    .from(branches)
    .where(and(eq(branches.learnerId, learnerId), eq(branches.isActive, true)))
    .orderBy(desc(branches.createdAt), desc(branches.id))
    .limit(1);
  if (active) return active;
  const { branch } = await ensureRoot(learnerId);
  return branch;
}

export async function getBranches(learnerId: number): Promise<Branch[]> {
  return db.select().from(branches).where(eq(branches.learnerId, learnerId)).orderBy(asc(branches.id));
}

/* ------------------------------------------------------------------ */
/* Nodes & edges                                                       */
/* ------------------------------------------------------------------ */

export interface NodeFilter {
  learnerId?: number;
  branchId?: number;
  type?: string;
  concept?: string;
  limit?: number;
}

export async function getNodes(filter: NodeFilter = {}): Promise<GraphNode[]> {
  const conditions: SQL[] = [];
  if (filter.learnerId !== undefined) conditions.push(eq(nodes.learnerId, filter.learnerId));
  const branchId = validateOptionalInt(filter.branchId, "branchId");
  if (branchId !== undefined) conditions.push(eq(nodes.branchId, branchId));
  const type = validateEnum(filter.type, NODE_TYPES, "nodeType");
  if (type) conditions.push(eq(nodes.type, type));
  if (filter.concept) conditions.push(eq(nodes.concept, filter.concept));
  const limit = validateLimit(filter.limit, 100);

  return db
    .select()
    .from(nodes)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(nodes.id))
    .limit(limit);
}

export interface EdgeFilter {
  learnerId?: number;
  type?: string;
  fromNodeId?: number;
  toNodeId?: number;
  limit?: number;
}

export async function getEdges(filter: EdgeFilter = {}): Promise<GraphEdge[]> {
  const conditions: SQL[] = [];
  if (filter.learnerId !== undefined) conditions.push(eq(edges.learnerId, filter.learnerId));
  const type = validateEnum(filter.type, EDGE_TYPES, "edgeType");
  if (type) conditions.push(eq(edges.type, type));
  const from = validateOptionalInt(filter.fromNodeId, "fromNodeId");
  if (from !== undefined) conditions.push(eq(edges.fromNodeId, from));
  const to = validateOptionalInt(filter.toNodeId, "toNodeId");
  if (to !== undefined) conditions.push(eq(edges.toNodeId, to));
  const limit = validateLimit(filter.limit, 200);

  return db
    .select()
    .from(edges)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(edges.id))
    .limit(limit);
}

/** The "tip" is the most recent node on the active (or given) branch. */
export async function getTip(learnerId: number, branchId?: number): Promise<GraphNode> {
  const branch = branchId !== undefined ? undefined : await getActiveBranch(learnerId);
  const targetBranchId = branchId ?? branch!.id;

  const [tip] = await db
    .select()
    .from(nodes)
    .where(and(eq(nodes.learnerId, learnerId), eq(nodes.branchId, targetBranchId)))
    .orderBy(desc(nodes.id))
    .limit(1);

  if (tip) return tip;

  // Branch without nodes yet (e.g. freshly forked) -> fall back to fork point or root.
  const [b] = await db.select().from(branches).where(eq(branches.id, targetBranchId)).limit(1);
  if (b?.forkedFromNodeId) {
    const [forkNode] = await db.select().from(nodes).where(eq(nodes.id, b.forkedFromNodeId)).limit(1);
    if (forkNode) return forkNode;
  }
  const { root } = await ensureRoot(learnerId);
  return root;
}

export interface AppendNodeInput {
  learnerId: number;
  type: NodeType;
  content: string;
  concept?: string | null;
  branchId?: number;
  edgeType?: EdgeType;
}

/** Append a node after the current tip and link it with an edge. */
export async function appendNode(input: AppendNodeInput): Promise<{ node: GraphNode; edge: GraphEdge }> {
  const branch = input.branchId !== undefined ? undefined : await getActiveBranch(input.learnerId);
  const branchId = input.branchId ?? branch!.id;
  const tip = await getTip(input.learnerId, branchId);

  const [node] = await db
    .insert(nodes)
    .values({
      learnerId: input.learnerId,
      branchId,
      parentId: tip.id,
      type: input.type,
      concept: input.concept ?? null,
      content: input.content,
    })
    .returning();

  const [edge] = await db
    .insert(edges)
    .values({
      learnerId: input.learnerId,
      fromNodeId: tip.id,
      toNodeId: node.id,
      type: input.edgeType ?? "next",
      weight: 1,
    })
    .returning();

  return { node, edge };
}

/* ------------------------------------------------------------------ */
/* Branching                                                           */
/* ------------------------------------------------------------------ */

export interface BranchIfInput {
  learnerId: number;
  concept: string;
  threshold?: number;
  /** When false, only evaluate the decision without mutating the graph. */
  apply?: boolean;
}

export interface BranchDecision {
  shouldBranch: boolean;
  applied: boolean;
  reason: string;
  concept: string;
  threshold: number;
  mastery: number;
  confidence: number;
  branch?: Branch;
  node?: GraphNode;
}

/**
 * Branch into a remediation path when the learner's mastery of `concept`
 * has dropped below the threshold with sufficient confidence, and no
 * remediation branch for that concept is already active.
 */
export async function branchIfThreshold(input: BranchIfInput): Promise<BranchDecision> {
  const threshold = input.threshold ?? DEFAULT_BRANCH_THRESHOLD;
  const apply = input.apply ?? true;
  const estimate = await getEstimate(input.learnerId, input.concept);
  const mastery = estimate?.mastery ?? 0.5;
  const confidence = estimate?.confidence ?? 0;

  const base = { concept: input.concept, threshold, mastery, confidence, applied: false };

  if (confidence < MIN_CONFIDENCE_FOR_BRANCH) {
    return {
      ...base,
      shouldBranch: false,
      reason: `Not enough evidence yet (confidence ${confidence.toFixed(2)} < ${MIN_CONFIDENCE_FOR_BRANCH}).`,
    };
  }
  if (mastery >= threshold) {
    return {
      ...base,
      shouldBranch: false,
      reason: `Mastery ${mastery.toFixed(2)} is at or above threshold ${threshold}.`,
    };
  }

  const remediationName = `remediate:${input.concept}`;
  const [existing] = await db
    .select()
    .from(branches)
    .where(
      and(
        eq(branches.learnerId, input.learnerId),
        eq(branches.name, remediationName),
        eq(branches.isActive, true),
      ),
    )
    .limit(1);

  if (existing) {
    return {
      ...base,
      shouldBranch: true,
      reason: `Remediation branch for "${input.concept}" is already active.`,
      branch: existing,
    };
  }

  const reason = `Mastery ${mastery.toFixed(2)} fell below threshold ${threshold} (confidence ${confidence.toFixed(2)}).`;
  if (!apply) {
    return { ...base, shouldBranch: true, reason: `${reason} [dry-run]` };
  }

  const current = await getActiveBranch(input.learnerId);
  const tip = await getTip(input.learnerId, current.id);

  // Deactivate other branches, open the remediation branch.
  const activeIds = (await getBranches(input.learnerId)).filter((b) => b.isActive).map((b) => b.id);
  if (activeIds.length) {
    await db.update(branches).set({ isActive: false }).where(inArray(branches.id, activeIds));
  }

  const [branch] = await db
    .insert(branches)
    .values({
      learnerId: input.learnerId,
      name: remediationName,
      parentBranchId: current.id,
      forkedFromNodeId: tip.id,
      reason,
      isActive: true,
    })
    .returning();

  const [node] = await db
    .insert(nodes)
    .values({
      learnerId: input.learnerId,
      branchId: branch.id,
      parentId: tip.id,
      type: "remediation",
      concept: input.concept,
      content: `Remediation path opened for ${input.concept}: ${reason}`,
    })
    .returning();

  await db.insert(edges).values({
    learnerId: input.learnerId,
    fromNodeId: tip.id,
    toNodeId: node.id,
    type: "branch",
    weight: 1 - mastery,
  });

  return { ...base, shouldBranch: true, applied: true, reason, branch, node };
}

/** Close a remediation branch and return to its parent (called when mastery recovers). */
export async function mergeBackIfRecovered(learnerId: number, concept: string, threshold = 0.65): Promise<boolean> {
  const active = await getActiveBranch(learnerId);
  if (active.name !== `remediate:${concept}` || !active.parentBranchId) return false;
  const estimate = await getEstimate(learnerId, concept);
  if (!estimate || estimate.mastery < threshold) return false;

  const tip = await getTip(learnerId, active.id);
  await db.update(branches).set({ isActive: false }).where(eq(branches.id, active.id));
  await db.update(branches).set({ isActive: true }).where(eq(branches.id, active.parentBranchId));

  const [node] = await db
    .insert(nodes)
    .values({
      learnerId,
      branchId: active.parentBranchId,
      parentId: tip.id,
      type: "reflection",
      concept,
      content: `Recovered ${concept} (mastery ${estimate.mastery.toFixed(2)}); merged back to main path.`,
    })
    .returning();
  await db.insert(edges).values({
    learnerId,
    fromNodeId: tip.id,
    toNodeId: node.id,
    type: "remediates",
    weight: estimate.mastery,
  });
  return true;
}
