import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { edges, nodes, signals, type Branch, type Estimate, type GraphNode, type Signal } from "@/db/schema";
import { CURRICULUM, getConcept } from "./curriculum";
import { getEstimates } from "./learner-model";
import { getActiveBranch, getBranches, getTip } from "./graph-engine";

export const SIGNAL_KINDS = [
  "correct",
  "incorrect",
  "confusion",
  "confidence",
  "hesitation",
  "question",
] as const;
export type SignalKind = (typeof SIGNAL_KINDS)[number];

export interface ExtractedSignal {
  kind: SignalKind;
  concept: string | null;
  /** Strength 0..1 */
  value: number;
  evidence: string;
}

const CONFUSION_PATTERNS = [
  /don'?t (understand|get)/i,
  /confus/i,
  /lost/i,
  /no idea/i,
  /what does .* mean/i,
  /i'?m stuck/i,
  /نمی\s?فهمم/,
  /گیج/,
];
const CONFIDENCE_PATTERNS = [
  /got it/i,
  /makes sense/i,
  /i (understand|see|know)/i,
  /easy/i,
  /of course/i,
  /فهمیدم/,
  /متوجه شدم/,
];
const HESITATION_PATTERNS = [/\bmaybe\b/i, /\bi think\b/i, /not sure/i, /\bum+\b/i, /\bguess\b/i, /شاید/, /فکر کنم/];

/* ------------------------------------------------------------------ */
/* Extraction                                                          */
/* ------------------------------------------------------------------ */

/** Detect which curriculum concept a message is most likely about. */
export function detectConcept(text: string, fallback?: string | null): string | null {
  const lower = text.toLowerCase();
  let best: { id: string; hits: number } | null = null;
  for (const c of CURRICULUM) {
    const hits = c.keywords.reduce((n, k) => (lower.includes(k.toLowerCase()) ? n + 1 : n), 0);
    if (hits > 0 && (!best || hits > best.hits)) best = { id: c.id, hits };
  }
  return best?.id ?? fallback ?? null;
}

function normalize(s: string): string {
  return s.toLowerCase().replace(/\s+/g, " ").trim();
}

/**
 * Pure, side-effect-free signal extraction from a learner utterance.
 * `expectedConcept` is the concept the tutor last asked about (if any);
 * it is used to grade answers against the curriculum's answer hints.
 */
export function extractSignals(text: string, expectedConcept?: string | null): ExtractedSignal[] {
  const out: ExtractedSignal[] = [];
  const concept = detectConcept(text, expectedConcept ?? null);
  const norm = normalize(text);

  for (const p of CONFUSION_PATTERNS) {
    if (p.test(text)) {
      out.push({ kind: "confusion", concept, value: 0.8, evidence: `matched ${p}` });
      break;
    }
  }
  for (const p of CONFIDENCE_PATTERNS) {
    if (p.test(text)) {
      out.push({ kind: "confidence", concept, value: 0.6, evidence: `matched ${p}` });
      break;
    }
  }
  for (const p of HESITATION_PATTERNS) {
    if (p.test(text)) {
      out.push({ kind: "hesitation", concept, value: 0.5, evidence: `matched ${p}` });
      break;
    }
  }
  if (/\?\s*$/.test(text.trim()) || /^(why|how|what|when|چرا|چطور|چگونه)\b/i.test(text.trim())) {
    out.push({ kind: "question", concept, value: 0.5, evidence: "interrogative form" });
  }

  // Grade against expected answer when a question is pending.
  if (expectedConcept) {
    const def = getConcept(expectedConcept);
    if (def) {
      const matched = def.answerHints.some((h) => {
        const hint = normalize(h);
        return new RegExp(`(^|[^\\w./])${hint.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^\\w./]|$)`).test(norm);
      });
      const looksLikeAnswer = /\d/.test(text) || /=/.test(text) || norm.split(" ").length <= 6;
      if (matched) {
        out.push({ kind: "correct", concept: expectedConcept, value: 1, evidence: `matched answer hint for ${expectedConcept}` });
      } else if (looksLikeAnswer && !out.some((s) => s.kind === "confusion" || s.kind === "question")) {
        out.push({ kind: "incorrect", concept: expectedConcept, value: 1, evidence: `no answer hint matched for ${expectedConcept}` });
      }
    }
  }

  return out;
}

/** Collapse signals into a single performance observation in [0,1] for a concept. */
export function signalsToEvidence(sigs: ExtractedSignal[]): number | null {
  if (sigs.length === 0) return null;
  let score = 0;
  let weight = 0;
  const table: Record<SignalKind, number> = {
    correct: 1,
    confidence: 0.75,
    question: 0.45,
    hesitation: 0.35,
    confusion: 0.15,
    incorrect: 0,
  };
  for (const s of sigs) {
    score += table[s.kind] * s.value;
    weight += s.value;
  }
  return weight === 0 ? null : score / weight;
}

/* ------------------------------------------------------------------ */
/* Persistence                                                         */
/* ------------------------------------------------------------------ */

export async function recordSignals(
  learnerId: number,
  sigs: ExtractedSignal[],
  ctx: { sessionId?: number | null; nodeId?: number | null } = {},
): Promise<Signal[]> {
  if (sigs.length === 0) return [];
  return db
    .insert(signals)
    .values(
      sigs.map((s) => ({
        learnerId,
        sessionId: ctx.sessionId ?? null,
        nodeId: ctx.nodeId ?? null,
        kind: s.kind,
        concept: s.concept,
        value: s.value,
        evidence: s.evidence,
      })),
    )
    .returning();
}

export async function getRecentSignals(learnerId: number, limit = 20): Promise<Signal[]> {
  return db.select().from(signals).where(eq(signals.learnerId, learnerId)).orderBy(desc(signals.id)).limit(limit);
}

/* ------------------------------------------------------------------ */
/* Snapshot                                                            */
/* ------------------------------------------------------------------ */

export interface LearnerSnapshot {
  learnerId: number;
  activeBranch: Branch;
  tip: GraphNode;
  branches: Branch[];
  estimates: Estimate[];
  recentSignals: Signal[];
  counts: { nodes: number; edges: number; branches: number; signals: number };
  signalMix: Record<string, number>;
  generatedAt: string;
}

/** Compact, read-only view of the learner's current state. */
export async function getSnapshot(learnerId: number, opts: { signalLimit?: number } = {}): Promise<LearnerSnapshot> {
  const [activeBranch, tip, allBranches, ests, recent, nodeCount, edgeCount, signalCount] = await Promise.all([
    getActiveBranch(learnerId),
    getTip(learnerId),
    getBranches(learnerId),
    getEstimates(learnerId),
    getRecentSignals(learnerId, opts.signalLimit ?? 15),
    db.select({ c: sql<number>`count(*)::int` }).from(nodes).where(eq(nodes.learnerId, learnerId)),
    db.select({ c: sql<number>`count(*)::int` }).from(edges).where(eq(edges.learnerId, learnerId)),
    db.select({ c: sql<number>`count(*)::int` }).from(signals).where(eq(signals.learnerId, learnerId)),
  ]);

  const signalMix: Record<string, number> = {};
  for (const s of recent) signalMix[s.kind] = (signalMix[s.kind] ?? 0) + 1;


  return {
    learnerId,
    activeBranch,
    tip,
    branches: allBranches,
    estimates: ests,
    recentSignals: recent,
    counts: {
      nodes: nodeCount[0]?.c ?? 0,
      edges: edgeCount[0]?.c ?? 0,
      branches: allBranches.length,
      signals: signalCount[0]?.c ?? 0,
    },
    signalMix,
    generatedAt: new Date().toISOString(),
  };
}
