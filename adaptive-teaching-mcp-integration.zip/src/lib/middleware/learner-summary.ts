import type { Estimate } from "@/db/schema";
import { CURRICULUM, getConcept } from "./curriculum";
import { getEstimates } from "./learner-model";
import { getActiveBranch, getTip, DEFAULT_BRANCH_THRESHOLD } from "./graph-engine";

export const MASTERED_THRESHOLD = 0.7;

export interface ConceptStatus {
  concept: string;
  title: string;
  mastery: number;
  confidence: number;
  attempts: number;
  status: "mastered" | "developing" | "weak" | "unseen";
  prerequisitesMet: boolean;
}

export interface LearnerSummary {
  learnerId: number;
  overallMastery: number;
  overallConfidence: number;
  concepts: ConceptStatus[];
  weakConcepts: string[];
  masteredConcepts: string[];
  nextRecommendation: {
    concept: string;
    title: string;
    action: "remediate" | "practice" | "introduce" | "review";
    rationale: string;
  } | null;
  activeBranch: { id: number; name: string; reason: string | null };
  tip: { id: number; type: string; concept: string | null; content: string };
  headline: string;
}

function classify(e: Estimate): ConceptStatus["status"] {
  if (e.attempts === 0) return "unseen";
  if (e.mastery >= MASTERED_THRESHOLD) return "mastered";
  if (e.mastery < DEFAULT_BRANCH_THRESHOLD) return "weak";
  return "developing";
}

/** Choose what the learner should work on next. */
export function recommendNext(concepts: ConceptStatus[]): LearnerSummary["nextRecommendation"] {
  const byId = new Map(concepts.map((c) => [c.concept, c]));

  // 1. Weak concepts with evidence -> remediate (lowest mastery first).
  const weak = concepts
    .filter((c) => c.status === "weak")
    .sort((a, b) => a.mastery - b.mastery)[0];
  if (weak) {
    return {
      concept: weak.concept,
      title: weak.title,
      action: "remediate",
      rationale: `Mastery ${weak.mastery.toFixed(2)} is below ${DEFAULT_BRANCH_THRESHOLD}; revisit fundamentals before moving on.`,
    };
  }

  // 2. Developing concepts -> more practice.
  const developing = concepts
    .filter((c) => c.status === "developing")
    .sort((a, b) => a.mastery - b.mastery)[0];
  if (developing) {
    return {
      concept: developing.concept,
      title: developing.title,
      action: "practice",
      rationale: `Mastery ${developing.mastery.toFixed(2)} is improving; targeted practice should push it past ${MASTERED_THRESHOLD}.`,
    };
  }

  // 3. Unseen concept whose prerequisites are mastered -> introduce (curriculum order).
  for (const def of CURRICULUM) {
    const c = byId.get(def.id);
    if (!c || c.status !== "unseen") continue;
    const prereqsMet = def.prerequisites.every((p) => byId.get(p)?.status === "mastered");
    if (prereqsMet) {
      return {
        concept: def.id,
        title: def.title,
        action: "introduce",
        rationale: def.prerequisites.length
          ? `Prerequisites (${def.prerequisites.join(", ")}) are mastered.`
          : "Entry point of the curriculum.",
      };
    }
  }

  // 4. Everything mastered -> review the least confident one.
  const review = [...concepts].sort((a, b) => a.confidence - b.confidence)[0];
  return review
    ? {
        concept: review.concept,
        title: review.title,
        action: "review",
        rationale: "All concepts mastered; spaced review keeps them fresh.",
      }
    : null;
}

export async function getSummary(learnerId: number): Promise<LearnerSummary> {
  const [ests, activeBranch, tip] = await Promise.all([
    getEstimates(learnerId),
    getActiveBranch(learnerId),
    getTip(learnerId),
  ]);

  const statuses = new Map<string, ConceptStatus["status"]>(ests.map((e) => [e.concept, classify(e)]));
  const concepts: ConceptStatus[] = ests.map((e) => {
    const def = getConcept(e.concept);
    return {
      concept: e.concept,
      title: def?.title ?? e.concept,
      mastery: e.mastery,
      confidence: e.confidence,
      attempts: e.attempts,
      status: classify(e),
      prerequisitesMet: (def?.prerequisites ?? []).every((p) => statuses.get(p) === "mastered"),
    };
  });

  const seen = concepts.filter((c) => c.status !== "unseen");
  const overallMastery = seen.length ? seen.reduce((s, c) => s + c.mastery, 0) / seen.length : 0;
  const overallConfidence = seen.length ? seen.reduce((s, c) => s + c.confidence, 0) / seen.length : 0;

  const weakConcepts = concepts.filter((c) => c.status === "weak").map((c) => c.concept);
  const masteredConcepts = concepts.filter((c) => c.status === "mastered").map((c) => c.concept);
  const nextRecommendation = recommendNext(concepts);

  const headline =
    seen.length === 0
      ? "No evidence yet - start a conversation to build the learner model."
      : `${masteredConcepts.length}/${concepts.length} concepts mastered, overall mastery ${(overallMastery * 100).toFixed(0)}%` +
        (weakConcepts.length ? `; needs help with ${weakConcepts.join(", ")}.` : ".");

  return {
    learnerId,
    overallMastery,
    overallConfidence,
    concepts,
    weakConcepts,
    masteredConcepts,
    nextRecommendation,
    activeBranch: { id: activeBranch.id, name: activeBranch.name, reason: activeBranch.reason },
    tip: { id: tip.id, type: tip.type, concept: tip.concept, content: tip.content },
    headline,
  };
}
