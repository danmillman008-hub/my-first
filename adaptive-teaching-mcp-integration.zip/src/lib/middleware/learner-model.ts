import { and, asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { estimates, type Estimate } from "@/db/schema";
import { CONCEPT_IDS } from "./curriculum";
import { validateConcept, validateUnit } from "./validator";

export const PRIOR_MASTERY = 0.5;
export const PRIOR_CONFIDENCE = 0.1;

/* ------------------------------------------------------------------ */
/* Reads                                                               */
/* ------------------------------------------------------------------ */

export async function getEstimate(learnerId: number, concept: string): Promise<Estimate | undefined> {
  const [row] = await db
    .select()
    .from(estimates)
    .where(and(eq(estimates.learnerId, learnerId), eq(estimates.concept, concept)))
    .limit(1);
  return row;
}

/** All estimates for a learner, with priors filled in for concepts never seen. */
export async function getEstimates(learnerId: number): Promise<Estimate[]> {
  const rows = await db
    .select()
    .from(estimates)
    .where(eq(estimates.learnerId, learnerId))
    .orderBy(asc(estimates.concept));
  const seen = new Set(rows.map((r) => r.concept));
  const now = new Date();
  const missing: Estimate[] = CONCEPT_IDS.filter((c) => !seen.has(c)).map((concept, i) => ({
    id: -(i + 1),
    learnerId,
    concept,
    mastery: PRIOR_MASTERY,
    confidence: PRIOR_CONFIDENCE,
    attempts: 0,
    updatedAt: now,
  }));
  return [...rows, ...missing].sort((a, b) => CONCEPT_IDS.indexOf(a.concept) - CONCEPT_IDS.indexOf(b.concept));
}

/* ------------------------------------------------------------------ */
/* Updates                                                             */
/* ------------------------------------------------------------------ */

export interface UpdateEstimateInput {
  learnerId: number;
  concept: string;
  /** Observed performance for this interaction, 0 (failed) .. 1 (perfect). */
  evidence: number;
  /** How much to trust this observation, 0..1. Defaults to 0.5. */
  weight?: number;
  /** Optional absolute override; when provided `evidence` is ignored. */
  mastery?: number;
}

export interface UpdateEstimateResult {
  estimate: Estimate;
  previous: { mastery: number; confidence: number; attempts: number };
  delta: number;
}

/**
 * Update the learner's mastery estimate for a concept.
 *
 * Model: an exponential moving average whose learning rate shrinks as the
 * model becomes more confident, so early evidence moves the estimate a lot
 * and later evidence refines it. Confidence itself grows with every
 * observation and is damped by surprising (high-error) observations.
 */
export async function updateEstimate(input: UpdateEstimateInput): Promise<UpdateEstimateResult> {
  const concept = validateConcept(input.concept);
  const weight = validateUnit(input.weight, "weight", 0.5);

  const current = await getEstimate(input.learnerId, concept);
  const prevMastery = current?.mastery ?? PRIOR_MASTERY;
  const prevConfidence = current?.confidence ?? PRIOR_CONFIDENCE;
  const prevAttempts = current?.attempts ?? 0;

  let nextMastery: number;
  let nextConfidence: number;

  if (input.mastery !== undefined) {
    nextMastery = validateUnit(input.mastery, "mastery");
    nextConfidence = Math.min(1, prevConfidence + 0.2 * weight);
  } else {
    const evidence = validateUnit(input.evidence, "evidence");
    // Learning rate: high while uncertain, floors at 0.15 once confident.
    const rate = Math.max(0.15, (1 - prevConfidence) * 0.6) * weight;
    nextMastery = prevMastery + rate * (evidence - prevMastery);
    const surprise = Math.abs(evidence - prevMastery); // 0..1
    nextConfidence = Math.min(1, prevConfidence + 0.12 * weight * (1 - 0.5 * surprise));
  }

  nextMastery = Math.min(1, Math.max(0, nextMastery));

  const [row] = await db
    .insert(estimates)
    .values({
      learnerId: input.learnerId,
      concept,
      mastery: nextMastery,
      confidence: nextConfidence,
      attempts: prevAttempts + 1,
      updatedAt: new Date(),
    })
    .onConflictDoUpdate({
      target: [estimates.learnerId, estimates.concept],
      set: {
        mastery: nextMastery,
        confidence: nextConfidence,
        attempts: sql`${estimates.attempts} + 1`,
        updatedAt: new Date(),
      },
    })
    .returning();

  return {
    estimate: row,
    previous: { mastery: prevMastery, confidence: prevConfidence, attempts: prevAttempts },
    delta: nextMastery - prevMastery,
  };
}
