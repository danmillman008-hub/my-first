import {
  pgTable,
  serial,
  text,
  integer,
  real,
  boolean,
  timestamp,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Learners & sessions                                                 */
/* ------------------------------------------------------------------ */

export const learners = pgTable(
  "learners",
  {
    id: serial("id").primaryKey(),
    externalId: text("external_id").notNull(),
    name: text("name").notNull().default("Learner"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("learners_external_id_idx").on(t.externalId)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    endedAt: timestamp("ended_at", { withTimezone: true }),
  },
  (t) => [index("sessions_learner_idx").on(t.learnerId)],
);

export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    sessionId: integer("session_id")
      .notNull()
      .references(() => sessions.id, { onDelete: "cascade" }),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    role: text("role").notNull(), // "learner" | "tutor" | "system"
    content: text("content").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("messages_session_idx").on(t.sessionId)],
);

/* ------------------------------------------------------------------ */
/* Learning graph: branches, nodes, edges                              */
/* ------------------------------------------------------------------ */

export const branches = pgTable(
  "branches",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    parentBranchId: integer("parent_branch_id"),
    forkedFromNodeId: integer("forked_from_node_id"),
    reason: text("reason"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("branches_learner_idx").on(t.learnerId)],
);

export const nodes = pgTable(
  "nodes",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    branchId: integer("branch_id")
      .notNull()
      .references(() => branches.id, { onDelete: "cascade" }),
    parentId: integer("parent_id"),
    type: text("type").notNull(), // root | explanation | question | assessment | remediation | reflection
    concept: text("concept"),
    content: text("content").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("nodes_learner_idx").on(t.learnerId),
    index("nodes_branch_idx").on(t.branchId),
  ],
);

export const edges = pgTable(
  "edges",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    fromNodeId: integer("from_node_id")
      .notNull()
      .references(() => nodes.id, { onDelete: "cascade" }),
    toNodeId: integer("to_node_id")
      .notNull()
      .references(() => nodes.id, { onDelete: "cascade" }),
    type: text("type").notNull(), // next | branch | remediates | prerequisite
    weight: real("weight").notNull().default(1),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("edges_from_idx").on(t.fromNodeId),
    index("edges_to_idx").on(t.toNodeId),
  ],
);

/* ------------------------------------------------------------------ */
/* Learner model: estimates & signals                                  */
/* ------------------------------------------------------------------ */

export const estimates = pgTable(
  "estimates",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    concept: text("concept").notNull(),
    mastery: real("mastery").notNull().default(0.5), // 0..1
    confidence: real("confidence").notNull().default(0.1), // 0..1 (how sure the model is)
    attempts: integer("attempts").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("estimates_learner_concept_idx").on(t.learnerId, t.concept)],
);

export const signals = pgTable(
  "signals",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id")
      .notNull()
      .references(() => learners.id, { onDelete: "cascade" }),
    sessionId: integer("session_id"),
    nodeId: integer("node_id"),
    kind: text("kind").notNull(), // correct | incorrect | confusion | confidence | hesitation | question
    concept: text("concept"),
    value: real("value").notNull().default(1),
    evidence: text("evidence"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("signals_learner_idx").on(t.learnerId)],
);

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

export type Learner = typeof learners.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type Branch = typeof branches.$inferSelect;
export type GraphNode = typeof nodes.$inferSelect;
export type GraphEdge = typeof edges.$inferSelect;
export type Estimate = typeof estimates.$inferSelect;
export type Signal = typeof signals.$inferSelect;
